"""Receive-only capture for the verified FT4232H channel-C COM16."""
import datetime
import json
import pathlib
import re
import sys
import time

import serial

out = pathlib.Path(sys.argv[1])
stop = out / 'stop_uart'
s = serial.Serial(port=None, baudrate=115200, timeout=0.1)
s.dtr = False
s.rts = False
s.port = sys.argv[2] if len(sys.argv) > 2 else 'COM16'
with (out / 'uart.bin').open('wb') as raw, (out / 'uart_lines.jsonl').open('w', encoding='utf-8') as rows:
    try:
        s.open()
        (out / 'uart_ready').write_text(s.port + ', 115200', encoding='ascii')
        pending = b''
        deadline = time.monotonic() + (int(sys.argv[3]) if len(sys.argv) > 3 else 900)
        command_offset = 0
        command_path = out / 'uart_commands.bin'
        while not stop.exists() and time.monotonic() < deadline:
            if command_path.exists():
                commands = command_path.read_bytes()
                if len(commands) > command_offset:
                    s.write(commands[command_offset:])
                    command_offset = len(commands)
            data = s.read(max(1, min(s.in_waiting, 4096)))
            if not data:
                continue
            raw.write(data)
            raw.flush()
            pending += data
            while b'\n' in pending:
                line, pending = pending.split(b'\n', 1)
                item = {'monotonic': time.monotonic(), 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        'line': line.rstrip(b'\r').decode('ascii', errors='replace')}
                rows.write(json.dumps(item) + '\n')
                rows.flush()
        if pending:
            rows.write(json.dumps({'monotonic': time.monotonic(), 'partial': True,
                                   'line': pending.decode('ascii', errors='replace')}) + '\n')
    except Exception as exc:
        (out / 'uart_error.txt').write_text(str(exc), encoding='utf-8')
        raise
    finally:
        s.close()
