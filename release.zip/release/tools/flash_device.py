"""Board-specific Flash backup/orchestration. No erase/write path in backup mode.

Uses the installed vendor programmer unmodified. Physical USB identity and
bridge ID are checked; read mode is an explicit immutable argument list.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,subprocess,time,shutil,sys

ROOT=Path(__file__).resolve().parents[1]
EF=Path('D:/ELSFPGA');LIBUSB=Path('D:/ELSFPGARSIC-V/openocd/bin/libusb-1.0.dll')
BRIDGE=EF/'pgm/fli/titanium/uANONYMOUS.bit'
LOCATION='1-3';CAPACITY=8388608
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def ftdi_url(device):
    # Efinity's Windows resolver and PyFTDI parse both locators as hexadecimal.
    # Decimal happened to work for addresses 1..9, then selected a different
    # address after USB re-enumeration to 10. Physical port identity is still
    # checked by inventory before this pure formatting helper is called.
    bus,address=device['bus'],device['address']
    if type(bus) is not int or type(address) is not int or not 1<=bus<=255 or not 1<=address<=255:
        raise RuntimeError('Invalid enumerated FTDI bus/address')
    return 'ftdi://0x0403:0x6011:%x:%x/2'%(bus,address)
def vendor_env(directory):
    env=os.environ.copy();env['EFINITY_HOME']=EF.as_posix()
    for k,s in [('EFXPT_HOME','pt'),('EFXPGM_HOME','pgm'),('EFXDBG_HOME','debugger'),('EFXIPM_HOME','ipm'),('EFXSVF_HOME','debugger/svf_player')]:env[k]=(EF/s).as_posix()
    env.update(PYTHONHOME=str(EF/'python311'),PYTHONPATH=os.pathsep.join(str(EF/s) for s in ['pgm/bin','debugger/bin']),PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONUNBUFFERED='1',QT_PLUGIN_PATH=str(EF/'bin'),QT_QPA_PLATFORM_PLUGIN_PATH=str(EF/'python311/platforms'),EFINITY_USER_DIR=str(directory),EFINITY_USER_DIR_INI=str(directory/'user_dir.ini'))
    directory.mkdir(parents=True,exist_ok=True)
    env['PATH']=os.pathsep.join(str(EF/s) for s in ['python311/bin','bin','pgm/bin','debugger/bin','scripts'])+os.pathsep+env.get('PATH','')
    return env
def inventory(env):
    code='import usb.core,usb.backend.libusb1,json; b=usb.backend.libusb1.get_backend(find_library=lambda n:'+repr(str(LIBUSB))+'); print(json.dumps([{"bus":d.bus,"address":d.address,"ports":d.port_numbers} for d in usb.core.find(find_all=True,idVendor=0x0403,idProduct=0x6011,backend=b)]))'
    r=subprocess.run([str(EF/'python311/bin/python.exe'),'-c',code],env=env,capture_output=True,text=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    if r.returncode:raise RuntimeError(r.stdout+r.stderr)
    devices=json.loads(r.stdout)
    if not re.fullmatch(r'[1-9][0-9]*-[1-9][0-9]*(?:\.[1-9][0-9]*)*',LOCATION):raise RuntimeError('Invalid explicit physical USB location')
    bus,ports=LOCATION.split('-',1);ports=[int(x) for x in ports.split('.')]
    if len(devices)!=1 or devices[0]['bus']!=int(bus) or devices[0]['ports']!=ports:raise RuntimeError('Unexpected USB physical identity; no JTAG/Flash operation performed')
    return devices[0]
def command(args,log,env,timeout=300,on_line=None):
    started=time.monotonic();last_alive=started;pending=''
    with log.open('wb') as output:
        p=subprocess.Popen([str(x) for x in args],env=env,cwd=log.parent,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        with log.open('rb') as read:
            try:
                while True:
                    pending+=read.read().decode('utf-8',errors='replace')
                    while '\n' in pending:
                        line,pending=pending.split('\n',1);line=line.rstrip('\r');print(line,flush=True)
                        if on_line:on_line(line)
                    if p.poll() is not None:
                        pending+=read.read().decode('utf-8',errors='replace')
                        if pending:
                            print(pending,flush=True)
                            if on_line:
                                for line in pending.splitlines():on_line(line)
                        break
                    if time.monotonic()-started>timeout:raise TimeoutError('Vendor operation timed out; retained '+str(log))
                    if time.monotonic()-last_alive>=2:
                        print('TOOL_ALIVE operation=%s elapsed_s=%d process_running=1 byte_progress_unknown=1'%(log.stem,int(time.monotonic()-started)),flush=True)
                        last_alive=time.monotonic()
                    time.sleep(.1)
            except BaseException:
                p.terminate()
                try:p.wait(timeout=10)
                except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5)
                raise
    text=log.read_text(encoding='utf-8',errors='replace')
    if p.returncode:raise RuntimeError('Vendor operation failed '+str(p.returncode)+': '+str(log))
    return text
def base_args(url):return [EF/'python311/bin/python.exe',EF/'pgm/bin/efx_pgm/ftdi_program.py','-u',url,'-b','Generic Board Profile Using FT4232H','--jtag_clock_freq','6000000']
def decode_hex(path,dest,expected=CAPACITY):
    lines=path.read_text(encoding='ascii').splitlines()
    if any(not re.fullmatch('[0-9a-fA-F]{2}',line) for line in lines):raise RuntimeError('Not an exact vendor raw byte HEX dump')
    data=bytes.fromhex(''.join(lines))
    if len(data)!=expected:raise RuntimeError('Unexpected complete Flash read size '+str(len(data)))
    dest.write_bytes(data);return data
def backup():
    session=ROOT/'sessions'/('backup_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));session.mkdir(parents=True)
    env=vendor_env(session/'vendor_user');device=inventory(env);url=ftdi_url(device)
    report={'status':'IN_PROGRESS','operation':'fresh_double_read_backup','flash_written':False,'capacity':CAPACITY,'usb_physical':LOCATION,'usb_device':device,'url':url,'bridge_sha256':sha(BRIDGE),'logs':[]}
    report_path=session/'backup_report.json'
    def save():report_path.write_text(json.dumps(report,indent=2),encoding='utf-8')
    save();print('SESSION '+str(session),flush=True)
    try:
        text=command(base_args(url)+['-m','jtag',BRIDGE],session/'bridge.log',env)
        if 'Device ID read from JTAG: 0xANONYMOUS' not in text or 'finished with JTAG programming' not in text:raise RuntimeError('Bridge device ID/completion missing')
        text=command([EF/'python311/bin/python.exe',ROOT/'tools/probe_jedec.py',url],session/'pure_jedec.log',env,30)
        probe_lines=[line for line in text.splitlines() if line.startswith('PURE_JEDEC ')]
        if len(probe_lines)!=1:raise RuntimeError('No pure JEDEC preflight')
        probe=json.loads(probe_lines[0][11:]);report['pure_jedec_preflight']=probe;save()
        # Read mode still requires a .hex positional argument in this SDK.
        # Its contents are never consumed by jtag2spi_read_flash().
        placeholder=session/'READ_ONLY_ARGUMENT.hex';placeholder.write_text('FF\n',encoding='ascii')
        ids=[];raw=[]
        for n in (1,2):
            output=session/('backup%d.hex'%n)
            args=base_args(url)+['-m','jtag_bridge','--jtag_bridge_mode','read','--address','0','--num_bytes',str(CAPACITY),'-o',output,placeholder]
            text=command(args,session/('read%d.log'%n),env)
            matches=re.findall(r'Flash device:[^\r\n]*?\b8 MiB\b[^\r\n]*?JEDEC ID:\s*0x([0-9A-Fa-f]{6})(?=[^0-9A-Fa-f]|$)',text)
            if len(matches)!=1 or matches[0].upper()!=probe['jedec']:raise RuntimeError('Unexpected Flash JEDEC/capacity')
            ids.append(matches[0].upper());raw.append(decode_hex(output,session/('backup%d.raw.bin'%n)))
            report['logs'].append({'read':n,'jedec':ids[-1],'sha256':hashlib.sha256(raw[-1]).hexdigest()});save()
        if ids[0]!=ids[1] or raw[0]!=raw[1]:raise RuntimeError('Independent Flash reads differ')
        if len(set(raw[0]))<4:raise RuntimeError('Unexpected blank/constant prior Flash image')
        report.update(status='PASS',jedec=ids[0],backup_sha256=hashlib.sha256(raw[0]).hexdigest(),double_read_identical=True,volatile_design='vendor Flash bridge; normal design not yet restored')
    except BaseException as exc:report.update(status='FAIL',error=repr(exc));raise
    finally:save();print('REPORT '+str(report_path),flush=True)
    return report_path

def profile_check(manifest=None):
    from persistent_profile import load_profile
    path=Path(manifest) if manifest else ROOT/'out/manifest.json'
    release=json.loads((ROOT/'reviewed_release.json').read_text(encoding='utf-8'))
    if release.get('status')!='TECHNICALLY_REVIEWED' or release['manifest_sha256']!=sha(path):raise RuntimeError('Candidate differs from technically reviewed release')
    profile=load_profile(path,reviewed=True)
    if profile.image_sha256!=release['image_sha256']:raise RuntimeError('Flash image differs from reviewed release')
    if not profile.reviewed or profile.flash_capacity_bytes!=CAPACITY:raise RuntimeError('Unreviewed or wrong-capacity Flash profile')
    for relative,expected in release.get('runtime_files',{}).items():
        target=(ROOT/relative).resolve()
        if not target.is_relative_to(ROOT) or not target.is_file() or sha(target)!=expected:raise RuntimeError('Persistent runtime changed after review: '+relative)
    return path,profile

def preserve_outside_ranges(before,image,partitions):
    if len(before)!=CAPACITY or len(image)!=CAPACITY:raise RuntimeError('Not a complete Flash image/backup')
    at=0
    for row in sorted(partitions,key=lambda r:r['offset']):
        off,size=row['offset'],row['length']
        if off<at or size<=0 or off+size>CAPACITY:raise RuntimeError('Overlapping or invalid release partition')
        if before[at:off]!=image[at:off]:raise RuntimeError('Image would alter bytes outside authorized program ranges')
        at=off+size
    if before[at:]!=image[at:]:raise RuntimeError('Image would alter trailing data outside program ranges')

def pure_probe(url,session,env,name):
    text=command([EF/'python311/bin/python.exe',ROOT/'tools/probe_jedec.py',url],session/name,env,30)
    rows=[line for line in text.splitlines() if line.startswith('PURE_JEDEC ')]
    if len(rows)!=1:raise RuntimeError('Missing pure JEDEC preflight')
    return json.loads(rows[0][11:])

def progress(stage,step,state='running',done=None,total=None):
    row={'stage':stage,'step':step,'state':state}
    if total is not None:row.update(done=done,total=total,unit='bytes')
    print('PROGRESS '+json.dumps(row,separators=(',',':')),flush=True)

def program(manifest=None,reuse_backup=None,port='COM16'):
    if not re.fullmatch(r'COM[1-9][0-9]*',port,re.I):raise RuntimeError('Invalid explicit board UART')
    progress('files',1);path,profile=profile_check(manifest)
    # Public/default workflow always makes two fresh independent full backups.
    # --reuse-backup is root's same-session engineering continuation, never UI.
    progress('configure',2)
    report_path=Path(reuse_backup) if reuse_backup else backup()
    previous=json.loads(report_path.read_text(encoding='utf-8'));source=report_path.parent
    before=(source/'backup1.raw.bin').read_bytes();second=(source/'backup2.raw.bin').read_bytes()
    if previous.get('status')!='PASS' or not previous.get('double_read_identical') or before!=second or hashlib.sha256(before).hexdigest()!=previous.get('backup_sha256'):raise RuntimeError('Complete identical backup evidence required')
    if time.time()-report_path.stat().st_mtime>1800:raise RuntimeError('Backup too old for this controlled continuation')
    image=profile.image_path.read_bytes();preserve_outside_ranges(before,image,profile.partitions)
    session=ROOT/'sessions'/('program_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));session.mkdir(parents=True)
    env=vendor_env(session/'vendor_user');device=inventory(env);url=ftdi_url(device)
    if previous['usb_device']['bus']!=device['bus'] or previous['usb_device']['ports']!=device['ports']:raise RuntimeError('Different physical board from backup')
    report={'status':'IN_PROGRESS','operation':'complete_persistent_flash','board':'Ti60F225I3-V4','capacity':CAPACITY,'clock_mhz':100,'flash_mutation_attempted':False,'flash_written':False,'independent_full_readback':False,'cold_boot_user_confirmed':'PENDING','manifest_sha256':sha(path),'image_sha256':profile.image_sha256,'backup_report':str(report_path),'backup_sha256':previous['backup_sha256'],'usb_physical':LOCATION,'url':url,'outside_authorized_ranges_identical':True}
    dest=session/'program_report.json'
    def save():dest.write_text(json.dumps(report,indent=2),encoding='utf-8')
    save();print('SESSION '+str(session),flush=True);receiver=None
    try:
        text=command(base_args(url)+['-m','jtag',BRIDGE],session/'bridge.log',env)
        if 'Device ID read from JTAG: 0xANONYMOUS' not in text or 'finished with JTAG programming' not in text:raise RuntimeError('Wrong bridge/device')
        probe=pure_probe(url,session,env,'before_write_jedec.log')
        if probe['jedec']!=previous['jedec']:raise RuntimeError('Flash changed since backup')
        report['status_before']=probe;save()
        if sha(path)!=profile.manifest_sha256:raise RuntimeError('Manifest changed before write')
        data=json.loads(path.read_text(encoding='utf-8'));hex_source=path.parent/data['image']['hex_path'];hex_copy=session/'full_flash_8m.hex';shutil.copy2(hex_source,hex_copy);shutil.copy2(path,session/'release_manifest.json')
        platform_copy=session/'matched_platform.bit';shutil.copy2((path.parent/data['platform']['bit_path']).resolve(),platform_copy)
        if sha(platform_copy)!=data['platform']['bit_sha256']:raise RuntimeError('Platform differs from reviewed design')
        if sha(hex_copy)!=data['image']['hex_sha256'] or sha(profile.image_path)!=profile.image_sha256:raise RuntimeError('Image changed before write')
        progress('load',3);report['flash_mutation_attempted']=True;report['phase']='erase_write_vendor_host_verify';save()
        text=command(base_args(url)+['-m','jtag_bridge','--jtag_bridge_mode','all','--verify_method','hostx1','--address','0',hex_copy],session/'program_vendor.log',env,600)
        if 'Flash verify successful' not in text or 'JTAG2SPI programming...done' not in text:raise RuntimeError('No confirmed vendor host verification')
        report['vendor_host_verify']=True;save();progress('verify',4,done=0,total=CAPACITY)
        output=session/'after_full_read.hex'
        text=command(base_args(url)+['-m','jtag_bridge','--jtag_bridge_mode','read','--address','0','--num_bytes',str(CAPACITY),'-o',output,hex_copy],session/'independent_read.log',env)
        actual=decode_hex(output,session/'after_full_read.raw.bin')
        if actual!=image:raise RuntimeError('Independent full 8MiB byte readback differs')
        after=pure_probe(url,session,env,'after_write_jedec.log')
        if after['jedec']!=probe['jedec'] or ((after['status1']^probe['status1'])&0xfc) or ((after['status2']^probe['status2'])&0xfd):raise RuntimeError('Unexpected protection/status change')
        report.update(flash_written=True,independent_full_readback=True,status_after=after,readback_sha256=hashlib.sha256(actual).hexdigest(),phase='boot_from_flash');save();progress('verify',4,'done',CAPACITY,CAPACITY)
        # Exit the programming bridge using the same immutable platform design.
        # Its original ROM then reads software solely from the newly written Flash.
        # There is deliberately no load_image, ELF-to-DDR upload or RAM fallback.
        progress('start',5)
        receiver=subprocess.Popen([EF/'python311/bin/python.exe','-B','-X','utf8',ROOT/'tools/capture_uart.py',session,port],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
        for _ in range(50):
            if (session/'uart_ready').exists():break
            if receiver.poll() is not None:raise RuntimeError('UART capture unavailable')
            time.sleep(.1)
        if not (session/'uart_ready').exists():raise RuntimeError('UART capture startup timeout')
        if sha(platform_copy)!=data['platform']['bit_sha256']:raise RuntimeError('Frozen platform changed during programming')
        text=command(base_args(url)+['-m','jtag',platform_copy],session/'start_platform_only.log',env)
        if 'finished with JTAG programming' not in text:raise RuntimeError('Platform configuration did not complete')
        required=['LAB23 PERSIST STAGE2 ELF '+data['elf']['sha256'],'LAB23 PERSIST Flash+DDR CRC PASS; jump 0x1000',data['boot_marker']]
        until=time.monotonic()+60;seen=[]
        while time.monotonic()<until:
            uart=session/'uart_lines.jsonl'
            if uart.exists():
                rows=[]
                for row in uart.read_text(encoding='utf-8',errors='replace').splitlines():
                    try:rows.append(json.loads(row)['line'])
                    except (ValueError,KeyError):pass
                seen=rows
                if any(re.search(r'(^|\s)(FAIL|TRAP)(\s|$)',r) for r in rows):raise RuntimeError('Boot/runtime fault')
                if all(any(marker in line for line in rows) for marker in required) and any(line.startswith('STAT ') and 'fw=LAB23' in line for line in rows):break
            time.sleep(.2)
        else:raise RuntimeError('Persistent loader/app startup evidence missing')
        report.update(status='FLASH_VERIFIED_BOOTED_COLD_PENDING',phase='complete',boot_markers_seen=required,booted_app_read_from_flash=True,pc_elf_ram_upload=False)
        for row in seen:print('FLASH_BOOT '+row,flush=True)
        progress('start',5,'done')
    except BaseException as exc:report.update(status='FAIL',error=repr(exc));raise
    finally:
        if receiver:
            (session/'stop_uart').write_text('stop',encoding='ascii')
            try:receiver.wait(timeout=5)
            except subprocess.TimeoutExpired:receiver.terminate();receiver.wait(timeout=5)
        save();print('REPORT '+str(dest),flush=True)
    return dest
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['inventory','backup','check','program']);p.add_argument('--manifest',type=Path);p.add_argument('--reuse-backup',type=Path);p.add_argument('--port',default='COM16');a=p.parse_args()
    if a.action=='backup':backup()
    elif a.action=='check':
        path,profile=profile_check(a.manifest);print('CHECK ONLY: reviewed complete Flash image PASS; no USB/JTAG/Flash access. '+profile.image_sha256)
    elif a.action=='program':program(a.manifest,a.reuse_backup,a.port)
    else:print(json.dumps(inventory(vendor_env(ROOT/'inventory_vendor_user'))))
if __name__=='__main__':main()
