"""Receive-only monitor. New UART boot evidence and user power-cycle are separate."""
from pathlib import Path
import argparse,json,time,datetime,hashlib
import serial
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser();p.add_argument('--port',default='COM16');p.add_argument('--timeout',type=int,default=480);a=p.parse_args()
    out=ROOT/'sessions'/('cold_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));out.mkdir(parents=True)
    m=json.loads((ROOT/'out/manifest.json').read_text());expected=['LAB23 PERSIST STAGE2 ELF '+m['elf']['sha256'],'LAB23 PERSIST Flash+DDR CRC PASS; jump 0x1000','PHASE BATTLE v3 LAB23 PC CONTROL']
    device=None;pending=b'';rows=[];started=time.monotonic();status='TIMEOUT';error=None
    with (out/'uart.bin').open('wb') as binary,(out/'uart_lines.jsonl').open('w',encoding='utf-8') as lines:
        try:
            while time.monotonic()-started<a.timeout:
                if device is None:
                    try:
                        device=serial.Serial(port=None,baudrate=115200,timeout=.1,write_timeout=.2);device.dtr=False;device.rts=False;device.port=a.port;device.open()
                        print('MONITOR_READY '+str(out)+' receive_only=True',flush=True)
                    except (OSError,serial.SerialException):
                        if device:device.close()
                        device=None;time.sleep(.3);continue
                try:data=device.read(max(1,min(8192,device.in_waiting)))
                except (OSError,serial.SerialException):device.close();device=None;pending=b'';continue
                if not data:continue
                binary.write(data);binary.flush();pending+=data
                while b'\n' in pending:
                    raw,pending=pending.split(b'\n',1);line=raw.rstrip(b'\r').decode('utf-8',errors='replace');rows.append(line)
                    lines.write(json.dumps({'s':time.monotonic()-started,'line':line})+'\n');lines.flush()
                    if any(marker in line for marker in expected):print(line,flush=True)
                if all(any(marker in line for line in rows) for marker in expected) and any(line.startswith('STAT ') and 'fw=LAB23' in line for line in rows):
                    status='NEW_FLASH_BOOT_OBSERVED';break
        except BaseException as exc:status='FAIL';error=repr(exc);raise
        finally:
            if device:device.close()
            report={'status':status,'port':a.port,'uart_transmitted_bytes':0,'device_writes':False,'new_flash_boot_observed':status=='NEW_FLASH_BOOT_OBSERVED','user_power_cycle_confirmation':'PENDING','required_markers':expected,'manifest_sha256':hashlib.sha256((ROOT/'out/manifest.json').read_bytes()).hexdigest(),'error':error,'seconds':time.monotonic()-started}
            (out/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print('REPORT '+str(out/'report.json'),flush=True)
    return 0 if status=='NEW_FLASH_BOOT_OBSERVED' else 1
if __name__=='__main__':raise SystemExit(main())
