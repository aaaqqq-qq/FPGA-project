"""Pure JEDEC probe through installed vendor bridge APIs (9F + volatile AB).
No flash device object is constructed; no configuration/status register writes.
"""
import json,sys,time
from efx_dbg.jtag import JtagManager
from efx_pgm.jtag2SpiDriver import Jtag2SpiDriver
from efx_pgm.jtag2SpiFlash import SerialFlashDetector,reverseBytes

def main():
    url=sys.argv[1]
    if not url.startswith('ftdi://0x0403:0x6011:') or not url.endswith('/2'):raise ValueError('Unexpected explicit physical adapter channel')
    manager=JtagManager();tap=manager.detect_jtag_tap(url=url)
    if tap!='efx_ti':raise RuntimeError('Unexpected JTAG TAP')
    session=manager.config_jtag(url=url,freq=6000000,tap=tap,use_custom_engine=True)
    result=None
    try:
        with session.get_engine() as engine:
            driver=Jtag2SpiDriver(engine);driver.setup();version=driver.get_version()
            if version[0]!=3:raise RuntimeError('Expected installed version 3 bridge')
            driver.exit_bridge_mode();driver.tristate_flash(0,False);driver.tristate_flash(1,False)
            driver.tristate_spi_clk(True);driver.switch_flash(0);driver.tristate_flash(0,True)
            try:
                SerialFlashDetector.release_powerdown(driver);time.sleep(.002)
                ids=[SerialFlashDetector.read_jedec_id(driver).hex().upper() for _ in range(2)]
                if ids[0]!=ids[1] or ids[0] not in {'EF6017','C86017','C84017'}:raise RuntimeError('Unexpected or unstable JEDEC '+repr(ids))
                status=[]
                for opcode in (0x05,0x35):
                    with driver.bridge_mode():
                        status.append(int.from_bytes(driver.bridge_send_receive(reverseBytes(bytes([opcode])),8).tobytes(True),'big'))
                result={'jedec':ids[0],'capacity_bytes':8388608,'bridge_version':version,'status1':status[0],'status2':status[1],'pure_probe':True,'nonvolatile_written':False}
            finally:
                driver.exit_bridge_mode();driver.tristate_flash(0,False);driver.tristate_spi_clk(False)
    finally:manager.unconfig_jtag(session)
    print('PURE_JEDEC '+json.dumps(result),flush=True)
if __name__=='__main__':main()
