#!/usr/bin/env python3
"""Host checks actual loader.c, binary layout and independent objcopy oracle."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess,time
from rv32_cache_audit import audit_stage1,audit_sync

R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',required=True);ap.add_argument('--toolchain-bin',type=Path,required=True);a=ap.parse_args()
B=R/'out';m=json.loads((B/'manifest.json').read_text());logs=[];began=time.perf_counter()
def run(cmd):
    p=subprocess.run([str(x) for x in cmd],cwd=R,capture_output=True,text=True);logs.append({'command':[str(x) for x in cmd],'exit_code':p.returncode,'output':p.stdout+p.stderr})
    if p.returncode:raise RuntimeError(p.stdout+p.stderr)
    print(p.stdout,end='');return p.stdout
cc=[a.host_cc,'-O2','-UNDEBUG','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-type-limits']
run([*cc,'-I'+str(B),'loader.c','loader_host.c','-o',B/'loader_host.exe'])
log=run([B/'loader_host.exe',B/m['image']['bin_path'],B/m['stage2']['bin_path'],m['stage1']['stage2_embedded_offset']]);assert 'ALL_LOADER_HOST_PASS' in log
bad=[{'APP_LOAD_ADDRESS':0},{'APP_LOAD_ADDRESS':0x100000,'APP_ENTRY':0x100000},
     {'APP_LOAD_ADDRESS':0xf00000,'APP_ENTRY':0xf00000},
     {'APP_LOAD_ADDRESS':0xffffff00,'APP_ENTRY':0xffffff00},{'APP_FILE_BYTES':0},
     {'APP_MEMORY_BYTES':0x200000},{'APP_FILE_BYTES':0x100000},
     {'APP_ENTRY':0x1000+m['elf']['file_bytes']},{'APP_FLASH_ADDRESS':0x380000},
     {'APP_FLASH_ADDRESS':0x7ffff0},{'APP_FLASH_ADDRESS':0xfffffff0}]
cfg=(B/'payload_config.h').read_text()
for i,values in enumerate(bad):
    folder=B/('bad_'+str(i));folder.mkdir(exist_ok=True);text=cfg
    for field,value in values.items():text=re.sub(r'(#define '+field+r') [^\n]+',lambda v:v[1]+' '+str(value)+'u',text)
    (folder/'payload_config.h').write_text(text)
    run([*cc,'-DINVALID_CONFIG','-I'+str(folder),'loader.c','loader_host.c','-o',folder/'host.exe']);run([folder/'host.exe'])
# GCC's objcopy independently defines the ELF-to-loadable-raw conversion.
run([a.toolchain_bin/'riscv-none-elf-objcopy.exe','-O','binary',(B/m['elf']['path']).resolve(),B/'app_objcopy.bin'])
payload=(B/m['payload']['path']).read_bytes();assert (B/'app_objcopy.bin').read_bytes()==payload
image=(B/m['image']['bin_path']).read_bytes();assert len(image)==8388608
assert bytes.fromhex((B/m['image']['hex_path']).read_text())==image
platform=bytes.fromhex((B/m['platform']['hex_path']).read_text());stage1=(B/m['stage1']['path']).read_bytes();stage2=(B/m['stage2']['bin_path']).read_bytes()
assert image[:len(platform)]==platform
assert image[0x380000:0x39f000]==stage1 and len(stage1)==126976
blob=m['stage1']['stage2_embedded_offset'];assert stage1[blob:blob+len(stage2)]==stage2
assert stage1[m['stage1']['unpadded_bytes']:]==b'\xff'*(126976-m['stage1']['unpadded_bytes'])
assert image[0x400000:0x400000+len(payload)]==payload
for lo,hi in [(len(platform),0x380000),(0x39f000,0x400000),(0x400000+len(payload),8388608)]:
    assert image[lo:hi]==(B/m['preservation_source']['path']).read_bytes()[lo:hi]
assert b'PHASE BATTLE v3 LAB23 PC CONTROL GAME60_PIPELINE_5' in payload
assert m['stage2']['run_address']==0xf00000 and m['stage2']['stack_pointer']==0xfff000
assembly=(B/'stage1.disasm.txt').read_text();assert 'fence.i' in assembly and '0xf00' in assembly and 'jr' in assembly
cache_audit={'stage1':audit_stage1(stage1,stage2),'stage2_sync':audit_sync((B/'stage2.disasm.txt').read_text())}
print('CACHE_ORDER PASS actual RV32 trampoline executed; both target paths invalidate before reserved DDR lw then re-invalidate/fence.i/jump')
print('PACK PASS 8MiB HEX/raw equivalence; exact platform/stage1/relocation/payload spans, FF gaps; ELF=objcopy; LAB23 boot marker')
report={'status':'PASS','generated_by':'test_persist.py','hardware_accessed':False,'flash_written':False,
        'loader_scenarios':6,'invalid_configuration_cases':len(bad),'independent_ELF_oracle':'RV32 objcopy -O binary',
        'seconds':round(time.perf_counter()-began,3),'logs':logs,'cache_instruction_audit':cache_audit,'scope':'Actual C loader algorithm with mocked SPI/RAM/jump; RV32 trampoline/leaf instruction oracle. No physical SPI/cache/DDR execution or cold boot.'}
(B/'host_verification.json').write_text(json.dumps(report,indent=2))
m['status']='OFFLINE_VERIFIED_NOT_BOARD_TESTED';m['verification']['host_tests']='PASS';m['verification']['host_report']='host_verification.json'
(B/'manifest.json').write_text(json.dumps(m,indent=2));print('PERSIST_HOST=PASS')
