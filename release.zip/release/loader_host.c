/* Actual loader.c is linked unchanged. Only hardware operations are mocked. */
#include "loader_platform.h"
#include "payload_config.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint8_t ram[0x1000000],flash_data[0x800000],stage2_snapshot[0x10000];
static unsigned flash_length=sizeof(flash_data),reads,stores,fetches,syncs,jumps,inits;
static int fail_init,fail_read,damage_ram;
static unsigned stage2_length,blob_offset=96;
int persist_platform_init(void){++inits;return fail_init;}
int persist_flash_read(uint32_t address,uint8_t *out,uint32_t count){
    ++reads;
    if(fail_read&&reads==(unsigned)fail_read)return -1;
    if(address>flash_length||count>flash_length-address)return -1;
    memcpy(out,flash_data+address,count);return 0;
}
void persist_store(uint32_t address,uint8_t value){
    assert(!syncs&&!jumps);
    assert(address==APP_LOAD_ADDRESS+stores&&address<APP_LOAD_ADDRESS+APP_FILE_BYTES);
    ram[address]=value;
    if(damage_ram&&stores==111)ram[address]^=1;
    ++stores;
}
uint8_t persist_fetch(uint32_t address){
    assert(syncs==1&&!jumps&&stores==APP_FILE_BYTES);
    assert(address==APP_LOAD_ADDRESS+fetches);++fetches;return ram[address];
}
void persist_sync(uint32_t last){
    assert(stores==APP_FILE_BYTES&&last==APP_LOAD_ADDRESS+APP_FILE_BYTES-1&&!jumps);
    if(syncs==1)assert(fetches==APP_FILE_BYTES);
    ++syncs;
}
void persist_log(const char *s){(void)s;}
void persist_jump(uint32_t entry){
    assert(entry==0x1000&&syncs==2&&fetches==APP_FILE_BYTES&&stores==APP_FILE_BYTES);
#ifndef INVALID_CONFIG
    assert(!memcmp(ram+APP_LOAD_ADDRESS,flash_data+APP_FLASH_ADDRESS,APP_FILE_BYTES));
    assert(!memcmp(ram+0xf00000,stage2_snapshot,stage2_length));++jumps;
#endif
}
static void reset(void){
    memset(ram,0xa5,sizeof(ram));
    reads=stores=fetches=syncs=jumps=inits=0;fail_init=fail_read=damage_ram=0;flash_length=sizeof(flash_data);
    /* Model the immutable ROM and stage1 relocation using the real built
       stage1 bytes. No model program executes from the overwritten low bank. */
    memcpy(ram+0x1000,flash_data+0x380000,126976);
    if(stage2_length){
        memcpy(ram+0xf00000,ram+0x1000+blob_offset,stage2_length);
        assert(!memcmp(ram+0xf00000,stage2_snapshot,stage2_length));
    }
}
static unsigned file(const char *name,uint8_t *out,unsigned capacity){
    FILE *f=fopen(name,"rb");assert(f);unsigned n=(unsigned)fread(out,1,capacity,f);assert(!ferror(f));
    assert(fgetc(f)==EOF);fclose(f);return n;
}
int main(int argc,char **argv){
#ifdef INVALID_CONFIG
    (void)argc;(void)argv;
    assert(persist_run()==1&&!inits&&!reads&&!stores&&!fetches&&!syncs&&!jumps);
    puts("BOUNDS PASS rejected before platform/MMIO");return 0;
#else
    assert(argc==4);
    assert(file(argv[1],flash_data,sizeof(flash_data))==sizeof(flash_data));
    stage2_length=file(argv[2],stage2_snapshot,sizeof(stage2_snapshot));assert(stage2_length);
    blob_offset=(unsigned)strtoul(argv[3],0,0);
    assert(APP_FILE_BYTES>126976&&APP_LOAD_ADDRESS+APP_MEMORY_BYTES<=0x100000);
    assert(0xf00000+stage2_length<0xffd000&&0xfff000<0x1000000);
    reset();assert(memcmp(ram+0x1000,flash_data+APP_FLASH_ADDRESS,APP_FILE_BYTES));
    assert(persist_run()==0&&inits==1&&stores==APP_FILE_BYTES&&fetches==APP_FILE_BYTES&&jumps==1&&syncs==2);
    assert(!memcmp(ram+0x1000,flash_data+APP_FLASH_ADDRESS,APP_FILE_BYTES));
    assert(memcmp(ram+0x1000,flash_data+0x380000,126976));
    printf("LOADER01 PASS real%uB overwrites old124KiB stage1, relocated stage2 intact; DDRcrc+2sync before jump\n", (unsigned)APP_FILE_BYTES);
    reset();flash_data[APP_FLASH_ADDRESS+70000]^=1;assert(persist_run()==4&&!fetches&&!syncs&&!jumps);
    flash_data[APP_FLASH_ADDRESS+70000]^=1;
    puts("LOADER02 PASS Flash payload corruption fail-stop before jump");
    reset();flash_length=APP_FLASH_ADDRESS+APP_FILE_BYTES-1;assert(persist_run()==3&&!jumps);
    puts("LOADER03 PASS truncated Flash payload fail-stop");
    reset();damage_ram=1;assert(persist_run()==5&&syncs==1&&fetches==APP_FILE_BYTES&&!jumps);
    puts("LOADER04 PASS DDR write corruption detected after drain/invalidate and before jump");
    reset();fail_read=100;assert(persist_run()==3&&!jumps&&stores<APP_FILE_BYTES);
    reset();fail_init=1;assert(persist_run()==2&&!reads&&!stores&&!jumps);
    puts("LOADER05 PASS timeout/init failures never jump");
    reset();assert(!memcmp(ram+0xf00000,stage2_snapshot,stage2_length));
    memset(ram+0x1000,0,126976);
    assert(!memcmp(ram+0xf00000,stage2_snapshot,stage2_length));assert(persist_run()==0&&jumps==1);
    puts("LOADER06 PASS low loader code can disappear after relocation; high code remains and application loads correctly");
    puts("ALL_LOADER_HOST_PASS");return 0;
#endif
}
