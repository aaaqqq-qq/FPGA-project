"""Small RV32 interpreter for the actual trampoline and cache-drain leaf.

This is an instruction-order oracle, not a CPU/peripheral timing simulator.
"""
import re,struct

def signed(value,bits):return value-(1<<bits) if value&(1<<(bits-1)) else value

def execute(fetch,start,ram,stop,limit=30000):
    regs=[0]*32;regs[1]=0xdead0000;pc=start;trace=[];invalidated=False;drained=False
    for steps in range(limit):
        if pc==stop:
            assert drained and trace[-2:] == ['fence.i','jump'],trace
            return regs,trace,steps
        ins=fetch(pc);opcode=ins&127;rd=(ins>>7)&31;funct3=(ins>>12)&7;rs1=(ins>>15)&31;rs2=(ins>>20)&31
        after=pc+4
        if ins==0x500f:
            invalidated=True;trace.append('invalidate')
        elif opcode==0x0f:
            trace.append('fence.i' if funct3==1 else 'fence')
        elif opcode==0x73:
            assert ins in (0x30047073,0x30401073)
        elif opcode==0x37:regs[rd]=ins&0xfffff000
        elif opcode==0x17:regs[rd]=(pc+(ins&0xfffff000))&0xffffffff
        elif opcode==0x13:
            assert funct3==0;regs[rd]=(regs[rs1]+signed(ins>>20,12))&0xffffffff
        elif opcode==0x33:
            assert funct3==0 and ins>>25==0;regs[rd]=(regs[rs1]+regs[rs2])&0xffffffff
        elif opcode==0x03:
            address=(regs[rs1]+signed(ins>>20,12))&0xffffffff
            if funct3==4:regs[rd]=ram[address]
            else:
                assert funct3==2 and address==0xffffc0
                assert invalidated,'Drain word could hit cache: invalidate must precede lw'
                drained=True;trace.append('drain');regs[rd]=int.from_bytes(ram[address:address+4],'little')
        elif opcode==0x23:
            assert funct3==0
            imm=((ins>>25)<<5)|((ins>>7)&31);address=(regs[rs1]+signed(imm,12))&0xffffffff
            assert 0xf00000<=address<0xf10000
            ram[address]=regs[rs2]&255;invalidated=False;drained=False
        elif opcode==0x63:
            assert funct3==6
            imm=((ins>>31)<<12)|(((ins>>7)&1)<<11)|(((ins>>25)&63)<<5)|(((ins>>8)&15)<<1)
            if regs[rs1]<regs[rs2]:after=(pc+signed(imm,13))&0xffffffff
        elif opcode==0x67:
            assert funct3==0
            after=(regs[rs1]+signed(ins>>20,12))&0xfffffffe
            if rd:regs[rd]=pc+4
            assert trace[-1]=='fence.i' and trace.count('invalidate')==2 and drained
            trace.append('jump')
        else:raise AssertionError((hex(pc),hex(ins),'unsupported instruction'))
        regs[0]=0;pc=after
    raise AssertionError('Instruction oracle did not reach jump')

def audit_stage1(stage1,stage2):
    ram=bytearray(0x1000000);ram[0x1000:0x1000+len(stage1)]=stage1
    regs,trace,steps=execute(lambda pc:struct.unpack_from('<I',ram,pc)[0],0x1000,ram,0xf00000)
    assert ram[0xf00000:0xf00000+len(stage2)]==stage2
    assert regs[2]==0xfff000
    assert trace==['fence','invalidate','drain','fence','invalidate','fence','fence.i','jump'],trace
    return {'instructions_executed':steps,'trace':trace,'drain_word':'0x00ffffc0','stack':'0x00fff000'}

def audit_sync(disassembly):
    text=disassembly.split('<persist_sync>:\n',1)[1].split('\n\n',1)[0]
    words={int(a,16):int(b,16) for a,b in re.findall(r'^\s*([0-9a-f]+):\s+([0-9a-f]{8})\s',text,re.M)}
    ram=bytearray(0x1000000)
    _,trace,steps=execute(words.__getitem__,min(words),ram,0xdead0000)
    assert trace==['fence','invalidate','drain','fence','invalidate','fence','fence.i','jump'],trace
    return {'instructions_executed':steps,'trace':trace,'drain_word':'0x00ffffc0'}
