"""Offline regression of full-Flash authorization/layout and identity gates.

No USB, serial or vendor process is opened by these tests.
"""
from pathlib import Path
import ast,types
import hashlib,json,sys,tempfile,unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
import flash_device as device

class GuardTests(unittest.TestCase):
    def test_hex_url_matches_actual_vendor_resolver_without_USB(self):
        source=Path('D:/ELSFPGA/pgm/bin/efx_pgm/usb_resolver.py')
        self.assertTrue(source.is_file())
        module=ast.parse(source.read_text(encoding='utf-8-sig'))
        function=next(node for node in module.body if isinstance(node,ast.FunctionDef) and node.name=='format_ftdi_url')
        scope={'platform':'win32','UsbTools':types.SimpleNamespace(get_string=lambda *args:'')}
        exec(compile(ast.Module(body=[function],type_ignores=[]),str(source),'exec'),scope)
        for bus in (1,9,10,16,127,255):
            for address in (1,9,10,15,16,127,128,255):
                dev=types.SimpleNamespace(idVendor=0x403,idProduct=0x6011,bus=bus,address=address,iSerialNumber=0)
                self.assertEqual(device.ftdi_url({'bus':bus,'address':address}),scope['format_ftdi_url'](dev,2))

    def test_bad_url_locator_rejected(self):
        for bus,address in ((0,1),(1,0),(256,1),(1,256),(True,1),(1,1.5)):
            with self.assertRaisesRegex(RuntimeError,'FTDI'):device.ftdi_url({'bus':bus,'address':address})

    def test_invalid_uart_rejected_before_profile_or_hardware(self):
        with patch.object(device,'profile_check') as profile, patch.object(device,'backup') as backup:
            with self.assertRaisesRegex(RuntimeError,'UART'):device.program(port='ttyUSB0')
            profile.assert_not_called();backup.assert_not_called()

    def test_declared_region_only(self):
        before=b'\xff'*device.CAPACITY; candidate=bytearray(before)
        candidate[4096:8192]=b'A'*4096
        device.preserve_outside_ranges(before,bytes(candidate),[dict(offset=4096,length=4096)])
        candidate[8192]=42
        with self.assertRaisesRegex(RuntimeError,'trailing'):device.preserve_outside_ranges(before,bytes(candidate),[dict(offset=4096,length=4096)])

    def test_gaps_overlap_and_size_fail_closed(self):
        before=b'\xff'*device.CAPACITY
        for partitions in [[dict(offset=2,length=4),dict(offset=4,length=8)],
                           [dict(offset=0,length=0)], [dict(offset=device.CAPACITY,length=1)]]:
            with self.assertRaisesRegex(RuntimeError,'invalid'):device.preserve_outside_ranges(before,before,partitions)
        with self.assertRaisesRegex(RuntimeError,'complete'):device.preserve_outside_ranges(before,before[:-1],[])
        changed=bytearray(before);changed[2]=0
        with self.assertRaisesRegex(RuntimeError,'outside'):device.preserve_outside_ranges(before,changed,[dict(offset=10,length=20)])

    def test_current_sealed_release_without_device_access(self):
        with (patch.object(device,'inventory',side_effect=AssertionError('USB forbidden')),
              patch.object(device,'command',side_effect=AssertionError('Vendor forbidden'))):
            path,p=device.profile_check()
        m=json.loads(path.read_text()); self.assertEqual(m['release'],'LAB23')
        self.assertTrue(p.reviewed);self.assertEqual(p.flash_capacity_bytes,8388608)
        self.assertEqual(hashlib.sha256(p.image_path.read_bytes()).hexdigest(),p.image_sha256)

    def test_changed_manifest_rejected_before_loader(self):
        with tempfile.TemporaryDirectory() as folder:
            other=Path(folder)/'changed.json';other.write_text('{}')
            with patch('persistent_profile.load_profile') as load:
                with self.assertRaisesRegex(RuntimeError,'reviewed release'):device.profile_check(other)
                load.assert_not_called()

    def test_runtime_tamper_rejected(self):
        real=device.sha
        with patch.object(device,'sha',side_effect=lambda p: '0'*64 if Path(p)==ROOT/'START_MENU.py' else real(p)):
            with self.assertRaisesRegex(RuntimeError,'runtime changed'):device.profile_check()

if __name__=='__main__':unittest.main(verbosity=2)
