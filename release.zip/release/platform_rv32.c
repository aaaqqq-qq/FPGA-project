#include "loader_platform.h"
#define SPI 0xf8014000u
#define UART 0xf8010000u
#define LIMIT 10000000u
static uint32_t rd(uint32_t p){return *(volatile uint32_t *)(uintptr_t)p;}
static void wr(uint32_t p,uint32_t v){*(volatile uint32_t *)(uintptr_t)p=v;}
static int cmd(uint32_t value){
    for(unsigned n=0;n<LIMIT;++n)if(rd(SPI+4)&0xffffu){wr(SPI,value);return 0;}
    return -1;
}
int persist_platform_init(void){
    /* Exactly the existing ROM's single-SPI mode and divider. The ROM has
       already woken Flash, exited 4-byte mode and successfully copied stage1. */
    wr(UART+8,107);wr(UART+12,7);
    wr(SPI+8,0);wr(SPI+32,2);wr(SPI+36,2);wr(SPI+40,2);wr(SPI+44,2);
    return cmd(0x800); /* deassert CS0; no Flash write-enable or program opcode */
}
int persist_flash_read(uint32_t address,uint8_t *out,uint32_t count){
    if(address>=0x800000u||count>0x800000u-address)return -1;
    if(cmd(0x880)||cmd(0x103)||cmd(0x100|((address>>16)&255))||
       cmd(0x100|((address>>8)&255))||cmd(0x100|(address&255)))return -1;
    for(uint32_t j=0;j<count;++j){
        if(cmd(0x200))return -1;
        unsigned n;for(n=0;n<LIMIT;++n)if(rd(SPI+4)>>16)break;
        if(n==LIMIT)return -1;
        out[j]=(uint8_t)rd(SPI);
    }
    return cmd(0x800);
}
void persist_store(uint32_t address,uint8_t value){*(volatile uint8_t *)(uintptr_t)address=value;}
uint8_t persist_fetch(uint32_t address){return *(volatile uint8_t *)(uintptr_t)address;}
void persist_sync(uint32_t last){
    (void)last;
    __asm__ volatile("fence iorw,iorw" ::: "memory");
    /* Match production bb_publish exactly: invalidate first so the reserved
       drain-word read cannot hit DCache. This AXI bridge orders a real DDR
       read after preceding write responses. The word lies above the stage2
       downward-growing stack and below FB0. */
    __asm__ volatile(".word 0x500f" ::: "memory");
    uint32_t observed=*(const volatile uint32_t *)(uintptr_t)0x00ffffc0u;
    __asm__ volatile("" :: "r"(observed) : "memory");
    __asm__ volatile("fence iorw,iorw; .word 0x500f; fence iorw,iorw; fence.i" ::: "memory");
}
void persist_log(const char *s){
    while(*s){unsigned n;for(n=0;n<LIMIT;++n)if((rd(UART+4)>>16)&255)break;
        if(n==LIMIT)return;wr(UART,(uint8_t)*s++);}
}
void persist_jump(uint32_t entry){
    __asm__ volatile("csrci mstatus,8; csrw mie,zero" ::: "memory");
    ((void (*)(void))(uintptr_t)entry)();
    for(;;)__asm__ volatile("nop");
}

