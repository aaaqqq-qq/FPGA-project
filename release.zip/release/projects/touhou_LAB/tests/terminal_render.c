#include "pipe5_game_stubs.h"
/* R7 renderer APIs are no-ops only in this gameplay/command stub. */
#include "scene_layers_stubs.h"
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#define main firmware_main
#include "game.c"
#undef main
#include "lab_stubs.h"
unsigned scene_list_us,scene_batch_cycles,scene_jobs,scene_hud_restored_rows,scene_hud_redraw_jobs,scene_sprite_count;
typedef struct {uint32_t field;unsigned initialized;} Bank;
static Bank banks[2];static unsigned current_bank,model_batch,model_hw,in_hud,cancel_next,cancelled;
static unsigned batches,tiles,field_rects,field_texts,hud_begins,hud_ends,checks;
static char hud_trace[8192];static uint64_t host_ticks;
#define CK(x) do{++checks;if(!(x)){printf("TERMINAL_FAIL line=%u %s\n",__LINE__,#x);return 1;}}while(0)
static void mark(unsigned value){banks[current_bank].field=(banks[current_bank].field^value)*16777619u;}
static void trace(const char *s){size_t a=strlen(hud_trace),b=strlen(s);assert(a+b+2<sizeof(hud_trace));memcpy(hud_trace+a,s,b);hud_trace[a+b]='|';hud_trace[a+b+1]=0;}
void scene_init(void){memset(banks,0,sizeof(banks));}
void scene_set_batch(unsigned enabled){if(model_batch!=enabled){banks[0].initialized=banks[1].initialized=0;model_batch=enabled;}}
void scene_begin(uint32_t fb,unsigned hw){current_bank=fb==BB_FB1;model_hw=hw;batches=tiles=field_rects=field_texts=hud_begins=hud_ends=0;hud_trace[0]=0;in_hud=0;cancelled=0;scene_sprite_count=scene_jobs=0;
 if(!banks[current_bank].initialized||(model_batch&&!hw)){banks[current_bank].field=2166136261u;banks[current_bank].initialized=1;}
}
void scene_tile(int x,int y,unsigned tile,unsigned alpha){++tiles;++scene_jobs;++scene_sprite_count;mark((unsigned)x);mark((unsigned)y);mark(tile);mark(alpha);}
void scene_rect(int x,int y,int w,int h,uint32_t color){if(in_hud)return;++field_rects;++scene_jobs;mark((unsigned)x);mark((unsigned)y);mark((unsigned)w);mark((unsigned)h);mark(color);}
void scene_text(int x,int y,const char *t,uint32_t color,unsigned scale){if(in_hud){trace(t);return;}++field_texts;mark((unsigned)x);mark((unsigned)y);mark(color);mark(scale);while(*t)mark((unsigned char)*t++);}
void scene_batch_shots(void){++batches;++scene_jobs;scene_sprite_count+=stage.count;banks[current_bank].field=2166136261u;
 for(unsigned i=0;i<stage.count;++i){mark(stage.shots[i].x);mark(stage.shots[i].y);mark(stage.shots[i].tile);}
}
void scene_batch_snapshot_ready(void){}
void scene_hud_begin(void){in_hud=1;++hud_begins;}
void scene_hud_end(void){in_hud=0;++hud_ends;}
void scene_hud_invalidate(void){}
void scene_hud_cache_enable(unsigned enabled){(void)enabled;}
void scene_end(void){if(cancel_next){cancel_next=0;cancelled=1;banks[0].initialized=banks[1].initialized=0;}}
unsigned scene_cancelled(void){return cancelled;}
uint32_t bb_read(unsigned r){(void)r;return 0;}void bb_write(unsigned r,uint32_t v){(void)r;(void)v;}
uint64_t bb_ticks(void){return ++host_ticks;}uint32_t bb_us(uint64_t t){return (uint32_t)t;}
bb_result bb_probe(void){return BB_OK;}bb_result bb_publish(void){return BB_OK;}void bb_acquire(void){}
bb_result bb_swap_wait(uint32_t fb,uint32_t timeout){(void)fb;(void)timeout;return BB_OK;}
unsigned gpio_getInput(unsigned g){(void)g;return 15;}void gpio_setOutputEnable(unsigned g,unsigned m){(void)g;(void)m;}
void bsp_init(void){}void bsp_printf(const char *fmt,...){va_list a;va_start(a,fmt);vprintf(fmt,a);va_end(a);}
unsigned uart_writeAvailability(unsigned u){(void)u;return 0;}void uart_write(unsigned u,unsigned c){(void)u;(void)c;}
unsigned uart_readOccupancy(unsigned u){(void)u;return 0;}char uart_read(unsigned u){(void)u;return 0;}unsigned csr_read(unsigned c){return c;}
static void setup(unsigned terminal_mode){game_config_defaults();game_cfg.boss_count=6;game_cfg.enemy_count=12;choice=0;demo_invincible=0;hardware=1;validation_active=0;terminal_key=terminal_banks=0;model_batch=0;cancel_next=cancelled=0;scene_init();start();
 stage.count=3;for(unsigned i=0;i<3;++i)stage.shots[i]=(Shot){(100+(int)i*40)*Q,200*Q,0,0,12,54,0};
 for(unsigned k=0;k<6;++k){bosses[k].state=BOSS_ENRAGED;bosses[k].entered=1;bosses[k].x=100+(int)k*100;bosses[k].y=120;}
 mode=terminal_mode;player.score=123;if(terminal_mode==LOST){player.hp=0;player.alive=0;}
}
static int assert_full(uint32_t fb){render(fb);CK(batches==1&&field_rects>0&&field_texts>0);CK(hud_begins==1&&hud_ends==1);CK(scene_sprite_count>0&&last_frame_sprites==scene_sprite_count);return 0;}
static int assert_reuse(uint32_t fb){uint32_t before=banks[fb==BB_FB1].field;render(fb);CK(!batches&&!tiles&&!field_rects&&!field_texts);CK(hud_begins==1&&hud_ends==1);CK(scene_sprite_count==0&&last_frame_sprites==0);CK(before==banks[fb==BB_FB1].field);if(choice!=5)CK(strstr(hud_trace,"DRAWN 0")!=0);return 0;}
static int basic_banks(void){
 for(unsigned order=0;order<2;++order){setup(LOST);uint32_t a=order?BB_FB1:BB_FB0,b=order?BB_FB0:BB_FB1;
  if(assert_full(a))return 1;uint32_t first=banks[a==BB_FB1].field;if(assert_reuse(a))return 1;CK(first==banks[a==BB_FB1].field);
  if(assert_full(b)||assert_reuse(b)||assert_reuse(a))return 1;
  player.score=777;if(assert_reuse(b))return 1;CK(strstr(hud_trace,"777")!=0);CK(strstr(hud_trace,"ACTORS 6  DRAWN 0")!=0);
 }
 puts("TERMINAL_BANKS PASS bothorders/independentfirstdraw/reuse/HUDvaluechanges/DRAWN0");return 0;
}
static int invalidations(void){setup(LOST);if(assert_full(BB_FB0)||assert_full(BB_FB1))return 1;
 mode=CLEARED;player.hp=100;player.alive=1;if(assert_full(BB_FB0)||assert_full(BB_FB1)||assert_reuse(BB_FB0))return 1;
 demo_invincible^=1;if(assert_full(BB_FB0)||assert_full(BB_FB1))return 1;
 choice=5;if(assert_full(BB_FB1)||assert_full(BB_FB0))return 1;
 hardware=0;if(assert_full(BB_FB0)||assert_full(BB_FB1)||assert_full(BB_FB0))return 1; /* CPU begin erasesfield eachframe. */
 hardware=1;if(assert_full(BB_FB1)||assert_full(BB_FB0)||assert_reuse(BB_FB1))return 1;
 validation_active=1;if(assert_full(BB_FB0)||assert_full(BB_FB0)||assert_full(BB_FB1))return 1;
 validation_active=0;if(assert_full(BB_FB0)||assert_full(BB_FB1)||assert_reuse(BB_FB1))return 1;
 show_menu();render(BB_FB0);CK(mode==MENU&&terminal_banks==0&&hud_begins==0);
 mode=LOST;if(assert_full(BB_FB0)||assert_full(BB_FB1))return 1;
 puts("TERMINAL_INVALIDATE PASS mode/demo/choice/backend/CPUredraw/validation/menu");return 0;}
static int restart_cancel(void){setup(LOST);if(assert_full(BB_FB0)||assert_full(BB_FB1))return 1;
 start();render(BB_FB1);CK(mode==PLAY&&terminal_banks==0&&batches==1);mode=LOST;player.hp=0;player.alive=0;
 if(assert_full(BB_FB1)||assert_full(BB_FB0)||assert_reuse(BB_FB1))return 1;
 terminal_banks=0;cancel_next=1;render(BB_FB0);CK(cancelled&&!(terminal_banks&1u));
 if(assert_full(BB_FB0)||assert_reuse(BB_FB0))return 1;
 mode=PLAY;render(BB_FB1);CK(!terminal_banks&&batches==1);render(BB_FB1);CK(!terminal_banks&&batches==1);
 puts("TERMINAL_RESTART_CANCEL PASS sameLOSTafterPLAY/newrun,cancelnotcached,PLAYalwaysdraws");return 0;}
static int presentation_invalidations(void){
 setup(LOST);if(assert_full(BB_FB0)||assert_full(BB_FB1)||assert_reuse(BB_FB0))return 1;
 const char *updates[]={"set layer_pipeline_enabled 0","set layer_y_sort 0","set layer_visuals_enabled 0","set layer_order[2] 1","set layer_visuals_strength 1","set layer_visuals_strength 2","set battle_gather_enabled 0","set opaque_sprites 0","set render_budget_enabled 0","set battle_gather_enabled 1","set opaque_sprites 1","set render_budget_enabled 1"};
 command_reply_count=command_reply_head=command_reply_overruns=0;
 for(unsigned i=0;i<sizeof(updates)/sizeof(updates[0]);++i){
  command_reply_count=command_reply_head=command_reply_overruns=0;
  unsigned revision=presentation_revision;char text[96];strcpy(text,updates[i]);command_line(text);CK(presentation_revision==revision+1);
  if(assert_full(BB_FB0)||assert_full(BB_FB1)||assert_reuse(BB_FB1))return 1;
 }
 GameConfig saved=game_cfg;unsigned revision=presentation_revision;
 const char *bad[]={"set layer_order[2] 256","set layer_order[8] 0","set layer_pipeline_enabled 2","set layer_visuals_strength 0","set layer_visuals_strength 3","set battle_gather_enabled 2","set opaque_sprites 2","set render_budget_enabled 2"};
 for(unsigned i=0;i<sizeof(bad)/sizeof(bad[0]);++i){command_reply_count=command_reply_head=command_reply_overruns=0;char text[96];strcpy(text,bad[i]);command_line(text);CK(presentation_revision==revision&&!memcmp(&saved,&game_cfg,sizeof(saved)));}
 if(assert_reuse(BB_FB0)||assert_reuse(BB_FB1))return 1;
 puts("TERMINAL_PRESENTATION PASS valid layerconfig changes invalidatebothbanks,invalid changes atomic");return 0;
}
int main(void){if(basic_banks()||invalidations()||restart_cancel()||presentation_invalidations())return 1;printf("TERMINAL_RENDER PASS checks=%u\n",checks);return 0;}
