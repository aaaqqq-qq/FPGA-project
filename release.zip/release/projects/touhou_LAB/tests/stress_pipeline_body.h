static Stage oracle_stage,saved_actual;
static Shot submitted_shots[SHOT_CAPACITY];
static unsigned case_kind,case_count=64,pipeline_active,current_iteration,total_wanted;
static unsigned submitted_count,submitted_frame,submissions,snapshots,ready_seen,expected_prepare;
static const unsigned step_plan[PIPELINE_ITERATIONS]={0,0,0,1,0,2,3,0,1,0,3,2,0,1};
static void serial_advance(unsigned n){
    saved_actual=stage;stage=oracle_stage;unsigned gather=game_cfg.stress_gather_enabled;game_cfg.stress_gather_enabled=0;
    while(n--)stage_stress_step();oracle_stage=stage;game_cfg.stress_gather_enabled=gather;stage=saved_actual;
}
static void pipeline_bootstrap(void){
    choice=case_kind==1?4:case_kind==4?0:case_kind==5?5:3;custom_limit=case_count;start();
    if(case_kind==2)game_cfg.stress_overlap_enabled=0;
    if(case_kind==3)validation_active=1;
    pipeline_active=1;total_wanted=0;oracle_stage=stage;submissions=snapshots=0;
}
static void pipeline_iteration(unsigned i){
    current_iteration=i;total_wanted+=step_plan[i];host_ticks=((uint64_t)total_wanted*1000000u+59u)/60u;
    host_cancelled=0;
    if(case_kind==7&&i==6){choice=0;start();assert(!stress_prepared&&clock_reset_requested);}
    if(case_kind==8&&i==4)game_cfg.stress_overlap_enabled=0;
    if(case_kind==8&&i==7)game_cfg.stress_overlap_enabled=1;
    if(mode==STRESS||mode==DODGE)serial_advance(step_plan[i]);
}
static void pipeline_submit(void){
    if(!pipeline_active)return;
    ++submissions;submitted_count=stage.count;submitted_frame=stage.frame;ready_seen=0;
    if(mode==STRESS||mode==DODGE){
        assert(stage.count==oracle_stage.count&&stage.frame==oracle_stage.frame);
        for(unsigned i=0;i<stage.count;++i){
            const Shot *a=&stage.shots[i],*b=&oracle_stage.shots[i];
            assert(a->x==b->x&&a->y==b->y&&a->vx==b->vx&&a->vy==b->vy&&a->tile==b->tile);
        }
    }
    if(case_kind==7&&current_iteration==6)assert(mode==PLAY&&ticks==0);
    memcpy(submitted_shots,stage.shots,stage.count*sizeof(Shot));
    expected_prepare=mode==STRESS&&hardware&&!stress_warmup_frames&&!validation_active&&game_cfg.stress_overlap_enabled&&!stress_prepared;
}
static void pipeline_snapshot(void){
    assert(pipeline_active&&expected_prepare&&!ready_seen);
    assert(stage.count==submitted_count&&stage.frame==submitted_frame);
    assert(!memcmp(submitted_shots,stage.shots,submitted_count*sizeof(Shot)));
    ready_seen=1;++snapshots;
}
static void pipeline_end(void){
    if(!pipeline_active)return;
    if(mode==STRESS||mode==DODGE){
        assert(!!ready_seen==!!expected_prepare);
        assert(stage.count==submitted_count);
        assert(stage.frame==submitted_frame+expected_prepare);
        if(!expected_prepare)assert(!memcmp(submitted_shots,stage.shots,submitted_count*sizeof(Shot)));
    }else assert(!ready_seen&&!stress_prepared);
    if(case_kind==6&&current_iteration==3)host_cancelled=1;
}
static void pipeline_finished(void){
    assert(submissions>0);
    if(case_kind==0||case_kind==6){assert(submissions==10&&snapshots==8);}
    if(case_kind==1||case_kind==2||case_kind==3||case_kind==4||case_kind==5)assert(!snapshots&&submissions==PIPELINE_ITERATIONS);
    if(case_kind==7)assert(mode==PLAY&&!stress_prepared);
    assert(!logic_drops&&!logic_overruns);
    printf("PIPELINE PASS case=%u N=%u submissions=%u snapshots=%u ticks=%u runtime=%u\n",case_kind,case_count,submissions,snapshots,ticks,runtime_tick);
}
int main(int argc,char **argv){
    case_kind=argc>1?(unsigned)atoi(argv[1]):0;case_count=argc>2?(unsigned)atoi(argv[2]):64;
    host_ticks=0;firmware_main();return 0;
}
