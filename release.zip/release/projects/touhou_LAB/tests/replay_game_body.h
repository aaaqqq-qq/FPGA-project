#include "replay.h"
#define REPLAY_TEST_TICKS 12000u
static uint32_t expected_hash[REPLAY_TEST_TICKS];
static unsigned expected_outcome[REPLAY_TEST_TICKS];
static unsigned external_boss_count=3,external_enemy_count;

static unsigned seek_boss_keys(void){
    int target=ARENA_W/2;
    for(unsigned k=0;k<3;++k)if(battle_targetable(k)){target=bosses[k].x;break;}
    return player.x<target-PLAYER_SPEED?2u:player.x>target+PLAYER_SPEED?1u:0u;
}
static void replay_tuned_setup(void){
    game_config_defaults();
    /* Deliberately short deterministic host fixture, not a normal-game score. */
    game_cfg.boss_max_hp=12;game_cfg.boss_half_hp=6;
    game_cfg.enrage_intro_ticks=4;game_cfg.enter_ticks=8;
    game_cfg.first_burst=32;game_cfg.other_burst=16;
    game_cfg.player_shot_damage=3;game_cfg.main_fire_period=2;
    game_cfg.spawn_invuln_ticks=100000;game_cfg.bomb_damage=3;
    remote_input_init(&remote);demo_invincible=0;autoplay=0;keys=edges=bomb_requests=0;
}
static int external_replay(const char *filename){
    static uint32_t words[8+REPLAY_CAPACITY*2];static ReplayEvent incoming[REPLAY_CAPACITY];
    FILE *f=fopen(filename,"r");if(!f){puts("REPLAY_MODEL FAIL input_open");return 2;}
    unsigned count=0;while(count<8+REPLAY_CAPACITY*2&&fscanf(f,"%u",&words[count])==1)++count;fclose(f);
    if(count<8||words[4]>REPLAY_CAPACITY||count!=8+words[4]*2){puts("REPLAY_MODEL FAIL input_size");return 2;}
    ReplayHeader h={words[0],words[1],words[2],words[3],words[4],words[5],words[6],words[7]};
    for(unsigned i=0;i<h.event_count;++i){incoming[i].tick=words[8+i*2];incoming[i].keys=(uint8_t)words[9+i*2];incoming[i].bombs=(uint8_t)(words[9+i*2]>>8);incoming[i].reserved=(uint16_t)(words[9+i*2]>>16);}
    game_config_defaults();game_cfg.boss_count=external_boss_count;game_cfg.enemy_count=external_enemy_count;
    if(replay_load(&h,incoming,h.config_hash)){printf("REPLAY_MODEL FAIL import=%d\n",replay_status());return 2;}
    replay_start_playback();
    if(replay_state()!=REPLAY_PLAYING){printf("REPLAY_MODEL FAIL config=%d\n",replay_status());return 2;}
    for(uint32_t t=0;t<h.final_tick&&replay_state()==REPLAY_PLAYING;++t)runtime_step();
    if(replay_state()==REPLAY_PLAYING&&runtime_tick==h.final_tick)runtime_step();
    if(replay_state()!=REPLAY_FINISHED){printf("REPLAY_MODEL FAIL final=%d state=%u\n",replay_status(),replay_state());return 2;}
    printf("REPLAY_MODEL PASS ticks=%u mode=%u hash=%u\n",(unsigned)runtime_tick,mode,(unsigned)runtime_state_hash());return 0;
}
int main(int argc,char **argv){
    if(argc==4){external_boss_count=(unsigned)atoi(argv[2]);external_enemy_count=(unsigned)atoi(argv[3]);if(external_boss_count<1||external_boss_count>MAX_BOSSES||external_enemy_count>ENEMY_CAPACITY)return 2;return external_replay(argv[1]);}
    if((argc==3&&!strcmp(argv[1],"--export-default"))||(argc==5&&!strcmp(argv[1],"--export-topology"))){
        game_config_defaults();
        if(argc==5){if(!game_config_set("boss_count",(unsigned)atoi(argv[3]))||!game_config_set("enemy_count",(unsigned)atoi(argv[4])))return 2;}
        remote_input_init(&remote);replay_record_start(0x2468ace1u);
        for(unsigned t=0;t<500&&replay_state()==REPLAY_RECORDING;++t){keys=(t/60)%2?1:2;edges=0;bomb_requests=t==50||t==150||t==350?1:0;runtime_step();}
        if(replay_state()==REPLAY_RECORDING)replay_stop_recording();assert(replay_state()==REPLAY_READY);
        FILE *f=fopen(argv[2],"w");assert(f);for(unsigned i=0;i<replay_export_words();++i){uint32_t w;assert(!replay_export_word(i,&w));fprintf(f,"%u\n",(unsigned)w);}fclose(f);
        printf("REPLAY_MODEL_EXPORT PASS ticks=%u events=%u\n",(unsigned)replay_header()->final_tick,(unsigned)replay_header()->event_count);return 0;
    }
    if(argc==2)return external_replay(argv[1]);
    replay_tuned_setup();replay_record_start(0x13579bdfu);
    assert(replay_state()==REPLAY_RECORDING);unsigned total=0;
    for(unsigned t=0;t<REPLAY_TEST_TICKS;++t){
        keys=seek_boss_keys();edges=0;bomb_requests=t==50||t==200?1:0;
        runtime_step();expected_hash[t]=runtime_state_hash();expected_outcome[t]=mode;total=t+1;
        if(mode==CLEARED||mode==LOST)break;
    }
    assert(total<REPLAY_TEST_TICKS&&mode==CLEARED);
    if(replay_state()==REPLAY_RECORDING)replay_stop_recording();
    assert(replay_state()==REPLAY_READY);assert(replay_header()->final_tick==total);
    uint32_t finalhash=runtime_state_hash();unsigned events=replay_header()->event_count;
    replay_start_playback();assert(replay_state()==REPLAY_PLAYING);
    for(unsigned t=0;t<total;++t){
        /* Live input noise must not alter replay-injected production inputs. */
        keys=15;edges=15;bomb_requests=3;
        runtime_step();
        assert(runtime_state_hash()==expected_hash[t]);assert(mode==expected_outcome[t]);
    }
    assert(mode==CLEARED&&runtime_state_hash()==finalhash);
    assert(replay_state()==REPLAY_FINISHED&&replay_status()==REPLAY_OK);
    printf("R10 PASS production runtime replay %u ticks %u RLE events per-tick hashes and CLEARED sequence\n",total,events);
    puts("ALL_REPLAY_GAME_PASS");return 0;
}
