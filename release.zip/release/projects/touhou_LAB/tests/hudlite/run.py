"""Actual production game HUD/menu command traces; no hardware/FPS claim."""
from pathlib import Path
import argparse,ctypes,hashlib,json,subprocess,re
F=Path(__file__).resolve().parents[2]
P=Path(r'C:/FPGA/migrations/C289_GENERAL_CA91_20261104/TI60_GAME60_PIPELINE5_LINEPUBLISH_CA91_20261104/projects/touhou_LAB')
O=F/'results/hudlite';O.mkdir(parents=True,exist_ok=True)
a=argparse.ArgumentParser();a.add_argument('--cc',default='E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe');args=a.parse_args()
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
libs=[]
for name,root in [('parent',P),('candidate',F)]:
 s=(root/'tests/phase_gameplay.c').read_text('utf-8-sig').split('static int failures;',1)[0]
 s=s.replace('#include "game.c"','#include "'+(root/'src/game.c').as_posix()+'"')
 s=s.replace('void scene_rect(int x, int y, int w, int h, uint32_t c) { (void)x; (void)y; (void)w; (void)h; (void)c; }','')
 st=s.index('static unsigned capture_hud;');en=s.index('void scene_end(void)',st);s=s[:st]+s[en:]
 st=s.index('unsigned scene_list_us')
 trace=r'''
static char trace[32768];static unsigned at;
void scene_rect(int x,int y,int w,int h,uint32_t c){at+=snprintf(trace+at,sizeof(trace)-at,"R|%d|%d|%d|%d|%u\n",x,y,w,h,c);assert(at<sizeof(trace));}
void scene_text(int x,int y,const char*t,uint32_t c,unsigned z){at+=snprintf(trace+at,sizeof(trace)-at,"T|%d|%d|%u|%u|%s\n",x,y,c,z,t);assert(at<sizeof(trace));}
'''
 s=s[:st]+trace+s[st:]
 s=s.replace('uint32_t bb_read(unsigned reg) { (void)reg; return 0; }','static unsigned host_scan,host_swap;uint32_t bb_read(unsigned reg){return reg==BB_FRAMES?host_scan:reg==BB_SWAPS?host_swap:0;}')
 for n,ar in [('scene_hud_begin','void'),('scene_hud_end','void'),('scene_hud_invalidate','void'),('scene_hud_cache_enable','unsigned e')]:s+='\nvoid '+n+'('+ar+'){}\n'
 s+=r'''
static unsigned rnd;
static unsigned ran(void){rnd^=rnd<<13;rnd^=rnd>>17;rnd^=rnd<<5;return rnd;}
static void state(unsigned seed){rnd=seed+1;game_config_defaults();game_cfg.boss_count=1+(seed/36)%6;game_cfg.enemy_count=seed%13;game_cfg.boss_max_hp=3000;
 memset(&player,0,sizeof player);player.hp=seed%101;player.max_hp=100;player.hp_display=(unsigned)player.hp;player.score=ran()%1000000;player.power_level=1+seed%5;player.bombs=seed%4;player.lives=seed%4;
 for(unsigned i=0;i<MAX_BOSSES;i++){bosses[i].hp=ran()%3001;bosses[i].state=ran()%6;}
 static const unsigned modes[]={MENU,PLAY,STRESS,DODGE,CLEARED,LOST};mode=modes[seed%6];choice=(seed/6)%6;hardware=(seed>>1)&1;validation_active=(seed>>2)&1;paused=(seed>>3)&1;ticks=ran()%12000;runtime_tick=100;hud_sample_tick=100;
 bench_cpu_n=bench_hw_n=seed%2?32:0;bench_cpu_fps=1000+seed;bench_hw_fps=5999;stage.count=1+ran()%20000;stage.limit=20000;fps100=5999;hud_render_sample=12345;missed=7;underflows=8;keys=9;logic_drops=10;game_load_running=0;demo_invincible=(seed>>4)&1;autoplay=(seed>>5)&1;hud_frozen_pending=0;}
__declspec(dllexport)const char* hl_hud(unsigned seed,unsigned deferred){state(seed);at=0;trace[0]=0;if(deferred){hud_freeze_deferred();state(seed+999);hud_frozen_pending=1;hud_emit_deferred();}else hud();return trace;}
__declspec(dllexport)const char* hl_menu(unsigned seed){state(seed);at=0;trace[0]=0;menu_panel();return trace;}
'''
 if name=='candidate':s+=r'''
__declspec(dllexport)const char* hl_fps(unsigned running,unsigned rate){state(1);game_load_running=running;game_load_hud_rate=rate;at=0;trace[0]=0;hud();return trace;}
__declspec(dllexport)unsigned hl_sample(unsigned frame,unsigned sw,unsigned us,unsigned old){state(1);memset(&gl,0,sizeof gl);gl.ready=1;gl.target=36001;gl.deadline=1800000000;gl.frames=frame-1;gl.last_scan=sw-1;gl.n=stage.count;gl.b=game_cfg.boss_count;gl.m=0;gl.hud_dma=hud_dma_tail_enabled;game_load_running=1;battle_load_active=1;mode=PLAY;hardware=1;paused=0;host_scan=host_swap=sw;host_ticks=us-1;frame_us=0;game_load_cancel=0;command_reply_head=command_reply_count=command_reply_overruns=0;game_load_hud_rate=old;game_load_after_swap(gl.n,gl.b,gl.m);assert(gl.frames==frame&&gl.us==us&&gl.swaps==sw);return game_load_hud_fps100();}
'''
 src=O/(name+'_host.c');src.write_text(s,encoding='utf8');dll=O/(name+'.dll')
 cmd=[args.cc,'-std=gnu11','-O2','-shared','-UNDEBUG','-Wno-misleading-indentation','-I'+str(root/'src'),'-I'+str(root/'tests/stub'),'-I'+str(root/'tests'),str(src),*[str(root/'src'/x)for x in ['stage.c','battle.c','player.c','enemies.c','layer_visuals.c','effects.c','game_config.c','font.c','replay.c','remote_input.c']],'-o',str(dll)]
 q=subprocess.run(cmd,capture_output=True,text=True);(O/(name+'_compile.log')).write_text(q.stdout+q.stderr,encoding='utf8');assert q.returncode==0,q.stderr
 lib=ctypes.CDLL(str(dll));lib.hl_hud.restype=lib.hl_menu.restype=ctypes.c_char_p;libs.append(lib)
base,cur=libs;checks=0
for seed in range(300):
 for deferred in (0,1):
  aa=base.hl_hud(seed,deferred).decode().splitlines();bb=cur.hl_hud(seed,deferred).decode().splitlines()
  upper=lambda t:[x for x in t if int(x.split('|')[2])<572]
  assert upper(aa)==upper(bb),(seed,deferred,'upper');checks+=1
  low=[x for x in bb if int(x.split('|')[2])>=572];assert len(low)==2 and '|N ' in low[0] and low[1].endswith('|FPS 59.99'),(seed,low);checks+=1
 for deferred in (0,1):assert cur.hl_hud(seed,0)==cur.hl_hud(seed,deferred);checks+=1
 aa=base.hl_menu(seed).decode().splitlines();bb=cur.hl_menu(seed).decode().splitlines()
 if seed%6!=0:assert aa==bb,(seed,'terminal menu changed')
 else:assert len(bb)==3 and int(bb[0].split('|')[4])==84 and int(bb[2].split('|')[2])-int(bb[1].split('|')[2])==26 and bb[1].split('|')[-1] in ('NORMAL PHASE BATTLE','HARD PHASE BATTLE','LUNATIC PHASE BATTLE','SPRITE STRESS - FPGA','SPRITE STRESS - CPU','200 SECOND DODGE') and ('|INVINCIBLE ON' in bb[2] or '|INVINCIBLE OFF' in bb[2]),bb
 checks+=1
cur.hl_fps.restype=ctypes.c_char_p
for running,rate,expect in [(0,0,'FPS 59.99'),(1,0xffffffff,'FPS --'),(1,3000,'FPS 30.00'),(1,5999,'FPS 59.99')]:
 text=cur.hl_fps(running,rate).decode();assert expect in text and 'R~' not in text;checks+=1
for frame,sw,us,old in [(59,59,983333,0xffffffff),(60,60,1000000,0xffffffff),(61,61,1016666,6000),(120,120,2000000,6000),(180,180,6000000,6000),(240,240,4000600,0xffffffff)]:
 got=cur.hl_sample(frame,sw,us,old)&0xffffffff;expect=(sw*100000000)//us if frame%60==0 else old;assert got==expect,(frame,got,expect);checks+=1
pg=(P/'src/game_load.inc').read_text();cg=(F/'src/game_load.inc').read_text();assert re.findall(r'"(?:GLOAD|MOTION)[^"\n]*"',pg)==re.findall(r'"(?:GLOAD|MOTION)[^"\n]*"',cg);checks+=1
assert cg.count('game_load_hud_rate=gl.us?')==1 and 'if(!(gl.frames%60u))game_load_hud_rate=' in cg;checks+=1
pa=(P/'src/hud_frozen.inc').read_text();ca=(F/'src/hud_frozen.inc').read_text();assert pa.split('static HudFrozen hud_frozen;')[0]==ca.split('static HudFrozen hud_frozen;')[0];checks+=1
s=(P/'src/scene.c').read_text();t=(F/'src/scene.c').read_text()
for line in ['    draw_text(BACKGROUND,1078,58,"SCARLET NIGHT",0xe86b82,1);\n','    draw_text(BACKGROUND,1078,80,"PHASE BATTLE",0xf5cf77,1);\n','    draw_text(BACKGROUND,1078,98,"RUMIA CIRNO MEILING",0xaebce6,1);\n']:s=s.replace(line,'')
assert s==t;checks+=1
result={'status':'PASS','checks':checks,'hud_cases':600,'menu_cases':300,'scope':'Actual production game.c includes and gameplay modules, mocked scene command capture/MMIO/clock. Every HUD command y<572 and non-MENU terminal commands exact against frozen C289 parent; bottom exactly N/FPS. Deferred capture/live-mutation exercised. Cache sampled by actual game_load_after_swap. No physical pixel/DDR/FPS claim.','source_sha256':{str(p.relative_to(F)):H(p)for p in (F/'src').glob('*')if p.is_file()},'test_source_sha256':H(Path(__file__)),'host_sha256':{p.name:H(p)for p in O.glob('*_host.c')},'hardware_accessed':False,'board_fps':'NOT_RUN','protocol_format_strings_unchanged':True}
(O/'REVIEW.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in result.items()if k!='source_sha256'},indent=2))
