static unsigned scan_reads,swap_reads,worst_values;
static uint32_t telemetry_read(unsigned reg){
    if(worst_values)return reg==BB_FRAMES||reg==BB_SWAPS||reg==BB_UNDERFLOWS?UINT32_MAX:0;
    if(reg==BB_FRAMES){static const unsigned scans[]={1120,1121,1121,1121};assert(scan_reads<4);return scans[scan_reads++];}
    if(reg==BB_SWAPS){static const unsigned swaps[]={1020,1021};assert(swap_reads<2);return swaps[swap_reads++];}
    return 0;
}
int main(void){
    game_config_defaults();mode=STRESS;hardware=1;stage.count=stage.limit=20000;
    window_start=0;window_frames=1001;window_swaps=901;window_underflows=0;last_frame=1120;
    frames=missed=underflows=log_drops=0;window_missed=0;txpos=txlen=0;
    frame_us=12345;logic_us=3345;render_us=9000;host_ticks=2000000;
    last_layer_commands=381;last_layer_clipped=3;last_layer_reordered=127;
    last_decor_jobs=11;last_decor_area=1828;last_decor_dropped=2;
    scene_layer_commands=scene_layer_clipped=scene_layer_reordered=0;
    last_fx_quality=1;last_fx_lod=2;
    profile_battle_us=11;profile_player_us=22;profile_collect_us=33;profile_flush_us=44;profile_hud_us=55;
    profile_battle_peak=111;profile_player_peak=222;profile_flush_peak=444;profile_hud_peak=555;
    telemetry();
    assert(scan_reads==4&&swap_reads==2);
    assert(strstr(tx,"scan_total=1121 swap_total=1021"));
    assert(strstr(tx,"swaps=120 scan=120 us=2000001 frame=12345 "));
    assert(window_frames==1121&&window_swaps==1021);
    assert(strstr(tx,"qcmd=381 qclip=3 qsort=127 decor=11 darea=1828 ddrop=2 vstr=2 "));
    assert(strstr(tx,"bg=1 opaque=1 rb=1 qly=1 lod=2 b_us=11 p_us=22 c_us=33 f_us=44 h_us=55 b_pk=111 p_pk=222 f_pk=444 h_pk=555 fw=LAB23 paused=0 control=PC adv=1 img=1 perf=1\r\n"));
    assert(!profile_battle_peak&&!profile_player_peak&&!profile_flush_peak&&!profile_hud_peak);
    assert(txlen==strlen(tx)&&txlen+1<=sizeof(tx)&&tx[txlen-2]=='\r'&&tx[txlen-1]=='\n');
    puts("TELEMETRY PASS retry torn scan/swap reads, cumulative counters captured consistently; frame remains processing_us");
    puts(tx);
    worst_values=1;txpos=txlen=0;host_ticks=UINT32_MAX-1u;window_start=0;window_frames=window_swaps=window_underflows=window_missed=0;
    mode=hardware=stage.count=stage.limit=UINT32_MAX;last_frame=UINT32_MAX;
    frame_us=logic_us=render_us=peak_us=window_peak=missed=log_drops=UINT32_MAX;
    stage.emitted=stage.requested=stage.rejected=UINT32_MAX;player.shot_rejections=UINT32_MAX;
    player.x=player.y=player.hp=-1;player.power_level=player.bombs=UINT32_MAX;
    logic_drops=logic_overruns=runtime_tick=slowmo_remaining=UINT32_MAX;
    battle_density_slow=battle_near_candidates=battle_near_fallbacks=player_homing_retargets=UINT32_MAX;
    scene_hud_restored_rows=scene_hud_redraw_jobs=scene_list_us=scene_batch_cycles=overlap_us=last_frame_sprites=UINT32_MAX;
    effects_jobs=effects_area=effects_over_budget=effects_drop_total=UINT32_MAX;window_effect_drops=0;
    last_layer_commands=last_layer_clipped=last_layer_reordered=last_decor_jobs=last_decor_area=last_decor_dropped=UINT32_MAX;
    game_cfg.layer_pipeline_enabled=game_cfg.layer_y_sort=UINT32_MAX;
    game_cfg.layer_visuals_strength=UINT32_MAX;
    game_cfg.battle_gather_enabled=game_cfg.opaque_sprites=game_cfg.render_budget_enabled=UINT32_MAX;
    last_fx_quality=last_fx_lod=paused=UINT32_MAX;
    profile_battle_us=profile_player_us=profile_collect_us=profile_flush_us=profile_hud_us=UINT32_MAX;
    profile_battle_peak=profile_player_peak=profile_flush_peak=profile_hud_peak=UINT32_MAX;
    telemetry();
    assert(txlen==strlen(tx)&&txlen+1<=sizeof(tx)&&tx[txlen-2]=='\r'&&tx[txlen-1]=='\n');
    assert(strstr(tx,"qcmd=4294967295 qclip=4294967295 qsort=4294967295 decor=4294967295 darea=4294967295 ddrop=4294967295 vstr=4294967295 "));
    assert(strstr(tx,"bg=4294967295 opaque=4294967295 rb=4294967295 qly=4294967295 lod=4294967295 b_us=4294967295 p_us=4294967295 c_us=4294967295 f_us=4294967295 h_us=4294967295 b_pk=4294967295 p_pk=4294967295 f_pk=4294967295 h_pk=4294967295 fw=LAB23 paused=4294967295 control=PC adv=1 img=1 perf=1\r\n"));
    printf("TELEMETRY_R8 PASS previous-frame latches,qualityandphase samples/windowpeakreset; maximumunsigned payload bytes=%u cap=%u fullCRLFandtail\n",txlen,(unsigned)sizeof(tx));
    return 0;
}
