#include <windows.h>
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scene.h"
#include "bitblt.h"
#include "stage.h"
#include "art_data.h"
#include "game_config.h"
Stage stage;
unsigned battle_materials;
#define stage (*(Stage *)(uintptr_t)0x02100000u)
static uint32_t regs[64],wait_polls,pending,publish_count;
static uint64_t ticks,pixels_checked;
static unsigned frames,copy_jobs,batch_jobs,cpu_jobs,cancel_after;
static uint32_t *gold;
static unsigned fast32_jobs;
static void *at(uint32_t p){return (void *)(uintptr_t)p;}
void fatal(const char *where,int code){fprintf(stderr,"FAIL %s %d\n",where,code);exit(2);}
static void model(const bb_job *j){
    if(j->op==2){
        assert(j->width==1024&&j->height==688&&regs[0x44/4]<=20000);
        bb_job bg=*j;bg.op=BB_COPY_OP;bg.flags=0;bg.fill=0;model(&bg);
        const uint32_t *d=at(j->fill);
        const unsigned side=(j->flags&4u)?32u:8u,half=side/2u;
        if(side==32)++fast32_jobs;
        for(unsigned i=0;i<regs[0x44/4];++i){
            int cx=(int32_t)d[4*i]>>12,cy=(int32_t)d[4*i+1]>>12;
            unsigned tile=((d[4*i+3]>>16)&255u)-regs[0x50/4];
            assert(cx>=(int)half&&cx<=1024-(int)half&&cy>=(int)half&&cy<=688-(int)half&&tile<=15);
            for(unsigned y=0;y<side;++y)for(unsigned x=0;x<side;++x){
                const uint32_t src=*(uint32_t*)at(regs[0x48/4]+tile*256u+(y*8u/side)*32u+(x*8u/side)*4u);
                uint32_t *dst=at(j->dst+(unsigned)(cy-(int)half+(int)y)*5120u+(unsigned)(cx-(int)half+(int)x)*4u);
                if((j->flags&BB_KEY_ENABLE)&&(src&0xffffffu)==(j->key&0xffffffu))continue;
                *dst=(j->flags&BB_ALPHA_ENABLE)?bb_blend(src,*dst,j->alpha):src;
            }
        }
        return;
    }
    assert(bb_validate(j)==BB_OK);
    for(unsigned y=0;y<j->height;++y)for(unsigned x=0;x<j->width;++x){
        uint32_t addr=j->dst+y*j->dst_stride+x*4u;
        assert((addr>=BB_FB0&&addr<BB_FB0+BB_FRAME_BYTES)||(addr>=BB_FB1&&addr<BB_FB1+BB_FRAME_BYTES));
        uint32_t *d=at(addr),s=j->op==BB_COPY_OP?*(uint32_t *)at(j->src+y*j->src_stride+x*4u):j->fill;
        if(j->op==BB_COPY_OP&&(j->flags&BB_KEY_ENABLE)&&(s&0xffffff)==(j->key&0xffffff))continue;
        *d=(j->flags&BB_ALPHA_ENABLE)?bb_blend(s,*d,j->alpha):s;
    }
}
uint32_t bb_read(unsigned reg){
    if(reg==0x4c)return 6;
    if(reg==BB_STATUS&&pending){
        if(wait_polls){--wait_polls;return BB_BUSY;}
        bb_job j;memcpy(&j,&regs[BB_OP/4],sizeof j);model(&j);pending=0;regs[BB_STATUS/4]=BB_DONE;
    }
    return regs[reg/4];
}
void bb_write(unsigned reg,uint32_t value){
    assert(!pending);
    if(reg==BB_CMD){pending=1;wait_polls=3;regs[BB_STATUS/4]=BB_BUSY;if(regs[BB_OP/4]==2)++batch_jobs;else ++copy_jobs;return;}
    if(reg==BB_STATUS){regs[reg/4]&=~value;return;}regs[reg/4]=value;
}
uint64_t bb_ticks(void){return ++ticks;}
uint32_t bb_us(uint64_t t){return (uint32_t)t;}
bb_result bb_publish(void){assert(!pending);++publish_count;return BB_OK;}
void bb_acquire(void){assert(!pending);}
bb_result bb_cpu_execute(const bb_job *j){
    assert(!pending);if(cancel_after&&!--cancel_after)return BB_E_CANCELLED;
    ++cpu_jobs;model(j);return BB_OK;
}
static uint32_t golden_blend(uint32_t s,uint32_t d){
    uint32_t v=0;for(unsigned k=0;k<3;++k){unsigned a=(s>>(k*8))&255,b=(d>>(k*8))&255;v|=((a*224u+b*31u+127u)/255u)<<(k*8);}return v;
}
static void golden(unsigned size){
    memcpy(gold,at(0x01a00000),BB_FRAME_BYTES);
    for(unsigned i=0;i<stage.count;++i){
        Shot s=stage.shots[i];Tile t=tiles[s.tile];
        int left=32+s.x/Q-(int)size/2,top=16+s.y/Q-(int)size/2;
        for(unsigned y=0;y<size;++y)for(unsigned x=0;x<size;++x){
            int dx=left+(int)x,dy=top+(int)y;if(dx<32||dx>=1056||dy<16||dy>=704)continue;
            uint32_t p=art_palette[art_pixels[t.off/4u+(y*8u/size)*8u+x*8u/size]];
            if(p==BB_KEY)continue;gold[(unsigned)dy*1280u+(unsigned)dx]=golden_blend(p,gold[(unsigned)dy*1280u+(unsigned)dx]);
        }
    }
}
static uint32_t rng=0x6712abcd;
static unsigned random32(void){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
static void populate(unsigned size,unsigned variant,unsigned n){
    stage.count=n;
    for(unsigned i=0;i<n;++i){
        int x=4+(int)(random32()%1017),y=4+(int)(random32()%681);
        if(variant==1){x=512+(int)(i%5);y=344+(int)(i%3);}
        if(variant==2&&size!=8){
            const int edge_x[]={-60,-1,0,3,4,7,8,16,32,512,992,1008,1016,1020,1021,1024,1025,1084};
            const int edge_y[]={-60,-1,0,3,4,7,8,16,32,344,656,672,680,684,685,688,689,748};
            x=edge_x[i%18];y=edge_y[(i/18)%18];
        }
        stage.shots[i]=(Shot){x*Q+(int)(random32()&4095),y*Q+(int)(random32()&4095),0,0,17,(uint8_t)((battle_materials?54:24)+(i%16)),0};
    }
}
static void compare(unsigned size,unsigned hw,unsigned bank){
    uint32_t fb=bank?BB_FB1:BB_FB0;
    unsigned before_batches=batch_jobs;
    scene_set_batch(1);scene_begin(fb,hw);scene_batch_shots();scene_end();assert(!pending&&!scene_cancelled());
    if(hw&&size==32){
        unsigned all_inside=1;
        for(unsigned i=0;i<stage.count;++i){
            int x=stage.shots[i].x/Q,y=stage.shots[i].y/Q;
            if(x<16||x>1008||y<16||y>672)all_inside=0;
        }
        assert(((regs[BB_FLAGS/4]&4u)!=0)==(all_inside!=0));
        if(all_inside)assert(regs[0x44/4]==stage.count);
    }
    golden(size);
    const uint32_t *actual=at(fb);
    for(unsigned i=0;i<1280u*720u;++i)if(actual[i]!=gold[i]){
        fprintf(stderr,"pixel mismatch size=%u hw=%u bank=%u material=%u at %u,%u got=%08x expected=%08x\n",size,hw,bank,battle_materials,i%1280,i/1280,actual[i],gold[i]);exit(3);
    }
    assert(batch_jobs-before_batches==(hw?1u:0u));
    assert(scene_bullets_guards_ok());++frames;pixels_checked+=1280u*720u;
}
static void check_atlas(unsigned size){
    for(unsigned bank=0;bank<2;++bank)for(unsigned m=0;m<16;++m){
        unsigned first=bank?54:24;Tile t=tiles[first+m];
        const uint32_t *p=at((bank?0x06040000u:0x06000000u)+m*56u*56u*4u);
        for(unsigned y=0;y<56;++y)for(unsigned x=0;x<56;++x){
            uint32_t expected=(x<size&&y<size)?art_palette[art_pixels[t.off/4u+(y*8u/size)*8u+x*8u/size]]:BB_KEY;
            assert(p[y*56u+x]==expected);
        }
    }
}
int main(void){
    assert(VirtualAlloc(at(0x01000000u),0x01200000u,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE)==at(0x01000000u));
    if(VirtualAlloc((void *)(uintptr_t)0x07000000u,0x00400000u,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE)!=(void *)(uintptr_t)0x07000000u)return 2;
    assert(VirtualAlloc(at(0x05ff0000u),0x00090000u,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE)==at(0x05ff0000u));
    gold=malloc(BB_FRAME_BYTES);assert(gold);game_config_defaults();scene_init();
    unsigned sizes[]={8,16,24,32,40,48,56,8,56,16,8};
    for(unsigned j=0;j<sizeof sizes/sizeof sizes[0];++j){
        unsigned size=sizes[j];assert(scene_bullets_prepare(size));if(size!=8)check_atlas(size);
        unsigned publications=publish_count;assert(scene_bullets_prepare(size));assert(publish_count==publications);
        for(unsigned mode=0;mode<2;++mode){
            battle_materials=mode;
            for(unsigned variant=0;variant<4;++variant){
                populate(size,variant,variant==2?648:variant==3?0:97);
                compare(size,0,(j+variant)&1);compare(size,1,(j+variant+1)&1);
            }
        }
    }
    for(unsigned i=0;i<6;++i){unsigned invalid[]={0,1,7,9,64,0xffffffffu};assert(!scene_bullets_prepare(invalid[i]));}
    assert(scene_bullets_prepare(32));
    for(unsigned b=0;b<2;++b){
        battle_materials=b;
        populate(32,1,5000);unsigned before=fast32_jobs;
        compare(32,0,0);compare(32,1,1);assert(fast32_jobs==before+1);
        populate(32,0,5000);
        for(unsigned i=0;i<stage.count;++i){
            stage.shots[i].x=(16+(i*37u)%993u)*Q+(i&4095u);
            stage.shots[i].y=(16+(i*23u)%657u)*Q+(i&4095u);
        }
        before=fast32_jobs;compare(32,0,0);compare(32,1,1);assert(fast32_jobs==before+1);
        stage.shots[stage.count-1].x=15*Q;
        before=fast32_jobs;compare(32,1,0);assert(fast32_jobs==before);
    }
    assert(scene_bullets_prepare(8));
    populate(8,0,20000);compare(8,0,0);compare(8,1,1);
    battle_materials=1;populate(8,0,5000);compare(8,0,0);compare(8,1,1);
    assert(scene_bullets_prepare(56));populate(56,0,5000);compare(56,0,0);compare(56,1,1);
    /* A changed material request must finish a pending old-atlas DMA before
       overwriting either bank. The model executes only on later status polls. */
    scene_begin(BB_FB0,1);scene_batch_shots();assert(pending);assert(scene_bullets_prepare(16));scene_end();check_atlas(16);
    for(unsigned bank=0;bank<2;++bank)for(unsigned side=0;side<2;++side){
        uint32_t base=bank?0x06040000u:0x06000000u;
        uint32_t *g=at(side?base+0x31000u:base-64u);g[7]^=1;assert(!scene_bullets_guards_ok());g[7]^=1;assert(scene_bullets_guards_ok());
    }
    scene_bullets_reset();assert(scene_bullets_guards_ok());populate(8,0,97);compare(8,1,0);
    assert(scene_bullets_prepare(24));populate(24,0,97);cancel_after=3;scene_begin(BB_FB0,0);scene_batch_shots();scene_end();assert(scene_cancelled());cancel_after=0;
    compare(24,0,0);compare(24,1,1);
    printf("PASS frames=%u pixels=%llu copies=%u batches=%u cpu_jobs=%u guards=4 sizes=7 large_population=5000\n",frames,(unsigned long long)pixels_checked,copy_jobs,batch_jobs,cpu_jobs);
    assert(fast32_jobs>4);printf("BATCH32_CAP_PASS fast32_jobs=%u full_count_preserved=1 whole_frame_clip_fallback=1\n",fast32_jobs);
    return 0;
}
