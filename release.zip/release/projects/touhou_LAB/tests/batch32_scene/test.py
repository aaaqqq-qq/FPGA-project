"""Exact production scene renderer vs independent original-art nearest sampling.

The hardware model defers jobs by three BUSY polls and validates every COPY.
No FPGA, serial, flash or performance claims are made by this host test.
"""
from pathlib import Path
import argparse, hashlib, json, os, shlex, subprocess, sys

root = Path(__file__).resolve().parents[2]
p = argparse.ArgumentParser()
p.add_argument('--host-cc', default=os.environ.get('HOST_CC', 'gcc'))
a = p.parse_args()
cc = [x.strip('"') for x in shlex.split(a.host_cc, posix=False)]
out = root / 'results/batch32_scene'
out.mkdir(parents=True, exist_ok=True)
scene = (root / 'src/scene.c').read_text()
# Map the test-only 64-bit process's Stage into the real 32-bit DMA address space.
mapped = scene.replace('#include "stage.h"', '#include "stage.h"\n#define stage (*(Stage *)(uintptr_t)0x02100000u)')
(out / 'scene.c').write_text(mapped)
exe = out / 'bullet_sizes.exe'
cmd = cc + ['-std=gnu11', '-O2', '-UNDEBUG', '-DBB_HOST_TEST', '-Isrc',
            'tests/batch32_scene/host.c', str(out / 'scene.c'), 'src/render_queue.c',
            'src/background.c', 'src/font.c', 'src/pixels.c', 'src/game_config.c', '-o', str(exe)]
build = subprocess.run(cmd, cwd=root, capture_output=True, text=True)
(out / 'compile.log').write_text(build.stdout + build.stderr)
assert build.returncode == 0, build.stdout + build.stderr
run = subprocess.run([str(exe)], cwd=root, capture_output=True, text=True)
(out / 'run.log').write_text(run.stdout + run.stderr)
regression = subprocess.run([sys.executable, 'scripts/test_scene.py', '--host-cc', a.host_cc],
                            cwd=root, capture_output=True, text=True)
(out / 'baseline8.log').write_text(regression.stdout + regression.stderr)
baseline = json.loads((root / 'tests/bullet_sizes/baseline8_pixels.json').read_text())
current = json.loads((root / 'results/scene_pixels_batch720.json').read_text())
regression_ok = regression.returncode == 0 and current['pixel_sha256'] == baseline['pixel_sha256']
ok = run.returncode == 0 and regression_ok
report = {
    'status': 'PASS' if ok else 'FAIL',
    'scope': 'Production C renderer, independent palette/source coordinate reference, full frames; delayed DMA model and public range validators. Not physical RTL/cache/FPS evidence.',
    'device_access': False, 'command': cmd, 'exit_code': run.returncode,
    'output': run.stdout + run.stderr,
    'default8_frozen_frames': len(baseline['pixel_sha256']),
    'default8_frozen_reference': 'TI60_LAB60D_20261101/results/scene_pixels_batch720.json; retained hashes from unchanged source',
    'default8_frozen_scene_sha256': baseline['source_sha256'],
    'default8_frozen_exact': regression_ok,
    'coverage': ['all 16 original appearances in both banks', '8/16/24/32/40/48/56 pixels',
                 'fractional Q12 centers, clipping on all edges and corners', 'dense ordered Alpha224 overlaps',
                 'empty population, 5000 bullets at 8 and 56 pixels', 'CPU and delayed hardware model',
                 'size transitions, immutable atlas/padding, invalid sizes, pre/post guards', 'cap6 fast32 N5000, both material banks, dense overlaps and full-frame clip fallback', 'N20000 default8 unchanged',
                 'pending DMA before prepare, cancellation and reuse'],
    'source_sha256': {str(f): hashlib.sha256((root / f).read_bytes()).hexdigest() for f in
                      ['src/scene.c', 'src/scene.h', 'tests/batch32_scene/host.c', 'tests/bullet_sizes/test.py']},
}
(out / 'summary.json').write_text(json.dumps(report, indent=2))
print(run.stdout + run.stderr)
print(regression.stdout + regression.stderr)
raise SystemExit(0 if ok else 1)
