#pragma once
#define mcause 0u
unsigned csr_read(unsigned csr);
