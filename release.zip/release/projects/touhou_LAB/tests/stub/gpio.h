#pragma once
#define SYSTEM_GPIO_0_IO_CTRL 0u
unsigned gpio_getInput(unsigned gpio);
void gpio_setOutputEnable(unsigned gpio, unsigned mask);
