#pragma once
#include <stdint.h>
#define BSP_UART_TERMINAL 0u
void bsp_init(void);
void bsp_printf(const char *fmt, ...);
unsigned uart_writeAvailability(unsigned uart);
void uart_write(unsigned uart, unsigned c);
unsigned uart_readOccupancy(unsigned uart);
char uart_read(unsigned uart);
