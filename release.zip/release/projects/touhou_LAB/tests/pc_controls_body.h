static void pc_append(const unsigned char *b,unsigned n){
    assert(host_uart_end+n<sizeof(host_uart));memcpy(host_uart+host_uart_end,b,n);host_uart_end+=n;
}
static void pc_packet(unsigned seq,unsigned mask,unsigned bad){
    unsigned char b[]={0xa5,0x5a,(unsigned char)seq,(unsigned char)mask,(unsigned char)(mask>>8),(unsigned char)(seq^mask^(mask>>8)^0xa7^bad)};pc_append(b,6);
}
static void pc_text(const char *s){pc_append((const unsigned char*)s,(unsigned)strlen(s));input();}
static void pc_clear(void){command_reply_count=command_reply_head=command_reply_overruns=0;txlen=txpos=0;}
static int pc_reply_has(const char *s){for(unsigned i=0;i<command_reply_count;++i)if(strstr(command_replies[(command_reply_head+i)%COMMAND_REPLY_CAP],s))return 1;return 0;}
int main(void){
    game_config_defaults();replay_reset();remote_input_init(&remote);mode=MENU;host_ticks=10000;
    pc_packet(0,REMOTE_START,0);input();assert(mode==PLAY&&!paused&&player.bombs==3);
    pc_packet(1,REMOTE_LEFT|REMOTE_UP,0);input();int x=player.x,y=player.y;runtime_step();
    assert(player.x<x&&player.y<y);
    puts("PC01 PASS packet start and diagonal movement use production runtime");
    pc_packet(2,REMOTE_BOMB,0);input();assert(bomb_requests==1);runtime_step();assert(player.bombs==2&&!bomb_requests);
    pc_packet(2,REMOTE_BOMB,0);input();pc_packet(3,REMOTE_BOMB,0);input();runtime_step();assert(player.bombs==2&&!bomb_requests);
    pc_packet(4,0,0);input();pc_packet(5,REMOTE_BOMB,0);input();runtime_step();assert(player.bombs==1);
    pc_packet(6,3,0);input();runtime_step();assert(player.bombs==1&&!bomb_requests);
    puts("PC02 PASS bomb new edge once; repeated heartbeat/held/L+R cannot bomb");
    pc_packet(7,REMOTE_PAUSE,0);input();assert(paused);uint32_t h=runtime_state_hash();unsigned rt=runtime_tick,bt=ticks;
    for(unsigned i=0;i<100;++i)runtime_step();assert(runtime_tick==rt&&ticks==bt&&runtime_state_hash()==h);
    host_pause_text=0;render(BB_FB0);assert(host_pause_text&&ticks==bt);
    pc_packet(7,REMOTE_PAUSE,0);input();assert(paused);
    pc_packet(8,0,0);input();pc_packet(9,REMOTE_PAUSE,0);input();assert(!paused);runtime_step();assert(runtime_tick==rt+1);
    puts("PC03 PASS pause edge freezes authoritative state while render/PAUSED/input continue");
    host_gpio_reads=0;unsigned oldmode=mode,oldbomb=player.bombs;
    pc_packet(10,0,0);input();
    for(unsigned bits=0;bits<16;++bits){host_gpio_raw=bits;poll_controls();buttons();}
    assert(!host_gpio_reads&&mode==oldmode&&player.bombs==oldbomb);
    puts("PC04 PASS every board GPIO pattern ignored; zero GPIO reads");
    pc_packet(11,REMOTE_RIGHT,0);input();host_ticks=remote.last_valid_us+500000;input();assert(!keys&&!remote.held);
    paused=1;bt=ticks;pc_clear();pc_text(":hello\n");assert(paused&&ticks==bt&&mode==PLAY&&!remote.held&&!remote.have_sequence);
    assert(pc_reply_has("CAPS fw=LAB23 proto=2 controls=PC lab=1 labx=1"));
    pc_packet(0,REMOTE_LEFT,0);input();assert(keys==1);
    puts("PC05 PASS timeout release and hello reconnect preserve progress/pause");
    pc_clear();pc_text(":pause 0\n");assert(!paused&&pc_reply_has("OK paused 0"));
    ticks=123;pc_text("mrsgn20000\n");assert(ticks==123&&mode==PLAY);
    pc_packet('m','r',1);input();assert(ticks==123&&mode==PLAY);
    pc_clear();pc_text(":limit 20000\n");assert(mode==PLAY&&pc_reply_has("limit requires menu"));
    pc_clear();pc_text(":menu\n:limit 20000\n:mode 3\n");assert(mode==STRESS&&stage.count==20000&&pc_reply_has("OK limit 20000")&&pc_reply_has("OK mode 3"));
    pc_text(":pause 1\n");unsigned sf=stage.frame;stress_warmup_frames=0;render(BB_FB0);assert(stage.frame==sf);
    puts("PC06 PASS corrupt/raw bytes inert; exact count stress command and paused stress no mutation");
    host_lab_active=1;oldmode=mode;pc_packet(1,REMOTE_START|REMOTE_BOMB,0);input();assert(mode==oldmode&&!keys&&!bomb_requests);
    pc_clear();pc_text(":mode 0\n");assert(mode==oldmode&&pc_reply_has("ERR lab active"));
    unsigned init_before=host_scene_inits;host_bank_mask=host_order_n=0;
    assert(game_lab_restore()==0);assert(mode==MENU&&!paused&&host_scene_inits==init_before+1&&host_bank_mask==3);
    assert(host_order_n==3&&host_order[0]==2&&host_order[1]==4&&host_order[2]==1);
    host_lab_active=0;
    puts("PC07 PASS experiment ownership blocks game; restore rebuilds both banks/HUD to menu");
    pc_clear();pc_text(":mode 4\n");pc_packet(0,0,0);input();pc_packet(1,0,0);
    assert(!bb_cpu_service()&&!uart_readOccupancy(0));
    pc_append((const unsigned char*)":menu\n",6);assert(bb_cpu_service()&&mode==STRESS);input();assert(mode==MENU);
    puts("PC08 PASS CPU reference render services binary heartbeat; text mutation deferred safely");
    profile_battle_peak=profile_player_peak=profile_flush_peak=profile_hud_peak=UINT32_MAX;reset_stats();
    assert(!profile_battle_peak&&!profile_player_peak&&!profile_flush_peak&&!profile_hud_peak);
    puts("PC09 PASS per-window profile peaks reset");
    pc_clear();
    for(unsigned i=0;i<16;++i){char msg[40];textfmt(msg,sizeof(msg),"CASE %u",i);command_message(msg);}
    assert(command_reply_count==16&&!command_reply_overruns);
    for(unsigned i=0;i<16;++i){char expected[40];textfmt(expected,sizeof(expected),"CASE %u\r\n",i);txlen=txpos=0;service_command_output();assert(!strcmp(tx,expected));}
    assert(!command_reply_count);puts("PC10 PASS 16 reply FIFO includes ACK+9CASE+DONE without loss");
    host_adv_active=1;oldmode=mode;pc_packet(4,REMOTE_START|REMOTE_BOMB|REMOTE_LEFT,0);input();assert(mode==oldmode&&!keys&&!bomb_requests);
    pc_clear();pc_text(":mode 0\n:labx 1 enter\n:lab 1 enter\n");assert(mode==oldmode&&pc_reply_has("ERR lab active")&&pc_reply_has("ERR adv active"));host_adv_active=0;
    puts("PC11 PASS ADV1 ownership suppresses PC game controls and legacy experiment entry");
    puts("ALL_PC_CONTROLS_PASS");return 0;
}
