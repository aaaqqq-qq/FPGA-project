"""Direct C284 golden comparison for frozen-HUD scheduling.

Uses the existing real-game APB/DMA fixture builder without altering its tests.
Checks actual render/runtime and firmware_main/UART; native time is not board FPS.
"""
from pathlib import Path
import ast, ctypes, hashlib, json, re, subprocess, sys

P=Path(__file__).resolve().parents[2]
B=P.parent/'game60_pipe5_prepare_actor_fw_20261103'
source=(P/'scripts/test_pipe5.py').read_text()
harness=source[:source.index("k=ctypes.WinDLL")]
harness=harness.replace("P=Path(__file__).resolve().parents[1];B=Path('E:/Ti60_builds/game60_motion_fw4_20261102')", "P=Path(__file__).resolve().parents[2];B=P.parent/'game60_pipe5_prepare_actor_fw_20261103'")
harness=re.sub(r'^assert hashlib.sha256.*\n','',harness,flags=re.M)
harness=harness.replace("O=P/'build/pipe5'", "O=P/'build/hud_frozen'").replace("R=P/'results/pipe5'", "R=P/'results/hud_frozen'")
harness=harness.replace("('reference',B,False)","('reference',B,True)")
harness=harness.replace("if pipe:common+=['-DTEST_PIPE5']", "if pipe:common+=['-DTEST_PIPE5']\n if label=='candidate':common+=['-DTEST_HUD_FROZEN']")
harness=harness.replace("backend=(P/'tests/pipe5/backend.inc').read_text()", "core+=(P/'tests/hud_frozen/probe.inc').read_text()\nbackend=(P/'tests/pipe5/backend.inc').read_text()")
harness=harness.replace('runtime_pipe_begin(snap);if(!scene_pipe_fallback())render_draw_frozen_hud();runtime_pipe_complete();', 'runtime_pipe_begin(snap);if(!scene_pipe_fallback()&&!hud_dma_tail_enabled)render_draw_frozen_hud();runtime_pipe_complete();if(!scene_pipe_fallback()&&hud_dma_tail_enabled)render_draw_frozen_hud();')
exec(compile(harness,str(P/'scripts/test_pipe5.py'), 'exec'),globals())

H=lambda b:hashlib.sha256(b).hexdigest()
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.VirtualAlloc.restype=ctypes.c_void_p
kernel.VirtualAlloc.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32,ctypes.c_uint32]
regions=[(0x1000000,0x1200000),(0x7000000,0x400000),(0x5ff0000,0x90000)]
for address,size in regions:assert kernel.VirtualAlloc(address,size,0x3000,4)==address
def reset(lib,n=128,side=8):
 for address,size in regions:ctypes.memset(address,0xa5,size)
 lib.backend_reset(126,0,0);lib.prepare(n,side)
def state(lib):
 return ctypes.string_at(lib.public_snapshot(),lib.public_bytes())+ctypes.string_at(lib.private_snapshot(),lib.private_bytes())
def frame_bytes(index):return ctypes.string_at(0x1000000+(0x400000 if index&1 else 0),1280*720*4)

assert 0<libs[1].frozen_bytes()<=512
case_count=0
for deferred in [0,1]:
 for poison in [0,1]:
  for which in range(36):
   images=[]
   for ix,lib in enumerate(libs):
    reset(lib);lib.hud_case(which,deferred,poison);images.append(frame_bytes(which))
   assert images[0]==images[1],('frozen exact HUD',deferred,poison,which)
   case_count+=1
print('HUD_FROZEN GOLDEN',case_count,'mode/old-value mutation frames',flush=True)

runtime_points=0
for side,n,policy,fault in [(8,20000,0,0),(32,5000,0,0),(8,128,1,0),(32,128,1,0),(8,128,0,1),(32,128,0,1)]:
 expected=[]
 for ix,lib in enumerate(libs):
  reset(lib,n,side);lib.hud_policy(policy)
  if fault:lib.backend_inject(fault)
  for f in range(16):
   lib.frame(f);result=(H(frame_bytes(f)),H(state(lib)),lib.real_hash())
   if ix==0:expected.append(result)
   else:assert result==expected[f],('C284 runtime',side,n,policy,fault,f,result,expected[f]);runtime_points+=1
print('HUD_FROZEN RUNTIME',runtime_points,'full state/pixel frames',flush=True)

# Build the actual firmware_main as an executable, feeding its real UART command
# parser. Read-only completion callbacks snapshot before cleanup. Capture all
# pixels; only the explicitly time-derived FPS/R row is excluded for comparison.
wire_tail=r'''
#include <windows.h>
#include <io.h>
#include <fcntl.h>
extern void backend_reset(unsigned,unsigned,unsigned);
int main(int argc,char **argv){
 assert(argc==5);_setmode(_fileno(stdout),_O_BINARY);
 unsigned side=atoi(argv[1]),fault=atoi(argv[2]),frames=atoi(argv[3]),n=side==32?5000:20000;
 snprintf(capture_prefix,sizeof capture_prefix,"%s",argv[4]);
 for(unsigned i=0;i<3;++i){uintptr_t v=(uintptr_t[]){0x1000000,0x7000000,0x5ff0000}[i];unsigned z=(unsigned[]){0x1200000,0x400000,0x90000}[i];assert(VirtualAlloc((void*)v,z,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE)==(void*)v);}
 backend_reset(126,0,fault);host_uart_at=0;
 host_uart_end=sprintf((char*)host_uart,":set tick_profile 0\n:set hud_dma_tail_enabled 0\n:hello\n:gload run %u 6 12 %u %u %u 123456789\n",451000+side,n,side,frames);
 firmware_main();return 99;
}
'''
wire_callback=r'''
static char capture_prefix[1024],wire_line[1024];static unsigned wire_at;
const void *public_snapshot(void);unsigned public_bytes(void);
const void *private_snapshot(void);unsigned private_bytes(void);
void host_capture_before_finish(void){
 char path[1200];snprintf(path,sizeof path,"%s.state.bin",capture_prefix);FILE *f=fopen(path,"wb");assert(f);
 assert(fwrite(public_snapshot(),1,public_bytes(),f)==public_bytes());assert(fwrite(private_snapshot(),1,private_bytes(),f)==private_bytes());fclose(f);
 snprintf(path,sizeof path,"%s.frame.bin",capture_prefix);f=fopen(path,"wb");assert(f);uint32_t fb=bb_read(BB_FRONT);
 assert(fwrite((void*)(uintptr_t)fb,1,1280*720*4,f)==1280*720*4);fclose(f);
}
void uart_write(unsigned u,unsigned c){(void)u;putchar(c);if(c=='\n'){
 wire_line[wire_at]=0;if(!strncmp(wire_line,"GLOAD_DONE ",11)){fflush(stdout);exit(0);}wire_at=0;
 }else if(c!='\r'){assert(wire_at+1<sizeof wire_line);wire_line[wire_at++]=(char)c;}}
'''
wire_results=[]
for label,root in [('reference',B),('candidate',P)]:
 gl=(root/'src/game_load.inc').read_text();needle='static void game_load_finish(const char *status,const char *reason){\n    if(!game_load_running)return;'
 assert gl.count(needle)==1
 gl=gl.replace(needle,needle+'\n    host_capture_before_finish();')
 inc=O/(label+'_wire_game_load.inc');inc.write_text(gl)
 game=(O/(label+'_game.c')).read_text().replace('#include "game_load.inc"','void host_capture_before_finish(void);\n#include "'+inc.as_posix()+'"')
 gf=O/(label+'_wire_game.c');gf.write_text(game)
 host=(O/(label+'_host.c')).read_text().replace((O/(label+'_game.c')).as_posix(),gf.as_posix())
 host=host.replace('unsigned uart_writeAvailability(unsigned u) { (void)u; return 0; }','unsigned uart_writeAvailability(unsigned u) { (void)u; return 128; }')
 host=host.replace('void uart_write(unsigned u, unsigned c) { (void)u; (void)c; }',wire_callback)
 host=host.replace('return host_uart_end-host_uart_at;','return bb_read(BB_DISPLAY_CTRL)?host_uart_end-host_uart_at:0;')
 hf=O/(label+'_wire.c');hf.write_text(host+wire_tail)
 cmd=json.loads((O/(label+'_argv.json')).read_text());cmd.remove('-shared');cmd[cmd.index(str(O/(label+'_host.c')))]=str(hf)
 if label=='candidate':cmd+=['-DTEST_HUD_FROZEN']
 exe=O/(label+'_wire.exe');run(cmd+['-Wl,--image-base,0x180000000,--high-entropy-va,--dynamicbase','-o',str(exe)],label+'_wire_compile')
 for side,fault in [(8,0),(32,0),(8,14),(32,14)]:
  tag=f'{label}_{side}_fault{fault}';out=R/tag
  q=run([str(exe),str(side),str(fault),'60',str(out)],tag)
  assert 'status='+('CANCEL' if fault else 'PASS') in q.stdout,q.stdout[-2000:]
  frame=Path(str(out)+'.frame.bin').read_bytes()
  stable=b''.join(frame[y*5120:(y+1)*5120] if not 588<=y<596 else frame[y*5120:y*5120+1072*4] for y in range(720))
  result=(Path(str(out)+'.state.bin').read_bytes(),stable)
  if label=='reference':wire_results.append((side,fault,result))
  else:
   expected=next(r for s,f,r in wire_results if s==side and f==fault)
   assert result==expected,('real main mismatch',side,fault)

report={'status':'PASS','golden_root':str(B),'snapshot_bytes':libs[1].frozen_bytes(),'mutation_mode_frames':case_count,'runtime_full_state_pixel_frames':runtime_points,'actual_main_comparisons':4,'actual_main_scope':'60-frame 8/20000 and 32/5000, plus active menu cancellation; exact state and full image excluding only numeric FPS/R row y588..595. Native DMA/display model, no board FPS.','source_sha256':{f.name:H(f.read_bytes()) for f in sorted((P/'src').glob('*')) if f.is_file()},'golden_source_sha256':{f.name:H(f.read_bytes()) for f in sorted((B/'src').glob('*')) if f.is_file()}}
(R/'summary.json').write_text(json.dumps(report,indent=2));print('HUD_FROZEN PASS',report['snapshot_bytes'],'bytes; real main/state/pixels exact',flush=True)
