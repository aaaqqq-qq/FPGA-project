# Frozen HUD scheduling regression

Run `python tests/hud_frozen/test.py --host-cc E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe`.
The default golden source is the adjacent preserved C284
`game60_pipe5_prepare_actor_fw_20261103` folder; `--baseline-root` can select its
relocated exact copy. Source hashes are recorded in the result.

The fixture uses the existing production-game APB/DMA builder from
`scripts/test_pipe5.py`; it does not alter that script or its assertions. It builds
separate C284 and candidate DLLs/executables in `build/hud_frozen` and writes
results to `results/hud_frozen`.

- 144 complete-frame golden comparisons cover normal play, stress, dodge,
  cleared/lost, menu, pause, validation, HP/level/score boundaries and six boss
  states. Half deliberately overwrite live HUD values and configuration between
  capture and emission. Supported active PLAY cases also use deferred capture;
  other modes retain their serial production route.
- 96 actual render/runtime frames compare gameplay arrays, replay state hash and
  every framebuffer pixel against C284. They include 8px/20000, 32px/5000, both
  HUD policies and exact NO_DRAW fallback. Diagnostic values are normalized in
  this explicit frame fixture so the complete HUD, including FPS/R, is compared.
- Four actual `firmware_main`/UART executions compare state at the production
  completion boundary and all image pixels except the time-derived FPS/R row
  (right HUD y588–595). They cover each target for 60 frames and cancellation
  during active motion. The normal protocol must say PASS and cancellation must
  say CANCEL; synthetic clock behavior does not establish board FPS.

The initial new fixture incorrectly called deferred capture during paused
STRESS. C284 itself rejected that unsupported sequence. The recorded failure and
correction are retained in `results/hud_frozen/initial_fixture_failure.txt`.

Current result: PASS, snapshot 224 bytes. Product source hashes, golden source
hashes and validation scope are in `results/hud_frozen/summary.json`.
