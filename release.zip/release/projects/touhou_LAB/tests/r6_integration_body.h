#include "enemies.h"
static uint32_t replay_expected[1200];
static unsigned replay_mode_expected[1200];
static void integrated_setup(unsigned bosses_count,unsigned fairies){
    replay_reset();game_config_defaults();game_cfg.boss_count=bosses_count;game_cfg.enemy_count=fairies;
    remote_input_init(&remote);choice=0;autoplay=demo_invincible=keys=edges=bomb_requests=0;start();
}
static void extension(unsigned count,unsigned fairies){
    integrated_setup(count,fairies);assert(mode==PLAY&&game_cfg.boss_count==count&&enemies_configured_count()==fairies);
    assert(bosses[0].state==BOSS_NORMAL);
    for(unsigned i=1;i<count;++i)assert(bosses[i].state==BOSS_WAIT&&bosses[i].hp==3000);
    for(unsigned t=0;t<300;++t)enemies_tick(t,512,620);
    assert(enemies_active_count()==fairies);
    game_cfg.enrage_intro_ticks=2;game_cfg.enter_ticks=2;
    bosses[0].vulnerable=1; /* controlled half-HP fixture, not a natural win claim */
    assert(battle_apply_damage(0,3000,0)==1500);for(unsigned t=0;t<8;++t)runtime_step();
    assert(summon_done);for(unsigned i=1;i<count;++i)assert(bosses[i].entered&&(bosses[i].state==BOSS_NORMAL||bosses[i].state==BOSS_ENRAGED));
}
int main(void){
    integrated_setup(3,0);assert(game_cfg.boss_count==3&&!enemies_configured_count());
    extension(4,6);extension(6,12);puts("I01 PASS baseline3+0 and actual start/summon4+6,6+12");
    for(unsigned i=0;i<MAX_BOSSES;++i){bosses[i].x=100;bosses[i].y=100;bosses[i].state=BOSS_DEAD;bosses[i].dead=1;bosses[i].hp=0;}
    bosses[5].x=900;bosses[5].y=100;bosses[5].state=BOSS_ENRAGED;bosses[5].dead=0;bosses[5].hp=100;bosses[5].vulnerable=1;
    player_shots_reset();PlayerShot *s=&player_shots[0];s->live=1;s->x=900;s->y=100;s->fx=s->x*256;s->fy=s->y*256;
    player_shots_tick();assert(!s->live&&bosses[5].hp==100-(int)game_cfg.player_shot_damage);
    player_shots_reset();s=&player_shots[0];s->live=1;s->kind=PLAYER_KIND_HOMING;s->x=800;s->y=400;s->fx=s->x*256;s->fy=s->y*256;s->vy=-512;s->target=-1;
    player_shots_tick();assert(s->live&&s->target==5&&s->target_valid);
    puts("I02 PASS real player projectile damage and homing target slot5");
    integrated_setup(6,12);for(unsigned t=0;t<300;++t)enemies_tick(t,512,620);unsigned before=enemies_kills;
    bomb_requests=1;bomb();assert(player.bombs==2&&enemies_kills==before+12&&!enemies_active_count()&&!stage.count);
    puts("I03 PASS real bomb consumes once, kills ordinary enemies and clears shared pool");
    integrated_setup(6,12);for(unsigned i=0;i<MAX_BOSSES;++i){bosses[i].hp=0;bosses[i].dead=1;bosses[i].entered=1;bosses[i].state=BOSS_DEAD;}
    player.hp=0;player.alive=0;slowmo_remaining=12;resolve_outcome();assert(mode==LOST&&!enemies_active_count());
    puts("I04 PASS simultaneous player death outranks all-boss victory and clears fairies");
    integrated_setup(6,12);for(unsigned i=0;i<MAX_BOSSES;++i){bosses[i].hp=0;bosses[i].dead=1;bosses[i].entered=1;bosses[i].state=BOSS_DEAD;}
    slowmo_remaining=12;slowmo_phase=0;dead_seen=63;resolve_outcome();assert(mode==PLAY);
    for(unsigned i=0;i<12;++i)runtime_step();assert(mode==CLEARED&&!slowmo_remaining);
    puts("I05 PASS last-boss12-base-tick ceremony precedes CLEARED");
    extension(6,12);for(unsigned i=0;i<6;++i){bosses[i].state=BOSS_ENRAGED;bosses[i].hp=3000;bosses[i].dead=0;}
    hud_capture[0]=0;capture_hud=1;scene_sprite_count=8211;hud();capture_hud=0;
    assert(strstr(hud_capture,"BOSS 6/6 MOB 12/12")&&strstr(hud_capture,"RUMIA II")&&strstr(hud_capture,"CIRNO II")&&strstr(hud_capture,"MEILING II")&&strstr(hud_capture,"ACTORS 19  DRAWN 8211"));
    puts("I06 PASS compact HUD names and actor/sprite/ordinary counters");
    integrated_setup(6,12);game_cfg.boss_max_hp=24;game_cfg.boss_half_hp=12;game_cfg.enrage_intro_ticks=4;game_cfg.enter_ticks=8;
    game_cfg.player_shot_damage=50;game_cfg.main_fire_period=2;game_cfg.spawn_invuln_ticks=100000;
    assert(replay_record_start(0x13579bdfu)==0&&game_cfg.boss_count==6&&enemies_configured_count()==12);
    unsigned total=0;
    for(unsigned t=0;t<600;++t){keys=(t/60)%2?1:2;edges=0;bomb_requests=t==80||t==250?1:0;runtime_step();replay_expected[t]=runtime_state_hash();replay_mode_expected[t]=mode;total=t+1;if(mode==CLEARED||mode==LOST)break;}
    assert(mode==CLEARED&&enemies_spawns>=12); /* tuned fixture, real runtime outcome */
    if(replay_state()==REPLAY_RECORDING)assert(!replay_stop_recording());
    assert(replay_state()==REPLAY_READY&&replay_header()->final_tick==total);assert(!replay_start_playback());
    for(unsigned t=0;t<total;++t){keys=15;edges=15;bomb_requests=3;runtime_step();assert(runtime_state_hash()==replay_expected[t]&&mode==replay_mode_expected[t]);}
    if(replay_state()==REPLAY_PLAYING)runtime_step();assert(replay_state()==REPLAY_FINISHED&&!replay_status());
    printf("I07 PASS actual6boss12fairy runtime replay %u ticks with per-tick complete hashes\n",total);
    puts("ALL_R6_INTEGRATION_PASS");return 0;
}
