#ifndef PIPE5_GAME_STUBS_H
#define PIPE5_GAME_STUBS_H
/* Existing gameplay-only suites retain a cap0 display. New PIPE5 tests remove
 * this header and link the real scene, control, battle and motion driver. */
#include "scene.h"
#include "../src/pipe5_control.c"
#ifndef SCENE_PIPE5_API
typedef struct {unsigned epoch,count,alpha,flags,key,material;} SceneSubmission;
#endif
void scene_pipe_set_service(void (*service)(void)){(void)service;}
void scene_pipe_defer_hud(unsigned e){(void)e;}
void scene_pipe_draw_hud(void){}
unsigned scene_pipe_snapshot_epoch(void){return 0;}
unsigned scene_pipe_frame_epoch(void){return 0;}
unsigned scene_pipe_fallback(void){return 0;}
void scene_pipe_check_fault(void){}
SceneSubmission scene_pipe_submission(void){return (SceneSubmission){0};}
#endif
