#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "battle.c"
static unsigned checks;
#define CK(x) do{++checks;if(!(x)){printf("R6_FAIL line=%u %s\n",__LINE__,#x);return 1;}}while(0)
static void reset_n(unsigned n){game_config_defaults();game_cfg.boss_count=n;battle_set_legacy(0);player_reset(512,620);effects_reset();battle_reset(0,SHOT_CAPACITY);}
static int config_test(void){
 game_config_defaults();CK(MAX_BOSSES==6&&game_cfg.boss_count==3&&game_cfg.enemy_count==0&&game_cfg.background_depth_enabled==1);
 for(unsigned n=1;n<=6;++n)CK(game_config_set("boss_count",n)&&game_cfg.boss_count==n);
 GameConfig before=game_cfg;CK(!game_config_set("boss_count",7)&&!memcmp(&before,&game_cfg,sizeof(before)));
 CK(!game_config_set("boss_count",0)&&!memcmp(&before,&game_cfg,sizeof(before)));
 CK(game_config_set("enemy_count",12)&&game_cfg.enemy_count==12);
 before=game_cfg;CK(!game_config_set("enemy_count",13)&&!memcmp(&before,&game_cfg,sizeof(before)));
 CK(game_config_set("background_depth_enabled",0)&&!game_cfg.background_depth_enabled);
 for(unsigned k=3;k<MAX_BOSSES;++k){
  CK(game_cfg.boss_move_num[k]==game_cfg.boss_move_num[k%3]);
  CK(game_cfg.boss_bullets_num[k]==game_cfg.boss_bullets_num[k%3]);
  CK(game_cfg.boss_burst_rings[k]==game_cfg.boss_burst_rings[k%3]);
 }
 CK(game_config_set("boss_move_num[5]",4)&&game_cfg.boss_move_num[5]==4);
 before=game_cfg;CK(!game_config_set("boss_move_num[6]",4)&&!memcmp(&before,&game_cfg,sizeof(before)));
 puts("R6_CONFIG PASS default3, counts1..6, enemy0..12, profileinheritance andatomic bounds");return 0;
}
static int topology_test(unsigned n){
 reset_n(n);CK(bosses[0].state==BOSS_NORMAL&&bosses[0].entered);
 for(unsigned k=1;k<MAX_BOSSES;++k)CK(bosses[k].state==BOSS_WAIT&&!bosses[k].entered);
 bosses[0].vulnerable=1;CK(battle_apply_damage(0,100000,1)==1500&&bosses[0].hp==1500);
 for(unsigned t=0;t<game_cfg.enrage_intro_ticks;++t)battle_step(512,620);
 CK(summon_done&&bosses[0].state==BOSS_ENRAGED&&bosses[0].hp==3000);
 for(unsigned k=1;k<n;++k){
  CK(bosses[k].state==BOSS_ENTER&&bosses[k].hp==3000);
  CK(bosses[k].enter_tx==256+(k%3)*256&&bosses[k].enter_ty==120+(k/3)*160);
 }
 for(unsigned k=n;k<MAX_BOSSES;++k)CK(bosses[k].state==BOSS_WAIT);
 for(unsigned t=0;t<game_cfg.enter_ticks;++t)battle_step(512,620);
 for(unsigned k=1;k<n;++k){
  CK(bosses[k].entered&&bosses[k].state==BOSS_NORMAL);
  bosses[k].hp=1501;bosses[k].vulnerable=1;
  CK(battle_apply_damage(k,2000,1)==1&&bosses[k].hp==1500&&bosses[k].enrage_done);
 }
 for(unsigned t=0;t<game_cfg.enrage_intro_ticks;++t)battle_step(512,620);
 for(unsigned k=1;k<n;++k)CK(bosses[k].state==BOSS_ENRAGED&&bosses[k].hp==1500&&bosses[k].enrage_done==1);
 if(n>3){unsigned old=(unsigned)VM(0)->c.v[7];VM(3)->c.v[7]=123456;CK((unsigned)VM(0)->c.v[7]==old);VM(3)->c.v[7]=0;}
 for(unsigned t=0;t<3600;++t){
  battle_step(512,620);CK(!stage.fault&&stage.count<=SHOT_CAPACITY);
  for(unsigned k=0;k<n;++k)CK(bosses[k].x>=32&&bosses[k].x<=ARENA_W-32&&bosses[k].y>=40&&bosses[k].y<=ARENA_H-40);
 }
 for(unsigned k=0;k<n;++k)CK(bosses[k].fired>0&&bosses[k].state==BOSS_ENRAGED);
 for(unsigned j=0;j<stage.count;++j)CK(stage.owner[j]<n&&stage.shots[j].tile>=54&&stage.shots[j].tile<70);
 CK(!battle_targetable(n)&&!battle_can_damage(MAX_BOSSES));
 if(n>3){uint32_t h=battle_state_hash(2166136261u);++VM(n-1)->c.time;CK(battle_state_hash(2166136261u)!=h);--VM(n-1)->c.time;}
 for(unsigned k=0;k<n;++k){bosses[k].hp=1;CK(battle_apply_damage(k,5,1)==1&&bosses[k].dead);if(k+1<n)CK(!battle_all_defeated());}
 CK(battle_all_defeated()&&battle_cleared);
 printf("R6_TOPOLOGY PASS bosses=%u independent phase/VM/HP/owner,3600active ticks,all-dead clear\n",n);return 0;
}
static int ordinary_api_test(void){
 reset_n(6);BattleBoss before[MAX_BOSSES];memcpy(before,bosses,sizeof(before));
 CK(!battle_spawn_enemy_bullet(127,100,100,0,Q,54));CK(!battle_spawn_enemy_bullet(256,100,100,0,Q,54));
 CK(!battle_spawn_enemy_bullet(128,-1,100,0,Q,54));CK(!battle_spawn_enemy_bullet(128,100,100,0,32768,54));
 CK(!battle_spawn_enemy_bullet(128,100,100,0,Q,70));
 CK(battle_spawn_enemy_bullet(128,100,100,0,Q,54));
 CK(battle_spawn_enemy_bullet(129,200,200,16384,2*Q,69));
 CK(battle_spawn_enemy_bullet(255,300,300,0,3*Q,60));
 CK(!memcmp(before,bosses,sizeof(before))&&stage.count==3&&stage.requested==3&&stage.emitted==3);
 CK(stage.owner[0]==128&&stage.owner[1]==129&&stage.owner[2]==255);
 CK(battle_clear_owner(128)==1&&stage.count==2);
 for(unsigned i=0;i<stage.count;++i)CK(stage.owner[i]!=128&&effects[i].speed==(stage.owner[i]==255?3*Q:2*Q));
 CK(battle_clear_owner(256)==0&&battle_clear_owner(255)==1&&battle_clear_owner(129)==1&&stage.count==0);
 stage.limit=1;CK(battle_spawn_enemy_bullet(128,100,100,0,Q,54));
 CK(!battle_spawn_enemy_bullet(129,200,200,0,Q,54)&&stage.rejected==1);
 CK(!memcmp(before,bosses,sizeof(before)));
 puts("R6_ORDINARY_API PASS128..255 tags, noBossstatwrite, poolbounds, privateEffect-compaction");return 0;
}
static int player_six_test(void){
 reset_n(6);
 for(unsigned k=0;k<6;++k){bosses[k].state=BOSS_ENRAGED;bosses[k].entered=1;bosses[k].enraged=1;bosses[k].x=100;bosses[k].y=100;}
 bosses[5].x=500;bosses[5].y=400;
 PlayerShot *s=&player_shots[0];*s=(PlayerShot){0};s->live=1;s->kind=PLAYER_KIND_HOMING;s->x=500;s->y=600;s->fx=500*256;s->fy=600*256;s->vy=-512;s->target=-1;
 player_shots_tick();CK(s->target==5&&s->target_valid);
 bosses[5].dead=1;bosses[5].state=BOSS_DEAD;player_shots_tick();CK(s->target>=0&&s->target<5);
 player_shots_reset();s=&player_shots[0];*s=(PlayerShot){0};s->live=1;s->kind=PLAYER_KIND_MAIN;s->x=500;s->y=402;s->fx=500*256;s->fy=402*256;s->vy=-512;
 bosses[5].dead=0;bosses[5].state=BOSS_ENRAGED;int hp=bosses[5].hp;
 player_shots_tick();CK(!s->live&&bosses[5].hp==hp-(int)game_cfg.player_shot_damage);
 puts("R6_PLAYER PASS homingtarget5,deadreacquire,andmainshotdamageboss5");return 0;
}
static int tiny_burst_test(void){
 reset_n(6);
 for(unsigned k=0;k<6;++k){bosses[k].state=BOSS_ENRAGED;
  for(unsigned n=1;n<=32;++n){
   stage.count=0;unsigned before=stage.emitted;
   unsigned expected=(n*game_cfg.boss_burst_scale_num[k]+game_cfg.boss_burst_scale_den[k]-1)/game_cfg.boss_burst_scale_den[k];
   battle_burst(k,n);CK(stage.emitted-before==expected&&stage.count==expected);
  }
 }
 puts("R6_BURST_BOUNDS PASS1..32requested x6bosses no unsignedringunderflow");return 0;
}
int main(void){if(config_test()||tiny_burst_test())return 1;for(unsigned n=1;n<=6;++n)if(topology_test(n))return 1;if(ordinary_api_test()||player_six_test())return 1;printf("R6_EXPANDED_BATTLE PASS checks=%u\n",checks);return 0;}
