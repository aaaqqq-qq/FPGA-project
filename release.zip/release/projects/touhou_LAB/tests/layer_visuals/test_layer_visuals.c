#include "layer_visuals.h"
#include "background.h"
#include "bitblt.h"
#include "art_ids.h"
#include "arena.h"
#include <assert.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "art_data.h"

typedef struct {int kind,x,y,w,h;unsigned tile,alpha;uint32_t color;} Op;
static Op calls[32];
static unsigned called,observed_area,checks;
static uint32_t guarded_pixels[1280*720+32];
static uint32_t *pixels=guarded_pixels+16;
static int painting;
static unsigned expected_strength=1;
static void set_strength(unsigned level){layer_visuals_strength(level);expected_strength=level<1?1:level>2?2:level;}
#define VERIFY(x) do{++checks;assert(x);}while(0)

static unsigned tile_area(int x,int y,unsigned w,unsigned h){
    int l=x<32?32:x,t=y<16?16:y;
    int r=x+(int)w>1056?1056:x+(int)w;
    int b=y+(int)h>704?704:y+(int)h;
    return r>l&&b>t?(unsigned)(r-l)*(unsigned)(b-t):0;
}
static void paint_tile(int x,int y,unsigned tile,unsigned alpha){
    const Tile *a=&tiles[tile];
    for(int sy=0;sy<a->h;++sy)for(int sx=0;sx<a->w;++sx){
        int px=x+sx,py=y+sy;
        if(px<32||px>=1056||py<16||py>=704)continue;
        unsigned index=a->off/4+(unsigned)sy*a->w+(unsigned)sx;
        uint32_t color=art_palette[art_pixels[index]];
        if(color!=BB_KEY)pixels[py*1280+px]=bb_blend(color,pixels[py*1280+px],alpha);
    }
}
void scene_rect(int x,int y,int w,int h,uint32_t color){
    VERIFY(called<32&&x>=32&&y>=16&&w>0&&h>0&&x+w<=1056&&y+h<=704);
    calls[called++]=(Op){0,x,y,w,h,0,0,color};observed_area+=(unsigned)w*(unsigned)h;
    if(painting)for(int py=y;py<y+h;++py)for(int px=x;px<x+w;++px)pixels[py*1280+px]=color;
}
void scene_tile(int x,int y,unsigned tile,unsigned alpha){
    unsigned size=expected_strength==2?64:32;
    VERIFY(called<32&&tile==(expected_strength==2?ART_RING_CYAN64:ART_RING_CYAN32));
    VERIFY(expected_strength==2?(alpha>=100&&alpha<=130):(alpha>=38&&alpha<=53));
    VERIFY(tile_area(x,y,size,size)>0);
    calls[called++]=(Op){1,x,y,(int)size,(int)size,tile,alpha,0};observed_area+=tile_area(x,y,size,size);
    if(painting)paint_tile(x,y,tile,alpha);
}
static void begin(unsigned tick,unsigned enabled,int px,int py){
    called=observed_area=0;memset(calls,0,sizeof(calls));
    layer_visuals_begin(tick,enabled,px,py);
    VERIFY(layer_visuals_jobs==0&&layer_visuals_area==0&&layer_visuals_dropped==0&&layer_visuals_clipped==0);
}
static void accounting(void){
    VERIFY(layer_visuals_jobs==called);
    VERIFY(layer_visuals_area==observed_area);
    VERIFY(called<=LAYER_VISUAL_JOB_LIMIT&&observed_area<=LAYER_VISUAL_AREA_LIMIT);
}
static void maximal(unsigned tick,int px,int py){
    begin(tick,1,px,py);
    for(unsigned i=0;i<7;++i)layer_visuals_shadow(80+(int)i*130,180+(int)i*55,40);
    layer_visuals_glow(px,py);layer_visuals_foreground();accounting();
}
static void write_preview(const char *path){
    painting=1;background_prepare(1);
    for(unsigned i=0;i<16;++i)guarded_pixels[i]=guarded_pixels[1280*720+16+i]=0x1234abcdu;
    for(unsigned y=0;y<720;++y)for(unsigned x=0;x<1280;++x)pixels[y*1280+x]=background_pixel(x,y);
    begin(240,1,512,620);
    layer_visuals_shadow(512,644,30);layer_visuals_shadow(260,210,36);
    layer_visuals_shadow(740,270,36);layer_visuals_glow(512,620);
    paint_tile(32+512-15,16+620-23,0,240);
    paint_tile(32+260-16,16+180-24,4,240);
    paint_tile(32+740-16,16+240-24,43,240);
    layer_visuals_foreground();accounting();
    for(unsigned i=0;i<16;++i)VERIFY(guarded_pixels[i]==0x1234abcdu&&guarded_pixels[1280*720+16+i]==0x1234abcdu);
    FILE *f=fopen(path,"wb");VERIFY(f!=NULL);fprintf(f,"P6\n1280 720\n255\n");
    for(unsigned i=0;i<1280*720;++i){unsigned char c[3]={(unsigned char)(pixels[i]>>16),(unsigned char)(pixels[i]>>8),(unsigned char)pixels[i]};VERIFY(fwrite(c,1,3,f)==3);}
    VERIFY(fclose(f)==0);painting=0;
}
int main(int argc,char **argv){
    set_strength(1);
    begin(0,0,INT_MIN,INT_MAX);
    for(unsigned i=0;i<100;++i){layer_visuals_shadow(INT_MAX,INT_MIN,UINT_MAX);layer_visuals_glow(INT_MIN,INT_MAX);layer_visuals_foreground();}
    accounting();VERIFY(called==0&&layer_visuals_dropped==0&&layer_visuals_clipped==0);
    puts("V01 PASS disabled is inert even for extreme coordinates");

    maximal(0,512,620);VERIFY(called==12&&observed_area==1828&&layer_visuals_dropped==0);
    for(unsigned i=0;i<100;++i){layer_visuals_shadow(512,620,40);layer_visuals_glow(512,620);layer_visuals_foreground();}
    accounting();VERIFY(called==12&&layer_visuals_dropped==200);
    puts("V02 PASS seven shadows + one aura + four ribbons hard cap12jobs/1828pixels, no silent overrun");

    const int points[]={INT_MIN,-100000,-33,-16,-1,0,1,16,343,620,687,688,1023,1024,100000,INT_MAX};
    for(unsigned i=0;i<sizeof(points)/sizeof(points[0]);++i)for(unsigned j=0;j<sizeof(points)/sizeof(points[0]);++j){
        begin(i+j,1,points[i],points[j]);layer_visuals_shadow(points[i],points[j],UINT_MAX);layer_visuals_glow(points[i],points[j]);layer_visuals_foreground();accounting();
    }
    begin(0,1,0,0);layer_visuals_shadow(INT_MIN,INT_MIN,0);VERIFY(called==0);
    puts("V03 PASS exact field clipping, safe extreme integer inputs, no HUD/border commands");

    maximal(997,350,510);Op saved[32];memcpy(saved,calls,sizeof(saved));unsigned saved_count=called,saved_area=observed_area;
    maximal(997,350,510);VERIFY(called==saved_count&&observed_area==saved_area&&!memcmp(saved,calls,sizeof(saved)));
    begin(300,1,100,344);layer_visuals_foreground();int left=calls[0].x,right=calls[2].x;
    for(unsigned i=0;i<called;++i)VERIFY(calls[i].x<152||calls[i].x>=904);
    begin(300,1,900,344);layer_visuals_foreground();VERIFY(calls[0].x<left&&calls[2].x<right);
    int motion=calls[0].x;begin(480,1,900,344);layer_visuals_foreground();VERIFY(calls[0].x!=motion);
    puts("V04 PASS deterministic repeated frame, camera counter-motion and bounded breeze in edge-only ribbons");

    for(unsigned tick=0;tick<60000;++tick){
        maximal(tick,(int)(tick%1025u),(int)((tick*7u)%689u));
        VERIFY(layer_visuals_dropped==0);
    }
    maximal(UINT_MAX,INT_MIN,INT_MAX);accounting();
    begin(1,0,512,620);layer_visuals_foreground();VERIFY(called==0);
    begin(2,1,512,620);layer_visuals_foreground();VERIFY(called==4);accounting();
    puts("V05 PASS60000frames budgets + tickwrap + enable/disable reset; gameplay RNG not referenced");
    for(unsigned level=1;level<=2;++level){
        set_strength(level);
        maximal(0,512,620);VERIFY(called==12&&observed_area==(level==1?1828u:5664u));
        for(unsigned i=0;i<sizeof(points)/sizeof(points[0]);++i)for(unsigned j=0;j<sizeof(points)/sizeof(points[0]);++j){
            begin(i+j,1,points[i],points[j]);layer_visuals_shadow(points[i],points[j],UINT_MAX);layer_visuals_glow(points[i],points[j]);layer_visuals_foreground();accounting();
        }
        maximal(997,350,510);memcpy(saved,calls,sizeof(saved));saved_count=called;saved_area=observed_area;
        maximal(997,350,510);VERIFY(called==saved_count&&observed_area==saved_area&&!memcmp(saved,calls,sizeof(saved)));
        begin(300,1,0,344);layer_visuals_foreground();
        for(unsigned i=0;i<called;++i)VERIFY(calls[i].x+calls[i].w<=32+160||calls[i].x>=32+ARENA_W-160);
        for(unsigned tick=0;tick<60000;++tick){maximal(tick,(int)(tick%1025u),(int)((tick*7u)%689u));VERIFY(layer_visuals_dropped==0);}
        begin(UINT_MAX,0,INT_MIN,INT_MAX);layer_visuals_shadow(INT_MAX,INT_MIN,UINT_MAX);layer_visuals_glow(INT_MIN,INT_MAX);layer_visuals_foreground();accounting();VERIFY(!called&&!layer_visuals_dropped&&!layer_visuals_clipped);
    }
    set_strength(0);maximal(0,512,620);VERIFY(observed_area==1828);
    set_strength(UINT_MAX);maximal(0,512,620);VERIFY(observed_area==5664);
    set_strength(1);maximal(0,512,620);VERIFY(observed_area==1828);
    puts("V07 PASS both strengths60000ticks each, exact1828/5664area, clipping/determinism, clamp and switch/off");
    if(argc>1){set_strength(1);write_preview(argv[1]);}
    if(argc>2){set_strength(2);write_preview(argv[2]);}
    if(argc>1)puts("V06 PASS both bounded composition previews with original atlas and cached background");
    printf("LAYER_VISUALS PASS checks=%u\n",checks);return 0;
}
