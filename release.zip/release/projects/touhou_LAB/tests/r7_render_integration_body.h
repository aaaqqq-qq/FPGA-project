/* The game's actual render/runtime is included by the generated host source.
   Commands pass through the production render_queue.c; only raster/MMIO are
   replaced. Independent pair-order assertions do not certify physical FPS. */
#include "render_queue.h"
static unsigned checks;
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"R7_RENDER_FAIL line=%u %s\n",__LINE__,#x);exit(1);}}while(0)
static void fixture(void){
 game_config_defaults();replay_reset();choice=0;hardware=1;validation_active=0;
 autoplay=demo_invincible=keys=edges=bomb_requests=0;terminal_key=terminal_banks=0;
 presentation_revision=0;game_cfg.boss_count=6;game_cfg.enemy_count=12;game_cfg.layer_visuals_enabled=0;
 start();for(unsigned t=0;t<300;++t)enemies_tick(t,512,620);
 for(unsigned k=0;k<6;++k){bosses[k].state=BOSS_ENRAGED;bosses[k].hp=3000;bosses[k].dead=0;bosses[k].entered=1;bosses[k].x=400;bosses[k].y=100+(int)k*60;}
 bosses[1].state=BOSS_ENTER;
 player.x=400;player.y=260;player.hp=10;player.hit_invuln=player.hit_flash=player.upgrade_anim=0;
 ordinary_enemies[0].x=400;ordinary_enemies[0].y=450;
 ordinary_enemies[1].x=400;ordinary_enemies[1].y=140;
 player_shots_reset();player_shots[0].live=1;player_shots[0].x=400;player_shots[0].y=220;
 player_shots[1].live=1;player_shots[1].kind=PLAYER_KIND_HOMING;player_shots[1].x=400;player_shots[1].y=240;
 effects_reset();fx_boss_enrage_start(0);
}
static int signature_equal(const Trace *a,const Trace *b){
 const RqCommand *x=&a->c,*y=&b->c;
 return x->x==y->x&&x->y==y->y&&x->w==y->w&&x->h==y->h&&x->depth==y->depth&&x->color==y->color&&x->tile==y->tile&&x->scale==y->scale&&x->kind==y->kind&&x->layer==y->layer&&x->alpha==y->alpha&&!strcmp(a->text,b->text);
}
static int expected_before(unsigned i,unsigned j){
 const RqCommand *x=&submitted[i].c,*y=&submitted[j].c;
 if(ranks[x->layer]!=ranks[y->layer])return ranks[x->layer]<ranks[y->layer];
 if(x->layer!=y->layer)return x->layer<y->layer;
 if(x->depth!=y->depth)return x->depth<y->depth;
 return i<j;
}
static void oracle(void){
 CHECK(submitted_count==emitted_count);unsigned used[RQ_CAPACITY]={0};
 for(unsigned out=0;out<emitted_count;++out){
  unsigned pick=RQ_CAPACITY;
  for(unsigned i=0;i<submitted_count;++i)if(!used[i]&&(pick==RQ_CAPACITY||expected_before(i,pick)))pick=i;
  CHECK(pick<RQ_CAPACITY&&signature_equal(&submitted[pick],&emitted[out]));used[pick]=1;
 }
}
static void order_and_semantics(void){
 fixture();stage.count=20000;render(BB_FB0);CHECK(batch_calls==1&&batch_descriptors==20000);
 CHECK(submitted_count<RQ_CAPACITY&&submitted_count<180);CHECK(layer_begins==1&&flush_calls>=1&&hud_begins==1&&!rq_count());oracle();
 unsigned actors=0,shots=0,world_labels=0,point=0,last_actor=0,first_shot=RQ_CAPACITY;
 int depth=-2147483647;
 for(unsigned i=0;i<emitted_count;++i){Trace *t=&emitted[i];
  if(t->c.layer==SCENE_LAYER_ACTOR){CHECK(t->c.depth>=depth);depth=t->c.depth;++actors;last_actor=i;}
  if(t->c.layer==SCENE_LAYER_PROJECTILE){++shots;if(first_shot==RQ_CAPACITY)first_shot=i;}
  if(t->c.kind==RQ_TEXT&&strstr(t->text,"CIRNO")){CHECK(t->c.layer==SCENE_LAYER_WORLD_UI);++world_labels;}
  if(t->c.kind==RQ_RECT&&t->c.x==32+player.x-1&&t->c.y==16+player.y-1){CHECK(t->c.layer==SCENE_LAYER_OVERLAY);++point;}
 }
 CHECK(actors>=19&&shots==2&&world_labels==1&&point==1&&last_actor<first_shot);
 CHECK(scene_layer_reordered>0);puts("R701 PASS real game->production queue,20konebatch,stableY,projectile/effect/worldlabel/point priorities");
 fixture();game_cfg.layer_y_sort=0;render(BB_FB1);oracle();
 for(unsigned i=0;i<emitted_count;++i)if(emitted[i].c.layer==SCENE_LAYER_ACTOR)CHECK(emitted[i].c.depth==0);
 puts("R702 PASS Y-sort off retains same-depth submission order");
 fixture();game_cfg.layer_order[SCENE_LAYER_PROJECTILE]=1;render(BB_FB0);oracle();
 unsigned last_shot=0,first_actor=RQ_CAPACITY;
 for(unsigned i=0;i<emitted_count;++i){if(emitted[i].c.layer==SCENE_LAYER_PROJECTILE)last_shot=i;if(emitted[i].c.layer==SCENE_LAYER_ACTOR&&first_actor==RQ_CAPACITY)first_actor=i;}
 CHECK(last_shot<first_actor);puts("R703 PASS configured projectile rank alters actual queue order");
 fixture();game_cfg.layer_pipeline_enabled=0;render(BB_FB1);CHECK(!submitted_count&&emitted_count>0&&scene_layer_commands==0&&batch_calls==1);
 puts("R704 PASS disabled path immediate, no per-bullet queue duplication");
}
static void opaque_scope(void){
 Trace reference[RQ_CAPACITY];unsigned count,changed=0,fairies=0;
 fixture();game_cfg.render_budget_enabled=0;game_cfg.opaque_sprites=0;render(BB_FB0);
 count=submitted_count;memcpy(reference,submitted,sizeof(reference));
 fixture();game_cfg.render_budget_enabled=0;game_cfg.opaque_sprites=1;render(BB_FB0);
 CHECK(count==submitted_count);
 for(unsigned i=0;i<count;++i){
  Trace expected=reference[i];RqCommand *c=&expected.c;
  unsigned permitted=c->kind==RQ_TILE&&c->alpha==240&&
      (c->layer==SCENE_LAYER_PROJECTILE||(c->layer==SCENE_LAYER_ACTOR&&c->tile<ART_FAIRY_BLUE0));
  if(permitted){CHECK(submitted[i].c.alpha==255);expected.c.alpha=255;++changed;}
  if(c->kind==RQ_TILE&&c->tile>=ART_FAIRY_BLUE0){++fairies;CHECK(c->alpha==submitted[i].c.alpha);}
  CHECK(signature_equal(&expected,&submitted[i]));
 }
 CHECK(changed>=9&&fairies>=12);
 puts("R706 PASS opacity255 limitedto protagonist/Boss/playerprojectiles;fairies/effects/geometry unchanged;Key policy remains renderer-owned");
}
static void budget_integration(void){
 for(unsigned enabled=0;enabled<2;++enabled){
  fixture();game_cfg.render_budget_enabled=enabled;game_cfg.layer_visuals_enabled=1;game_cfg.layer_visuals_strength=2;
  uint32_t before=runtime_state_hash();render(BB_FB0);CHECK(runtime_state_hash()==before);
  CHECK(last_fx_quality==enabled&&last_fx_lod==enabled);
  unsigned aura=0,warning=0;
  for(unsigned i=0;i<submitted_count;++i){const RqCommand *c=&submitted[i].c;if(c->kind!=RQ_TILE)continue;
   if(c->layer==SCENE_LAYER_DECOR){CHECK(c->tile==(enabled?ART_RING_CYAN32:ART_RING_CYAN64));++aura;}
   if(c->layer==SCENE_LAYER_EFFECT){CHECK(c->tile==(enabled?ART_RING_ROSE32:ART_RING_WARN64));++warning;}
  }
  CHECK(aura==1&&warning==1&&last_decor_jobs<=12&&last_decor_area<=8192&&last_decor_dropped==0);
  mode=LOST;player.hp=0;player.alive=0;render(BB_FB0);render(BB_FB1);render(BB_FB0);
  if(last_fx_lod||last_layer_commands||last_decor_jobs||batch_calls)fprintf(stderr,"terminal diagnostic enabled=%u lod=%u q=%u decor=%u batch=%u banks=%u mode=%u hw=%u validation=%u\n",enabled,last_fx_lod,last_layer_commands,last_decor_jobs,batch_calls,terminal_banks,mode,hardware,validation_active);
  CHECK(last_fx_lod==0&&last_layer_commands==0&&last_decor_jobs==0&&batch_calls==0);
 }
 puts("R707 PASS actualgame wires qualitypolicy toevent/decor32rings,latchedquality/LOD,cachedterminalnofakejobs,physicsunchanged");
}
static uint32_t hashes[600];static unsigned modes[600];
static void render_neutral_logic(void){
 for(unsigned pass=0;pass<4;++pass){
  fixture();
  game_cfg.layer_pipeline_enabled=pass!=0;game_cfg.layer_y_sort=pass!=0;game_cfg.layer_visuals_enabled=pass!=0;
  game_cfg.battle_gather_enabled=pass>=2;game_cfg.opaque_sprites=pass>=2;game_cfg.render_budget_enabled=pass==3;
  game_cfg.boss_max_hp=24;game_cfg.boss_half_hp=12;game_cfg.enter_ticks=8;game_cfg.enrage_intro_ticks=4;
  game_cfg.player_shot_damage=50;game_cfg.spawn_invuln_ticks=100000;start();stage.seed=0x13579bdfu;
  for(unsigned t=0;t<600;++t){keys=(t/60)%2?1:2;edges=0;bomb_requests=t==80||t==250?1:0;runtime_step();
   uint32_t before=runtime_state_hash();render(t&1?BB_FB1:BB_FB0);CHECK(runtime_state_hash()==before);
   if(!pass){hashes[t]=before;modes[t]=mode;}else CHECK(hashes[t]==before&&modes[t]==mode);
  }
 }
 puts("R705 PASS600ticks each realruntime hashes invariant across layers,visuals,gather,opacity,budget4policies");
}
int main(void){order_and_semantics();opaque_scope();budget_integration();render_neutral_logic();printf("R7_RENDER_INTEGRATION PASS checks=%u\n",checks);return 0;}
