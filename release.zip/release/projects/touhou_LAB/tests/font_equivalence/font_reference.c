#include "font.h"
#include "bitblt.h"

/* Original compact 5x7 bitmap glyphs; column bits run from top to bottom. */
static const unsigned char digits[10][5] = {
 {0x3e,0x51,0x49,0x45,0x3e},{0x00,0x42,0x7f,0x40,0x00},
 {0x62,0x51,0x49,0x49,0x46},{0x22,0x49,0x49,0x49,0x36},
 {0x18,0x14,0x12,0x7f,0x10},{0x2f,0x49,0x49,0x49,0x31},
 {0x3e,0x49,0x49,0x49,0x32},{0x01,0x71,0x09,0x05,0x03},
 {0x36,0x49,0x49,0x49,0x36},{0x26,0x49,0x49,0x49,0x3e}
};
static const unsigned char letters[26][5] = {
 {0x7e,0x09,0x09,0x09,0x7e},{0x7f,0x49,0x49,0x49,0x36},
 {0x3e,0x41,0x41,0x41,0x22},{0x7f,0x41,0x41,0x22,0x1c},
 {0x7f,0x49,0x49,0x49,0x41},{0x7f,0x09,0x09,0x09,0x01},
 {0x3e,0x41,0x49,0x49,0x7a},{0x7f,0x08,0x08,0x08,0x7f},
 {0x00,0x41,0x7f,0x41,0x00},{0x20,0x40,0x41,0x3f,0x01},
 {0x7f,0x08,0x14,0x22,0x41},{0x7f,0x40,0x40,0x40,0x40},
 {0x7f,0x02,0x0c,0x02,0x7f},{0x7f,0x04,0x08,0x10,0x7f},
 {0x3e,0x41,0x41,0x41,0x3e},{0x7f,0x09,0x09,0x09,0x06},
 {0x3e,0x41,0x51,0x21,0x5e},{0x7f,0x09,0x19,0x29,0x46},
 {0x26,0x49,0x49,0x49,0x32},{0x01,0x01,0x7f,0x01,0x01},
 {0x3f,0x40,0x40,0x40,0x3f},{0x1f,0x20,0x40,0x20,0x1f},
 {0x7f,0x20,0x18,0x20,0x7f},{0x63,0x14,0x08,0x14,0x63},
 {0x03,0x04,0x78,0x04,0x03},{0x61,0x51,0x49,0x45,0x43}
};
static unsigned column(char c, unsigned x) {
    if (c >= 'a' && c <= 'z') c -= 'a' - 'A';
    if (c >= '0' && c <= '9') return digits[c-'0'][x];
    if (c >= 'A' && c <= 'Z') return letters[c-'A'][x];
    if (c == '-') return 0x08;
    if (c == ':') return x == 2 ? 0x24 : 0;
    if (c == '.') return x == 2 ? 0x40 : 0;
    if (c == '/') return 0x40u >> x;
    if (c == '+') return x == 2 ? 0x3e : 0x08;
    if (c == '=') return 0x14;
    if (c == '[') return x == 0 ? 0x7f : x < 3 ? 0x41 : 0;
    if (c == ']') return x == 4 ? 0x7f : x > 1 ? 0x41 : 0;
    return 0;
}
void draw_text_clipped(uint32_t fb, int x, int y, const char *t,
               uint32_t color, unsigned scale,
               int clip_left, int clip_top, int clip_right, int clip_bottom) {
    int64_t pen_x = x, pen_y = y;
    if (!t || !scale || (fb & 3u) || fb < 0x00100000u ||
        (uint64_t)fb + BB_FRAME_BYTES > BB_DDR_END) return;
    while (*t) {
        if (*t == '\n') {
            pen_x = 8;
            pen_y += 9u * (uint64_t)scale;
            if (pen_y >= BB_SCREEN_H) return;
            ++t; continue;
        }
        for (unsigned col = 0; col < 5 && pen_x < BB_SCREEN_W && pen_y < BB_SCREEN_H; ++col) {
            unsigned bits = column(*t, col);
            int64_t left = pen_x + col * (int64_t)scale;
            if (left >= BB_SCREEN_W) break;
            unsigned width = scale;
            if (width > BB_SCREEN_W - (unsigned)left) width = BB_SCREEN_W - (unsigned)left;
            for (unsigned row = 0; row < 7; ++row) if (bits & (1u << row)) {
                int64_t top = pen_y + row * (int64_t)scale;
                if (top >= BB_SCREEN_H) break;
                unsigned height = scale;
                if (height > BB_SCREEN_H - (unsigned)top) height = BB_SCREEN_H - (unsigned)top;
                for (unsigned sy = 0; sy < height; ++sy)
                    for (unsigned sx = 0; sx < width; ++sx) {
                        int64_t px=left+sx, py=top+sy;
                        if(px>=0 && py>=0 && px<BB_SCREEN_W && py<BB_SCREEN_H &&
                           px>=clip_left && px<clip_right && py>=clip_top && py<clip_bottom)
                            *(volatile uint32_t *)(uintptr_t)(fb + (unsigned)py * BB_SCREEN_STRIDE +
                                (unsigned)px * 4u) = color;
                    }
            }
        }
        /* Saturate once beyond the screen; a later newline resets x to 8. */
        pen_x += 6u * (uint64_t)scale;
        if (pen_x > BB_SCREEN_W) pen_x = BB_SCREEN_W;
        ++t;
    }
}
void draw_text(uint32_t fb, unsigned x, unsigned y, const char *t,
               uint32_t color, unsigned scale) {
    if(x>0x7fffffffu || y>0x7fffffffu)return;
    draw_text_clipped(fb,(int)x,(int)y,t,color,scale,0,0,BB_SCREEN_W,BB_SCREEN_H);
}
void format_uint(char *out, uint32_t value) {
    char reverse[10];
    unsigned n = 0;
    do { reverse[n++] = (char)('0' + value % 10u); value /= 10u; } while (value);
    for (unsigned i = 0; i < n; ++i) out[i] = reverse[n - i - 1u];
    out[n] = 0;
}
