from pathlib import Path
import subprocess,ctypes,random,json,hashlib,time,argparse,os,shlex,sys

def main():
    r=Path(__file__).resolve().parents[2];out=r/'build/font_equivalence';out.mkdir(parents=True,exist_ok=True)
    records=r/'results/font_equivalence';records.mkdir(parents=True,exist_ok=True)
    result_path=records/'test_result.json'
    result_path.write_text(json.dumps({'status':'IN_PROGRESS'}))
    ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));args=ap.parse_args()
    if os.name!='nt':
     result_path.write_text(json.dumps({'status':'NOT_RUN','reason':'guarded framebuffer harness requires Win32 VirtualAlloc'}));print('FONT_EQUIVALENCE=NOT_RUN Win32 VirtualAlloc required');raise SystemExit(0)
    cc=[x.strip('\"') for x in shlex.split(args.host_cc,posix=False)];libs=[]
    for name,source in [('ref',r/'tests/font_equivalence/font_reference_c285.c'),('candidate',r/'src/font.c')]:
     dll=out/(name+'.dll');p=subprocess.run(cc+['-std=gnu11','-O2','-Wall','-Wextra','-Wno-misleading-indentation','-shared','-I'+str(r/'src'),str(source),'-o',str(dll)],capture_output=True,text=True)
     (records/(name+'_compile.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
     lib=ctypes.CDLL(str(dll));fn=lib.draw_text_clipped;fn.argtypes=[ctypes.c_uint32,ctypes.c_int,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint32,ctypes.c_uint,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int];fn.restype=None
     lib.draw_text.argtypes=[ctypes.c_uint32,ctypes.c_uint,ctypes.c_uint,ctypes.c_char_p,ctypes.c_uint32,ctypes.c_uint];lib.draw_text.restype=None
     libs.append(lib)
    k=ctypes.WinDLL('kernel32',use_last_error=True);k.VirtualAlloc.restype=ctypes.c_void_p;k.VirtualAlloc.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32,ctypes.c_uint32]
    base=0x00ff0000;size=0x810000;assert k.VirtualAlloc(base,size,0x3000,4)==base
    fb0=0x01000000;fb1=0x01400000;slot=0x400000;prefix=b'\xa5'*0x10000
    rng=random.Random(20261029);alphabet=b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 -:./+=[]!?\n\x80\xff'
    cases=[]
    for scale in range(0,9):
     for x,y in [(0,0),(32,16),(1078,138),(1279,719),(1280,0),(0,720),(-8,0),(0,-8),(-8,-8),(1270,710),(2**31-1,0),(-2**31,0),(0,2**31-1),(0,-2**31)]:
      cases.append((x,y,b'ABCD\n0123\nX+/-[]',0x77aacc,scale,0,0,1280,720))
    for n in range(700):
     typ=n%5
     if typ==0:x,y=rng.randrange(0,1281),rng.randrange(0,721);scale=rng.randrange(1,5)
     elif typ==1:x,y=rng.randrange(0,1281),rng.randrange(0,721);scale=rng.randrange(5,9)
     elif typ==2:x,y=rng.randrange(-50,1330),rng.randrange(-50,770);scale=rng.randrange(1,9)
     elif typ==3:x,y=rng.choice([-2**31,-100000,2**31-1,100000]),rng.choice([-2**31,-100000,2**31-1,100000]);scale=rng.randrange(1,9)
     else:x,y=1078,rng.randrange(118,704);scale=rng.randrange(1,5)
     text=bytes(rng.choice(alphabet) for _ in range(rng.randrange(0,45)))
     if n%3==0:clip=(32,16,1056,704)
     elif n%3==1:clip=(0,0,1280,720)
     else:clip=tuple(rng.randrange(-100,1400) for _ in range(4))
     cases.append((x,y,text,rng.getrandbits(32),scale,*clip))
    # Narrow dirty regions on actual HUD-like long lines, glyph boundaries,
    # partially clipped scaled rows, and newlines after an offscreen prefix.
    for scale in range(1,5):
     for dy in range(-1,7*scale+2):
      for dx in [-1,0,1,4*scale,5*scale,6*scale,40*scale,100*scale]:
       cases.append((800,500,b'FPS 59.99 RENDER 12345 HP 100\nNEXT LINE 0123456789',0x12345678,scale,800+dx,500+dy,803+dx,502+dy))
    for scale in range(1,5):
     cases.append((1279,0,b'OFFSCREEN PREFIX\nVISIBLE NEXT LINE',0xffaa55,scale,8,9*scale,100,18*scale))
    start=time.perf_counter()
    for i,case in enumerate(cases):
     ctypes.memset(base,0xa5,size)
     libs[0].draw_text_clipped(fb0,*case);libs[1].draw_text_clipped(fb1,*case)
     a=ctypes.string_at(fb0,slot);b=ctypes.string_at(fb1,slot)
     if a!=b:raise AssertionError(('pixels',i,case,next(i for i,(x,y) in enumerate(zip(a,b)) if x!=y)))
     assert ctypes.string_at(base,0x10000)==prefix,('leading guard',i)
    # Invalid pointers/alignment and wrapper unsigned-coordinate semantics.
    for x in [0,1280,2**31-1,2**31,2**32-1]:
     for y in [0,720,2**31,2**32-1]:
      ctypes.memset(base,0xa5,size)
      for lib,fb in zip(libs,[fb0,fb1]):lib.draw_text(fb,x,y,b'X\nY',0x123456,2)
      assert ctypes.string_at(fb0,slot)==ctypes.string_at(fb1,slot)
    for text in [None,b'X']:
     for offset in [0,1,2,3]:
      ctypes.memset(base,0xa5,size)
      for lib,fb in zip(libs,[fb0,fb1]):lib.draw_text_clipped(fb+offset,0,0,text,0x123456,1,0,0,1280,720)
      assert ctypes.string_at(fb0,slot)==ctypes.string_at(fb1,slot)
      if offset or text is None:assert ctypes.string_at(fb0,slot)==b'\xa5'*slot
    result={'status':'PASS','clipped_cases':len(cases),'wrapper_cases':20,'null_alignment_cases':8,'compared_bytes_per_case':slot,'guard_prefix_bytes':65536,'scales':'0..8 (0 no-op)','scope':'Win32 mapped framebuffer; full 4MiB byte comparison includes 507904 trailing guard bytes per frame','seconds':time.perf_counter()-start,'source_sha256':hashlib.sha256((r/'src/font.c').read_bytes()).hexdigest(),'reference_sha256':hashlib.sha256((r/'tests/font_equivalence/font_reference_c285.c').read_bytes()).hexdigest()}
    result_path.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));print('FONT_EQUIVALENCE=PASS')

if __name__=="__main__":
    try:
        main()
    except Exception as exc:
        root=Path(__file__).resolve().parents[2]
        result=root/"results/font_equivalence/test_result.json"
        result.parent.mkdir(parents=True,exist_ok=True)
        result.write_text(json.dumps({"status":"FAIL","reason":repr(exc)},indent=2))
        raise
