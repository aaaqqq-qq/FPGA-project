#include "motion_abi.h"
#include <string.h>
#define SHOT_CAPACITY 20000
#define CONTACT_BUCKETS 8u
#define CONTACT_BUCKET_CAP 4096u
#define ARENA_W 1024
#define ARENA_H 688
#define Q 4096
typedef MotionShot Shot;
typedef MotionEffect Effect;
static struct {Shot shots[20000];uint8_t owner[20000];unsigned count;} stage;
static Effect effects[20000];
static struct {unsigned enemy_bullet_size,bullet_age_max;} game_cfg;
static unsigned battle_near_candidates,battle_near_fallbacks,battle_hit,battle_grazes,contact_count[8];
static MotionCompletionV1 diagnostic;
static unsigned game_bullet_radius(void){return game_cfg.enemy_bullet_size/2;}
static unsigned game_bullet_graze_radius(void){return game_bullet_radius()+9;}
static unsigned contact_bucket(int y){if(y<0)return 0;unsigned b=(unsigned)y*8/688;return b<8?b:7;}
static const int16_t sin_lut[1024]={0,201,402,603,804,1005,1206,1407,1608,1809,2009,2210,2410,2611,2811,3012,3212,3412,3612,3811,4011,4210,4410,4609,4808,5007,5205,5404,5602,5800,5998,6195,6393,6590,6786,6983,7179,7375,7571,7767,7962,8157,8351,8545,8739,8933,9126,9319,9512,9704,9896,10087,10278,10469,10659,10849,11039,11228,11417,11605,11793,11980,12167,12353,12539,12725,12910,13094,13279,13462,13645,13828,14010,14191,14372,14553,14732,14912,15090,15269,15446,15623,15800,15976,16151,16325,16499,16673,16846,17018,17189,17360,17530,17700,17869,18037,18204,18371,18537,18703,18868,19032,19195,19357,19519,19680,19841,20000,20159,20317,20475,20631,20787,20942,21096,21250,21403,21554,21705,21856,22005,22154,22301,22448,22594,22739,22884,23027,23170,23311,23452,23592,23731,23870,24007,24143,24279,24413,24547,24680,24811,24942,25072,25201,25329,25456,25582,25708,25832,25955,26077,26198,26319,26438,26556,26674,26790,26905,27019,27133,27245,27356,27466,27575,27683,27790,27896,28001,28105,28208,28310,28411,28510,28609,28706,28803,28898,28992,29085,29177,29268,29358,29447,29534,29621,29706,29791,29874,29956,30037,30117,30195,30273,30349,30424,30498,30571,30643,30714,30783,30852,30919,30985,31050,31113,31176,31237,31297,31356,31414,31470,31526,31580,31633,31685,31736,31785,31833,31880,31926,31971,32014,32057,32098,32137,32176,32213,32250,32285,32318,32351,32382,32412,32441,32469,32495,32521,32545,32567,32589,32609,32628,32646,32663,32678,32692,32705,32717,32728,32737,32745,32752,32757,32761,32765,32766,32767,32766,32765,32761,32757,32752,32745,32737,32728,32717,32705,32692,32678,32663,32646,32628,32609,32589,32567,32545,32521,32495,32469,32441,32412,32382,32351,32318,32285,32250,32213,32176,32137,32098,32057,32014,31971,31926,31880,31833,31785,31736,31685,31633,31580,31526,31470,31414,31356,31297,31237,31176,31113,31050,30985,30919,30852,30783,30714,30643,30571,30498,30424,30349,30273,30195,30117,30037,29956,29874,29791,29706,29621,29534,29447,29358,29268,29177,29085,28992,28898,28803,28706,28609,28510,28411,28310,28208,28105,28001,27896,27790,27683,27575,27466,27356,27245,27133,27019,26905,26790,26674,26556,26438,26319,26198,26077,25955,25832,25708,25582,25456,25329,25201,25072,24942,24811,24680,24547,24413,24279,24143,24007,23870,23731,23592,23452,23311,23170,23027,22884,22739,22594,22448,22301,22154,22005,21856,21705,21554,21403,21250,21096,20942,20787,20631,20475,20317,20159,20000,19841,19680,19519,19357,19195,19032,18868,18703,18537,18371,18204,18037,17869,17700,17530,17360,17189,17018,16846,16673,16499,16325,16151,15976,15800,15623,15446,15269,15090,14912,14732,14553,14372,14191,14010,13828,13645,13462,13279,13094,12910,12725,12539,12353,12167,11980,11793,11605,11417,11228,11039,10849,10659,10469,10278,10087,9896,9704,9512,9319,9126,8933,8739,8545,8351,8157,7962,7767,7571,7375,7179,6983,6786,6590,6393,6195,5998,5800,5602,5404,5205,5007,4808,4609,4410,4210,4011,3811,3612,3412,3212,3012,2811,2611,2410,2210,2009,1809,1608,1407,1206,1005,804,603,402,201,0,-201,-402,-603,-804,-1005,-1206,-1407,-1608,-1809,-2009,-2210,-2410,-2611,-2811,-3012,-3212,-3412,-3612,-3811,-4011,-4210,-4410,-4609,-4808,-5007,-5205,-5404,-5602,-5800,-5998,-6195,-6393,-6590,-6786,-6983,-7179,-7375,-7571,-7767,-7962,-8157,-8351,-8545,-8739,-8933,-9126,-9319,-9512,-9704,-9896,-10087,-10278,-10469,-10659,-10849,-11039,-11228,-11417,-11605,-11793,-11980,-12167,-12353,-12539,-12725,-12910,-13094,-13279,-13462,-13645,-13828,-14010,-14191,-14372,-14553,-14732,-14912,-15090,-15269,-15446,-15623,-15800,-15976,-16151,-16325,-16499,-16673,-16846,-17018,-17189,-17360,-17530,-17700,-17869,-18037,-18204,-18371,-18537,-18703,-18868,-19032,-19195,-19357,-19519,-19680,-19841,-20000,-20159,-20317,-20475,-20631,-20787,-20942,-21096,-21250,-21403,-21554,-21705,-21856,-22005,-22154,-22301,-22448,-22594,-22739,-22884,-23027,-23170,-23311,-23452,-23592,-23731,-23870,-24007,-24143,-24279,-24413,-24547,-24680,-24811,-24942,-25072,-25201,-25329,-25456,-25582,-25708,-25832,-25955,-26077,-26198,-26319,-26438,-26556,-26674,-26790,-26905,-27019,-27133,-27245,-27356,-27466,-27575,-27683,-27790,-27896,-28001,-28105,-28208,-28310,-28411,-28510,-28609,-28706,-28803,-28898,-28992,-29085,-29177,-29268,-29358,-29447,-29534,-29621,-29706,-29791,-29874,-29956,-30037,-30117,-30195,-30273,-30349,-30424,-30498,-30571,-30643,-30714,-30783,-30852,-30919,-30985,-31050,-31113,-31176,-31237,-31297,-31356,-31414,-31470,-31526,-31580,-31633,-31685,-31736,-31785,-31833,-31880,-31926,-31971,-32014,-32057,-32098,-32137,-32176,-32213,-32250,-32285,-32318,-32351,-32382,-32412,-32441,-32469,-32495,-32521,-32545,-32567,-32589,-32609,-32628,-32646,-32663,-32678,-32692,-32705,-32717,-32728,-32737,-32745,-32752,-32757,-32761,-32765,-32766,-32767,-32766,-32765,-32761,-32757,-32752,-32745,-32737,-32728,-32717,-32705,-32692,-32678,-32663,-32646,-32628,-32609,-32589,-32567,-32545,-32521,-32495,-32469,-32441,-32412,-32382,-32351,-32318,-32285,-32250,-32213,-32176,-32137,-32098,-32057,-32014,-31971,-31926,-31880,-31833,-31785,-31736,-31685,-31633,-31580,-31526,-31470,-31414,-31356,-31297,-31237,-31176,-31113,-31050,-30985,-30919,-30852,-30783,-30714,-30643,-30571,-30498,-30424,-30349,-30273,-30195,-30117,-30037,-29956,-29874,-29791,-29706,-29621,-29534,-29447,-29358,-29268,-29177,-29085,-28992,-28898,-28803,-28706,-28609,-28510,-28411,-28310,-28208,-28105,-28001,-27896,-27790,-27683,-27575,-27466,-27356,-27245,-27133,-27019,-26905,-26790,-26674,-26556,-26438,-26319,-26198,-26077,-25955,-25832,-25708,-25582,-25456,-25329,-25201,-25072,-24942,-24811,-24680,-24547,-24413,-24279,-24143,-24007,-23870,-23731,-23592,-23452,-23311,-23170,-23027,-22884,-22739,-22594,-22448,-22301,-22154,-22005,-21856,-21705,-21554,-21403,-21250,-21096,-20942,-20787,-20631,-20475,-20317,-20159,-20000,-19841,-19680,-19519,-19357,-19195,-19032,-18868,-18703,-18537,-18371,-18204,-18037,-17869,-17700,-17530,-17360,-17189,-17018,-16846,-16673,-16499,-16325,-16151,-15976,-15800,-15623,-15446,-15269,-15090,-14912,-14732,-14553,-14372,-14191,-14010,-13828,-13645,-13462,-13279,-13094,-12910,-12725,-12539,-12353,-12167,-11980,-11793,-11605,-11417,-11228,-11039,-10849,-10659,-10469,-10278,-10087,-9896,-9704,-9512,-9319,-9126,-8933,-8739,-8545,-8351,-8157,-7962,-7767,-7571,-7375,-7179,-6983,-6786,-6590,-6393,-6195,-5998,-5800,-5602,-5404,-5205,-5007,-4808,-4609,-4410,-4210,-4011,-3811,-3612,-3412,-3212,-3012,-2811,-2611,-2410,-2210,-2009,-1809,-1608,-1407,-1206,-1005,-804,-603,-402,-201};
static int turn_sin(int a){return sin_lut[((unsigned)a>>6)&1023];}
static int turn_cos(int a){return turn_sin(a+16384);}
static void simulate_bullets_relevant(int px, int py) {
    /* Only the one or two Y buckets queried by this player can affect contact.
       Keep their exact original ascending-index order and overflow threshold.
       All surviving bullets are positive-Y and 688/8 is exactly86 pixels. */
    enum { ROW_PIXELS=ARENA_H/CONTACT_BUCKETS };
    _Static_assert(ARENA_H%CONTACT_BUCKETS==0,"exact relevant bucket edges");
    unsigned lo=contact_bucket(py-(int)game_bullet_graze_radius()),hi=contact_bucket(py+(int)game_bullet_graze_radius());
    unsigned lower=lo*ROW_PIXELS*Q,span=(hi-lo+1)*ROW_PIXELS*Q;
    unsigned pair_counts=0,count=stage.count;
    _Static_assert(SHOT_CAPACITY<65536,"packed relevant bucket counts");
    battle_near_candidates=0;
    memset(contact_count,0,sizeof(contact_count));
    int radius=(int)game_bullet_radius();
    const unsigned age_max=game_cfg.bullet_age_max;
    _Static_assert(sizeof(Shot)==16 && __builtin_offsetof(Shot,vx)==8 && __builtin_offsetof(Shot,age)==12,"packed Shot read layout");
    _Static_assert(sizeof(Effect)==12 && __builtin_offsetof(Effect,target)==4 && __builtin_offsetof(Effect,turn)==8,"packed Effect read layout");
    _Static_assert(__BYTE_ORDER__==__ORDER_LITTLE_ENDIAN__,"packed fields require little endian");
    for (unsigned i = 0; i < count;) {
 ++diagnostic.processed;
        Shot *b = &stage.shots[i];
        Effect *e = &effects[i];
        int bx,by;uint32_t velocity,age_word,timing_word;
#ifdef __riscv
        /* Publish no writes before all inputs are loaded. The AXI bridge
           otherwise has to drain pending writes before a subsequent read. */
        __asm__ volatile(
            "lw %0,0(%5)\n\tlw %1,4(%5)\n\tlw %2,8(%5)\n\t"
            "lw %3,12(%5)\n\tlw %4,8(%6)"
            : "=&r"(bx),"=&r"(by),"=&r"(velocity),"=&r"(age_word),"=&r"(timing_word)
            : "r"(b),"r"(e) : "memory");
#else
        bx=b->x;by=b->y;memcpy(&velocity,&b->vx,4);memcpy(&age_word,&b->age,4);
        memcpy(&timing_word,&e->turn,4);
#endif
        int vx=(int16_t)velocity,vy=(int16_t)(velocity>>16);
        unsigned age=(uint16_t)age_word,turn=(uint16_t)timing_word,delay=timing_word>>16;
        if (age < delay) {
 ++diagnostic.delay_steps;
            vx = vx * 2 / 5; vy = vy * 2 / 5;
        } else if (turn) {
            unsigned t = age - delay;
            if (t >= turn) {
 ++diagnostic.turn_complete_steps;
                uint32_t target_word;memcpy(&target_word,&e->target,4);
                int target=(int16_t)target_word,speed=(int16_t)(target_word>>16);
                vx=(int16_t)((int32_t)turn_cos(target)*speed/32768);
                vy=(int16_t)((int32_t)turn_sin(target)*speed/32768);
                uint32_t changed=(uint16_t)vx|((uint32_t)(uint16_t)vy<<16);
                memcpy(&b->vx,&changed,4);e->turn=0;
            } else {
                ++diagnostic.turn_partial_steps;
                vx = vx * (int)(turn - t) / (int)turn;
                vy = vy * (int)(turn - t) / (int)turn;
            }
        }
        int x=bx+vx,y=by+vy;
        if(age<age_max)++age;
        age=(uint16_t)age; /* contact reads the stored uint16 age, including wrap. */
        if (x < radius * Q || x > (ARENA_W - radius) * Q ||
            y < radius * Q || y > (ARENA_H - radius) * Q) {
            /* Preserve the updated removed-tail age before copying, even
               when last==i. Tile/grazed bytes are unchanged on this path. */
            b->x=x;b->y=y;b->age=(uint16_t)age;
            ++diagnostic.removed;
            unsigned last = --count;stage.count=count;
            *b = stage.shots[last];
            *e = effects[last];
            stage.owner[i] = stage.owner[last];
            continue;
        }
        uint32_t updated=(age_word&0xffff0000u)|age;
        unsigned relative=(unsigned)y-lower;
        if(relative<span){
            /* Fused contact never consumes these index slots. Retain the
               exact bucket visit counts and overflow threshold, not stores. */
            if(lo!=hi&&relative>=ROW_PIXELS*Q)pair_counts+=65536u;else ++pair_counts;
            /* The motion inputs already contain all contact fields. Each
               surviving bullet has independent hit/graze side effects; keep
               exact candidate counts and overflow diagnostics below. */
            int graze=radius+9,dx=x/Q-px,dy=y/Q-py;
            if((unsigned)(dy+graze)<(unsigned)(graze*2+1)){
                if((unsigned)(dx+radius)<(unsigned)(radius*2+1)&&
                   (unsigned)(dy+radius)<(unsigned)(radius*2+1)&&age>=delay)battle_hit=1;
                if((unsigned)(dx+graze)<(unsigned)(graze*2+1)&&!(age_word&0xff000000u)){
                    updated|=0x01000000u;++battle_grazes;
                }
            }
        }
        /* One aligned word stores updated age plus the original tile and
           grazed byte (only a legal zero-to-one graze changes that byte). */
#ifdef __riscv
        /* Complete every input/spill read before this contiguous write group;
           the bridge must not drain for an inserted stack load between them. */
        __asm__ volatile("sw %1,0(%0)\n\tsw %2,4(%0)\n\tsw %3,12(%0)"
            : : "r"(b),"r"(x),"r"(y),"r"(updated) : "memory");
#else
        b->x=x;b->y=y;memcpy(&b->age,&updated,4);
#endif
        ++i;
    }
    /* No index scratch is consumed in this fused path. Counts, candidate
       totals and overflow diagnostics retain their original exact values. */
    unsigned nl=pair_counts&65535u,nh=pair_counts>>16;
    contact_count[lo]=nl;if(hi!=lo)contact_count[hi]=nh;
    {
        unsigned overflow=0;
        for(unsigned b=lo;b<=hi;++b)if(contact_count[b]>CONTACT_BUCKET_CAP)overflow=1;
        if(overflow){
            ++battle_near_fallbacks;
            /* The original fallback visits all survivors. Nonqueried Y
               buckets cannot hit/graze, but its visit count is observable. */
            battle_near_candidates=count;
        }else battle_near_candidates=nl+nh;
    }
}

#ifdef _WIN32
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif
static int interval(uint32_t a,uint32_t n){return a>=0x1000u&&(uint64_t)a+n<=0x00f00000u&&n;}
EXPORT int motion_validate_job(const MotionJobV1 *j,uint32_t job_address){
 if(!j||j->magic!=MOTION_MAGIC||j->abi!=1||!j->epoch||j->capacity!=20000||j->count>j->capacity||j->flags!=MOTION_SW3_INDEXLESS||j->size<8||j->size>56||(j->size&7)||j->player_x < -65536||j->player_x>65536||j->player_y < -65536||j->player_y>65536)return MOTION_BAD_JOB;
 for(unsigned i=0;i<15;++i)if(j->reserved[i])return MOTION_BAD_JOB;
 uint32_t a[]={job_address,j->shots,j->effects,j->owners,j->contact_index,j->contact_count,j->sincos_lut,j->result};
 const uint32_t n[]={128,320000,240000,20000,65536,32,4096,128};
 if((a[0]&15)||(a[1]&15)||(a[2]&3)||(a[4]&1)||(a[5]&3)||(a[6]&15)||(a[7]&15))return MOTION_BAD_JOB;
 for(unsigned i=0;i<8;++i){if(!interval(a[i],n[i]))return MOTION_BAD_JOB;for(unsigned k=0;k<i;++k)if((uint64_t)a[i]<(uint64_t)a[k]+n[k]&&(uint64_t)a[k]<(uint64_t)a[i]+n[i])return MOTION_BAD_JOB;}
 return MOTION_OK;
}
EXPORT int motion_validate_lut(const MotionSinCos *p){
 if(!p)return MOTION_BAD_LUT;
 for(unsigned i=0;i<1024;++i)if(p[i].sin!=sin_lut[i]||p[i].cos!=sin_lut[(i+256)&1023])return MOTION_BAD_LUT;
 return MOTION_OK;
}
EXPORT void motion_oracle_tick(void *ss,void *ee,uint8_t *oo,uint32_t n,uint32_t size,uint32_t age_max,int32_t px,int32_t py,uint32_t counts[8],MotionCompletionV1 *r){
 memcpy(stage.shots,ss,sizeof stage.shots);memcpy(effects,ee,sizeof effects);memcpy(stage.owner,oo,sizeof stage.owner);stage.count=n;
 game_cfg.enemy_bullet_size=size;game_cfg.bullet_age_max=age_max;battle_near_candidates=battle_near_fallbacks=battle_hit=battle_grazes=0;memset(&diagnostic,0,sizeof diagnostic);
 simulate_bullets_relevant(px,py);
 memcpy(ss,stage.shots,sizeof stage.shots);memcpy(ee,effects,sizeof effects);memcpy(oo,stage.owner,sizeof stage.owner);memcpy(counts,contact_count,sizeof contact_count);
 *r=diagnostic;r->magic=MOTION_MAGIC;r->abi=1;r->status=MOTION_OK;r->count=stage.count;r->hit=battle_hit;r->grazes=battle_grazes;r->candidates=battle_near_candidates;r->fallbacks=battle_near_fallbacks;r->flags=MOTION_SW3_INDEXLESS;
}
