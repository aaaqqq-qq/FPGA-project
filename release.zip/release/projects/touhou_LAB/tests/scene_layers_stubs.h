#ifndef SCENE_LAYERS_TEST_STUBS_H
#define SCENE_LAYERS_TEST_STUBS_H
/* Gameplay-only harnesses intentionally do not render pixels. Real scene
   pixel tests must link scene.c/render_queue.c instead of this header. */
unsigned scene_layer_commands,scene_layer_peak,scene_layer_clipped,scene_layer_reordered;
void scene_layers_begin(unsigned enabled){(void)enabled;}
void scene_layer(unsigned layer,int depth){(void)layer;(void)depth;}
void scene_layers_flush(void){}
void scene_layers_prepare(void){}
void scene_batch_shots(void);
void scene_batch_shots_deferred(void){scene_batch_shots();}
void scene_batch_resolve(void){}
void scene_clip(int x,int y,int w,int h){(void)x;(void)y;(void)w;(void)h;}
void scene_clip_reset(void){}
int scene_layer_order(const unsigned ranks[8]){(void)ranks;return 1;}
#endif
