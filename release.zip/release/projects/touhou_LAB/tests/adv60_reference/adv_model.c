#include "adv_model.h"
uint32_t adv_random(uint32_t *s){uint32_t x=*s?*s:1u;x^=x<<13;x^=x>>17;x^=x<<5;return *s=x;}
static int clamp(int v,int lo,int hi){return v<lo?lo:v>hi?hi:v;}
static unsigned root(unsigned v){unsigned r=0,b=1u<<30;while(b>v)b>>=2;while(b){if(v>=r+b){v-=r+b;r=(r>>1)+b;}else r>>=1;b>>=2;}return r;}
uint32_t adv_color(uint32_t a,uint32_t b,uint32_t c,unsigned mode,unsigned index){
 if(!mode)return a;if(mode==1)return index%3==0?a:index%3==1?b:c;
 unsigned t=index%16;uint32_t lo=t<8?a:b,hi=t<8?b:c;unsigned k=t<8?t:t-8,den=t<8?8:7;uint32_t out=0;
 for(unsigned s=0;s<24;s+=8)out|=((((lo>>s)&255)*(den-k)+((hi>>s)&255)*k+den/2)/den)<<s;return out;
}
unsigned adv_shape(unsigned shape,unsigned size,unsigned x,unsigned y){
 int dx=(int)(2*x+1)-(int)size,dy=(int)(2*y+1)-(int)size,a=dx<0?-dx:dx,b=dy<0?-dy:dy;unsigned rr=size*size;
 switch(shape){case 0:return (unsigned)(dx*dx+dy*dy)<=rr;case 1:return 1;case 2:return (unsigned)(a+b)<=size;
 case 3:return (unsigned)(dx*dx+dy*dy)<=rr&&(unsigned)(dx*dx+dy*dy)>=rr*9/25;
 case 4:return (unsigned)(a+b)<=size/2||(unsigned)(a*3+b)<=size*5/4||(unsigned)(a+b*3)<=size*5/4;
 default:return y*2+1>=size/4&&a<=(int)((y*size)/(size?size:1));}
}
uint32_t adv_golden(uint32_t s,uint32_t d,unsigned a,uint32_t key,unsigned flags){
 if((flags&2)&&(s&0xffffffu)==(key&0xffffffu))return d;if(!(flags&1)||a==255)return s;if(!a)return d;
 uint32_t out=0;for(unsigned k=0;k<24;k+=8){uint64_t v=((s>>k)&255u)*(uint64_t)a+((d>>k)&255u)*(uint64_t)(255-a)+127;out|=(uint32_t)(v/255)<<k;}return out;
}
void adv_particles_init(AdvParticle *p,unsigned n,unsigned size,unsigned colors,uint32_t seed){
 for(unsigned i=0;i<n;++i){AdvParticle *q=&p[i];q->x=(int32_t)(size/2+adv_random(&seed)%(ADV_W-size))<<8;q->y=(int32_t)(size/2+adv_random(&seed)%(ADV_H-size))<<8;
 q->vx=(int16_t)((int)(adv_random(&seed)%769)-384);q->vy=(int16_t)((int)(adv_random(&seed)%769)-384);if(!q->vx)q->vx=128;if(!q->vy)q->vy=-128;
 q->mass=1;q->size=(uint8_t)size;q->color=(uint8_t)(i%colors);q->alive=1;q->pad=0;}
}
/* Grid broad phase has no capacity truncation: each of <=512 particles has
   exactly one linked node. Contacts use circular envelopes for every sprite.
   A deterministic single contact pass is used (not a rigid-body solver).
   Forces have a documented 128px cutoff, not an omitted neighbour budget. */
void adv_particles_step(AdvParticle *p,unsigned n,unsigned mode,AdvStats *st){
 for(unsigned i=0;i<n;++i)if(p[i].alive){AdvParticle *q=&p[i];
  if(mode==5){int dx=(ADV_W/2)-(q->x>>8),dy=(ADV_H/2)-(q->y>>8),d=dx*dx+dy*dy+512;
   q->vx=(int16_t)clamp(q->vx+(-dy*2048+dx*256)/d,-1024,1024);q->vy=(int16_t)clamp(q->vy+(dx*2048+dy*256)/d,-1024,1024);}
  q->x+=q->vx;q->y+=q->vy;int r=(q->size+1)/2;
  int lx=r<<8,hx=(ADV_W-r-1)<<8,ly=r<<8,hy=(ADV_H-r-1)<<8;
  if(q->x<lx){q->x=lx;q->vx=(int16_t)(q->vx<0?-q->vx:q->vx);}if(q->x>hx){q->x=hx;q->vx=(int16_t)(q->vx>0?-q->vx:q->vx);}
  if(q->y<ly){q->y=ly;q->vy=(int16_t)(q->vy<0?-q->vy:q->vy);}if(q->y>hy){q->y=hy;q->vy=(int16_t)(q->vy>0?-q->vy:q->vy);}}
 if(!mode||mode==5)return;
 /* Fusion changes centers and radii during the pass. An explicit all-pairs
    fallback therefore preserves exact i,j ordering without stale-grid misses.
    Its documented upper bound is 512 particles, never a truncated candidate set. */
 if(mode==2){
  for(unsigned i=0;i<n;++i)if(p[i].alive)for(unsigned j=i+1;j<n;++j)if(p[j].alive){
   AdvParticle *a=&p[i],*b=&p[j];++st->pairs;int dx=(b->x-a->x)>>8,dy=(b->y-a->y)>>8,r=(a->size+b->size+1)/2;
   if(dx*dx+dy*dy>r*r)continue;++st->collisions;
   unsigned mass=a->mass+b->mass;
   a->x=(int32_t)(((int64_t)a->x*a->mass+(int64_t)b->x*b->mass)/mass);a->y=(int32_t)(((int64_t)a->y*a->mass+(int64_t)b->y*b->mass)/mass);
   a->vx=(int16_t)((a->vx*a->mass+b->vx*b->mass)/(int)mass);a->vy=(int16_t)((a->vy*a->mass+b->vy*b->mass)/(int)mass);
   unsigned area=a->size*a->size+b->size*b->size,s=root(area);if(s*s<area)++s;a->size=(uint8_t)(s>64?64:s);a->mass=(uint16_t)mass;
   int radius=(a->size+1)/2;a->x=clamp(a->x,radius<<8,(ADV_W-radius-1)<<8);a->y=clamp(a->y,radius<<8,(ADV_H-radius-1)<<8);
   b->alive=0;--st->count;++st->merges;
  }
  if(st->count<st->minimum)st->minimum=st->count;if(st->count>st->maximum)st->maximum=st->count;return;
 }
 if(n>ADV_PHYS_MAX)return; /* Defensive API guard; command parser rejects it. */
 int16_t heads[128],next[ADV_PHYS_MAX];for(unsigned i=0;i<128;++i)heads[i]=-1;
 for(unsigned i=0;i<n;++i){next[i]=-1;if(p[i].alive){unsigned cell=((unsigned)(p[i].y>>8)/64)*16+(unsigned)(p[i].x>>8)/64;next[i]=heads[cell];heads[cell]=(int16_t)i;}}
 for(unsigned i=0;i<n;++i)if(p[i].alive){int cx=(p[i].x>>8)/64,cy=(p[i].y>>8)/64;int reach=(mode==3||mode==4)?2:1;
  for(int by=cy-reach;by<=cy+reach;++by)for(int bx=cx-reach;bx<=cx+reach;++bx){if(bx<0||bx>=16||by<0||by>=8)continue;
   for(int j=heads[by*16+bx];j>=0;j=next[j]){if((unsigned)j<=i||!p[j].alive)continue;AdvParticle *a=&p[i],*b=&p[j];++st->pairs;
    int dx=(b->x-a->x)>>8,dy=(b->y-a->y)>>8,d2=dx*dx+dy*dy,r=(a->size+b->size+1)/2;
    if(mode==3||mode==4){if(d2<=128*128){int sign=mode==3?1:-1;int ax=clamp(dx*2048/(d2+64),-48,48)*sign,ay=clamp(dy*2048/(d2+64),-48,48)*sign;
     a->vx=(int16_t)clamp(a->vx+ax,-1024,1024);a->vy=(int16_t)clamp(a->vy+ay,-1024,1024);b->vx=(int16_t)clamp(b->vx-ax,-1024,1024);b->vy=(int16_t)clamp(b->vy-ay,-1024,1024);}continue;}
    if(d2>r*r)continue;++st->collisions;
    if(!d2){dx=1;dy=0;d2=1;}int rv=(b->vx-a->vx)*dx+(b->vy-a->vy)*dy;
    if(rv<0){int ix=dx*rv/d2,iy=dy*rv/d2;a->vx=(int16_t)clamp(a->vx+ix,-1024,1024);a->vy=(int16_t)clamp(a->vy+iy,-1024,1024);b->vx=(int16_t)clamp(b->vx-ix,-1024,1024);b->vy=(int16_t)clamp(b->vy-iy,-1024,1024);}
   }
  }
 }
 if(st->count<st->minimum)st->minimum=st->count;if(st->count>st->maximum)st->maximum=st->count;
}
