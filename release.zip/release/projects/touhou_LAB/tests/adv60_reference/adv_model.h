#ifndef ADV_MODEL_H
#define ADV_MODEL_H
#include <stdint.h>
#define ADV_MAX 20000u
#define ADV_PHYS_MAX 512u
#define ADV_W 1024u
#define ADV_H 512u
typedef struct {int32_t x,y;int16_t vx,vy;uint16_t mass;uint8_t size,color,alive,pad;} AdvParticle;
typedef struct {uint64_t pairs,collisions,merges;unsigned count,minimum,maximum;} AdvStats;
uint32_t adv_random(uint32_t *seed);
uint32_t adv_color(uint32_t a,uint32_t b,uint32_t c,unsigned mode,unsigned index);
unsigned adv_shape(unsigned shape,unsigned size,unsigned x,unsigned y);
uint32_t adv_golden(uint32_t s,uint32_t d,unsigned alpha,uint32_t key,unsigned flags);
void adv_particles_init(AdvParticle *p,unsigned n,unsigned size,unsigned colors,uint32_t seed);
void adv_particles_step(AdvParticle *p,unsigned n,unsigned physics,AdvStats *stats);
#endif
