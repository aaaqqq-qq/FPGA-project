
static unsigned checks;
#define CK(x) do{++checks;if(!(x)){printf("GAME_LOAD FAIL line=%u %s\n",__LINE__,#x);return 1;}}while(0)
static char output[8192];
static FILE *protocol_sample;
static void drain(void){while(command_reply_count){txlen=txpos=0;service_command_output();if(strlen(output)+strlen(tx)+1<sizeof output)strcat(output,tx);if(protocol_sample)fputs(tx,protocol_sample);txpos=txlen;}txpos=txlen=0;}
static void line(const char *s){while(*s)uart_character(*s++);}
static void setup(void){
 game_load_running=game_load_cancel=validate_requested=validation_active=0;battle_load_end();game_config_defaults();replay_reset();mode=MENU;choice=0;custom_limit=512;autoplay=demo_invincible=0;host_bullet_prepare_fail=host_bullet_guard_fail=0;
 host_ticks=host_scan=host_swap=host_uf=0;command_reply_head=command_reply_count=command_reply_overruns=0;txpos=txlen=0;command_len=command_overflow=0;output[0]=0;
}
static void ready(void){render_warmup_advance();render_warmup_advance();game_load_ready(bb_ticks());drain();}
static void frame(unsigned n,unsigned b,unsigned m,unsigned gap){
 ++host_swap;host_scan+=gap;host_ticks=gl.start+(uint64_t)(gl.frames+1)*1000000/60;
 logic_us=1000;render_us=2000;frame_us=3000;game_load_after_swap(n,b,m);drain();
}
static int protocol(void){
 setup();line(":hello\n");drain();CK(strstr(output,"game_load=1"));output[0]=0;
 const char *bad[]={":gload run 1 0 0 100 8 60 1\n",":gload run 1 7 0 100 8 60 1\n",":gload run 1 1 13 100 8 60 1\n",":gload run 1 1 0 0 8 60 1\n",":gload run 1 1 0 100 9 60 1\n",":gload run 1 1 0 100 64 60 1\n",":gload run 1 1 0 100 8 59 1\n",":gload run 1 1 0 100 8 60 0\n",":gload run 1 1 0 100 8 60 4294967296\n",":gload run 1 1 0 100 8 60 1 0\n"};
 GameConfig save=game_cfg;
 for(unsigned i=0;i<sizeof bad/sizeof bad[0];++i){line(bad[i]);drain();CK(strstr(output,"status=ERR")&&!game_load_running&&!memcmp(&save,&game_cfg,sizeof save));output[0]=0;}
 host_adv_active=1;line(":gload status 4\n");drain();CK(strstr(output,"id=4 op=status status=OK running=0 current=0"));output[0]=0;
 line(":gload run 7 6 12 5000 56 60 1\n");drain();CK(strstr(output,"reason=busy"));host_adv_active=0;output[0]=0;
 game_cfg.main_fire_period=17;custom_limit=400;choice=1;autoplay=0;demo_invincible=1;save=game_cfg;
 line(":gload run 7 6 12 5000 56 60 1234\n");drain();CK(game_load_running&&strstr(output,"status=OK kind=GAME_LOAD b=6 m=12 n=5000 size=56 frames=60 seed=1234"));
 CK(stage.count==5000&&stage.limit==5000&&game_cfg.enemy_bullet_size==56&&!demo_invincible&&autoplay&&enemies_fighting_count()==12);
 output[0]=0;line(":adv status 99\n:set boss_count 1\n:limit 10\n");drain();CK(game_cfg.boss_count==6&&stage.limit==5000&&!host_adv_active&&strstr(output,"GAME_LOAD active"));
 output[0]=0;line(":gload cancel 8\n");drain();CK(!game_load_cancel&&strstr(output,"reason=id"));
 output[0]=0;line(":gload cancel 7\n");drain();CK(game_load_running&&game_load_cancel);game_load_poll_cancel();drain();
 CK(!game_load_running&&!battle_load_active&&mode==MENU&&strstr(output,"status=CANCEL reason=cancel"));
 CK(!memcmp(&save,&game_cfg,sizeof save)&&custom_limit==400&&choice==1&&!autoplay&&demo_invincible==1&&host_bullet_size==save.enemy_bullet_size);
 setup();line(":limit 123\n:mode 0\n");drain();CK(stage.limit==123);line(":limit 42\n");drain();CK(stage.limit==123&&strstr(output,"limit requires menu"));
 setup();host_bullet_prepare_fail=1;line(":gload run 1 1 0 100 8 60 1\n");drain();CK(!game_load_running&&strstr(output,"reason=prepare"));
 setup();game_cfg.background_depth_enabled=0;scene_init();unsigned bg_calls=host_background_prepares;
 line(":gload run 88 1 0 100 16 60 1\n");drain();CK(host_scene_background==1&&host_background_prepares==bg_calls+1);game_load_finish("CANCEL","cancel");drain();CK(host_scene_background==0&&host_background_prepares==bg_calls+2&&game_cfg.background_depth_enabled==0);
 setup();replay_play_begin(123);CK(replay_state()==REPLAY_ERROR);line(":gload run 1 1 0 100 8 60 1\n");drain();CK(!game_load_running&&strstr(output,"reason=replay_error")&&replay_state()==REPLAY_ERROR);
 setup();line(":validate 1\n:gload run 1 1 0 100 8 60 1\n");drain();CK(!game_load_running&&strstr(output,"reason=validation")&&validate_requested==1);
 puts("GAME_LOAD protocol PASS atomicbadinput/ownership/menu/IDcancel/restoresettings/normalPLAYlimit");return 0;
}
static int matrix(void){
 unsigned runs=0;
 for(unsigned b=1;b<=6;++b)for(unsigned m=0;m<=12;m+=6)for(unsigned size=8;size<=56;size+=8){
  setup();if(b==6&&m==12&&size==8){protocol_sample=fopen("results/validation/game_load_native_protocol.log","wb");CK(protocol_sample);fputs("# Native production C protocol; mocked timer/display; not physical FPS.\n",protocol_sample);}
  char cmd[128];sprintf(cmd,":gload run 123 %u %u 5000 %u 60 123456789\n",b,m,size);line(cmd);drain();CK(game_load_running);ready();CK(gl.ready&&strstr(output,"GLOAD_READY"));output[0]=0;
  for(unsigned f=0;f<60;++f){runtime_step();CK(stage.count==5000&&visible_boss_count()==b&&enemies_fighting_count()==m&&!stage.fault);frame(stage.count,visible_boss_count(),enemies_fighting_count(),1);}
  CK(!game_load_running&&strstr(output,"GLOAD_DONE id=123 status=PASS reason=complete"));CK(strstr(output,"nmin=5000 nmax=5000"));CK(!command_reply_overruns);
  if(protocol_sample){fclose(protocol_sample);protocol_sample=0;}
  ++runs;
 }
 printf("GAME_LOAD matrix PASS %u cases x60 real game ticks,5000 maintained, synthetic MMIO timing only\n",runs);return 0;
}
static int reject_faults(void){
 const char *reasons[]={"timing","timing","load","guards","timing"};
 for(unsigned k=0;k<5;++k){setup();line(":gload run 19 2 6 200 8 60 9\n");drain();ready();output[0]=0;
  for(unsigned f=0;f<60;++f){runtime_step();if(f==10&&k==1)++host_uf;if(f==10&&k==3)host_bullet_guard_fail=1;if(f==10&&k==4)++logic_drops;frame((f==10&&k==2)?199:200,2,6,(f==10&&k==0)?2:1);}
  CK(strstr(output,"status=FAIL")&&strstr(output,reasons[k]));
 }
 setup();line(":gload run 20 6 12 5000 56 600 5\n");drain();ready();
 player.spawn_invuln=player.hit_invuln=player.bomb_invuln=player.upgrade_invuln=0;player.hp=1;
 CK(player_take_hit(15)==15&&player.hp==85&&player_alive()&&battle_load_player_hits==1&&battle_load_player_damage==15&&battle_load_keeps==1);
 bosses[5].hp=1;CK(battle_apply_damage(5,5,1)==5&&bosses[5].hp==2995&&battle_load_boss_hits==1);
 ordinary_enemies[0].hp=1;CK(enemies_apply_damage(0,5)==5&&ordinary_enemies[0].hp==15&&battle_load_mob_hits==1);
 for(unsigned f=0;f<600;++f){runtime_step();frame(stage.count,visible_boss_count(),enemies_fighting_count(),1);}
 CK(strstr(output,"status=PASS")&&gl.frames==600&&battle_load_recycles>0&&battle_load_fills>5000&&battle_load_keeps>3);
 puts("GAME_LOAD failureinjection PASS gap/UF/load/guards/logicdrop; realHPdamage,AIemission,recycle,sustainedmob tests");return 0;
}

static int sizes_and_repro(void){
 for(unsigned size=8;size<=56;size+=8)for(unsigned optimized=0;optimized<=1;++optimized){
  setup();game_cfg.enemy_bullet_size=size;game_cfg.battle_gather_enabled=optimized;
  for(unsigned py=64;py<650;py+=17){
   unsigned radius=size/2,graze=radius+9;
   for(unsigned distance=radius;distance<=graze+1;++distance){
    battle_reset(0,10);for(unsigned k=0;k<6;++k)bosses[k].state=BOSS_WAIT;
    CK(battle_spawn_enemy_bullet(128,512+distance,py,0,0,54));
    battle_step(512,(int)py);CK(battle_hit==(distance<=radius)&&battle_grazes==(distance<=graze));
   }
  }
  for(unsigned edge=0;edge<2;++edge){
   battle_reset(0,10);for(unsigned k=0;k<6;++k)bosses[k].state=BOSS_WAIT;
   CK(battle_spawn_enemy_bullet(128,size/2-edge,100,0,0,54));battle_step(512,620);CK(stage.count==(edge?0u:1u));
  }
 }
 uint32_t checksum[2];
 for(unsigned run=0;run<2;++run){setup();line(":gload run 31 6 12 5000 56 600 123456789\n");drain();ready();
  for(unsigned f=0;f<300;++f){runtime_step();frame(stage.count,visible_boss_count(),enemies_fighting_count(),1);}
  checksum[run]=runtime_state_hash();game_load_finish("CANCEL","cancel");drain();
 }
 CK(checksum[0]==checksum[1]);
 setup();line(":gload run 44 1 0 200 8 60 123\n");drain();ready();output[0]=0;
 host_ticks=gl.start+gl.deadline;host_scan=1200;host_swap=1;game_load_after_swap(200,1,0);drain();CK(!game_load_running&&strstr(output,"status=FAIL reason=timeout")&&gl.frames==1);
 setup();line(":gload run 45 1 0 200 8 60 123\n");drain();ready();output[0]=0;
 for(unsigned f=0;f<60;++f)frame(200,1,0,1);CK(strstr(output,"status=FAIL reason=timing")&&!gl.logic_ticks);
 setup();line(":gload run 46 1 0 200 8 60 123\n");drain();ready();output[0]=0;mode=STRESS;frame(200,1,0,1);CK(strstr(output,"status=FAIL reason=state"));
 setup();line(":gload run 47 1 0 200 8 60 123\n");drain();ready();output[0]=0;
 for(unsigned f=0;f<60;++f){runtime_step();last_fx_quality=f<30?0:1;last_fx_lod=2;last_decor_dropped=3;effects_drop_total=gl.fxdrop_start+f+1;frame(stage.count,visible_boss_count(),enemies_fighting_count(),1);}
 CK(gl.qmin==0&&gl.qmax==1&&gl.lodsum==120&&gl.ddrop==180&&strstr(output,"fxdrop=60 ddrop=180"));
 puts("GAME_LOAD sizes PASS independent radius/graze/near+clip oracle all7sizes; deterministic300ticks and partialtimeout");return 0;
}
static int payload(void){
 setup();memset(&gl,255,sizeof gl);logic_drops=logic_overruns=~0u;battle_load_fills=battle_load_recycles=battle_load_keeps=~0u;
 battle_load_player_hits=battle_load_player_damage=battle_load_boss_hits=battle_load_mob_hits=~0u;
 gl.start_fill=gl.start_recycle=gl.start_keep=gl.start_hits=gl.start_damage=gl.start_bhits=gl.start_mhits=0;
 mode=hardware=battle_load_active=paused=~0u;
 effects_quality=effects_lod_jobs=effects_drop_total=stage.fault=runtime_tick=~0u;
 game_load_stat();CK(command_reply_count==2);
 for(unsigned k=0;k<2;++k){const char *s=command_replies[(command_reply_head+k)%COMMAND_REPLY_CAP];unsigned n=strlen(s);CK(n<COMMAND_REPLY_BYTES&&s[n-2]=='\r'&&s[n-1]=='\n');printf("GAME_LOAD payload %u bytes\n",n);}
 CK(strstr(command_replies[(command_reply_head+1)%COMMAND_REPLY_CAP],"collision=scaled pipe=4294967295 hud_dma=0\r\n"));return 0;
}
int main(void){if(protocol()||matrix()||reject_faults()||sizes_and_repro()||payload())return 1;printf("GAME_LOAD PASS checks=%u; hostonly not physical FPS\n",checks);return 0;}
