#include "scene.h"
#include "art_data.h"
#include "bitblt.h"
#include "font.h"
#include "stage.h"
#include "background.h"
#include "game_config.h"
#include "render_queue.h"
#include <string.h>
#define BACKGROUND 0x01A00000u
int scene_art_info(unsigned tile,uint32_t *address,unsigned *width,unsigned *height){
    if(tile>=sizeof(tiles)/sizeof(tiles[0]))return 0;
    *address=ART_BASE+tiles[tile].off;*width=tiles[tile].w;*height=tiles[tile].h;return 1;
}
#ifdef BB_HOST_TEST
#define SCENE_FENCE() do{}while(0)
#else
#define SCENE_FENCE() __asm__ volatile("fence iorw,iorw" ::: "memory")
#endif
static uint32_t framebuffer;
static unsigned hardware,batch_mode,cancelled;
unsigned scene_cancelled(void){return cancelled;}
unsigned scene_jobs,scene_list_us,scene_batch_cycles,scene_sprite_count;
static bb_job previous;
static unsigned cache_valid, pending_job, initialized_frames;
static unsigned batch_count;
static unsigned layer_capture,layers_started,current_layer;
static int current_depth;
static int clip_left=32,clip_top=16,clip_right=1056,clip_bottom=704;
unsigned scene_layer_commands,scene_layer_peak,scene_layer_clipped,scene_layer_reordered;
static void layer_sink(const RqCommand *c,const char *text,void *context);
static int text_bounds(const RqCommand *c,const char *text,int *ox,int *oy,int *ow,int *oh);
static void layer_metrics(void){scene_layer_commands=rq_total;scene_layer_peak=rq_peak;scene_layer_reordered=rq_reordered;}
void scene_clip_reset(void){clip_left=32;clip_top=16;clip_right=1056;clip_bottom=704;}
void scene_clip(int x,int y,int w,int h){
    int64_t r=(int64_t)x+w,b=(int64_t)y+h;
    int64_t l=x,t=y;if(l<32)l=32;if(t<16)t=16;if(r>1056)r=1056;if(b>704)b=704;
    if(w<=0||h<=0||r<=l||b<=t){clip_left=clip_right=32;clip_top=clip_bottom=16;return;}
    clip_left=(int)l;clip_top=(int)t;clip_right=(int)r;clip_bottom=(int)b;
}
int scene_layer_order(const unsigned ranks[SCENE_LAYER_COUNT]){return rq_set_order(ranks);}
void scene_layers_flush(void){rq_flush(layer_sink,0);layer_metrics();}
void scene_layers_begin(unsigned enabled){
    if(rq_count())scene_layers_flush();
    rq_reset();scene_layer_commands=scene_layer_peak=scene_layer_clipped=scene_layer_reordered=0;
    layer_capture=!!enabled;layers_started=1;current_layer=SCENE_LAYER_ACTOR;current_depth=0;scene_clip_reset();
}
void scene_layer(unsigned layer,int depth){if(layer>=SCENE_LAYER_COUNT)fatal("LAYER ID",(int)layer);current_layer=layer;current_depth=depth;}
static int clipped_bounds(int x,int y,int w,int h,int l,int t,int r,int b,
                          int *ox,int *oy,int *ow,int *oh){
    int64_t x0=x,y0=y,x1=(int64_t)x+w,y1=(int64_t)y+h;
    if(w<=0||h<=0||l>=r||t>=b)return 0;
    if(x0<l)x0=l;if(y0<t)y0=t;if(x1>r)x1=r;if(y1>b)y1=b;
    if(x0>=x1||y0>=y1)return 0;
    *ox=(int)x0;*oy=(int)y0;*ow=(int)(x1-x0);*oh=(int)(y1-y0);return 1;
}
static void layer_submit(RqCommand *c,const char *text){
    c->layer=(uint8_t)current_layer;c->depth=current_depth;
    c->left=(int16_t)clip_left;c->top=(int16_t)clip_top;c->right=(int16_t)clip_right;c->bottom=(int16_t)clip_bottom;
    if(c->kind!=RQ_TEXT){
        int x,y,w,h;
        if(!clipped_bounds(c->x,c->y,c->w,c->h,clip_left,clip_top,clip_right,clip_bottom,&x,&y,&w,&h)){++scene_layer_clipped;return;}
        if(x!=c->x||y!=c->y||w!=c->w||h!=c->h)++scene_layer_clipped;
    }else{
        int x,y,w,h;
        if(!text_bounds(c,text,&x,&y,&w,&h)){++scene_layer_clipped;return;}
        if(c->x<clip_left||c->y<clip_top||clip_left!=32||clip_top!=16||clip_right!=1056||clip_bottom!=704)++scene_layer_clipped;
    }
    int result=rq_push(c,text);if(result!=RQ_OK)fatal("LAYER QUEUE",result);layer_metrics();
}
/* A bounded command cache for the right HUD. Cache equality is exact bytewise,
   per framebuffer and per 8-pixel strip; no hash can hide a changed value. */
#define HUD_LEFT 1072
#define HUD_TOP 118
#define HUD_BOTTOM 704
#define HUD_ROWS ((HUD_BOTTOM-HUD_TOP+7)/8)
#define HUD_COMMAND_CAP 96
#define HUD_TEXT_CAP 96
typedef struct {
    int x,y,w,h;
    uint32_t color;
    unsigned scale,kind;
    char text[HUD_TEXT_CAP];
} HudCommand;
static HudCommand hud_current[HUD_COMMAND_CAP],hud_saved[2][HUD_COMMAND_CAP];
static unsigned hud_count,hud_saved_count[2],hud_valid[2],hud_capture,hud_used;
static unsigned hud_cache_enabled=1;
unsigned scene_hud_restored_rows,scene_hud_redraw_jobs;
static void hud_record(unsigned kind,int x,int y,int w,int h,uint32_t color,unsigned scale,const char *text){
    if(hud_count>=HUD_COMMAND_CAP)fatal("HUD COMMAND CAP",hud_count);
    HudCommand *c=&hud_current[hud_count++];memset(c,0,sizeof(*c));
    c->kind=kind;c->x=x;c->y=y;c->w=w;c->h=h;c->color=color;c->scale=scale;
    if(text){size_t n=strlen(text);if(n>=HUD_TEXT_CAP)fatal("HUD TEXT CAP",(int)n);memcpy(c->text,text,n+1);}
}
void scene_hud_invalidate(void){hud_valid[0]=hud_valid[1]=0;}
void scene_hud_cache_enable(unsigned enabled){enabled=!!enabled;if(hud_cache_enabled!=enabled){hud_cache_enabled=enabled;scene_hud_invalidate();}}
void scene_hud_begin(void){scene_layers_flush();layer_capture=0;hud_capture=1;hud_used=1;hud_count=0;scene_hud_restored_rows=scene_hud_redraw_jobs=0;}

/* Per-buffer damage history in a reserved DDR area beyond both frames, art
   and background. Keep exact rectangles, so 8x8 sprites restore only 64 pixels.
   Store history for the buffer being reused (two frames old), not front buffer. */
typedef struct {uint16_t x,y,w,h;} Damage;
#define DAMAGE_CAP (SHOT_CAPACITY+128)
#define DAMAGE ((volatile Damage *)(uintptr_t)0x01E00000u)
static unsigned damage_count[2],damage_bank;
static void mark_damage(int x,int y,int w,int h){
    if(batch_mode)return;
    if(x<32){w-=32-x;x=32;}if(y<16){h-=16-y;y=16;}
    if(x+w>1056)w=1056-x;if(y+h>704)h=704-y;
    if(w<=0||h<=0)return;
    unsigned n=damage_count[damage_bank];if(n>=DAMAGE_CAP)fatal("DAMAGE CAPACITY",n);
    volatile Damage *d=&DAMAGE[damage_bank*DAMAGE_CAP+n];
    d->x=x;d->y=y;d->w=w;d->h=h;damage_count[damage_bank]=n+1;
}

/* Private hot-path MMIO; generic validated public driver remains available. */
#ifdef BB_HOST_TEST
static inline uint32_t scene_read(unsigned reg){return bb_read(reg);}
static inline void scene_write(unsigned reg,uint32_t value){bb_write(reg,value);}
#else
static inline uint32_t scene_read(unsigned reg){return *(volatile uint32_t *)(uintptr_t)(BB_BASE+reg);}
static inline void scene_write(unsigned reg,uint32_t value){*(volatile uint32_t *)(uintptr_t)(BB_BASE+reg)=value;}
#endif
/* Keep one hardware operation in flight while preparing the next sprite.
   Wait before changing its registers, touching pixels on CPU, or swapping. */
static void finish_job(void){
    if(!pending_job)return;
    unsigned polls=0;uint64_t start=0;
    for(;;){uint32_t s=scene_read(BB_STATUS);if(s&BB_ERROR)fatal("ENGINE",s);if((s&(BB_BUSY|BB_DONE))==BB_DONE)break;
        if((++polls&1023)==0){if(!start)start=bb_ticks();else if(bb_us(bb_ticks()-start)>100000)fatal("ENGINE TIMEOUT",s);}}
    if(previous.op==2)scene_batch_cycles=scene_read(BB_CYCLES);
    SCENE_FENCE();pending_job=0;
}
/* Descriptors are snapshotted before any background reads. Once that DMA
   completes, the CPU can calculate the next frame without changing this one. */
void scene_batch_snapshot_ready(void){
    if(!pending_job || previous.op!=2)return;
    SCENE_FENCE();
    unsigned accepted=0;uint64_t accepted_at=0,start=bb_ticks();
    for(;;){
        unsigned status=scene_read(BB_STATUS);
        if(status&BB_ERROR)fatal("SNAPSHOT ENGINE",status);
        if((status&BB_BUSY)&&!accepted){accepted=1;accepted_at=bb_ticks();}
        if((status&(BB_BUSY|BB_DONE))==BB_DONE)break;
        /* APB CMD accepted at T0; batch mux/counters reset unconditionally
           at T0+1 on this same 100MHz clock. Anchor the extra guard to the
           first new BUSY, not to helper entry or a short texture DMA window. */
        if(accepted&&bb_us(bb_ticks()-accepted_at)>=1&&
           scene_read(BB_READ_BYTES)>=4096+batch_count*16)break;
        if(bb_us(bb_ticks()-start)>100000)fatal("SNAPSHOT TIMEOUT",status);
    }
    SCENE_FENCE();
}
static void engine(const bb_job *j){
    finish_job();
    /* Immutable art, clipped destinations. Publish CPU writes at frame end. */
    const unsigned regs[]={BB_OP,BB_SRC,BB_DST,BB_SRC_STRIDE,BB_DST_STRIDE,BB_WIDTH,BB_HEIGHT,BB_FILL,BB_ALPHA,BB_KEY_REG,BB_FLAGS};
    const uint32_t *p=(const uint32_t *)j;uint32_t *old=(uint32_t *)&previous;
    /* Accepted CMD clears sticky DONE/ERROR in game_apb.sv. */
    for(unsigned i=0;i<11;++i)if(!cache_valid||old[i]!=p[i]){scene_write(regs[i],p[i]);old[i]=p[i];}
    cache_valid=1;SCENE_FENCE();scene_write(BB_CMD,1);pending_job=1;
}
static void execute(const bb_job *j){
    if(cancelled)return;
    ++scene_jobs;
    if(hardware)engine(j);else {bb_result r=bb_cpu_execute(j);if(r==BB_E_CANCELLED)cancelled=1;else if(r)fatal("CPU RENDER",r);}
}
static int text_bounds(const RqCommand *c,const char *text,int *ox,int *oy,int *ow,int *oh){
    int64_t px=c->x,py=c->y,l=c->right,t=c->bottom,r=c->left,b=c->top;
    unsigned visible=0;
    for(unsigned i=0;text[i]&&i<RQ_TEXT_BYTES;++i){
        if(text[i]=='\n'){px=8;py+=9*(int64_t)c->scale;continue;}
        int64_t x0=px,y0=py,x1=px+5*(int64_t)c->scale,y1=py+7*(int64_t)c->scale;
        if(x0<c->left)x0=c->left;if(y0<c->top)y0=c->top;
        if(x1>c->right)x1=c->right;if(y1>c->bottom)y1=c->bottom;
        if(x0<x1&&y0<y1){if(x0<l)l=x0;if(y0<t)t=y0;if(x1>r)r=x1;if(y1>b)b=y1;visible=1;}
        px+=6*(int64_t)c->scale;
    }
    if(!visible)return 0;*ox=(int)l;*oy=(int)t;*ow=(int)(r-l);*oh=(int)(b-t);return 1;
}
static void layer_sink(const RqCommand *c,const char *text,void *context){
    (void)context;if(cancelled)return;
    int x,y,w,h;
    if(c->kind==RQ_TEXT){
        if(!text_bounds(c,text,&x,&y,&w,&h))return;
        finish_job();mark_damage(x,y,w,h);
        draw_text_clipped(framebuffer,c->x,c->y,text,c->color,c->scale,c->left,c->top,c->right,c->bottom);
        return;
    }
    if(!clipped_bounds(c->x,c->y,c->w,c->h,c->left,c->top,c->right,c->bottom,&x,&y,&w,&h))return;
    mark_damage(x,y,w,h);
    if(c->kind==RQ_TILE){
        Tile tile=tiles[c->tile];unsigned sx=(unsigned)((int64_t)x-c->x),sy=(unsigned)((int64_t)y-c->y);
        ++scene_sprite_count;
        bb_job j={BB_COPY_OP,ART_BASE+tile.off+(sy*tile.w+sx)*4,framebuffer+y*BB_SCREEN_STRIDE+x*4,
                  tile.w*4,BB_SCREEN_STRIDE,(unsigned)w,(unsigned)h,0,c->alpha,BB_KEY,BB_ALPHA_ENABLE|BB_KEY_ENABLE};execute(&j);
    }else{
        bb_job j={BB_FILL_OP,0,framebuffer+y*BB_SCREEN_STRIDE+x*4,0,BB_SCREEN_STRIDE,(unsigned)w,(unsigned)h,c->color,255,BB_KEY,0};execute(&j);
    }
}
void scene_tile(int x,int y,unsigned tile,unsigned alpha){
    if(cancelled)return;
    if(tile>=sizeof(tiles)/sizeof(tiles[0]))fatal("TILE",tile);
    if(layer_capture){
        if(alpha>255)fatal("LAYER ALPHA",(int)alpha);
        RqCommand c={0};c.kind=RQ_TILE;c.x=x;c.y=y;c.w=tiles[tile].w;c.h=tiles[tile].h;c.tile=(uint16_t)tile;c.alpha=(uint8_t)alpha;
        layer_submit(&c,0);return;
    }
    Tile t=tiles[tile];int w=t.w,h=t.h,sx=0,sy=0;
    /* Game sprites are clipped to the 720p 1024x688 play field. */
    if(x<32){sx=32-x;w-=sx;x=32;}if(y<16){sy=16-y;h-=sy;y=16;}
    if(x+w>1056)w=1056-x;if(y+h>704)h=704-y;if(w<=0||h<=0)return;
    ++scene_sprite_count;
    mark_damage(x,y,w,h);
    bb_job j={BB_COPY_OP,ART_BASE+t.off+(sy*t.w+sx)*4,framebuffer+y*BB_SCREEN_STRIDE+x*4,t.w*4,BB_SCREEN_STRIDE,w,h,0,alpha,BB_KEY,BB_ALPHA_ENABLE|BB_KEY_ENABLE};execute(&j);
}
void scene_rect(int x,int y,int w,int h,uint32_t color){
    if(cancelled)return;
    if(hud_capture){hud_record(0,x,y,w,h,color,0,0);return;}
    if(layer_capture){RqCommand c={0};c.kind=RQ_RECT;c.x=x;c.y=y;c.w=w;c.h=h;c.color=color;layer_submit(&c,0);return;}
    if(x<0||y<0||x+w>1280||y+h>720||w<=0||h<=0)fatal("RECT",-1);
    if(x<1072)mark_damage(x,y,w,h);
    bb_job j={BB_FILL_OP,0,framebuffer+y*BB_SCREEN_STRIDE+x*4,0,BB_SCREEN_STRIDE,w,h,color,255,BB_KEY,0};execute(&j);
}
void scene_text(int x,int y,const char *text,uint32_t color,unsigned scale){
    if(cancelled)return;
    if(hud_capture){hud_record(1,x,y,(int)strlen(text)*6*(int)scale,7*(int)scale,color,scale,text);return;}
    if(layer_capture){
        if(!text||!scale)return;
        if(scale>65535)fatal("LAYER SCALE",(int)scale);
        RqCommand c={0};c.kind=RQ_TEXT;c.x=x;c.y=y;c.color=color;c.scale=(uint16_t)scale;layer_submit(&c,text);return;
    }
    /* The batch writes only x=32..1055. CPU HUD writes may run concurrently,
       but all field text and generic jobs still wait for completion. */
    unsigned w=(unsigned)strlen(text)*6*scale,h=7*scale;
    if(!(pending_job && previous.op==2 && x>=1072 && y>=0 &&
         (unsigned)x+w<=1280 && (unsigned)y+h<=720))finish_job();
    if(x<1072){
        mark_damage(x,y,w,h);
        /* Field overlays must stay inside the area restored on both buffers. */
        draw_text_clipped(framebuffer,x,y,text,color,scale,32,16,1056,704);
    }else draw_text(framebuffer,x,y,text,color,scale);
}
void scene_init(void){
    rq_reset();layer_capture=layers_started=0;scene_clip_reset();
    initialized_frames=0;cache_valid=0;pending_job=0;damage_count[0]=damage_count[1]=0;hud_capture=hud_used=0;scene_hud_invalidate();
    volatile uint32_t *art=(volatile uint32_t *)ART_BASE;
    for(unsigned i=0;i<sizeof(art_pixels);++i)art[i]=art_palette[art_pixels[i]];
    background_prepare(game_cfg.background_depth_enabled);
    volatile uint32_t *bg=(volatile uint32_t *)BACKGROUND;
    for(unsigned y=0;y<720;++y)for(unsigned x=0;x<1280;++x)
        bg[y*1280+x]=background_pixel(x,y);
    draw_text(BACKGROUND,1078,28,"TOUHOU",0xece3f4,3);
    draw_text(BACKGROUND,1078,58,"SCARLET NIGHT",0xe86b82,1);
    draw_text(BACKGROUND,1078,80,"PHASE BATTLE",0xf5cf77,1);
    draw_text(BACKGROUND,1078,98,"RUMIA CIRNO MEILING",0xaebce6,1);
    if(bb_publish()!=BB_OK)fatal("ART PUBLISH",-1);
}
static void restore_rect(int x,int y,int w,int h){
    unsigned offset=(unsigned)y*BB_SCREEN_STRIDE+(unsigned)x*4;
    bb_job j={BB_COPY_OP,BACKGROUND+offset,framebuffer+offset,BB_SCREEN_STRIDE,BB_SCREEN_STRIDE,w,h,0,255,BB_KEY,0};execute(&j);
}

static int hud_intersects(const HudCommand *c,int top,int bottom){
    return c->x<1280 && c->x+c->w>HUD_LEFT && c->y<bottom && c->y+c->h>top;
}
static int hud_same_row(unsigned bank,int top,int bottom){
    unsigned a=0,b=0;
    for(;;){
        while(a<hud_count&&!hud_intersects(&hud_current[a],top,bottom))++a;
        while(b<hud_saved_count[bank]&&!hud_intersects(&hud_saved[bank][b],top,bottom))++b;
        if(a==hud_count||b==hud_saved_count[bank])return a==hud_count&&b==hud_saved_count[bank];
        if(memcmp(&hud_current[a++],&hud_saved[bank][b++],sizeof(HudCommand)))return 0;
    }
}
/* Equal command counts are the usual HUD case. Compare each command once,
   marking both its old and new coverage, then redraw commands in their original
   painter order inside each dirty band. Exact equality; no hash collisions. */
static void hud_mark_rows(uint32_t *mask,const HudCommand *c){
    if(!hud_intersects(c,HUD_TOP,HUD_BOTTOM))return;
    int top=c->y,bottom=c->y+c->h;
    if(top<HUD_TOP)top=HUD_TOP;
    if(bottom>HUD_BOTTOM)bottom=HUD_BOTTOM;
    if(top>=bottom)return;
    unsigned first=(unsigned)(top-HUD_TOP)/8,last=(unsigned)(bottom-1-HUD_TOP)/8;
    for(unsigned row=first;row<=last;++row)mask[row>>5]|=1u<<(row&31);
}
static int hud_mask_has(const uint32_t *mask,unsigned row){return (mask[row>>5]>>(row&31))&1u;}
void scene_hud_end(void){
    hud_capture=0;
    unsigned bank=damage_bank;
    if(cancelled){scene_hud_invalidate();return;}
    uint32_t dirty[(HUD_ROWS+31)/32]={0};
    unsigned fast_rows=hud_cache_enabled&&hud_valid[bank]&&hud_count==hud_saved_count[bank];
    if(fast_rows){
        unsigned changed=0,any_row=0;
        for(unsigned i=0;i<hud_count;++i)if(memcmp(&hud_current[i],&hud_saved[bank][i],sizeof(HudCommand))){
            changed=1;hud_mark_rows(dirty,&hud_saved[bank][i]);hud_mark_rows(dirty,&hud_current[i]);
        }
        for(unsigned i=0;i<(HUD_ROWS+31)/32;++i)any_row|=dirty[i];
        if(!any_row){
            if(changed)memcpy(hud_saved[bank],hud_current,hud_count*sizeof(HudCommand));
            return;
        }
    }
    unsigned row=0;
    while(row<HUD_ROWS){
        int top=HUD_TOP+(int)row*8,bottom=top+8;if(bottom>HUD_BOTTOM)bottom=HUD_BOTTOM;
        if(hud_cache_enabled&&hud_valid[bank]&&(fast_rows?!hud_mask_has(dirty,row):hud_same_row(bank,top,bottom))){++row;continue;}
        unsigned first=row++;
        while(row<HUD_ROWS){
            int t=HUD_TOP+(int)row*8,b=t+8;if(b>HUD_BOTTOM)b=HUD_BOTTOM;
            if(hud_cache_enabled&&hud_valid[bank]&&(fast_rows?!hud_mask_has(dirty,row):hud_same_row(bank,t,b)))break;
            ++row;
        }
        top=HUD_TOP+(int)first*8;bottom=HUD_TOP+(int)row*8;if(bottom>HUD_BOTTOM)bottom=HUD_BOTTOM;
        restore_rect(HUD_LEFT,top,1280-HUD_LEFT,bottom-top);
        scene_hud_restored_rows+=row-first;++scene_hud_redraw_jobs;
        for(unsigned i=0;i<hud_count&&!cancelled;++i){
            const HudCommand *c=&hud_current[i];if(!hud_intersects(c,top,bottom))continue;
            if(c->kind){
                finish_job();draw_text_clipped(framebuffer,c->x,c->y,c->text,c->color,c->scale,HUD_LEFT,top,1280,bottom);
            }else{
                int x=c->x,y=c->y,w=c->w,h=c->h;
                if(x<HUD_LEFT){w-=HUD_LEFT-x;x=HUD_LEFT;}if(x+w>1280)w=1280-x;
                if(y<top){h-=top-y;y=top;}if(y+h>bottom)h=bottom-y;
                if(w>0&&h>0){bb_job j={BB_FILL_OP,0,framebuffer+y*BB_SCREEN_STRIDE+x*4,0,BB_SCREEN_STRIDE,w,h,c->color,255,BB_KEY,0};execute(&j);++scene_hud_redraw_jobs;}
            }
        }
    }
    if(cancelled){scene_hud_invalidate();return;}
    memcpy(hud_saved[bank],hud_current,hud_count*sizeof(HudCommand));
    hud_saved_count[bank]=hud_count;hud_valid[bank]=1;
}
void scene_set_batch(unsigned enabled){
    if(batch_mode!=enabled){finish_job();scene_hud_invalidate();batch_mode=enabled;initialized_frames=0;damage_count[0]=damage_count[1]=0;}
}
void scene_begin(uint32_t fb,unsigned hw){
    if(rq_count())fatal("LAYER FRAME END",-1);
    layer_capture=layers_started=0;rq_reset();scene_layer_commands=scene_layer_peak=scene_layer_clipped=scene_layer_reordered=0;scene_clip_reset();
    finish_job();
    framebuffer=fb;hardware=hw;scene_jobs=0;scene_sprite_count=0;cancelled=0;
    if(!hw)bb_acquire();
    unsigned bit=fb==BB_FB0?1:fb==BB_FB1?2:0;
    if(!bit)fatal("SCENE FRAMEBUFFER",-1);
    damage_bank=fb==BB_FB1;
    if(!(initialized_frames&bit)){
        restore_rect(0,0,1024,720);restore_rect(1024,0,256,720);initialized_frames|=bit;
    }else{
        /* The play field is rebuilt by the batch background; CPU fallback and
           non-batch modes restore the tracked rectangles. The full right-hand
           HUD is restored every frame because score/HP/level text can shrink,
           and stale glyphs are not allowed on either buffer. */
        if(batch_mode && !hw)restore_rect(32,16,1024,688);
        if(!batch_mode)for(unsigned i=0;i<damage_count[damage_bank];++i){
            volatile Damage *d=&DAMAGE[damage_bank*DAMAGE_CAP+i];
            restore_rect(d->x,d->y,d->w,d->h);
        }
        if(!hud_used)restore_rect(1072,118,208,586);
    }
    damage_count[damage_bank]=0;
}
void scene_end(void){scene_layers_flush();layer_capture=0;finish_job();if(bb_publish()!=BB_OK)fatal("FRAME PUBLISH",-1);
    if(cancelled){scene_hud_invalidate();initialized_frames=0;damage_count[0]=damage_count[1]=0;}
}

/* Standard-register batch extension: op/source/destination/width/height,
   descriptor pointer in FILL, count and material base in extension registers. */
void scene_batch_shots(void){
    if(layers_started)fatal("LAYER BATCH ORDER",-1);
    if(!batch_mode)fatal("BATCH MODE",-1);
    if(!hardware){
        for(unsigned i=0;i<stage.count&&!cancelled;++i){Shot *b=&stage.shots[i];scene_tile(32+b->x/Q-4,16+b->y/Q-4,b->tile,224);}
        return;
    }
    finish_job();
    if(!(scene_read(0x4c)&2))fatal("BATCH CAPABILITY",-1);
    uint64_t list_begin=bb_ticks();
    _Static_assert(sizeof(Shot)==16 && offsetof(Shot,tile)==14,"DMA sprite layout");
    uintptr_t list=(uintptr_t)&stage.shots[0];
    batch_count=stage.count;scene_sprite_count+=batch_count; /* freeze the submitted count for the snapshot test */
    if((list&15)||batch_count>SHOT_CAPACITY)fatal("BATCH DESCRIPTOR",-1);
    if(bb_publish()!=BB_OK)fatal("BATCH PUBLISH",-1);
    scene_list_us=bb_us(bb_ticks()-list_begin);
    unsigned base=battle_materials?54:24;scene_write(0x50,base);scene_write(0x44,batch_count);scene_write(0x48,ART_BASE+tiles[base].off);
    bb_job j={2,BACKGROUND+16*BB_SCREEN_STRIDE+32*4,framebuffer+16*BB_SCREEN_STRIDE+32*4,
        BB_SCREEN_STRIDE,BB_SCREEN_STRIDE,1024,688,(uint32_t)list,224,BB_KEY,BB_ALPHA_ENABLE|BB_KEY_ENABLE};
    execute(&j);
}
