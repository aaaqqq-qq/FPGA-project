/* Freeze renderer commands as well as every pixel; this catches a cache that
   redraws needlessly or drops updates without relying on a host time estimate. */
#define bb_write model_bb_write
#define bb_cpu_execute model_bb_cpu_execute
#include "../../sim/scene_host.c"
#undef bb_write
#undef bb_cpu_execute
#include "game_config.h"
static uint32_t trace[16384],trace_count;
static void trace_job(const bb_job *j){
    if(trace_count+11>=sizeof trace/sizeof trace[0])fatal("TRACE CAP",0);
    memcpy(trace+trace_count,j,sizeof(*j));trace_count+=11;
}
void bb_write(unsigned reg,uint32_t v){
    if(reg==BB_CMD){bb_job j;memcpy(&j,&regs[BB_OP/4],sizeof j);trace_job(&j);}
    model_bb_write(reg,v);
}
bb_result bb_cpu_execute(const bb_job *j){trace_job(j);return model_bb_cpu_execute(j);}
__declspec(dllexport) unsigned compact_trace_count(void){return trace_count;}
__declspec(dllexport) const uint32_t *compact_trace(void){return trace;}
__declspec(dllexport) unsigned compact_rows(void){return scene_hud_restored_rows;}
__declspec(dllexport) unsigned compact_jobs(void){return scene_hud_redraw_jobs;}
__declspec(dllexport) unsigned compact_cancelled(void){return scene_cancelled();}
__declspec(dllexport) void compact_init(void){game_config_defaults();init_test();trace_count=0;}
static unsigned random_state;
static unsigned random32(void){random_state^=random_state<<13;random_state^=random_state>>17;random_state^=random_state<<5;return random_state;}
__declspec(dllexport) void compact_frame(unsigned seed,unsigned bank,unsigned hw,unsigned cache,unsigned kind,unsigned abort_job){
    trace_count=0;abort_after=abort_job;random_state=seed?seed:1;
    scene_hud_cache_enable(cache);scene_set_batch(0);scene_begin(bank?BB_FB1:BB_FB0,hw);scene_hud_begin();
    unsigned n=kind==0?96:kind==1?0:1+random32()%95;
    char text[96];
    for(unsigned i=0;i<n;++i){
        int x=kind==0?1078:1040+(int)(random32()%320);
        int y=kind==0?118+(int)(i%70)*8:80+(int)(random32()%670);
        unsigned color=random32()&0xffffffu;
        unsigned type=(i+kind)%5;
        if(type==0){scene_rect(x,y,(int)(random32()%210),1+(int)(random32()%34),color);continue;}
        unsigned len=kind==0?95:(kind==3?0:kind==4?1:random32()%96);
        for(unsigned k=0;k<len;++k){
            unsigned r=random32();text[k]=(r%19==0)?'\n':(r%23==0)?(char)0x92:(char)(' '+r%95);
        }
        text[len]=0;
        scene_text(x,y,text,color,1+random32()%4);
        /* Submission must copy before this stack buffer is poisoned. */
        memset(text,'Q',95);text[95]=0;
    }
    scene_hud_end();scene_end();abort_after=0;
}
