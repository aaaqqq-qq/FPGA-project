"""Compare compact HUD caching with the frozen LAB60D implementation."""
from pathlib import Path
import argparse, ctypes, hashlib, json, os, shlex, struct, subprocess

root=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=p.parse_args()
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
out=root/'results/hud_compact';out.mkdir(parents=True,exist_ok=True)
font=(root/'src/font.c').read_text().replace('void draw_text(','void font_draw_text(')
(out/'font.c').write_text(font)
ref=root/'tests/hud_compact/reference_scene.c'
assert hashlib.sha256(ref.read_text().encode()).hexdigest()=='a555e786885ece0540b0551f3e18453fb0e3a837033b621adce5209c1056ae68'
libs=[]
for name,source in [('compact','src/scene.c'),('frozen','tests/hud_compact/reference_scene.c')]:
    dll=out/(name+'.dll')
    cmd=cc+['-std=gnu11','-O2','-shared','-DBB_HOST_TEST','-Isrc','tests/hud_compact/host.c',source,
            'src/background.c',str(out/'font.c'),'src/pixels.c','src/render_queue.c','src/game_config.c','-o',str(dll)]
    run=subprocess.run(cmd,cwd=root,capture_output=True,text=True)
    (out/(name+'_compile.log')).write_text(run.stdout+run.stderr)
    assert run.returncode==0,run.stdout+run.stderr
    lib=ctypes.CDLL(str(dll));lib.compact_trace.restype=ctypes.POINTER(ctypes.c_uint32);libs.append(lib)
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.VirtualAlloc.restype=ctypes.c_void_p
k.VirtualAlloc.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32,ctypes.c_uint32]
base=0x01000000;size=0x01200000
assert k.VirtualAlloc(base,size,0x3000,4)==base,ctypes.get_last_error()
assert k.VirtualAlloc(0x07000000,0x00400000,0x3000,4)==0x07000000, ctypes.get_last_error()
# Same 96-command slots repeatedly become maximal text, empty text, one byte,
# rectangles and absent commands; then restore a previous bank independently.
sequence=[]
for kind in [0,3,4,1,2,0,4,3,0,1,2]:
    seed=4567+kind
    for bank,hw,cache in [(0,0,1),(1,1,1),(0,1,1),(1,0,1),(0,1,0),(0,0,1),(0,1,1)]:
        sequence.append((seed,bank,hw,cache,kind,0))
for i in range(220):
    seed=0x61cd23+(i//3)*137
    sequence.append((seed,(i//2)&1,i&1,0 if i%17==0 else 1,2+i%3,0))
for kind in [0,4,3,2,1]:
    sequence.extend([(789,0,0,1,kind,3),(789,0,1,1,kind,0),(789,1,0,1,kind,0),(789,0,0,1,kind,0)])
reference=[]
for index,lib in enumerate(libs):
    ctypes.memset(base,0xa5,size);lib.compact_init()
    for frame,args in enumerate(sequence):
        lib.compact_frame(*args)
        address=base+(0x00400000 if args[1] else 0)
        pixels=ctypes.string_at(address,1280*720*4)
        count=lib.compact_trace_count()
        raw_trace=ctypes.string_at(lib.compact_trace(),count*4)
        trace_parts=[];text_copies=0
        for offset in range(0,len(raw_trace),44):
            block=raw_trace[offset:offset+44];job=struct.unpack('<11I',block)
            if job[0]==1 and 0x07000000<=job[1]<0x07240000:
                assert job[3]==5120 and job[4]==5120 and 0<job[5]<=208 and 0<job[6]<=14
                assert job[8]==255 and job[9]==0xff00ff and job[10]==2
                assert 0<=job[2]-address<1280*720*4 and ((job[2]-address)%5120)//4>=1072
                text_copies+=1
            else:trace_parts.append(block)
        trace=b''.join(trace_parts)
        observed=(hashlib.sha256(pixels).hexdigest(),trace,lib.compact_rows(),lib.compact_jobs()-text_copies,lib.compact_cancelled())
        if index==0:reference.append(observed)
        else:assert observed==reference[frame],(frame,args,observed[0],reference[frame][0],observed[2:],reference[frame][2:])
report={'status':'PASS','frames_fullpixel_and_exact_job_trace':len(sequence),'pixels_compared':len(sequence)*1280*720,
        'source_sha256':hashlib.sha256((root/'src/scene.c').read_bytes()).hexdigest(),
        'frozen_reference_normalized_sha256':hashlib.sha256(ref.read_text().encode()).hexdigest(),
        'scope':'Exact full pixels, every legacy COPY/FILL job and dirty rows/cancellation vs frozen old C renderer; additional text-cache COPY jobs independently validated and counted separately. No FPGA timing claim.',
        'coverage':['96 commands','95-byte, empty and 1-byte text','embedded newlines and non-ASCII glyph fallback',
                    'poisoned source buffer/trailing bytes','text/rectangle slot transitions','count changes and empty HUD',
                    'both framebuffers and repeated bank','CPU/deferred DMA','cache disable/enable','cancellation and reuse']}
(out/'summary.json').write_text(json.dumps(report,indent=2))
print('HUD_COMPACT PASS',len(sequence),'complete frames and exact rendering job traces')
