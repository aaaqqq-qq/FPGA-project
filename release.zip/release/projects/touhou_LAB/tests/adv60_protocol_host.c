/* Extend the complete retained real-C/driver ADV coverage with perf1 wire and
   progress semantics. This is still native-model evidence, not board FPS. */
#define main retained_adv_coverage
#include "adv_host.c"
#undef main
int main(void){CHECK(retained_adv_coverage()==0);CHECK(ADV_FRAMES_MAX==36000);pass(":adv 100 enter");unsigned start_swaps=swaps;
 pass(":adv 101 stress fpga 1 8 0 65535 16711935 16763904 1 128 1 0 1201 987");
 const char *result=row("ADV_RESULT "),*metric=row("ADV_METRIC "),*timing=row("ADV_TIMING ");
 CHECK(value(result,"frames")==1201&&value(metric,"swaps")==1201);CHECK(swaps-start_swaps==1205);
 CHECK(value(timing,"warmup_frames")==1&&value(timing,"pipeline")==1&&value(timing,"sample_points")==16);
 CHECK(value(timing,"scan_total")==1201&&value(timing,"max_scan_gap")==1&&value(timing,"missed_scans")==0);
 CHECK(value(timing,"state_first")!=value(timing,"state_last"));CHECK(value(timing,"hw_us")>0);CHECK(value(timing,"overlap_us")==0); /* immediate DMA model has no overlap */
 unsigned progress_rows=0;uint64_t task=value(result,"task");for(unsigned i=0;i<lines_n;++i)if(strstr(lines[i],"ADV_PROGRESS ")==lines[i]){
  ++progress_rows;CHECK(value(lines[i],"id")==101&&value(lines[i],"task")==task&&value(lines[i],"total")==1201);CHECK(value(lines[i],"frames")==progress_rows*600&&value(lines[i],"swaps")==progress_rows*600);}
 CHECK(progress_rows==2);queue(":adv 102 stress fpga 20000 8 0 1 2 3 2 128 1 0 36000 9");CHECK(strstr(last(),"status=QUEUED"));queue(":adv 103 cancel");adv_service();CHECK(strstr(last(),"status=CANCELLED")&&value(last(),"completed")==0);pass(":adv 104 exit");
 printf("ADV60_PROTOCOL_PASS progress_rows=%u measured_frames=1201 bank_setup2_warmup1_overlay1_unmeasured=4 max_line=%u assertions=%u hardware=NOT_RUN\n",progress_rows,max_line,checks);return 0;}
