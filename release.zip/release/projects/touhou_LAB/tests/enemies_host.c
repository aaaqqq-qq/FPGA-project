/* R7 renderer APIs are no-ops only in this gameplay/command stub. */
#include "scene_layers_stubs.h"
void scene_batch_shots(void){}
#include "enemies.h"
#include "stage.h"
#include "battle.h"
#include "game_config.h"
#include "effects.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static unsigned checks,draws,rects,stars;
#define CK(x) do{++checks;if(!(x)){fprintf(stderr,"ENEMIES FAIL line=%d expression=%s\n",__LINE__,#x);assert(x);}}while(0)
void scene_tile(int x,int y,unsigned tile,unsigned alpha){(void)x;(void)y;CK(tile>=83&&tile<=90&&alpha<=255);++draws;}
void scene_rect(int x,int y,int w,int h,uint32_t color){(void)color;CK(x>=0&&y>=0&&w>0&&h>0&&x+w<=1280&&y+h<=720);++rects;}
void scene_text(int x,int y,const char *t,uint32_t c,unsigned s){(void)x;(void)y;(void)t;(void)c;(void)s;}
void fatal(const char *where,int error){fprintf(stderr,"FATAL %s %d\n",where,error);assert(0);}
static unsigned owner_count(unsigned owner){unsigned n=0;for(unsigned i=0;i<stage.count;++i)n+=stage.owner[i]==owner;return n;}
static void fresh(unsigned count,unsigned initial_seed){
    game_config_defaults();battle_set_legacy(0);battle_reset(0,SHOT_CAPACITY);player_reset(512,620);player.spawn_invuln=100000;
    effects_reset();enemies_reset(count);stage.seed=initial_seed;draws=rects=stars=0;
}
static void tick(unsigned t){enemies_tick(t,player.x,player.y);effects_tick();}
static void population(unsigned count){
    fresh(count,0x13579bdfu);for(unsigned t=0;t<300;++t){unsigned before=enemies_requested;tick(t);CK(enemies_requested-before<=6);CK(enemies_active_count()<=count);}
    CK(enemies_active_count()==count&&enemies_spawns==count&&enemies_requested>0);
    CK(enemies_spawned==enemies_requested&&!enemies_rejected&&stage.count==enemies_spawned);
    for(unsigned i=0;i<count;++i){OrdinaryEnemy *e=&ordinary_enemies[i];CK(e->state==ENEMY_ACTIVE&&e->hp>0&&e->x>=24&&e->x<=ARENA_W-24);}
    for(unsigned i=0;i<stage.count;++i)CK(stage.owner[i]>=128&&stage.owner[i]<128+count&&stage.shots[i].tile>=54&&stage.shots[i].tile<70);
    uint32_t h=enemies_state_hash(1);enemies_render();CK(draws==count&&rects<=count*2&&enemies_state_hash(1)==h);
}
static uint32_t hw(uint32_t h,unsigned n){for(unsigned i=0;i<4;++i){h=(h^(n&255u))*16777619u;n>>=8;}return h;}
static uint32_t full_hash(void){
    uint32_t h=enemies_state_hash(battle_state_hash(2166136261u));h=hw(h,stage.count);h=hw(h,stage.seed);h=hw(h,player.score);h=hw(h,player.graze);
    for(unsigned i=0;i<stage.count;++i){Shot *s=&stage.shots[i];h=hw(h,(unsigned)s->x);h=hw(h,(unsigned)s->y);h=hw(h,(unsigned)s->vx);h=hw(h,(unsigned)s->vy);h=hw(h,s->tile);h=hw(h,stage.owner[i]);}return h;
}
static uint32_t expected[600];
static void replay_sequence(unsigned pass,unsigned seed_value){
    fresh(6,seed_value);
    for(unsigned t=0;t<600;++t){
        player.x=450+turn_sin((int)(t*321))*80/32768;player_begin_tick();battle_step(player.x,player.y);tick(t);
        if(t%73==0)for(unsigned i=0;i<6;++i)if(ordinary_enemies[i].hp>0&&ordinary_enemies[i].y>=0){PlayerShot s={0};s.live=1;s.x=ordinary_enemies[i].x;s.y=ordinary_enemies[i].y;enemies_hit_shot(&s);break;}
        uint32_t h=full_hash();if(!pass)expected[t]=h;else if(pass==1)CK(h==expected[t]);else if(!t)CK(h!=expected[t]);
    }
}
int main(void){
    fresh(0,123);uint32_t unchanged=enemies_state_hash(1);for(unsigned t=0;t<240;++t)tick(t);
    CK(!enemies_active_count()&&!enemies_spawns&&!enemies_requested&&unchanged==enemies_state_hash(1)&&stage.seed==123&&!player.score);
    puts("E01 PASS zero enemies is inert");
    population(6);population(12);puts("E02 PASS6/12 independent moving fairies, bounded firing/renderer");
    fresh(999,3);CK(enemies_configured_count()==12&&enemies_config_rejections==1);for(unsigned t=0;t<300;++t)tick(t);CK(enemies_active_count()==12);
    puts("E03 PASS overflow request clamps bounded12");
    fresh(6,3);for(unsigned t=0;t<300;++t)tick(t);
    unsigned saved_other=owner_count(129);CK(owner_count(128)>0&&saved_other>0);
    unsigned hp=(unsigned)ordinary_enemies[0].hp,score=player.score;
    PlayerShot s={0};s.live=1;s.x=ordinary_enemies[0].x;s.y=ordinary_enemies[0].y;
    CK(enemies_hit_shot(&s)&&!s.live);unsigned after_hp=(unsigned)ordinary_enemies[0].hp;CK(hp-after_hp==game_cfg.player_shot_damage);CK(!enemies_hit_shot(&s));
    CK(enemies_apply_damage(0,0xffffffffu)==after_hp&&enemies_kills==1&&!owner_count(128)&&owner_count(129)==saved_other);
    CK(player.score-score==hp*game_cfg.damage_score+ENEMY_KILL_SCORE&&ordinary_enemies[0].state==ENEMY_WAIT);
    CK(!enemies_apply_damage(0,1)&&!enemies_apply_damage(12,1)&&!enemies_hit_shot(0));
    unsigned next=ordinary_enemies[0].next_spawn;for(unsigned t=300;t<next;++t)tick(t);CK(ordinary_enemies[0].state==ENEMY_WAIT);tick(next);CK(ordinary_enemies[0].state==ENEMY_ENTER&&ordinary_enemies[0].generation==2);
    puts("E04 PASS projectile consumption, kill score once, only owned bullets cleared, respawn");
    fresh(12,7);stage.limit=0;for(unsigned t=0;t<300;++t){unsigned old=enemies_requested;tick(t);CK(enemies_requested-old<=6);}CK(enemies_requested>0&&!enemies_spawned&&enemies_rejected==enemies_requested&&!stage.count);
    puts("E05 PASS full pool requests/rejections counted, never exceeds6shots per tick");
    fresh(12,7);game_cfg.adaptive_density=1;battle_density_slow=1;for(unsigned t=0;t<300;++t)tick(t);CK(!enemies_requested&&enemies_volleys_deferred>0);
    battle_density_slow=0;for(unsigned i=0;i<12;++i)ordinary_enemies[i].fire_wait=0;
    for(unsigned t=300;t<312;++t)tick(t);for(unsigned i=0;i<12;++i)CK(owner_count(128+i)>0);
    puts("E06 PASS crowded-pool throttle and rotating fair volley service");
    fresh(1,8);tick(0);OrdinaryEnemy *e=&ordinary_enemies[0];e->state=ENEMY_ENTER;e->age=47;e->anchor_y=200;e->anchor_x=e->x=300;
    unsigned pscore=player.score;enemies_tick(1,320,200);CK(player.graze==1&&player.score==pscore+game_cfg.graze_score);CK(enemies_contact_hit(300,200)&&!enemies_contact_hit(330,230));
    for(unsigned t=2;t<12;++t)enemies_tick(t,e->x+20,e->y);CK(player.graze==1&&player.hp==100);
    e->state=ENEMY_EXIT;e->y=687;e->hit_flash=5;enemies_render();
    puts("E07 PASS one graze per life, contact flag leaves unified HP to caller, safe bottom-edge render");
    fresh(1,9);unsigned despawned=0;for(unsigned t=0;t<900;++t){unsigned old=enemies_despawns;tick(t);if(enemies_despawns>old){CK(!owner_count(128)&&ordinary_enemies[0].state==ENEMY_WAIT);despawned=1;break;}}CK(despawned);
    puts("E08 PASS natural exit/despawn cleans only its bullets");
    fresh(12,10);for(unsigned t=0;t<300;++t)tick(t);unsigned kills=enemies_kills;enemies_clear_all();CK(!enemies_active_count()&&!stage.count&&enemies_kills==kills);for(unsigned t=300;t<900;++t)tick(t);CK(!enemies_active_count());
    puts("E09 PASS terminal clear stops respawn without kill score");
    replay_sequence(0,0x13579bdfu);replay_sequence(1,0x13579bdfu);replay_sequence(2,0x2468ace1u);
    printf("E10 PASS600tick production enemy/bullet/player-action deterministic replay, different seed differs; checks=%u\n",checks);
    puts("ALL_ENEMIES_PASS");return 0;
}
