#include "replay.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static ReplayEvent backup[REPLAY_CAPACITY];
static ReplayHeader saved;
static void fixture(void){
    assert(replay_record_begin(0x6e697468u,0x12345678u)==0);
    for(unsigned t=0;t<1000;++t)assert(replay_record_input(t,t<100?0:2,t==500?1:0)==0);
    assert(replay_record_end(1000,0x11223344u)==0);
    saved=*replay_header();memcpy(backup,replay_events(),saved.event_count*sizeof(backup[0]));
}
int main(void){
    fixture();assert(saved.event_count==3);assert(replay_export_words()==14);
    assert(replay_play_begin(0x12345678u)==0);
    for(unsigned t=0;t<1000;++t){unsigned k,b;assert(replay_play_input(t,&k,&b)==1);assert(k==(t<100?0u:2u));assert(b==(t==500?1u:0u));}
    unsigned k,b;assert(replay_play_input(1000,&k,&b)==0);assert(replay_play_end(0x11223344u)==0);assert(replay_state()==REPLAY_FINISHED);
    puts("R01 PASS RLE keys/events and exclusive end");
    fixture();assert(replay_play_begin(99)==REPLAY_E_CONFIG);assert(replay_status()==REPLAY_E_CONFIG);assert(replay_play_begin(0x12345678u)==REPLAY_E_CONFIG);
    puts("R02 PASS config mismatch sticky fail-stop");
    fixture();saved.magic=0;assert(replay_load(&saved,backup,0x12345678u)==REPLAY_E_HEADER);
    puts("R03 PASS invalid header");
    fixture();backup[1].keys^=1;assert(replay_load(&saved,backup,0x12345678u)==REPLAY_E_CRC);
    puts("R04 PASS corrupt payload CRC");
    fixture();saved.seed^=1;assert(replay_load(&saved,backup,0x12345678u)==REPLAY_E_CRC);
    puts("R05 PASS corrupt seed CRC");
    replay_record_begin(3,5);for(unsigned t=0;t<REPLAY_CAPACITY;++t)assert(replay_record_input(t,t&1,0)==0);
    ReplayEvent last=replay_events()[REPLAY_CAPACITY-1];assert(replay_record_input(REPLAY_CAPACITY,0,0)==REPLAY_E_OVERFLOW);
    assert(replay_header()->event_count==REPLAY_CAPACITY);assert(memcmp(&last,&replay_events()[REPLAY_CAPACITY-1],sizeof(last))==0);assert(replay_export_words()==0);
    puts("R06 PASS bounded overflow no overwrite/export");
    replay_record_begin(3,5);assert(replay_record_input(1,0,0)==REPLAY_E_TICK);
    replay_record_begin(3,5);assert(replay_record_input(0,16,0)==REPLAY_E_INPUT);
    replay_record_begin(3,5);assert(replay_record_input(0,0,256)==REPLAY_E_INPUT);
    puts("R07 PASS invalid tick/key/event rejected");
    fixture();assert(replay_play_begin(0x12345678u)==0);assert(replay_play_end(0x11223344u)==REPLAY_E_TICK);
    fixture();assert(replay_play_begin(0x12345678u)==0);for(unsigned t=0;t<1000;++t)assert(replay_play_input(t,&k,&b)==1);assert(replay_play_end(9)==REPLAY_E_HASH);
    puts("R08 PASS incomplete/hash-mismatch rejected");
    fixture();assert(replay_load(&saved,backup,0x12345678u)==0);assert(replay_play_begin(0x12345678u)==0);
    assert(replay_play_input(0,&k,&b)==1);assert(replay_abort()==0);assert(replay_state()==REPLAY_READY);assert(replay_play_begin(0x12345678u)==0);
    puts("R09 PASS validated import");
    fixture();for(unsigned i=0;i<replay_export_words();++i){uint32_t word;assert(replay_export_word(i,&word)==0);printf("REPLAY_WORD %u %u\n",i,(unsigned)word);}
    puts("ALL_REPLAY_PROTOCOL_PASS");return 0;
}
