/* Real adv.c + production driver CPU/submit/swap, independent bounded DMA model.
   No physical FPGA throughput claim is made by this host model. */
#include "adv.h"
#include "adv_model.h"
#include "bitblt.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
static unsigned checks,jobs,batches,cpu_jobs,swaps,restores,poll_count,cancel_at,timeout_at;
static unsigned inject_source,inject_guard,inject_pixel,restore_error,legacy;
static uint64_t ticks;
static uint32_t regs[64],front=BB_FB0,next_fb,swap_pending,swap_reads;
static char lines[128][512];static unsigned lines_n,max_line;
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL %d %s\n",__LINE__,#x);for(unsigned q=0;q<lines_n;++q)fprintf(stderr,"%s\n",lines[q]);exit(1);}}while(0)
static uint32_t *p(uint32_t a){return (uint32_t *)(uintptr_t)a;}
unsigned lab_active(void){return legacy;}
unsigned lab_pending(void){return 0;}
unsigned labx_active(void){return 0;}
unsigned labx_pending(void){return 0;}
uint64_t bb_ticks(void){ticks+=100;return ticks;}
uint32_t bb_us(uint64_t n){return (uint32_t)(n/100);}
bb_result bb_publish(void){ticks+=300;return BB_OK;}
void bb_acquire(void){ticks+=300;}
static uint32_t blend(uint32_t s,uint32_t d,unsigned alpha,unsigned flags,uint32_t key){
 if((flags&2)&&(s&0xffffff)==(key&0xffffff))return d;if(!(flags&1)||alpha==255)return s;if(!alpha)return d;uint32_t out=0;
 for(unsigned b=0;b<3;++b){unsigned sc=(s>>(b*8))&255,dc=(d>>(b*8))&255;out|=((sc*alpha+dc*(255-alpha)+127)/255)<<(b*8);}return out;
}
static void pixel_job(const bb_job *j){for(unsigned y=0;y<j->height;++y)for(unsigned x=0;x<j->width;++x){uint32_t *d=p(j->dst+y*j->dst_stride)+x;uint32_t src=j->op==BB_FILL_OP?j->fill:p(j->src+y*j->src_stride)[x];*d=blend(src,*d,j->alpha,j->flags,j->key);}}
uint32_t bb_read(unsigned r){ticks+=10;if(r==BB_FRONT)return front;if(r==BB_SWAPS)return swaps;if(r==BB_FRAMES)return swaps+100;
 if(r==BB_DISPLAY_STATUS){if(swap_pending&&++swap_reads>=3){front=next_fb;swap_pending=0;++swaps;}return BB_CAL_DONE|(swap_pending?BB_SWAP_PENDING:0);}if(r==0x4c)return 2;return regs[r/4];}
void bb_write(unsigned r,uint32_t v){CHECK(r!=BB_DISPLAY_CTRL);ticks+=10;regs[r/4]=v;
 if(r==BB_STATUS){regs[r/4]=0;return;}if(r==BB_NEXT_FRONT){next_fb=v;return;}if(r==BB_SWAP){CHECK(!swap_pending&&next_fb!=front);swap_pending=1;swap_reads=0;return;}if(r!=BB_CMD)return;
 bb_job j={regs[BB_OP/4],regs[BB_SRC/4],regs[BB_DST/4],regs[BB_SRC_STRIDE/4],regs[BB_DST_STRIDE/4],regs[BB_WIDTH/4],regs[BB_HEIGHT/4],regs[BB_FILL/4],regs[BB_ALPHA/4],regs[BB_KEY_REG/4],regs[BB_FLAGS/4]};
 CHECK(j.dst<front||j.dst>=front+BB_FRAME_BYTES);CHECK(!swap_pending);++jobs;
 if(j.op==2){++batches;CHECK(j.width==1024&&j.height==512&&regs[0x44/4]<=ADV_MAX);bb_job bg=j;bg.op=1;bg.flags=0;bg.alpha=255;pixel_job(&bg);
  for(unsigned i=0;i<regs[0x44/4];++i){uint32_t a=j.fill+i*16;int cx=*(int32_t *)p(a)>>12,cy=*(int32_t *)p(a+4)>>12;unsigned tile=((uint8_t *)p(a))[14];CHECK(cx>=4&&cx<=1020&&cy>=4&&cy<=508&&tile<16);
   bb_job sprite=j;sprite.op=1;sprite.src=regs[0x48/4]+tile*256;sprite.dst=j.dst+(cy-4)*5120+(cx-4)*4;sprite.src_stride=32;sprite.width=sprite.height=8;pixel_job(&sprite);}
 }else{CHECK(bb_validate(&j)==BB_OK);pixel_job(&j);}
 if(inject_source&&j.op==1&&j.src>=0x03b00000&&j.src<0x04f00000){p(j.src)[0]^=1;inject_source=0;}
 if(inject_pixel&&j.op==1&&j.src>=0x03b00000){p(j.dst)[0]^=1;inject_pixel=0;}
 if(inject_guard&&j.op==1&&j.src>=0x03b00000){p(BB_FB0+BB_FRAME_BYTES)[0]^=1;inject_guard=0;}
 regs[BB_CYCLES/4]=j.width*j.height/4+24;regs[BB_STATUS/4]=BB_DONE;ticks+=regs[BB_CYCLES/4];
}
int bb_cpu_service(void){return adv_cpu_poll();}
bb_result host_cpu_execute(const bb_job *j){CHECK(j->dst<front||j->dst>=front+BB_FRAME_BYTES);++cpu_jobs;ticks+=(uint64_t)j->width*j->height*2;return bb_cpu_execute(j);}
void adv_io_service(void){++poll_count;if(cancel_at&&poll_count>=cancel_at){cancel_at=0;CHECK(adv_command(":adv 999 cancel"));}if(timeout_at&&poll_count>=timeout_at){timeout_at=0;ticks+=180000000100ull;}}
int scene_art_info(unsigned tile,uint32_t *address,unsigned *w,unsigned *h){if(tile!=0&&tile!=4&&tile!=8)return 0;*w=tile==0?31:tile==4?32:16;*h=tile==0?47:tile==4?48:16;*address=BB_SPRITES+tile*0x10000;return 1;}
static void output(const char *line){unsigned n=(unsigned)strlen(line);CHECK(n<510&&lines_n<128);if(n>max_line)max_line=n;strcpy(lines[lines_n++],line);}
static int restore_game(void){++restores;return restore_error?-1:0;}
static const char *last(void){CHECK(lines_n>0);return lines[lines_n-1];}
static uint64_t value(const char *line,const char *name){char k[48];snprintf(k,sizeof k," %s=",name);const char *v=strstr(line,k);CHECK(v);return strtoull(v+strlen(k),0,10);}
static const char *row(const char *tag){for(unsigned i=0;i<lines_n;++i)if(!strncmp(lines[i],tag,strlen(tag)))return lines[i];CHECK(0);return "";}
static void queue(const char *cmd){lines_n=0;CHECK(adv_command(cmd));}
static void run(const char *cmd){queue(cmd);CHECK(adv_pending());adv_service();CHECK(!adv_pending());}
static void pass(const char *cmd){run(cmd);CHECK(strstr(last(),"status=PASS"));if(strstr(cmd," show ")||strstr(cmd," verify ")||strstr(cmd," stress ")){const char *c=row("ADV_CHECK ");CHECK(!value(c,"errors")&&!value(c,"guards")&&!value(c,"source")&&value(c,"actual")==1&&!value(c,"replayed"));CHECK(value(c,"checked")== (strstr(cmd," stress ")?64:1280*720));}}
static uint32_t hash_particles(unsigned n){uint32_t h=2166136261u;uint8_t *a=(uint8_t *)p(0x03800000);for(unsigned i=0;i<n*sizeof(AdvParticle);++i)h=(h^a[i])*16777619u;return h;}
int main(void){void *base=(void *)(uintptr_t)0x01000000;CHECK(VirtualAlloc(base,0x04000000,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE)==base);memset(base,0xa5,0x04000000);
 for(unsigned tile=0;tile<9;tile+=4){uint32_t a;unsigned w,h;CHECK(scene_art_info(tile,&a,&w,&h));for(unsigned y=0;y<h;++y)for(unsigned x=0;x<w;++x)p(a)[y*w+x]=(x==0||y==0||x+1==w||y+1==h)?BB_KEY:(0x125a9c^(x<<16)^(y<<8));}
 adv_init(output,restore_game);CHECK(!adv_command("lab 1 enter"));queue(":adv 1 verify alpha");CHECK(strstr(last(),"code=MODE"));legacy=1;queue(":adv 2 enter");CHECK(strstr(last(),"code=LEGACY_ACTIVE"));legacy=0;
 queue(":adv 3 enter");queue(":adv 4 cancel");adv_service();CHECK(strstr(last(),"status=CANCELLED")&&!adv_active());pass(":adv 5 enter");CHECK(adv_active());
 const char *bad[]={":adv 0 status",":adv 2147483648 status",":adv 1 show alpha 0 7 0 1 2 128 16711935 3 1 0",":adv 1 stress fpga 513 8 0 1 2 3 0 128 1 1 3 1",":adv 1 stress fpga 20001 8 0 1 2 3 0 128 1 0 3 1",":adv 1 stress cpu 1 64 6 1 2 3 0 128 1 0 3 1",":adv 1 stress cpu 1 64 0 1 2 3 0 128 1 0 36001 1",":adv 1 show joint 0 64 0 4294967296 0 128 16711935 3 0 0"};
 for(unsigned i=0;i<sizeof bad/sizeof bad[0];++i){queue(bad[i]);CHECK(strstr(last(),"status=ERROR")&&!adv_pending());}
 pass(":adv 10 verify alpha");CHECK(value(row("ADV_RESULT "),"cases")==256);pass(":adv 11 verify key");CHECK(value(row("ADV_RESULT "),"cases")==8);pass(":adv 12 verify joint");CHECK(value(row("ADV_RESULT "),"cases")==4);
 for(unsigned material=0;material<=3;++material)for(unsigned order=0;order<2;++order){char c[192];snprintf(c,sizeof c,":adv 20 show alpha %u 64 0 1193046 2368640 128 16711935 3 1 %u",material,order);pass(c);}
 pass(":adv 21 show key 1 48 0 123 2368640 128 0 3 0 0");pass(":adv 22 show joint 2 48 0 123 2368640 128 16711935 3 2 0");
 for(unsigned size=8;size<=64;++size){char c[192];snprintf(c,sizeof c,":adv 30 stress fpga 3 %u %u 16711935 4386 16752640 2 128 1 0 2 123",size,size%6);pass(c);CHECK(value(row("ADV_RESULT "),"final")==3);}
 for(unsigned physics=1;physics<=5;++physics){char c[192];snprintf(c,sizeof c,":adv 40 stress fpga 512 8 0 65535 16711935 16763904 1 180 1 %u 3 141",physics);pass(c);uint32_t h=hash_particles(512);snprintf(c,sizeof c,":adv 41 stress cpu 512 8 0 65535 16711935 16763904 1 180 1 %u 3 141",physics);pass(c);CHECK(h==hash_particles(512));}
 pass(":adv 42 stress fpga 20000 8 4 1 2 3 1 255 1 0 2 989");CHECK(value(row("ADV_RESULT "),"initial")==20000&&value(row("ADV_RESULT "),"final")==20000);CHECK(batches>0);
 inject_source=1;run(":adv 50 verify key");CHECK(strstr(last(),"status=ERROR")&&value(row("ADV_CHECK "),"source")>0);
 inject_guard=1;run(":adv 51 verify joint");CHECK(strstr(last(),"status=ERROR")&&value(row("ADV_CHECK "),"guards")>0);
 inject_pixel=1;run(":adv 52 verify alpha");CHECK(strstr(last(),"status=ERROR")&&value(row("ADV_CHECK "),"errors")>0);
 queue(":adv 60 verify alpha");queue(":adv 61 verify key");CHECK(strstr(last(),"code=BUSY"));queue(":adv 62 cancel");adv_service();CHECK(strstr(last(),"status=CANCELLED"));
 queue(":adv 63 stress cpu 20000 64 0 1 2 3 2 128 1 0 3600 9");cancel_at=poll_count+40;adv_service();CHECK(strstr(last(),"status=CANCELLED")&&adv_active());
 queue(":adv 64 stress cpu 20000 64 0 1 2 3 2 128 1 0 3600 9");timeout_at=poll_count+40;adv_service();CHECK(strstr(last(),"code=TIMEOUT")&&adv_active());
 restore_error=1;run(":adv 70 exit");CHECK(strstr(last(),"code=RESTORE")&&adv_active());restore_error=0;pass(":adv 71 exit");CHECK(!adv_active()&&restores==2);queue(":adv 72 status");CHECK(value(row("ADV_STATE "),"active")==0);
 printf("ALL_ADV_PASS checks=%u hw_jobs=%u cpu_jobs=%u batch_jobs=%u max_line=%u swaps=%u\n",checks,jobs,cpu_jobs,batches,max_line,swaps);printf("Hardware and physical timing: NOT_RUN; actual C firmware + driver DMA/display model only.\n");return 0;
}
