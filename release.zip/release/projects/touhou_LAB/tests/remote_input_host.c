#include "remote_input.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
static void packet(RemoteInput *r,unsigned seq,unsigned mask,uint32_t now,unsigned bad){
    unsigned char b[]={0xa5,0x5a,(unsigned char)seq,(unsigned char)mask,(unsigned char)(mask>>8),(unsigned char)(seq^mask^(mask>>8)^0xa7^bad)};
    for(unsigned i=0;i<6;++i)assert(remote_input_feed(r,b[i],now+i));
}
int main(void){
    RemoteInput r;remote_input_init(&r);
    assert(!remote_input_feed(&r,'r',0));assert(!r.held);
    assert(remote_input_feed(&r,0xa5,1));assert(remote_input_feed(&r,0x5a,2));
    assert(remote_input_feed(&r,9,3));assert(!r.held);remote_input_expire(&r,50002);assert(!r.position&&!r.held);
    puts("REMOTE01 PASS partial packet timeout is inert");
    packet(&r,254,REMOTE_LEFT|REMOTE_UP,100000,1);assert(!r.held&&!r.have_sequence);
    packet(&r,254,0x100,100010,0);assert(!r.held&&!r.have_sequence);
    packet(&r,254,REMOTE_LEFT|REMOTE_UP,100020,0);
    assert(r.held==5&&remote_input_pressed(&r)==5&&!remote_input_pressed(&r));
    packet(&r,254,5,170020,0);assert(r.duplicates==1&&!remote_input_pressed(&r));
    packet(&r,254,16,180000,0);assert(r.held==5&&!remote_input_pressed(&r));
    packet(&r,253,16,190000,0);assert(r.held==5&&!remote_input_pressed(&r));
    packet(&r,255,0,200000,0);packet(&r,0,REMOTE_BOMB,200010,0);
    assert(r.held==16&&remote_input_pressed(&r)==16);
    puts("REMOTE02 PASS checksum/mask/stale/same-seq conflict reject; duplicate safe;255-to0");
    remote_input_expire(&r,700014);assert(r.held==16);
    remote_input_expire(&r,700015);assert(!r.held&&!r.have_sequence&&!remote_input_pressed(&r));
    packet(&r,0,REMOTE_RIGHT,700020,0);assert(r.held==2&&remote_input_pressed(&r)==2);
    puts("REMOTE03 PASS 500ms release and reconnect sequence reset");
    remote_input_init(&r);uint32_t epoch=UINT32_MAX-100;
    packet(&r,1,REMOTE_DOWN,epoch,0);
    remote_input_expire(&r,epoch+499999u);assert(r.held==8);
    remote_input_expire(&r,epoch+500005u);assert(!r.held&&!r.have_sequence);
    puts("REMOTE04 PASS uint32 timer wrap and queued-edge expiry");
    remote_input_init(&r);
    assert(remote_input_feed(&r,0xa5,0));assert(remote_input_feed(&r,0xa5,1));assert(remote_input_feed(&r,0x5a,2));
    const unsigned char tail[]={13,32,0,13^32^0xa7};
    for(unsigned i=0;i<4;++i)assert(remote_input_feed(&r,tail[i],3+i));
    assert(r.held==32&&remote_input_pressed(&r)==32);
    puts("REMOTE05 PASS split packet and overlapping sync recovery");
    puts("ALL_REMOTE_INPUT_PASS");return 0;
}
