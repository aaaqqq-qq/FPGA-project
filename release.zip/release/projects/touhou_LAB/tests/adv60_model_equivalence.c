#include "adv_model.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct {int32_t x,y;int16_t vx,vy;uint16_t mass;uint8_t size,color,alive,pad;} OldParticle;
void old_init(OldParticle *,unsigned,unsigned,unsigned,uint32_t);
void old_step(OldParticle *,unsigned,unsigned,AdvStats *);
static AdvParticle current[ADV_MAX],generic[ADV_MAX];static OldParticle previous[ADV_MAX];
static unsigned cases;static unsigned long long checks,ticks;
#define CK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL line%d %s case%u tick%llu\n",__LINE__,#x,cases,ticks);exit(1);}}while(0)
static void equal(unsigned n,const AdvStats *a,const AdvStats *b){CK(a->pairs==b->pairs&&a->collisions==b->collisions&&a->merges==b->merges&&a->count==b->count&&a->minimum==b->minimum&&a->maximum==b->maximum);
 for(unsigned i=0;i<n;++i){AdvParticle *x=current+i;OldParticle *y=previous+i;CK(x->x==(int64_t)y->x*16&&x->y==(int64_t)y->y*16);CK(x->vx==y->vx&&x->vy==y->vy);CK(adv_mass(x)==y->mass&&adv_alive(x)==y->alive&&x->size==y->size&&x->color==y->color);}}
static void scenario(unsigned n,unsigned size,unsigned mode,uint32_t seed,unsigned frames){++cases;adv_particles_init(current,n,size,16,seed);memcpy(generic,current,n*sizeof(*current));old_init(previous,n,size,16,seed);AdvStats a={0,0,0,n,n,n},b=a,c=a;equal(n,&a,&b);
 for(unsigned f=0;f<frames;++f){old_step(previous,n,mode,&b);if(mode)adv_particles_step(current,n,mode,&a);else{adv_particles_step_draw(current,n,size);adv_particles_step(generic,n,0,&c);CK(memcmp(current,generic,n*sizeof(*current))==0);}ticks+=n;equal(n,&a,&b);}}
int main(void){CK(sizeof(AdvParticle)==16&&offsetof(AdvParticle,color)==14&&offsetof(AdvParticle,size)==15);CK(sizeof(OldParticle)==20);
 for(unsigned size=8;size<=64;++size)for(unsigned n=0;n<=9;++n)scenario(n,size,0,0x734a9281u+n*31+size,64);
 for(unsigned k=0;k<3;++k)scenario(20000,k==0?8:k==1?56:64,0,0xffffffffu-k,128);
 unsigned sizes[]={8,9,31,56,64};uint32_t seeds[]={1,42,0xffffffffu};for(unsigned m=1;m<=5;++m)for(unsigned z=0;z<5;++z)for(unsigned q=0;q<3;++q)scenario(512,sizes[z],m,seeds[q],64);
 printf("ADV60_MODEL_PASS cases=%u particle_ticks=%llu assertions=%llu old_Q8_state_and_statistics_equal=1\n",cases,ticks,checks);return 0;}
