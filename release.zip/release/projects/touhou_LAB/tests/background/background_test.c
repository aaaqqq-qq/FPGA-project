#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "background.h"
static uint32_t classic(unsigned x,unsigned y){
 unsigned c=0x0b0d1c;
 if(x>=32&&x<1056&&y>=16&&y<704){
  unsigned shade=(y-16)*14/688;c=((10+shade)<<16)|((13+shade)<<8)|(30+shade*2);
  int mx=(int)x-955,my=(int)y-92;if(mx*mx+my*my<44*44)c=0x3a3948;if(mx*mx+my*my<40*40)c=0x625f70;
  unsigned h=x*19349663u^y*73856093u;if((h&2047)==7&&y<290)c=0x7c7a94;
  int edge=x<544?(int)x-32:1055-(int)x;if(edge<(int)((y/23*17+9)%29)&&y>180)c=0x080e18;
 }if(x==30||x==1057)c=0x64607c;return c;
}
static uint32_t render(unsigned enabled){
 uint32_t *buf=malloc((1280u*720+32)*4);assert(buf);for(unsigned i=0;i<1280u*720+32;i++)buf[i]=0xa5a5a5a5;
 background_prepare(enabled);uint32_t hash=2166136261u;unsigned bright=0;
 for(unsigned y=0;y<720;y++)for(unsigned x=0;x<1280;x++){
  uint32_t c=background_pixel(x,y);buf[16+y*1280+x]=c;hash=(hash^c)*16777619u;
  if(!enabled)assert(c==classic(x,y));
  if(x<32||x>=1056||y<16||y>=704)assert(c==((x==30||x==1057)?0x64607c:0x0b0d1c));
  unsigned rr=(c>>16)&255,gg=(c>>8)&255,bb=c&255;assert(rr<=180&&gg<=180&&bb<=180);
  if(rr>120||gg>120||bb>120)++bright;
 }
 for(unsigned i=0;i<16;i++)assert(buf[i]==0xa5a5a5a5&&buf[16+1280u*720+i]==0xa5a5a5a5);
 assert(bright<6000);assert(background_pixel(0xffffffffu,0)==0x0b0d1c);assert(background_pixel(0,0xffffffffu)==0x0b0d1c);
 free(buf);return hash;
}
int main(void){uint32_t a=render(1),b=render(1),old=render(0),c=render(1);assert(a==b&&a==c&&a!=old);printf("BACKGROUND PASS deterministic=%08x classic=%08x guard/boundary/lowcontrast/toggle\n",a,old);return 0;}
