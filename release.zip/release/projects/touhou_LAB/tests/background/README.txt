Cached moonlit 2.5D background.

python scripts/test_background.py --host-cc <host GCC>
python scripts/test_scene.py --host-cc <host GCC>

The first verifies the CURRENT background function deterministically for both
enabled depth and classic fallback, all921600 screen coordinates, UI/field
boundaries, brightness restraint, out-of-range coordinates and framebuffer guards.
The second compares64 complete CPU/emulated-hardware frames against full redraw,
including the prepared depth background. These are host models, not board timing.

Preview uses tests/background/preview.c + src/background.c to produce actual
PPM pixels; results/background/background_depth.png is a PNG conversion of that
PPM, not AI artwork. Cache arrays occupy11220 bytes. No heap, floats, trigonometric
calls, per-frame full-screen blend layers, or extra sprite characters are added.

background_prepare(enable) is called only during scene_init. Changing the config
flag takes effect when scene_init is explicitly rerun; no implicit per-frame
regeneration is performed. Existing batch/copy background restoration is reused.
