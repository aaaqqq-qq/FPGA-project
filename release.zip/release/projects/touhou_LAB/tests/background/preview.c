#include <stdio.h>
#include <stdlib.h>
#include "background.h"
int main(int argc,char **argv){
 const char *name=argc>1?argv[1]:"background.ppm";background_prepare(1);
 FILE *f=fopen(name,"wb");if(!f)return 2;fprintf(f,"P6\n1280 720\n255\n");
 for(unsigned y=0;y<720;y++)for(unsigned x=0;x<1280;x++){
  unsigned c=background_pixel(x,y);unsigned char p[3]={(unsigned char)(c>>16),(unsigned char)(c>>8),(unsigned char)c};fwrite(p,1,3,f);
 }fclose(f);return 0;
}