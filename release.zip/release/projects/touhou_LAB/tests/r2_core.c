#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "battle.c"
static unsigned checks;
#define CK(x) do{++checks;if(!(x)){printf("FAIL %s:%d %s\n",__FILE__,__LINE__,#x);return 1;}}while(0)
static Stage saved_stage;
static Effect saved_effects[SHOT_CAPACITY];
static Shot expected_shots[SHOT_CAPACITY];
static Effect expected_effects[SHOT_CAPACITY];
static uint8_t expected_owners[SHOT_CAPACITY];
static Vm reference_vm[360];
static unsigned rng=3;
static unsigned rnd(void){rng=rng*1664525u+1013904223u;return rng;}
static void fresh(void){game_config_defaults();battle_set_legacy(0);player_reset(512,620);effects_reset();battle_reset(0,SHOT_CAPACITY);}
static int test_hot(void){
 fresh();GameConfig before=game_cfg;
 CK(!game_config_set("boss_count",7)&&!memcmp(&before,&game_cfg,sizeof(before)));
 CK(!game_config_set("logic_hz",120)&&!memcmp(&before,&game_cfg,sizeof(before)));
 CK(!game_config_set("density_low_pct",80)&&!memcmp(&before,&game_cfg,sizeof(before)));
 CK(!game_config_set("boss_move_den[2]",0)&&!memcmp(&before,&game_cfg,sizeof(before)));
 CK(!game_config_set("boss_move_num[6]",2)&&!memcmp(&before,&game_cfg,sizeof(before)));
 CK(!game_config_set("boss_move_num[0]garbage",2)&&!memcmp(&before,&game_cfg,sizeof(before)));
 CK(!game_config_set("level_threshold[2]",7000)&&!memcmp(&before,&game_cfg,sizeof(before)));
 CK(!game_config_set("level_threshold[1]",1)&&!memcmp(&before,&game_cfg,sizeof(before)));
 CK(game_config_set("density_high_pct",85)&&game_cfg.density_high_pct==85);
 CK(game_config_set("boss_bullets_num[1]",3)&&game_cfg.boss_bullets_num[1]==3);
 CK(game_config_set("hud_dirty_enabled",0)&&!game_cfg.hud_dirty_enabled);
 CK(game_config_set("level_threshold[2]",1200)&&game_cfg.level_threshold[2]==1200);
 puts("R2_HOT PASS atomic whitelist scalar/array limits and fixed clock/bounded boss-count whitelist");return 0;
}
static int test_density(void){
 fresh();stage.limit=100;stage.count=80;density_update();CK(!battle_density_slow);
 stage.count=81;density_update();CK(battle_density_slow);
 stage.count=75;density_update();CK(battle_density_slow);
 stage.count=70;density_update();CK(!battle_density_slow);
 stage.count=90;density_update();game_cfg.adaptive_density=0;density_update();CK(!battle_density_slow);
 for(unsigned pass=0;pass<2;++pass){
  fresh();game_cfg.boss_profiles_enabled=0;game_cfg.adaptive_density=pass;game_cfg.near_enabled=0;
  battle_density_slow=1;
  for(unsigned f=0;f<360;++f){
   run(0,512,620);
   if(!pass)reference_vm[f]=*VM(0);else CK(!memcmp(&reference_vm[f],VM(0),sizeof(Vm)));
  }
  if(pass)CK(battle_density_skips>0);
 }
 fresh();stage.limit=20000;stage.count=17000;density_update();CK(battle_density_slow);
 unsigned emitted=stage.emitted;bosses[0].state=BOSS_ENRAGED;battle_burst(0,512);
 CK(stage.emitted-emitted==768); /* protected threshold burst ignores density limiter */
 puts("R2_DENSITY PASS80/70 hysteresis, unchanged360tick VM/movement, threshold burst retained");return 0;
}
static int test_profiles(void){
 fresh();Vm a={0},b={0};movement(0,&a,120,100,100,1);movement(2,&b,120,100,100,1);
 CK(a.mn==96&&b.mn==80);
 Volley q={0};q.n=10;q.layers=1;q.type=1;q.color=5;q.speed1=q.speed2=65536;
 bosses[0].state=BOSS_ENRAGED;bosses[1].state=BOSS_ENRAGED;bosses[2].state=BOSS_ENRAGED;
 volley_fire(0,&q);CK(bosses[0].shots_spawned==15);
 volley_fire(1,&q);CK(bosses[1].shots_spawned==20);
 volley_fire(2,&q);CK(bosses[2].shots_spawned==15);
 unsigned n=stage.emitted;battle_burst(0,100);CK(stage.emitted-n==150);
 game_cfg.boss_profiles_enabled=0;n=stage.emitted;battle_burst(0,100);CK(stage.emitted-n==100);
 n=stage.emitted;volley_fire(1,&q);CK(stage.emitted-n==15);
 battle_set_legacy(1);n=stage.emitted;volley_fire(1,&q);CK(stage.emitted-n==10);
 puts("R2_PROFILES PASS Rumia denser rings, Cirno volley, Meiling movement, disable/legacy bypass");return 0;
}
static int test_near(void){
 const unsigned ns[]={64,512,4096,20000,5000,20000,20000};
 const int pys[]={85,86,172,344,344,620,16};
 for(unsigned trial=0;trial<7;++trial){
  fresh();unsigned n=ns[trial];stage.count=n;
  for(unsigned i=0;i<n;++i){
   int x=4+(int)(rnd()%(ARENA_W-8)),y=4+(int)(rnd()%(ARENA_H-8));
   if(trial==4||trial==5)y=344;
   stage.shots[i]=(Shot){x*Q,y*Q,(int16_t)((int)(rnd()%6001)-3000),(int16_t)((int)(rnd()%6001)-3000),(uint16_t)(rnd()%40),54,0};
   effects[i]=(Effect){0,0,16384,4096,(uint16_t)(i%4?0:12),(uint16_t)(i%8)};
   stage.owner[i]=(uint8_t)(i%3);
   if(trial==4){stage.shots[i].vx=stage.shots[i].vy=0;effects[i].turn=0;}
  }
  stage.shots[0]=(Shot){512*Q,pys[trial]*Q,0,0,20,54,0};effects[0].delay=0;
  saved_stage=stage;memcpy(saved_effects,effects,sizeof(effects));
  game_cfg.near_enabled=0;battle_hit=battle_grazes=0;simulate_bullets(512,pys[trial]);
  unsigned count=stage.count,hit=battle_hit,grazes=battle_grazes;
  memcpy(expected_shots,stage.shots,count*sizeof(Shot));memcpy(expected_effects,effects,count*sizeof(Effect));memcpy(expected_owners,stage.owner,count);
  stage=saved_stage;memcpy(effects,saved_effects,sizeof(effects));
  game_cfg.near_enabled=1;battle_hit=battle_grazes=0;simulate_bullets(512,pys[trial]);
  CK(stage.count==count&&battle_hit==hit&&battle_grazes==grazes);
  CK(!memcmp(expected_shots,stage.shots,count*sizeof(Shot)));
  CK(!memcmp(expected_effects,effects,count*sizeof(Effect))&&!memcmp(expected_owners,stage.owner,count));
  if(trial==3)CK(battle_near_candidates<count/2);
  if(trial==4)CK(battle_near_fallbacks==1&&battle_near_candidates==count);
  if(trial==5)CK(battle_near_candidates<count); /* overflow in unrelated bucket does not force fallback */
  printf("R2_NEAR trial=%u n=%u candidates=%u fallback=%u\n",trial,count,battle_near_candidates,battle_near_fallbacks);
 }
 fresh();stage.count=4;for(unsigned i=0;i<4;++i){stage.owner[i]=(uint8_t)(i%2);stage.shots[i].x=(int)i;effects[i].angle=(int16_t)(i+100);}
 CK(battle_clear_owner(0)==2&&stage.count==2);
 for(unsigned i=0;i<stage.count;++i)CK(stage.owner[i]==1&&effects[i].angle==stage.shots[i].x+100);
 CK(battle_clear_owner(3)==0&&battle_clear_owner(1)==2&&stage.count==0);
 puts("R2_NEAR PASS exact movement/contact/graze/compaction; overflow fallback and safe owner clear");return 0;
}
static void homing_init(void){
 fresh();bosses[0].state=BOSS_NORMAL;bosses[0].entered=1;bosses[0].vulnerable=1;bosses[0].x=300;bosses[0].y=100;
 bosses[1].state=BOSS_NORMAL;bosses[1].entered=1;bosses[1].vulnerable=1;bosses[1].x=800;bosses[1].y=100;
 PlayerShot *s=&player_shots[0];*s=(PlayerShot){0};s->live=1;s->kind=PLAYER_KIND_HOMING;s->x=500;s->y=600;s->fx=500*256;s->fy=600*256;s->vy=-512;s->target=-1;
}
static int test_homing(void){
 homing_init();for(unsigned t=0;t<8;++t)player_shots_tick();CK(player_homing_retargets==2&&player_shots[0].age==8);
 CK(player_shots[0].y<600);
 homing_init();player_shots_tick();CK(player_shots[0].target==0&&player_homing_retargets==1);
 bosses[0].dead=1;bosses[0].state=BOSS_DEAD;player_shots_tick();CK(player_shots[0].target==1&&player_homing_retargets==2);
 bosses[1].vulnerable=0;player_shots_tick();CK(!player_shots[0].target_valid&&player_homing_retargets==3);
 bosses[0].dead=0;bosses[0].state=BOSS_NORMAL;player_shots_tick();CK(player_shots[0].target==0&&player_homing_retargets==4);
 homing_init();game_cfg.homing_retarget_ticks=1;for(unsigned t=0;t<8;++t)player_shots_tick();CK(player_homing_retargets==8);
 puts("R2_HOMING PASS4tick cache, every-tick movement, immediate dead/untargetable/missing reacquire,1tick reference");return 0;
}
static int test_private_hash(void){
 fresh();uint32_t h=battle_state_hash(2166136261u);
 ++VM(0)->c.time;CK(battle_state_hash(2166136261u)!=h);--VM(0)->c.time;CK(battle_state_hash(2166136261u)==h);
 ++vmb[0].density_acc;CK(battle_state_hash(2166136261u)!=h);--vmb[0].density_acc;
 ++vmb[1].fire_acc;CK(battle_state_hash(2166136261u)!=h);--vmb[1].fire_acc;
 vmb[2].pending_count=1;CK(battle_state_hash(2166136261u)!=h);vmb[2].pending_count=0;
 battle_density_slow=1;CK(battle_state_hash(2166136261u)!=h);battle_density_slow=0;
 effects[0].target=123;CK(battle_state_hash(2166136261u)==h); /* inactive storage excluded */
 stage.count=1;uint32_t active=battle_state_hash(2166136261u);effects[0].target=124;CK(battle_state_hash(2166136261u)!=active);
 puts("R2_HASH PASS private VM/pending/cadence/density andactiveEffects protected");return 0;
}
int main(void){if(test_hot()||test_density()||test_profiles()||test_near()||test_homing()||test_private_hash())return 1;printf("R2_CORE PASS checks=%u\n",checks);return 0;}
