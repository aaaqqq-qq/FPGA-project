/* PC host preview of the real game renderer. Not a board screenshot.
 * Maps the firmware's fixed DDR addresses with VirtualAlloc, executes the
 * bitblt jobs synchronously, and calls the production render()/logic(). */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <stdint.h>

#define main firmware_main
#include "game.c"
#undef main


static uint32_t regs[64];
static unsigned pending;

static void render_job(const bb_job *j);
uint32_t bb_read(unsigned reg) {
    if (reg == 0x4c) return 2;
    if (reg == BB_STATUS) {
        if (pending) {
            bb_job j;
            memcpy(&j, &regs[BB_OP / 4], sizeof(j));
            render_job(&j);
            pending = 0;
            regs[BB_STATUS / 4] = BB_DONE;
        }
        return regs[reg / 4];
    }
    return regs[reg / 4];
}
void bb_write(unsigned reg, uint32_t v) {
    if (reg == BB_CMD) { pending = 1; regs[BB_STATUS / 4] = BB_BUSY; return; }
    if (reg == BB_STATUS) { regs[reg / 4] &= ~v; return; }
    regs[reg / 4] = v;
}
uint64_t bb_ticks(void) { static uint64_t t; return ++t; }
uint32_t bb_us(uint64_t t) { return (uint32_t)t; }
bb_result bb_probe(void) { return BB_OK; }
bb_result bb_publish(void) { return BB_OK; }
void bb_acquire(void) {}
bb_result bb_swap_wait(uint32_t fb, uint32_t t) { (void)fb; (void)t; return BB_OK; }
bb_result bb_cpu_execute(const bb_job *j) { render_job(j); return BB_OK; }

unsigned gpio_getInput(unsigned g) { (void)g; return 15; }
void gpio_setOutputEnable(unsigned g, unsigned m) { (void)g; (void)m; }
void bsp_init(void) {}
void bsp_printf(const char *fmt, ...) { va_list ap; va_start(ap, fmt); vprintf(fmt, ap); va_end(ap); }
unsigned uart_writeAvailability(unsigned u) { (void)u; return 0; }
void uart_write(unsigned u, unsigned c) { (void)u; (void)c; }
unsigned uart_readOccupancy(unsigned u) { (void)u; return 0; }
char uart_read(unsigned u) { (void)u; return 0; }
unsigned csr_read(unsigned c) { return c; }

static void render_job(const bb_job *j) {
    if (j->op == 2) {
        bb_job bg = *j; bg.op = BB_COPY_OP; bg.flags = 0; render_job(&bg);
        const uint32_t *list = (const uint32_t *)(uintptr_t)&stage.shots[0];
        unsigned count = regs[0x44 / 4];
        unsigned base = regs[0x50 / 4];
        uint32_t art = regs[0x48 / 4];
        for (unsigned i = 0; i < count; ++i) {
            int x = (int32_t)list[4 * i] / Q - 4;
            int y = (int32_t)list[4 * i + 1] / Q - 4;
            unsigned tile = ((list[4 * i + 3] >> 16) & 255) - base;
            if (x < 0 || y < 0 || x + 8 > 1024 || y + 8 > 688) continue;
            bb_job s = {BB_COPY_OP, art + tile * 256,
                        j->dst + (unsigned)y * j->dst_stride + (unsigned)x * 4,
                        32, j->dst_stride, 8, 8, 0, j->alpha, j->key, j->flags};
            render_job(&s);
        }
        return;
    }
    for (unsigned y = 0; y < j->height; ++y) for (unsigned x = 0; x < j->width; ++x) {
        uint32_t *d = (uint32_t *)(uintptr_t)(j->dst + y * j->dst_stride + x * 4);
        uint32_t s = j->op == BB_COPY_OP ? *(uint32_t *)(uintptr_t)(j->src + y * j->src_stride + x * 4) : j->fill;
        if (j->op == BB_COPY_OP && (j->flags & BB_KEY_ENABLE) && (s & 0xffffff) == j->key) continue;
        if (j->flags & BB_ALPHA_ENABLE) *d = bb_blend(s, *d, j->alpha); else *d = s;
    }
}

static void ppm(const char *path, uint32_t fb) {
    FILE *f = fopen(path, "wb");
    if (!f) { perror(path); exit(2); }
    fprintf(f, "P6\n1280 720\n255\n");
    for (unsigned y = 0; y < 720; ++y) for (unsigned x = 0; x < 1280; ++x) {
        uint32_t c = *(volatile uint32_t *)(uintptr_t)(fb + y * BB_SCREEN_STRIDE + x * 4);
        unsigned char rgb[3] = {(unsigned char)(c >> 16), (unsigned char)(c >> 8), (unsigned char)c};
        fwrite(rgb, 1, 3, f);
    }
    fclose(f);
}

static void shot(const char *name) {
    printf("shot %s\n", name); fflush(stdout);
    render(BB_FB0);
    char path[256];
    snprintf(path, sizeof(path), "results/preview/%s.ppm", name);
    ppm(path, BB_FB0);
    printf("PREVIEW %s\n", path);
}

static unsigned border_diff(uint32_t fb, int *firstx, int *firsty) {
    unsigned n=0;
    for(unsigned y=0;y<720;y++)for(unsigned x=0;x<1072;x++) {
        if(x>=32 && x<1056 && y>=16 && y<704)continue;
        uint32_t a=*(uint32_t *)(uintptr_t)(fb+y*BB_SCREEN_STRIDE+x*4);
        uint32_t b=*(uint32_t *)(uintptr_t)(0x01A00000u+y*BB_SCREEN_STRIDE+x*4);
        if(a!=b){if(!n){*firstx=x;*firsty=y;}n++;}
    }
    return n;
}
static void report(const char *label,uint32_t fb) {
    int x=-1,y=-1; unsigned n=border_diff(fb,&x,&y);
    printf("%s border_dirty=%u first=(%d,%d)\n",label,n,x,y); if(n)exit(3);
}
int main(void) {
    if (!VirtualAlloc((void *)0x01000000, 0x1200000, MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE))return 2;
    if(VirtualAlloc((void *)(uintptr_t)0x07000000u,0x00400000u,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE)!=(void *)(uintptr_t)0x07000000u)return 2;
    game_config_defaults();scene_init();choice=0;start();demo_invincible=1;hardware=1;
    for(unsigned k=0;k<3;k++)bosses[k].state=BOSS_WAIT;
    stage.count=0;player.x=PLAYER_MIN_X;player.y=100;
    render(BB_FB0);render(BB_FB1);report("upgrade_control",BB_FB0);
    player.upgrade_anim=48;render(BB_FB0);
    player.upgrade_anim=0;render(BB_FB1);render(BB_FB0);
    report("upgrade_expired",BB_FB0);
    ppm("D:/FPGA/reviews/phase_battle_fix_20261029/hdmi_rumia_ultimate/results/review_render_regression/upgrade_expired.ppm",BB_FB0);

    scene_init();choice=0;start();demo_invincible=1;hardware=1;stage.count=0;
    for(unsigned k=0;k<3;k++)bosses[k].state=BOSS_WAIT;
    player.upgrade_anim=0;
    render(BB_FB0);render(BB_FB1);report("entry_control",BB_FB0);
    bosses[1].state=BOSS_ENTER;bosses[1].x=500;bosses[1].y=30;render(BB_FB0);
    bosses[1].state=BOSS_NORMAL;bosses[1].y=120;render(BB_FB1);render(BB_FB0);
    report("entry_finished",BB_FB0);
    ppm("D:/FPGA/reviews/phase_battle_fix_20261029/hdmi_rumia_ultimate/results/review_render_regression/entry_finished.ppm",BB_FB0);
    scene_init();choice=0;start();demo_invincible=1;hardware=1;
    bosses[0].vulnerable=1;battle_apply_damage(0,2000,1);
    for(unsigned t=0;t<game_cfg.enrage_intro_ticks+game_cfg.enter_ticks+5;t++) {
        logic();render((t&1)?BB_FB1:BB_FB0);
    }
    render(BB_FB0);render(BB_FB1);
    report("natural_entry_FB0",BB_FB0);report("natural_entry_FB1",BB_FB1);
    ppm("D:/FPGA/reviews/phase_battle_fix_20261029/hdmi_rumia_ultimate/results/review_render_regression/natural_entry.ppm",BB_FB0);    return 0;
}

