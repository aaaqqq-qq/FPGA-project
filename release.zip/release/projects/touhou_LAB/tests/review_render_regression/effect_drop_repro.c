#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <stdint.h>
#include <assert.h>

#define main firmware_main
#include "game.c"
#undef main

unsigned scene_list_us, scene_batch_cycles, scene_jobs;
void scene_init(void) {}
void scene_begin(uint32_t fb, unsigned hw) { (void)fb; (void)hw; }
void scene_tile(int x, int y, unsigned tile, unsigned alpha) { (void)x; (void)y; (void)tile; (void)alpha; }
void scene_rect(int x, int y, int w, int h, uint32_t c) { (void)x; (void)y; (void)w; (void)h; (void)c; }
void scene_text(int x, int y, const char *t, uint32_t c, unsigned s) { (void)x; (void)y; (void)t; (void)c; (void)s; }
void scene_end(void) {}
void scene_set_batch(unsigned e) { (void)e; }
void scene_batch_shots(void) {}
void scene_batch_snapshot_ready(void) {}
unsigned scene_cancelled(void) { return 0; }

static uint64_t host_ticks;
uint32_t bb_read(unsigned reg) { (void)reg; return 0; }
void bb_write(unsigned reg, uint32_t v) { (void)reg; (void)v; }
uint64_t bb_ticks(void) { return ++host_ticks; }
uint32_t bb_us(uint64_t t) { return (uint32_t)t; }
bb_result bb_probe(void) { return BB_OK; }
bb_result bb_publish(void) { return BB_OK; }
void bb_acquire(void) {}
bb_result bb_swap_wait(uint32_t fb, uint32_t t) { (void)fb; (void)t; return BB_OK; }

unsigned gpio_getInput(unsigned g) { (void)g; return 15; }
void gpio_setOutputEnable(unsigned g, unsigned m) { (void)g; (void)m; }
void bsp_init(void) {}
void bsp_printf(const char *fmt, ...) { va_list ap; va_start(ap, fmt); vprintf(fmt, ap); va_end(ap); }
unsigned uart_writeAvailability(unsigned u) { (void)u; return 0; }
void uart_write(unsigned u, unsigned c) { (void)u; (void)c; }
unsigned uart_readOccupancy(unsigned u) { (void)u; return 0; }
char uart_read(unsigned u) { (void)u; return 0; }
unsigned csr_read(unsigned c) { return c; }

static int failures;
static void check(int ok, const char *test, int line) {
    if (!ok) {
        printf("%s FAIL line=%d\n", test, line);
        ++failures;
    }
}
#define CK(c, t) check((c), (t), __LINE__)

static void new_run(void) {
    game_config_defaults();
    choice = 0; capacity_level = 14; hardware = 1; demo_invincible = 0; autoplay = 0;
    host_ticks = 0;
    start();
    demo_invincible = 1;
    player.spawn_invuln = 0;
}

static unsigned count_shots(unsigned kind) {
    unsigned n = 0;
    for (unsigned i = 0; i < PLAYER_SHOT_CAPACITY; ++i)
        if (player_shots[i].live && player_shots[i].kind == kind) ++n;
    return n;
}

static void test_t01(void) {
    new_run();
    CK(mode == PLAY, "T01");
    CK(bosses[0].state == BOSS_NORMAL, "T01");
    CK(bosses[1].state == BOSS_WAIT && bosses[2].state == BOSS_WAIT, "T01");
    CK(bosses[1].entered == 0 && bosses[2].entered == 0, "T01");
    for (unsigned i = 0; i < 240; ++i) logic();
    CK(bosses[0].fired > 0, "T01");
    CK(bosses[1].fired == 0 && bosses[2].fired == 0, "T01");
    for (unsigned i = 0; i < stage.count; ++i)
        CK(stage.owner[i] != 1 && stage.owner[i] != 2, "T01");
    CK(battle_apply_damage(1, 10, 0) == 0, "T01");
    CK(battle_apply_damage(2, 10, 0) == 0, "T01");
    CK(!battle_targetable(1) && !battle_targetable(2), "T01");
    CK(bosses[1].hp == 3000 && bosses[2].hp == 3000, "T01");
    printf("T01 PASS\n");
}

static void test_t02(void) {
    new_run();
    bosses[0].vulnerable = 1;
    bosses[0].hp = 1501;
    player.score = 0;
    CK(battle_apply_damage(0, 1, 0) == 1, "T02");
    CK(bosses[0].hp == 1500 && bosses[0].state == BOSS_ENRAGE_INTRO, "T02");
    CK(player.score == 1, "T02");
    CK(battle_apply_damage(0, 5000, 0) == 0, "T02");

    new_run();
    bosses[0].vulnerable = 1;
    bosses[0].hp = 1500;
    player.score = 0;
    CK(battle_apply_damage(0, 10, 0) == 0, "T02");
    CK(bosses[0].state == BOSS_ENRAGE_INTRO && player.score == 0, "T02");
    CK(battle_apply_damage(0, 10, 0) == 0, "T02");

    new_run();
    bosses[0].vulnerable = 1;
    bosses[0].hp = 1499;
    CK(battle_apply_damage(0, 10, 0) == 0, "T02");
    CK(bosses[0].state == BOSS_ENRAGE_INTRO, "T02");

    new_run();
    bosses[0].vulnerable = 1;
    bosses[0].hp = 3000;
    player.score = 0;
    CK(battle_apply_damage(0, 100000, 0) == 1500, "T02");
    CK(bosses[0].hp == 1500 && bosses[0].state == BOSS_ENRAGE_INTRO, "T02");
    CK(bosses[0].dead == 0, "T02");
    CK(player.score == 1500, "T02");
    CK(battle_apply_damage(0, 100000, 0) == 0, "T02");
    printf("T02 PASS\n");
}

static void test_t03(void) {
    new_run();
    bosses[0].vulnerable = 1;
    battle_apply_damage(0, 2000, 0);
    for (unsigned i = 0; i < game_cfg.enrage_intro_ticks; ++i) battle_step(512, 620);
    CK(bosses[0].state == BOSS_ENRAGED && bosses[0].hp == 3000, "T03");
    CK(summon_done == 1 && bosses[1].state == BOSS_ENTER, "T03");
    unsigned summoned = summon_done;
    for (unsigned i = 0; i < 10; ++i) battle_step(512, 620);
    bosses[0].hp = 3000;
    battle_apply_damage(0, 1500, 0);
    CK(bosses[0].state == BOSS_ENRAGED && bosses[0].hp == 1500, "T03");
    CK(summon_done == summoned && bosses[1].state == BOSS_ENTER, "T03");
    bosses[0].script_ticks = 1499;
    battle_step(512, 620);
    CK(bosses[0].state == BOSS_ENRAGED && bosses[0].enrage_done == 1, "T03");
    CK(summon_done == 1, "T03");
    bosses[0].hp = 1;
    CK(battle_apply_damage(0, 5, 0) == 1, "T03");
    CK(bosses[0].state == BOSS_DEAD && bosses[0].dead == 1, "T03");
    CK(battle_apply_damage(0, 5, 0) == 0, "T03");
    printf("T03 PASS\n");
}

static void test_t04(void) {
    new_run();
    bosses[0].vulnerable = 1;
    battle_apply_damage(0, 2000, 0);
    for (unsigned i = 0; i < game_cfg.enrage_intro_ticks; ++i) battle_step(512, 620);
    CK(bosses[1].state == BOSS_ENTER && bosses[2].state == BOSS_ENTER, "T04");
    CK(battle_apply_damage(1, 100, 0) == 0, "T04");
    CK(battle_apply_damage(2, 100, 0) == 0, "T04");
    for (unsigned i = 0; i < game_cfg.enter_ticks; ++i) battle_step(512, 620);
    CK(bosses[1].state == BOSS_NORMAL && bosses[2].state == BOSS_NORMAL, "T04");
    CK(bosses[1].entered && bosses[2].entered, "T04");
    for (unsigned k = 1; k < 3; ++k) {
        bosses[k].hp = 1501; bosses[k].vulnerable = 1;
        CK(battle_apply_damage(k, 1, 0) == 1, "T04");
        CK(bosses[k].state == BOSS_ENRAGE_INTRO, "T04");
        for (unsigned i = 0; i < game_cfg.enrage_intro_ticks; ++i) battle_step(512, 620);
        CK(bosses[k].state == BOSS_ENRAGED, "T04");
        CK(bosses[k].hp == (int)game_cfg.boss_half_hp, "T04");
    }
    const unsigned order[3] = {2, 1, 0};
    for (unsigned i = 0; i < 3; ++i) {
        unsigned k = order[i];
        bosses[k].hp = 1;
        CK(battle_apply_damage(k, 5, 0) == 1, "T04");
        CK(bosses[k].state == BOSS_DEAD, "T04");
    }
    CK(battle_all_defeated() == 1, "T04");
    printf("T04 PASS\n");
}

static void test_t05(void) {
    player_reset(100, 100);
    player.spawn_invuln = 0;
    CK(player.hp == 100, "T05");
    CK(player_take_hit(15) == 15, "T05");
    CK(player.hp == 85 && player.hit_invuln == 48, "T05");
    CK(player_take_hit(15) == 0, "T05");
    CK(player.hp == 85, "T05");
    player_begin_tick();
    CK(player.hit_invuln == 47, "T05");
    player.hit_invuln = 100; player.upgrade_invuln = 10; player.spawn_invuln = 5;
    CK(player_take_hit(15) == 0, "T05");
    CK(player.hit_invuln == 100 && player.upgrade_invuln == 10, "T05");

    new_run();
    demo_invincible = 0;
    player.spawn_invuln = player.hit_invuln = player.bomb_invuln = player.upgrade_invuln = 0;
    player.hp = 100;
    keys = edges = 0;
    stage.count = 5;
    for (unsigned i = 0; i < 5; ++i)
        stage.shots[i] = (Shot){player.x * Q, player.y * Q, 0, 0, 30, 54, 0};
    logic();
    CK(player.hp == 85 && player.hit_invuln > 0, "T05");

    new_run();
    demo_invincible = 0;
    for (unsigned k = 0; k < 3; ++k) { bosses[k].dead = 1; bosses[k].entered = 1; }
    player.hp = 15; player.alive = 1;
    player.spawn_invuln = player.hit_invuln = player.bomb_invuln = player.upgrade_invuln = 0;
    keys = edges = 0;
    stage.count = 1;
    stage.shots[0] = (Shot){player.x * Q, player.y * Q, 0, 0, 30, 54, 0};
    logic();
    CK(mode == LOST, "T05");
    CK(player.hp == 0, "T05");
    printf("T05 PASS\n");
}

static void test_t06(void) {
    player_reset(100, 100);
    player.spawn_invuln = 0; player.hit_invuln = 0;
    player.hp = 50; player.regen_wait = 0; player.regen_accum = 59;
    player_begin_tick();
    CK(player.regen_accum == 60, "T06");
    player_regen_tick();
    CK(player.hp == 55, "T06");
    player.hp = 50; player.regen_wait = 0; player.regen_accum = 0;
    player.hit_invuln = 0;
    CK(player_take_hit(15) == 15, "T06");
    CK(player.regen_wait == 300, "T06");
    unsigned wait_before = player.regen_wait;
    CK(player_take_hit(15) == 0, "T06");
    CK(player.regen_wait == wait_before, "T06");
    for (unsigned i = 0; i < 299; ++i) player_begin_tick();
    CK(player.hp == 35 && player.regen_wait == 1, "T06");
    player_begin_tick();
    CK(player.regen_wait == 0 && player.regen_accum == 60, "T06");
    player_regen_tick();
    CK(player.hp == 40, "T06");
    player.hp = 98; player.regen_wait = 0; player.regen_accum = 60;
    player_regen_tick();
    CK(player.hp == 100, "T06");
    player.hp = 0; player.alive = 0; player.regen_wait = 0; player.regen_accum = 60;
    player_regen_tick();
    CK(player.hp == 0, "T06");
    printf("T06 PASS\n");
}

static void test_t07(void) {
    static const unsigned expect_main[6] = {0, 1, 3, 3, 5, 7};
    static const unsigned expect_home[6] = {0, 0, 0, 2, 2, 4};
    for (unsigned level = 1; level <= 5; ++level) {
        player_reset(100, 100);
        player.spawn_invuln = 0;
        player.score = game_cfg.level_threshold[level];
        player.power_level = level;
        for (unsigned i = 0; i < PLAYER_SHOT_CAPACITY; ++i) player_shots[i].live = 0;
        player_fire_tick(0);
        CK(count_shots(PLAYER_KIND_MAIN) == expect_main[level], "T07");
        CK(count_shots(PLAYER_KIND_HOMING) == expect_home[level], "T07");
    }
    player_reset(100, 100);
    player.spawn_invuln = 0;
    player.score = 12000;
    player.power_level = 1;
    unsigned before = player.upgrades;
    CK(player_update_level() == 1, "T07");
    CK(player.power_level == 5, "T07");
    CK(player.upgrades == before + 1 && player.upgrade_anim == 48, "T07");
    CK(player.upgrade_invuln == 48, "T07");

    for (unsigned i = 0; i < PLAYER_SHOT_CAPACITY; ++i) {
        player_shots[i].live = 1; player_shots[i].kind = PLAYER_KIND_MAIN;
    }
    unsigned rej = player.shot_rejections;
    player_fire_tick(0);
    CK(player.shot_rejections > rej, "T07");
    player.hp = 0; player.alive = 0; player.power_level = 1; player.score = 12000;
    CK(player_update_level() == 0, "T07");
    CK(player.power_level == 1, "T07");
    printf("T07 PASS\n");
}

static void test_t08(void) {
    new_run();
    bosses[0].vulnerable = 1;
    bosses[0].hp = 3000;
    player.score = 0;
    CK(battle_apply_damage(0, 5, 0) == 5, "T08");
    CK(player.score == 5, "T08");
    CK(battle_apply_damage(1, 5, 0) == 0, "T08");
    CK(player.score == 5, "T08");
    bosses[0].hp = 5;
    bosses[0].state = BOSS_ENRAGED; bosses[0].enraged = 1;
    CK(battle_apply_damage(0, 100, 0) == 5, "T08");
    CK(player.score == 10 + 2000, "T08");
    CK(battle_apply_damage(0, 100, 0) == 0, "T08");
    CK(player.score == 10 + 2000, "T08");
    for (unsigned k = 0; k < 3; ++k) bosses[k].dead = 1;

    stage_reset(0, 4096);
    battle_set_legacy(0);
    bosses[0].state = BOSS_NORMAL; bosses[0].entered = 1;
    bosses[0].x = 512; bosses[0].y = 120; bosses[0].hp = 3000; bosses[0].vulnerable = 1;
    stage.count = 1;
    stage.shots[0] = (Shot){(player.x + 13) * Q, player.y * Q, 0, 0, 30, 54, 0};
    stage.owner[0] = 0;
    battle_step(player.x, player.y);
    CK(battle_grazes == 1, "T08");
    player_add_score(battle_grazes * game_cfg.graze_score);
    CK(player.score == 10 + 2000 + 10, "T08");
    battle_step(player.x, player.y);
    CK(battle_grazes == 0, "T08");
    printf("T08 PASS\n");
}

static void test_t09(void) {
    stage_reset(0, 20000);
    bosses[0] = (BattleBoss){.x = 512, .y = 120, .hp = 3000, .state = BOSS_NORMAL, .entered = 1, .vulnerable = 1};
    stage.count = stage.limit;
    unsigned rejected = stage.rejected, requested = stage.requested;
    battle_burst(0, 10);
    CK(stage.count == stage.limit, "T09");
    CK(stage.rejected == rejected + 10, "T09");
    CK(stage.requested == requested + 10, "T09");
    for (unsigned i = 0; i < 10; ++i) battle_step(512, 620);
    CK(stage.count <= stage.limit && stage.fault == 0, "T09");

    stage_reset(0, 4096);
    stage.count = 1;
    stage.shots[0] = (Shot){100 * Q, 100 * Q, 10, 0, game_cfg.bullet_age_max, 54, 0};
    battle_set_legacy(1);
    battle_reset(0, 4096);
    stage.count = 1;
    stage.shots[0] = (Shot){100 * Q, 100 * Q, 10, 0, game_cfg.bullet_age_max, 54, 0};
    battle_step(512, 620);
    CK(stage.shots[0].age == game_cfg.bullet_age_max, "T09");
    battle_set_legacy(0);

    stage_reset(0, 4096);
    stage.count = 600;
    for (unsigned i = 0; i < 600; ++i) {
        stage.shots[i] = (Shot){(player.x + (int)(i % 20) - 10) * Q, (player.y + (int)(i / 20) - 10) * Q, 0, 0, 30, 54, 0};
    }
    stage_stress_step_near(player.x, player.y);
    CK(stage_near_count == 512, "T09");
    CK(stage_near_ready(player.x, player.y) == 0, "T09");
    CK(stage.count == 600, "T09");
    printf("T09 PASS\n");
}

static void test_t10(void) {
    game_config_defaults();
    show_menu();
    CK(mode == MENU, "T10");
    choice = 0;
    start();
    CK(mode == PLAY && player.hp == 100 && player.bombs == 3, "T10");
    demo_invincible = 1; player.spawn_invuln = 0;
    for (unsigned i = 0; i < 180; ++i) logic();
    player.hp = 40; player.score = 4321;
    start();
    CK(player.hp == 100 && player.score == 0 && player.bombs == 3, "T10");
    CK(bosses[0].state == BOSS_NORMAL && bosses[1].state == BOSS_WAIT, "T10");
    CK(summon_done == 0 && stage.count == 0 && effects_active == 0, "T10");
    mode = LOST; CK(mode == LOST, "T10");
    mode = CLEARED; CK(mode == CLEARED, "T10");
    show_menu();
    CK(mode == MENU, "T10");
    printf("T10 PASS\n");
}

static void test_t12(void) {
    game_config_defaults();
    demo_invincible = 0;
    choice = 5; capacity_level = 0; start();
    CK(mode == DODGE && stage.count == 64, "T12");
    player.hit_invuln = 20000;
    for (unsigned i = 0; i < 12000; ++i) logic();
    CK(mode == CLEARED, "T12");
    CK(ticks >= ROUND_FRAMES, "T12");

    game_config_defaults();
    choice = 3; capacity_level = 0; start();
    CK(mode == STRESS && stage.count == 64, "T12");
    stage_stress_step();
    CK(stage.count == 64, "T12");

    new_run();
    for (unsigned k = 0; k < 3; ++k) {
        bosses[k].state = BOSS_ENRAGED; bosses[k].enraged = 1; bosses[k].entered = 1;
        bosses[k].hp = 3000;
    }
    player.power_level = 5;
    player.score = 12000;
    for (unsigned i = 0; i < 600; ++i) logic();
    CK(stage.fault == 0, "T12");
    CK(stage.count <= stage.limit, "T12");
    CK(effects_over_budget <= 1, "T12");
    printf("T12 PASS stress_count=%u peak=%u\n", stage.count, stage.peak);
}

int main(void) {
 game_config_defaults();player_reset(512,620);effects_reset();
 bosses[1].x=400;bosses[1].y=120;bosses[2].x=700;bosses[2].y=120;
 fx_boss_enrage_start(1);fx_boss_enrage_start(2);
 fx_player_hit(player.x,player.y);fx_levelup(player.x,player.y);
 effects_render();
 printf("DEFAULT_STACK expected_jobs=7 expected_area=17152 actual_jobs=%u actual_area=%u over_budget=%u\n",effects_jobs,effects_area,effects_over_budget);
 if(effects_jobs!=6 || effects_area!=13056 || effects_over_budget!=1)return 3; game_cfg.effect_job_budget=0;effects_reset();fx_levelup(512,620);effects_render();
 printf("ZERO_BUDGET upgrade_expected_jobs=2 actual_jobs=%u actual_area=%u over_budget=%u\n",effects_jobs,effects_area,effects_over_budget);
 if(effects_jobs!=0 || effects_area!=0 || effects_over_budget!=2)return 4; return 0;
}
