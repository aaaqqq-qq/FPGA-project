#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef EXACT_REFERENCE
/* New GAME_LOAD hooks stay disabled in the frozen reference oracle. */
unsigned battle_load_active,battle_load_fills,battle_load_recycles,battle_load_keeps;
unsigned battle_load_boss_hits,battle_load_mob_hits,battle_load_player_hits,battle_load_player_damage;
#include "reference_battle_R7p1.c"
#else
#include "../../src/battle.c"
#endif
#include "../../src/effects.c"
#include "enemies.h"
#include "layer_visuals.h"
unsigned scene_sprite_count,scene_jobs;
unsigned scene_layer_commands,scene_layer_peak,scene_layer_clipped,scene_layer_reordered;
void scene_tile(int x,int y,unsigned t,unsigned a){(void)x;(void)y;(void)t;(void)a;}
void scene_rect(int x,int y,int w,int h,uint32_t c){(void)x;(void)y;(void)w;(void)h;(void)c;}
void scene_text(int x,int y,const char *s,uint32_t c,unsigned z){(void)x;(void)y;(void)s;(void)c;(void)z;}
void scene_layer(unsigned layer,int depth){(void)layer;(void)depth;}
void scene_clip(int x,int y,int w,int h){(void)x;(void)y;(void)w;(void)h;}
void scene_clip_reset(void){}
void fatal(const char *s,int n){fprintf(stderr,"EXACT FATAL %s %d\n",s,n);abort();}
static unsigned scenario,step_number;
static uint32_t random_local(uint32_t *s){uint32_t v=*s;v^=v<<13;v^=v>>17;v^=v<<5;return *s=v;}
typedef struct {
 Stage stage;
 Effect private_effects[SHOT_CAPACITY];
 BattleBoss bosses[MAX_BOSSES];
 BattleVm vm[MAX_BOSSES];
 PlayerState player;
 PlayerShot shots[PLAYER_SHOT_CAPACITY];
 OrdinaryEnemy enemies[ENEMY_CAPACITY];
 Fx cosmetics[FX_CAP];
 unsigned state[32];
 unsigned relevant_lo,relevant_hi,counts[2];
 uint16_t relevant_indices[2][CONTACT_BUCKET_CAP];
} Snapshot;
static Snapshot snapshot;
__declspec(dllexport) unsigned exact_snapshot_size(void){return sizeof(snapshot);}
__declspec(dllexport) void exact_init(unsigned which,unsigned n,unsigned seed){
 scenario=which;step_number=0;game_config_defaults();game_cfg.boss_count=6;game_cfg.enemy_count=12;
 game_cfg.battle_gather_enabled=1;
 if(which==9)game_cfg.near_enabled=0;
 battle_set_legacy(which==10);battle_reset(1,SHOT_CAPACITY);player_reset(512,620);enemies_reset(12);effects_reset();
 memset(effects,0,sizeof(effects));memset(contact_count,0,sizeof(contact_count));memset(contact_index,0,sizeof(contact_index));
 stage.seed=seed;uint32_t rng=seed?seed:1;stage.count=n;
 for(unsigned i=0;i<n;++i){
  int x=4+(int)(random_local(&rng)%1017),y=4+(int)(random_local(&rng)%681);
  int16_t vx=(int16_t)((int)(random_local(&rng)%12001)-6000),vy=(int16_t)((int)(random_local(&rng)%12001)-6000);
  unsigned age=random_local(&rng)%48,delay=i%9,turn=i%4?0:12;
  if(which==1){x=(i&1)?1020:4;y=(i&2)?684:4;vx=(i&1)?4096:-4096;vy=(i&2)?4096:-4096;turn=0;}
  if(which==2||which==3){y=which==2?620:100;vx=vy=0;turn=0;age=20;}
  if(which==4){static const int ys[]={72,73,85,86,98,99,171,172};y=ys[i%8];vx=vy=0;turn=0;age=20;}
  if(which==5){static const int ds[]={-14,-13,-5,-4,0,4,5,13,14};x=512+ds[i%9];y=620+ds[(i/9)%9];vx=vy=0;turn=0;age=20;}
  if(which==6){delay=6;turn=12;unsigned ages[]={0,5,6,17,18,19,65534,65535};age=ages[i%8];}
  if(which==7){x=i%3==0?-20:100+(int)(i%700);y=100+(int)(i%400);vx=vy=0;turn=0;age=0;}
  if(which==8){vx=vy=0;turn=0;age=i%2?65535:65534;}
  stage.shots[i]=(Shot){x*Q+(int)(i%3),y*Q+(int)(i%5),vx,vy,(uint16_t)age,(uint8_t)(54+i%16),(uint8_t)(i%7==0)};
  stage.owner[i]=(uint8_t)(i%4?i%6:128+i%12);
  effects[i]=(Effect){(int16_t)(i*231),(int16_t)(i%8192),(int16_t)(i*719),(int16_t)(2048+i%4096),(uint16_t)turn,(uint16_t)delay};
 }
 if(which==12){stage.count=0;game_cfg.enter_ticks=1;game_cfg.enrage_intro_ticks=1;game_cfg.player_shot_damage=50;battle_apply_damage(0,1500,1);}
}
__declspec(dllexport) void exact_tick(int px,int py,unsigned enabled){
 game_cfg.battle_gather_enabled=enabled;
 if(scenario==8){static const unsigned ages[]={0,1,20,60000,65535,65536};game_cfg.bullet_age_max=ages[step_number%6];}
 if(scenario==12){
  battle_step(px,py);enemies_tick(step_number,px,py);player_fire_tick(step_number);player_shots_tick();effects_tick();
 }else{battle_hit=battle_grazes=0;simulate_bullets(px,py);++stage.frame;}
 ++step_number;
}
__declspec(dllexport) const void *exact_snapshot(int py){
 memset(&snapshot,0,sizeof(snapshot));snapshot.stage=stage;memcpy(snapshot.private_effects,effects,sizeof(effects));
 memcpy(snapshot.bosses,bosses,sizeof(bosses));memcpy(snapshot.vm,vmb,sizeof(vmb));snapshot.player=player;
 memcpy(snapshot.shots,player_shots,sizeof(player_shots));memcpy(snapshot.enemies,ordinary_enemies,sizeof(ordinary_enemies));memcpy(snapshot.cosmetics,fx,sizeof(fx));
 unsigned fields[]={legacy_mode,battle_hit,battle_grazes,battle_materials,summon_done,battle_cleared,battle_density_slow,battle_density_skips,battle_near_candidates,battle_near_fallbacks,
 effects_jobs,effects_area,effects_over_budget,effects_active,effects_drop_total,fx_overflow,graze_wait,enemies_kills,enemies_spawns,enemies_despawns,enemies_requested,enemies_spawned,enemies_rejected,enemies_volleys_deferred,enemies_bullets_cleared,enemies_config_rejections,player_homing_retargets};
 memcpy(snapshot.state,fields,sizeof(fields));
 if(!legacy_mode&&game_cfg.near_enabled){
  unsigned lo=contact_bucket(py-(int)game_bullet_graze_radius()),hi=contact_bucket(py+(int)game_bullet_graze_radius());snapshot.relevant_lo=lo;snapshot.relevant_hi=hi;
  snapshot.counts[0]=contact_count[lo];snapshot.counts[1]=contact_count[hi];
  unsigned n0=contact_count[lo]<CONTACT_BUCKET_CAP?contact_count[lo]:CONTACT_BUCKET_CAP;
  unsigned n1=contact_count[hi]<CONTACT_BUCKET_CAP?contact_count[hi]:CONTACT_BUCKET_CAP;
  /* Canonical query sequence, not physical index-history scratch: SW3's fused
     path no longer consumes or stores that history. Reconstruct each queried
     bucket from final surviving Shots in the original ascending-index order.
     Counts/caps remain the real contact_count values and are compared strictly.
     test_sw3_state.py separately proves physical no-write/prefix-write rules
     and exact bytes for every original-path index prefix actually consumed. */
  unsigned q0=0,q1=0;
  for(unsigned i=0;i<stage.count;++i){
   unsigned bucket=contact_bucket(stage.shots[i].y/Q);
   if(bucket==lo&&q0<n0)snapshot.relevant_indices[0][q0++]=(uint16_t)i;
   if(bucket==hi&&q1<n1)snapshot.relevant_indices[1][q1++]=(uint16_t)i;
  }
  /* Player-shot owner deletion can follow motion in the same tick, so the
     preserved motion counts may exceed current surviving entries. Remaining
     canonical slots stay zero from snapshot initialization; counts are not
     recomputed, normalized, or weakened. */
 }
 return &snapshot;
}
