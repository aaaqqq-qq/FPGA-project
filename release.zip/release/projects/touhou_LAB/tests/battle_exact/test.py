from pathlib import Path
import argparse,ctypes,hashlib,json,os,shlex,subprocess,time
r=Path(__file__).resolve().parents[2];o=r/'results/battle_exact';o.mkdir(exist_ok=True)
p=argparse.ArgumentParser();p.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=p.parse_args();cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
libs=[]
for label in ('reference','candidate'):
 dll=o/(label+'.dll');cmd=cc+['-std=gnu11','-O2','-shared','-UNDEBUG','-Wno-misleading-indentation','-Isrc','-Itests/stub']
 if label=='reference':cmd+=['-DEXACT_REFERENCE']
 cmd+=['tests/battle_exact/host.c','src/stage.c','src/player.c','src/enemies.c','src/layer_visuals.c','src/game_config.c','src/font.c','-o',str(dll)]
 q=subprocess.run(cmd,cwd=r,capture_output=True,text=True);(o/(label+'_compile.log')).write_text(q.stdout+q.stderr,encoding='utf-8');assert q.returncode==0,q.stderr
 lib=ctypes.CDLL(str(dll));lib.exact_snapshot.restype=ctypes.c_void_p;lib.exact_tick.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_uint];libs.append(lib)
size=libs[0].exact_snapshot_size();assert size==libs[1].exact_snapshot_size()
cases=[];frames=0;started=time.monotonic()
for scenario in range(13):
 for n in ((0,1,64,4096,4097,20000) if scenario!=12 else (0,)):
  seed=(0x12345678+scenario*73+n)&0xffffffff
  for lib in libs:lib.exact_init(scenario,n,seed)
  ticks=720 if scenario==12 else 24
  for tick in range(ticks):
   py=(24,72,73,85,86,98,99,171,172,344,620,664)[(tick//2)%12]
   if scenario in (2,3,5,6):py=620
   if scenario==4:py=(85,86,171,172)[tick%4]
   px=16+(tick*71)%993
   if scenario==5:px=512
   enabled=tick%3!=0
   data=[]
   for lib in libs:
    lib.exact_tick(px,py,enabled);data.append(ctypes.string_at(lib.exact_snapshot(py),size))
   assert data[0]==data[1],('exact state mismatch',scenario,n,tick,py,next(i for i,(x,y)in enumerate(zip(*data))if x!=y))
   frames+=1
  cases.append({'scenario':scenario,'initial_count':n,'ticks':ticks,'status':'PASS'})
result={'status':'PASS','frames_exact':frames,'snapshot_bytes':size,'cases':cases,'host_elapsed_seconds':time.monotonic()-started,
 'reference_sha256':hashlib.sha256((r/'tests/battle_exact/reference_battle_R7p1.c').read_bytes()).hexdigest(),
 'candidate_sha256':hashlib.sha256((r/'src/battle.c').read_bytes()).hexdigest(),
 'scope':'Every tick byte-exact complete Stage includingunusedtail,private20kEffects,6BossVM/HP,Player/projectiles,ordinaryenemies,Fx,publiccounters,andrelevantbucketindex/counts. Unqueriedbuckettemporaryscratch excluded by design. FrozenR7p1sourcecompiledindependently; no board timing claim.'}
(o/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print('BATTLE_EXACT PASS',frames,'ticks',size,'bytes/state;',len(cases),'scenarios/count cases')
