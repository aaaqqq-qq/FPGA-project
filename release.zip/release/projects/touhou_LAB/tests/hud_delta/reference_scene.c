#include "scene.h"
#include "art_data.h"
#include "bitblt.h"
#include "segment_diag.h"
#include "font.h"
#include "stage.h"
#include "background.h"
#include "game_config.h"
#include "render_queue.h"
#include "pipe5_abi.h"
#ifndef BB_HOST_TEST
#include "motion_hw.h"
#else
/* New path requires an explicit host model of validated motion ownership. */
__attribute__((weak,noinline)) unsigned scene_test_motion_committed(void){return 0;}
#endif
#include <string.h>

#define BACKGROUND 0x01A00000u
int scene_art_info(unsigned tile,uint32_t *address,unsigned *width,unsigned *height){
    if(tile>=sizeof(tiles)/sizeof(tiles[0]))return 0;
    *address=ART_BASE+tiles[tile].off;*width=tiles[tile].w;*height=tiles[tile].h;return 1;
}
#ifdef BB_HOST_TEST
#define SCENE_FENCE() do{}while(0)
#else
#define SCENE_FENCE() __asm__ volatile("fence iorw,iorw" ::: "memory")
#endif
static uint32_t framebuffer;
static unsigned hardware,batch_mode,cancelled;
unsigned scene_cancelled(void){return cancelled;}
unsigned scene_jobs,scene_list_us,scene_batch_cycles,scene_sprite_count;
static bb_job previous;
static unsigned cache_valid, pending_job, initialized_frames;
static unsigned batch_count;
static unsigned batch_defer_preflight,batch_preflight_pending;
static bb_job batch_preflight_job;
static unsigned pending_pipe_job,pending_epoch,next_render_epoch,frame_pipe_epoch,batch_fallback;
static unsigned defer_hud,hud_deferred;
static unsigned hud_dma_active,hud_dma_cpu_writes,hud_dma_gpu_writes;
static unsigned fallback_hold_epoch;
static SceneSubmission frame_submission;
static void (*pipe_rx_service)(void);
void scene_pipe_set_service(void (*service)(void)){pipe_rx_service=service;}
/* Dedicated immutable DDR atlases, outside frames, original art, all LAB/ADV
   pools and the uploaded image. Each bank is 16 * 56 * 56 * 4 = 0x31000 B;
   64-byte guards occupy [base-64,base) and [base+0x31000,base+0x31040).
   Bank 0 uses original tiles 24..39, bank 1 uses battle tiles 54..69. */
#define BULLET_ATLAS0 0x06000000u
#define BULLET_ATLAS1 0x06040000u
#define BULLET_ATLAS_SIDE 56u
#define BULLET_ATLAS_SLOT (BULLET_ATLAS_SIDE*BULLET_ATLAS_SIDE*4u)
#define BULLET_ATLAS_BYTES (16u*BULLET_ATLAS_SLOT)
static unsigned bullet_size=8,bullet_atlas_size;
_Static_assert(BULLET_ATLAS0>=0x05400000u,"bullet atlas beyond LAB image");
_Static_assert(BULLET_ATLAS0+BULLET_ATLAS_BYTES+64u<=BULLET_ATLAS1-64u,"bullet atlas separation");
_Static_assert(BULLET_ATLAS1+BULLET_ATLAS_BYTES+64u<=BB_DDR_END,"bullet atlas DDR range");
static unsigned layer_capture,layers_started,current_layer,layer_pending_sprites;
static unsigned hud_cpu_overlap,hud_sprite_base;
static int current_depth;
static int clip_left=32,clip_top=16,clip_right=1056,clip_bottom=704;
unsigned scene_layer_commands,scene_layer_peak,scene_layer_clipped,scene_layer_reordered;
static void layer_sink(const RqCommand *c,const char *text,void *context);
static void layer_prepare(RqCommand *c,const char *text,void *context);
static int text_bounds(const RqCommand *c,const char *text,int *ox,int *oy,int *ow,int *oh);
static void layer_metrics(void){scene_layer_commands=rq_total;scene_layer_peak=rq_peak;scene_layer_reordered=rq_reordered;}
void scene_clip_reset(void){clip_left=32;clip_top=16;clip_right=1056;clip_bottom=704;}
void scene_clip(int x,int y,int w,int h){
    int64_t r=(int64_t)x+w,b=(int64_t)y+h;
    int64_t l=x,t=y;if(l<32)l=32;if(t<16)t=16;if(r>1056)r=1056;if(b>704)b=704;
    if(w<=0||h<=0||r<=l||b<=t){clip_left=clip_right=32;clip_top=clip_bottom=16;return;}
    clip_left=(int)l;clip_top=(int)t;clip_right=(int)r;clip_bottom=(int)b;
}
int scene_layer_order(const unsigned ranks[SCENE_LAYER_COUNT]){return rq_set_order(ranks);}
void scene_layers_prepare(void){if(layer_capture)rq_prepare(layer_prepare,0);}
void scene_layers_flush(void){rq_flush(layer_sink,0);layer_pending_sprites=0;layer_metrics();}
void scene_layers_begin(unsigned enabled){
    if(rq_count())scene_layers_flush();
    rq_reset();scene_layer_commands=scene_layer_peak=scene_layer_clipped=scene_layer_reordered=0;
    layer_pending_sprites=0;layer_capture=!!enabled;layers_started=1;current_layer=SCENE_LAYER_ACTOR;current_depth=0;scene_clip_reset();
}
void scene_layer(unsigned layer,int depth){if(layer>=SCENE_LAYER_COUNT)fatal("LAYER ID",(int)layer);current_layer=layer;current_depth=depth;}
static int clipped_bounds(int x,int y,int w,int h,int l,int t,int r,int b,
                          int *ox,int *oy,int *ow,int *oh){
    int64_t x0=x,y0=y,x1=(int64_t)x+w,y1=(int64_t)y+h;
    if(w<=0||h<=0||l>=r||t>=b)return 0;
    if(x0<l)x0=l;if(y0<t)y0=t;if(x1>r)x1=r;if(y1>b)y1=b;
    if(x0>=x1||y0>=y1)return 0;
    *ox=(int)x0;*oy=(int)y0;*ow=(int)(x1-x0);*oh=(int)(y1-y0);return 1;
}
static void layer_submit(RqCommand *c,const char *text){
    c->layer=(uint8_t)current_layer;c->depth=current_depth;
    c->left=(int16_t)clip_left;c->top=(int16_t)clip_top;c->right=(int16_t)clip_right;c->bottom=(int16_t)clip_bottom;
    if(c->kind!=RQ_TEXT){
        int x,y,w,h;
        if(!clipped_bounds(c->x,c->y,c->w,c->h,clip_left,clip_top,clip_right,clip_bottom,&x,&y,&w,&h)){++scene_layer_clipped;return;}
        if(x!=c->x||y!=c->y||w!=c->w||h!=c->h)++scene_layer_clipped;
    }else{
        int x,y,w,h;
        if(!text_bounds(c,text,&x,&y,&w,&h)){++scene_layer_clipped;return;}
        if(c->x<clip_left||c->y<clip_top||clip_left!=32||clip_top!=16||clip_right!=1056||clip_bottom!=704)++scene_layer_clipped;
    }
    int result=rq_push(c,text);if(result!=RQ_OK)fatal("LAYER QUEUE",result);if(c->kind==RQ_TILE)++layer_pending_sprites;layer_metrics();
}
/* A bounded command cache for the right HUD. Compare every field and occupied
   text byte exactly, per framebuffer/8-pixel strip; no hash hides a change. */
#define HUD_LEFT 1072
#define HUD_TOP 118
#define HUD_BOTTOM 704
#define HUD_ROWS ((HUD_BOTTOM-HUD_TOP+7)/8)
#define HUD_COMMAND_CAP 96
#define HUD_TEXT_CAP 96
typedef struct {
    int x,y,w,h;
    uint32_t color;
    unsigned scale;
    uint16_t kind,text_len;
    char text[HUD_TEXT_CAP];
} HudCommand;
_Static_assert(offsetof(HudCommand,text)==28&&sizeof(HudCommand)==124,"compact HUD header, unchanged BSS");
static HudCommand hud_current[HUD_COMMAND_CAP],hud_saved[2][HUD_COMMAND_CAP];
static unsigned hud_count,hud_saved_count[2],hud_valid[2],hud_capture,hud_used;
static unsigned hud_cache_enabled=1;

/* Exact static HUD text textures. Numeric or unusual text stays on CPU.
   Slots [0x07000000,0x07240000), metadata [0x07300000,0x07301000).
   Only the actual glyph bounding rectangle is cleared/read, not stride holes. */
#define HUD_TEXT_BASE 0x07000000u
#define HUD_TEXT_META 0x07300000u
#define HUD_TEXT_SLOTS 32u
#define HUD_TEXT_SLOT_BYTES 0x12000u
#define HUD_TEXT_ROWS 14u
#define HUD_TEXT_MAX_W 208u
typedef struct { uint32_t valid,color,scale,len;char text[HUD_TEXT_CAP]; } HudTextEntry;
#define HUD_TEXT_ENTRIES ((volatile HudTextEntry *)(uintptr_t)(HUD_TEXT_META+64u))
static unsigned hud_text_ready,hud_text_victim;
_Static_assert(sizeof(HudTextEntry)*HUD_TEXT_SLOTS+128u<=0x1000u,"HUD metadata bounds");
_Static_assert(HUD_TEXT_ROWS*BB_SCREEN_STRIDE+128u<=HUD_TEXT_SLOT_BYTES,"HUD texture bounds");
_Static_assert(HUD_TEXT_BASE+HUD_TEXT_SLOTS*HUD_TEXT_SLOT_BYTES<=HUD_TEXT_META,"HUD regions disjoint");
_Static_assert(HUD_TEXT_META+0x1000u<=BB_DDR_END,"HUD DDR bounds");
static void hud_text_cache_reset(void);
static int hud_text_cache_guards_ok(void);

unsigned scene_hud_restored_rows,scene_hud_redraw_jobs;
static void hud_record(unsigned kind,int x,int y,int w,int h,uint32_t color,unsigned scale,const char *text){
    if(hud_count>=HUD_COMMAND_CAP)fatal("HUD COMMAND CAP",hud_count);
    HudCommand *c=&hud_current[hud_count++];
    c->kind=kind;c->x=x;c->y=y;c->w=w;c->h=h;c->color=color;c->scale=scale;
    size_t n=text?strlen(text):0;if(n>=HUD_TEXT_CAP)fatal("HUD TEXT CAP",(int)n);
    c->text_len=(uint16_t)n;
    if(n)memcpy(c->text,text,n);c->text[n]=0;
}
static int hud_same_command(const HudCommand *a,const HudCommand *b){
    return !memcmp(a,b,offsetof(HudCommand,text))&&
           !memcmp(a->text,b->text,a->text_len);
}
static void hud_save_commands(unsigned bank,const uint32_t *changed){
    for(unsigned i=0;i<hud_count;++i)if(!changed||(changed[i>>5]&(1u<<(i&31)))){
        /* Bytes after the terminator never participate in drawing/equality.
           Do not clear or copy them, including when a command becomes shorter. */
        memcpy(&hud_saved[bank][i],&hud_current[i],offsetof(HudCommand,text)+hud_current[i].text_len+1u);
    }
}
void scene_hud_invalidate(void){hud_valid[0]=hud_valid[1]=0;}
void scene_hud_cache_enable(unsigned enabled){enabled=!!enabled;if(hud_cache_enabled!=enabled){hud_cache_enabled=enabled;scene_hud_invalidate();}}
/* scene_hud_begin is below the private MMIO helpers. */

/* Per-buffer damage history in a reserved DDR area beyond both frames, art
   and background. Keep exact rectangles, so 8x8 sprites restore only 64 pixels.
   Store history for the buffer being reused (two frames old), not front buffer. */
typedef struct {uint16_t x,y,w,h;} Damage;
#define DAMAGE_CAP (SHOT_CAPACITY+128)
#define DAMAGE ((volatile Damage *)(uintptr_t)0x01E00000u)
static unsigned damage_count[2],damage_bank;
static void mark_damage(int x,int y,int w,int h){
    if(batch_mode)return;
    if(x<32){w-=32-x;x=32;}if(y<16){h-=16-y;y=16;}
    if(x+w>1056)w=1056-x;if(y+h>704)h=704-y;
    if(w<=0||h<=0)return;
    unsigned n=damage_count[damage_bank];if(n>=DAMAGE_CAP)fatal("DAMAGE CAPACITY",n);
    volatile Damage *d=&DAMAGE[damage_bank*DAMAGE_CAP+n];
    d->x=x;d->y=y;d->w=w;d->h=h;damage_count[damage_bank]=n+1;
}

/* Private hot-path MMIO; generic validated public driver remains available. */
#ifdef BB_HOST_TEST
static inline uint32_t scene_read(unsigned reg){return bb_read(reg);}
static inline void scene_write(unsigned reg,uint32_t value){bb_write(reg,value);}
#else
static inline uint32_t scene_read(unsigned reg){return *(volatile uint32_t *)(uintptr_t)(BB_BASE+reg);}
static inline void scene_write(unsigned reg,uint32_t value){*(volatile uint32_t *)(uintptr_t)(BB_BASE+reg)=value;}
#endif
void scene_pipe_check_fault(void){if((scene_read(0x4c)&PIPE5_CAP_CONCURRENT_EPOCH)&&scene_read(PIPE5_FAULT))fatal("PIPE RENDER FAULT",-1);}
unsigned scene_pipe_frame_epoch(void){return frame_pipe_epoch;}
unsigned scene_pipe_fallback(void){return batch_fallback;}
SceneSubmission scene_pipe_submission(void){return frame_submission;}
void scene_pipe_defer_hud(unsigned enabled){if(hud_deferred)fatal("PIPE HUD PENDING",-1);defer_hud=!!enabled;}
void scene_hud_begin(void){
    if(batch_preflight_pending)fatal("HUD BEFORE PREFLIGHT",-1);
    /* OP2 owns only x=[32,1056); right HUD owns x=[1072,1280).
       Preserve the queued world layers and their painter order. The HUD's
       DRAWN value must still describe the same fully submitted frame. */
    hud_cpu_overlap=hardware&&pending_job&&previous.op==2&&layer_capture;
    if(hud_cpu_overlap){
        if(scene_read(BB_STATUS)&BB_ERROR)fatal("HUD BATCH ENGINE",-1);
        hud_sprite_base=scene_sprite_count;scene_sprite_count+=layer_pending_sprites;
    }else {scene_layers_flush();layer_capture=0;}
    hud_capture=1;hud_used=1;hud_count=0;scene_hud_restored_rows=scene_hud_redraw_jobs=0;
}

/* Keep one hardware operation in flight while preparing the next sprite.
   Wait before changing its registers, touching pixels on CPU, or swapping. */
static void finish_job(void){
    if(!pending_job)return;
    unsigned sd_phase=pending_pipe_job?SD_R_WAIT:SD_LEGACY_WAIT;uint64_t sd_begin=segment_diag_nested_begin();
    unsigned polls=0;uint64_t start=0;
    for(;;){if(pending_pipe_job)scene_pipe_check_fault();uint32_t s=scene_read(pending_pipe_job?PIPE5_R_STATUS:BB_STATUS);if(s&BB_ERROR)fatal("ENGINE",s);if((s&(BB_BUSY|BB_DONE))==BB_DONE){if(pending_pipe_job&&scene_read(PIPE5_R_DONE_EPOCH)!=pending_epoch)fatal("PIPE R DONE EPOCH",-1);break;}
        if((++polls&1023)==0){if(!start)start=bb_ticks();else if(bb_us(bb_ticks()-start)>100000)fatal("ENGINE TIMEOUT",s);}}
    if(pending_pipe_job)segment_diag_event(SDE_R_DONE);
    if(previous.op==2)scene_batch_cycles=scene_read(pending_pipe_job?PIPE5_R_CYCLES:BB_CYCLES);
    if(segment_diag_active&&pending_pipe_job){segment_diag_value(SD_R_CYCLES,scene_batch_cycles);segment_diag_value(SD_R_READ,scene_read(PIPE5_R_READ_BYTES));segment_diag_value(SD_R_WRITE,scene_read(PIPE5_R_WRITE_BYTES));}
    if(segment_diag_active&&!pending_pipe_job)segment_diag_value(SD_LEGACY_CYCLES,scene_read(BB_CYCLES));
    SCENE_FENCE();pending_job=0;pending_pipe_job=0;
    segment_diag_nested_end(sd_phase,sd_begin);
}
static uint32_t bullet_guard(unsigned bank,unsigned side,unsigned i){return 0x62534c91u^(bank*0x100u+side*0x20u+i);}
void scene_bullets_reset(void){
    finish_job();bullet_size=8;bullet_atlas_size=0;
}
int scene_bullets_prepare(unsigned size){
    if(size<8||size>56||(size&7u))return 0;
    finish_job();
    if(size==8){bullet_size=8;return 1;}
    if(bullet_atlas_size==size){bullet_size=size;return 1;}
    unsigned sample[BULLET_ATLAS_SIDE];
    for(unsigned i=0;i<size;++i)sample[i]=i*8u/size;
    for(unsigned bank=0;bank<2;++bank){
        uint32_t address=bank?BULLET_ATLAS1:BULLET_ATLAS0;
        unsigned first=bank?54u:24u;
        for(unsigned material=0;material<16;++material){
            Tile t=tiles[first+material];
            if(t.w!=8||t.h!=8)fatal("BULLET MATERIAL",(int)(first+material));
            const volatile uint32_t *src=(const volatile uint32_t *)(uintptr_t)(ART_BASE+t.off);
            volatile uint32_t *dst=(volatile uint32_t *)(uintptr_t)(address+material*BULLET_ATLAS_SLOT);
            /* Integer nearest-neighbour sampling preserves the existing RGB
               and exact colour key. Fill padding, so unused rows are defined. */
            for(unsigned y=0;y<BULLET_ATLAS_SIDE;++y)for(unsigned x=0;x<BULLET_ATLAS_SIDE;++x)
                dst[y*BULLET_ATLAS_SIDE+x]=(x<size&&y<size)?src[sample[y]*8u+sample[x]]:BB_KEY;
        }
        for(unsigned side=0;side<2;++side){
            volatile uint32_t *g=(volatile uint32_t *)(uintptr_t)(side?address+BULLET_ATLAS_BYTES:address-64u);
            for(unsigned i=0;i<16;++i)g[i]=bullet_guard(bank,side,i);
        }
    }
    if(bb_publish()!=BB_OK)return 0;
    bullet_atlas_size=size;bullet_size=size;return 1;
}
int scene_bullets_guards_ok(void){
    finish_job();bb_acquire();if(!hud_text_cache_guards_ok())return 0;if(!bullet_atlas_size)return 1;
    for(unsigned bank=0;bank<2;++bank)for(unsigned side=0;side<2;++side){
        uint32_t address=bank?BULLET_ATLAS1:BULLET_ATLAS0;
        const volatile uint32_t *g=(const volatile uint32_t *)(uintptr_t)(side?address+BULLET_ATLAS_BYTES:address-64u);
        for(unsigned i=0;i<16;++i)if(g[i]!=bullet_guard(bank,side,i))return 0;
    }
    return 1;
}
/* Descriptors are snapshotted before any background reads. Once that DMA
   completes, the CPU can calculate the next frame without changing this one. */
void scene_batch_snapshot_ready(void){
    if(!pending_job || previous.op!=2)return;
    if(pending_pipe_job){(void)scene_pipe_snapshot_epoch();return;}
    SCENE_FENCE();
    unsigned accepted=0;uint64_t accepted_at=0,start=bb_ticks();
    for(;;){
        unsigned status=scene_read(BB_STATUS);
        if(status&BB_ERROR)fatal("SNAPSHOT ENGINE",status);
        if((status&BB_BUSY)&&!accepted){accepted=1;accepted_at=bb_ticks();}
        if((status&(BB_BUSY|BB_DONE))==BB_DONE)break;
        /* APB CMD accepted at T0; batch mux/counters reset unconditionally
           at T0+1 on this same 100MHz clock. Anchor the extra guard to the
           first new BUSY, not to helper entry or a short texture DMA window. */
        if(accepted&&bb_us(bb_ticks()-accepted_at)>=1&&
           scene_read(BB_READ_BYTES)>=4096+batch_count*16)break;
        if(bb_us(bb_ticks()-start)>100000)fatal("SNAPSHOT TIMEOUT",status);
    }
    SCENE_FENCE();
}
unsigned scene_pipe_snapshot_epoch(void){
    if(batch_fallback||!pending_job||!pending_pipe_job||previous.op!=2)return 0;
    uint64_t start=bb_ticks();SCENE_FENCE();
    for(;;){
        scene_pipe_check_fault();unsigned status=scene_read(PIPE5_R_STATUS),snapshot=scene_read(PIPE5_R_SNAP_STATUS);
        if(status&PIPE5_ERROR)fatal("PIPE SNAPSHOT",(int)status);
        if(snapshot&PIPE5_SNAP_NO_DRAW)return 0;
        if((snapshot&PIPE5_SNAP_READY)&&scene_read(PIPE5_R_SNAP_EPOCH)==pending_epoch){SCENE_FENCE();return pending_epoch;}
        if((status&(PIPE5_BUSY|PIPE5_DONE))==PIPE5_DONE)fatal("PIPE SNAPSHOT MISSING",-1);
        if(bb_us(bb_ticks()-start)>100000)fatal("PIPE SNAPSHOT TIMEOUT",-1);
    }
}
void scene_external_begin(void){
    finish_job();cache_valid=0;
}
static void engine(const bb_job *j){
    finish_job();
    unsigned pipe_job=j->op==2&&(scene_read(0x4c)&PIPE5_CAP_CONCURRENT_EPOCH);
    if(pipe_job){scene_pipe_check_fault();if(scene_read(PIPE5_M_STATUS)&PIPE5_BUSY)fatal("PIPE R ADMISSION",-1);}
    /* Immutable art, clipped destinations. Publish CPU writes at frame end. */
    const unsigned regs[]={BB_OP,BB_SRC,BB_DST,BB_SRC_STRIDE,BB_DST_STRIDE,BB_WIDTH,BB_HEIGHT,BB_FILL,BB_ALPHA,BB_KEY_REG,BB_FLAGS};
    const uint32_t *p=(const uint32_t *)j;uint32_t *old=(uint32_t *)&previous;
    /* Accepted CMD clears sticky DONE/ERROR in game_apb.sv. */
    for(unsigned i=0;i<11;++i)if(!cache_valid||old[i]!=p[i]){scene_write(regs[i],p[i]);old[i]=p[i];}
    cache_valid=1;SCENE_FENCE();
    if(pipe_job){
        if(!++next_render_epoch)++next_render_epoch;
        pending_epoch=frame_pipe_epoch=next_render_epoch;pending_pipe_job=1;
        if(scene_read(BB_ALPHA)!=j->alpha||scene_read(BB_FLAGS)!=j->flags||scene_read(BB_KEY_REG)!=j->key||scene_read(0x44)!=batch_count)fatal("PIPE R PARAM READBACK",-1);
        frame_submission=(SceneSubmission){pending_epoch,batch_count,j->alpha,j->flags,j->key,scene_read(0x50)};
        scene_write(PIPE5_R_STATUS,PIPE5_DONE|PIPE5_ERROR);scene_write(PIPE5_R_EPOCH,pending_epoch);SCENE_FENCE();scene_write(PIPE5_R_CMD,1);segment_diag_event(SDE_R_SUBMIT);
    }else{pending_pipe_job=0;scene_write(BB_CMD,1);}
    pending_job=1;
}
static void execute(const bb_job *j){
    if(cancelled)return;
    if(hud_dma_active&&hud_dma_cpu_writes){
        if(bb_publish()!=BB_OK)fatal("HUD DMA CPU PUBLISH",-1);hud_dma_cpu_writes=0;
    }
    ++scene_jobs;
    if(hud_dma_active)hud_dma_gpu_writes=1;
    if(hardware)engine(j);else {bb_result r=bb_cpu_execute(j);if(r==BB_E_CANCELLED)cancelled=1;else if(r)fatal("CPU RENDER",r);}
}

static uint32_t hud_text_guard(unsigned slot,unsigned side,unsigned word){return 0x687544a1u^(slot*0x10001u+side*0x100u+word);}
static uint32_t hud_text_guard_address(unsigned slot,unsigned side){
    if(slot==HUD_TEXT_SLOTS)return side?HUD_TEXT_META+64u+sizeof(HudTextEntry)*HUD_TEXT_SLOTS:HUD_TEXT_META;
    uint32_t base=HUD_TEXT_BASE+slot*HUD_TEXT_SLOT_BYTES;
    return side?base+64u+HUD_TEXT_ROWS*BB_SCREEN_STRIDE:base;
}
static void hud_text_cache_reset(void){
    finish_job();hud_text_ready=0;hud_text_victim=0;
    for(unsigned slot=0;slot<=HUD_TEXT_SLOTS;++slot)for(unsigned side=0;side<2;++side){
        volatile uint32_t *g=(volatile uint32_t *)(uintptr_t)hud_text_guard_address(slot,side);
        for(unsigned i=0;i<16;++i)g[i]=hud_text_guard(slot,side,i);
    }
    for(unsigned slot=0;slot<HUD_TEXT_SLOTS;++slot)HUD_TEXT_ENTRIES[slot].valid=0;
    if(bb_publish()!=BB_OK)fatal("HUD TEXT INIT",-1);hud_text_ready=1;
}
static int hud_text_cache_guards_ok(void){
    if(!hud_text_ready)return 1;
    for(unsigned slot=0;slot<=HUD_TEXT_SLOTS;++slot)for(unsigned side=0;side<2;++side){
        const volatile uint32_t *g=(const volatile uint32_t *)(uintptr_t)hud_text_guard_address(slot,side);
        for(unsigned i=0;i<16;++i)if(g[i]!=hud_text_guard(slot,side,i))return 0;
    }
    return 1;
}
static void hud_text_slot_sentinels(unsigned slot){
    /* All guard words are checked by the public final guard check; check each
       boundary's first/last sentinel before every texture or metadata use. */
    for(unsigned side=0;side<2;++side){
        const volatile uint32_t *g=(const volatile uint32_t *)(uintptr_t)hud_text_guard_address(slot,side);
        if(g[0]!=hud_text_guard(slot,side,0)||g[15]!=hud_text_guard(slot,side,15))fatal("HUD TEXT GUARD",(int)slot);
    }
}
static int hud_text_cached(const HudCommand *c,int top,int bottom){
    if(!hardware||!hud_text_ready||c->scale<1||c->scale>2||c->text_len<3||c->w<=0||c->w>(int)HUD_TEXT_MAX_W||
       c->h<=0||c->h>(int)HUD_TEXT_ROWS||c->x<HUD_LEFT||c->x+c->w>1280||c->y<0||c->y+c->h>720||
       (c->color&0xffffffu)==BB_KEY)return 0;
    uint32_t hash=2166136261u;
    for(unsigned i=0;i<c->text_len;++i){
        unsigned char ch=(unsigned char)c->text[i];
        if(ch=='\n'||(ch>='0'&&ch<='9'))return 0;
        hash=(hash^ch)*16777619u;
    }
    hash|=1u;hud_text_slot_sentinels(HUD_TEXT_SLOTS);
    unsigned slot=HUD_TEXT_SLOTS,empty=HUD_TEXT_SLOTS,match=0;
    for(unsigned k=0;k<HUD_TEXT_SLOTS;++k){
        volatile HudTextEntry *entry=&HUD_TEXT_ENTRIES[k];unsigned valid=entry->valid;
        if(!valid&&empty==HUD_TEXT_SLOTS)empty=k;
        if(valid!=hash||entry->color!=c->color||entry->scale!=c->scale||entry->len!=c->text_len)continue;
        unsigned same=1;for(unsigned i=0;i<c->text_len;++i)if(entry->text[i]!=c->text[i]){same=0;break;}
        if(same){slot=k;match=1;break;}
    }
    if(!match)slot=empty<HUD_TEXT_SLOTS?empty:(hud_text_victim++&(HUD_TEXT_SLOTS-1));
    hud_text_slot_sentinels(slot);volatile HudTextEntry *e=&HUD_TEXT_ENTRIES[slot];
    uint32_t source=HUD_TEXT_BASE+slot*HUD_TEXT_SLOT_BYTES+64u;
    if(!match){
        finish_job();e->valid=0;
        for(int y=0;y<c->h;++y){volatile uint32_t *p=(volatile uint32_t *)(uintptr_t)(source+(unsigned)y*BB_SCREEN_STRIDE);for(int x=0;x<c->w;++x)p[x]=BB_KEY;}
        draw_text_clipped(source,0,0,c->text,c->color,c->scale,0,0,c->w,c->h);
        if(bb_publish()!=BB_OK)fatal("HUD TEXT PUBLISH",-1);
        if(hud_dma_active)hud_dma_cpu_writes=0;
        e->color=c->color;e->scale=c->scale;e->len=c->text_len;
        for(unsigned i=0;i<c->text_len;++i)e->text[i]=c->text[i];e->valid=hash;
        hud_text_slot_sentinels(slot);
    }
    int y=c->y;if(y<top)y=top;int end=c->y+c->h;if(end>bottom)end=bottom;
    if(y>=end)return 1;
    bb_job j={BB_COPY_OP,source+(unsigned)(y-c->y)*BB_SCREEN_STRIDE,framebuffer+(unsigned)y*BB_SCREEN_STRIDE+(unsigned)c->x*4u,
              BB_SCREEN_STRIDE,BB_SCREEN_STRIDE,(unsigned)c->w,(unsigned)(end-y),0,255,BB_KEY,BB_KEY_ENABLE};
    execute(&j);++scene_hud_redraw_jobs;return 1;
}

static int text_bounds(const RqCommand *c,const char *text,int *ox,int *oy,int *ow,int *oh){
    int64_t px=c->x,py=c->y,l=c->right,t=c->bottom,r=c->left,b=c->top;
    unsigned visible=0;
    for(unsigned i=0;text[i]&&i<RQ_TEXT_BYTES;++i){
        if(text[i]=='\n'){px=8;py+=9*(int64_t)c->scale;continue;}
        int64_t x0=px,y0=py,x1=px+5*(int64_t)c->scale,y1=py+7*(int64_t)c->scale;
        if(x0<c->left)x0=c->left;if(y0<c->top)y0=c->top;
        if(x1>c->right)x1=c->right;if(y1>c->bottom)y1=c->bottom;
        if(x0<x1&&y0<y1){if(x0<l)l=x0;if(y0<t)t=y0;if(x1>r)r=x1;if(y1>b)b=y1;visible=1;}
        px+=6*(int64_t)c->scale;
    }
    if(!visible)return 0;*ox=(int)l;*oy=(int)t;*ow=(int)(r-l);*oh=(int)(b-t);return 1;
}
/* Captured commands contain frozen old-frame coordinates. Prepare in place
   while the R/M engines own disjoint memories. No MMIO, DDR writes, source
   mutation, painter-order change, or extra command buffer occurs here.
   reserved=1: exact clipped COPY/FILL; reserved=2: proven empty.
   Text retains its original path, glyph origin and clipping semantics. */
static void layer_prepare(RqCommand *c,const char *text,void *context){
    (void)text;(void)context;
    if(c->reserved||c->kind==RQ_TEXT)return;
    int x,y,w,h;
    if(!clipped_bounds(c->x,c->y,c->w,c->h,c->left,c->top,c->right,c->bottom,&x,&y,&w,&h)){c->reserved=2;return;}
    if(c->kind==RQ_TILE){
        Tile t=tiles[c->tile];
        unsigned sx=(unsigned)((int64_t)x-c->x),sy=(unsigned)((int64_t)y-c->y);
        c->color=ART_BASE+t.off+(sy*t.w+sx)*4u;
    }
    c->x=x;c->y=y;c->w=w;c->h=h;c->reserved=1;
}
static void layer_sink(const RqCommand *c,const char *text,void *context){
    (void)context;if(cancelled)return;
    int x,y,w,h;
    if(c->kind==RQ_TEXT){
        if(!text_bounds(c,text,&x,&y,&w,&h))return;
        finish_job();mark_damage(x,y,w,h);
        draw_text_clipped(framebuffer,c->x,c->y,text,c->color,c->scale,c->left,c->top,c->right,c->bottom);
        return;
    }
    if(c->reserved==2)return;
    if(c->reserved==1){x=c->x;y=c->y;w=c->w;h=c->h;}
    else if(!clipped_bounds(c->x,c->y,c->w,c->h,c->left,c->top,c->right,c->bottom,&x,&y,&w,&h))return;
    mark_damage(x,y,w,h);
    if(c->kind==RQ_TILE){
        Tile tile=tiles[c->tile];
        uint32_t source=c->color;
        if(!c->reserved){unsigned sx=(unsigned)((int64_t)x-c->x),sy=(unsigned)((int64_t)y-c->y);source=ART_BASE+tile.off+(sy*tile.w+sx)*4u;}
        ++scene_sprite_count;
        bb_job j={BB_COPY_OP,source,framebuffer+y*BB_SCREEN_STRIDE+x*4,
                  tile.w*4,BB_SCREEN_STRIDE,(unsigned)w,(unsigned)h,0,c->alpha,BB_KEY,BB_ALPHA_ENABLE|BB_KEY_ENABLE};execute(&j);
    }else{
        bb_job j={BB_FILL_OP,0,framebuffer+y*BB_SCREEN_STRIDE+x*4,0,BB_SCREEN_STRIDE,(unsigned)w,(unsigned)h,c->color,255,BB_KEY,0};execute(&j);
    }
}
void scene_tile(int x,int y,unsigned tile,unsigned alpha){
    if(cancelled)return;
    if(tile>=sizeof(tiles)/sizeof(tiles[0]))fatal("TILE",tile);
    if(layer_capture){
        if(alpha>255)fatal("LAYER ALPHA",(int)alpha);
        RqCommand c={0};c.kind=RQ_TILE;c.x=x;c.y=y;c.w=tiles[tile].w;c.h=tiles[tile].h;c.tile=(uint16_t)tile;c.alpha=(uint8_t)alpha;
        layer_submit(&c,0);return;
    }
    Tile t=tiles[tile];int w=t.w,h=t.h,sx=0,sy=0;
    /* Game sprites are clipped to the 720p 1024x688 play field. */
    if(x<32){sx=32-x;w-=sx;x=32;}if(y<16){sy=16-y;h-=sy;y=16;}
    if(x+w>1056)w=1056-x;if(y+h>704)h=704-y;if(w<=0||h<=0)return;
    ++scene_sprite_count;
    mark_damage(x,y,w,h);
    bb_job j={BB_COPY_OP,ART_BASE+t.off+(sy*t.w+sx)*4,framebuffer+y*BB_SCREEN_STRIDE+x*4,t.w*4,BB_SCREEN_STRIDE,w,h,0,alpha,BB_KEY,BB_ALPHA_ENABLE|BB_KEY_ENABLE};execute(&j);
}
void scene_rect(int x,int y,int w,int h,uint32_t color){
    if(cancelled)return;
    if(hud_capture){hud_record(0,x,y,w,h,color,0,0);return;}
    if(layer_capture){RqCommand c={0};c.kind=RQ_RECT;c.x=x;c.y=y;c.w=w;c.h=h;c.color=color;layer_submit(&c,0);return;}
    if(x<0||y<0||x+w>1280||y+h>720||w<=0||h<=0)fatal("RECT",-1);
    if(x<1072)mark_damage(x,y,w,h);
    bb_job j={BB_FILL_OP,0,framebuffer+y*BB_SCREEN_STRIDE+x*4,0,BB_SCREEN_STRIDE,w,h,color,255,BB_KEY,0};execute(&j);
}
void scene_text(int x,int y,const char *text,uint32_t color,unsigned scale){
    if(cancelled)return;
    if(hud_capture){hud_record(1,x,y,(int)strlen(text)*6*(int)scale,7*(int)scale,color,scale,text);return;}
    if(layer_capture){
        if(!text||!scale)return;
        if(scale>65535)fatal("LAYER SCALE",(int)scale);
        RqCommand c={0};c.kind=RQ_TEXT;c.x=x;c.y=y;c.color=color;c.scale=(uint16_t)scale;layer_submit(&c,text);return;
    }
    /* The batch writes only x=32..1055. CPU HUD writes may run concurrently,
       but all field text and generic jobs still wait for completion. */
    unsigned w=(unsigned)strlen(text)*6*scale,h=7*scale;
    if(!(pending_job && previous.op==2 && x>=1072 && y>=0 &&
         (unsigned)x+w<=1280 && (unsigned)y+h<=720))finish_job();
    if(x<1072){
        mark_damage(x,y,w,h);
        /* Field overlays must stay inside the area restored on both buffers. */
        draw_text_clipped(framebuffer,x,y,text,color,scale,32,16,1056,704);
    }else draw_text(framebuffer,x,y,text,color,scale);
}
void scene_init(void){
    rq_reset();layer_capture=layers_started=0;layer_pending_sprites=hud_cpu_overlap=0;hud_dma_active=hud_dma_cpu_writes=hud_dma_gpu_writes=0;scene_clip_reset();
    initialized_frames=0;cache_valid=0;pending_job=0;damage_count[0]=damage_count[1]=0;hud_capture=hud_used=0;scene_hud_invalidate();
    scene_bullets_reset();hud_text_cache_reset();
    volatile uint32_t *art=(volatile uint32_t *)ART_BASE;
    for(unsigned i=0;i<sizeof(art_pixels);++i)art[i]=art_palette[art_pixels[i]];
    background_prepare(game_cfg.background_depth_enabled);
    volatile uint32_t *bg=(volatile uint32_t *)BACKGROUND;
    for(unsigned y=0;y<720;++y)for(unsigned x=0;x<1280;++x)
        bg[y*1280+x]=background_pixel(x,y);
    draw_text(BACKGROUND,1078,28,"TOUHOU",0xece3f4,3);
    draw_text(BACKGROUND,1078,58,"SCARLET NIGHT",0xe86b82,1);
    draw_text(BACKGROUND,1078,80,"PHASE BATTLE",0xf5cf77,1);
    draw_text(BACKGROUND,1078,98,"RUMIA CIRNO MEILING",0xaebce6,1);
    if(bb_publish()!=BB_OK)fatal("ART PUBLISH",-1);
}
static void restore_rect(int x,int y,int w,int h){
    unsigned offset=(unsigned)y*BB_SCREEN_STRIDE+(unsigned)x*4;
    bb_job j={BB_COPY_OP,BACKGROUND+offset,framebuffer+offset,BB_SCREEN_STRIDE,BB_SCREEN_STRIDE,w,h,0,255,BB_KEY,0};execute(&j);
}

static int hud_intersects(const HudCommand *c,int top,int bottom){
    return c->x<1280 && c->x+c->w>HUD_LEFT && c->y<bottom && c->y+c->h>top;
}
static int hud_same_row_range(unsigned bank,int top,int bottom,unsigned first,unsigned end_a,unsigned end_b){
    unsigned a=first,b=first;
    for(;;){
        while(a<end_a&&!hud_intersects(&hud_current[a],top,bottom))++a;
        while(b<end_b&&!hud_intersects(&hud_saved[bank][b],top,bottom))++b;
        if(a==end_a||b==end_b)return a==end_a&&b==end_b;
        if(!hud_same_command(&hud_current[a++],&hud_saved[bank][b++]))return 0;
    }
}
/* Equal command counts are the usual HUD case. Compare each command once,
   marking both its old and new coverage, then redraw commands in their original
   painter order inside each dirty band. Exact equality; no hash collisions. */
static void hud_mark_rows(uint32_t *mask,uint16_t *left,uint16_t *right,const HudCommand *c){
    if(!hud_cpu_overlap){
        /* Preserve legacy unusual-size dirty-row and job-trace semantics. */
        if(!hud_intersects(c,HUD_TOP,HUD_BOTTOM))return;
        int top=c->y,bottom=c->y+c->h;
        if(top<HUD_TOP)top=HUD_TOP;if(bottom>HUD_BOTTOM)bottom=HUD_BOTTOM;
        if(top>=bottom)return;
        unsigned first=(unsigned)(top-HUD_TOP)/8,last=(unsigned)(bottom-1-HUD_TOP)/8;
        for(unsigned row=first;row<=last;++row)mask[row>>5]|=1u<<(row&31);
        return;
    }
    /* Union the old and new command bounds separately on each eight-pixel row.
       Restore and replay every intersecting command in original painter order. */
    int64_t x0=c->x,x1=x0+c->w,y0=c->y,y1=y0+c->h;
    if(x0<HUD_LEFT)x0=HUD_LEFT;if(x1>1280)x1=1280;
    if(y0<HUD_TOP)y0=HUD_TOP;if(y1>HUD_BOTTOM)y1=HUD_BOTTOM;
    if(x0>=x1||y0>=y1)return;
    unsigned first=(unsigned)(y0-HUD_TOP)/8,last=(unsigned)(y1-1-HUD_TOP)/8;
    for(unsigned row=first;row<=last;++row){
        mask[row>>5]|=1u<<(row&31);
        if(x0<left[row])left[row]=(uint16_t)x0;
        if(x1>right[row])right[row]=(uint16_t)x1;
    }
}
static int hud_mask_has(const uint32_t *mask,unsigned row){return (mask[row>>5]>>(row&31))&1u;}
/* The background is immutable after scene_init, and no destination reads
   are needed. Do not invalidate/acquire the DCache while OP2 is active.
   These whole-word stores stay strictly in the right HUD's aligned region;
   scene_end's existing publish performs the posted-store drain before swap. */
static void hud_cpu_restore(int left,int top,int right,int bottom){
    for(int y=top;y<bottom;++y){
        const uint32_t *s=(const uint32_t *)(uintptr_t)(BACKGROUND+(unsigned)y*BB_SCREEN_STRIDE+(unsigned)left*4u);
        volatile uint32_t *d=(volatile uint32_t *)(uintptr_t)(framebuffer+(unsigned)y*BB_SCREEN_STRIDE+(unsigned)left*4u);
        unsigned w=(unsigned)(right-left),x=0;
        for(;x+4<=w;x+=4){d[x]=s[x];d[x+1]=s[x+1];d[x+2]=s[x+2];d[x+3]=s[x+3];}
        for(;x<w;++x)d[x]=s[x];
    }
}
static void hud_cpu_fill(int x,int y,int w,int h,uint32_t color){
    for(int row=0;row<h;++row){
        volatile uint32_t *d=(volatile uint32_t *)(uintptr_t)(framebuffer+(unsigned)(y+row)*BB_SCREEN_STRIDE+(unsigned)x*4u);
        int col=0;for(;col+4<=w;col+=4){d[col]=color;d[col+1]=color;d[col+2]=color;d[col+3]=color;}
        for(;col<w;++col)d[col]=color;
    }
}
static void hud_draw_end(void){
    hud_capture=0;
    unsigned bank=damage_bank;
    if(cancelled){scene_hud_invalidate();return;}
    uint32_t dirty[(HUD_ROWS+31)/32]={0};
    uint32_t changed[(HUD_COMMAND_CAP+31)/32]={0};
    unsigned reuse_rows=hud_cache_enabled&&hud_valid[bank];
    unsigned fast_rows=reuse_rows&&hud_count==hud_saved_count[bank];
    uint16_t left[HUD_ROWS],right[HUD_ROWS];
    for(unsigned r=0;r<HUD_ROWS;++r){left[r]=reuse_rows?1280:HUD_LEFT;right[r]=reuse_rows?HUD_LEFT:1280;}
    if(fast_rows){
        unsigned any_row=0,any_change=0;
        for(unsigned i=0;i<hud_count;++i)if(!hud_same_command(&hud_current[i],&hud_saved[bank][i])){
            any_change=1;
            changed[i>>5]|=1u<<(i&31);hud_mark_rows(dirty,left,right,&hud_saved[bank][i]);hud_mark_rows(dirty,left,right,&hud_current[i]);
        }
        for(unsigned i=0;i<(HUD_ROWS+31)/32;++i)any_row|=dirty[i];
        if(!any_row){
            if(any_change)hud_save_commands(bank,changed);
            return;
        }
    }
    if(reuse_rows&&!fast_rows){
        /* The same painter-order prefix and suffix cancel after row filtering.
           Only the unmatched middle can change a row. Keep exact comparisons,
           including the original treatment of unusual zero/negative sizes. */
        unsigned first=0,end_a=hud_count,end_b=hud_saved_count[bank];
        while(first<end_a&&first<end_b&&hud_same_command(&hud_current[first],&hud_saved[bank][first]))++first;
        while(end_a>first&&end_b>first&&hud_same_command(&hud_current[end_a-1],&hud_saved[bank][end_b-1])){--end_a;--end_b;}
        unsigned unusual=0;
        for(unsigned i=first;i<end_a;++i){hud_mark_rows(dirty,left,right,&hud_current[i]);unusual|=hud_current[i].w<=0||hud_current[i].h<=0;}
        for(unsigned i=first;i<end_b;++i){hud_mark_rows(dirty,left,right,&hud_saved[bank][i]);unusual|=hud_saved[bank][i].w<=0||hud_saved[bank][i].h<=0;}
        if(unusual){
            for(unsigned i=0;i<(HUD_ROWS+31)/32;++i)dirty[i]=~0u;
            for(unsigned r=0;r<HUD_ROWS;++r){left[r]=HUD_LEFT;right[r]=1280;}
        }
        for(unsigned row=0;row<HUD_ROWS;++row)if(hud_mask_has(dirty,row)){
            int top=HUD_TOP+(int)row*8,bottom=top+8;if(bottom>HUD_BOTTOM)bottom=HUD_BOTTOM;
            if(hud_same_row_range(bank,top,bottom,first,end_a,end_b))dirty[row>>5]&=~(1u<<(row&31));
        }
    }
    /* Keep the established legacy CPU/hardware job sequence unchanged.
       The pipelined CPU HUD alone uses horizontal dirty spans. */
    if(!hud_cpu_overlap)for(unsigned r=0;r<HUD_ROWS;++r){left[r]=HUD_LEFT;right[r]=1280;}
    unsigned row=0;
    while(row<HUD_ROWS){
        int top=HUD_TOP+(int)row*8,bottom=top+8;if(bottom>HUD_BOTTOM)bottom=HUD_BOTTOM;
        if(reuse_rows&&!hud_mask_has(dirty,row)){++row;continue;}
        unsigned first=row++;int l=left[first],r=right[first];
        while(row<HUD_ROWS){
            int t=HUD_TOP+(int)row*8,b=t+8;if(b>HUD_BOTTOM)b=HUD_BOTTOM;
            if((reuse_rows&&!hud_mask_has(dirty,row))||left[row]!=l||right[row]!=r)break;
            ++row;
        }
        top=HUD_TOP+(int)first*8;bottom=HUD_TOP+(int)row*8;if(bottom>HUD_BOTTOM)bottom=HUD_BOTTOM;
        if(hud_cpu_overlap&&!hud_dma_active)hud_cpu_restore(l,top,r,bottom);
        else restore_rect(l,top,r-l,bottom-top);
        scene_hud_restored_rows+=row-first;++scene_hud_redraw_jobs;
        if(hud_deferred&&pipe_rx_service)pipe_rx_service();
        for(unsigned i=0;i<hud_count&&!cancelled;++i){
            const HudCommand *c=&hud_current[i];if(!hud_intersects(c,top,bottom))continue;
            if(c->kind){
                if((hud_cpu_overlap&&!hud_dma_active)||c->x<l||(int64_t)c->x+c->w>r||!hud_text_cached(c,top,bottom)){
                    if(hud_dma_active){
                        finish_job();
                        if(hud_dma_gpu_writes){
                            if(bb_publish()!=BB_OK)fatal("HUD DMA ACQUIRE DRAIN",-1);
                            bb_acquire();hud_dma_gpu_writes=0;hud_dma_cpu_writes=0;
                        }
                    }else if(!hud_cpu_overlap)finish_job();
                    draw_text_clipped(framebuffer,c->x,c->y,c->text,c->color,c->scale,l,top,r,bottom);
                    if(hud_dma_active)hud_dma_cpu_writes=1;
                }
            }else{
                int x=c->x,y=c->y,w=c->w,h=c->h;
                if(x<l){w-=l-x;x=l;}if(x+w>r)w=r-x;
                if(y<top){h-=top-y;y=top;}if(y+h>bottom)h=bottom-y;
                if(w>0&&h>0){if(hud_cpu_overlap&&!hud_dma_active)hud_cpu_fill(x,y,w,h,c->color);else {bb_job j={BB_FILL_OP,0,framebuffer+y*BB_SCREEN_STRIDE+x*4,0,BB_SCREEN_STRIDE,w,h,c->color,255,BB_KEY,0};execute(&j);}++scene_hud_redraw_jobs;}
            }
        }
    }
    if(cancelled){scene_hud_invalidate();return;}
    hud_save_commands(bank,fast_rows?changed:0);
    hud_saved_count[bank]=hud_count;hud_valid[bank]=1;
}
void scene_hud_end(void){
    if(defer_hud&&hud_cpu_overlap){hud_capture=0;hud_deferred=1;defer_hud=0;return;}
    hud_draw_end();
    if(hud_cpu_overlap){SCENE_FENCE();scene_sprite_count=hud_sprite_base;hud_cpu_overlap=0;}
}
static void scene_pipe_draw_hud_dma(void){
    if(!hardware||!hud_cpu_overlap||hud_dma_active)fatal("HUD DMA CONTEXT",-1);
#ifndef BB_HOST_TEST
    if(motion_hw_active())fatal("HUD DMA MOTION COMMIT",-1);
#else
    if(!scene_test_motion_committed())fatal("HUD DMA MOTION COMMIT",-1);
#endif
    scene_pipe_check_fault();
    unsigned epoch=frame_pipe_epoch;
    if(!(scene_read(0x4c)&PIPE5_CAP_CONCURRENT_EPOCH)||!epoch||
       (scene_read(PIPE5_M_STATUS)&(PIPE5_BUSY|PIPE5_ERROR)))fatal("HUD DMA MOTION BUSY",-1);
    /* No legacy command before R terminal and validated M acquire. */
    finish_job();scene_pipe_check_fault();
    if((scene_read(PIPE5_R_STATUS)&(PIPE5_BUSY|PIPE5_DONE|PIPE5_ERROR))!=PIPE5_DONE||
       scene_read(PIPE5_R_DONE_EPOCH)!=epoch||
       (scene_read(PIPE5_M_STATUS)&(PIPE5_BUSY|PIPE5_ERROR)))fatal("HUD DMA R EPOCH",-1);
    if(bb_publish()!=BB_OK)fatal("HUD DMA BEGIN PUBLISH",-1);
    hud_dma_active=1;hud_dma_cpu_writes=hud_dma_gpu_writes=0;
    hud_draw_end();finish_job();scene_pipe_check_fault();
    if(bb_publish()!=BB_OK)fatal("HUD DMA END PUBLISH",-1);bb_acquire();
    hud_dma_active=hud_dma_cpu_writes=hud_dma_gpu_writes=0;
    SCENE_FENCE();scene_sprite_count=hud_sprite_base;hud_cpu_overlap=0;hud_deferred=0;
}
void scene_pipe_draw_hud(void){
    if(!hud_deferred)return;
    if(hud_dma_tail_enabled){scene_pipe_draw_hud_dma();return;}
    scene_pipe_check_fault();hud_draw_end();
    SCENE_FENCE();scene_sprite_count=hud_sprite_base;hud_cpu_overlap=0;hud_deferred=0;
}
void scene_set_batch(unsigned enabled){
    if(batch_mode!=enabled){finish_job();scene_hud_invalidate();batch_mode=enabled;initialized_frames=0;damage_count[0]=damage_count[1]=0;}
}
void scene_begin(uint32_t fb,unsigned hw){
    if(fallback_hold_epoch)fatal("PIPE FALLBACK NOT RETURNED",-1);
    if(hud_deferred)fatal("PIPE FRAME HUD",-1);
    if(rq_count())fatal("LAYER FRAME END",-1);
    layer_capture=layers_started=0;layer_pending_sprites=hud_cpu_overlap=0;rq_reset();scene_layer_commands=scene_layer_peak=scene_layer_clipped=scene_layer_reordered=0;scene_clip_reset();
    finish_job();
    framebuffer=fb;hardware=hw;scene_jobs=0;scene_sprite_count=0;scene_batch_cycles=scene_list_us=0;cancelled=0;frame_pipe_epoch=batch_fallback=defer_hud=0;memset(&frame_submission,0,sizeof frame_submission);
    if(!hw)bb_acquire();
    unsigned bit=fb==BB_FB0?1:fb==BB_FB1?2:0;
    if(!bit)fatal("SCENE FRAMEBUFFER",-1);
    damage_bank=fb==BB_FB1;
    if(!(initialized_frames&bit)){
        restore_rect(0,0,1024,720);restore_rect(1024,0,256,720);initialized_frames|=bit;
    }else{
        /* The play field is rebuilt by the batch background; CPU fallback and
           non-batch modes restore the tracked rectangles. The full right-hand
           HUD is restored every frame because score/HP/level text can shrink,
           and stale glyphs are not allowed on either buffer. */
        if(batch_mode && !hw)restore_rect(32,16,1024,688);
        if(!batch_mode)for(unsigned i=0;i<damage_count[damage_bank];++i){
            volatile Damage *d=&DAMAGE[damage_bank*DAMAGE_CAP+i];
            restore_rect(d->x,d->y,d->w,d->h);
        }
        if(!hud_used)restore_rect(1072,118,208,586);
    }
    damage_count[damage_bank]=0;
}
void scene_end(void){if(batch_preflight_pending)fatal("END BEFORE PREFLIGHT",-1);if(hud_deferred)fatal("PIPE END HUD",-1);scene_layers_flush();layer_capture=0;finish_job();scene_pipe_check_fault();
    if(segment_diag_active&&!scene_pipe_fallback())segment_diag_cut(SD_FRAME_DRAIN);
    if(bb_publish()!=BB_OK)fatal("FRAME PUBLISH",-1);
    if(segment_diag_active&&!scene_pipe_fallback())segment_diag_cut(SD_FRAME_PUBLISH);
    if(fallback_hold_epoch){
        unsigned status=scene_read(PIPE5_R_STATUS);
        if((status&(PIPE5_BUSY|PIPE5_DONE|PIPE5_ERROR|PIPE5_FALLBACK_PENDING))!=(PIPE5_DONE|PIPE5_FALLBACK_PENDING)||
          scene_read(PIPE5_R_DONE_EPOCH)!=fallback_hold_epoch||scene_read(PIPE5_R_SNAP_EPOCH)||
          scene_read(PIPE5_R_SNAP_STATUS)!=(PIPE5_SNAP_DECIDED|PIPE5_SNAP_NO_DRAW)||
          (scene_read(BB_STATUS)&(BB_BUSY|BB_ERROR)))fatal("PIPE FALLBACK RETURN",-1);
        scene_write(PIPE5_R_EPOCH,fallback_hold_epoch);SCENE_FENCE();scene_write(PIPE5_R_CMD,PIPE5_FALLBACK_DONE);
        if(scene_read(PIPE5_R_STATUS)&(PIPE5_FALLBACK_PENDING|PIPE5_ERROR))fatal("PIPE FALLBACK ACK",-1);
        fallback_hold_epoch=0;
    }
    if(cancelled){scene_hud_invalidate();initialized_frames=0;damage_count[0]=damage_count[1]=0;}
}

/* Standard-register batch extension: op/source/destination/width/height,
   descriptor pointer in FILL, count and material base in extension registers. */
static unsigned batch32_inside(void){
    /* OP2's compact normalized coordinates deliberately describe complete
       sprites. Preserve the ordered clipped COPY path for the whole frame if
       even one large sprite is partial, outside, or has an invalid material.
       This keeps blending order and does not silently discard edge pixels. */
    const unsigned first=battle_materials?54u:24u;
    for(unsigned i=0;i<stage.count;++i){
        const Shot *s=&stage.shots[i];
        int x=s->x/Q,y=s->y/Q;
        if(x<16||x>1008||y<16||y>672||s->tile<first||s->tile>=first+16u)return 0;
    }
    return 1;
}
/* New capability bit3 promises a complete snapshot decision before any
   framebuffer write. A NO_DRAW is not a bus/header error and is the sole
   condition permitted to enter the old ordered whole-frame COPY fallback. */
static unsigned batch_preflight_fallback(void){
    uint64_t start=bb_ticks();SCENE_FENCE();
    for(;;){
        if(pending_pipe_job)scene_pipe_check_fault();unsigned status=scene_read(pending_pipe_job?PIPE5_R_STATUS:BB_STATUS);
        if(status&BB_ERROR)fatal("PREFLIGHT ENGINE",(int)status);
        unsigned snapshot=scene_read(pending_pipe_job?PIPE5_R_SNAP_STATUS:0x54);
        if(snapshot&1u){
            if(snapshot&2u){unsigned independent=pending_pipe_job,epoch=pending_epoch;finish_job();batch_fallback=1;if(independent)fallback_hold_epoch=epoch;return 1;}
            return 0;
        }
        if((status&(BB_BUSY|BB_DONE))==BB_DONE)fatal("PREFLIGHT MISSING RESULT",(int)status);
        if(bb_us(bb_ticks()-start)>100000)fatal("PREFLIGHT TIMEOUT",(int)status);
    }
}
static void scene_restore_rejected_batch(bb_job j){
    scene_sprite_count-=batch_count;batch_count=0;scene_write(0x44,0);
    if(fallback_hold_epoch){j.op=BB_COPY_OP;j.fill=0;j.alpha=255;j.flags=0;}
    else j.flags=BB_ALPHA_ENABLE|BB_KEY_ENABLE;
    execute(&j);
}
static void scene_ordered_shots(void){
    if(bullet_size!=8){
        unsigned first=battle_materials?54u:24u;
        uint32_t atlas=battle_materials?BULLET_ATLAS1:BULLET_ATLAS0;
        for(unsigned i=0;i<stage.count&&!cancelled;++i){
            const Shot *b=&stage.shots[i];
            if(b->tile<first||b->tile>=first+16u)fatal("BULLET TILE",(int)b->tile);
            int x=32+b->x/Q-(int)bullet_size/2,y=16+b->y/Q-(int)bullet_size/2;
            int dx,dy,w,h;
            if(!clipped_bounds(x,y,(int)bullet_size,(int)bullet_size,32,16,1056,704,&dx,&dy,&w,&h))continue;
            unsigned sx=(unsigned)(dx-x),sy=(unsigned)(dy-y);
            bb_job j={BB_COPY_OP,atlas+(b->tile-first)*BULLET_ATLAS_SLOT+(sy*BULLET_ATLAS_SIDE+sx)*4u,
                framebuffer+(unsigned)dy*BB_SCREEN_STRIDE+(unsigned)dx*4u,
                BULLET_ATLAS_SIDE*4u,BB_SCREEN_STRIDE,(unsigned)w,(unsigned)h,0,224,BB_KEY,BB_ALPHA_ENABLE|BB_KEY_ENABLE};
            ++scene_sprite_count;execute(&j);
        }
        return;
    }
    if(!hardware||batch_fallback){
        for(unsigned i=0;i<stage.count&&!cancelled;++i){Shot *b=&stage.shots[i];scene_tile(32+b->x/Q-4,16+b->y/Q-4,b->tile,224);}
        return;
    }
}
/* The captured layer queue is independent of the immutable descriptor source.
   Snapshot validation stays mandatory before motion or any field draw. */
void scene_batch_resolve(void){
    if(!batch_preflight_pending)return;
    batch_preflight_pending=0;
    if(!batch_preflight_fallback())return;
    unsigned capture=layer_capture;
    layer_capture=0; /* fallback bullets precede the already captured actors */
    scene_restore_rejected_batch(batch_preflight_job);
    scene_ordered_shots();
    layer_capture=capture;
}
void scene_batch_shots_deferred(void){
    if(batch_preflight_pending)fatal("PREFLIGHT ALREADY PENDING",-1);
    batch_defer_preflight=1;scene_batch_shots();batch_defer_preflight=0;
}
void scene_batch_shots(void){
    if(layers_started)fatal("LAYER BATCH ORDER",-1);
    if(!batch_mode)fatal("BATCH MODE",-1);
    if(stage.count>SHOT_CAPACITY)fatal("BATCH COUNT",(int)stage.count);
    if(bullet_size!=8&&bullet_atlas_size!=bullet_size)fatal("BULLET ATLAS NOT PREPARED",(int)bullet_size);
    unsigned batch32=0,preflight32=0,preflight8=0;
    /* OP2 zero descriptors is an exact raw-background restore with the burst
       engine. Large sprites then keep their original ordered COPY sequence. */
    if(hardware){
        finish_job();
        const unsigned capabilities=scene_read(0x4c);
        if(!(capabilities&2u))fatal("BATCH CAPABILITY",-1);
        preflight32=bullet_size==32&&(capabilities&12u)==12u;
        preflight8=bullet_size==8&&(capabilities&PIPE5_CAP_PREFLIGHT8);
        batch32=bullet_size==32&&(capabilities&4u)&&(preflight32||batch32_inside());
        uint64_t list_begin=bb_ticks();
        _Static_assert(sizeof(Shot)==16 && offsetof(Shot,tile)==14,"DMA sprite layout");
        uintptr_t list=(uintptr_t)&stage.shots[0];
        batch_count=(bullet_size==8||batch32)?stage.count:0;scene_sprite_count+=batch_count; /* freeze the submitted count for the snapshot test */
        if((list&15)||batch_count>SHOT_CAPACITY)fatal("BATCH DESCRIPTOR",-1);
        if(bb_publish()!=BB_OK)fatal("BATCH PUBLISH",-1);
        scene_list_us=bb_us(bb_ticks()-list_begin);
        unsigned base=battle_materials?54:24;scene_write(0x50,base);scene_write(0x44,batch_count);scene_write(0x48,ART_BASE+tiles[base].off);
        bb_job j={2,BACKGROUND+16*BB_SCREEN_STRIDE+32*4,framebuffer+16*BB_SCREEN_STRIDE+32*4,
            BB_SCREEN_STRIDE,BB_SCREEN_STRIDE,1024,688,(uint32_t)list,224,BB_KEY,BB_ALPHA_ENABLE|BB_KEY_ENABLE|(batch32?4u:0u)|(preflight32?8u:0u)|(preflight8?PIPE5_FLAG_PREFLIGHT8:0u)};
        execute(&j);
        if(preflight32||preflight8){
            if(batch_defer_preflight){batch_preflight_pending=1;batch_preflight_job=j;return;}
            if(!batch_preflight_fallback())return;
            /* Rejected snapshot wrote no field pixels. Restore through the
               original N=0 batch, then use its original ordered clipped COPY
               loop. Do this before layers/HUD so DRAWN includes only actually
               visible clipped sprites, including fully outside sprites. */
            scene_restore_rejected_batch(j);
        }else if(bullet_size==8||batch32)return;
    }
    scene_ordered_shots();
}
