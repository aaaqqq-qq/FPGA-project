# Exact HUD0 dirty-span regression

`reference_scene.c` is the unmodified C284 source copied from
`work/game60_pipe5_prepare_actor_fw_20261103/src/scene.c`.
Its pinned SHA256 is
`1777f74bcf50b9f6d0988739055856cdeeba737008dd2086a3721837afb78fb6`.
The verifier refuses to run if this frozen source changes.

Run `scripts/verify_hud_delta.py` with the Windows Python runtime and
`--host-cc E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe`.
Each run creates a new timestamped `results/hud_delta/` directory, including
both compiler logs, the exact cases, metrics, and PASS/FAIL summary. Failures
are retained; no existing suite or result is changed.

The two renderer libraries use the unchanged independent pixel model from
`tests/hud_span/host.c`. The new host feeds the same command sequence into
both libraries. Every frame compares all pixels of both framebuffers and
ordered field/all-engine job traces. Existing bounds assertions also verify
that concurrent CPU HUD writes affect only the active bank's right HUD.

Coverage includes same-bank reuse and alternating banks, changed/removed
glyphs, digit carries, spaces and extended characters, scales 0 through 5,
newlines, screen and strip boundaries, widths 0/1/185/186, negative and huge
dimensions, moved/recoloured commands, insert/delete/reorder and overlapping
commands, cache toggles, immediate/deferred HUD, non-overlap CPU/hardware,
and full 20000 x 8 / 5000 x 32 shot scenes. Exact equality is required;
no tolerance or ignored HUD region is used.

The candidate only narrows damage when CPU overlap is active and HUD DMA is
inactive. Normal same-origin/same-colour single-line text marks changed
5-by-7 glyph cells. Normal same-origin/same-height/same-colour rectangles
mark their width difference. Other cases retain the previous union path.
Restore and redraw preserve the complete painter sequence.

Initial run `20261103_122452_964813` found an oversized-width counterexample:
the old renderer's 32-bit intersection expression and 64-bit delta geometry
disagreed. The fix limits rectangle delta eligibility to normal screen
coordinates and bounded dimensions. That original failing run and case
remain unchanged; subsequent exact tests include the same case.

Pixel and operation-count tests are host evidence. They do not measure
physical cache behaviour, DDR arbitration, clock timing, or FPS.
