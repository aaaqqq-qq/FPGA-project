/* Reuse the unchanged, independently rasterizing scene model and safety checks.
   Test command generation is separate from either renderer. */
#include "../hud_span/host.c"
static unsigned delta_pending,delta_op,delta_drawn,delta_fb,delta_hw,delta_layered;
__declspec(dllexport) void delta_begin(unsigned frame,unsigned bank,unsigned hw,
                                      unsigned layered,unsigned cache,unsigned size,
                                      unsigned count,unsigned deferred){
 const uint32_t fb=bank?BB_FB1:BB_FB0;
 assert(scene_bullets_prepare(size));battle_materials=frame%2;
 scene_hud_cache_enable(cache);scene_set_batch(1);scene_begin(fb,hw);
 stage.count=count;
 for(unsigned i=0;i<count;++i){unsigned half=size/2;
  stage.shots[i]=(Shot){(int32_t)(half+(i*37+frame*11)%(1025-size))*Q,
   (int32_t)(half+(i*17+frame*7)%(689-size))*Q,0,0,17,
   (uint8_t)((battle_materials?54:24)+(i%16)),0};
 }
 trace_hash=2166136261u;trace_count=0;scene_batch_shots();
 assert(scene_sprite_count==count);scene_layers_begin(layered);
 for(unsigned i=0;i<9;++i){
  scene_layer(i%8,(int)(i*7%19)-9);
  scene_tile(30+(int)(i*127),10+(int)(i*79),i%24,(unsigned[]){0,128,224,255}[i%4]);
  scene_rect(70+(int)(i*91),55+(int)(i*67),15,7,0x507090+i);
 }
 scene_layer(SCENE_LAYER_WORLD_UI,0);
 scene_text(45,620,"FIELD KEEP ORDER",0xf0cc8d,1);
 delta_fb=fb;delta_hw=hw;delta_layered=layered;
 delta_pending=pending;delta_op=regs[BB_OP/4];
 scene_pipe_defer_hud(deferred);snapshot();scene_hud_begin();delta_drawn=scene_sprite_count;
}
__declspec(dllexport) void delta_command(unsigned kind,int x,int y,int w,int h,
                                        unsigned color,unsigned scale,const char *text){
 if(kind)scene_text(x,y,text,color,scale);else scene_rect(x,y,w,h,color);
}
__declspec(dllexport) void delta_end(void){
 scene_hud_end();scene_pipe_draw_hud();
 if(delta_pending&&delta_op==2&&delta_hw&&delta_layered){
  assert(pending&&regs[BB_OP/4]==2);assert(regs[BB_STATUS/4]==BB_BUSY);
  strict_right_only(delta_fb);++overlap_frames;
 }
 scene_layers_flush();scene_end();assert(!pending&&!scene_cancelled());
 assert(delta_drawn==scene_sprite_count);
}
