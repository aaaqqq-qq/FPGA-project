#include "pipe5_game_stubs.h"
/* R7 renderer APIs are no-ops only in this gameplay/command stub. */
#include "scene_layers_stubs.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <stdint.h>
#include <assert.h>

#define main firmware_main
#include "game.c"
#undef main
#include "lab_stubs.h"

unsigned scene_list_us, scene_batch_cycles, scene_jobs;
void scene_init(void) {}
void scene_begin(uint32_t fb, unsigned hw) { (void)fb; (void)hw; }
void scene_tile(int x, int y, unsigned tile, unsigned alpha) { (void)x; (void)y; (void)tile; (void)alpha; }
void scene_rect(int x, int y, int w, int h, uint32_t c) { (void)x; (void)y; (void)w; (void)h; (void)c; }
void scene_text(int x, int y, const char *t, uint32_t c, unsigned s) { (void)x; (void)y; (void)t; (void)c; (void)s; }
void scene_end(void) {}
void scene_set_batch(unsigned e) { (void)e; }
void scene_batch_shots(void) {}
void scene_batch_snapshot_ready(void) {}
unsigned scene_cancelled(void) { return 0; }

static uint64_t host_ticks;
uint32_t bb_read(unsigned reg) { (void)reg; return 0; }
void bb_write(unsigned reg, uint32_t v) { (void)reg; (void)v; }
uint64_t bb_ticks(void) { return ++host_ticks; }
uint32_t bb_us(uint64_t t) { return (uint32_t)t; }
bb_result bb_probe(void) { return BB_OK; }
bb_result bb_publish(void) { return BB_OK; }
void bb_acquire(void) {}
bb_result bb_swap_wait(uint32_t fb, uint32_t t) { (void)fb; (void)t; return BB_OK; }

static unsigned host_raw = 15,host_gpio_reads;
unsigned gpio_getInput(unsigned g) { (void)g;++host_gpio_reads;return host_raw; }
void gpio_setOutputEnable(unsigned g, unsigned m) { (void)g; (void)m; }
void bsp_init(void) {}
void bsp_printf(const char *fmt, ...) { va_list ap; va_start(ap, fmt); vprintf(fmt, ap); va_end(ap); }
unsigned uart_writeAvailability(unsigned u) { (void)u; return 0; }
void uart_write(unsigned u, unsigned c) { (void)u; (void)c; }
unsigned uart_readOccupancy(unsigned u) { (void)u; return 0; }
char uart_read(unsigned u) { (void)u; return 0; }
unsigned csr_read(unsigned c) { return c; }

static void hit_once(void) {
    player.spawn_invuln = player.bomb_invuln = player.upgrade_invuln = player.hit_invuln = 0;
    demo_invincible = 0;
    keys = edges = 0;
    stage.count = 1;
    stage.shots[0] = (Shot){player.x * Q, player.y * Q, 0, 0, 30, 24, 0};
    logic();
}

int main(void) {
    game_config_defaults();
    choice = 5; capacity_level = 0; demo_invincible = 0; start();
    assert(mode == DODGE && stage.count == 64 && hardware == 1);
    player.hit_invuln = 10000;

    keys = 2; logic(); assert(player.x == 518);
    keys = 1; logic(); assert(player.x == 512);
    keys = 4; logic(); assert(player.y == 614);
    keys = 8; logic(); assert(player.y == 620);
    keys = 3; edges = 0; logic(); assert(player.x == 512);
    keys = edges = 0;bomb_requests=1;unsigned n = stage.count;logic();
    assert(player.bombs == 2 && stage.count == n && player.bomb_invuln > 0);

    start(); player.hit_invuln = 10000;
    hit_once(); assert(player.lives == 2 && mode == DODGE);
    hit_once(); assert(player.lives == 1 && mode == DODGE);
    hit_once(); assert(player.lives == 0 && mode == LOST);

    start(); player.hit_invuln = 20000; demo_invincible = 0;
    for (unsigned i = 0; i < 12000; ++i) logic();
    assert(mode == CLEARED && ticks >= ROUND_FRAMES);

    /* LAB1 intentionally has no debounce/hold-menu board path. */
    remote_input_init(&remote);mode=STRESS;hardware=0;host_ticks=0;
    for(unsigned value=0;value<16;++value){host_raw=value;buttons();}
    assert(!host_gpio_reads&&mode==STRESS&&hardware==0);
    unsigned char packet[]={0xa5,0x5a,0,REMOTE_MENU,0,REMOTE_MENU^0xa7};
    for(unsigned i=0;i<6;++i)remote_input_feed(&remote,packet[i],i);
    buttons();assert(mode==MENU&&hardware==1);
    printf("PASS dodge gameplay,PC bomb/menu,board keys ignored\n");
    return 0;
}

void scene_hud_begin(void) {}
void scene_hud_end(void) {}
void scene_hud_invalidate(void) {}
void scene_hud_cache_enable(unsigned e) {(void)e;}

unsigned scene_hud_restored_rows,scene_hud_redraw_jobs,scene_sprite_count;
