/* Executes the real lab.c with bounded in-memory DMA and independent reference
   images. This is logic/scheduling/readback evidence, not board/cache evidence. */
#include "lab.h"
#include "bitblt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <windows.h>
#else
#include <sys/mman.h>
#endif

static uint32_t front=BB_FB0;
static unsigned jobs,publishes,acquires,swaps,restores,checks;
static unsigned inject_error,inject_pixel,inject_guard,restore_error;
static unsigned next_id=1;
static uint64_t ticks;
static char lines[64][192];
static unsigned line_count;
static uint32_t expected[1280u*720u];
#define REQUIRE(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static uint32_t *mem(uint32_t a){return (uint32_t *)(uintptr_t)a;}
uint64_t bb_ticks(void){ticks+=100;return ticks;}
uint32_t bb_us(uint64_t value){return (uint32_t)value;}
uint32_t bb_read(unsigned r){return r==BB_FRONT?front:0;}
void bb_write(unsigned r,uint32_t v){(void)r;(void)v;REQUIRE(0);}
bb_result bb_publish(void){++publishes;return BB_OK;}
void bb_acquire(void){++acquires;}
bb_result bb_execute(const bb_job *j,bb_metrics *m){
    REQUIRE(bb_validate(j)==BB_OK);
    REQUIRE(j->flags==0 && j->alpha==255 && j->width && j->height);
    REQUIRE(j->dst>=BB_FB0 && j->dst<BB_FB1+BB_FRAME_BYTES);
    REQUIRE(j->width<=1024 && j->dst_stride==BB_SCREEN_STRIDE);
    if(j->op==BB_COPY_OP){REQUIRE(j->src>=LAB_SOURCE_BASE && j->src<LAB_SOURCE_BASE+32768u);REQUIRE(j->src_stride==256);}
    ++jobs;++publishes;
    if(inject_error){inject_error=0;return BB_E_HARDWARE;}
    for(unsigned y=0;y<j->height;++y)for(unsigned x=0;x<j->width;++x)
        mem(j->dst+y*j->dst_stride)[x]=j->op==BB_FILL_OP?j->fill:mem(j->src+y*j->src_stride)[x];
    if(j->op==BB_COPY_OP && inject_pixel){mem(j->dst)[0]^=1;inject_pixel=0;}
    if(j->op==BB_COPY_OP && inject_guard){mem((j->dst<BB_FB1?BB_FB0:BB_FB1)+BB_FRAME_BYTES)[3]^=1;inject_guard=0;}
    m->cycles=j->width*j->height+10;
    m->read_bytes=j->op==BB_COPY_OP?j->width*j->height*4u:0;
    m->write_bytes=j->width*j->height*4u;
    return BB_OK;
}
bb_result bb_swap_wait(uint32_t fb,uint32_t timeout){
    REQUIRE(fb==BB_FB0||fb==BB_FB1);REQUIRE(timeout==200000);REQUIRE(acquires>swaps);
    front=fb;++swaps;return BB_OK;
}
static void emit(const char *s){REQUIRE(strlen(s)<192);REQUIRE(strchr(s,'\n')==0);
    REQUIRE(line_count<64);strcpy(lines[line_count++],s);}
static int restore(void){++restores;return restore_error?-1:0;}
static const char *last(void){REQUIRE(line_count>0);return lines[line_count-1];}
static void send_request(unsigned id,const char *op,unsigned service){
    char b[256];snprintf(b,sizeof b,":lab %u %s",id,op);line_count=0;
    REQUIRE(lab_command(b)==1);
    if(service){REQUIRE(lab_pending());REQUIRE(strstr(last(),"LAB_ACK ")==last());
        REQUIRE(strstr(last(),"status=QUEUED")!=0);lab_service();REQUIRE(!lab_pending());}
}
static void pass(const char *op){send_request(next_id++,op,1);REQUIRE(strstr(last(),"status=PASS")!=0);}
static uint32_t palette(unsigned n){static const uint32_t p[]={0x4c8dff,0x7c6df0,0x35b89b,0xf2b65c};return p[n%4];}
static void reference_clear(void){for(unsigned n=0;n<1280u*720u;++n)expected[n]=0xf4f6fa;}
static void reference_fill(unsigned x,unsigned y,unsigned w,unsigned h,uint32_t color){
    reference_clear();for(unsigned yy=y;yy<y+h;++yy)for(unsigned xx=x;xx<x+w;++xx)expected[yy*1280u+xx]=color;}
static void reference_copy(unsigned tile,unsigned sx,unsigned sy,unsigned w,unsigned h,unsigned dx,unsigned dy){
    reference_clear();for(unsigned y=0;y<h;++y)for(unsigned x=0;x<w;++x)
        expected[(dy+y)*1280u+dx+x]=palette(tile?(sx+x)/8u:((sx+x)/8u+(sy+y)/8u));
}
static void reference_pattern(unsigned k){
    const uint32_t p[]={0xf2f2f2,0xf1c75b,0x42c5c2,0x51b875,0xdc6d9b,0xe76565,0x5788d9,0x24262c};
    for(unsigned y=0;y<720;++y)for(unsigned x=0;x<1280;++x){uint32_t c;
        if(k==0)c=x%40==0||y%40==0?0xd4d8e2:0xf4f6fa;
        else if(k==1)c=p[x/160];else c=x==640||y==360?0x4c8dff:0xffffff;
        if(k==2)for(unsigned n=0;n<4;++n){unsigned cx=n&1?1252:12,cy=n&2?692:12;
            if(x>=cx&&x<cx+16&&y>=cy&&y<cy+16)c=palette(n);}
        unsigned b=k==2?4:2;if(x<b||x>=1280-b||y<b||y>=720-b)c=0x40444f;
        expected[y*1280u+x]=c;
    }
}
static void compare_frame(void){REQUIRE(memcmp(expected,mem(front),sizeof expected)==0);}
static uint32_t memory_hash(void){uint32_t hash=2166136261u;
    for(unsigned n=0;n<(BB_FRAME_BYTES+64u)/4u;++n){hash=(hash^mem(BB_FB0)[n])*16777619u;hash=(hash^mem(BB_FB1)[n])*16777619u;}
    for(unsigned n=0;n<((32768u+64u)/4u);++n)hash=(hash^mem(LAB_SOURCE_BASE)[n])*16777619u;
    return hash;
}
static void rejected(const char *op,const char *code){
    uint32_t hash=memory_hash(),f=front,j=jobs,s=swaps;
    send_request(next_id++,op,0);REQUIRE(strstr(last(),"status=ERROR")!=0);REQUIRE(strstr(last(),code)!=0);
    REQUIRE(!lab_pending());lab_service();REQUIRE(hash==memory_hash());REQUIRE(front==f&&jobs==j&&swaps==s);
}
int main(void){
    void *base=(void *)(uintptr_t)0x01000000u;size_t size=0x01300000u;
#ifdef _WIN32
    void *allocation=VirtualAlloc(base,size,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
    if(allocation!=base)fprintf(stderr,"VirtualAlloc failure %lu\n",(unsigned long)GetLastError());
    REQUIRE(allocation==base);
#else
    REQUIRE(mmap(base,size,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_FIXED,-1,0)==base);
#endif
    memset(base,0xa5,size);lab_init(emit,restore);REQUIRE(!lab_active());
    REQUIRE(lab_command("not lab")==0);REQUIRE(lab_command("l")==0);REQUIRE(lab_command("la")==0);
    rejected("fill 0 0 1 1 1","MODE");rejected("exit","MODE");
    send_request(next_id++,"enter",0);REQUIRE(!lab_active()&&lab_pending());
    uint32_t hash=memory_hash();unsigned count=jobs;send_request(next_id++,"enter",0);
    REQUIRE(strstr(last(),"code=BUSY")!=0);REQUIRE(lab_pending()&&count==jobs&&hash==memory_hash());
    lab_service();REQUIRE(lab_active());REQUIRE(strstr(last(),"status=PASS")!=0);
    reference_pattern(0);compare_frame();
    rejected("enter","MODE");
    pass("clear");reference_clear();compare_frame();
    pass("fill 0 0 1 1 0x123456");reference_fill(0,0,1,1,0x123456);compare_frame();
    pass("fill 1279 719 1 1 16777215");reference_fill(1279,719,1,1,0xffffff);compare_frame();
    pass("fill 0 0 1280 720 0x7c6df0");reference_fill(0,0,1280,720,0x7c6df0);compare_frame();
    pass("fill 1000 600 280 120 12");reference_fill(1000,600,280,120,12);compare_frame();
    pass("copy 0 7 11 31 29 123 77");reference_copy(0,7,11,31,29,123,77);compare_frame();
    pass("copy 1 0 0 64 64 1216 656");reference_copy(1,0,0,64,64,1216,656);compare_frame();
    pass("copy 0 63 63 1 1 0 0");reference_copy(0,63,63,1,1,0,0);compare_frame();
    for(unsigned n=0;n<3;++n){char b[32];snprintf(b,sizeof b,"pattern %u",n);pass(b);reference_pattern(n);compare_frame();}
    const char *bad[]={"fill 0 0 0 1 0","fill 0 0 1 0 0","fill 1279 719 2 1 0",
        "fill 0 719 1 2 0","fill 4294967295 1 2 2 0","fill 0 0 1 1 16777216",
        "copy 2 0 0 1 1 0 0","copy 0 63 0 2 2 0 0","copy 0 0 63 1 2 0 0",
        "copy 1 0 0 1 1 1280 0","copy 1 0 0 1 1 0 720","copy 0 0 0 0 1 0 0","pattern 3"};
    for(unsigned n=0;n<sizeof bad/sizeof bad[0];++n)rejected(bad[n],"RANGE");
    const char *syntax[]={"fill -1 0 1 1 0","fill 0 0 1 1 0x","fill 0 0 1 1 0xffffffz",
        "fill 0 0 1 1 4294967296","copy 0 0 0 1 1 0","clear extra","verify extra","bad", "pattern +1"};
    for(unsigned n=0;n<sizeof syntax/sizeof syntax[0];++n)rejected(syntax[n],"PARSE");
    char long_line[180];memset(long_line,'7',sizeof long_line);memcpy(long_line,"fill ",5);long_line[179]=0;
    rejected(long_line,"PARSE");
    pass("verify");REQUIRE(strstr(last(),"passed=9 failed=0")!=0);REQUIRE(line_count==11);
    unsigned case_pass=0;for(unsigned n=0;n<line_count;++n)case_pass+=strstr(lines[n],"LAB_CASE ")==lines[n]&&strstr(lines[n],"status=PASS")!=0;
    REQUIRE(case_pass==9);reference_pattern(2);compare_frame();
    uint32_t oldfront=front;
    inject_pixel=1;send_request(next_id++,"copy 0 0 0 8 8 20 20",1);
    REQUIRE(strstr(last(),"code=VERIFY")!=0&&strstr(last(),"errors=1 ")!=0);REQUIRE(front==oldfront);
    pass("clear");inject_guard=1;oldfront=front;send_request(next_id++,"copy 1 0 0 8 8 20 20",1);
    REQUIRE(strstr(last(),"code=VERIFY")!=0&&strstr(last(),"errors=1 ")!=0);REQUIRE(front==oldfront);
    pass("clear");inject_error=1;oldfront=front;send_request(next_id++,"fill 1 1 4 4 42",1);
    REQUIRE(strstr(last(),"code=ENGINE")!=0);REQUIRE(front==oldfront);
    restore_error=1;send_request(next_id++,"exit",1);REQUIRE(strstr(last(),"code=RESTORE")!=0&&lab_active());
    restore_error=0;pass("exit");REQUIRE(!lab_active()&&restores==2);
    rejected("clear","MODE");
    pass("enter");pass("exit");REQUIRE(restores==3);
    REQUIRE(publishes>jobs&&acquires>0&&swaps>0);
    printf("PASS lab real C: %u assertions; %u opaque DMA jobs; %u swaps; 9 built-in verification cases\n",checks,jobs,swaps);
    printf("SCOPE host memory/DMA model only; board UART, cache, timing, HDMI and 60Hz NOT_RUN\n");
    return 0;
}
