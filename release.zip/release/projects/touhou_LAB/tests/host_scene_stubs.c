/* R7 renderer APIs are no-ops only in this gameplay/command stub. */
#include "scene_layers_stubs.h"
void scene_batch_shots(void){}
#include <stdint.h>
void scene_tile(int x, int y, unsigned t, unsigned a) { (void)x; (void)y; (void)t; (void)a; }
void scene_rect(int x, int y, int w, int h, uint32_t c) { (void)x; (void)y; (void)w; (void)h; (void)c; }
void scene_text(int x, int y, const char *t, uint32_t c, unsigned s) { (void)x; (void)y; (void)t; (void)c; (void)s; }
void fatal(const char *where, int error) { (void)where; (void)error; }
