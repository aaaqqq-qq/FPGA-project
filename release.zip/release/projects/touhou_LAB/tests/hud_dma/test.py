"""Exact HUD pixels plus explicit posted-store/acquire ownership guards."""
from pathlib import Path
import argparse,ctypes,hashlib,json,subprocess,sys
r=Path(__file__).resolve().parents[2];t=r/'tests/hud_dma';out=r/'results/hud_dma';out.mkdir(parents=True,exist_ok=True)
p=argparse.ArgumentParser();p.add_argument('--host-cc',default='E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe');a=p.parse_args();H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert H(t/'reference_scene.c')=='5ab7d81652cd45ac4bdfff64029c7860dddd205d47e698917ef64df2d67c3a0e'
font=(r/'src/font.c').read_text(encoding='utf8').replace('#include "bitblt.h"','#include "bitblt.h"\nextern void hud_dma_test_cpu_store(volatile uint32_t *,uint32_t);').replace('while(p<end)*p++=color;','while(p<end)hud_dma_test_cpu_store(p++,color);')
fp=out/'font.c';fp.write_text(font,encoding='utf8')
libs=[]
for name in ['reference','off','on','no_publish','no_acquire']:
 s=(t/'reference_scene.c' if name=='reference' else r/'src/scene.c').read_text(encoding='utf8')
 if name=='no_publish':
  needle='if(bb_publish()!=BB_OK)fatal("HUD DMA CPU PUBLISH",-1);';assert s.count(needle)==1;s=s.replace(needle,'/* injected missing CPU publish */;')
 if name=='no_acquire':
  needle='bb_acquire();hud_dma_gpu_writes=0;';assert s.count(needle)==1;s=s.replace(needle,'/* injected missing GPU acquire */;hud_dma_gpu_writes=0;')
 s=s.replace('#include "stage.h"','#include "stage.h"\n#define stage (*(Stage *)(uintptr_t)0x02100000u)\nextern void hud_dma_test_cpu_store(volatile uint32_t *,uint32_t);').replace('p[x]=BB_KEY;','hud_dma_test_cpu_store(&p[x],BB_KEY);')
 s+='\nunsigned hud_dma_test_active(void){return '+('0' if name=='reference' else 'hud_dma_active')+';}\n'
 mapped=out/(name+'_scene.c');mapped.write_text(s,encoding='utf8');dll=out/(name+'.dll')
 cmd=[a.host_cc,'-O2','-shared','-UNDEBUG','-DBB_HOST_TEST','-Isrc',str(t/'host.c'),str(mapped),str(fp),'src/pixels.c','src/render_queue.c','src/background.c','src/game_config.c','-o',str(dll)]
 q=subprocess.run(cmd,cwd=r,capture_output=True,text=True);(out/(name+'_compile.log')).write_text(q.stdout+q.stderr,encoding='utf8');assert q.returncode==0,q.stderr
 if name in ['reference','off','on']:libs.append((name,ctypes.CDLL(str(dll))))
k=ctypes.WinDLL('kernel32',use_last_error=True);k.VirtualAlloc.restype=ctypes.c_void_p;k.VirtualAlloc.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32,ctypes.c_uint32]
for addr,size in [(0x1000000,0x1200000),(0x7000000,0x400000),(0x5ff0000,0x90000)]:assert k.VirtualAlloc(addr,size,0x3000,4)==addr
seq=[(f,0 if f%17==15 else 1,0 if f%13==11 else 1,0 if f%19 in (12,13) else 1,32 if f%4<2 else 8,5000 if f in (40,41) else 20000 if f in (42,43) else 257)for f in range(128)]
gold=[];traces=[];metrics=[]
for name,lib in libs:
 ctypes.memset(0x1000000,0xa5,0x1200000);ctypes.memset(0x7000000,0xa5,0x400000);lib.set_dma(0);lib.init_overlap();lib.set_dma(name=='on')
 for n,args in enumerate(seq):
  lib.frame_overlap(*args);address=0x1000000+(0x400000 if args[0]&1 else 0);sha=hashlib.sha256(ctypes.string_at(address,1280*720*4)).hexdigest();trace=(lib.trace()&0xffffffff,lib.trace_jobs())
  if name=='reference':gold.append(sha);traces.append(trace)
  else:assert sha==gold[n] and trace==traces[n],(name,n,args,sha,gold[n],trace,traces[n])
 metrics.append({'variant':name,'overlap_frames':lib.overlap_count(),'ownership_counts':[lib.ownership_count(i)for i in range(5)]})
assert metrics[-1]['ownership_counts'][0]>100 and metrics[-1]['ownership_counts'][1]>100 and metrics[-1]['ownership_counts'][2]>100,metrics
assert metrics[-1]['ownership_counts'][3:]==[0,0]
# Live C/mock uses a real R doorbell/epoch. Missing ownership transitions are
# independently injected and must be rejected by the store/DMA model.
faults=[]
for label,dll,inject,needle in [('M_uncommitted','on',41,'HUD DMA MOTION COMMIT'),('R_wrong_epoch','on',42,'EPOCH'),('missing_publish','no_publish',0,'GPU HUD before CPU publish'),('missing_acquire','no_acquire',0,'CPU read/write of GPU HUD before acquire')]:
 child="import ctypes\nk=ctypes.WinDLL('kernel32');k.VirtualAlloc.restype=ctypes.c_void_p\nfor a,s in [(0x1000000,0x1200000),(0x7000000,0x400000),(0x5ff0000,0x90000)]:assert k.VirtualAlloc(ctypes.c_void_p(a),s,0x3000,4)==a\nf=ctypes.CDLL("+repr(str(out/(dll+'.dll')))+");f.init_overlap();f.set_dma(1);f.set_fault("+str(inject)+");f.frame_overlap(113,1,1,1,8,257)\n"
 q=subprocess.run([sys.executable,'-c',child],capture_output=True,text=True);(out/(label+'.log')).write_text(q.stdout+q.stderr,encoding='utf8');assert q.returncode!=0 and needle in q.stderr,(label,q.returncode,q.stdout,q.stderr);faults.append({'case':label,'exit':q.returncode,'guard':needle})
report={'status':'PASS_HOST_PIXELS_AND_OWNERSHIP_GUARDS','frames':128,'pixels_compared_per_alternative':128*1280*720,'actual_mapped_fullN':'8x20000 and32x5000','metrics':metrics,'faults':faults,'source_sha256':{str(p.relative_to(r)).replace('\\','/'):H(p)for p in [r/'src/scene.c',r/'src/font.c',r/'src/game_config.c',t/'host.c',t/'test.py',t/'reference_scene.c']},'scope':'Full32bit pixels/ordered field jobs vs frozenHUDSPAN and currentdefault-off. Explicit pendingCPUstore counters reject GPU consumption beforepublish; GPUdirty ownership rejects CPUfont writes beforeacquire. Mutation tests provefence-only wouldfail. Model is not actualCPUcache orDDRtiming; realmotion-driver/runtime NO_DRAW andcancel cases are a separate test. No boardFPS claim.','pixel_sha256':gold}
(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print('HUD_DMA',report['status'],metrics,faults)
