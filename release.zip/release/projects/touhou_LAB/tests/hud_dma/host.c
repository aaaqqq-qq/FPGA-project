#include <windows.h>
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scene.h"
#include "pipe5_abi.h"
#include "render_queue.h"
#include "bitblt.h"
#include "stage.h"
#include "art_data.h"
#include "game_config.h"
Stage stage;
unsigned battle_materials;
#define stage (*(Stage *)(uintptr_t)0x02100000u)
static uint32_t regs[64],wait_polls,pending,publish_count;
static uint64_t ticks,pixels_checked;
static unsigned frames,copy_jobs,batch_jobs,cpu_jobs,cancel_after;
static uint32_t *gold;
static unsigned fast32_jobs;
static uint32_t trace_hash;
static unsigned trace_count,overlap_frames,strict_pixels;
extern unsigned hud_dma_test_active(void);
static unsigned fault,ownership_mode,pending_pipe,m_committed,cpu_pending,gpu_dirty,legacy_hud_jobs,ownership_publishes,ownership_acquires;
static int hud_address(uint32_t a){for(unsigned b=0;b<2;++b){uint32_t fb=b?BB_FB1:BB_FB0;if(a>=fb&&a<fb+BB_FRAME_BYTES){unsigned p=(a-fb)/4;return p%1280>=1072&&p/1280>=118&&p/1280<704;}}return 0;}
void hud_dma_test_cpu_store(volatile uint32_t *p,uint32_t value){
 uint32_t a=(uint32_t)(uintptr_t)p;
 if(ownership_mode&&hud_dma_test_active()&&(hud_address(a)||(a>=0x07000000u&&a<0x07240000u))){
  if(hud_address(a))assert(!gpu_dirty&&"CPU read/write of GPU HUD before acquire");
  ++cpu_pending;
 }
 *p=value;
}
unsigned scene_test_motion_committed(void){return m_committed;}
__declspec(dllexport) void set_dma(unsigned enabled){ownership_mode=enabled;hud_dma_tail_enabled=enabled;}
__declspec(dllexport) unsigned ownership_count(unsigned i){unsigned a[]={legacy_hud_jobs,ownership_publishes,ownership_acquires,cpu_pending,gpu_dirty};return a[i];}

static void *at(uint32_t p){return (void *)(uintptr_t)p;}
void fatal(const char *where,int code){fprintf(stderr,"FAIL %s %d\n",where,code);exit(2);}
static void model(const bb_job *j){
    if(j->op==2){
        assert(j->width==1024&&j->height==688&&regs[0x44/4]<=20000);
        bb_job bg=*j;bg.op=BB_COPY_OP;bg.flags=0;bg.fill=0;model(&bg);
        const uint32_t *d=at(j->fill);
        const unsigned side=(j->flags&4u)?32u:8u,half=side/2u;
        if(side==32)++fast32_jobs;
        for(unsigned i=0;i<regs[0x44/4];++i){
            int cx=(int32_t)d[4*i]>>12,cy=(int32_t)d[4*i+1]>>12;
            unsigned tile=((d[4*i+3]>>16)&255u)-regs[0x50/4];
            assert(cx>=(int)half&&cx<=1024-(int)half&&cy>=(int)half&&cy<=688-(int)half&&tile<=15);
            for(unsigned y=0;y<side;++y)for(unsigned x=0;x<side;++x){
                const uint32_t src=*(uint32_t*)at(regs[0x48/4]+tile*256u+(y*8u/side)*32u+(x*8u/side)*4u);
                uint32_t *dst=at(j->dst+(unsigned)(cy-(int)half+(int)y)*5120u+(unsigned)(cx-(int)half+(int)x)*4u);
                if((j->flags&BB_KEY_ENABLE)&&(src&0xffffffu)==(j->key&0xffffffu))continue;
                *dst=(j->flags&BB_ALPHA_ENABLE)?bb_blend(src,*dst,j->alpha):src;
            }
        }
        return;
    }
    assert(bb_validate(j)==BB_OK);
    if(ownership_mode&&hud_dma_test_active()&&hud_address(j->dst)){assert(m_committed&&!(regs[PIPE5_M_STATUS/4]&PIPE5_BUSY));assert(!cpu_pending&&"GPU HUD before CPU publish");gpu_dirty=1;++legacy_hud_jobs;}
    if(j->dst>=BB_FB0&&j->dst<BB_FB1+BB_FRAME_BYTES&&((j->dst%(BB_FB1-BB_FB0))/4u)%1280u<1072u){
        const uint32_t *w=(const uint32_t *)j;for(unsigned z=0;z<sizeof(*j)/4;++z)trace_hash=(trace_hash^w[z])*16777619u;++trace_count;
    }
    for(unsigned y=0;y<j->height;++y)for(unsigned x=0;x<j->width;++x){
        uint32_t addr=j->dst+y*j->dst_stride+x*4u;
        assert((addr>=BB_FB0&&addr<BB_FB0+BB_FRAME_BYTES)||(addr>=BB_FB1&&addr<BB_FB1+BB_FRAME_BYTES));
        uint32_t *d=at(addr),s=j->op==BB_COPY_OP?*(uint32_t *)at(j->src+y*j->src_stride+x*4u):j->fill;
        if(j->op==BB_COPY_OP&&(j->flags&BB_KEY_ENABLE)&&(s&0xffffff)==(j->key&0xffffff))continue;
        *d=(j->flags&BB_ALPHA_ENABLE)?bb_blend(s,*d,j->alpha):s;
    }
}
uint32_t bb_read(unsigned reg){
    if(reg==0x4c)return 126;
    if((reg==BB_STATUS||reg==PIPE5_R_STATUS)&&pending){
        if(fault==1){regs[BB_STATUS/4]=regs[PIPE5_R_STATUS/4]=BB_ERROR;return BB_ERROR;}
        if(wait_polls){--wait_polls;return BB_BUSY;}
        bb_job j;memcpy(&j,&regs[BB_OP/4],sizeof j);model(&j);pending=0;regs[BB_STATUS/4]=BB_DONE;if(pending_pipe){regs[PIPE5_R_STATUS/4]=BB_DONE;regs[PIPE5_R_DONE_EPOCH/4]=regs[PIPE5_R_EPOCH/4]+(fault==42);regs[PIPE5_R_CYCLES/4]=1000;pending_pipe=0;}
    }
    return regs[reg/4];
}
void bb_write(unsigned reg,uint32_t value){
    assert(!pending);
    if(reg==PIPE5_R_CMD){assert(value==1);pending=pending_pipe=1;wait_polls=3;regs[BB_STATUS/4]=regs[PIPE5_R_STATUS/4]=BB_BUSY;regs[PIPE5_R_SNAP_STATUS/4]=5;regs[PIPE5_R_SNAP_EPOCH/4]=regs[PIPE5_R_EPOCH/4];++batch_jobs;return;}
    if(reg==BB_CMD){if(ownership_mode)assert(m_committed&&!(regs[PIPE5_M_STATUS/4]&PIPE5_BUSY));pending=1;wait_polls=3;regs[BB_STATUS/4]=BB_BUSY;if(regs[BB_OP/4]==2)++batch_jobs;else ++copy_jobs;return;}
    if(reg==BB_STATUS){regs[reg/4]&=~value;return;}regs[reg/4]=value;
}
uint64_t bb_ticks(void){return ++ticks;}
uint32_t bb_us(uint64_t t){return (uint32_t)t;}
bb_result bb_publish(void){assert(!pending);++publish_count;if(ownership_mode){cpu_pending=0;++ownership_publishes;}return BB_OK;}
void bb_acquire(void){assert(!pending||pending_pipe);if(ownership_mode){assert(!cpu_pending);gpu_dirty=0;++ownership_acquires;}}
bb_result bb_cpu_execute(const bb_job *j){
    assert(!pending);if(cancel_after&&!--cancel_after)return BB_E_CANCELLED;
    ++cpu_jobs;model(j);return BB_OK;
}

static uint32_t *before;
static unsigned tiles_submitted;
__declspec(dllexport) void init_overlap(void){
 game_config_defaults();pending=wait_polls=fault=0;ticks=0;memset(regs,0,sizeof regs);
 before=malloc(2u*BB_FRAME_BYTES);assert(before);scene_init();overlap_frames=strict_pixels=0;pending_pipe=0;m_committed=1;cpu_pending=gpu_dirty=legacy_hud_jobs=ownership_publishes=ownership_acquires=0;
}
static void snapshot(void){memcpy(before,at(BB_FB0),BB_FRAME_BYTES);memcpy(before+BB_FRAME_BYTES/4,at(BB_FB1),BB_FRAME_BYTES);}
static void strict_right_only(uint32_t fb){
 for(unsigned bank=0;bank<2;++bank){
  const uint32_t *p=at(bank?BB_FB1:BB_FB0),*b=before+bank*BB_FRAME_BYTES/4;
  for(unsigned y=0;y<720;++y)for(unsigned x=0;x<1280;++x){
   if((bank?BB_FB1:BB_FB0)==fb&&y>=118&&y<704&&x>=1072)continue;
   if(p[y*1280+x]!=b[y*1280+x]){fprintf(stderr,"unsafe HUD CPU write at bank%u %u,%u\n",bank,x,y);exit(4);}++strict_pixels;
  }
 }
}
__declspec(dllexport) unsigned trace(void){return trace_hash;}
__declspec(dllexport) unsigned trace_jobs(void){return trace_count;}
__declspec(dllexport) unsigned overlap_count(void){return overlap_frames;}
__declspec(dllexport) unsigned checked(void){return strict_pixels;}
__declspec(dllexport) void frame_overlap(unsigned f,unsigned hw,unsigned layered,unsigned cache,unsigned size,unsigned count){
 const uint32_t fb=(f&1)?BB_FB1:BB_FB0;
 assert(scene_bullets_prepare(size));battle_materials=f%2;
 scene_hud_cache_enable(cache);scene_set_batch(1);scene_begin(fb,hw);
 stage.count=count;
 for(unsigned i=0;i<count;++i){unsigned half=size/2;stage.shots[i]=(Shot){(int32_t)(half+(i*37+f*11)%(1025-size))*Q,(int32_t)(half+(i*17+f*7)%(689-size))*Q,0,0,17,(uint8_t)((battle_materials?54:24)+(i%16)),0};}
 trace_hash=2166136261u;trace_count=0;
 scene_batch_shots();assert(scene_sprite_count==count);if(hw)assert(regs[0x44/4]==count);scene_layers_begin(layered);
 unsigned ranks[8]={0,1,2,3,4,5,6,7};if(f%3==1){ranks[SCENE_LAYER_ACTOR]=5;ranks[SCENE_LAYER_EFFECT]=1;}assert(scene_layer_order(ranks));
 for(unsigned i=0;i<31;++i){
  scene_layer(i%8,(int)((i*17+f*13)%49)-24);
  int x=(i%6==0)?20:(i%6==1)?1046:120+(int)(i*27%800),y=(i%5==0)?8:(i%5==1)?698:50+(int)(i*19%540);
  if(i%7==0)scene_clip(x+3,y+2,13,17);else scene_clip_reset();
  scene_tile(x,y,i%24,(unsigned[]){0,128,224,255}[i%4]);
  scene_rect(x+4,y+4,11,9,0x506070+i*0x713u);
 }
 scene_clip_reset();scene_layer(SCENE_LAYER_WORLD_UI,0);scene_text(45,620,"FIELD KEEP ORDER",0xf0cc8d,1);
 /* The reference uses the old scheduling call, not a changed renderer. */
#ifdef BASELINE_SCHEDULE
 scene_layers_flush();
#endif
 unsigned was_pending=pending,was_op=regs[BB_OP/4];
 scene_pipe_defer_hud(1);snapshot();scene_hud_begin();
 char text[96];unsigned drawn=scene_sprite_count;
 snprintf(text,sizeof text,"ACTORS 19 DRAWN %u",drawn);scene_text(1078,286,text,0x80cfff,1);
 scene_text(1078,124,"SCORE",0x8786a3,1);
 snprintf(text,sizeof text,"%u",f%7?f*127:0);scene_text(1078,138,text,0xffffff,2);
 scene_rect(1078,178,186,10,0x383143);scene_rect(1078,178,1+(f*7)%186,10,0x80cfff);scene_rect(1171,178,1,10,0xffffff);
 snprintf(text,sizeof text,"HP %u/100",(100-f)%101);scene_text(1078,192,text,0xe9e5f2,1);
 for(unsigned k=0;k<(f%9==7?3:6);++k){int y=320+(int)k*34;
  scene_text(1078,y,k%3==0?"RUMIA":k%3==1?"CIRNO":"HONG MEILING",0xeb859a+k*0x500,1);
  scene_text(1198,y,f%4?"ACTIVE":"ENRAGED",0xf5cf77,1);
  scene_rect(1078,y+14,186,8,0x383143);scene_rect(1078,y+14,1+(f*13+k*31)%186,8,0x80d89b);
  snprintf(text,sizeof text,"%u/3000",(3000-f*17-k*31)%3001);scene_text(1078,y+26,text,0xe9e5f2,1);
 }
 if(f%8==2){scene_rect(1088,200,70,30,0x204080);scene_rect(1100,213,75,18,0x802040);}
 else if(f%8==3){scene_rect(1100,213,75,18,0x802040);scene_rect(1088,200,70,30,0x204080);}
 scene_text(1060,690,"RIGHT CLIP",0xabcdef,3);
 scene_text(1264,684,f%5?"E":"EDGE",0xa0b0c0,4);
 scene_text(1400,199,f%2?"OUTSIDE CHANGED":"OUTSIDE",0xffffff,1);
 if(f%7==6)scene_text(1078,620,"AB\nCD",0xc0c0ff,1);
 snprintf(text,sizeof text,"FPS %u.%02u R~%u",f%61,f%100,f*72);scene_text(1078,588,text,0x8be2cc,1);
 scene_text(1078,684,"LAY 1 Q99 C0 S2",0x80cfff,1);
 if(f>=80){
  /* Edge clips, narrow stores, insertion/deletion and painter order. */
  unsigned k=f%8;
  scene_rect(1071+(int)(k%3),601,1+(int)k,3,0x109030+k);
  scene_rect(1276-(int)k,617,9,5,0x501080+k);
  scene_text(1113,641,k==0?"":k==1?"LONG TEXT":k==2?"A":"PAIR",0xb0d080,1);
  scene_rect(1111,658,k==3?0:k==4?-1:1+(int)k,7,0x705030);
  if(k==5){scene_rect(1109,669,29,11,0x405070);scene_rect(1117,672,17,8,0xc0a080);}
  if(k==6){scene_rect(1117,672,17,8,0xc0a080);scene_rect(1109,669,29,11,0x405070);}
 }
 if(f>=112){scene_text(1105,650,"123456",0xabc0de,1);scene_rect(1112,650,13,7,0x608020);}
 scene_hud_end();
 if(ownership_mode&&hw&&layered){m_committed=0;regs[PIPE5_M_STATUS/4]=PIPE5_BUSY;regs[PIPE5_M_STATUS/4]=PIPE5_DONE;if(fault!=41){bb_acquire();m_committed=1;}}
 unsigned kept=rq_count();scene_pipe_draw_hud();assert(rq_count()==kept);

#ifndef BASELINE_SCHEDULE
 if(was_pending&&was_op==2&&hw&&layered){if(!ownership_mode){assert(pending&&regs[BB_OP/4]==2);assert(regs[BB_STATUS/4]==BB_BUSY);strict_right_only(fb);}else assert(!pending&&!cpu_pending&&!gpu_dirty);++overlap_frames;}
#endif
 scene_layers_flush();scene_end();assert(!pending&&!scene_cancelled());assert(drawn==scene_sprite_count);
}
__declspec(dllexport) void inject_fault(void){
 scene_set_batch(1);scene_begin(BB_FB0,1);stage.count=0;scene_batch_shots();scene_layers_begin(1);scene_tile(100,100,0,224);fault=1;scene_hud_begin();
}

__declspec(dllexport) void set_fault(unsigned f){fault=f;}
