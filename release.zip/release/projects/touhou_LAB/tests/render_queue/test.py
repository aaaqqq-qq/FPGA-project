from pathlib import Path
import argparse,ctypes,subprocess,json,os,shlex,hashlib
r=Path(__file__).resolve().parents[2];out=r/'results/render_queue';out.mkdir(exist_ok=True)
p=argparse.ArgumentParser();p.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=p.parse_args();cc=[x.strip('"')for x in shlex.split(a.host_cc,posix=False)]
def run(name,cmd):
 q=subprocess.run(cmd,cwd=r,capture_output=True,text=True);(out/(name+'.log')).write_text(q.stdout+q.stderr,encoding='utf-8');assert q.returncode==0,q.stdout+q.stderr;return q.stdout
exe=out/'queue.exe';run('pure_compile',cc+['-std=gnu11','-O2','-UNDEBUG','-Isrc','tests/render_queue/queue.c','src/render_queue.c','-o',str(exe)]);pure=run('pure',[str(exe)])
font=(r/'src/font.c').read_text().replace('void draw_text(','void font_draw_text(');(out/'font.c').write_text(font)
guard=out/'guards.exe';run('guards_compile',cc+['-O2','-DBB_HOST_TEST','-Isrc','tests/render_queue/guards.c','src/scene.c','src/render_queue.c','src/background.c',str(out/'font.c'),'src/pixels.c','src/game_config.c','-o',str(guard)])
guards={}
for case,expected in [('late_batch','LAYER BATCH ORDER'),('capacity','LAYER QUEUE -1'),('text_capacity','LAYER QUEUE -2'),('missing_end','LAYER FRAME END')]:
 q=subprocess.run([str(guard),case],cwd=r,capture_output=True,text=True);assert q.returncode==2 and expected in q.stderr,(case,q.returncode,q.stderr);guards[case]='PASS'
run('cancellation',[str(guard),'cancel']);guards['cancel_and_reuse']='PASS'
libs=[]
for name in ['queued','reference']:
 dll=out/(name+'.dll');run(name+'_compile',cc+['-O2','-shared','-DBB_HOST_TEST','-Isrc','tests/render_queue/host.c','src/scene.c','src/render_queue.c','src/background.c',str(out/'font.c'),'src/pixels.c','src/game_config.c','-o',str(dll)]);libs.append(ctypes.CDLL(str(dll)))
k=ctypes.WinDLL('kernel32',use_last_error=True);k.VirtualAlloc.restype=ctypes.c_void_p;k.VirtualAlloc.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32,ctypes.c_uint32]
base=0x1000000;size=0x1200000;assert k.VirtualAlloc(base,size,0x3000,4)==base
assert k.VirtualAlloc(0x07000000,0x00400000,0x3000,4)==0x07000000, ctypes.get_last_error()
seq=[(0,0,1),(0,1,0),(1,0,0),(2,1,1),(3,0,1),(4,1,1),(5,0,1),(7,1,0),(0,0,0),(4,0,0),(5,1,0),(7,0,1),(6,1,1),(0,1,1),(1,1,1),(2,1,0),(3,1,0),(7,1,1)]
pixels=[];metrics=[]
for ix,lib in enumerate(libs):
 ctypes.memset(base,0xa5,size);lib.layers_init()
 for n,(case,bank,hw) in enumerate(seq):
  lib.layer_frame(case,bank,hw,ix)
  image=ctypes.string_at(base+(0x400000 if bank else 0),1280*720*4)
  if ix==0:
   pixels.append(image);metrics.append({'frame':n,'case':case,'bank':bank,'hardware_model':hw,'commands':lib.get_layer_commands(),'clipped':lib.get_layer_clipped(),'reordered':lib.get_layer_reordered()})
  else:assert image==pixels[n],('fullpixel mismatch',n,case,bank,hw)
assert pixels[2]!=pixels[3], 'depth/tie crossing must change visible result'
assert pixels[0]!=pixels[12], 'legacy immediate order must differ from layered order'
result={'status':'PASS','frames_exact':len(seq),'pure_output':pure,'guards':guards,'metrics':metrics,'source_sha256':{n:hashlib.sha256((r/n).read_bytes()).hexdigest()for n in ('src/scene.c','src/render_queue.c','src/render_queue.h','src/scene.h')},'scope':'Production sparse queue and scene backend; full frames compared to direct independent painter pixels; no board timing claim'}
(out/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(pure.strip());print('RENDER_QUEUE PIXELS PASS',len(seq),'complete frames')
