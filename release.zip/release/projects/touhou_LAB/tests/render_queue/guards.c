#include "host.c"
#include <windows.h>
int main(int argc,char **argv){
 assert(argc==2);assert(VirtualAlloc((void *)0x01000000,0x1200000,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE)==(void *)0x01000000);
    if(VirtualAlloc((void *)(uintptr_t)0x07000000u,0x00400000u,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE)!=(void *)(uintptr_t)0x07000000u)return 2;
 layers_init();scene_set_batch(0);scene_begin(BB_FB0,1);scene_end();scene_begin(BB_FB1,1);scene_end();
 if(!strcmp(argv[1],"late_batch")){
  scene_set_batch(1);scene_begin(BB_FB0,1);stage.count=0;scene_batch_shots();scene_layers_begin(1);scene_rect(100,100,5,5,0x112233);scene_batch_shots();
 }else if(!strcmp(argv[1],"capacity")){
  scene_begin(BB_FB0,1);scene_layers_begin(1);for(unsigned i=0;i<=RQ_CAPACITY;++i)scene_rect(100,100,2,2,0x112233);
 }else if(!strcmp(argv[1],"text_capacity")){
  char s[2048];memset(s,'A',sizeof(s)-1);s[sizeof(s)-1]=0;
  scene_begin(BB_FB0,1);scene_layers_begin(1);scene_text(100,100,s,0xffffff,1);scene_text(100,100,s,0xffffff,1);scene_text(100,100,"X",0xffffff,1);
 }else if(!strcmp(argv[1],"missing_end")){
  scene_begin(BB_FB0,1);scene_layers_begin(1);scene_rect(100,100,2,2,0x112233);scene_begin(BB_FB1,1);
 }else if(!strcmp(argv[1],"cancel")){
  scene_begin(BB_FB0,0);scene_layers_begin(1);scene_rect(100,100,9,9,0xffffff);scene_tile(100,100,0,128);
  abort_after=1;scene_end();assert(scene_cancelled());assert(rq_count()==0);
  scene_begin(BB_FB1,0);scene_layers_begin(1);scene_rect(100,100,9,9,0x123456);scene_end();assert(!scene_cancelled());
  assert(*(uint32_t *)(uintptr_t)(BB_FB1+100*5120+100*4)==0x123456);puts("CANCEL_REUSE PASS");return 0;
 }else return 9;
 fputs("guard did not reject misuse\n",stderr);return 8;
}
