#include "../../sim/scene_host.c"
#include "game_config.h"
#include "art_data.h"
#include "font.h"
#include "render_queue.h"
#include <limits.h>
#include <assert.h>
static uint32_t target;
static void ref_tile(int x,int y,unsigned ti,unsigned alpha,int l,int t,int r,int b){
 Tile a=tiles[ti];
 for(unsigned yy=0;yy<a.h;++yy)for(unsigned xx=0;xx<a.w;++xx){
  int64_t px=(int64_t)x+xx,py=(int64_t)y+yy;if(px<l||px>=r||py<t||py>=b)continue;
  uint32_t s=*(uint32_t *)(uintptr_t)(ART_BASE+a.off+(yy*a.w+xx)*4);
  if((s&0xffffff)==BB_KEY)continue;
  uint32_t *d=(uint32_t *)(uintptr_t)(target+(uint32_t)py*5120+(uint32_t)px*4);*d=bb_blend(s,*d,alpha);
 }
}
static void ref_rect(int x,int y,int w,int h,unsigned color,int l,int t,int r,int b){
 int64_t x0=x,y0=y,x1=(int64_t)x+w,y1=(int64_t)y+h;if(w<=0||h<=0)return;
 if(x0<l)x0=l;if(y0<t)y0=t;if(x1>r)x1=r;if(y1>b)y1=b;
 for(int64_t yy=y0;yy<y1;++yy)for(int64_t xx=x0;xx<x1;++xx)*(uint32_t *)(uintptr_t)(target+(uint32_t)yy*5120+(uint32_t)xx*4)=color;
}
__declspec(dllexport) void layers_init(void){game_config_defaults();init_test();}
__declspec(dllexport) unsigned get_layer_commands(void){return scene_layer_commands;}
__declspec(dllexport) unsigned get_layer_peak(void){return scene_layer_peak;}
__declspec(dllexport) unsigned get_layer_clipped(void){return scene_layer_clipped;}
__declspec(dllexport) unsigned get_layer_reordered(void){return scene_layer_reordered;}
static void hud(unsigned n){scene_hud_begin();scene_text(1078,124,"HUD SAFE",0xffffff,1);scene_text(1078,138,n&1?"1":"123456",0x80cfff,2);scene_hud_end();}
/* Independent reference below draws known expected painter sequences directly
   to pixels, rather than calling the queue's sorting or clipping helpers. */
__declspec(dllexport) void layer_frame(unsigned which,unsigned bank,unsigned hw,unsigned reference){
 target=bank?BB_FB1:BB_FB0;scene_set_batch(0);scene_begin(target,hw);
 unsigned ranks[8]={0,1,2,3,4,5,6,7};
 if(which==3){ranks[SCENE_LAYER_ACTOR]=5;ranks[SCENE_LAYER_EFFECT]=1;}
 if(reference){scene_end();memcpy((void *)(uintptr_t)target,(const void *)(uintptr_t)0x01a00000,1280*720*4);scene_hud_cache_enable(0);}
 else{scene_layers_begin(which!=6);assert(scene_layer_order(ranks));}
 if(which==0||which==3||which==6){
  if(reference){
   if(which==0){ref_rect(85,83,55,45,0x334477,32,16,1056,704);ref_tile(90,90,0,125,32,16,1056,704);ref_tile(92,92,1,190,32,16,1056,704);}
   if(which==3){ref_tile(92,92,1,190,32,16,1056,704);ref_rect(85,83,55,45,0x334477,32,16,1056,704);ref_tile(90,90,0,125,32,16,1056,704);}
   if(which==6){ref_tile(92,92,1,190,32,16,1056,704);ref_tile(90,90,0,125,32,16,1056,704);ref_rect(85,83,55,45,0x334477,32,16,1056,704);}
  }else{
   scene_layer(SCENE_LAYER_EFFECT,0);scene_tile(92,92,1,190);
   scene_layer(SCENE_LAYER_ACTOR,10);scene_tile(90,90,0,125);
   scene_layer(SCENE_LAYER_ACTOR,-10);scene_rect(85,83,55,45,0x334477);
  }
 }else if(which==1||which==2){
  if(reference){ref_tile(91,92,which==1?0:1,140,32,16,1056,704);ref_tile(91,92,which==1?1:0,140,32,16,1056,704);}
  else{scene_layer(SCENE_LAYER_ACTOR,which==1?10:30);scene_tile(91,92,0,140);scene_layer(SCENE_LAYER_ACTOR,20);scene_tile(91,92,1,140);}
 }else if(which==4){
  char text[24]="STACK COPIED";
  if(reference){ref_rect(25,15,60,45,0x304050,40,20,80,50);ref_tile(30,18,4,180,40,20,80,50);draw_text_clipped(target,38,19,text,0xffeedd,2,40,20,80,50);}
  else{scene_clip(40,20,40,30);scene_layer(SCENE_LAYER_DECOR,0);scene_rect(25,15,60,45,0x304050);scene_tile(30,18,4,180);scene_text(38,19,text,0xffeedd,2);strcpy(text,"MUTATED");scene_clip_reset();}
 }else if(which==5){
  if(reference){ref_tile(33,18,3,224,32,16,1056,704);ref_rect(1040,690,100,50,0x708090,32,16,1056,704);}
  else{scene_layer(SCENE_LAYER_ACTOR,0);scene_tile(INT_MIN,INT_MIN,0,224);scene_rect(INT_MIN,INT_MIN,INT_MAX,INT_MAX,0xffffff);scene_text(INT_MAX,INT_MAX,"NO",0xffffff,1);scene_clip(INT_MAX,INT_MAX,INT_MAX,INT_MAX);scene_tile(33,18,0,224);scene_clip_reset();scene_tile(33,18,3,224);scene_rect(1040,690,100,50,0x708090);}
 }else if(which==7){
  if(reference){ref_tile(91,92,0,0,32,16,1056,704);ref_tile(91,92,1,255,32,16,1056,704);draw_text_clipped(target,50,50,"AB\nCD",0xaaaaff,2,32,16,1056,704);}
  else{scene_layer(SCENE_LAYER_ACTOR,0);scene_tile(91,92,0,0);scene_tile(91,92,1,255);scene_layer(SCENE_LAYER_WORLD_UI,0);scene_text(50,50,"AB\nCD",0xaaaaff,2);}
 }
 hud(which);scene_end();
}
