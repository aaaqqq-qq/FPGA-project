#include "render_queue.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
static unsigned seen[RQ_CAPACITY],used,checks;
static char text_seen[64];
static void sink(const RqCommand *c,const char *s,void *p){(void)p;assert(used<RQ_CAPACITY);seen[used++]=c->color;if(s)snprintf(text_seen,sizeof(text_seen),"%s",s);}
typedef struct {unsigned id,rank,layer;int depth;} Expected;
static int compare(const void *aa,const void *bb){const Expected *a=aa,*b=bb;
 if(a->rank!=b->rank)return a->rank<b->rank?-1:1;
 if(a->layer!=b->layer)return a->layer<b->layer?-1:1;
 if(a->depth!=b->depth)return a->depth<b->depth?-1:1;
 return a->id<b->id?-1:a->id>b->id;
}
int main(void){
 unsigned ranks[8]={0,1,2,3,4,5,6,7},bad[8]={0,1,2,3,4,5,6,256};
 for(unsigned round=0;round<40;++round){
  rq_reset();used=0;
  for(unsigned l=0;l<8;++l)ranks[l]=(round*13+l*7)%11;
  assert(rq_set_order(ranks));assert(!rq_set_order(bad));assert(!rq_set_order(0));
  unsigned n=1+(round*29)%RQ_CAPACITY;Expected e[RQ_CAPACITY];
  for(unsigned i=0;i<n;++i){RqCommand c={0};c.kind=RQ_RECT;c.layer=(i*73+round)%8;c.depth=(int)((i*17+round)%13)-6;c.color=i;
   if(i==2)c.depth=INT_MIN;if(i==3)c.depth=INT_MAX;
   e[i]=(Expected){i,ranks[c.layer],c.layer,c.depth};assert(rq_push(&c,0)==RQ_OK);
  }
  qsort(e,n,sizeof(e[0]),compare);rq_flush(sink,0);assert(used==n&&rq_count()==0&&rq_total==n&&rq_peak==n);
  for(unsigned i=0;i<n;++i){assert(seen[i]==e[i].id);++checks;}
 }
 rq_reset();used=0;RqCommand c={0};c.kind=RQ_TEXT;c.layer=2;char stack[64]="COPIED STACK TEXT";
 assert(rq_push(&c,stack)==RQ_OK);strcpy(stack,"DESTROYED");rq_flush(sink,0);assert(!strcmp(text_seen,"COPIED STACK TEXT"));
 rq_reset();used=0;c.kind=RQ_RECT;for(unsigned i=0;i<RQ_CAPACITY;++i){c.color=i;assert(rq_push(&c,0)==RQ_OK);}
 assert(rq_push(&c,0)==RQ_E_CAPACITY&&rq_count()==RQ_CAPACITY);rq_flush(sink,0);assert(used==RQ_CAPACITY);
 rq_reset();c.kind=RQ_TEXT;char full[2048];memset(full,'A',sizeof(full)-1);full[sizeof(full)-1]=0;
 assert(rq_push(&c,full)==RQ_OK);assert(rq_push(&c,full)==RQ_OK);assert(rq_push(&c,"X")==RQ_E_TEXT&&rq_count()==2);
 c.kind=RQ_RECT;assert(rq_push(&c,0)==RQ_OK&&rq_count()==3);
 rq_reset();c.layer=8;assert(rq_push(&c,0)==RQ_E_ARGUMENT);c.layer=0;c.kind=3;assert(rq_push(&c,0)==RQ_E_ARGUMENT);
 c.kind=RQ_TEXT;assert(rq_push(&c,0)==RQ_E_ARGUMENT);rq_flush(sink,0);
 printf("RENDER_QUEUE PURE PASS comparisons=%u capacity=%u command_bytes=%u\n",checks,RQ_CAPACITY,(unsigned)sizeof(RqCommand));return 0;
}
