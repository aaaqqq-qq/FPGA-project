static void run_600_seconds(uint64_t epoch){
    const uint64_t cycles=600ull*100000000ull;unsigned count=36000;
    uint64_t before=epoch,new_total=0,old_total=0;
    uint64_t new_acc=0,old_acc=0,new_logic=0,old_logic=0;
    for(unsigned i=1;i<=count;++i){
        uint64_t now=epoch+cycles*i/count;
        uint32_t fresh=frame_elapsed_us(now,before),old=bb_us(now-before);
        new_total+=fresh;old_total+=old;new_acc+=(uint64_t)fresh*60;old_acc+=(uint64_t)old*60;
        new_logic+=new_acc/1000000;new_acc%=1000000;old_logic+=old_acc/1000000;old_acc%=1000000;
        before=now;
    }
    assert(before-epoch==60000000000ull);
    assert(new_total==600000000ull&&new_logic==36000&&!new_acc);
    assert(old_total==599976000ull&&old_logic==35998&&old_acc==560000);
    printf("CLOCK PASS 600s epoch=%s new_us=%u logic=%u old_floor_us=%u old_logic=%u\n",
        epoch?"wrap":"zero",(unsigned)new_total,(unsigned)new_logic,
        (unsigned)old_total,(unsigned)old_logic);
}
static void runtime_schedule(uint64_t epoch){
    static const unsigned plan[]={0,1,0,2,3,0,1,3,2,0};
    game_config_defaults();replay_reset();choice=3;custom_limit=64;start();
    uint64_t before=epoch,acc=0;unsigned expected=0;
    for(unsigned i=0;i<sizeof(plan)/sizeof(plan[0]);++i){
        expected+=plan[i];uint64_t us=((uint64_t)expected*1000000+59)/60;
        uint64_t now=epoch+us*100;uint32_t delta=frame_elapsed_us(now,before);before=now;
        acc+=(uint64_t)delta*60;unsigned steps=0;
        while(acc>=1000000&&steps<3){runtime_step();acc-=1000000;++steps;}
        assert(steps==plan[i]&&ticks==expected&&runtime_tick==expected&&stage.frame==expected);
        assert(acc<1000000&&!logic_drops&&!logic_overruns);
    }
    printf("CLOCK PASS zero/one/two/three runtime steps across absolute_us epoch=%s\n",epoch?"wrap":"zero");
}
static void round_preparation(void){
    game_config_defaults();replay_reset();choice=0;hardware=1;command_reply_count=command_reply_head=command_reply_overruns=0;
    host_ticks=1000000;profile_battle_peak=profile_player_peak=profile_flush_peak=profile_hud_peak=UINT32_MAX;
    start();assert(mode==PLAY&&hardware&&render_warmup_pending()&&play_warmup_frames==2);
    assert(!profile_battle_peak&&!profile_player_peak&&!profile_flush_peak&&!profile_hud_peak);
    uint32_t initial=runtime_state_hash();
    render(BB_FB0);render_warmup_advance();assert(play_warmup_frames==1&&render_warmup_pending()&&!ticks&&!runtime_tick&&!command_reply_count);
    assert(runtime_state_hash()==initial);
    host_ticks+=2000000;render(BB_FB1);profile_battle_peak=profile_player_peak=profile_flush_peak=profile_hud_peak=UINT32_MAX;
    render_warmup_advance();assert(!play_warmup_frames&&!render_warmup_pending()&&!ticks&&!runtime_tick);
    assert(!profile_battle_peak&&!profile_player_peak&&!profile_flush_peak&&!profile_hud_peak);
    assert(runtime_state_hash()==initial&&command_reply_count==1);
    assert(strstr(command_replies[command_reply_head],"PLAY_READY prepare_us=")&&strstr(command_replies[command_reply_head],"scan=0 swaps=0 ticks=0\r\n"));
    render_warmup_advance();assert(command_reply_count==1&&!render_warmup_pending());
    runtime_step();assert(ticks==1&&runtime_tick==1);
    start();show_menu();render_warmup_advance();assert(!render_warmup_pending()&&play_warmup_frames==2);
    choice=3;start();assert(render_warmup_pending()&&stress_warmup_frames==2&&!play_warmup_frames);
    render_warmup_advance();assert(stress_warmup_frames==1&&render_warmup_pending());
    render_warmup_advance();assert(!stress_warmup_frames&&!render_warmup_pending());
    choice=4;start();assert(!hardware&&!render_warmup_pending());
    choice=5;start();assert(mode==DODGE&&hardware&&!render_warmup_pending());
    puts("CLOCK_R8 PASS twoactualPLAYrenderpreparations,zeroactionticks,singlePLAY_READY,firsttick1,menu/CPU/DODGE/STRESSboundaries");
}
int main(void){
    assert(frame_elapsed_us(0,0)==0&&frame_elapsed_us(99,0)==0);
    assert(frame_elapsed_us(100,99)==1&&bb_us(100-99)==0);
    assert(frame_elapsed_us(199,100)==0&&frame_elapsed_us(200,199)==1);
    uint64_t near_wrap=0xfffffffeull*100+80;
    assert(bb_us(near_wrap)==0xfffffffeu&&bb_us(near_wrap+350)==2);
    assert(frame_elapsed_us(near_wrap+350,near_wrap)==4);
    puts("CLOCK PASS zero/sub-microsecond carry and 32-bit absolute_us wrap");
    run_600_seconds(0);run_600_seconds(near_wrap);
    runtime_schedule(0);runtime_schedule(near_wrap);
    round_preparation();
    puts("ALL_FRAME_CLOCK_PASS");return 0;
}
