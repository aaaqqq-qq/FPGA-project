/* B2 independent whole-viewport oracle: frozen oldQ8 source order vs actual
   multi-page renderer on every warmup/measured presentation. */
#include <stdint.h>
uint32_t bb_read(unsigned);
#define bb_read support_read
#define main retained_adv_main
#include "adv_host.c"
#undef main
#undef bb_read
typedef struct {int32_t x,y;int16_t vx,vy;uint16_t mass;uint8_t size,color,alive,pad;} RefParticle;
void old_init(RefParticle *,unsigned,unsigned,unsigned,uint32_t);void old_step(RefParticle *,unsigned,unsigned,AdvStats *);
unsigned old_shape(unsigned,unsigned,unsigned,unsigned);uint32_t old_color(uint32_t,uint32_t,uint32_t,unsigned,unsigned);uint32_t old_golden(uint32_t,uint32_t,unsigned,uint32_t,unsigned);
static RefParticle refp[512];static uint32_t reference[1024*512],refcolors[16],refkey;
static unsigned capture,ordinal,fullframes,refn,refphysics,refframes,refalpha,refkeyon,refshape,refcases;static AdvStats refstats;
static unsigned long long fullpixels;
static void compare_present(uint32_t fb){if(ordinal++<2)return;if(fullframes>refframes)return;
 if(fullframes)old_step(refp,refn,refphysics,&refstats);
 for(unsigned y=0;y<512;++y)for(unsigned x=0;x<1024;++x)reference[y*1024+x]=((x/24)^(y/24))&1?0xc5cfdf:0xf5f7fb;
 for(unsigned i=0;i<refn;++i)if(refp[i].alive){RefParticle *q=refp+i;int left=(q->x>>8)-q->size/2,top=(q->y>>8)-q->size/2;
  for(unsigned y=0;y<q->size;++y)for(unsigned x=0;x<q->size;++x){uint32_t source=old_shape(refshape,q->size,x,y)?refcolors[q->color]:refkey;unsigned at=(top+y)*1024+left+x;reference[at]=old_golden(source,reference[at],refalpha,refkey,1u|(refkeyon?2u:0u));}}
 for(unsigned y=0;y<512;++y)for(unsigned x=0;x<1024;++x){uint32_t got=p(fb)[(160+y)*1280+32+x];if(got!=reference[y*1024+x]){fprintf(stderr,"FULLPIXFAIL case%u frame%u x%u y%u got%x expected%x\n",refcases,fullframes,x,y,got,reference[y*1024+x]);exit(2);}}
 ++fullframes;fullpixels+=1024u*512u;
}
uint32_t bb_read(unsigned r){uint32_t before=front,v=support_read(r);if(capture&&front!=before)compare_present(front);return v;}
static void testcase(unsigned n,unsigned size,unsigned shape,unsigned mode,unsigned key,unsigned alpha,unsigned physics,const char *expected_path){
 ++refcases;refn=n;refphysics=physics;refframes=3;refalpha=alpha;refkeyon=key;refshape=shape;refstats=(AdvStats){0,0,0,n,n,n};unsigned colors=mode==0?1:mode==1?3:16;
 for(unsigned c=0;c<colors;++c)refcolors[c]=old_color(0x4c8dff,0xf18bbb,0xf5be52,mode,c);refkey=BB_KEY;
 for(;;){unsigned match=0;for(unsigned c=0;c<colors;++c)match|=refcolors[c]==refkey;if(!match)break;refkey=(refkey+0x010101u)&0xffffffu;}
 old_init(refp,n,size,colors,42);ordinal=fullframes=0;capture=1;char cmd[220];snprintf(cmd,sizeof cmd,":adv %u stress fpga %u %u %u 5017087 15829947 16105042 %u %u %u %u 3 42",200+refcases,n,size,shape,mode,alpha,key,physics);
 pass(cmd);capture=0;CHECK(fullframes==4);CHECK(strstr(row("ADV_PATH "),expected_path));CHECK(value(row("ADV_PATH "),"prime_steps")+value(row("ADV_PATH "),"measured_steps")==3&&value(row("ADV_PATH "),"total_steps")==3);
 CHECK(value(row("ADV_RESULT "),"final")==refstats.count);CHECK(value(row("ADV_RESULT "),"merges")==refstats.merges);
}
int main(void){CHECK(retained_adv_main()==0);pass(":adv 190 enter");
 unsigned sizes[]={8,16,24,32,40,48,56};for(unsigned i=0;i<7;++i)for(unsigned a=0;a<3;++a)testcase(64,sizes[i],0,0,1,a==0?0:a==1?128:255,0,i==0?"path=direct8":i<5?"path=tile8_ordered":"path=tile8_commute");
 for(unsigned i=1;i<7;++i)testcase(64,sizes[i],0,0,0,128,0,i<5?"path=tile8_ordered":"path=rect reason=materials_over16");
 testcase(64,32,0,1,1,128,0,"path=rect reason=materials_over16");testcase(64,32,0,2,1,128,0,"path=rect reason=materials_over16");testcase(64,56,1,2,0,128,0,"path=tile8_ordered");
 testcase(64,56,3,0,1,128,0,"path=tile8_commute");testcase(64,56,4,0,1,128,0,"path=tile8_commute");testcase(64,17,0,0,0,128,0,"path=rect reason=size_not_multiple8");
 for(unsigned mode=1;mode<=5;++mode)for(unsigned key=0;key<=1;++key)testcase(128,32,0,0,key,128,mode,mode==2?(key?"path=rowrun":"path=rect reason=fusion_dynamic"):"path=tile8_ordered");
 for(unsigned sh=0;sh<6;++sh){testcase(64,17,sh,0,1,128,0,"path=rowrun");testcase(64,31,sh,0,1,1,0,"path=rowrun");testcase(64,47,sh,0,1,254,0,"path=rowrun");testcase(64,63,sh,0,1,128,0,"path=rowrun");} testcase(512,63,3,0,1,128,0,"path=rowrun_mixed reason=rowrun_capacity_fallback"); testcase(128,32,0,1,1,128,2,"path=rect reason=fusion_dynamic"); pass(":adv 399 exit");printf("ADV60C_FULLPIX_PASS cases=%u presentations=%u pixels=%u million_plus=%u no_hardware_timing_claim=1\n",refcases,refcases*4,(unsigned)(fullpixels%1000000000ull),(unsigned)(fullpixels/1000000000ull));return 0;}
