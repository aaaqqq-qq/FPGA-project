/* Real lab.c upload state machine and independent bounded DDR/opaque DMA.
   Host only: serial transport/cache/physical display remain NOT_RUN. */
#include "lab.h"
#include "bitblt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <windows.h>
static unsigned checks,jobs,copies,swaps,restores,max_width,max_line,errors_inject,source_inject,guard_inject,outside_inject,restore_error,swap_error;
static uint32_t front=BB_FB0;static uint64_t ticks;static char lines[32][512];static unsigned count,next_id=1;
#define CK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL line%d %s\n",__LINE__,#x);for(unsigned z=0;z<count;++z)fprintf(stderr,"%s\n",lines[z]);exit(1);}}while(0)
static uint32_t *p(uint32_t a){return (uint32_t *)(uintptr_t)a;}
uint64_t bb_ticks(void){return ticks+=100;}
uint32_t bb_us(uint64_t t){return (uint32_t)(t/100);}
uint32_t bb_read(unsigned r){return r==BB_FRONT?front:0;}
void bb_write(unsigned r,uint32_t v){(void)r;(void)v;CK(0);}
bb_result bb_publish(void){return BB_OK;}
void bb_acquire(void){}
bb_result bb_execute(const bb_job *j,bb_metrics *m){CK(bb_validate(j)==BB_OK);CK(j->flags==0&&j->alpha==255&&j->width<=1024);CK(j->dst<front||j->dst>=front+BB_FRAME_BYTES);++jobs;if(j->width>max_width)max_width=j->width;
 if(j->op==BB_COPY_OP){++copies;CK((j->src>=LAB_SOURCE_BASE&&j->src<LAB_SOURCE_BASE+32768)||(j->src>=LAB_IMAGE_BASE&&j->src<LAB_IMAGE_BASE+BB_FRAME_BYTES));}
 if(errors_inject){errors_inject=0;return BB_E_HARDWARE;}
 for(unsigned y=0;y<j->height;++y)for(unsigned x=0;x<j->width;++x)p(j->dst+y*j->dst_stride)[x]=j->op==BB_FILL_OP?j->fill:p(j->src+y*j->src_stride)[x];
 if(j->op==BB_COPY_OP&&j->src>=LAB_IMAGE_BASE){
  if(source_inject){p(j->src)[0]^=1;source_inject=0;}
  if(guard_inject){p(LAB_IMAGE_BASE-64)[0]^=1;guard_inject=0;}
  if(outside_inject){uint32_t fb=j->dst>=BB_FB1?BB_FB1:BB_FB0;p(fb)[100*1280+100]^=1;outside_inject=0;}
 }
 m->cycles=j->width*j->height;m->read_bytes=j->op==BB_COPY_OP?j->width*j->height*4:0;m->write_bytes=j->width*j->height*4;return BB_OK;
}
bb_result bb_swap_wait(uint32_t fb,uint32_t timeout){CK(timeout==200000&&fb!=front);if(swap_error){swap_error=0;return BB_E_TIMEOUT;}front=fb;++swaps;return BB_OK;}
static int restore(void){++restores;return restore_error?-1:0;}
static void emit(const char *s){unsigned n=(unsigned)strlen(s);CK(n<512&&count<32);if(n>max_line)max_line=n;strcpy(lines[count++],s);}
static const char *last(void){CK(count);return lines[count-1];}
static uint32_t field(const char *name){char k[40];snprintf(k,sizeof k," %s=",name);const char *v=strstr(last(),k);CK(v);return (uint32_t)strtoul(v+strlen(k),0,10);}
static void run(const char *op){char cmd[640];snprintf(cmd,sizeof cmd,":lab %u %s",next_id++,op);count=0;CK(lab_command(cmd));if(lab_pending()){CK(strstr(last(),"LAB_ACK ")==last());lab_service();}CK(!lab_pending());}
static void pass(const char *op){run(op);CK(strstr(last(),"status=PASS"));}
static void fail(const char *op,const char *code){run(op);CK(strstr(last(),"status=ERROR")&&strstr(last(),code));if(strncmp(op,"img",3)==0)CK(field("verified")==0);}
static uint32_t bytecrc(uint32_t c,unsigned b){c^=b;for(unsigned i=0;i<8;++i)c=(c>>1)^((c&1)?0xedb88320u:0);return c;}
static uint32_t pixel(unsigned x,unsigned y){return (((x*17+y*3)&255)<<16)|(((x^(y*7))&255)<<8)|((x+y*13+0x5a)&255);}
static uint32_t image_crc(unsigned w,unsigned h){uint32_t c=0xffffffffu;for(unsigned y=0;y<h;++y)for(unsigned x=0;x<w;++x){uint32_t v=pixel(x,y);c=bytecrc(c,v>>16&255);c=bytecrc(c,v>>8&255);c=bytecrc(c,v&255);}return c^0xffffffffu;}
static void begin(unsigned token,unsigned w,unsigned h,unsigned badcrc){char cmd[128];snprintf(cmd,sizeof cmd,"imgbegin %u %u %u %u",token,w,h,image_crc(w,h)^badcrc);pass(cmd);CK(field("session")==token&&field("received")==0&&!field("ready")&&field("total")==w*h*3);}
static void upload(unsigned token,unsigned w,unsigned h){const char base[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";unsigned total=w*h;
 for(unsigned first=0;first<total;first+=96){unsigned n=total-first;if(n>96)n=96;char encoded[385],cmd[520];for(unsigned i=0;i<n;++i){unsigned ix=first+i;uint32_t v=pixel(ix%w,ix/w);encoded[i*4]=base[(v>>18)&63];encoded[i*4+1]=base[(v>>12)&63];encoded[i*4+2]=base[(v>>6)&63];encoded[i*4+3]=base[v&63];}encoded[n*4]=0;
  snprintf(cmd,sizeof cmd,"imgdata %u %u %s",token,first*3,encoded);pass(cmd);CK(field("received")==((first+n)*3)&&!field("ready")&&!field("verified"));}
 CK(field("crc")==image_crc(w,h));
}
static void commit(unsigned token){char cmd[80];snprintf(cmd,sizeof cmd,"imgcommit %u",token);pass(cmd);CK(field("ready")==1&&field("verified")==0);}
static void copy(unsigned token,unsigned w,unsigned h,unsigned dx,unsigned dy){char cmd[100];snprintf(cmd,sizeof cmd,"imgcopy %u %u %u",token,dx,dy);pass(cmd);CK(field("ready")==1&&field("verified")==921600);
 for(unsigned y=0;y<720;++y)for(unsigned x=0;x<1280;++x){uint32_t expected=x>=dx&&x-dx<w&&y>=dy&&y-dy<h?pixel(x-dx,y-dy):LAB_BACKGROUND;CK(p(front)[y*1280+x]==expected);}}
int main(void){void *base=(void *)(uintptr_t)0x01000000;CK(VirtualAlloc(base,0x04400000,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE)==base);memset(base,0xa5,0x04400000);lab_init(emit,restore);
 pass("imgstatus");CK(field("session")==0&&!field("active")&&!field("ready"));fail("imgbegin 1 1 1 0","MODE");pass("enter");
 begin(123,1,1,0);fail("imgcopy 123 0 0","INCOMPLETE");fail("imgcommit 123","INCOMPLETE");fail("imgdata 124 0 AAAA","SESSION");fail("imgdata 123 3 AAAA","OFFSET");
 const char *bad[]={"imgdata 123 0 A===","imgdata 123 0 AA==","imgdata 123 0 AAA=","imgdata 123 0 AAA","imgdata 123 0 A-AA","imgdata 123 0 A_AA","imgdata 123 0 AAA?"};
 for(unsigned i=0;i<sizeof bad/sizeof bad[0];++i){uint32_t before=p(LAB_IMAGE_BASE)[0];fail(bad[i],"ENCODING");CK(field("received")==0&&p(LAB_IMAGE_BASE)[0]==before);}
 upload(123,1,1);fail("imgdata 123 0 AAAA","OFFSET");commit(123);copy(123,1,1,1279,719);copy(123,1,1,0,0);fail("imgcopy 123 1280 0","RANGE");CK(field("ready"));
 begin(124,1,1,1);CK(!field("ready"));upload(124,1,1);fail("imgcommit 124","CRC");fail("imgcopy 124 0 0","INCOMPLETE");
 begin(125,1,1,0);upload(125,1,1);p(LAB_IMAGE_BASE)[0]^=1;fail("imgcommit 125","CRC");CK(!field("ready"));
 for(unsigned g=0;g<3;++g){begin(126+g,1,1,0);upload(126+g,1,1);p(g==0?LAB_IMAGE_BASE-64:g==1?LAB_IMAGE_BASE+4:LAB_IMAGE_BASE+BB_FRAME_BYTES)[0]^=1;char cmd[64];snprintf(cmd,sizeof cmd,"imgcommit %u",126+g);fail(cmd,"GUARD");}
 begin(130,2,2,0);upload(130,2,2);commit(130);outside_inject=1;fail("imgcopy 130 7 8","VERIFY");CK(field("ready"));source_inject=1;fail("imgcopy 130 7 8","CRC");CK(!field("ready"));
 begin(131,2,2,0);upload(131,2,2);commit(131);guard_inject=1;fail("imgcopy 131 7 8","GUARD");
 begin(132,1025,1,0);upload(132,1025,1);commit(132);unsigned before=copies;copy(132,1025,1,0,719);CK(copies-before==2);fail("imgcopy 132 256 719","RANGE");
 begin(133,1280,720,0);upload(133,1280,720);commit(133);before=copies;copy(133,1280,720,0,0);CK(copies-before==2&&max_width==1024);fail("imgcopy 133 1 0","RANGE");
 pass("imgstatus");CK(field("ready")==1&&field("received")==2764800&&field("verified")==0);pass("imgabort 133");CK(!field("ready")&&field("session")==133&&field("active"));
 fail("imgcopy 133 0 0","SESSION");fail("imgbegin 2147483648 1 1 0","RANGE");fail("imgbegin 2 1281 1 0","RANGE");fail("imgbegin 2 1 721 0","RANGE");
 begin(144,1,1,0);upload(144,1,1);commit(144);restore_error=1;fail("exit","RESTORE");pass("imgstatus");CK(field("active")&&field("ready"));restore_error=0;pass("exit");pass("imgstatus");CK(!field("active")&&!field("ready")&&!field("session"));
 printf("LABIMG_PASS checks=%u jobs=%u copies=%u swaps=%u max_line=%u max_image=1280x720 native_only=1\n",checks,jobs,copies,swaps,max_line);return 0;}
