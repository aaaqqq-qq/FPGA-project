#include "stage.h"
#include "stage_data.h"
#include <string.h>
Stage stage __attribute__((aligned(16)));
int turn_sin(int a){return sin_lut[((unsigned)a>>6)&1023];}
int turn_cos(int a){return turn_sin(a+16384);}
int turn_atan(int x,int y){
    unsigned ax=x<0?-x:x,ay=y<0?-y:y;
    int a=ax>=ay ? (ax?atan_lut[(ay*256u)/ax]:0) : 16384-atan_lut[(ax*256u)/ay];
    if(x<0)a=32768-a;
    return y<0?-a:a;
}
unsigned stage_random(void){unsigned x=stage.seed;x^=x<<13;x^=x>>17;x^=x<<5;return stage.seed=x;}
static int val(int v){if(v<=-10001*65536&&v>=-10012*65536)return stage.vars[-v/65536-10001];return v;}
static void set(int index,int value){if(index<=-10001&&index>=-10012)stage.vars[-index-10001]=value;else stage.fault=1;}
static int radians(int f){return (int)((int64_t)f*65536/411775);}
void stage_reset(unsigned difficulty,unsigned limit){
    battle_materials=0;memset(&stage,0,sizeof(stage));stage.seed=0x6e697468;stage.difficulty=difficulty%3;
    stage.limit=limit>SHOT_CAPACITY?SHOT_CAPACITY:limit;stage.bx=ARENA_W/2*Q;stage.by=arena_script_y(80*Q);
}
static int spawn(int x,int y,int angle,int speed,unsigned tile){
    ++stage.requested;
    if(stage.count>=stage.limit){++stage.rejected;return 0;}
    unsigned index=stage.count++;
    Shot *b=&stage.shots[index];b->x=x;b->y=y;
    b->vx=(int16_t)((int64_t)turn_cos(angle)*speed/32768);
    b->vy=(int16_t)((int64_t)turn_sin(angle)*speed/32768);
    b->tile=tile;b->age=0;b->grazed=0;stage.owner[index]=0;++stage.emitted;
    if(stage.count>stage.peak)stage.peak=stage.count;
    return 1;
}
static void move(unsigned frames,int dx,int dy){
    stage.move_time=0;stage.move_total=frames;stage.move_x=stage.bx;stage.move_y=stage.by;stage.move_dx=dx;stage.move_dy=dy;
}
void stage_step(int px,int py){
    const EclOp *code=stage.difficulty==0?ecl_normal:stage.difficulty==1?ecl_hard:ecl_lunatic;
    unsigned watchdog=0;
    while(stage.pc<ECL_OP_COUNT && code[stage.pc].time==(int)stage.time){
        if(++watchdog>256){stage.fault=2;return;}
        const EclOp *o=&code[stage.pc];const int32_t *a=o->arg;++stage.pc;
        switch(o->op){
        case 2:stage.time=a[0];stage.pc=a[1];break;
        case 3:{int i=-a[2]-10001;if(i<0||i>=12){stage.fault=3;return;}if(--stage.vars[i]>0){stage.time=a[0];stage.pc=a[1];}break;}
        case 4:case 5:set(a[0],a[1]);break;
        case 20:set(a[0],val(a[1])+val(a[2]));break;
        case 47:stage.speed=val(a[0])>>4;break;
        case 50:{
            int lo=radians(a[0]),hi=radians(a[1]);int an=lo+(int)(stage_random()%(unsigned)(hi-lo));
            /* Reflect toward the interior of the complete 720p arena. */
            int x=stage.bx/Q,y=stage.by/Q;
            if(x<ARENA_W/3){if(an>16384)an=32768-an;else if(an<-16384)an=-32768-an;}
            if(x>ARENA_W*2/3){if(an<16384&&an>=0)an=32768-an;else if(an>-16384&&an<=0)an=-32768-an;}
            if(y<ARENA_H/2&&an<0)an=-an;if(y>ARENA_H/2&&an>0)an=-an;stage.angle=an;break;
        }
        case 57:move(a[0],arena_script_x(a[1]>>4)-stage.bx,arena_script_y(a[2]>>4)-stage.by);break;
        case 61:{
            /* Retain the script's movement duration/direction, but map its
               destination over the new arena instead of the old small box. */
            int tx=ARENA_W/2*Q+(int)((int64_t)turn_cos(stage.angle)*(ARENA_W/2-32)*Q/32768);
            int ty=ARENA_H/2*Q+(int)((int64_t)turn_sin(stage.angle)*(ARENA_H/2-48)*Q/32768);
            move(a[0],tx-stage.bx,ty-stage.by);break;
        }
        case 67:{
            int aim=turn_atan(px*Q-stage.bx,py*Q-stage.by)+radians(val(a[6]));
            int speed1=val(a[4])>>4,speed2=val(a[5])>>4;
            for(int j=0;j<a[3];++j){int speed=arena_script_y(speed1-(speed1-speed2)*j/a[3]);spawn(stage.bx,stage.by,aim,speed,8u+(unsigned)a[1]);}
            break;
        }
        case 105:stage.vulnerable=a[0];break;
        default:stage.fault=o->op;return;
        }
    }
    if(stage.pc>=ECL_OP_COUNT){stage.fault=4;return;}
    if(stage.move_time<stage.move_total){
        unsigned t=++stage.move_time,n=stage.move_total;
        unsigned u=(2*n*t-t*t)*65536u/(n*n);
        stage.bx=stage.move_x+(int)((int64_t)stage.move_dx*u/65536);
        stage.by=stage.move_y+(int)((int64_t)stage.move_dy*u/65536);
        if(stage.bx<BOSS_MIN_X*Q)stage.bx=BOSS_MIN_X*Q;if(stage.bx>BOSS_MAX_X*Q)stage.bx=BOSS_MAX_X*Q;
        if(stage.by<BOSS_MIN_Y*Q)stage.by=BOSS_MIN_Y*Q;if(stage.by>BOSS_MAX_Y*Q)stage.by=BOSS_MAX_Y*Q;
    }
    for(unsigned i=0;i<stage.count;){
        Shot *b=&stage.shots[i];
        /* Original flag 4 spawn has a short slower launch. Presentation is simplified. */
        if(b->age<SPAWN_FRAMES){b->x+=b->vx*2/5;b->y+=b->vy*2/5;}else{b->x+=b->vx;b->y+=b->vy;}
        ++b->age;
        if(b->x<-16*Q||b->x>(ARENA_W+16)*Q||b->y<-16*Q||b->y>(ARENA_H+16)*Q){unsigned last=--stage.count;*b=stage.shots[last];stage.owner[i]=stage.owner[last];continue;}++i;
    }
    ++stage.frame;++stage.time;
}
void stage_stress(unsigned count){
    stage_reset(0,count);
    for(unsigned i=0;i<stage.limit;++i){int x=8+stage_random()%1008,y=8+stage_random()%672;spawn(x*Q,y*Q,stage_random()&65535,4096+(stage_random()&2047),24+(i&15));stage.shots[i].age=12;}
}
unsigned stage_near_count,stage_near_indices[512];
static unsigned near_valid,near_frame,near_overflow;
static int near_x,near_y;
static inline __attribute__((always_inline)) void stress_update(unsigned collect,int px,int py){
    stage_near_count=0;near_overflow=0;near_valid=collect;near_x=px;near_y=py;
    int xlo=(px-32)*Q,ylo=(py-32)*Q;
    for(unsigned i=0;i<stage.count;++i){Shot *b=&stage.shots[i];int x=b->x+b->vx,y=b->y+b->vy;
        if(__builtin_expect((unsigned)(x-8*Q)>1008u*Q,0)){b->vx=-b->vx;x=x<8*Q?8*Q:1016*Q;}
        if(__builtin_expect((unsigned)(y-8*Q)>672u*Q,0)){b->vy=-b->vy;y=y<8*Q?8*Q:680*Q;}
        b->x=x;b->y=y;
        // Candidate radius 32 covers hit/graze radius 14 plus next-frame
        // movement up to 16 pixels. Overflow/teleport use the full scan.
        if(collect && __builtin_expect((unsigned)(y-ylo)<64u*Q && (unsigned)(x-xlo)<64u*Q,0)){
            if(stage_near_count<512)stage_near_indices[stage_near_count++]=i;else near_overflow=1;
        }
    }
    ++stage.frame;near_frame=stage.frame;
}
void stage_stress_step(void){stress_update(0,0,0);}
void stage_stress_step_near(int px,int py){stress_update(1,px,py);}
unsigned stage_near_ready(int px,int py){
    return near_valid && !near_overflow && near_frame==stage.frame &&
        (unsigned)(px-near_x+16)<=32 && (unsigned)(py-near_y+16)<=32;
}
