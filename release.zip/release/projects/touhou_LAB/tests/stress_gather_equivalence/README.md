# STRESS gather等价验证

这是可迁移的生产代码测试，宿主不需要板卡、Windows图像API或外部工程路径。

在工程根运行：

    python scripts/test_stress_gather.py --host-cc gcc

实际候选始终编译当前`src/stage.c`，参考为本目录冻结的R2标量`reference_stage_R2.c`。两个翻译单元使用独立符号，生产`GameConfig`正常初始化，默认gather启用。

11档0/1/3/4/5/63/64/65/512/4096/20000，每档36000tick，对比位置、速度、age、owner、阶段元数据及近邻集合，共1200276项检查。再关闭gather，对11档各128tick整Stage逐字节核验。输入包含随机signed16速度、年龄、标签、反射边界、近邻/普通更新混用。

宿主执行可移植C路径；RV32的12次寄存器gather加载另由实际目标反汇编核验，宿主计时不能外推板端FPS。脚本只在build目录生成可执行程序，测试源码目录不含DLL/EXE。

16字节DMA布局和STRESS不更新age的既有语义保持；测试不验证RTL时序或600秒实板稳定性。

另有513个同点候选的明确溢出用例，核512项近邻容量、集合及fallback readiness一致。
