#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stddef.h>
#include <time.h>
#include "stage.h"
#include "game_config.h"
unsigned battle_materials;
extern Stage base_stage,cand_stage;
extern void base_stage_stress(unsigned),cand_stage_stress(unsigned);
extern void base_stage_stress_step(void),cand_stage_stress_step(void);
extern void base_stage_stress_step_near(int,int),cand_stage_stress_step_near(int,int);
extern unsigned base_stage_near_count,cand_stage_near_count;
extern unsigned base_stage_near_indices[512],cand_stage_near_indices[512];
extern unsigned base_stage_near_ready(int,int),cand_stage_near_ready(int,int);
static unsigned checks;
#define CHECK(c) do{++checks;if(!(c)){printf("FAIL count=%u tick=%u %s\n",n,t,#c);return 1;}}while(0)
static unsigned rng=9;
static unsigned rnd(void){rng=rng*1664525u+1013904223u;return rng;}
static void initialize(unsigned n,unsigned seed){
 base_stage_stress(n);
 for(unsigned i=0;i<n;++i){Shot *s=&base_stage.shots[i];
  if(seed){s->x=(8+(int)(rnd()%1009))*Q+(int)(rnd()%4096);s->y=(8+(int)(rnd()%673))*Q+(int)(rnd()%4096);s->vx=(int16_t)rnd();s->vy=(int16_t)rnd();}
  s->age=(uint16_t)rnd();s->grazed=(uint8_t)rnd();base_stage.owner[i]=(uint8_t)(i%3);
 }
 cand_stage=base_stage;
}
int main(void){
 game_config_defaults();if(game_cfg.stress_gather_enabled!=1){puts("FAIL expected default gather enabled");return 2;}
 const unsigned counts[]={0,1,3,4,5,63,64,65,512,4096,20000};
 clock_t began=clock();
 for(unsigned c=0;c<sizeof(counts)/sizeof(counts[0]);++c){unsigned n=counts[c],t=0;initialize(n,c&1);
  for(t=0;t<36000;++t){
   if(t%97==0){int px=(int)(t*37%1024),py=(int)(t*11%688);base_stage_stress_step_near(px,py);cand_stage_stress_step_near(px,py);
    CHECK(base_stage_near_count==cand_stage_near_count);
    CHECK(!memcmp(base_stage_near_indices,cand_stage_near_indices,base_stage_near_count*sizeof(unsigned)));
    CHECK(base_stage_near_ready(px,py)==cand_stage_near_ready(px,py));
    CHECK(base_stage_near_ready(px+17,py)==cand_stage_near_ready(px+17,py));
   }else {base_stage_stress_step();cand_stage_stress_step();CHECK(base_stage_near_count==cand_stage_near_count);}
   CHECK(!memcmp(base_stage.shots,cand_stage.shots,n*sizeof(Shot)));
   CHECK(!memcmp((char *)&base_stage+offsetof(Stage,count),(char *)&cand_stage+offsetof(Stage,count),sizeof(Stage)-offsetof(Stage,count)));
  }
  printf("EXACT count=%u ticks=36000 positions/velocities/age/owner/near PASS\n",n);
 }
 printf("STAGE_CANDIDATE_SEMANTICS PASS checks=%u seconds=%.3f\n",checks,(double)(clock()-began)/CLOCKS_PER_SEC);
 game_cfg.stress_gather_enabled=0;
 for(unsigned c=0;c<sizeof(counts)/sizeof(counts[0]);++c){unsigned n=counts[c],t=0;initialize(n,c&1);
  for(t=0;t<128;++t){base_stage_stress_step();cand_stage_stress_step();CHECK(!memcmp(&base_stage,&cand_stage,sizeof(Stage)));}
 }
 puts("GATHER_DISABLED_REFERENCE PASS11counts x128ticks byteexact");
 game_cfg.stress_gather_enabled=1;
 {unsigned n=513,t=0;initialize(n,0);
  for(unsigned i=0;i<n;++i){base_stage.shots[i].x=512*Q;base_stage.shots[i].y=344*Q;base_stage.shots[i].vx=base_stage.shots[i].vy=0;}
  cand_stage=base_stage;base_stage_stress_step_near(512,344);cand_stage_stress_step_near(512,344);
  CHECK(base_stage_near_count==512&&cand_stage_near_count==512);
  CHECK(!base_stage_near_ready(512,344)&&!cand_stage_near_ready(512,344));
  CHECK(!memcmp(&base_stage,&cand_stage,sizeof(Stage)));
  CHECK(!memcmp(base_stage_near_indices,cand_stage_near_indices,512*sizeof(unsigned)));
  puts("NEAR_OVERFLOW PASS513 candidates use exact fallback readiness");
 }
 unsigned n=20000,t=0;initialize(n,0);clock_t a=clock();for(t=0;t<36000;++t)base_stage_stress_step();clock_t b=clock();
 initialize(n,0);clock_t c=clock();for(t=0;t<36000;++t)cand_stage_stress_step();clock_t d=clock();
 printf("HOST_TIMING baseline=%.3f candidate=%.3f ratio=%.3f (host-only,notboard)\n",(double)(b-a)/CLOCKS_PER_SEC,(double)(d-c)/CLOCKS_PER_SEC,(double)(d-c)/(double)(b-a));return 0;
}
