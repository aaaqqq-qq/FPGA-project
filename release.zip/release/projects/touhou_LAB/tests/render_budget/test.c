/* Render-quality policy is tested against a boundary/trace oracle. It cannot
   certify frame rate; actual firmware timing is measured independently. */
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include "effects.c"
#include "layer_visuals.h"
BattleBoss bosses[MAX_BOSSES];
typedef struct {int x,y,w,h;unsigned tile,alpha;} Draw;
static Draw output[64];static unsigned count,area,checks;
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"BUDGET_FAIL %u %s\n",__LINE__,#x);return 1;}}while(0)
static unsigned size(unsigned tile){
 if(tile==ART_RING_WARN64||tile==ART_RING_GOLD64||tile==ART_RING_CYAN64)return 64;
 if(tile==ART_RING_GREEN32||tile==ART_RING_ROSE32||tile==ART_RING_GOLD32||tile==ART_RING_CYAN32)return 32;
 assert(tile==ART_STAR16||tile==ART_PLUS16);return 16;
}
void scene_tile(int x,int y,unsigned tile,unsigned alpha){unsigned n=size(tile);assert(count<64);output[count++]=(Draw){x,y,(int)n,(int)n,tile,alpha};area+=n*n;}
void scene_rect(int x,int y,int w,int h,uint32_t color){(void)color;assert(count<64);output[count++]=(Draw){x,y,w,h,UINT_MAX,0};area+=(unsigned)w*(unsigned)h;}
static void capture_reset(void){count=area=0;memset(output,0,sizeof(output));}
static int policy_boundaries(void){
 const unsigned trigger[][4]={{3,0,0,0},{0,32,0,0},{0,0,512,0},{0,0,0,14001},{UINT_MAX,UINT_MAX,UINT_MAX,UINT_MAX}};
 for(unsigned k=0;k<sizeof(trigger)/sizeof(trigger[0]);++k){
  effects_reset();CHECK(!effects_render_budget(1,2,31,511,14000));
  CHECK(effects_render_budget(1,trigger[k][0],trigger[k][1],trigger[k][2],trigger[k][3])==1);
  for(unsigned i=0;i<59;++i)CHECK(effects_render_budget(1,2,16,256,11999)==1);
  CHECK(effects_render_budget(1,2,16,256,11999)==0);
 }
 const unsigned deadband[][4]={{2,17,256,11999},{2,16,257,11999},{2,16,256,12000},{2,16,256,14000}};
 for(unsigned k=0;k<sizeof(deadband)/sizeof(deadband[0]);++k){
  effects_reset();CHECK(effects_render_budget(1,3,0,0,0)==1);
  for(unsigned i=0;i<59;++i)CHECK(effects_render_budget(1,0,0,0,0)==1);
  CHECK(effects_render_budget(1,deadband[k][0],deadband[k][1],deadband[k][2],deadband[k][3])==1);
  for(unsigned i=0;i<59;++i)CHECK(effects_render_budget(1,0,0,0,0)==1);
  CHECK(effects_render_budget(1,0,0,0,0)==0);
 }
 CHECK(effects_render_budget(1,3,0,0,0)==1);CHECK(!effects_render_budget(0,UINT_MAX,UINT_MAX,UINT_MAX,UINT_MAX));
 CHECK(effects_quality==0&&effects_lod_jobs==0);CHECK(!effects_render_budget(1,2,31,511,14000));
 CHECK(effects_render_budget(1,3,0,0,0)==1);effects_reset();CHECK(!effects_quality&&!effects_lod_jobs);
 puts("B01 PASS fourtrigger boundaries,strict14000/12000,60framelowrecovery,deadbandresets,disable/reset");return 0;
}
static void cue(unsigned kind){
 switch(kind){case 0:fx_player_hit(500,500);break;case 1:fx_levelup(500,500);break;case 2:fx_regen(500,500);break;
 case 3:fx_boss_enrage_start(0);break;case 4:fx_boss_enrage_finish(0);break;case 5:fx_boss_enter(0);break;
 case 6:fx_boss_death(0);break;case 7:fx_graze(500,500);break;default:fx_cancel_star(500,500);break;}
}
static unsigned counterpart(unsigned t){return t==ART_RING_WARN64?ART_RING_ROSE32:t==ART_RING_GOLD64?ART_RING_GOLD32:t==ART_RING_CYAN64?ART_RING_CYAN32:t;}
static int cue_geometry(void){
 for(unsigned kind=0;kind<9;++kind){
  game_config_defaults();effects_reset();bosses[0].x=500;bosses[0].y=200;bosses[0].enter_tx=500;bosses[0].enter_ty=200;cue(kind);
  Fx before[FX_CAP];memcpy(before,fx,sizeof(before));BattleBoss saved[MAX_BOSSES];memcpy(saved,bosses,sizeof(saved));
  capture_reset();effects_render_budget(0,0,0,0,0);effects_render();Draw full[64];memcpy(full,output,sizeof(full));unsigned n=count,fullarea=area;
  CHECK(n>0&&!effects_over_budget&&!effects_lod_jobs&&!memcmp(before,fx,sizeof(before)));
  capture_reset();CHECK(effects_render_budget(1,3,0,0,0));effects_render();CHECK(n==count&&area<=fullarea&&effects_jobs==count&&effects_area==area);
  unsigned replacements=0;
  for(unsigned i=0;i<n;++i){Draw expected=full[i];if(expected.w==64){expected.x+=16;expected.y+=16;expected.w=expected.h=32;expected.tile=counterpart(expected.tile);++replacements;}
   CHECK(!memcmp(&expected,&output[i],sizeof(Draw)));
  }
  CHECK(effects_lod_jobs==replacements&&!memcmp(before,fx,sizeof(before))&&!memcmp(saved,bosses,sizeof(saved)));
  CHECK(effects_jobs<=12&&effects_area<=16384&&effects_drop_total==0);
  effects_tick();for(unsigned i=0;i<FX_CAP;++i)if(before[i].active)CHECK(fx[i].age==before[i].age+1);
 }
 puts("B02 PASS ninecue traces,64to32only,samecenter/Alpha/count,hit/regen/entryretained,Fxlifetime/Bossuntouched");return 0;
}
static int hard_limits(void){
 game_config_defaults();effects_reset();game_cfg.effect_job_budget=64;game_cfg.effect_area_budget=65536;
 for(unsigned i=0;i<FX_CAP;++i)fx[i]=(Fx){FX_RING_WARN,1,500,500,0,36};
 capture_reset();effects_render_budget(1,6,128,20000,UINT_MAX);effects_render();
 CHECK(effects_jobs==12&&effects_area==12288&&effects_lod_jobs==12&&effects_over_budget==20&&effects_drop_total==20);
 game_config_defaults();effects_reset();game_cfg.effect_job_budget=1;
 for(unsigned i=0;i<FX_CAP;++i)fx[i]=(Fx){FX_GRAZE,1,500,500,0,10};
 fx_levelup(500,500);capture_reset();effects_render_budget(1,3,0,0,0);effects_render();
 CHECK(count==1&&output[0].tile==ART_RING_CYAN32&&effects_lod_jobs==1);
 puts("B03 PASS hard12jobs/16384pixels and criticallevelup priority evenwithfullcosmeticpool");return 0;
}
static int decorations(void){
 for(unsigned strength=1;strength<=2;++strength)for(unsigned busy=0;busy<2;++busy){
  for(unsigned tick=0;tick<12000;++tick){capture_reset();layer_visuals_strength(strength);layer_visuals_quality(busy);layer_visuals_begin(tick,1,512,620);
   for(unsigned k=0;k<7;++k)layer_visuals_shadow(80+(int)k*130,180+(int)k*55,40);
   layer_visuals_glow(512,620);layer_visuals_foreground();
   CHECK(count==12&&area==layer_visuals_area&&layer_visuals_jobs==count&&!layer_visuals_dropped);
   CHECK(area==(strength==1?1828u:busy?2592u:5664u));CHECK(area<=8192);
   CHECK(output[7].tile==(strength==2&&!busy?ART_RING_CYAN64:ART_RING_CYAN32));
   CHECK(output[7].alpha==(strength==2?100u:38u)+(((tick>>2)&31)<16?((tick>>2)&31):31-((tick>>2)&31))*(strength==2?2u:1u));
  }
 }
 capture_reset();layer_visuals_quality(UINT_MAX);layer_visuals_begin(0,0,INT_MIN,INT_MAX);layer_visuals_glow(INT_MAX,INT_MIN);layer_visuals_foreground();CHECK(!count&&!layer_visuals_area);
 layer_visuals_quality(0);
 puts("B04 PASS48000decorframes,exact1828/5664/2592areas,12jobcap,Alphaandstrengthpreserved,disabledinert");return 0;
}
int main(void){if(policy_boundaries()||cue_geometry()||hard_limits()||decorations())return 1;printf("RENDER_BUDGET PASS checks=%u\n",checks);return 0;}
