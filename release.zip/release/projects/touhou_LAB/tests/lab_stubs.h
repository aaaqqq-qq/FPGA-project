#ifndef LAB_GAMEPLAY_TEST_STUBS_H
#define LAB_GAMEPLAY_TEST_STUBS_H
#include "lab.h"
/* Logic harnesses deliberately stub display ownership. Real lab tests execute
 * src/lab.c with an independent pixel oracle. */
static unsigned host_lab_active,host_lab_pending;
static lab_restore_fn host_lab_restore;
void lab_init(lab_reply_fn emit,lab_restore_fn restore){(void)emit;host_lab_restore=restore;host_lab_active=host_lab_pending=0;}
int lab_command(const char *line){(void)line;return 0;}
unsigned lab_active(void){return host_lab_active;}
unsigned lab_pending(void){return host_lab_pending;}
void lab_service(void){}

/* LAB23 display-ownership stubs for game-only host harnesses. */
#include "labx.h"
static unsigned host_labx_active,host_labx_pending,host_labx_cancel;
void labx_init(lab_reply_fn a,lab_restore_fn b){(void)a;(void)b;host_labx_active=host_labx_pending=0;}
unsigned labx_active(void){return host_labx_active;}
unsigned labx_pending(void){return host_labx_pending;}
unsigned labx_cancelled(void){return host_labx_cancel;}
int labx_cpu_poll(void){return (int)host_labx_cancel;}
int labx_command(const char *s){return !strncmp(s,"labx ",5);}
void labx_service(void){}
/* Game-only harnesses stub ADV ownership; real ADV C has a separate DMA test. */
#include "adv.h"
static unsigned host_adv_active,host_adv_pending;
void adv_init(lab_reply_fn a,lab_restore_fn b){(void)a;(void)b;host_adv_active=host_adv_pending=0;}
unsigned adv_active(void){return host_adv_active;}
unsigned adv_pending(void){return host_adv_pending;}
int adv_cpu_poll(void){return 0;}
int adv_command(const char *s){return !strncmp(s,"adv ",4);}
void adv_service(void){}
/* The full scene renderer has independent raster/guard tests. */
static unsigned host_bullet_size=8,host_bullet_prepare_fail,host_bullet_guard_fail;
int scene_bullets_prepare(unsigned size){if(host_bullet_prepare_fail)return 0;host_bullet_size=size;return size>=8&&size<=56&&!(size&7);}
void scene_bullets_reset(void){host_bullet_size=8;}
int scene_bullets_guards_ok(void){return !host_bullet_guard_fail;}
#endif
