
#include "../../sim/scene_host.c"
#include "game_config.h"
#include "effects.h"
#include "battle.h"
BattleBoss bosses[MAX_BOSSES];
__declspec(dllexport) void hud_frame(unsigned f,unsigned hw){
 uint32_t fb=(f&1)?BB_FB1:BB_FB0;scene_set_batch(0);scene_begin(fb,hw);scene_hud_begin();
 scene_text(1078,124,"SCORE",0x8786a3,1);
 if(f<6)scene_text(1078,138,f<3?"123456789":f<5?"987654321":"1",0xffffff,2);
 scene_rect(1078,178,186,10,0x383143);
 scene_rect(1078,178,f<5?180:20,10,0x80d89b);
 scene_text(1078,192,f<5?"HP 100/100":"HP 9/100",0xffffff,1);
 scene_text(1078,620,"LIVE",0x80d89b,1);
 scene_hud_end();scene_end();
}
__declspec(dllexport) void vignette_frame(unsigned f,unsigned hw,unsigned batch,unsigned on){
 uint32_t fb=(f&1)?BB_FB1:BB_FB0;scene_set_batch(batch);scene_begin(fb,hw);
 if(batch){stage.count=0;scene_batch_shots();}
 effects_reset();effects_render();effects_vignette(f,100,100,on);scene_end();
}

__declspec(dllexport) void set_cache(unsigned n){scene_hud_cache_enable(n);}
__declspec(dllexport) unsigned get_rows(void){return scene_hud_restored_rows;}
__declspec(dllexport) unsigned get_jobs(void){return scene_hud_redraw_jobs;}

__declspec(dllexport) void new_init(void){game_config_defaults();init_test();}
