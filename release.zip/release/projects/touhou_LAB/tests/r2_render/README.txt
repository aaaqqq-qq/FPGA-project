R2 renderer regressions. Run from project root.

1. python tests/r2_render/test_render.py
2. gcc -O2 -Wall -Wextra -Isrc tests/r2_render/effects_budget.c src/game_config.c -o build/r2_effects_budget.exe
3. build/r2_effects_budget.exe

Test 1 uses actual scene/font/effects/config source and the deferred MMIO host model.
It compares all bytes of 12 complete frames against cache-disabled redraw, validates unchanged HUD submits zero jobs, a single changed score updates three strips independently on each buffer, and shorter/removed text and bars leave no stale pixels.
Warning accents are checked for both CPU/emulated hardware and batch/nonbatch modes, on both buffers after expiry.
Test 2 checks rate limiting, bounded cosmetic slots, high-priority effect allocation/draw ordering, low-HP pulse and shared hard budgets.
These tests do not prove physical DDR/cache timing or board FPS.
