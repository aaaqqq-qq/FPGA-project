
from pathlib import Path
import ctypes,subprocess,json,argparse,os,shlex
r=Path(__file__).resolve().parents[2];out=r/'results/r2_render';out.mkdir(exist_ok=True)
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));args=ap.parse_args()
cc=[x.strip('"') for x in shlex.split(args.host_cc,posix=False)]
font=(r/'src/font.c').read_text().replace('void draw_text(','void font_draw_text(')
(out/'font.c').write_text(font)
libs=[]
for name in ['cached','reference']:
 dll=out/(name+'.dll')
 cmd=cc+['-O2','-shared','-DBB_HOST_TEST','-Isrc','tests/r2_render/hud_host.c','src/scene.c','src/background.c',str(out/'font.c'),'src/pixels.c','src/render_queue.c','src/effects.c','src/game_config.c','-o',str(dll)]
 p=subprocess.run(cmd,cwd=r,capture_output=True,text=True);(out/(name+'_compile.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
 libs.append(ctypes.CDLL(str(dll)))
k=ctypes.WinDLL('kernel32',use_last_error=True);k.VirtualAlloc.restype=ctypes.c_void_p;k.VirtualAlloc.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32,ctypes.c_uint32]
base=0x01000000;size=0x1200000;assert k.VirtualAlloc(base,size,0x3000,4)==base
assert k.VirtualAlloc(0x07000000,0x00400000,0x3000,4)==0x07000000, ctypes.get_last_error()
expected=[];counts=[]
for index,lib in enumerate(libs):
 ctypes.memset(base,0xa5,size);lib.new_init();lib.set_cache(index==0)
 for f in range(12):
  lib.hud_frame(f,f%3!=0)
  pix=ctypes.string_at(base+(0x400000 if f&1 else 0),1280*720*4)
  rows=lib.get_rows()
  jobs=lib.get_jobs()
  if index==0:
   expected.append(pix);counts.append({'frame':f,'rows':rows,'jobs':jobs})
   if f==2:assert rows==0 and jobs==0,counts[-1]
   if f in [3,4]:assert 0<rows<8,counts[-1]
   if f>=8:assert rows==0 and jobs==0,counts[-1]
  else:assert pix==expected[f],f
# Warning accents must disappear after reuse of both framebuffer banks in all modes.
vignette=[]
lib=libs[0]
for batch in [0,1]:
 for hw in [0,1]:
  ctypes.memset(base,0xa5,size);lib.new_init()
  lib.vignette_frame(0,hw,batch,0);lib.vignette_frame(1,hw,batch,0)
  clean0=ctypes.string_at(base,1280*720*4);clean1=ctypes.string_at(base+0x400000,1280*720*4)
  lib.vignette_frame(2,hw,batch,1);lib.vignette_frame(3,hw,batch,1)
  assert ctypes.string_at(base,1280*720*4)!=clean0
  lib.vignette_frame(4,hw,batch,0);lib.vignette_frame(5,hw,batch,0)
  assert ctypes.string_at(base,1280*720*4)==clean0
  assert ctypes.string_at(base+0x400000,1280*720*4)==clean1
  vignette.append({'batch':batch,'hw':hw,'cleanup':'PASS'})
result={'status':'PASS','hud_frames_exact':12,'cached_rows':counts,'vignette':vignette}
(out/'summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
