/* R7 renderer APIs are no-ops only in this gameplay/command stub. */
#include "../scene_layers_stubs.h"
void scene_batch_shots(void){}

#include <assert.h>
#include <stdio.h>
#include "../../src/effects.c"
BattleBoss bosses[MAX_BOSSES];
static unsigned draws,first_tile;
void scene_tile(int x,int y,unsigned tile,unsigned alpha){(void)x;(void)y;(void)alpha;if(!draws)first_tile=tile;++draws;}
void scene_rect(int x,int y,int w,int h,uint32_t c){(void)x;(void)y;(void)w;(void)h;(void)c;++draws;}
static unsigned count_kind(unsigned kind){unsigned n=0;for(unsigned i=0;i<FX_CAP;++i)if(fx[i].active&&fx[i].kind==kind)++n;return n;}
int main(void){
 game_config_defaults();effects_reset();
 for(unsigned i=0;i<100;++i)fx_graze(500,600);
 assert(count_kind(FX_GRAZE)==1);effects_render();assert(effects_jobs==1&&effects_area==256);
 for(unsigned i=0;i<game_cfg.graze_feedback_cooldown;++i)effects_tick();
 fx_graze(500,600);assert(count_kind(FX_GRAZE)<=2);
 effects_reset();game_cfg.graze_feedback_enabled=0;fx_graze(0,0);assert(count_kind(FX_GRAZE)==0);
 game_config_defaults();effects_reset();
 for(unsigned i=0;i<100;++i)fx_cancel_star((int)i,100);
 assert(count_kind(FX_CANCEL_STAR)<=game_cfg.death_star_budget&&count_kind(FX_CANCEL_STAR)<=8);
 effects_render();assert(effects_jobs<=12&&effects_area<=16384);
 effects_reset();for(unsigned i=0;i<FX_CAP;++i)fx[i]=(Fx){FX_GRAZE,1,500,500,0,10};
 bosses[0].x=500;bosses[0].y=100;fx_boss_enrage_start(0);game_cfg.effect_job_budget=1;draws=0;
 effects_render();assert(draws==1&&first_tile==ART_RING_WARN64);
 effects_reset();for(unsigned i=0;i<FX_CAP;++i)fx[i]=(Fx){FX_GRAZE,1,500,500,0,10};
 fx_levelup(500,500);game_cfg.effect_job_budget=12;draws=0;effects_render();assert(first_tile==ART_RING_CYAN64);
 assert(effects_jobs<=12&&effects_area<=16384);
 game_config_defaults();assert(effects_hp_color(10,100,0)!=effects_hp_color(10,100,game_cfg.low_hp_pulse_ticks/2));
 assert(effects_hitpoint_color(10,100,0)!=effects_hitpoint_color(100,100,0));
 effects_reset();effects_render();effects_vignette(0,100,100,1);assert(effects_jobs==4&&effects_area==1664);
 game_cfg.effect_job_budget=0;effects_reset();effects_render();effects_vignette(0,100,100,1);assert(effects_jobs==0&&effects_area==0&&effects_over_budget==4);
 game_config_defaults();assert(effects_hp_color(30,100,0)==effects_hp_color(30,100,game_cfg.low_hp_pulse_ticks/2));
 assert(effects_hp_color(29,100,0)!=effects_hp_color(29,100,game_cfg.low_hp_pulse_ticks/2));
 assert(!game_config_set("effect_job_budget",13));assert(!game_config_set("effect_area_budget",16385));assert(!game_config_set("death_star_budget",9));
 effects_reset();game_cfg.effect_job_budget=64;game_cfg.effect_area_budget=65536;
 for(unsigned i=0;i<FX_CAP;++i)fx[i]=(Fx){FX_GRAZE,1,500,500,0,10};
 effects_render();assert(effects_jobs==12&&effects_area==3072&&effects_over_budget==20&&effects_drop_total==20);
 effects_render();assert(effects_over_budget==20&&effects_drop_total==40);
 effects_reset();assert(effects_drop_total==0);
 effects_reset();for(unsigned i=0;i<FX_CAP;++i)fx[i]=(Fx){FX_RING_WARN,1,500,500,0,36};
 effects_render();assert(effects_jobs==4&&effects_area==16384&&effects_over_budget==28);
 fx_graze(500,500);effects_reset();assert(graze_wait==0);assert(effects_jobs==0);assert(effects_over_budget==0);
 puts("R2_EFFECTS_PASS graze_rate_limit death_star_cap primary_priority lowHP_pulse vignette_budget");return 0;
}
