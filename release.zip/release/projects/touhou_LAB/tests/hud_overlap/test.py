from pathlib import Path
import argparse,ctypes,hashlib,json,subprocess,os,sys
r=Path(__file__).resolve().parents[2];out=r/'results/hud_overlap';out.mkdir(exist_ok=True)
p=argparse.ArgumentParser();p.add_argument('--host-cc',default='E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe');a=p.parse_args()
base=t=r/'tests/hud_overlap'
# Freeze old source verbatim: the reference does not share the new HUD code.
old=(base/'reference_scene.c').read_bytes();assert hashlib.sha256(old).hexdigest()=='0288f7cc1ced616db16d46fb446c3752f59692dfcc92ffff2d9d0ca0cb9b7a95';(out/'reference_scene.c').write_bytes(old)
libs=[]
for name,source in [('reference',str(out/'reference_scene.c')),('candidate','src/scene.c')]:
 mapped=Path(source).read_text() if Path(source).is_absolute() else (r/source).read_text();mapped=mapped.replace('#include "stage.h"','#include "stage.h"'+chr(10)+'#define stage (*(Stage *)(uintptr_t)0x02100000u)');mapped_path=out/(name+'_mapped_scene.c');mapped_path.write_text(mapped,encoding='utf8');source=str(mapped_path)
 dll=out/(name+'.dll');cmd=[a.host_cc,'-O2','-shared','-DBB_HOST_TEST','-Isrc','tests/hud_overlap/host.c',source,'src/font.c','src/pixels.c','src/render_queue.c','src/background.c','src/game_config.c','-o',str(dll)]
 if name=='reference':cmd.insert(1,'-DBASELINE_SCHEDULE')
 q=subprocess.run(cmd,cwd=r,capture_output=True,text=True);(out/(name+'_compile.log')).write_text(q.stdout+q.stderr,encoding='utf8');assert q.returncode==0,q.stderr
 libs.append(ctypes.CDLL(str(dll)))
k=ctypes.WinDLL('kernel32',use_last_error=True);k.VirtualAlloc.restype=ctypes.c_void_p;k.VirtualAlloc.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32,ctypes.c_uint32]
for address,size in [(0x1000000,0x1200000),(0x7000000,0x400000),(0x5ff0000,0x90000)]:assert k.VirtualAlloc(address,size,0x3000,4)==address,ctypes.get_last_error()
# Both banks, changing numeric values every frame, insertion/deletion,
# overlap reorder, clipping, scaled/unusual text, cache toggles, both materials.
seq=[]
for f in range(80):seq.append((f,0 if f%17==15 else 1,0 if f%13==11 else 1,0 if f%19 in (12,13) else 1,32 if f%4<2 else 8,5000 if f in (40,41) else 20000 if f in (42,43) else 257))
expected=[];traces=[];metrics=[]
for ix,lib in enumerate(libs):
 ctypes.memset(0x1000000,0xa5,0x1200000);ctypes.memset(0x7000000,0xa5,0x400000);lib.init_overlap()
 for n,args in enumerate(seq):
  lib.frame_overlap(*args);address=0x1000000+(0x400000 if args[0]&1 else 0)
  pixel=hashlib.sha256(ctypes.string_at(address,1280*720*4)).hexdigest();trace=(lib.trace()&0xffffffff,lib.trace_jobs())
  if ix==0:expected.append(pixel);traces.append(trace)
  else:
   assert pixel==expected[n],('fullpixel',n,args,pixel,expected[n]);assert trace==traces[n],('fieldjob order',n,args,trace,traces[n])
 metrics.append({'variant':ix,'overlap_frames':lib.overlap_count(),'strict_unchanged_pixels':lib.checked()})
assert metrics[1]['overlap_frames']>=60,metrics
# Run the error injection in a separate process: real scene fatal must fire
# before any unsafe fallback or metadata publication can hide the engine error.
child=out/'fault.py';child.write_text("import ctypes\nk=ctypes.WinDLL('kernel32');k.VirtualAlloc.restype=ctypes.c_void_p\nfor a,s in [(0x1000000,0x1200000),(0x7000000,0x400000)]:\n assert k.VirtualAlloc(ctypes.c_void_p(a),s,0x3000,4)==a\nf=ctypes.CDLL("+repr(str(out/'candidate.dll'))+");f.init_overlap();f.inject_fault()\n",encoding='utf8')
q=subprocess.run([sys.executable,str(child)],capture_output=True,text=True);(out/'fault.log').write_text(q.stdout+q.stderr,encoding='utf8');assert q.returncode==2 and 'HUD BATCH ENGINE' in q.stderr,(q.returncode,q.stdout,q.stderr)
result={'status':'PASS','frames_exact':len(seq),'pixels_compared':len(seq)*1280*720,'field_job_traces_exact':len(seq),'metrics':metrics,'error_fail_closed':'PASS','base':str(base),'source_sha256':{p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in ['src/scene.c','tests/hud_overlap/host.c']},'reference_scene_sha256':hashlib.sha256(old).hexdigest(),'scope':'Full source CPU deferred-DMA raster; strict CPU HUD writes only x>=1072/y118..703, both FBs outside region unchanged; no physical cache/DDR timing or FPS claim','pixel_sha256':expected}
(out/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf8');print('HUD_OVERLAP PASS',len(seq),'frames',len(seq)*1280*720,'pixels, ordered field jobs exact, errors fail closed; overlap frames',metrics[1]['overlap_frames'])
