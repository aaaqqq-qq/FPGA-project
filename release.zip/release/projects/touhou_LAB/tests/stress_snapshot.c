#include <assert.h>
#include <stdio.h>
#include <stdint.h>
#include <setjmp.h>
#include <string.h>
#define BB_HOST_TEST
#include "scene.c"
Stage stage;
unsigned battle_materials;
static unsigned sequence,status_reads,byte_reads,stale_reads,expected_fatal;
static uint64_t fake_ticks;
static jmp_buf fault_jump;
static char fault_where[64];
void fatal(const char *where,int code){(void)code;if(expected_fatal){strcpy(fault_where,where);longjmp(fault_jump,1);}fprintf(stderr,"UNEXPECTED FATAL %s %d\n",where,code);assert(0);}
uint64_t bb_ticks(void){return fake_ticks;}
uint32_t bb_us(uint64_t t){return (uint32_t)(t/100);}
void bb_write(unsigned reg,uint32_t value){(void)reg;(void)value;assert(0);}
bb_result bb_publish(void){assert(0);return BB_OK;}
void bb_acquire(void){assert(0);}
bb_result bb_cpu_execute(const bb_job *job){(void)job;assert(0);return BB_OK;}
void draw_text(uint32_t fb,unsigned x,unsigned y,const char *t,uint32_t c,unsigned s){(void)fb;(void)x;(void)y;(void)t;(void)c;(void)s;assert(0);}
void draw_text_clipped(uint32_t fb,int x,int y,const char *t,uint32_t c,unsigned s,int l,int top,int r,int b){(void)fb;(void)x;(void)y;(void)t;(void)c;(void)s;(void)l;(void)top;(void)r;(void)b;assert(0);}
uint32_t bb_read(unsigned reg){
    if(reg==BB_STATUS){
        ++status_reads;fake_ticks=1000+(status_reads-1)*50;
        if(sequence==2)return BB_DONE;
        if(sequence==3&&status_reads==2)return BB_DONE;
        if(sequence==4)return BB_ERROR;
        if(sequence==5&&status_reads>=2)fake_ticks=10000200;
        if(sequence==6){fake_ticks=1000000+(status_reads-1)*50;if(status_reads==1)return 0;}
        return BB_BUSY;
    }
    if(reg==BB_READ_BYTES){
        ++byte_reads;
        if((sequence!=6&&fake_ticks<1100)||(sequence==6&&fake_ticks<1000150)){++stale_reads;return 0xffffffffu;}
        if(sequence==5)return 0;
        if(sequence==0&&byte_reads==1)return 4096;
        return 4096+64*16;
    }
    return 0;
}
static void new_case(unsigned n){sequence=n;status_reads=byte_reads=stale_reads=0;fake_ticks=0;pending_job=1;previous.op=2;batch_count=64;stage.count=20000;expected_fatal=0;fault_where[0]=0;}
int main(void){
    new_case(0);scene_batch_snapshot_ready();assert(status_reads==4&&byte_reads==2&&!stale_reads);
    puts("SNAPSHOT PASS first BUSY anchors 1us guard; stale-high before guard never read; fresh incomplete descriptors wait");
    new_case(1);scene_batch_snapshot_ready();assert(status_reads==3&&byte_reads==1&&!stale_reads);
    puts("SNAPSHOT PASS new generation after1us; frozen submitted count64 ignores stage.count20000");
    new_case(2);scene_batch_snapshot_ready();assert(status_reads==1&&!byte_reads);
    pending_job=0;scene_batch_snapshot_ready();assert(status_reads==1);
    pending_job=1;previous.op=0;scene_batch_snapshot_ready();assert(status_reads==1);
    puts("SNAPSHOT PASS complete/no-job/non-batch paths");
    new_case(3);scene_batch_snapshot_ready();assert(status_reads==2&&!byte_reads);
    puts("SNAPSHOT PASS early DONE safely bypasses BUSY timer");
    new_case(6);scene_batch_snapshot_ready();assert(status_reads==4&&byte_reads==1&&!stale_reads);
    puts("SNAPSHOT PASS late BUSY does not inherit helper-entry elapsed time");
    new_case(4);expected_fatal=1;if(!setjmp(fault_jump)){scene_batch_snapshot_ready();assert(0);}assert(!strcmp(fault_where,"SNAPSHOT ENGINE"));
    new_case(5);expected_fatal=1;if(!setjmp(fault_jump)){scene_batch_snapshot_ready();assert(0);}assert(!strcmp(fault_where,"SNAPSHOT TIMEOUT"));
    puts("SNAPSHOT PASS engine error and timeout stop before mutation");return 0;
}
