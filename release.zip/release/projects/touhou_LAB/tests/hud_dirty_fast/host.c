#include "../../sim/scene_host.c"
#include "game_config.h"
__declspec(dllexport) void fast_init(void){game_config_defaults();init_test();}
__declspec(dllexport) unsigned rows(void){return scene_hud_restored_rows;}
__declspec(dllexport) unsigned jobs(void){return scene_hud_redraw_jobs;}
__declspec(dllexport) void frame(unsigned id,unsigned bank,unsigned hw,unsigned cache){
 scene_hud_cache_enable(cache);scene_set_batch(0);scene_begin(bank?BB_FB1:BB_FB0,hw);scene_hud_begin();
 if(id!=7){
  scene_text(1078,124,id==2?"1":"ALPHABET123456",0x80cfff,2);
  if(id==3)scene_text(1078,157,"INSERTED",0xf0cc8d,1);
  scene_rect(1078,178,186,10,0x28253b);scene_rect(1078,178,id==2?9:170,10,0x80d89b);
  if(id!=4)scene_text(1078,192,"REMOVE ME",0xffffff,1);
  if(id==5){scene_rect(1105,300,80,22,0x204080);scene_rect(1080,296,80,22,0x802040);}
  else {scene_rect(1080,296,80,22,0x802040);scene_rect(1105,300,80,22,0x204080);}
  scene_rect(1080,id==6?263:327,93,31,0x283b50);
  scene_text(1078,id==6?399:351,"WIDE",id==6?0xf0cc8d:0xffffff,4);
  scene_text(1078,620,"LIVE",0x80d89b,1);
  scene_text(1264,690,id==10?"EDGE":"E",0xe080c0,id==10?4:1);
  /* Equal-count command changes entirely outside the cached clip. */
  scene_text(1400,199,id==11?"OUTSIDE CHANGED":"OUTSIDE",0xffffff,1);
 }
 scene_hud_end();scene_end();
}
