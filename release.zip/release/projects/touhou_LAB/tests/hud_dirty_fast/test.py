
from pathlib import Path
import argparse,ctypes,subprocess,json,os,shlex,hashlib
r=Path(__file__).resolve().parents[2];out=r/'results/hud_dirty_fast';out.mkdir(exist_ok=True)
p=argparse.ArgumentParser();p.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=p.parse_args();cc=[x.strip('"')for x in shlex.split(a.host_cc,posix=False)]
font=(r/'src/font.c').read_text().replace('void draw_text(','void font_draw_text(');(out/'font.c').write_text(font)
libs=[]
for name in ['cached','reference']:
 dll=out/(name+'.dll');cmd=cc+['-O2','-shared','-DBB_HOST_TEST','-Isrc','tests/hud_dirty_fast/host.c','src/scene.c','src/background.c',str(out/'font.c'),'src/pixels.c','src/render_queue.c','src/game_config.c','-o',str(dll)]
 q=subprocess.run(cmd,cwd=r,capture_output=True,text=True);(out/(name+'_compile.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,q.stderr;libs.append(ctypes.CDLL(str(dll)))
k=ctypes.WinDLL('kernel32',use_last_error=True);k.VirtualAlloc.restype=ctypes.c_void_p;k.VirtualAlloc.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32,ctypes.c_uint32]
base=0x1000000;size=0x1200000;assert k.VirtualAlloc(base,size,0x3000,4)==base
assert k.VirtualAlloc(0x07000000,0x00400000,0x3000,4)==0x07000000, ctypes.get_last_error()
# Same bank repeats, alternating banks, reordered overlaps, insert/delete,
# shortening, cross-band moves, empty lists, clipping and cache off/on.
seq=[(0,0,1,1),(0,1,0,1),(0,0,0,1),(0,1,1,1),
 (2,1,1,1),(2,0,0,1),(3,0,1,1),(3,1,0,1),
 (4,1,1,1),(4,0,1,1),(5,0,0,1),(5,1,1,1),
 (6,1,0,1),(6,0,1,1),(7,0,1,1),(7,1,0,1),
 (7,0,0,1),(7,1,1,1),(0,1,1,0),(0,0,0,0),
 (0,1,0,1),(0,0,1,1),(10,0,1,1),(10,1,0,1),
 (11,1,1,1),(11,0,0,1),(11,1,0,1),(11,0,1,1)]
expected=[];counts=[]
for ix,lib in enumerate(libs):
 ctypes.memset(base,0xa5,size);lib.fast_init()
 for n,(case,bank,hw,cache) in enumerate(seq):
  lib.frame(case,bank,hw,cache if ix==0 else 0)
  pix=ctypes.string_at(base+(0x400000 if bank else 0),1280*720*4)
  if ix==0:
   expected.append(pix);counts.append({'step':n,'case':case,'bank':bank,'hardware_model':hw,'cache':cache,'rows':lib.rows(),'jobs':lib.jobs()})
   if n in [2,3,16,17,26,27]:assert lib.rows()==0 and lib.jobs()==0,counts[-1]
  else:assert pix==expected[n],('pixels mismatch',n,seq[n])
result={'status':'PASS','frames_exact':len(seq),'sequence':counts,'source_sha256':hashlib.sha256((r/'src/scene.c').read_bytes()).hexdigest(),'scope':'exact full1280x720 frames vs cache-disabled redraw; host deferred MMIO model, no board timing claim'}
(out/'summary.json').write_text(json.dumps(result,indent=2));print('HUD_DIRTY_FAST PASS',len(seq),'complete frames')
