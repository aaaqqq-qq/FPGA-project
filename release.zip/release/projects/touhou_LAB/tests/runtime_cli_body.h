#include "replay.h"
static void send_line(const char *s){while(*s)uart_character(*s++);}
static unsigned reply(char *out){txlen=txpos=0;service_command_output();if(txlen){memcpy(out,tx,txlen);out[txlen]=0;txpos=txlen;return txlen;}out[0]=0;return 0;}
static void clear_replies(void){char out[768];for(unsigned i=0;i<64&&reply(out);++i){} }
static void cli_setup(void){
    clear_replies();game_config_defaults();replay_reset();remote_input_init(&remote);mode=MENU;
    command_len=command_overflow=0;demo_invincible=autoplay=keys=edges=bomb_requests=0;
    txlen=txpos=0;replay_export_active=0;
}
int main(void){
    char out[768];assert(sizeof(command_rx)>=256);cli_setup();send_line(":set low_hp_threshold 30\n");assert(mode==MENU&&game_cfg.low_hp_threshold==30);assert(reply(out)&&strstr(out,"OK set"));
    puts("C01 PASS full set command without legacy prefix trigger");
    GameConfig old=game_cfg;
    for(unsigned i=0;i<3;++i){const char *bad[]={":set unknown_field 1\n",":set low_hp_threshold 42949672960\n",":set low_hp_threshold -1\n"};send_line(bad[i]);assert(memcmp(&old,&game_cfg,sizeof(old))==0);assert(reply(out)&&strstr(out,"ERR"));}
    puts("C02 PASS unknown/overflow/negative values atomic reject");
    send_line(":set low_hp_threshold ");for(unsigned i=0;i<sizeof(command_rx)+16;++i)uart_character('9');uart_character('\n');assert(memcmp(&old,&game_cfg,sizeof(old))==0);assert(reply(out)&&strstr(out,"too long"));assert(mode==MENU);
    puts("C03 PASS command buffer overflow fails without mutation");
    send_line(":rubbish\n");assert(mode==MENU);assert(reply(out)&&strstr(out,"ERR"));
    send_line(":something\n");assert(mode==MENU);assert(reply(out)&&strstr(out,"ERR"));
    puts("C04 PASS invalid alphabetic commands cannot launch legacy modes");
    cli_setup();uart_character('r');host_ticks+=60000;input();assert(mode==MENU);
    send_line("mn20000\ns\nr\n");assert(mode==MENU);
    send_line(":mode 3\n");assert(mode==STRESS);assert(reply(out)&&strstr(out,"OK mode 3"));
    puts("C05 PASS raw legacy bytes inert; explicit PC mode starts stress");
    cli_setup();send_line(":set low_hp_threshold 31\n:set unknown_field 1\n");assert(game_cfg.low_hp_threshold==31);assert(reply(out)&&strstr(out,"OK set"));assert(reply(out)&&strstr(out,"ERR"));
    puts("C06 PASS acknowledgement FIFO order");
    cli_setup();send_line(":record 12345\n");assert(replay_state()==REPLAY_RECORDING&&stage.seed==12345);assert(reply(out)&&strstr(out,"record started"));
    for(unsigned i=0;i<8;++i)runtime_step();send_line(":stop\n");assert(replay_state()==REPLAY_READY);assert(reply(out)&&strstr(out,"saved"));
    send_line(":replay status\n");assert(reply(out)&&strstr(out,"REPLAY_STATUS"));
    send_line(":replay dump\n");assert(reply(out)&&strstr(out,"REPLAY_BEGIN"));unsigned words=0;
    while(reply(out)){if(strstr(out,"REPLAY_WORD"))++words;else if(strstr(out,"REPLAY_END"))break;else assert(0);}
    assert(words==replay_export_words());
    send_line(":replay\n");assert(replay_state()==REPLAY_PLAYING);assert(reply(out)&&strstr(out,"started"));
    for(unsigned i=0;i<9;++i)runtime_step();assert(replay_state()==REPLAY_FINISHED&&replay_status()==0);
    puts("C07 PASS record/stop/status/bounded dump/replay commands");
    cli_setup();choice=0;start();game_cfg.death_slowmo_enabled=1;game_cfg.death_slowmo_divisor=3;slowmo_remaining=12;slowmo_phase=0;unsigned before=ticks;
    for(unsigned i=0;i<12;++i)runtime_step();assert(runtime_tick==12&&ticks-before==4&&slowmo_remaining==0);
    puts("C08 PASS 12 base ticks produce precisely 4 slow-motion logic steps");
    cli_setup();
    assert(game_cfg.layer_visuals_strength==2);
    for(unsigned value=1;value<=2;++value){char line[96];sprintf(line,":set layer_visuals_strength %u\n",value);unsigned rev=presentation_revision;send_line(line);
        assert(reply(out)&&strstr(out,"OK set")&&game_cfg.layer_visuals_strength==value&&presentation_revision==rev+1);}
    const char *fields[]={"layer_pipeline_enabled","layer_y_sort","layer_visuals_enabled"};
    for(unsigned i=0;i<3;++i)for(unsigned value=0;value<2;++value){
        char line[96];sprintf(line,":set %s %u\n",fields[i],value);unsigned rev=presentation_revision;
        send_line(line);assert(reply(out)&&strstr(out,"OK set")&&presentation_revision==rev+1);
        assert((i==0?game_cfg.layer_pipeline_enabled:i==1?game_cfg.layer_y_sort:game_cfg.layer_visuals_enabled)==value);
    }
    for(unsigned index=0;index<8;++index)for(unsigned value=0;value<256;++value){
        char line[96];sprintf(line,":set layer_order[%u] %u\n",index,value);send_line(line);
        assert(reply(out)&&strstr(out,"OK set")&&game_cfg.layer_order[index]==value);
    }
    const char *invalid[]={":set layer_pipeline_enabled 2\n",":set layer_y_sort 4294967295\n",":set layer_visuals_enabled 2\n",":set layer_order[0] 256\n",":set layer_order[8] 1\n",":set layer_order[2] -1\n",":set layer_order[0]garbage 1\n",":set layer_visuals_strength 0\n",":set layer_visuals_strength 3\n",":set layer_visuals_strength 4294967295\n"};
    for(unsigned i=0;i<sizeof(invalid)/sizeof(invalid[0]);++i){GameConfig saved=game_cfg;unsigned rev=presentation_revision;
        send_line(invalid[i]);assert(reply(out)&&strstr(out,"ERR")&&!memcmp(&saved,&game_cfg,sizeof(saved))&&presentation_revision==rev);
    }
    puts("C09 PASS R7p1strength1..2/three booleanflags,all8x256ranks,atomicbadvaluesandrevisions");
    cli_setup();
    assert(game_cfg.battle_gather_enabled==1&&game_cfg.opaque_sprites==1&&game_cfg.render_budget_enabled==1);
    const char *r8flags[]={"battle_gather_enabled","opaque_sprites","render_budget_enabled"};
    for(unsigned i=0;i<3;++i){
        for(unsigned value=0;value<2;++value){char line[96];unsigned rev=presentation_revision;
            sprintf(line,":set %s %u\n",r8flags[i],value);send_line(line);
            assert(reply(out)&&strstr(out,"OK set")&&presentation_revision==rev+1);
            assert((i==0?game_cfg.battle_gather_enabled:i==1?game_cfg.opaque_sprites:game_cfg.render_budget_enabled)==value);
        }
        const unsigned badvalues[]={2u,4294967295u};
        for(unsigned j=0;j<2;++j){GameConfig saved=game_cfg;unsigned rev=presentation_revision;char line[96];
            sprintf(line,":set %s %u\n",r8flags[i],badvalues[j]);send_line(line);
            assert(reply(out)&&strstr(out,"ERR")&&presentation_revision==rev&&!memcmp(&saved,&game_cfg,sizeof(saved)));
        }
    }
    puts("C10 PASS R8gather/opaque/budget defaults1,toggle0/1,atomic2/UINTMAXrejects");
    puts("ALL_RUNTIME_CLI_PASS");return 0;
}
