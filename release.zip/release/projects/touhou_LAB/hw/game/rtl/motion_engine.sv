// OP3: exact SW3 enemy motion and player contact. No rendering or bullet/bullet
// physics. Single job; a bus fault drains the accepted transaction and fails
// closed. Software must never repeat a partially updated job on the CPU.
module motion_engine(
 input wire clk,resetn,start,input wire [31:0] job_address,
 input wire epoch_check,input wire [31:0] expected_epoch,
 output reg busy,done,error,output reg [31:0] cycles,
 output wire [31:0] read_bytes,write_bytes,
 output wire [31:0] m_awaddr,output wire [7:0] m_awlen,output wire m_awvalid,input wire m_awready,
 output wire [127:0] m_wdata,output wire [15:0] m_wstrb,output wire m_wlast,m_wvalid,input wire m_wready,
 input wire [1:0] m_bresp,input wire m_bvalid,output wire m_bready,
 output wire [31:0] m_araddr,output wire [7:0] m_arlen,output wire m_arvalid,input wire m_arready,
 input wire [127:0] m_rdata,input wire [1:0] m_rresp,input wire m_rlast,m_rvalid,output wire m_rready
);
 localparam IDLE=0,BOOT=1,JOB_READ=2,JOB_GOT=3,HEADER=4,RANGES=5,LUT_READ=6,LUT_GOT=7,
  LUT_LOOKUP=8,LUT_CHECK=9,BEGIN_MOTION=10,FETCH=11,GOT=12,ARITH=13,TURN_LOOKUP=14,TURN_DONE=15,
  PARTIAL_INIT=16,CACHE_LOOKUP=17,DIVIDE=18,PARTIAL_MULT=19,PARTIAL_QPROD=20,PARTIAL_CORRECT=21,
  MOVE=22,CONTACT=23,STORE=24,STORED=25,TAIL_GOT=26,TAIL_STORED=27,FLUSH=28,COUNTS=29,
  COMPLETE_PACK=30,COMPLETE_WRITE=31,FINISH=32,FAIL=33,WAIT_MEM=34,WAIT_ROM=35;
 reg [5:0] state,return_state,rom_return;
 reg enforce_epoch;reg [31:0] accepted_epoch;
 reg [31:0] job_base;
 // The128-byte Job still consumes all8 DMA beats. Its upper480 reserved bits
 // only participate in a zero test, so retain their OR instead of480 flops.
 // Real fields are completely refilled before HEADER; no invalid payload is
 // read by a fetch/store command while BOOT/JOB_READ is filling them.
 reg [543:0] job;reg job_reserved_nonzero;
 reg [31:0] completion_cycles,completion_read,completion_write,completion_stall;
 reg [127:0] completion_data;
 wire [31:0] j_magic=job[0+:32],j_abi=job[32+:32],j_epoch=job[64+:32],j_count=job[96+:32],j_capacity=job[128+:32];
 wire [31:0] j_shots=job[160+:32],j_effects=job[192+:32],j_owners=job[224+:32],j_index=job[256+:32];
 wire [31:0] j_counts=job[288+:32],j_lut=job[320+:32],j_result=job[352+:32],j_size=job[384+:32],j_age_max=job[416+:32];
 wire signed [31:0] j_px=job[448+:32],j_py=job[480+:32];
 wire [31:0] j_flags=job[512+:32];
 reg [3:0] job_beat,range_i,range_k,completion_beat,count_word;
 reg [7:0] lut_word;reg [1:0] lut_pair;reg [127:0] lut_data;
 reg [14:0] i,n;reg [2:0] lo,hi;reg [31:0] lower,span,nl,nh;
 reg [31:0] hit_count,graze_count,processed,removed,delay_steps,partial_steps,complete_steps;
 reg [31:0] cache_hits,cache_misses,divider_cycles,status;
 reg [127:0] shot;reg [95:0] effect;reg [7:0] owner;
 reg signed [31:0] vx,vy,x,y;reg [15:0] age,turn,delay,factor;
 reg [11:0] effect_dirty;reg outside;
 reg [31:0] numerator_x,numerator_y,reciprocal;
 reg negative_x,negative_y;
 reg [63:0] product_x,product_y;reg [31:0] quotient_x,quotient_y;
 reg [47:0] qprod_x,qprod_y;
 reg [255:0] cache_d;reg [511:0] cache_m;reg [15:0] cache_valid;reg [3:0] replacement;
 reg [32:0] div_n;reg [16:0] div_rem;reg [31:0] div_q;reg [5:0] div_bit;
 wire [16:0] div_trial={div_rem[15:0],div_n[32]};
 wire div_take=div_trial>={1'b0,turn};
 wire [31:0] div_next_q={div_q[30:0],div_take};
 reg cache_found;reg [3:0] cache_slot;

 // Fixed per-slot writes avoid a wide variable-position packed-vector write.
 // Payload has no reset: cache_valid is reset and only becomes1 on the same
 // edge that the complete denominator/reciprocal pair is committed.
 genvar denominator_slot;
 generate for(denominator_slot=0;denominator_slot<16;denominator_slot=denominator_slot+1)begin:denominator_payload
  always @(posedge clk)if(resetn&&state==DIVIDE&&div_bit==32&&replacement==denominator_slot)begin
   cache_d[denominator_slot*16+:16]<=turn;
   cache_m[denominator_slot*32+:32]<=div_next_q;
  end
 end endgenerate
 function automatic [31:0] cached_reciprocal(input [3:0] slot);
  begin case(slot)
   4'd0:cached_reciprocal=cache_m[0+:32];
   4'd1:cached_reciprocal=cache_m[32+:32];
   4'd2:cached_reciprocal=cache_m[64+:32];
   4'd3:cached_reciprocal=cache_m[96+:32];
   4'd4:cached_reciprocal=cache_m[128+:32];
   4'd5:cached_reciprocal=cache_m[160+:32];
   4'd6:cached_reciprocal=cache_m[192+:32];
   4'd7:cached_reciprocal=cache_m[224+:32];
   4'd8:cached_reciprocal=cache_m[256+:32];
   4'd9:cached_reciprocal=cache_m[288+:32];
   4'd10:cached_reciprocal=cache_m[320+:32];
   4'd11:cached_reciprocal=cache_m[352+:32];
   4'd12:cached_reciprocal=cache_m[384+:32];
   4'd13:cached_reciprocal=cache_m[416+:32];
   4'd14:cached_reciprocal=cache_m[448+:32];
   4'd15:cached_reciprocal=cache_m[480+:32];
  endcase end
 endfunction
 integer z;
 always @*begin cache_found=0;cache_slot=0;for(integer k=0;k<16;k=k+1)if(cache_valid[k]&&cache_d[k*16+:16]==turn&&!cache_found)begin cache_found=1;cache_slot=k;end end
 reg mem_invalidate,mem_fetch,mem_tail,mem_store,mem_flush,mem_raw,mem_raw_write;
 reg [14:0] mem_fetch_index;reg [31:0] mem_address;reg [127:0] mem_data;reg [15:0] mem_strobe;
 reg [127:0] store_shot;reg [95:0] store_effect;reg [7:0] store_owner;
 reg [11:0] store_effect_dirty;reg store_owner_dirty;
 wire [127:0] record_shot,raw_result;wire [95:0] record_effect;wire [7:0] record_owner;
 wire mem_ack,mem_busy,mem_error;wire [31:0] mem_stall;
 motion_cache_dma cache(.clk(clk),.resetn(resetn),.invalidate(mem_invalidate),
  .shots_base(j_shots),.effects_base(j_effects),.owners_base(j_owners),
  .fetch(mem_fetch),.fetch_tail(mem_tail),.fetch_index(mem_fetch_index),.record_shot(record_shot),.record_effect(record_effect),.record_owner(record_owner),
  .store(mem_store),.store_index(i),.store_shot(store_shot),.store_effect(store_effect),.store_owner(store_owner),
  .store_shot_dirty(1'b1),.store_effect_dirty(store_effect_dirty),.store_owner_dirty(store_owner_dirty),.flush(mem_flush),
  .raw(mem_raw),.raw_write(mem_raw_write),.raw_address(mem_address),.raw_data(mem_data),.raw_strobe(mem_strobe),.raw_result(raw_result),
  .ack(mem_ack),.busy(mem_busy),.error(mem_error),.read_bytes(read_bytes),.write_bytes(write_bytes),.stall_cycles(mem_stall),
  .m_awaddr(m_awaddr),.m_awlen(m_awlen),.m_awvalid(m_awvalid),.m_awready(m_awready),.m_wdata(m_wdata),.m_wstrb(m_wstrb),.m_wlast(m_wlast),.m_wvalid(m_wvalid),.m_wready(m_wready),
  .m_bresp(m_bresp),.m_bvalid(m_bvalid),.m_bready(m_bready),.m_araddr(m_araddr),.m_arlen(m_arlen),.m_arvalid(m_arvalid),.m_arready(m_arready),.m_rdata(m_rdata),.m_rresp(m_rresp),.m_rlast(m_rlast),.m_rvalid(m_rvalid),.m_rready(m_rready));
 reg rom_start;reg [9:0] rom_index;wire rom_busy,rom_done;wire signed [15:0] rom_sin,rom_cos;
 motion_trig_rom trig(.clk(clk),.resetn(resetn),.start(rom_start),.index(rom_index),.busy(rom_busy),.done(rom_done),.sin_value(rom_sin),.cos_value(rom_cos));
 function automatic [31:0] region_start(input [3:0] a);
  begin case(a)0:region_start=job_base;1:region_start=j_shots;2:region_start=j_effects;3:region_start=j_owners;4:region_start=j_index;5:region_start=j_counts;6:region_start=j_lut;default:region_start=j_result;endcase end
 endfunction
 function automatic [31:0] region_bytes(input [3:0] a);
  begin case(a)0:region_bytes=128;1:region_bytes=320000;2:region_bytes=240000;3:region_bytes=20000;4:region_bytes=65536;5:region_bytes=32;6:region_bytes=4096;default:region_bytes=128;endcase end
 endfunction
 wire [32:0] current_end={1'b0,region_start(range_i)}+{1'b0,region_bytes(range_i)};
 wire [32:0] previous_end={1'b0,region_start(range_k)}+{1'b0,region_bytes(range_k)};
 function automatic [2:0] bucket(input signed [31:0] p);
  begin if(p<86)bucket=0;else if(p<172)bucket=1;else if(p<258)bucket=2;else if(p<344)bucket=3;else if(p<430)bucket=4;else if(p<516)bucket=5;else if(p<602)bucket=6;else bucket=7;end
 endfunction
 function automatic signed [31:0] delay_scale(input signed [15:0] v);
  reg signed [31:0] d;reg [31:0] a;reg [47:0] p;
  begin d=$signed(v)*32'sd2;a=d<0?-d:d;p=a*16'd52429;delay_scale=d<0?-$signed(p>>18):$signed(p>>18);end
 endfunction
 function automatic signed [31:0] scale_complete(input signed [15:0] v,input signed [15:0] speed);
  reg signed [31:0] p;reg [31:0] a;
  begin p=v*speed;a=p<0?-p:p;scale_complete=p<0?-$signed(a>>15):$signed(a>>15);end
 endfunction
 task automatic raw_read(input [31:0] address,input [5:0] ret);
  begin mem_raw<=1;mem_raw_write<=0;mem_address<=address;return_state<=ret;state<=WAIT_MEM;end
 endtask
 task automatic raw_write(input [31:0] address,input [127:0] data,input [15:0] strobe,input [5:0] ret);
  begin mem_raw<=1;mem_raw_write<=1;mem_address<=address;mem_data<=data;mem_strobe<=strobe;return_state<=ret;state<=WAIT_MEM;end
 endtask
 task automatic fetch_record(input [14:0] index,input tail,input [5:0] ret);
  begin mem_fetch<=1;mem_tail<=tail;mem_fetch_index<=index;return_state<=ret;state<=WAIT_MEM;end
 endtask
 task automatic store_record(input [127:0] s,input [95:0] e,input [7:0] own,input [11:0] dirty,input own_dirty,input [5:0] ret);
  begin mem_store<=1;store_shot<=s;store_effect<=e;store_owner<=own;store_effect_dirty<=dirty;store_owner_dirty<=own_dirty;return_state<=ret;state<=WAIT_MEM;end
 endtask
 task automatic lookup(input [9:0] index,input [5:0] ret);
  begin rom_index<=index;rom_start<=1;rom_return<=ret;state<=WAIT_ROM;end
 endtask
 wire [31:0] relative_y=$unsigned(y)-lower;
 wire signed [31:0] dx=(x>>>12)-j_px,dy=(y>>>12)-j_py;
 wire [31:0] radius=j_size>>1,graze=(j_size>>1)+9;
 wire final_overflow=nl>4096||nh>4096;
 // The wire packet is locked into mem_data by raw_write before each DMA.
 // Beat order/128-byte ABI and PACK-edge metric snapshot are unchanged.
 always @*begin
  completion_data=0;
  case(completion_beat)
   0:completion_data={32'b0,j_epoch,32'd1,32'h4d4f5431};
   1:completion_data={final_overflow?{17'b0,n}:nl+nh,graze_count,hit_count,{17'b0,n}};
   2:completion_data={delay_steps,removed,processed,final_overflow?32'd1:32'd0};
   3:completion_data={completion_read,completion_cycles,complete_steps,partial_steps};
   4:completion_data={cache_misses,cache_hits,32'd1,completion_write};
   5:completion_data={64'b0,completion_stall,divider_cycles};
   default:completion_data=0;
  endcase
 end
 reg [31:0] count_value;
 always @*begin count_value=0;if(count_word==lo)count_value=nl;else if(lo!=hi&&count_word==hi)count_value=nh;end
 always @(posedge clk)begin
  if(!resetn)begin
   state<=IDLE;return_state<=IDLE;rom_return<=IDLE;busy<=0;done<=0;error<=0;cycles<=0;
   enforce_epoch<=0;accepted_epoch<=0;
   job_reserved_nonzero<=0;completion_cycles<=0;completion_read<=0;completion_write<=0;completion_stall<=0;job_base<=0;job_beat<=0;range_i<=0;range_k<=0;lut_word<=0;lut_pair<=0;lut_data<=0;completion_beat<=0;count_word<=0;
   i<=0;n<=0;lo<=0;hi<=0;lower<=0;span<=0;nl<=0;nh<=0;hit_count<=0;graze_count<=0;processed<=0;removed<=0;delay_steps<=0;partial_steps<=0;complete_steps<=0;
   cache_hits<=0;cache_misses<=0;divider_cycles<=0;status<=0;shot<=0;effect<=0;owner<=0;vx<=0;vy<=0;x<=0;y<=0;age<=0;turn<=0;delay<=0;factor<=0;effect_dirty<=0;outside<=0;
   numerator_x<=0;numerator_y<=0;reciprocal<=0;negative_x<=0;negative_y<=0;product_x<=0;product_y<=0;quotient_x<=0;quotient_y<=0;qprod_x<=0;qprod_y<=0;
   cache_valid<=0;replacement<=0;div_n<=0;div_rem<=0;div_q<=0;div_bit<=0;
   mem_invalidate<=0;mem_fetch<=0;mem_tail<=0;mem_store<=0;mem_flush<=0;mem_raw<=0;mem_raw_write<=0;mem_fetch_index<=0;mem_address<=0;mem_data<=0;mem_strobe<=0;
   store_shot<=0;store_effect<=0;store_owner<=0;store_effect_dirty<=0;store_owner_dirty<=0;rom_start<=0;rom_index<=0;
  end else begin
   done<=0;mem_invalidate<=0;mem_fetch<=0;mem_store<=0;mem_flush<=0;mem_raw<=0;rom_start<=0;
   if(busy)cycles<=cycles+1;
   case(state)
    IDLE:if(start)begin
     busy<=1;error<=0;cycles<=0;job_base<=job_address;enforce_epoch<=epoch_check;accepted_epoch<=expected_epoch;mem_invalidate<=1;job_beat<=0;job_reserved_nonzero<=0;status<=0;
     cache_hits<=0;cache_misses<=0;divider_cycles<=0;state<=BOOT;
    end
    BOOT:if(job_base[3:0]!=0||job_base<4096||{1'b0,job_base}+128>33'h00f00000)begin status<=1;state<=FAIL;end else state<=JOB_READ;
    JOB_READ:raw_read(job_base+job_beat*16,JOB_GOT);
    JOB_GOT:begin
     case(job_beat)
      0:job[0+:128]<=raw_result;1:job[128+:128]<=raw_result;
      2:job[256+:128]<=raw_result;3:job[384+:128]<=raw_result;
      4:begin job[512+:32]<=raw_result[31:0];job_reserved_nonzero<=|raw_result[127:32];end
      default:job_reserved_nonzero<=job_reserved_nonzero||(|raw_result);
     endcase
     if(job_beat==7)state<=HEADER;else begin job_beat<=job_beat+1;state<=JOB_READ;end
    end
    HEADER:begin
     if((enforce_epoch&&j_epoch!=accepted_epoch)||j_magic!=32'h4d4f5431||j_abi!=1||j_epoch==0||j_count>20000||j_capacity!=20000||j_size<8||j_size>56||j_size[2:0]!=0||j_flags!=1||job_reserved_nonzero||j_px < -65536||j_px>65536||j_py < -65536||j_py>65536||j_shots[3:0]!=0||j_effects[1:0]!=0||j_index[0]!=0||j_counts[1:0]!=0||j_lut[3:0]!=0||j_result[3:0]!=0)begin status<=1;state<=FAIL;end
     else begin range_i<=0;range_k<=0;state<=RANGES;end
    end
    RANGES:begin
     if(region_start(range_i)<4096||current_end>33'h00f00000)begin status<=1;state<=FAIL;end
     else if(range_k<range_i)begin
      if({1'b0,region_start(range_i)}<previous_end&&{1'b0,region_start(range_k)}<current_end)begin status<=1;state<=FAIL;end else range_k<=range_k+1;
     end else if(range_i==7)begin lut_word<=0;lut_pair<=0;state<=LUT_READ;end
     else begin range_i<=range_i+1;range_k<=0;end
    end
    LUT_READ:raw_read(j_lut+lut_word*16,LUT_GOT);
    LUT_GOT:begin lut_data<=raw_result;lut_pair<=0;state<=LUT_LOOKUP;end
    LUT_LOOKUP:lookup({lut_word,lut_pair},LUT_CHECK);
    LUT_CHECK:begin
     if(lut_data[lut_pair*32+:32]!={rom_cos,rom_sin})begin status<=2;state<=FAIL;end
     else if(lut_pair!=3)begin lut_pair<=lut_pair+1;state<=LUT_LOOKUP;end
     else if(lut_word!=255)begin lut_word<=lut_word+1;state<=LUT_READ;end else state<=BEGIN_MOTION;
    end
    BEGIN_MOTION:begin
     n<=j_count[14:0];i<=0;lo<=bucket(j_py-$signed(graze));hi<=bucket(j_py+$signed(graze));
     lower<=bucket(j_py-$signed(graze))*32'd352256;span<=(bucket(j_py+$signed(graze))-bucket(j_py-$signed(graze))+1)*32'd352256;
     nl<=0;nh<=0;hit_count<=0;graze_count<=0;processed<=0;removed<=0;delay_steps<=0;partial_steps<=0;complete_steps<=0;state<=FETCH;
    end
    FETCH:if(i>=n)state<=FLUSH;else fetch_record(i,0,GOT);
    GOT:begin
     shot<=record_shot;effect<=record_effect;owner<=record_owner;
     vx<=$signed(record_shot[64+:16]);vy<=$signed(record_shot[80+:16]);age<=record_shot[96+:16];
     turn<=record_effect[64+:16];delay<=record_effect[80+:16];effect_dirty<=0;processed<=processed+1;state<=ARITH;
    end
    ARITH:begin
     if(age<delay)begin vx<=delay_scale(shot[64+:16]);vy<=delay_scale(shot[80+:16]);delay_steps<=delay_steps+1;state<=MOVE;end
     else if(turn!=0)begin
      if(({1'b0,age}-{1'b0,delay})>={1'b0,turn})begin complete_steps<=complete_steps+1;state<=TURN_LOOKUP;end
      else begin partial_steps<=partial_steps+1;factor<=turn-(age-delay);state<=PARTIAL_INIT;end
     end else state<=MOVE;
    end
    TURN_LOOKUP:lookup(effect[32+:16]>>6,TURN_DONE);
    TURN_DONE:begin
     vx<=$signed(scale_complete(rom_cos,effect[48+:16]));vy<=$signed(scale_complete(rom_sin,effect[48+:16]));
     shot[64+:16]<=scale_complete(rom_cos,effect[48+:16]);shot[80+:16]<=scale_complete(rom_sin,effect[48+:16]);
     effect[64+:16]<=0;effect_dirty<=12'h300;state<=MOVE;
    end
    PARTIAL_INIT:begin
     negative_x<=vx<0;negative_y<=vy<0;
     numerator_x<=vx<0?-($signed(vx)*$signed({1'b0,factor})):($signed(vx)*$signed({1'b0,factor}));
     numerator_y<=vy<0?-($signed(vy)*$signed({1'b0,factor})):($signed(vy)*$signed({1'b0,factor}));state<=CACHE_LOOKUP;
    end
    CACHE_LOOKUP:begin
     if(turn==1)state<=MOVE;
     else if(cache_found)begin reciprocal<=cached_reciprocal(cache_slot);cache_hits<=cache_hits+1;state<=PARTIAL_MULT;end
     else begin cache_misses<=cache_misses+1;div_n<=33'h100000000;div_rem<=0;div_q<=0;div_bit<=0;state<=DIVIDE;end
    end
    DIVIDE:begin
     divider_cycles<=divider_cycles+1;div_n<=div_n<<1;div_q<=div_next_q;div_rem<=div_take?div_trial-{1'b0,turn}:div_trial;
     if(div_bit==32)begin
      reciprocal<=div_next_q;cache_valid[replacement]<=1;replacement<=replacement+1;state<=PARTIAL_MULT;
     end else div_bit<=div_bit+1;
    end
    PARTIAL_MULT:begin product_x<={32'b0,numerator_x}*reciprocal;product_y<={32'b0,numerator_y}*reciprocal;state<=PARTIAL_QPROD;end
    PARTIAL_QPROD:begin quotient_x<=product_x[63:32];quotient_y<=product_y[63:32];qprod_x<=product_x[63:32]*turn;qprod_y<=product_y[63:32]*turn;state<=PARTIAL_CORRECT;end
    PARTIAL_CORRECT:begin
     vx<=negative_x?-$signed(quotient_x+((numerator_x-qprod_x)>=turn)):$signed(quotient_x+((numerator_x-qprod_x)>=turn));
     vy<=negative_y?-$signed(quotient_y+((numerator_y-qprod_y)>=turn)):$signed(quotient_y+((numerator_y-qprod_y)>=turn));state<=MOVE;
    end
    MOVE:begin
     x<=$signed(shot[0+:32])+vx;y<=$signed(shot[32+:32])+vy;
     shot[0+:32]<=$signed(shot[0+:32])+vx;shot[32+:32]<=$signed(shot[32+:32])+vy;
     if({16'b0,age}<j_age_max)begin age<=age+1'b1;shot[96+:16]<=age+1'b1;end
     outside<=($signed(shot[0+:32])+vx)<$signed(radius<<12)||($signed(shot[0+:32])+vx)>$signed((1024-radius)<<12)||($signed(shot[32+:32])+vy)<$signed(radius<<12)||($signed(shot[32+:32])+vy)>$signed((688-radius)<<12);state<=CONTACT;
    end
    CONTACT:begin
     if(!outside&&relative_y<span)begin
      if(lo!=hi&&relative_y>=352256)nh<=nh+1;else nl<=nl+1;
      if($unsigned(dy+$signed(graze))<(graze*2+1))begin
       if($unsigned(dx+$signed(radius))<(radius*2+1)&&$unsigned(dy+$signed(radius))<(radius*2+1)&&age>=delay)hit_count<=1;
       if($unsigned(dx+$signed(graze))<(graze*2+1)&&shot[120+:8]==0)begin shot[120+:8]<=1;graze_count<=graze_count+1;end
      end
     end
     state<=STORE;
    end
    STORE:store_record(shot,effect,owner,effect_dirty,0,STORED);
    STORED:if(outside)begin n<=n-1'b1;removed<=removed+1;fetch_record(n-1'b1,1,TAIL_GOT);end else begin i<=i+1'b1;state<=FETCH;end
    TAIL_GOT:store_record(record_shot,record_effect,record_owner,12'hfff,1,TAIL_STORED);
    TAIL_STORED:state<=FETCH;
    FLUSH:begin mem_flush<=1;return_state<=COUNTS;count_word<=0;state<=WAIT_MEM;end
    COUNTS:begin
     if(count_word==8)state<=COMPLETE_PACK;
     else begin raw_write(j_counts+count_word*4,({96'b0,count_value}<<(((j_counts+count_word*4)&15)*8)),16'h000f<<((j_counts+count_word*4)&15),COUNTS);count_word<=count_word+1;end
    end
    COMPLETE_PACK:begin
     // Only these4 metrics can change during completion DMA backpressure.
     // Every other payload field stays stable until the last B/FINISH.
     completion_cycles<=cycles;completion_read<=read_bytes;completion_write<=write_bytes;completion_stall<=mem_stall;
     completion_beat<=0;state<=COMPLETE_WRITE;
    end
    COMPLETE_WRITE:if(completion_beat==8)state<=FINISH;else begin raw_write(j_result+completion_beat*16,completion_data,16'hffff,COMPLETE_WRITE);completion_beat<=completion_beat+1;end
    WAIT_MEM:if(mem_ack)begin if(mem_error)begin status<=3;state<=FAIL;end else state<=return_state;end
    WAIT_ROM:if(rom_done)state<=rom_return;
    FINISH:begin busy<=0;done<=1;error<=0;state<=IDLE;end
    FAIL:begin busy<=0;done<=1;error<=1;state<=IDLE;end
    default:begin status<=5;state<=FAIL;end
   endcase
  end
 end
endmodule
