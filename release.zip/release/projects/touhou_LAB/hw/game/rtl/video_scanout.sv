// 1280x720, 1650x750, positive sync, 74.25 MHz pixel clock = 60.000 Hz.
// Two 1280-pixel line buffers cross clock domains through dual-port RAM.
// A bank is refilled only after its last visible pixel; tags are published
// after the complete line has arrived. Frame swaps retire at vertical blank.
module video_scanout(
 input wire clk,resetn,pixel_clk,pixel_resetn,display_enable,swap_start,
 input wire [31:0] swap_addr,output reg [31:0] front_addr,
 output reg swap_pending,output reg [31:0] frame_count,swap_count,
 output wire [31:0] underflow_count,
 output reg [23:0] rgb,output reg hs,vs,de,
 output wire [31:0] m_araddr,output wire [7:0] m_arlen,
 output wire m_arvalid,input wire m_arready,
 input wire [127:0] m_rdata,input wire [1:0] m_rresp,
 input wire m_rlast,m_rvalid,output wire m_rready
);
(* syn_ramstyle="block_ram" *) reg [127:0] line0[0:319];
(* syn_ramstyle="block_ram" *) reg [127:0] line1[0:319];
// tags={valid,frame epoch,line number}, stable until a later completed DMA.
reg [11:0] tag0,tag1;
reg tag0_toggle,tag1_toggle;
(* async_reg="true" *) reg tag0_event_meta,tag0_event_sync,tag1_event_meta,tag1_event_sync;
reg tag0_seen,tag1_seen;
reg [11:0] tag0_latched,tag1_latched;
// A one-bit epoch eventually wraps during a stalled DMA. A tag must also
// have been published in this pixel frame, never just match a resident tag.
reg tag0_current,tag1_current;
(* async_reg="true" *) reg enable_meta,enable_sync;
reg [10:0] px; reg [9:0] py;
reg frame_toggle,line_toggle;
reg safe_blank;
reg [9:0] requested_line;
reg [31:0] underflow_bin,underflow_gray;
(* async_reg="true" *) reg [31:0] uf_meta,uf_sync;
reg [31:0] uf_bin;
integer j;
always @* begin
 uf_bin[31]=uf_sync[31];
 for(j=30;j>=0;j=j-1)uf_bin[j]=uf_bin[j+1]^uf_sync[j];
end
assign underflow_count=uf_bin;
reg [127:0] pixel_word0,pixel_word1;
reg bank_d;
wire [127:0] pixel_word=bank_d?pixel_word1:pixel_word0;
reg [1:0] lane_d;
reg active_d,valid_d,hs_d,vs_d,line_ok,scan_enabled;
wire tag_ok=py[0] ? (tag1_current && tag1_latched=={1'b1,frame_toggle,py[9:0]}) :
                           (tag0_current && tag0_latched=={1'b1,frame_toggle,py[9:0]});
wire visible=px<1280 && py<720;
always @(posedge pixel_clk) begin
 // RAM read is intentionally outside reset logic, allowing true block RAM.
 if(px<1280)begin pixel_word0<=line0[px[10:2]];pixel_word1<=line1[px[10:2]];end
end
always @(posedge pixel_clk or negedge pixel_resetn) begin
 if(!pixel_resetn) begin
  px<=1649;py<=719;frame_toggle<=0;line_toggle<=0;requested_line<=0;
  tag0_event_meta<=0;tag0_event_sync<=0;tag1_event_meta<=0;tag1_event_sync<=0;
  tag0_seen<=0;tag1_seen<=0;tag0_latched<=0;tag1_latched<=0;safe_blank<=0;
  tag0_current<=0;tag1_current<=0;
  enable_meta<=0;enable_sync<=0;underflow_bin<=0;underflow_gray<=0;
  lane_d<=0;bank_d<=0;active_d<=0;valid_d<=0;hs_d<=0;vs_d<=0;line_ok<=0;
  rgb<=0;hs<=0;vs<=0;de<=0;scan_enabled<=0;
 end else begin
  // Bundled data handshake: latch the tag only after its single-bit publication
  // event has crossed two flops. The source holds data until the next full line.
  tag0_event_meta<=tag0_toggle;tag0_event_sync<=tag0_event_meta;
  tag1_event_meta<=tag1_toggle;tag1_event_sync<=tag1_event_meta;
  if(tag0_event_sync!=tag0_seen)begin
   tag0_latched<=tag0;tag0_seen<=tag0_event_sync;tag0_current<=1;
  end
  if(tag1_event_sync!=tag1_seen)begin
   tag1_latched<=tag1;tag1_seen<=tag1_event_sync;tag1_current<=1;
  end
  safe_blank<=(py>=720 && py<749);
  enable_meta<=display_enable;enable_sync<=enable_meta;
  if(px==1649) begin px<=0;if(py==749)py<=0;else py<=py+1'b1;end
  else px<=px+1'b1;
  if(px==0 && py==720)begin
   frame_toggle<=~frame_toggle;scan_enabled<=enable_sync;
   // Local validity clears take priority over a coincident old publication.
   // Fresh priming cannot publish until this frame event reaches the core.
   tag0_current<=0;tag1_current<=0;
  end
  if(px==1280 && py<718) begin requested_line<=py[9:0]+2;line_toggle<=~line_toggle;end
  if(px==0 && py<720) begin
   line_ok<=tag_ok && scan_enabled;
   if(scan_enabled && !tag_ok) begin
    underflow_bin<=underflow_bin+1'b1;
    underflow_gray<=((underflow_bin+1'b1)>>1)^(underflow_bin+1'b1);
   end
  end
  lane_d<=px[1:0];bank_d<=py[0];active_d<=visible;
  valid_d<=scan_enabled && ((px==0)?tag_ok:line_ok);
  hs_d<=(px>=1390 && px<1430);vs_d<=(py>=725 && py<730);
  de<=active_d;hs<=hs_d;vs<=vs_d;
  if(!active_d || !scan_enabled)rgb<=0;
  else if(!valid_d)rgb<=24'hff00ff;
  else case(lane_d)
   0:rgb<=pixel_word[23:0];1:rgb<=pixel_word[55:32];
   2:rgb<=pixel_word[87:64];3:rgb<=pixel_word[119:96];
  endcase
 end
end
(* async_reg="true" *) reg frame_meta,frame_sync,line_meta,line_sync;
(* async_reg="true" *) reg blank_meta,blank_sync;
reg frame_seen,line_seen,frame_wait,epoch;
reg line_queued;reg [9:0] queued_line,next_line;
reg [1:0] prime;
reg [31:0] queued_base,line_address;
reg [9:0] dma_line;
reg dma_epoch,line_bad;
reg [8:0] beat_index;
reg [1:0] state;
localparam IDLE=0, AR=1, READ=2, PUBLISH=3;
assign m_araddr=line_address+{19'b0,beat_index,4'b0};
assign m_arlen=8'd63;
assign m_arvalid=resetn && state==AR;
assign m_rready=resetn && state==READ;
// Each 256-byte request is 256-byte aligned; no burst crosses 4 KiB.
wire frame_event=frame_sync!=frame_seen;
always @(posedge clk) begin
 if(state==READ && m_rvalid && m_rready) begin
  if(dma_line[0])line1[beat_index]<=m_rdata;
  else line0[beat_index]<=m_rdata;
 end
end
always @(posedge clk or negedge resetn) begin
 if(!resetn) begin
  frame_meta<=0;frame_sync<=0;line_meta<=0;line_sync<=0;blank_meta<=0;blank_sync<=0;
  frame_seen<=0;line_seen<=0;frame_wait<=0;epoch<=0;
  uf_meta<=0;uf_sync<=0;tag0<=0;tag1<=0;tag0_toggle<=0;tag1_toggle<=0;
  front_addr<=32'h01000000;queued_base<=32'h01000000;
  swap_pending<=0;frame_count<=0;swap_count<=0;
  line_queued<=0;queued_line<=0;next_line<=2;prime<=0;state<=IDLE;
  line_address<=0;dma_line<=0;dma_epoch<=0;line_bad<=0;beat_index<=0;
 end else begin
  frame_meta<=frame_toggle;frame_sync<=frame_meta;
  // Reserve the final blanking line as a CDC guard. If a read stalls past
  // this safe window, defer its frame swap until the next vertical blank.
  blank_meta<=safe_blank;blank_sync<=blank_meta;
  line_meta<=line_toggle;line_sync<=line_meta;uf_meta<=underflow_gray;uf_sync<=uf_meta;
  if(swap_start && !swap_pending)begin queued_base<=swap_addr;swap_pending<=1;end
  if(frame_event)begin frame_seen<=frame_sync;frame_wait<=1;frame_count<=frame_count+1'b1;end
  if(line_sync!=line_seen)begin
   line_seen<=line_sync;
   if(display_enable)begin queued_line<=requested_line;line_queued<=1;end
  end
  case(state)
   IDLE:begin
    if(frame_wait || frame_event)begin
     if(blank_sync)begin
     // No outstanding read exists here; old frame memory may be reused only
     // after this acknowledgement. Old line-buffer tags are epoch mismatches.
     frame_wait<=0;epoch<=frame_sync;line_queued<=0;next_line<=2;
     if(swap_pending)begin front_addr<=queued_base;swap_pending<=0;swap_count<=swap_count+1'b1;end
     prime<=display_enable?2:0;
     end
    end else if(display_enable && (prime!=0 || (line_queued && next_line<=queued_line)))begin
     dma_epoch<=epoch;line_bad<=0;beat_index<=0;state<=AR;
     if(prime!=0)begin
      dma_line<=(prime==2)?0:1;
      line_address<=front_addr+((prime==2)?0:5120);
      prime<=prime-1'b1;
     end else begin
      dma_line<=next_line;
      line_address<=front_addr+({22'b0,next_line}<<12)+({22'b0,next_line}<<10);
      next_line<=next_line+1'b1;
     end
    end
   end
   AR:if(m_arready)state<=READ;
   READ:if(m_rvalid)begin
    if(m_rresp!=0 || m_rlast!=(beat_index[5:0]==63))line_bad<=1;
    if(m_rlast && beat_index[5:0]!=63)state<=PUBLISH;
    else if(beat_index==319)state<=PUBLISH;
    else begin beat_index<=beat_index+1'b1;if(beat_index[5:0]==63)state<=AR;end
   end
   PUBLISH:begin
    // A DMA spanning a frame event belongs to the retired frame, even if its
    // one-bit epoch has wrapped. Publish it invalid before acknowledging swap.
    if(dma_line[0])begin tag1<={!line_bad && !frame_wait && !frame_event,dma_epoch,dma_line};tag1_toggle<=~tag1_toggle;end
    else begin tag0<={!line_bad && !frame_wait && !frame_event,dma_epoch,dma_line};tag0_toggle<=~tag0_toggle;end
    state<=IDLE;
   end
  endcase
 end
end
endmodule
