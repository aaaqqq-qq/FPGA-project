// Exact frozen SW3 trig. A single synchronous read port intentionally
// time-multiplexes sin and cos so a16-bit ROM need not become two DPRAM10s.
module motion_trig_rom(input wire clk,resetn,start,input wire [9:0] index,
 output reg busy,done,output reg signed [15:0] sin_value,cos_value);
 localparam [4111:0] VALUES=4112'h7fff7ffe7ffd7ff97ff57ff07fe97fe17fd87fcd7fc17fb47fa67f977f867f747f617f4d7f377f217f097eef7ed57eb97e9c7e7e7e5f7e3e7e1d7dfa7dd57db07d897d627d397d0e7ce37cb67c887c597c297bf87bc57b917b5c7b267aee7ab67a7c7a417a0579c87989794a790978c77884783f77fa77b3776b772276d8768d764175f375a57555750474b2745f740a73b5735e730772ae725471f9719d714070e2708370226fc16f5e6efb6e966e306dc96d616cf86c8e6c236bb76b4a6adc6a6d69fd698b691968a6683267bc674666cf665665dd656364e8646c63ee637062f1627161f0616e60eb60685fe35f5d5ed75e4f5dc75d3e5cb35c285b9c5b0f5a8259f3596458d3584257b0571d568a55f5556054c95432539b5302526851ce513350974ffb4f5d4ebf4e204d814ce04c3f4b9d4afb4a5849b4490f486947c3471c467545cd4524447a43d04325427a41ce412140733fc53f173e683db83d073c563ba53af23a40398c38d93824376f36ba3604354d349633df3326326e31b530fb30412f872ecc2e112d552c992bdc2b1f2a6129a328e52826276726a825e82528246723a622e522232161209f1fdd1f1a1e571d931ccf1c0b1b471a8219be18f91833176e16a815e2151c1455138f12c81201113a10720fab0ee30e1c0d540c8c0bc40afb0a33096a08a207d907110648057f04b603ed0324025b019200c90000;
 (* syn_ramstyle="block_ram" *) reg [15:0] quarter[0:256];
 reg [8:0] address;reg [15:0] q;reg [9:0] cos_index;
 reg sin_negative,cos_negative;reg [2:0] state;
 integer k;
 initial for(k=0;k<257;k=k+1)quarter[k]=VALUES[k*16+:16];
 function automatic [8:0] folded_address(input [9:0] x);
 begin folded_address=x[8]?9'd256-{1'b0,x[7:0]}:{1'b0,x[7:0]};end endfunction
 always @(posedge clk)q<=quarter[address];
 always @(posedge clk)begin
  if(!resetn)begin state<=0;address<=0;busy<=0;done<=0;cos_index<=0;sin_negative<=0;cos_negative<=0;sin_value<=0;cos_value<=0;end
  else begin
   done<=0;
   case(state)
    0:if(start)begin address<=folded_address(index);cos_index<=index+10'd256;sin_negative<=index[9];busy<=1;state<=1;end
    1:state<=2;
    2:begin sin_value<=sin_negative?-$signed(q):$signed(q);address<=folded_address(cos_index);cos_negative<=cos_index[9];state<=3;end
    3:state<=4;
    4:begin cos_value<=cos_negative?-$signed(q):$signed(q);busy<=0;done<=1;state<=0;end
    default:begin state<=0;busy<=0;end
   endcase
  end
 end
endmodule
