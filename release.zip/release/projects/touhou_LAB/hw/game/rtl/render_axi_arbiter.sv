// Two private render/motion clients, one AXI ID. Ownership is a transaction
// property, never a live opcode or engine selection. No buffer RAM is added.
module render_axi_arbiter(
 input wire clk,resetn,
 input wire [63:0] s_awaddr,input wire [15:0] s_awlen,input wire [1:0] s_awvalid,output reg [1:0] s_awready,
 input wire [255:0] s_wdata,input wire [31:0] s_wstrb,input wire [1:0] s_wlast,s_wvalid,output reg [1:0] s_wready,
 output wire [3:0] s_bresp,output reg [1:0] s_bvalid,input wire [1:0] s_bready,
 input wire [63:0] s_araddr,input wire [15:0] s_arlen,input wire [1:0] s_arvalid,output reg [1:0] s_arready,
 output wire [255:0] s_rdata,output wire [3:0] s_rresp,output reg [1:0] s_rlast,s_rvalid,input wire [1:0] s_rready,
 output reg [31:0] m_awaddr,output reg [7:0] m_awlen,output wire m_awvalid,input wire m_awready,
 output wire [127:0] m_wdata,output wire [15:0] m_wstrb,output wire m_wlast,m_wvalid,input wire m_wready,
 input wire [1:0] m_bresp,input wire m_bvalid,output wire m_bready,
 output reg [31:0] m_araddr,output reg [7:0] m_arlen,output wire m_arvalid,input wire m_arready,
 input wire [127:0] m_rdata,input wire [1:0] m_rresp,input wire m_rlast,m_rvalid,output wire m_rready,
 output reg protocol_error
);
 localparam RI=0,RA=1,RD=2,WI=0,WA=1,WD=2,WB=3;
 reg [1:0] rstate,wstate;
 reg r_owner,w_owner,r_prefer,w_prefer;
 reg [8:0] r_left,w_left;
 wire r_pick=s_arvalid[r_prefer]?r_prefer:!r_prefer;
 wire w_pick=s_awvalid[w_prefer]?w_prefer:!w_prefer;
 assign m_arvalid=rstate==RA;
 assign m_awvalid=wstate==WA;
 assign m_rready=rstate==RD&&s_rready[r_owner];
 assign m_wvalid=wstate==WD&&s_wvalid[w_owner];
 assign m_wdata=s_wdata[w_owner*128+:128];
 assign m_wstrb=s_wstrb[w_owner*16+:16];
 assign m_wlast=s_wlast[w_owner];
 assign m_bready=wstate==WB&&s_bready[w_owner];
 assign s_rdata={m_rdata,m_rdata};assign s_rresp={m_rresp,m_rresp};assign s_bresp={m_bresp,m_bresp};
 always @*begin
  s_arready=0;s_rvalid=0;s_rlast=0;s_awready=0;s_wready=0;s_bvalid=0;
  if(rstate==RA)s_arready[r_owner]=m_arready;
  if(rstate==RD)begin s_rvalid[r_owner]=m_rvalid;s_rlast[r_owner]=m_rlast;end
  if(wstate==WA)s_awready[w_owner]=m_awready;
  if(wstate==WD)s_wready[w_owner]=m_wready;
  if(wstate==WB)s_bvalid[w_owner]=m_bvalid;
 end
 always @(posedge clk)begin
  if(!resetn)begin
   rstate<=RI;wstate<=WI;r_owner<=0;w_owner<=0;r_prefer<=0;w_prefer<=0;
   r_left<=0;w_left<=0;m_araddr<=0;m_arlen<=0;m_awaddr<=0;m_awlen<=0;protocol_error<=0;
  end else begin
   protocol_error<=0; // pulse; APB latches only active PIPE-context faults
   case(rstate)
    RI:if(|s_arvalid)begin
     r_owner<=r_pick;m_araddr<=s_araddr[r_pick*32+:32];m_arlen<=s_arlen[r_pick*8+:8];rstate<=RA;
    end
    RA:if(m_arready)begin r_left<={1'b0,m_arlen}+1'b1;rstate<=RD;end
    RD:if(m_rvalid&&m_rready)begin
     if(m_rlast)begin
      if(r_left!=1)protocol_error<=1;
      rstate<=RI;r_prefer<=!r_owner;r_left<=0;
     end else if(r_left>1)r_left<=r_left-1'b1;
     else begin
      // A missing final RLAST must not release ownership. Continue draining
      // the same client until an actual accepted RLAST or whole-platform reset.
      protocol_error<=1;r_left<=0;
     end
    end
    default:begin protocol_error<=1;rstate<=RI;end
   endcase
   case(wstate)
    WI:if(|s_awvalid)begin
     w_owner<=w_pick;m_awaddr<=s_awaddr[w_pick*32+:32];m_awlen<=s_awlen[w_pick*8+:8];wstate<=WA;
    end
    WA:if(m_awready)begin w_left<={1'b0,m_awlen}+1'b1;wstate<=WD;end
    WD:if(m_wvalid&&m_wready)begin
     if(m_wlast!=(w_left==1))protocol_error<=1;
     if(w_left==1)begin w_left<=0;wstate<=WB;end
     else w_left<=w_left-1'b1;
    end
    WB:if(m_bvalid&&m_bready)begin wstate<=WI;w_prefer<=!w_owner;end
    default:begin protocol_error<=1;wstate<=WI;end
   endcase
  end
 end
endmodule
