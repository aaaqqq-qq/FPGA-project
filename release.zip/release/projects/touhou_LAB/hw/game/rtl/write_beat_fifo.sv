`timescale 1ns/1ps
// Four-beat elastic queue: {WLAST, WSTRB[15:0], WDATA[127:0]}.
// There is no empty bypass. VALID depends only on registered occupancy;
// full simultaneous pop/push is permitted. This small queue uses logic RAM.
module write_beat_fifo (
    input wire clk, resetn,
    input wire s_valid,
    output wire s_ready,
    input wire [144:0] s_data,
    output wire m_valid,
    input wire m_ready,
    output wire [144:0] m_data
);
    reg [144:0] storage [0:3];
    reg [1:0] read_pointer, write_pointer;
    reg [2:0] count;
    wire pop = m_valid && m_ready;
    wire push = s_valid && s_ready;
    assign m_valid = resetn && (count != 0);
    assign s_ready = resetn && ((count < 4) || pop);
    assign m_data = storage[read_pointer];

    always @(posedge clk) begin
        if (!resetn) begin
            read_pointer <= 0;
            write_pointer <= 0;
            count <= 0;
        end else begin
            if (push) begin
                storage[write_pointer] <= s_data;
                write_pointer <= write_pointer + 1'b1;
            end
            if (pop) read_pointer <= read_pointer + 1'b1;
            case ({push,pop})
                2'b10: count <= count + 1'b1;
                2'b01: count <= count - 1'b1;
                default: count <= count;
            endcase
        end
    end
endmodule
