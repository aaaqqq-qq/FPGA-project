`timescale 1ns/1ps
// Ordered 8x8 / nearest-neighbor 32x32 sprite batch renderer. DDR background -> 1024x8 BRAM strip
// -> DSP alpha/key composition -> DDR framebuffer. No scanout-only overlay.
// 16-byte descriptors: signed Q20.12 center X/Y, ignored payload word,
// material ID in byte 14. CPU state is fetched directly, then normalized in RAM.
module sprite_batch_engine(
 input wire clk,resetn,start,
 input wire [31:0] src_addr,dst_addr,src_stride,dst_stride,descriptor_addr,texture_addr,
 input wire [15:0] width,height,input wire [14:0] sprite_count,
 input wire [7:0] tile_first,
 input wire [7:0] alpha,input wire [23:0] color_key,input wire alpha_enable,key_enable,batch32_enable,preflight_enable,preflight8_enable,
 output reg snapshot_decided,snapshot_no_draw,snapshot_ready_pulse,
 output reg busy,done,error,output reg [31:0] cycles,read_bytes,write_bytes,
 output reg [31:0] m_awaddr,output reg [7:0] m_awlen,output wire m_awvalid,input wire m_awready,
 output wire [127:0] m_wdata,output wire [15:0] m_wstrb,output wire m_wlast,m_wvalid,input wire m_wready,
 input wire [1:0] m_bresp,input wire m_bvalid,output wire m_bready,
 output reg [31:0] m_araddr,output reg [7:0] m_arlen,output wire m_arvalid,input wire m_arready,
 input wire [127:0] m_rdata,input wire [1:0] m_rresp,input wire m_rlast,m_rvalid,output wire m_rready
);
 localparam IDLE=0,CHECK=1,RPLAN=2,RADDR=3,RDATA=4,DPREF=5,DTEST=6,
            PIXELS=7,DRAIN=8,WPLAN=9,WADDR=10,WPREF=11,WDATA=12,WRESP=13,FINISH=14,PREFLIGHT=15,RD_DRAIN=16;
 reg [4:0] state;
 reg [31:0] bg_strip,dst_strip,src_pitch,dst_pitch,desc_base,tex_base;
 reg [15:0] height_q,strip_y;
 reg [14:0] count_q,di;
 reg [7:0] alpha_q,tile_first_q;reg [23:0] key_q;reg alpha_en,key_en,bad;
 reg [1:0] load_kind;
 reg [31:0] rd_address,wr_address;
 reg [14:0] rd_left,rd_mem;
 reg [8:0] wr_left,wr_mem;
 reg [6:0] rd_count,rd_index,wr_count,wr_index;
 reg [3:0] row;
 reg [15:0] spx,spy;
 reg [3:0] tile;
 reg [4:0] sx,sy;
 reg [5:0] sy_end;
 reg batch32_q,preflight_q;
 reg [1:0] tex_pair_sel0;
 wire [2:0] texture_row=batch32_q?sy[4:2]:sy[2:0];
 // Each bit proves that an eight-pixel 32px chunk contains a non-key texel.
 // Metadata is rebuilt from every texture DMA using this job's exact key.
 // Key-disabled jobs retain all chunks, including their original alpha bytes.
 reg [31:0] tile_chunks[0:15];
 reg [31:0] active_chunks;
 wire [3:0] row_chunks=(!batch32_q||!key_en)?4'hf:active_chunks[texture_row*4+:4];
 wire [3:0] remaining_chunks=row_chunks & (4'hf << sx[4:3]);
 wire chunk_present=!batch32_q||(|remaining_chunks);
 wire [1:0] chosen_chunk=remaining_chunks[0]?2'd0:remaining_chunks[1]?2'd1:remaining_chunks[2]?2'd2:2'd3;
 wire [4:0] issue_sx=batch32_q?{chosen_chunk,3'b0}:sx;
 wire issue_pixel=state==PIXELS && chunk_present;
 wire preflight8_request=(preflight8_enable===1'b1);
 wire [16:0] sprite_side=batch32_q?17'd32:17'd8;
 wire [19:0] sprite_half=batch32_q?20'd16:20'd4;
 (* syn_ramstyle="block_ram" *) reg [127:0] textures_lo[0:127],textures_hi[0:127];
 (* syn_ramstyle="block_ram" *) reg [23:0] descriptors_lo0[0:4095],descriptors_hi0[0:2047];
 (* syn_ramstyle="block_ram" *) reg [23:0] descriptors_lo1[0:4095],descriptors_hi1[0:2047];
 (* syn_ramstyle="block_ram" *) reg [23:0] descriptors_lo2[0:4095],descriptors_hi2[0:2047];
 (* syn_ramstyle="block_ram" *) reg [23:0] descriptors_lo3[0:4095],descriptors_hi3[0:2047];
 (* syn_ramstyle="block_ram" *) reg [31:0] bank0[0:1023],bank1[0:1023],bank2[0:1023],bank3[0:1023],bank4[0:1023],bank5[0:1023],bank6[0:1023],bank7[0:1023];
 (* syn_ramstyle="block_ram" *) reg [89:0] group_masks_lo[0:2047],group_masks_hi[0:1023];
 reg [23:0] desc_lo0,desc_hi0;
 reg [23:0] desc_lo1,desc_hi1;
 reg [23:0] desc_lo2,desc_hi2;
 reg [23:0] desc_lo3,desc_hi3;
 reg desc_select;
 reg [89:0] group_lo,group_hi;reg group_select;
 reg [89:0] group_acc;
 wire [89:0] group_word=group_select?group_hi:group_lo;
 // Four interleaved reads preserve exact original descriptor order.
 // Candidate includes invalid descriptors so errors cannot be skipped.
 wire [23:0] desc_word0=desc_select?desc_hi0:desc_lo0;
 wire [23:0] desc_word1=desc_select?desc_hi1:desc_lo1;
 wire [23:0] desc_word2=desc_select?desc_hi2:desc_lo2;
 wire [23:0] desc_word3=desc_select?desc_hi3:desc_lo3;
 function automatic candidate(input [23:0] d,input [14:0] ix,first,num,input [15:0] strip,h,input [16:0] side);
  reg [16:0] ex,ey;
  begin ex={7'b0,d[9:0]}+side;ey={7'b0,d[19:10]}+side;
   candidate=ix>=first&&ix<num&&(ex>1024||ey>{1'b0,h}||
     ({7'b0,d[19:10]}<{1'b0,strip}+17'd8&&ey>{1'b0,strip}));
  end
 endfunction
 wire [14:0] quad_base={di[14:2],2'b0};
 wire [3:0] candidates={candidate(desc_word3,quad_base+15'd3,di,count_q,strip_y,height_q,sprite_side),candidate(desc_word2,quad_base+15'd2,di,count_q,strip_y,height_q,sprite_side),candidate(desc_word1,quad_base+15'd1,di,count_q,strip_y,height_q,sprite_side),candidate(desc_word0,quad_base,di,count_q,strip_y,height_q,sprite_side)};
 wire candidate_found=|candidates;
 wire [1:0] selected_lane=candidates[0]?2'd0:candidates[1]?2'd1:candidates[2]?2'd2:2'd3;
 wire [14:0] selected_di={di[14:2],selected_lane};
 wire [23:0] desc_word=selected_lane==0?desc_word0:selected_lane==1?desc_word1:selected_lane==2?desc_word2:desc_word3;
reg [255:0] tex_word;
 reg [31:0] bg0,bg1,bg2,bg3;
 wire [15:0] dx={6'b0,desc_word[9:0]},dy={6'b0,desc_word[19:10]};
 wire [19:0] raw_cx=m_rdata[31:12],raw_cy=m_rdata[63:44];
 wire [19:0] raw_x=raw_cx-sprite_half,raw_y=raw_cy-sprite_half;
 wire [8:0] material={1'b0,m_rdata[119:112]}-{1'b0,tile_first_q};
 wire raw_bad=raw_cx<sprite_half || raw_cx>1024-sprite_half || raw_cy<sprite_half || ({1'b0,raw_cy}+{1'b0,sprite_half})>{5'b0,height_q} || material>15;
 wire [19:0] raw_last_y=raw_y+(batch32_q?20'd31:20'd7);
 /* A 32px sprite touches four aligned strips or five unaligned strips.
    Preserve every middle strip as well as the two endpoints. */
 wire [89:0] raw_mask=raw_bad?{90{1'b1}}:
   (((batch32_q?90'hf:90'b1)<<raw_y[9:3])|(90'b1<<raw_last_y[9:3]));
 wire [89:0] merged_mask=rd_mem[2:0]==0?raw_mask:(group_acc|raw_mask);
 wire empty_group=di[2:0]==0&&!group_word[strip_y[9:3]];
 wire [15:0] proposed_di=empty_group?({1'b0,di}+16'd8):candidate_found?({1'b0,selected_di}+16'd1):({1'b0,quad_base}+16'd4);
 wire [14:0] next_di=proposed_di>{1'b0,count_q}?count_q:proposed_di[14:0];
 wire [23:0] normalized=raw_bad?24'hffffff:{material[3:0],raw_y[9:0],raw_x[9:0]};
 wire pipeline_hazard;
 wire [14:0] prefetch_di=(state==DTEST&&!pipeline_hazard)?next_di:di;
 wire [16:0] dx_end={1'b0,dx}+sprite_side,dy_end={1'b0,dy}+sprite_side;
 wire intersects=({1'b0,dy} < {1'b0,strip_y}+17'd8) && (dy_end > {1'b0,strip_y});
 wire [15:0] pixel_x=spx+issue_sx,pixel_y=spy+sy-strip_y;
 wire [9:0] issue_addr={pixel_y[2:0],pixel_x[9:3]};
 wire [11:0] write_read_addr={row,8'b0}+wr_mem+wr_index+((state==WDATA)?12'd1:12'd0);
 reg v0,v1,v2,v3;
 reg [9:0] pending_x0,pending_x1,pending_x2,pending_x3;
 reg [9:0] pending_y0,pending_y1,pending_y2,pending_y3;
 // Keep pipeline occupancy across disjoint sprites. Only overlapping bounds
 // (or an invalid next descriptor) require draining in source order.
 // Every uncommitted issue retains its complete sprite bounds. With four
 // stages, a one-row8px A/B/C chain can still carry A while C follows B;
 // checking only the most recently issued sprite would miss A/C overlap.
 wire overlap0=({1'b0,dx}<{7'b0,pending_x0}+sprite_side)&&(dx_end>{7'b0,pending_x0})&&
                 ({1'b0,dy}<{7'b0,pending_y0}+sprite_side)&&(dy_end>{7'b0,pending_y0});
 wire overlap1=({1'b0,dx}<{7'b0,pending_x1}+sprite_side)&&(dx_end>{7'b0,pending_x1})&&
                 ({1'b0,dy}<{7'b0,pending_y1}+sprite_side)&&(dy_end>{7'b0,pending_y1});
 wire overlap2=({1'b0,dx}<{7'b0,pending_x2}+sprite_side)&&(dx_end>{7'b0,pending_x2})&&
                 ({1'b0,dy}<{7'b0,pending_y2}+sprite_side)&&(dy_end>{7'b0,pending_y2});
 wire overlap3=({1'b0,dx}<{7'b0,pending_x3}+sprite_side)&&(dx_end>{7'b0,pending_x3})&&
                 ({1'b0,dy}<{7'b0,pending_y3}+sprite_side)&&(dy_end>{7'b0,pending_y3});
 assign pipeline_hazard=!empty_group && candidate_found &&
   (((v0||v1||v2||v3)&&(dx_end>1024||dy_end>{1'b0,height_q})) ||
    (v0&&overlap0)||(v1&&overlap1)||(v2&&overlap2)||(v3&&overlap3));
 reg [2:0] rotate0,rotate1,rotate2,rotate3;
 reg [9:0] issue_base0,issue_base1,issue_base2,issue_base3;
 reg read_bad;
 wire loading=state==RDATA && m_rvalid && m_rready && load_kind==2;
 wire bank_re=issue_pixel || state==WPREF || (state==WDATA && m_wready && !m_wlast);
 // Exact abs/sign rounding: p=(fg-bg)*alpha, result=bg +/- round(abs(p)/255).
 // All RGB operands are bytes; valid products are in[-65025,65025].
 function automatic [7:0] rounded_magnitude(input signed [17:0] p);
  reg [17:0] magnitude;reg [16:0] folded;
  begin magnitude=p[17]?(~p+18'd1):p;
   folded={1'b0,magnitude[15:0]}+17'd128;
   folded=folded+(folded>>8);rounded_magnitude=folded[15:8];end
 endfunction
 function automatic [6:0] burst(input [31:0] a,input [14:0] left);
  reg [14:0] n;reg [8:0] boundary;
  begin n=left>64?15'd64:left;boundary=9'd256-{1'b0,a[11:4]};if(n>boundary)n=boundary;burst=n[6:0];end
 endfunction
 wire [63:0] src_end={32'b0,src_addr}+({32'b0,src_stride}*({48'b0,height}-1))+4096;
 wire [63:0] dst_end={32'b0,dst_addr}+({32'b0,dst_stride}*({48'b0,height}-1))+4096;
 assign m_arvalid=resetn && state==RADDR;
 assign m_rready=resetn && (state==RDATA||state==RD_DRAIN);
 assign m_awvalid=resetn && state==WADDR;
 assign m_wvalid=resetn && state==WDATA;
 assign m_bready=resetn && state==WRESP;
 assign m_wdata={bg3,bg2,bg1,bg0};assign m_wstrb=16'hffff;
 assign m_wlast=wr_index==wr_count-1;
 // Eight independent modulo-8 banks: an unaligned group uses either the
 // current word or its successor in each bank. Source-order drain is retained.
 always @(posedge clk)begin
  if(state==RDATA && m_rvalid && m_rready && load_kind==0)begin
   tile_chunks[rd_mem[7:4]][{rd_mem[3:0],1'b0}+:2] <= {
     (m_rdata[119:96]!=key_q)||(m_rdata[87:64]!=key_q),
     (m_rdata[55:32]!=key_q)||(m_rdata[23:0]!=key_q)};
   if(rd_mem[0])textures_hi[rd_mem[7:1]]<=m_rdata;else textures_lo[rd_mem[7:1]]<=m_rdata;
  end
  if(state==RDATA && m_rvalid && m_rready && load_kind==1)begin
   case(rd_mem[1:0])
    2'd0:if(rd_mem[14])descriptors_hi0[rd_mem[12:2]]<=normalized;else descriptors_lo0[rd_mem[13:2]]<=normalized;
    2'd1:if(rd_mem[14])descriptors_hi1[rd_mem[12:2]]<=normalized;else descriptors_lo1[rd_mem[13:2]]<=normalized;
    2'd2:if(rd_mem[14])descriptors_hi2[rd_mem[12:2]]<=normalized;else descriptors_lo2[rd_mem[13:2]]<=normalized;
    2'd3:if(rd_mem[14])descriptors_hi3[rd_mem[12:2]]<=normalized;else descriptors_lo3[rd_mem[13:2]]<=normalized;
   endcase
   group_acc<=merged_mask;
   if(rd_mem[2:0]==7||rd_mem+1==count_q)begin
    if(rd_mem[14])group_masks_hi[rd_mem[12:3]]<=merged_mask;else group_masks_lo[rd_mem[13:3]]<=merged_mask;
   end
  end
  if(state==DPREF || (state==DTEST && di+1<count_q))begin
   desc_lo0<=descriptors_lo0[prefetch_di[13:2]];desc_hi0<=descriptors_hi0[prefetch_di[12:2]];
   desc_lo1<=descriptors_lo1[prefetch_di[13:2]];desc_hi1<=descriptors_hi1[prefetch_di[12:2]];
   desc_lo2<=descriptors_lo2[prefetch_di[13:2]];desc_hi2<=descriptors_hi2[prefetch_di[12:2]];
   desc_lo3<=descriptors_lo3[prefetch_di[13:2]];desc_hi3<=descriptors_hi3[prefetch_di[12:2]];
   desc_select<=prefetch_di[14];
   group_lo<=group_masks_lo[prefetch_di[13:3]];group_hi<=group_masks_hi[prefetch_di[12:3]];group_select<=prefetch_di[14];
  end
  if(state==PIXELS)begin
   tex_word<={textures_hi[{tile,texture_row}],textures_lo[{tile,texture_row}]};
   tex_pair_sel0<=issue_sx[4:3];
  end
  if(!resetn)begin v0<=0;v1<=0;v2<=0;v3<=0;end
  else begin
   v0<=issue_pixel;v1<=v0;v2<=v1;v3<=v2;
  end
  // Invalid metadata may advance even during reset; valid stages still reset0.
  rotate0<=pixel_x[2:0];rotate1<=rotate0;rotate2<=rotate1;rotate3<=rotate2;
  issue_base0<=issue_addr;issue_base1<=issue_base0;issue_base2<=issue_base1;issue_base3<=issue_base2;
  pending_x0<=spx[9:0];pending_y0<=spy[9:0];
  pending_x1<=pending_x0;pending_y1<=pending_y0;
  pending_x2<=pending_x1;pending_y2<=pending_y1;
  pending_x3<=pending_x2;pending_y3<=pending_y2;
 end
 // Shared exact texture rotations; same old two RAM reads/32-bit texels.
 wire [255:0] tex8_r1=rotate0[0]?{tex_word[223:0],tex_word[255:224]}:tex_word;
 wire [255:0] tex8_r2=rotate0[1]?{tex8_r1[191:0],tex8_r1[255:192]}:tex8_r1;
 wire [255:0] tex8_r4=rotate0[2]?{tex8_r2[127:0],tex8_r2[255:128]}:tex8_r2;
 // Same two texture reads. Each32px issue consumes eight pixels/two texels.
 wire [63:0] tex_pair=tex_word[tex_pair_sel0*64+:64];
 wire [63:0] pair_rot=rotate0[2]?{tex_pair[31:0],tex_pair[63:32]}:tex_pair;
 wire payload_copy=!alpha_en||alpha_q==255;
 genvar q;
 generate for(q=0;q<8;q=q+1)begin:blend_lane
  wire [9:0] issue=issue_addr+((q<pixel_x[2:0])?10'd1:10'd0);
  wire [9:0] ra=state==PIXELS?issue:write_read_addr[10:1];
  reg [31:0] bg,payload1,payload2,result3;
  reg keep1,keep2,keep3;
  (* syn_use_dsp="yes" *) reg signed [17:0] product_r,product_g,product_b;
  reg [7:0] quotient_r,quotient_g,quotient_b;
  reg negative_r,negative_g,negative_b;
  // q=4G+u, rotate=4R+v: sourceGroup=(G-R-[u<v]) mod2.
  wire texture_borrow=(q%4)<rotate0[1:0];
  wire texture_group=(q/4)^texture_borrow;
  wire [31:0] fg32=texture_group?pair_rot[63:32]:pair_rot[31:0];
  wire [31:0] fg=batch32_q?fg32:tex8_r4[(q%8)*32+:32];
  wire signed [8:0] delta_r=$signed({1'b0,fg[23:16]})-$signed({1'b0,bg[23:16]});
  wire signed [8:0] delta_g=$signed({1'b0,fg[15:8]})-$signed({1'b0,bg[15:8]});
  wire signed [8:0] delta_b=$signed({1'b0,fg[7:0]})-$signed({1'b0,bg[7:0]});
  wire signed [8:0] positive_alpha=$signed({1'b0,alpha_q});
  wire [7:0] blended_r=negative_r?payload2[23:16]-quotient_r:payload2[23:16]+quotient_r;
  wire [7:0] blended_g=negative_g?payload2[15:8]-quotient_g:payload2[15:8]+quotient_g;
  wire [7:0] blended_b=negative_b?payload2[7:0]-quotient_b:payload2[7:0]+quotient_b;
  wire [9:0] write_issue=issue_base3+((q<rotate3)?10'd1:10'd0);
  wire [9:0] wa=loading?rd_mem[10:1]:write_issue;
  wire we=(loading && rd_mem[0]==(q/4))||(v3&&keep3);
  wire [31:0] wd=loading?m_rdata[(q%4)*32+:32]:result3;
  if(q==0)always @(posedge clk)begin if(we)bank0[wa]<=wd;if(bank_re)bg<=bank0[ra];end
  if(q==1)always @(posedge clk)begin if(we)bank1[wa]<=wd;if(bank_re)bg<=bank1[ra];end
  if(q==2)always @(posedge clk)begin if(we)bank2[wa]<=wd;if(bank_re)bg<=bank2[ra];end
  if(q==3)always @(posedge clk)begin if(we)bank3[wa]<=wd;if(bank_re)bg<=bank3[ra];end
  if(q==4)always @(posedge clk)begin if(we)bank4[wa]<=wd;if(bank_re)bg<=bank4[ra];end
  if(q==5)always @(posedge clk)begin if(we)bank5[wa]<=wd;if(bank_re)bg<=bank5[ra];end
  if(q==6)always @(posedge clk)begin if(we)bank6[wa]<=wd;if(bank_re)bg<=bank6[ra];end
  if(q==7)always @(posedge clk)begin if(we)bank7[wa]<=wd;if(bank_re)bg<=bank7[ra];end
  always @(posedge clk)begin
   // No invalid-cycle CE/reset is needed for payload arithmetic. Only
   // v3&&keep3 commits to a bank. bank_re still holds WDATA under WREADY stalls.
   product_r<=delta_r*positive_alpha;product_g<=delta_g*positive_alpha;product_b<=delta_b*positive_alpha;
   payload1<=payload_copy?fg:bg;
   keep1<=!(key_en&&fg[23:0]==key_q);
   quotient_r<=rounded_magnitude(product_r);quotient_g<=rounded_magnitude(product_g);quotient_b<=rounded_magnitude(product_b);
   negative_r<=product_r[17];negative_g<=product_g[17];negative_b<=product_b[17];
   payload2<=payload1;keep2<=keep1;
   result3<=payload_copy||alpha_q==0?payload2:{8'b0,blended_r,blended_g,blended_b};
   keep3<=keep2;
  end
 end endgenerate
 wire [8:0] output_beat=wr_mem+wr_index;
 wire output_half=output_beat[0];
 always @*begin
  case(output_half)
   1'b0:begin bg0=blend_lane[0].bg;bg1=blend_lane[1].bg;bg2=blend_lane[2].bg;bg3=blend_lane[3].bg;end
   1'b1:begin bg0=blend_lane[4].bg;bg1=blend_lane[5].bg;bg2=blend_lane[6].bg;bg3=blend_lane[7].bg;end
  endcase
 end
 always @(posedge clk)begin
  if(!resetn)begin
   state<=IDLE;busy<=0;done<=0;error<=0;read_bad<=0;cycles<=0;read_bytes<=0;write_bytes<=0;
   snapshot_decided<=0;snapshot_no_draw<=0;snapshot_ready_pulse<=0;preflight_q<=0;
   m_awaddr<=0;m_awlen<=0;m_araddr<=0;m_arlen<=0;
   bg_strip<=0;dst_strip<=0;src_pitch<=0;dst_pitch<=0;desc_base<=0;tex_base<=0;
   height_q<=0;strip_y<=0;count_q<=0;di<=0;batch32_q<=0;alpha_q<=0;tile_first_q<=0;key_q<=0;alpha_en<=0;key_en<=0;bad<=0;
   load_kind<=0;rd_address<=0;wr_address<=0;rd_left<=0;rd_mem<=0;wr_left<=0;wr_mem<=0;
   rd_count<=0;rd_index<=0;wr_count<=0;wr_index<=0;row<=0;spx<=0;spy<=0;tile<=0;sx<=0;sy<=0;sy_end<=0;
  end else begin
   done<=0;snapshot_decided<=0;snapshot_no_draw<=0;snapshot_ready_pulse<=0;if(busy)cycles<=cycles+1;
   case(state)
    IDLE:if(start)begin
     busy<=1;error<=0;cycles<=0;read_bytes<=0;write_bytes<=0;
     bg_strip<=src_addr;dst_strip<=dst_addr;src_pitch<=src_stride;dst_pitch<=dst_stride;
     desc_base<=descriptor_addr;tex_base<=texture_addr;height_q<=height;count_q<=sprite_count;
     alpha_q<=alpha;tile_first_q<=tile_first;key_q<=color_key;alpha_en<=alpha_enable;key_en<=key_enable;batch32_q<=batch32_enable;preflight_q<=preflight_enable||preflight8_request;
     strip_y<=0;row<=0;di<=0;
     bad<=(preflight_enable&&!batch32_enable) || (preflight8_request&&batch32_enable) || width!=1024 || height==0 || height>720 || height[2:0]!=0 || sprite_count>24576 ||
          src_addr[3:0]!=0 || dst_addr[3:0]!=0 || src_stride[3:0]!=0 || dst_stride[3:0]!=0 ||
          src_stride<4096 || dst_stride<4096 || src_end>64'h10000000 || dst_end>64'h10000000 ||
          descriptor_addr[3:0]!=0 || texture_addr[3:0]!=0 ||
          ({32'b0,descriptor_addr}+{49'b0,sprite_count}*16)>64'h10000000 ||
          ({32'b0,texture_addr}+4096)>64'h10000000;
     state<=CHECK;
    end
    CHECK:if(bad)begin error<=1;state<=FINISH;end else begin
     load_kind<=0;rd_address<=tex_base;rd_left<=256;rd_mem<=0;state<=RPLAN;
    end
    RPLAN:begin read_bad<=0;rd_count<=burst(rd_address,rd_left);rd_index<=0;
     m_araddr<=rd_address;m_arlen<=burst(rd_address,rd_left)-1;state<=RADDR;end
    RADDR:if(m_arready)state<=RDATA;
    RDATA:if(m_rvalid)begin
     if(load_kind==1&&raw_bad)bad<=1;
     read_bytes<=read_bytes+16;rd_mem<=rd_mem+1;
     if(m_rresp!=0)read_bad<=1;
     if(m_rlast || rd_index==rd_count-1)begin
      if(read_bad || m_rresp!=0 || m_rlast!=(rd_index==rd_count-1))begin error<=1;state<=m_rlast?FINISH:RD_DRAIN;end
      else begin
      if(rd_left!=rd_count)begin rd_left<=rd_left-rd_count;rd_address<=rd_address+(rd_count<<4);state<=RPLAN;end
      else if(load_kind==0 && count_q!=0)begin
       load_kind<=1;rd_address<=desc_base;rd_left<=count_q;rd_mem<=0;state<=RPLAN;
      end else if(load_kind<2)begin
       state<=PREFLIGHT;
      end else if(row!=7)begin
       row<=row+1;rd_address<=bg_strip+(row+1)*src_pitch;rd_left<=256;state<=RPLAN;
      end else begin di<=0;state<=DPREF;end
     end
     end else rd_index<=rd_index+1;
    end
    // A missing expected final RLAST is not a completed transaction.
    // Preserve ownership and consume a genuinely late tail before DONE_ERROR.
    // If no tail ever arrives BUSY remains asserted for firmware fail-closed timeout.
    RD_DRAIN:if(m_rvalid)begin read_bytes<=read_bytes+16;if(m_rlast)state<=FINISH;end
    // All descriptor reads, including their final RLAST/response checks,
    // complete before this decision. No framebuffer AW can precede it.
    // Pulse a separate non-error result: bus/header faults are never fallback.
    PREFLIGHT:begin
     snapshot_decided<=preflight_q;snapshot_no_draw<=preflight_q&&bad;
     if(preflight_q&&bad)state<=FINISH;
     else begin snapshot_ready_pulse<=!bad;load_kind<=2;rd_address<=bg_strip;rd_left<=256;rd_mem<=0;row<=0;state<=RPLAN;end
    end
    DPREF:if(di==count_q)state<=DRAIN;else state<=DTEST;
    DTEST:begin
     if(di==count_q)state<=DRAIN;
     else if(pipeline_hazard)state<=DTEST;
     else if(empty_group||!candidate_found)di<=next_di;
     else if(dx_end>1024 || dy_end>{1'b0,height_q})begin error<=1;state<=FINISH;end
     else if(intersects)begin
      di<=selected_di;spx<=dx;spy<=dy;tile<=desc_word[23:20];active_chunks<=tile_chunks[desc_word[23:20]];sx<=0;sy<=dy<strip_y?strip_y-dy:0;
      sy_end<=dy_end>{1'b0,strip_y}+17'd8 ? strip_y+8-dy:sprite_side;state<=PIXELS;
     end else begin di<=di+1;state<=DTEST;end
    end
    PIXELS:if(batch32_q && chunk_present && chosen_chunk!=2'd3)sx<={chosen_chunk+2'd1,3'b0};
    else begin
     sx<=0;
     if({1'b0,sy}+1==sy_end)begin di<=di+1;state<=DTEST;end else sy<=sy+1;
    end
    DRAIN:if(!(v0||v1||v2||v3))begin row<=0;wr_address<=dst_strip;wr_left<=256;wr_mem<=0;state<=WPLAN;end
    WPLAN:begin wr_count<=burst(wr_address,{4'b0,wr_left});wr_index<=0;
     m_awaddr<=wr_address;m_awlen<=burst(wr_address,{4'b0,wr_left})-1;state<=WADDR;end
    WADDR:if(m_awready)state<=WPREF;
    WPREF:state<=WDATA;
    WDATA:if(m_wready)begin write_bytes<=write_bytes+16;
     if(m_wlast)state<=WRESP;else wr_index<=wr_index+1;
    end
    WRESP:if(m_bvalid)begin
     if(m_bresp!=0)begin error<=1;state<=FINISH;end
     else if(wr_left!=wr_count)begin
      wr_left<=wr_left-wr_count;wr_mem<=wr_mem+wr_count;wr_address<=wr_address+(wr_count<<4);state<=WPLAN;
     end else if(row!=7)begin
      row<=row+1;wr_left<=256;wr_mem<=0;wr_address<=dst_strip+(row+1)*dst_pitch;state<=WPLAN;
     end else if(strip_y+8>=height_q)state<=FINISH;
     else begin
      strip_y<=strip_y+8;bg_strip<=bg_strip+(src_pitch<<3);dst_strip<=dst_strip+(dst_pitch<<3);
      load_kind<=2;rd_address<=bg_strip+(src_pitch<<3);rd_left<=256;rd_mem<=0;row<=0;state<=RPLAN;
     end
    end
    FINISH:begin busy<=0;done<=1;state<=IDLE;end
    default:begin error<=1;state<=FINISH;end
   endcase
  end
 end
endmodule

