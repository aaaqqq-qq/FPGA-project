module game_fabric(
input wire clk, resetn, pixel_clk, pixel_resetn, cal_done,
input wire [15:0] paddr,
input wire psel,penable,pwrite,
input wire [31:0] pwdata,
output wire [31:0] prdata,
output wire pready,pslverror,
output wire [9:0] tmds_data0,tmds_data1,tmds_data2,tmds_clk,
input wire [31:0] c_awaddr,
output wire [27:0] m_awaddr,
input wire [7:0] c_awid,
output wire [3:0] m_awid,
input wire [7:0] c_awlen,
output wire [7:0] m_awlen,
input wire [2:0] c_awsize,
output wire [2:0] m_awsize,
input wire [1:0] c_awburst,
output wire [1:0] m_awburst,
input wire c_awlock,
output wire m_awlock,
input wire [3:0] c_awcache,
output wire [3:0] m_awcache,
input wire [2:0] c_awprot,
output wire [2:0] m_awprot,
input wire c_awvalid,
output wire m_awvalid,
output wire c_awready,
input wire m_awready,
input wire [127:0] c_wdata,
output wire [127:0] m_wdata,
input wire [15:0] c_wstrb,
output wire [15:0] m_wstrb,
input wire c_wlast,
output wire m_wlast,
input wire c_wvalid,
output wire m_wvalid,
output wire c_wready,
input wire m_wready,
output wire [7:0] c_bid,
input wire [3:0] m_bid,
output wire [1:0] c_bresp,
input wire [1:0] m_bresp,
output wire c_bvalid,
input wire m_bvalid,
input wire c_bready,
output wire m_bready,
input wire [31:0] c_araddr,
output wire [27:0] m_araddr,
input wire [7:0] c_arid,
output wire [3:0] m_arid,
input wire [7:0] c_arlen,
output wire [7:0] m_arlen,
input wire [2:0] c_arsize,
output wire [2:0] m_arsize,
input wire [1:0] c_arburst,
output wire [1:0] m_arburst,
input wire c_arlock,
output wire m_arlock,
input wire [3:0] c_arcache,
output wire [3:0] m_arcache,
input wire [2:0] c_arprot,
output wire [2:0] m_arprot,
input wire c_arvalid,
output wire m_arvalid,
output wire c_arready,
input wire m_arready,
output wire [7:0] c_rid,
input wire [3:0] m_rid,
output wire [127:0] c_rdata,
input wire [127:0] m_rdata,
output wire [1:0] c_rresp,
input wire [1:0] m_rresp,
output wire c_rlast,
input wire m_rlast,
output wire c_rvalid,
input wire m_rvalid,
input wire c_rready,
output wire m_rready
);
wire [31:0] b_awaddr;
wire [7:0] b_awid;
wire [7:0] b_awlen;
wire [2:0] b_awsize;
wire [1:0] b_awburst;
wire b_awlock;
wire [3:0] b_awcache;
wire [2:0] b_awprot;
wire b_awvalid;
wire b_awready;
wire [127:0] b_wdata;
wire [15:0] b_wstrb;
wire b_wlast;
wire b_wvalid;
wire b_wready;
wire [7:0] b_bid;
wire [1:0] b_bresp;
wire b_bvalid;
wire b_bready;
wire [31:0] b_araddr;
wire [7:0] b_arid;
wire [7:0] b_arlen;
wire [2:0] b_arsize;
wire [1:0] b_arburst;
wire b_arlock;
wire [3:0] b_arcache;
wire [2:0] b_arprot;
wire b_arvalid;
wire b_arready;
wire [7:0] b_rid;
wire [127:0] b_rdata;
wire [1:0] b_rresp;
wire b_rlast;
wire b_rvalid;
wire b_rready;
wire [31:0] v_awaddr;
wire [7:0] v_awid;
wire [7:0] v_awlen;
wire [2:0] v_awsize;
wire [1:0] v_awburst;
wire v_awlock;
wire [3:0] v_awcache;
wire [2:0] v_awprot;
wire v_awvalid;
wire v_awready;
wire [127:0] v_wdata;
wire [15:0] v_wstrb;
wire v_wlast;
wire v_wvalid;
wire v_wready;
wire [7:0] v_bid;
wire [1:0] v_bresp;
wire v_bvalid;
wire v_bready;
wire [31:0] v_araddr;
wire [7:0] v_arid;
wire [7:0] v_arlen;
wire [2:0] v_arsize;
wire [1:0] v_arburst;
wire v_arlock;
wire [3:0] v_arcache;
wire [2:0] v_arprot;
wire v_arvalid;
wire v_arready;
wire [7:0] v_rid;
wire [127:0] v_rdata;
wire [1:0] v_rresp;
wire v_rlast;
wire v_rvalid;
wire v_rready;
wire [95:0] s_awaddr;
wire [23:0] s_awid;
wire [23:0] s_awlen;
wire [8:0] s_awsize;
wire [5:0] s_awburst;
wire [2:0] s_awlock;
wire [11:0] s_awcache;
wire [8:0] s_awprot;
wire [2:0] s_awvalid;
wire [2:0] s_awready;
wire [383:0] s_wdata;
wire [47:0] s_wstrb;
wire [2:0] s_wlast;
wire [2:0] s_wvalid;
wire [2:0] s_wready;
wire [23:0] s_bid;
wire [5:0] s_bresp;
wire [2:0] s_bvalid;
wire [2:0] s_bready;
wire [95:0] s_araddr;
wire [23:0] s_arid;
wire [23:0] s_arlen;
wire [8:0] s_arsize;
wire [5:0] s_arburst;
wire [2:0] s_arlock;
wire [11:0] s_arcache;
wire [8:0] s_arprot;
wire [2:0] s_arvalid;
wire [2:0] s_arready;
wire [23:0] s_rid;
wire [383:0] s_rdata;
wire [5:0] s_rresp;
wire [2:0] s_rlast;
wire [2:0] s_rvalid;
wire [2:0] s_rready;
assign s_awaddr={v_awaddr,b_awaddr,c_awaddr};
assign s_awid={v_awid,b_awid,c_awid};
assign s_awlen={v_awlen,b_awlen,c_awlen};
assign s_awsize={v_awsize,b_awsize,c_awsize};
assign s_awburst={v_awburst,b_awburst,c_awburst};
assign s_awlock={v_awlock,b_awlock,c_awlock};
assign s_awcache={v_awcache,b_awcache,c_awcache};
assign s_awprot={v_awprot,b_awprot,c_awprot};
assign s_awvalid={v_awvalid,b_awvalid,c_awvalid};
assign {v_awready,b_awready,c_awready}=s_awready;
assign s_wdata={v_wdata,b_wdata,c_wdata};
assign s_wstrb={v_wstrb,b_wstrb,c_wstrb};
assign s_wlast={v_wlast,b_wlast,c_wlast};
assign s_wvalid={v_wvalid,b_wvalid,c_wvalid};
assign {v_wready,b_wready,c_wready}=s_wready;
assign {v_bid,b_bid,c_bid}=s_bid;
assign {v_bresp,b_bresp,c_bresp}=s_bresp;
assign {v_bvalid,b_bvalid,c_bvalid}=s_bvalid;
assign s_bready={v_bready,b_bready,c_bready};
assign s_araddr={v_araddr,b_araddr,c_araddr};
assign s_arid={v_arid,b_arid,c_arid};
assign s_arlen={v_arlen,b_arlen,c_arlen};
assign s_arsize={v_arsize,b_arsize,c_arsize};
assign s_arburst={v_arburst,b_arburst,c_arburst};
assign s_arlock={v_arlock,b_arlock,c_arlock};
assign s_arcache={v_arcache,b_arcache,c_arcache};
assign s_arprot={v_arprot,b_arprot,c_arprot};
assign s_arvalid={v_arvalid,b_arvalid,c_arvalid};
assign {v_arready,b_arready,c_arready}=s_arready;
assign {v_rid,b_rid,c_rid}=s_rid;
assign {v_rdata,b_rdata,c_rdata}=s_rdata;
assign {v_rresp,b_rresp,c_rresp}=s_rresp;
assign {v_rlast,b_rlast,c_rlast}=s_rlast;
assign {v_rvalid,b_rvalid,c_rvalid}=s_rvalid;
assign s_rready={v_rready,b_rready,c_rready};
assign b_awid=8'b0;
assign b_arid=8'b0;
assign b_awsize=3'd4;
assign b_arsize=3'd4;
assign b_awburst=2'b01;
assign b_arburst=2'b01;
assign b_awlock=1'b0;
assign b_arlock=1'b0;
assign b_awcache=4'b0;
assign b_arcache=4'b0;
assign b_awprot=3'b0;
assign b_arprot=3'b0;
assign v_awid=8'b0;
assign v_arid=8'b0;
assign v_awsize=3'd4;
assign v_arsize=3'd4;
assign v_awburst=2'b01;
assign v_arburst=2'b01;
assign v_awlock=1'b0;
assign v_arlock=1'b0;
assign v_awcache=4'b0;
assign v_arcache=4'b0;
assign v_awprot=3'b0;
assign v_arprot=3'b0;
assign v_awaddr=0;
assign v_awlen=0;
assign v_awvalid=0;
assign v_wdata=0;
assign v_wstrb=0;
assign v_wlast=0;
assign v_wvalid=0;
assign v_bready=0;
axi_shared bus(.clk(clk),.resetn(resetn),
.s_awaddr(s_awaddr),
.m_awaddr(m_awaddr),
.s_awid(s_awid),
.m_awid(m_awid),
.s_awlen(s_awlen),
.m_awlen(m_awlen),
.s_awsize(s_awsize),
.m_awsize(m_awsize),
.s_awburst(s_awburst),
.m_awburst(m_awburst),
.s_awlock(s_awlock),
.m_awlock(m_awlock),
.s_awcache(s_awcache),
.m_awcache(m_awcache),
.s_awprot(s_awprot),
.m_awprot(m_awprot),
.s_awvalid(s_awvalid),
.m_awvalid(m_awvalid),
.s_awready(s_awready),
.m_awready(m_awready),
.s_wdata(s_wdata),
.m_wdata(m_wdata),
.s_wstrb(s_wstrb),
.m_wstrb(m_wstrb),
.s_wlast(s_wlast),
.m_wlast(m_wlast),
.s_wvalid(s_wvalid),
.m_wvalid(m_wvalid),
.s_wready(s_wready),
.m_wready(m_wready),
.s_bid(s_bid),
.m_bid(m_bid),
.s_bresp(s_bresp),
.m_bresp(m_bresp),
.s_bvalid(s_bvalid),
.m_bvalid(m_bvalid),
.s_bready(s_bready),
.m_bready(m_bready),
.s_araddr(s_araddr),
.m_araddr(m_araddr),
.s_arid(s_arid),
.m_arid(m_arid),
.s_arlen(s_arlen),
.m_arlen(m_arlen),
.s_arsize(s_arsize),
.m_arsize(m_arsize),
.s_arburst(s_arburst),
.m_arburst(m_arburst),
.s_arlock(s_arlock),
.m_arlock(m_arlock),
.s_arcache(s_arcache),
.m_arcache(m_arcache),
.s_arprot(s_arprot),
.m_arprot(m_arprot),
.s_arvalid(s_arvalid),
.m_arvalid(m_arvalid),
.s_arready(s_arready),
.m_arready(m_arready),
.s_rid(s_rid),
.m_rid(m_rid),
.s_rdata(s_rdata),
.m_rdata(m_rdata),
.s_rresp(s_rresp),
.m_rresp(m_rresp),
.s_rlast(s_rlast),
.m_rlast(m_rlast),
.s_rvalid(s_rvalid),
.m_rvalid(m_rvalid),
.s_rready(s_rready),
.m_rready(m_rready));
wire [7:0] tile_first;wire [14:0] sprite_count;wire [31:0] texture_addr;
wire start,busy,done,error; wire [1:0] op;
wire [31:0] src_addr,dst_addr,src_stride,dst_stride,fill_color,cycles,read_bytes,write_bytes;
wire [15:0] width,height;wire [7:0] alpha;wire [23:0] color_key;
wire snapshot_decided,snapshot_no_draw,preflight_enable;
wire preflight8_enable,snapshot_ready_pulse,r_pipe_start,m_pipe_start;
wire r_busy,r_done,r_error,m_busy,m_done,m_error,axi_protocol_error;
wire [31:0] m_pipe_job,m_pipe_epoch,r_cycles,r_read_bytes,r_write_bytes,m_cycles,m_read_bytes,m_write_bytes;
wire alpha_enable,key_enable,batch32_enable,display_enable,swap_start,swap_pending;
wire [31:0] swap_addr,front_addr,frame_count,swap_count,underflow_count;
wire [23:0] rgb;wire hs,vs,de;
wire [127:0] e_wdata;wire [15:0] e_wstrb;wire e_wlast,e_wvalid,e_wready;
write_beat_fifo write_queue(.clk(clk),.resetn(resetn),.s_valid(e_wvalid),.s_ready(e_wready),
 .s_data({e_wlast,e_wstrb,e_wdata}),.m_valid(b_wvalid),.m_ready(b_wready),
 .m_data({b_wlast,b_wstrb,b_wdata}));
render_engine blitter(.preflight8_enable(preflight8_enable),.snapshot_ready_pulse(snapshot_ready_pulse),.r_pipe_start(r_pipe_start),.m_pipe_start(m_pipe_start),.m_pipe_job(m_pipe_job),.m_pipe_epoch(m_pipe_epoch),.r_busy(r_busy),.r_done(r_done),.r_error(r_error),.m_busy(m_busy),.m_done(m_done),.m_error(m_error),.axi_protocol_error(axi_protocol_error),.r_cycles(r_cycles),.r_read_bytes(r_read_bytes),.r_write_bytes(r_write_bytes),.m_cycles(m_cycles),.m_read_bytes(m_read_bytes),.m_write_bytes(m_write_bytes),
.preflight_enable(preflight_enable),.snapshot_decided(snapshot_decided),.snapshot_no_draw(snapshot_no_draw),.batch32_enable(batch32_enable),.clk(clk),.resetn(resetn),
.tile_first(tile_first),.sprite_count(sprite_count),.texture_addr(texture_addr),
.start(start),
.busy(busy),
.done(done),
.error(error),
.op(op),
.src_addr(src_addr),
.dst_addr(dst_addr),
.src_stride(src_stride),
.dst_stride(dst_stride),
.fill_color(fill_color),
.cycles(cycles),
.read_bytes(read_bytes),
.write_bytes(write_bytes),
.width(width),
.height(height),
.alpha(alpha),
.color_key(color_key),
.alpha_enable(alpha_enable),
.key_enable(key_enable),
.m_awaddr(b_awaddr),
.m_awlen(b_awlen),
.m_awvalid(b_awvalid),
.m_awready(b_awready),
.m_wdata(e_wdata),
.m_wstrb(e_wstrb),
.m_wlast(e_wlast),
.m_wvalid(e_wvalid),
.m_wready(e_wready),
.m_bresp(b_bresp),
.m_bvalid(b_bvalid),
.m_bready(b_bready),
.m_araddr(b_araddr),
.m_arlen(b_arlen),
.m_arvalid(b_arvalid),
.m_arready(b_arready),
.m_rdata(b_rdata),
.m_rresp(b_rresp),
.m_rlast(b_rlast),
.m_rvalid(b_rvalid),
.m_rready(b_rready));
game_apb registers(.preflight8_enable(preflight8_enable),.snapshot_ready_pulse(snapshot_ready_pulse),.r_pipe_start(r_pipe_start),.m_pipe_start(m_pipe_start),.m_pipe_job(m_pipe_job),.m_pipe_epoch(m_pipe_epoch),.r_busy(r_busy),.r_done(r_done),.r_error(r_error),.m_busy(m_busy),.m_done(m_done),.m_error(m_error),.axi_protocol_error(axi_protocol_error),.r_cycles(r_cycles),.r_read_bytes(r_read_bytes),.r_write_bytes(r_write_bytes),.m_cycles(m_cycles),.m_read_bytes(m_read_bytes),.m_write_bytes(m_write_bytes),
.preflight_enable(preflight_enable),.snapshot_decided(snapshot_decided),.snapshot_no_draw(snapshot_no_draw),.batch32_enable(batch32_enable),.clk(clk),.resetn(resetn),
.paddr(paddr),
.psel(psel),
.penable(penable),
.pwrite(pwrite),
.pwdata(pwdata),
.prdata(prdata),
.pready(pready),
.pslverror(pslverror),
.tile_first(tile_first),.sprite_count(sprite_count),.texture_addr(texture_addr),
.start(start),
.busy(busy),
.done(done),
.error(error),
.op(op),
.src_addr(src_addr),
.dst_addr(dst_addr),
.src_stride(src_stride),
.dst_stride(dst_stride),
.fill_color(fill_color),
.cycles(cycles),
.read_bytes(read_bytes),
.write_bytes(write_bytes),
.width(width),
.height(height),
.alpha(alpha),
.color_key(color_key),
.alpha_enable(alpha_enable),
.key_enable(key_enable),
.display_enable(display_enable),
.swap_start(swap_start),
.swap_addr(swap_addr),
.front_addr(front_addr),
.swap_pending(swap_pending),
.frame_count(frame_count),
.swap_count(swap_count),
.underflow_count(underflow_count),
.cal_done(cal_done));
video_scanout video(.clk(clk),.resetn(resetn),
.pixel_clk(pixel_clk),
.pixel_resetn(pixel_resetn),
.display_enable(display_enable),
.swap_start(swap_start),
.swap_addr(swap_addr),
.front_addr(front_addr),
.swap_pending(swap_pending),
.frame_count(frame_count),
.swap_count(swap_count),
.underflow_count(underflow_count),
.rgb(rgb),
.hs(hs),
.vs(vs),
.de(de),
.m_araddr(v_araddr),
.m_arlen(v_arlen),
.m_arvalid(v_arvalid),
.m_arready(v_arready),
.m_rdata(v_rdata),
.m_rresp(v_rresp),
.m_rlast(v_rlast),
.m_rvalid(v_rvalid),
.m_rready(v_rready));
dvi_encoder hdmi(.pixelclk(pixel_clk),.rstin(!pixel_resetn),.blue_din(rgb[7:0]),
 .green_din(rgb[15:8]),.red_din(rgb[23:16]),.hsync(hs),.vsync(vs),.de(de),
 .tmds_data0(tmds_data0),.tmds_data1(tmds_data1),.tmds_data2(tmds_data2),.tmds_clk(tmds_clk));
endmodule
