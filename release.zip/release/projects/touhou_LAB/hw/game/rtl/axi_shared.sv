module axi_shared(
input wire clk, resetn,
input wire [95:0] s_awaddr,
output wire [27:0] m_awaddr,
input wire [23:0] s_awid,
output wire [3:0] m_awid,
input wire [23:0] s_awlen,
output wire [7:0] m_awlen,
input wire [8:0] s_awsize,
output wire [2:0] m_awsize,
input wire [5:0] s_awburst,
output wire [1:0] m_awburst,
input wire [2:0] s_awlock,
output wire m_awlock,
input wire [11:0] s_awcache,
output wire [3:0] m_awcache,
input wire [8:0] s_awprot,
output wire [2:0] m_awprot,
input wire [2:0] s_awvalid,
output wire m_awvalid,
output wire [2:0] s_awready,
input wire m_awready,
input wire [383:0] s_wdata,
output wire [127:0] m_wdata,
input wire [47:0] s_wstrb,
output wire [15:0] m_wstrb,
input wire [2:0] s_wlast,
output wire m_wlast,
input wire [2:0] s_wvalid,
output wire m_wvalid,
output wire [2:0] s_wready,
input wire m_wready,
output wire [23:0] s_bid,
input wire [3:0] m_bid,
output wire [5:0] s_bresp,
input wire [1:0] m_bresp,
output wire [2:0] s_bvalid,
input wire m_bvalid,
input wire [2:0] s_bready,
output wire m_bready,
input wire [95:0] s_araddr,
output wire [27:0] m_araddr,
input wire [23:0] s_arid,
output wire [3:0] m_arid,
input wire [23:0] s_arlen,
output wire [7:0] m_arlen,
input wire [8:0] s_arsize,
output wire [2:0] m_arsize,
input wire [5:0] s_arburst,
output wire [1:0] m_arburst,
input wire [2:0] s_arlock,
output wire m_arlock,
input wire [11:0] s_arcache,
output wire [3:0] m_arcache,
input wire [8:0] s_arprot,
output wire [2:0] m_arprot,
input wire [2:0] s_arvalid,
output wire m_arvalid,
output wire [2:0] s_arready,
input wire m_arready,
output wire [23:0] s_rid,
input wire [3:0] m_rid,
output wire [383:0] s_rdata,
input wire [127:0] m_rdata,
output wire [5:0] s_rresp,
input wire [1:0] m_rresp,
output wire [2:0] s_rlast,
input wire m_rlast,
output wire [2:0] s_rvalid,
input wire m_rvalid,
input wire [2:0] s_rready,
output wire m_rready
);

// One outstanding read and one outstanding write. Round robin is applied at
// burst boundaries; video cannot monopolize CPU instruction/data traffic.
localparam IDLE=0, ADDR=1, DATA=2, RESP=3;
reg [1:0] ws,rs,wo,ro,wp,rp;
reg [1:0] wc,rc;
reg whave,rhave;
reg [31:0] wa,ra;
reg [7:0] wi,ri,wl,rl;
reg [2:0] wz,rz,wprot,rprot;
reg [1:0] wb,rb;
reg wlock,rlock;
reg [3:0] wcache,rcache;
always @* begin
  wc=wp; whave=0; rc=rp; rhave=0;
  case(wp)
    0: if(s_awvalid[0]) begin wc=0;whave=1;end
       else if(s_awvalid[1]) begin wc=1;whave=1;end
       else if(s_awvalid[2]) begin wc=2;whave=1;end
    1: if(s_awvalid[1]) begin wc=1;whave=1;end
       else if(s_awvalid[2]) begin wc=2;whave=1;end
       else if(s_awvalid[0]) begin wc=0;whave=1;end
    default: if(s_awvalid[2]) begin wc=2;whave=1;end
       else if(s_awvalid[0]) begin wc=0;whave=1;end
       else if(s_awvalid[1]) begin wc=1;whave=1;end
  endcase
  case(rp)
    0: if(s_arvalid[0]) begin rc=0;rhave=1;end
       else if(s_arvalid[1]) begin rc=1;rhave=1;end
       else if(s_arvalid[2]) begin rc=2;rhave=1;end
    1: if(s_arvalid[1]) begin rc=1;rhave=1;end
       else if(s_arvalid[2]) begin rc=2;rhave=1;end
       else if(s_arvalid[0]) begin rc=0;rhave=1;end
    default: if(s_arvalid[2]) begin rc=2;rhave=1;end
       else if(s_arvalid[0]) begin rc=0;rhave=1;end
       else if(s_arvalid[1]) begin rc=1;rhave=1;end
  endcase
end
always @(posedge clk or negedge resetn) begin
  if(!resetn) begin
    ws<=IDLE;rs<=IDLE;wo<=0;ro<=0;wp<=0;rp<=0;
    wa<=0;ra<=0;wi<=0;ri<=0;wl<=0;rl<=0;wz<=0;rz<=0;
    wb<=0;rb<=0;wlock<=0;rlock<=0;wcache<=0;rcache<=0;wprot<=0;rprot<=0;
  end else begin
    case(ws)
      IDLE: if(whave) begin
        wo<=wc; wa<=s_awaddr[wc*32+:32];wi<=s_awid[wc*8+:8];
        wl<=s_awlen[wc*8+:8];wz<=s_awsize[wc*3+:3];wb<=s_awburst[wc*2+:2];
        wlock<=s_awlock[wc];wcache<=s_awcache[wc*4+:4];wprot<=s_awprot[wc*3+:3];ws<=ADDR;
      end
      ADDR: if(m_awready) ws<=DATA;
      DATA: if(m_wvalid && m_wready && m_wlast) ws<=RESP;
      RESP: if(m_bvalid && m_bready) begin ws<=IDLE;wp<=(wo==2)?0:wo+1'b1;end
    endcase
    case(rs)
      IDLE: if(rhave) begin
        ro<=rc;ra<=s_araddr[rc*32+:32];ri<=s_arid[rc*8+:8];
        rl<=s_arlen[rc*8+:8];rz<=s_arsize[rc*3+:3];rb<=s_arburst[rc*2+:2];
        rlock<=s_arlock[rc];rcache<=s_arcache[rc*4+:4];rprot<=s_arprot[rc*3+:3];rs<=ADDR;
      end
      ADDR: if(m_arready) rs<=DATA;
      DATA: if(m_rvalid && m_rready && m_rlast) begin rs<=IDLE;rp<=(ro==2)?0:ro+1'b1;end
    endcase
  end
end
assign m_awaddr=wa[27:0],m_awid=4'b0,m_awlen=wl,m_awsize=wz,m_awburst=wb;
assign m_awlock=wlock,m_awcache=wcache,m_awprot=wprot,m_awvalid=resetn && ws==ADDR;
assign m_wdata=s_wdata[wo*128+:128],m_wstrb=s_wstrb[wo*16+:16];
assign m_wlast=s_wlast[wo],m_wvalid=resetn && ws==DATA && s_wvalid[wo];
assign m_bready=resetn && ws==RESP && s_bready[wo];
assign m_araddr=ra[27:0],m_arid=4'b0,m_arlen=rl,m_arsize=rz,m_arburst=rb;
assign m_arlock=rlock,m_arcache=rcache,m_arprot=rprot,m_arvalid=resetn && rs==ADDR;
assign m_rready=resetn && rs==DATA && s_rready[ro];
genvar n;
generate for(n=0;n<3;n=n+1) begin: clients
  assign s_awready[n]=resetn && ws==IDLE && whave && wc==n;
  assign s_wready[n]=resetn && ws==DATA && wo==n && m_wready;
  assign s_bvalid[n]=resetn && ws==RESP && wo==n && m_bvalid;
  assign s_bid[n*8+:8]=wi; assign s_bresp[n*2+:2]=m_bresp;
  assign s_arready[n]=resetn && rs==IDLE && rhave && rc==n;
  assign s_rvalid[n]=resetn && rs==DATA && ro==n && m_rvalid;
  assign s_rdata[n*128+:128]=m_rdata;assign s_rid[n*8+:8]=ri;
  assign s_rresp[n*2+:2]=m_rresp; assign s_rlast[n]=m_rlast;
end endgenerate
endmodule
