//***************************************************************/
//
// Moudel Name    : ddr3_example_top.v
// Version        : 1.1
// Date Created   : 2023-02-23 10:37:59
// Last Modified  : 2023-02-24 15:27:41
// Abstract       : ---
//
//***************************************************************/
//Modification History
//1.initial
//***************************************************************/
`include "ddr3_controller/ddr3_parameter.vh"

`define Efinity_Debug
`timescale 1ps/1ps
// `define SOFT_JTAG

module ddr3_example_top #
(
parameter                       RANK_RATIO         = 1,       // # of unique CS outputs per rank
parameter                       CK_RATIO           = `CK_RATIO, 
parameter                       ASYN_AXI_CLK       = `ASYN_AXI_CLK, 
parameter                       RANKS              = `RANKS,
parameter                       CK_WIDTH           = `CK_WIDTH,       // # of CK/CK# outputs to memory   
parameter                       CKE_WIDTH          = `CKE_WIDTH,       // # of cke outputs
parameter                       CS_WIDTH           = `CS_WIDTH,       // # of unique CS outputs
parameter                       BANK_WIDTH         = `BANK_WIDTH,       // # of bank bits
parameter                       ROW_WIDTH          = `ROW_WIDTH,       // DRAM address bus width
parameter                       COL_WIDTH          = `COL_WIDTH,      // column address width
parameter                       DM_WIDTH           = `DM_WIDTH,       // # of DM (data mask)
parameter                       DQS_WIDTH          = `DQS_WIDTH,       // # of DQS (strobe)
parameter                       DQ_WIDTH           = `DQ_WIDTH,      // # of DQ (data)
parameter                       ODT_WIDTH          = `ODT_WIDTH,
parameter                       DQ_CNT_WIDTH       = `DQ_CNT_WIDTH,       // = ceil(log2(DQ_WIDTH))
parameter                       DQS_CNT_WIDTH      = `DQS_CNT_WIDTH,       // = ceil(log2(DQS_WIDTH))  
parameter                       DRAM_WIDTH         = `DRAM_WIDTH,       // # of DQ per DQS   
parameter                       DATA_WIDTH         = `DATA_WIDTH,
parameter                       ADDR_WIDTH         = `ADDR_WIDTH,    
parameter                       AXI_ID_WIDTH       = `AXI_ID_WIDTH,
parameter                       AXI_ADDR_WIDTH     = `AXI_ADDR_WIDTH,
parameter                       AXI_DATA_WIDTH     = `AXI_DATA_WIDTH
)
(

   input hdmi_tx_locked, hdmi_tx_slow_clk,
   output [9:0] tmds_data0_o,tmds_data1_o,tmds_data2_o,tmds_clk_o,
   output tmds_data0_TX_OE,tmds_data1_TX_OE,tmds_data2_TX_OE,tmds_clk_TX_OE,
   output tmds_data0_TX_RST,tmds_data1_TX_RST,tmds_data2_TX_RST,tmds_clk_TX_RST,
   // Clock and reset ports
   input                              axi_clk,      
   input                              core_clk,     // CORE CLK @ 100MHz
   input                              sdram_clk,    // SDRAM CK @ 400MHz
   input                              rx_cal_clk,   // SDRAM CK @ 400MHz
   input                              tx_cal_clk,   // SDRAM CK @ 400MHz
   input                              tx_cal_clk_90edge,   // SDRAM CK @ 400MHz
   input                              pll_locked,
   input                              user_pll_locked,
  //  input                              peripheralClk,
   //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
   output  wire                       system_uart_0_io_txd,
   input                              system_uart_0_io_rxd,   
   input  [3:0]                       soc_gpio_IN,
   output [3:0]                       soc_gpio_OUT,
   output [3:0]                       soc_gpio_OE,
    // debug core ports
`ifdef  Efinity_Debug  //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& 
`ifdef SOFT_JTAG
  input                               io_jtag_tms,
  input                               io_jtag_tdi,
  output  wire                        io_jtag_tdo,
  input                               io_jtag_tck,
`else
  input                               jtag_inst1_CAPTURE ,
  input                               jtag_inst1_DRCK    ,
  input                               jtag_inst1_RESET   ,
  input                               jtag_inst1_RUNTEST ,
  input                               jtag_inst1_SEL     ,
  input                               jtag_inst1_SHIFT   ,
  input                               jtag_inst1_TCK     ,
  input                               jtag_inst1_TDI     ,
  input                               jtag_inst1_TMS     ,
  input                               jtag_inst1_UPDATE  ,
  output                              jtag_inst1_TDO     ,
`endif 

`endif  //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
   // PLL status flags  
   output [2:0]                       pll_shift,  
   output [4:0]                       pll_shift_sel,
   output                             pll_shift_ena,  
   // memory interface ports
   output                             ddr_ck_hi,
   output                             ddr_ck_lo,
   output                             ddr_reset_n,
   output [CKE_WIDTH-1:0]             ddr_cke,     
   output [ROW_WIDTH-1:0]             ddr_addr,
   output [BANK_WIDTH-1:0]            ddr_ba,
   output                             ddr_cas_n,

   output [CS_WIDTH*RANK_RATIO-1:0]   ddr_cs_n,
   output                             ddr_ras_n,
   output                             ddr_we_n,
   
   input  [DQS_WIDTH-1:0]             ddr_dqs_in_hi,
   input  [DQS_WIDTH-1:0]             ddr_dqs_in_lo,
   input  [DQ_WIDTH-1:0]              ddr_dq_in_hi,
   input  [DQ_WIDTH-1:0]              ddr_dq_in_lo,
   
   output [DQS_WIDTH-1:0]             ddr_dqs_oe,
   output [DQS_WIDTH-1:0]             ddr_dqs_oe_n,
   output [DQ_WIDTH-1:0]              ddr_dq_oe,  
   output [DQS_WIDTH-1:0]             ddr_dqs_out_hi,
   output [DQS_WIDTH-1:0]             ddr_dqs_out_lo,
   output [DQ_WIDTH-1:0]              ddr_dq_out_hi,
   output [DQ_WIDTH-1:0]              ddr_dq_out_lo,
   output [DM_WIDTH-1:0]              ddr_dm_hi,
   output [DM_WIDTH-1:0]              ddr_dm_lo,
   output [ODT_WIDTH-1:0]             ddr_odt,

   input                              system_spi_0_io_data_0_IN,
   input                              system_spi_0_io_data_1_IN,
   output                             system_spi_0_io_ss,
   output                             system_spi_0_io_sclk_write,
   output                             system_spi_0_io_data_0_OUT,
   output                             system_spi_0_io_data_0_OE,
   output                             system_spi_0_io_data_1_OUT,
   output                             system_spi_0_io_data_1_OE

   );
// SW0..SW3: C4/P14/N14/A3, active low. Never drive a pushbutton pin.
wire [3:0] unused_gpio_oe;
assign soc_gpio_OE = 4'b0000;
(* async_reg = "true", syn_keep = 1 *) reg [3:0] button_meta = 4'hf;
(* async_reg = "true", syn_keep = 1 *) reg [3:0] button_sync = 4'hf;
always @(posedge core_clk) begin
    button_meta <= soc_gpio_IN;
    button_sync <= button_meta;
end



      
//Parameter Define
parameter FREQ = 200;			// default is 100 MHz.  Redefine as needed.
`ifndef SIM
    localparam CNT_INIT = 1.5*FREQ*1000;
`else
    localparam CNT_INIT = 10;
`endif    
  localparam   AIW               = AXI_ID_WIDTH      ;
  localparam   ADW               = AXI_DATA_WIDTH    ;
  localparam   ABN               = AXI_DATA_WIDTH/8   ;
  /////////////////////////////////////////////////////////
  // Wire declarations
  reg  [19:0]                       cnt;    
  wire                              clk;
  wire                              rst;
  wire                              mmcm_locked;
  reg                               aresetn;
  wire                              app_sr_active;
  wire                              app_ref_ack;
  wire                              app_zq_ack;

  wire                              cal_done;

  // Slave Interface Write Address Ports
  wire [AXI_ID_WIDTH-1:0]           s_axi_awid;
  wire [AXI_ADDR_WIDTH-1:0]         s_axi_awaddr;
  wire [7:0]                        s_axi_awlen;
  wire [2:0]                        s_axi_awsize;
  wire [1:0]                        s_axi_awburst;
  wire [0:0]                        s_axi_awlock;
  wire [3:0]                        s_axi_awcache;
  wire [2:0]                        s_axi_awprot;
  wire                              s_axi_awvalid;
  wire                              s_axi_awready;
   // Slave Interface Write Data Ports
  wire [AXI_DATA_WIDTH-1:0]         s_axi_wdata;
  wire [(AXI_DATA_WIDTH/8)-1:0]     s_axi_wstrb;
  wire                              s_axi_wlast;
  wire                              s_axi_wvalid;
  wire                              s_axi_wready;
   // Slave Interface Write Response Ports
  wire                              s_axi_bready;
  wire [AXI_ID_WIDTH-1:0]           s_axi_bid;
  wire [1:0]                        s_axi_bresp;
  wire                              s_axi_bvalid;
   // Slave Interface Read Address Ports
  wire [AXI_ID_WIDTH-1:0]           s_axi_arid;
  wire [AXI_ADDR_WIDTH-1:0]         s_axi_araddr;
  wire [7:0]                        s_axi_arlen;
  wire [2:0]                        s_axi_arsize;
  wire [1:0]                        s_axi_arburst;
  wire [0:0]                        s_axi_arlock;
  wire [3:0]                        s_axi_arcache;
  wire [2:0]                        s_axi_arprot;
  wire                              s_axi_arvalid;
  wire                              s_axi_arready;
   // Slave Interface Read Data Ports
  wire                              s_axi_rready;
  wire [AXI_ID_WIDTH-1:0]           s_axi_rid;
  wire [AXI_DATA_WIDTH-1:0]         s_axi_rdata;
  wire [1:0]                        s_axi_rresp;
  wire                              s_axi_rlast;
  wire                              s_axi_rvalid;


//***************************************************************************
  wire [2:0]                        vio_pll_shift;  
  wire [4:0]                        vio_pll_shift_sel;
  wire                              vio_pll_shift_ena; 
  wire                              pos_pll_shift_ena; 
  wire [2:0]                        phy_pll_shift;  
  wire [4:0]                        phy_pll_shift_sel;
  wire                              phy_pll_shift_ena; 
  wire                              ddr_reset; 
  wire                              sys_rst;
  wire  [2:0]                       phy_wr_pll_shift;
  wire                              idelay_ld       ;
  wire                              mpr_rdlvl_dly   ;
  wire  [7:0]                       wrlvl_dq_check  ;
  wire  [7:0]                       rd_level_dqs_check;  
  wire  [2:0]                       rdlvl_shift;  
  wire  [2:0]                       wrlvl_shift;  
  wire  [15:0]                      debug_fifo;  
  wire  [15:0]                      overflow_fifo;  
  wire  [6:0]                       init_cur_state;  
  wire  [35:0]                      ddr_debug_port;  
  wire                              app_rdy;  
  wire                              user_clk;  
  reg                               ddr_rstn;  
  wire                                phy_rddata_valid;
  wire [2*CK_RATIO*DQ_WIDTH-1:0]      phy_rd_data;
  wire [2*CK_RATIO*DATA_WIDTH-1:0]    app_rd_data_to_axi; 
  wire                                app_rd_data_end;
  wire                                app_rd_data_valid;
  wire [2*CK_RATIO*DQ_WIDTH-1:0]      rd_data;          
  wire                                rd_data_en;            
  wire                                rd_data_end;   
   
  
// Start of User Design top instance
//***************************************************************************
// The User design is instantiated below. The memory interface ports are
// connected to the top-level and the application interface ports are
// connected to the traffic generator module. This provides a reference
// for connecting the memory controller to system.
//***************************************************************************
always @(posedge user_clk or negedge sys_rst) begin
	if (!sys_rst)
		cnt <= 0;
    else if (cnt != CNT_INIT) 
        cnt <= cnt + 20'd1;
	else 
        cnt <= cnt;
end
// Register the startup terminal-count decode before distributing reset.
// Assertion remains asynchronous; release occurs one core clock later.
always @(posedge user_clk or negedge sys_rst) begin
    if (!sys_rst) ddr_rstn <= 1'b0;
    else ddr_rstn <= (cnt == CNT_INIT);
end


generate
if (ASYN_AXI_CLK) begin
assign user_clk = axi_clk;

end else begin
assign user_clk = core_clk;
end
endgenerate
//***************************************************************************
// The traffic generation module instantiated below drives traffic (patterns)
// on the application interface of the memory controller
//***************************************************************************
//***************************************************************************

assign sys_rst       = pll_locked & user_pll_locked;

//***************************************************************************
ddr3_top                 u_ddr3_top
      (
      
    .axi_clk                (user_clk             ),
    .core_clk               (core_clk            ),
    .sdram_clk              (sdram_clk           ),  
    .rx_cal_clk             (rx_cal_clk          ),
    .tx_cal_clk             (tx_cal_clk          ),
    .tx_cal_clk_90edge      (tx_cal_clk_90edge   ),
    .rstn                   (ddr_rstn            ),      
    .pll_shift              (pll_shift           ),
    .pll_shift_sel          (pll_shift_sel       ),
    .pll_shift_ena          (pll_shift_ena       ), 
///////////////DDR BUS
    .ddr_ck_hi              (ddr_ck_hi           ),
    .ddr_ck_lo              (ddr_ck_lo           ),
    .ddr_cke                (ddr_cke             ),    
    .ddr_reset_n            (ddr_reset_n         ),
    .ddr_cs_n               (ddr_cs_n            ),
    .ddr_ras_n              (ddr_ras_n           ),
    .ddr_cas_n              (ddr_cas_n           ),
    .ddr_we_n               (ddr_we_n            ),     
    .ddr_addr               (ddr_addr            ),
    .ddr_ba                 (ddr_ba              ),

    .ddr_dqs_oe             (ddr_dqs_oe          ),
    .ddr_dqs_oe_n           (ddr_dqs_oe_n        ),
    .ddr_dq_oe              (ddr_dq_oe           ),
    .ddr_dqs_in_hi          (ddr_dqs_in_hi       ),
    .ddr_dqs_in_lo          (ddr_dqs_in_lo       ),
    .ddr_dq_in_hi           (ddr_dq_in_hi        ),
    .ddr_dq_in_lo           (ddr_dq_in_lo        ),

    .ddr_dqs_out_hi         (ddr_dqs_out_hi      ),
    .ddr_dqs_out_lo         (ddr_dqs_out_lo      ),
    .ddr_dq_out_hi          (ddr_dq_out_hi       ),
    .ddr_dq_out_lo          (ddr_dq_out_lo       ),
    
    .ddr_dm_hi              (ddr_dm_hi           ),
    .ddr_dm_lo              (ddr_dm_lo           ),
    .ddr_odt                (ddr_odt             ),

// Application interface ports
       .app_sr_req                     (1'b0),
       .app_ref_req                    (1'b0),
       .app_zq_req                     (1'b0),
       .app_sr_active                  (app_sr_active),
       .app_ref_ack                    (app_ref_ack),
       .app_zq_ack                     (app_zq_ack),

// Slave Interface Write Address Ports
       .s_axi_awid                     (s_axi_awid        ),
       .s_axi_awaddr                   (s_axi_awaddr      ),
       .s_axi_awlen                    (s_axi_awlen       ),
       .s_axi_awsize                   (s_axi_awsize      ),
       .s_axi_awburst                  (s_axi_awburst     ),
       .s_axi_awlock                   (s_axi_awlock      ),
       .s_axi_awcache                  (s_axi_awcache     ),
       .s_axi_awprot                   (s_axi_awprot      ),
       .s_axi_awqos                    (4'h0              ),
       .s_axi_awvalid                  (s_axi_awvalid     ),
       .s_axi_awready                  (s_axi_awready     ),
// Slave Interface Write Data Ports
       .s_axi_wdata                    (s_axi_wdata       ),
       .s_axi_wstrb                    (s_axi_wstrb       ),
       .s_axi_wlast                    (s_axi_wlast       ),
       .s_axi_wvalid                   (s_axi_wvalid      ),
       .s_axi_wready                   (s_axi_wready      ),
// Slave Interface Write Response Ports
       .s_axi_bid                      (s_axi_bid         ),
       .s_axi_bresp                    (s_axi_bresp       ),
       .s_axi_bvalid                   (s_axi_bvalid      ),
       .s_axi_bready                   (s_axi_bready      ),
// Slave Interface Read Address Ports
       .s_axi_arid                     (s_axi_arid        ),
       .s_axi_araddr                   (s_axi_araddr      ),
       .s_axi_arlen                    (s_axi_arlen       ),
       .s_axi_arsize                   (s_axi_arsize      ),
       .s_axi_arburst                  (s_axi_arburst     ),
       .s_axi_arlock                   (s_axi_arlock      ),
       .s_axi_arcache                  (s_axi_arcache     ),
       .s_axi_arprot                   (s_axi_arprot      ),
       .s_axi_arqos                    (4'h0              ),
       .s_axi_arvalid                  (s_axi_arvalid     ),
       .s_axi_arready                  (s_axi_arready     ),
// Slave Interface Read Data Ports
       .s_axi_rid                      (s_axi_rid         ),
       .s_axi_rdata                    (s_axi_rdata       ),
       .s_axi_rresp                    (s_axi_rresp       ),
       .s_axi_rlast                    (s_axi_rlast       ),
       .s_axi_rvalid                   (s_axi_rvalid      ),
       .s_axi_rready                   (s_axi_rready      ),
//DEBUG       
       .wrlvl_dq_check                 (wrlvl_dq_check    ) ,
       .rd_level_dqs_check             (rd_level_dqs_check) ,
       .rdlvl_shift                    (rdlvl_shift) ,
       .wrlvl_shift                    (wrlvl_shift) ,
       .init_cur_state                 (init_cur_state    ) ,
       .idelay_ld                      (idelay_ld         ) ,
       .mpr_rdlvl_dly                  (mpr_rdlvl_dly     ) ,
       .ddr_debug_port                 (ddr_debug_port    ) ,
       .cal_done                       (cal_done          ) 
       );
// End of User Design top instance

//***************************************************************************


//***************************************************************************

wire [15:0] apb_paddr;wire [31:0] apb_pwdata,apb_prdata;
wire apb_psel,apb_penable,apb_pwrite,apb_pready,apb_pslverror;
reg [2:0] ready_sync;
always @(posedge user_clk or negedge sys_rst)
  if(!sys_rst) ready_sync<=0; else ready_sync<={ready_sync[1:0],ddr_rstn & cal_done};
wire fabric_resetn=ready_sync[2];
// Loss of PLL lock can stop the pixel clock. Assert without that clock,
// then release only after three good pixel edges once both inputs are ready.
wire pixel_async_resetn=fabric_resetn & hdmi_tx_locked;
(* async_reg="true" *) reg [2:0] pixel_reset_sync;
always @(posedge hdmi_tx_slow_clk or negedge pixel_async_resetn)
  if(!pixel_async_resetn) pixel_reset_sync<=0; else pixel_reset_sync<={pixel_reset_sync[1:0],1'b1};
wire [9:0] td0,td1,td2,tc;
assign {tmds_data0_o,tmds_data1_o,tmds_data2_o,tmds_clk_o}={~td0,~td1,~td2,~tc};
assign {tmds_data0_TX_OE,tmds_data1_TX_OE,tmds_data2_TX_OE,tmds_clk_TX_OE}=4'b1111;
assign {tmds_data0_TX_RST,tmds_data1_TX_RST,tmds_data2_TX_RST,tmds_clk_TX_RST}=4'b0;
wire [31:0] c_awaddr;
wire [7:0] c_awid;
wire [7:0] c_awlen;
wire [2:0] c_awsize;
wire [1:0] c_awburst;
wire c_awlock;
wire [3:0] c_awcache;
wire [2:0] c_awprot;
wire c_awvalid;
wire c_awready;
wire [127:0] c_wdata;
wire [15:0] c_wstrb;
wire c_wlast;
wire c_wvalid;
wire c_wready;
wire [7:0] c_bid;
wire [1:0] c_bresp;
wire c_bvalid;
wire c_bready;
wire [31:0] c_araddr;
wire [7:0] c_arid;
wire [7:0] c_arlen;
wire [2:0] c_arsize;
wire [1:0] c_arburst;
wire c_arlock;
wire [3:0] c_arcache;
wire [2:0] c_arprot;
wire c_arvalid;
wire c_arready;
wire [7:0] c_rid;
wire [127:0] c_rdata;
wire [1:0] c_rresp;
wire c_rlast;
wire c_rvalid;
wire c_rready;
soc u_sapphire_soc(
.axiA_awready(1'b0),
.axiA_arready(1'b0),
.axiAInterrupt(1'b0),
.axiA_rlast(1'b0),
.axiA_wready(1'b0),
.axiA_bvalid(1'b0),
.axiA_bid(1'b0),
.axiA_bresp(1'b0),
.axiA_rvalid(1'b0),
.axiA_rdata(1'b0),
.axiA_rid(1'b0),
.axiA_rresp(1'b0),
.userInterruptA(1'b0),
.system_i2c_0_io_scl_read(1'b1),
.system_i2c_0_io_sda_read(1'b1),
.io_ddrMasters_0_clk(user_clk),
.io_ddrMasters_0_r_ready(1'b0),
.io_ddrMasters_0_ar_payload_prot(1'b0),
.io_ddrMasters_0_ar_payload_qos(1'b0),
.io_ddrMasters_0_ar_payload_cache(1'b0),
.io_ddrMasters_0_ar_payload_lock(1'b0),
.io_ddrMasters_0_ar_payload_burst(1'b0),
.io_ddrMasters_0_ar_payload_size(1'b0),
.io_ddrMasters_0_ar_payload_len(1'b0),
.io_ddrMasters_0_ar_payload_region(1'b0),
.io_ddrMasters_0_ar_payload_id(1'b0),
.io_ddrMasters_0_ar_payload_addr(1'b0),
.io_ddrMasters_0_ar_valid(1'b0),
.io_ddrMasters_0_b_ready(1'b0),
.io_ddrMasters_0_w_payload_last(1'b0),
.io_ddrMasters_0_w_payload_strb(1'b0),
.io_ddrMasters_0_w_payload_data(1'b0),
.io_ddrMasters_0_w_valid(1'b0),
.io_ddrMasters_0_aw_payload_prot(1'b0),
.io_ddrMasters_0_aw_payload_qos(1'b0),
.io_ddrMasters_0_aw_payload_cache(1'b0),
.io_ddrMasters_0_aw_payload_lock(1'b0),
.io_ddrMasters_0_aw_payload_burst(1'b0),
.io_ddrMasters_0_aw_payload_size(1'b0),
.io_ddrMasters_0_aw_payload_len(1'b0),
.io_ddrMasters_0_aw_payload_region(1'b0),
.io_ddrMasters_0_aw_payload_id(1'b0),
.io_ddrMasters_0_aw_payload_addr(1'b0),
.io_ddrMasters_0_aw_valid(1'b0),
    .io_asyncReset                      (!fabric_resetn                     ),
    .io_systemClk                       (user_clk                           ),

    //UART 0
    .system_uart_0_io_txd               (system_uart_0_io_txd               ),
    .system_uart_0_io_rxd               (system_uart_0_io_rxd               ),
    .io_memoryClk                       (user_clk                           ),
    .io_memoryReset                     (                                   ),
    .io_systemReset                     (                                   ),
    //External Memory AXI4 Interface
    .io_ddrA_aw_payload_prot            (c_awprot),//(                                  ),
    .io_ddrA_aw_payload_qos             (                                  ),//(                                  ),
    .io_ddrA_aw_payload_cache           (c_awcache),//(                                  ),
    .io_ddrA_aw_payload_lock            (c_awlock),//(m1_axi_awlock                     ),
    .io_ddrA_aw_payload_burst           (c_awburst),//(m1_axi_awburst                    ),
    .io_ddrA_aw_payload_size            (c_awsize),//(m1_axi_awsize                     ),
    .io_ddrA_aw_payload_len             (c_awlen),//(m1_axi_awlen                      ),
    .io_ddrA_aw_payload_region          (                                 ),//(                                  ),
    .io_ddrA_aw_payload_id              (c_awid),//(m1_axi_awid                       ),
    .io_ddrA_aw_payload_addr            (c_awaddr),//(m1_axi_awaddr                     ),
    .io_ddrA_aw_ready                   (c_awready),//(m1_axi_awready                    ),
    .io_ddrA_aw_valid                   (c_awvalid),//(m1_axi_awvalid                    ),
    .io_ddrA_w_payload_last             (c_wlast),//(m1_axi_wlast                      ),
    .io_ddrA_w_ready                    (c_wready),//(m1_axi_wready                     ),
    .io_ddrA_w_valid                    (c_wvalid),  //(m1_axi_wvalid                     ),    
    .io_ddrA_w_payload_strb             (c_wstrb),//(m1_axi_wstrb                      ),
    .io_ddrA_w_payload_data             (c_wdata),//(m1_axi_wdata                      ),
    .io_ddrA_b_payload_resp             (c_bresp),//(                                  ),
    .io_ddrA_b_payload_id               (c_bid),//(m1_axi_bid                        ),
    .io_ddrA_b_ready                    (c_bready),//(m1_axi_bready                     ),
    .io_ddrA_b_valid                    (c_bvalid),//(m1_axi_bvalid                     ),
    .io_ddrA_ar_payload_prot            (c_arprot),//(                                  ),
    .io_ddrA_ar_payload_qos             (                                 ),//(                                  ),
    .io_ddrA_ar_payload_cache           (c_arcache),//(                                  ),
    .io_ddrA_ar_payload_region          (                                 ),//(                                  ),
    .io_ddrA_ar_payload_lock            (c_arlock),//(m1_axi_arlock                     ),
    .io_ddrA_ar_payload_burst           (c_arburst),//(m1_axi_arburst                    ),
    .io_ddrA_ar_payload_size            (c_arsize),//(m1_axi_arsize                     ),
    .io_ddrA_ar_payload_len             (c_arlen),//(m1_axi_arlen                      ),
    .io_ddrA_ar_payload_id              (c_arid),//(m1_axi_arid                       ),
    .io_ddrA_ar_payload_addr            (c_araddr),//(m1_axi_araddr                     ),
    .io_ddrA_ar_ready                   (c_arready),//(m1_axi_arready                    ),
    .io_ddrA_ar_valid                   (c_arvalid),//(m1_axi_arvalid                    ),
    .io_ddrA_r_payload_last             (c_rlast),//(m1_axi_rlast                      ),
    .io_ddrA_r_payload_resp             (c_rresp),//(m1_axi_rresp                      ),
    .io_ddrA_r_payload_id               (c_rid),//(m1_axi_rid                        ),
    .io_ddrA_r_payload_data             (c_rdata),//(m1_axi_rdata                      ),
    .io_ddrA_r_ready                    (c_rready),//(m1_axi_rready                     ),
    .io_ddrA_r_valid                    (c_rvalid),//(m1_axi_rvalid                     ),
     //SPI 0
    .system_spi_0_io_sclk_write         (system_spi_0_io_sclk_write         ),
    .system_spi_0_io_data_0_writeEnable (system_spi_0_io_data_0_OE ),
    .system_spi_0_io_data_0_read        (system_spi_0_io_data_0_IN        ),
    .system_spi_0_io_data_0_write       (system_spi_0_io_data_0_OUT       ),
    .system_spi_0_io_data_1_writeEnable (system_spi_0_io_data_1_OE ),
    .system_spi_0_io_data_1_read        (system_spi_0_io_data_1_IN        ),
    .system_spi_0_io_data_1_write       (system_spi_0_io_data_1_OUT       ),
    .system_spi_0_io_data_2_writeEnable (                                   ),
    .system_spi_0_io_data_2_read        (1'b0),
    .system_spi_0_io_data_2_write       (                                   ),
    .system_spi_0_io_data_3_writeEnable (                                   ),
    .system_spi_0_io_data_3_read        (1'b0),
    .system_spi_0_io_data_3_write       (                                   ),
    .system_spi_0_io_ss                 (system_spi_0_io_ss                 ),
    //APB 0
    .io_apbSlave_0_PADDR                (apb_paddr                          ),
    .io_apbSlave_0_PSEL                 (apb_psel                           ),
    .io_apbSlave_0_PENABLE              (apb_penable                        ),
    .io_apbSlave_0_PREADY               (apb_pready                         ),
    .io_apbSlave_0_PWRITE               (apb_pwrite                         ),
    .io_apbSlave_0_PWDATA               (apb_pwdata                         ),
    .io_apbSlave_0_PRDATA               (apb_prdata                         ),
    .io_apbSlave_0_PSLVERROR            (apb_pslverror                      ),

    .system_gpio_0_io_write             ( soc_gpio_OUT                      ),//,
    .system_gpio_0_io_read              ( button_sync                       ),//
    .system_gpio_0_io_writeEnable       ( unused_gpio_oe                       ),//, 


    //Hard Jtag Tap
    .jtagCtrl_tck                       (jtag_inst1_TCK                     ),
    .jtagCtrl_tdi                       (jtag_inst1_TDI                     ),
    .jtagCtrl_tdo                       (jtag_inst1_TDO                     ),
    .jtagCtrl_enable                    (jtag_inst1_SEL                     ),
    .jtagCtrl_capture                   (jtag_inst1_CAPTURE                 ),
    .jtagCtrl_shift                     (jtag_inst1_SHIFT                   ),
    .jtagCtrl_update                    (jtag_inst1_UPDATE                  ),
    .jtagCtrl_reset                     (jtag_inst1_RESET                   )

);


game_fabric game(.clk(user_clk),.resetn(fabric_resetn),
 .pixel_clk(hdmi_tx_slow_clk),.pixel_resetn(pixel_reset_sync[2]),.cal_done(cal_done),
 .paddr(apb_paddr),.psel(apb_psel),.penable(apb_penable),.pwrite(apb_pwrite),
 .pwdata(apb_pwdata),.prdata(apb_prdata),.pready(apb_pready),.pslverror(apb_pslverror),
 .tmds_data0(td0),.tmds_data1(td1),.tmds_data2(td2),.tmds_clk(tc),
.c_awaddr(c_awaddr),.m_awaddr(s_axi_awaddr),
.c_awid(c_awid),.m_awid(s_axi_awid),
.c_awlen(c_awlen),.m_awlen(s_axi_awlen),
.c_awsize(c_awsize),.m_awsize(s_axi_awsize),
.c_awburst(c_awburst),.m_awburst(s_axi_awburst),
.c_awlock(c_awlock),.m_awlock(s_axi_awlock),
.c_awcache(c_awcache),.m_awcache(s_axi_awcache),
.c_awprot(c_awprot),.m_awprot(s_axi_awprot),
.c_awvalid(c_awvalid),.m_awvalid(s_axi_awvalid),
.c_awready(c_awready),.m_awready(s_axi_awready),
.c_wdata(c_wdata),.m_wdata(s_axi_wdata),
.c_wstrb(c_wstrb),.m_wstrb(s_axi_wstrb),
.c_wlast(c_wlast),.m_wlast(s_axi_wlast),
.c_wvalid(c_wvalid),.m_wvalid(s_axi_wvalid),
.c_wready(c_wready),.m_wready(s_axi_wready),
.c_bid(c_bid),.m_bid(s_axi_bid),
.c_bresp(c_bresp),.m_bresp(s_axi_bresp),
.c_bvalid(c_bvalid),.m_bvalid(s_axi_bvalid),
.c_bready(c_bready),.m_bready(s_axi_bready),
.c_araddr(c_araddr),.m_araddr(s_axi_araddr),
.c_arid(c_arid),.m_arid(s_axi_arid),
.c_arlen(c_arlen),.m_arlen(s_axi_arlen),
.c_arsize(c_arsize),.m_arsize(s_axi_arsize),
.c_arburst(c_arburst),.m_arburst(s_axi_arburst),
.c_arlock(c_arlock),.m_arlock(s_axi_arlock),
.c_arcache(c_arcache),.m_arcache(s_axi_arcache),
.c_arprot(c_arprot),.m_arprot(s_axi_arprot),
.c_arvalid(c_arvalid),.m_arvalid(s_axi_arvalid),
.c_arready(c_arready),.m_arready(s_axi_arready),
.c_rid(c_rid),.m_rid(s_axi_rid),
.c_rdata(c_rdata),.m_rdata(s_axi_rdata),
.c_rresp(c_rresp),.m_rresp(s_axi_rresp),
.c_rlast(c_rlast),.m_rlast(s_axi_rlast),
.c_rvalid(c_rvalid),.m_rvalid(s_axi_rvalid),
.c_rready(c_rready),.m_rready(s_axi_rready));
endmodule
