`timescale 1ns/1ps
// XRGB8888 rectangle engine. One AXI transaction is outstanding at a time.
// AXI size is 16 bytes and INCR; external integration supplies those constants.
// Each row is buffered before writes, permitting different 4-byte lane offsets.
// Caller must reject source/destination overlap for copy operations.
module bitblt_engine (
    input wire clk, resetn, start,
    input wire [1:0] op,
    input wire [31:0] src_addr, dst_addr, src_stride, dst_stride,
    input wire [15:0] width, height,
    input wire [31:0] fill_color,
    input wire [7:0] alpha,
    input wire [23:0] color_key,
    input wire alpha_enable, key_enable,
    output reg busy, done, error,
    output reg [31:0] cycles, read_bytes, write_bytes,
    output reg [31:0] m_awaddr,
    output reg [7:0] m_awlen,
    output wire m_awvalid,
    input wire m_awready,
    output reg [127:0] m_wdata,
    output reg [15:0] m_wstrb,
    output reg m_wlast,
    output wire m_wvalid,
    input wire m_wready,
    input wire [1:0] m_bresp,
    input wire m_bvalid,
    output wire m_bready,
    output reg [31:0] m_araddr,
    output reg [7:0] m_arlen,
    output wire m_arvalid,
    input wire m_arready,
    input wire [127:0] m_rdata,
    input wire [1:0] m_rresp,
    input wire m_rlast, m_rvalid,
    output wire m_rready
);
    localparam [4:0] IDLE=0, CHECK=1, ROW_START=2,
        RD_PLAN=3, RD_ADDR=4, RD_DATA=5, PIXEL_LOAD=6,
        PIXEL_PICK=7, PIXEL_MULT=8, PIXEL_BLEND=9, PIXEL_PACK=10,
        WR_PLAN=11, WR_ADDR=12, WR_LOAD=13, WR_DATA=14, WR_RESP=15,
        ROW_END=16, FINISH=17, VEC_RUN=18, VEC_DRAIN=19, RD_DRAIN=20;
    reg [4:0] state;
    reg [1:0] op_q;
    reg [31:0] src_row, dst_row, src_stride_q, dst_stride_q, fill_q;
    reg [15:0] width_q, height_q, row_index;
    reg [7:0] alpha_q;
    reg [23:0] key_q;
    reg alpha_en_q, key_en_q, bad_parameter;
    reg cached_source;
    // Packed <=32x16 tiles fit in the existing 257-word source RAM. Fetch the
    // complete tile in bursts once, instead of eight/sixteen short row reads.
    wire [8:0] cached_row_base = row_index[3:0] * width_q[5:2];


    // A 1024-pixel row beginning at lane 1..3 spans at most 257 beats.
    (* syn_ramstyle = "block_ram" *) reg [127:0] source_buffer [0:255];
    // Background and output share one line RAM. Every old background beat
    // is consumed before that address is overwritten with the composed beat.
    (* syn_ramstyle = "block_ram" *) reg [127:0] line_buffer [0:255];
    (* syn_ramstyle = "block_ram" *) reg [15:0] strobe_buffer [0:256];
    reg [9:0] dst_beats, rd_remaining, rd_base, wr_remaining, wr_base;
    reg [4:0] rd_count, rd_index, wr_count, wr_index;
    reg [31:0] rd_address, wr_address;
    reg read_background, read_failed;
    reg [10:0] pixel_index;
    reg [8:0] output_index;
    reg [127:0] pack_accumulator;
    // The 257th word is a register. This avoids rounding every 257x128 line
    // buffer up to 512 words of block RAM while preserving all edge beats.
    reg [127:0] source_tail,background_tail,output_tail;
    reg [127:0] source_ram_word,source_ram_word_hi,line_ram_word;
    reg [127:0] source_tail_q,source_tail_hi_q,background_tail_q;
    reg source_read_tail,source_hi_read_tail,background_read_tail;
    wire [127:0] source_word=source_read_tail?source_tail_q:source_ram_word;
    wire [127:0] source_word_hi=source_hi_read_tail?source_tail_hi_q:source_ram_word_hi;
    wire [127:0] background_word=background_read_tail?background_tail_q:line_ram_word;
    reg [15:0] strobe_accumulator;
    reg [127:0] output_tail_q;
    reg output_read_tail;
    wire [127:0] buffered_write_data=output_read_tail?output_tail_q:line_ram_word;
    reg [15:0] buffered_write_strobe, solid_write_strobe;
    reg [31:0] foreground_pixel, background_pixel, pixel_result;
    reg pixel_write;

    // Efinity 2026.1 doc/topics/syn-attr-use-dsp.html specifies this attribute
    // on multiplier output signals. DSP use must also be checked in synthesis.
    (* syn_use_dsp = "yes" *) reg [15:0] fg_r_product, fg_g_product, fg_b_product;
    (* syn_use_dsp = "yes" *) reg [15:0] bg_r_product, bg_g_product, bg_b_product;

    wire [63:0] row_bytes_input = {48'd0,width} << 2;
    wire [63:0] src_limit_input = {32'd0,src_addr} +
        ({32'd0,src_stride} * ({48'd0,height} - 64'd1)) + row_bytes_input;
    wire [63:0] dst_limit_input = {32'd0,dst_addr} +
        ({32'd0,dst_stride} * ({48'd0,height} - 64'd1)) + row_bytes_input;
    wire invalid_input = (op > 1) || (width > 1024) ||
        (dst_addr[1:0] != 0) || (dst_stride[1:0] != 0) ||
        (dst_limit_input > 64'h10000000) ||
        ((height > 1) && ({32'd0,dst_stride} < row_bytes_input)) ||
        // Fill does not access its source fields; match the software contract.
        ((op == 1) && ((src_addr[1:0] != 0) || (src_stride[1:0] != 0) ||
        (src_limit_input > 64'h10000000) ||
        ((height > 1) && ({32'd0,src_stride} < row_bytes_input))));
    wire [10:0] src_pixel_offset = pixel_index + {9'd0,src_row[3:2]};
    wire [10:0] dst_pixel_offset = pixel_index + {9'd0,dst_row[3:2]};
    wire [31:0] picked_foreground = (op_q == 0) ? fill_q :
        source_word[src_pixel_offset[1:0]*32 +: 32];
    wire [31:0] picked_background = background_word[dst_pixel_offset[1:0]*32 +: 32];
    wire [7:0] inverse_alpha = 8'd255 - alpha_q;
    wire solid_fill = (op_q == 0) && !alpha_en_q && !key_en_q;
    // Opaque aligned background copies need no pixel arithmetic. Transfer
    // complete 128-bit words, retaining the same burst/error/backpressure path.
    wire aligned_copy = (op_q == 1) && !alpha_en_q && !key_en_q &&
                        (src_row[3:0] == 0) && (dst_row[3:0] == 0) &&
                        (width_q[1:0] == 0);
    wire [10:0] write_beat_pixel = (wr_base + wr_index) << 2;
    wire [8:0] read_buffer_address = rd_base[8:0] + rd_index;
    wire [8:0] write_buffer_address = wr_base[8:0] + wr_index;
    wire [8:0] source_read_index;
    // Four-pixel COPY pipeline. The two source reads use the two physical RAM
    // ports; port A multiplexes its write and read address (never concurrent).
    // No additional line buffer or duplicate source RAM is introduced.
    reg vec_v0,vec_v1,vec_v2;
    reg [8:0] vec_index0,vec_index1,vec_index2;
    reg vec_lo_valid0,vec_hi_valid0;
    reg [3:0] vec_valid0,vec_keep1,vec_keep2;
    reg [127:0] vec_fg1,vec_bg1,vec_result2;
    wire vector_copy = (op_q == 1) && (width_q[1:0] == 0);
    wire vec_issue = state == VEC_RUN;
    wire [9:0] vec_src_beat = {1'b0,output_index} -
        ((src_row[3:2] < dst_row[3:2]) ? 10'd1 : 10'd0);
    wire [9:0] vec_src_next = vec_src_beat + 10'd1;
    wire [9:0] vec_src_beats = row_beat_count(src_row,width_q);
    wire vec_lo_valid = vec_src_beat < vec_src_beats;
    wire vec_hi_valid = vec_src_next < vec_src_beats;
    wire [1:0] vec_shift = src_row[3:2] - dst_row[3:2];
    wire [255:0] vec_source_pair = {
        vec_hi_valid0 ? source_word_hi : 128'd0,
        vec_lo_valid0 ? source_word : 128'd0};
    wire [127:0] vec_foreground = vec_source_pair >> ({5'd0,vec_shift} << 5);
    wire [10:0] vec_beat_pixel = {output_index,2'b00};
    wire [8:0] vec_source_lo_index = (vec_lo_valid ? vec_src_beat[8:0] : 9'd0) +
        (cached_source ? cached_row_base : 9'd0);
    wire [8:0] vec_source_hi_index = (vec_hi_valid ? vec_src_next[8:0] : 9'd0) +
        (cached_source ? cached_row_base : 9'd0);
    wire source_ram_write = state == RD_DATA && m_rvalid && !read_background;
    wire source_ram_read = ((state == PIXEL_LOAD) && (op_q == 1)) ||
        ((state == WR_LOAD) && aligned_copy) || vec_issue;
    wire [8:0] source_port_a_address = source_ram_write ? read_buffer_address : source_read_index;
    wire [31:0] multiply_foreground0 = vec_v0 ? vec_foreground[31:0] : foreground_pixel;
    wire [31:0] multiply_background0 = vec_v0 ? background_word[31:0] : background_pixel;
    wire [15:0] vec_strobe2 = {{4{vec_keep2[3]}},{4{vec_keep2[2]}},{4{vec_keep2[1]}},{4{vec_keep2[0]}}};
    reg [127:0] packed_data;
    reg [15:0] packed_strobe;
    wire scalar_pack_emit = state == PIXEL_PACK &&
        (dst_pixel_offset[1:0] == 3 || pixel_index == width_q-1);
    wire output_ram_write = scalar_pack_emit || (resetn && vec_v2);
    wire [8:0] output_ram_write_address = vec_v2 ? vec_index2 : output_index;
    wire [127:0] output_ram_write_data = vec_v2 ? vec_result2 : packed_data;
    wire [15:0] output_ram_write_strobe = vec_v2 ? vec_strobe2 : packed_strobe;
    wire [8:0] background_read_address = vec_issue ? output_index : dst_pixel_offset[10:2];
    wire background_load_read = (state == PIXEL_LOAD && alpha_en_q && alpha_q != 255) || vec_issue;
    wire output_load_read = state == WR_LOAD && !solid_fill;
    wire line_ram_read = background_load_read || output_load_read;
    wire [7:0] line_ram_read_address = output_load_read ? write_buffer_address[7:0] : background_read_address[7:0];
    wire line_ram_write = (state == RD_DATA && m_rvalid && read_background && !read_buffer_address[8]) ||
        (output_ram_write && !output_ram_write_address[8]);
    wire [7:0] line_ram_write_address = output_ram_write ? output_ram_write_address[7:0] : read_buffer_address[7:0];
    wire [127:0] line_ram_write_data = output_ram_write ? output_ram_write_data : m_rdata;
    assign source_read_index = vec_issue ? vec_source_lo_index :
        (aligned_copy ? write_buffer_address : src_pixel_offset[10:2]) +
        (cached_source ? cached_row_base : 9'd0);
    reg [15:0] fill_strobe;
    reg [15:0] next_fill_strobe;
    integer fill_lane;

    assign m_awvalid = (state == WR_ADDR);
    assign m_wvalid = (state == WR_DATA);
    assign m_bready = (state == WR_RESP);
    assign m_arvalid = (state == RD_ADDR);
    assign m_rready = (state == RD_DATA || state == RD_DRAIN);

    function automatic [9:0] row_beat_count;
        input [31:0] address;
        input [15:0] pixels;
        reg [31:0] bytes;
        begin
            bytes = {16'd0,pixels} * 32'd4 + {28'd0,address[3:0]} + 32'd15;
            row_beat_count = bytes >> 4;
        end
    endfunction

    function automatic [4:0] burst_count;
        input [31:0] address;
        input [9:0] remaining;
        reg [8:0] boundary;
        reg [9:0] count;
        begin
            boundary = 9'd256 - {1'b0,address[11:4]};
            count = (remaining > 16) ? 10'd16 : remaining;
            if (count > boundary) count = boundary;
            burst_count = count[4:0];
        end
    endfunction

    // Exact floor(v / 255) for 0 <= v <= 65152. The RGB numerator already
    // includes +127 for rounding. This avoids a general divider in hardware.
    function automatic [7:0] divide_255;
        input [16:0] v;
        reg [16:0] t;
        begin
            t = v + 17'd1;
            t = t + (t >> 8);
            divide_255 = t[15:8];
        end
    endfunction

    function automatic [4:0] byte_count;
        input [15:0] strobe;
        integer i;
        begin
            byte_count = 0;
            for (i=0; i<16; i=i+1) byte_count = byte_count + strobe[i];
        end
    endfunction

    always @* begin
        packed_data = pack_accumulator;
        packed_strobe = strobe_accumulator;
        packed_data[dst_pixel_offset[1:0]*32 +: 32] = pixel_result;
        packed_strobe[dst_pixel_offset[1:0]*4 +: 4] = pixel_write ? 4'hf : 4'h0;
        fill_strobe = 0;
        next_fill_strobe = 0;
        for (fill_lane=0; fill_lane<4; fill_lane=fill_lane+1) begin
            if ((write_beat_pixel + fill_lane >= {9'd0,dst_row[3:2]}) &&
                (write_beat_pixel + fill_lane < {9'd0,dst_row[3:2]} + {1'b0,width_q}))
                fill_strobe[fill_lane*4 +: 4] = 4'hf;
            if ((write_beat_pixel + 4 + fill_lane >= {9'd0,dst_row[3:2]}) &&
                (write_beat_pixel + 4 + fill_lane < {9'd0,dst_row[3:2]} + {1'b0,width_q}))
                next_fill_strobe[fill_lane*4 +: 4] = 4'hf;
        end
        // Select after the registered RAM outputs; a mux before the RAM read
        // register prevents Efinity from inferring the synchronous read port.
        m_wdata = solid_fill ? {4{fill_q}} : aligned_copy ? source_word : buffered_write_data;
        m_wstrb = solid_fill ? solid_write_strobe : aligned_copy ? 16'hffff : buffered_write_strobe;
    end

    // Simple dual-port block RAM templates. Neither arrays nor read-data
    // registers have synchronous resets (unsupported by the RAM read port).
    always @(posedge clk) begin
        if ((state == RD_DATA) && m_rvalid) begin
            if (read_background) begin
                if(read_buffer_address[8])background_tail<=m_rdata;
            end
        end
        if (output_ram_write) begin
            if(output_ram_write_address[8])output_tail<=output_ram_write_data;
            strobe_buffer[output_ram_write_address]<=output_ram_write_strobe;
        end
        if(line_ram_write)line_buffer[line_ram_write_address]<=line_ram_write_data;
    end
    always @(posedge clk) begin
        if(line_ram_read)line_ram_word<=line_buffer[line_ram_read_address];
        if (source_ram_write || source_ram_read) begin
            if (source_ram_write) begin
                if(source_port_a_address[8])source_tail<=m_rdata;
                else source_buffer[source_port_a_address[7:0]]<=m_rdata;
            end
            source_ram_word<=source_buffer[source_port_a_address[7:0]];
            source_read_tail<=source_port_a_address[8];source_tail_q<=source_tail;
        end
        if (vec_issue) begin
            source_ram_word_hi<=source_buffer[vec_source_hi_index[7:0]];
            source_hi_read_tail<=vec_source_hi_index[8];source_tail_hi_q<=source_tail;
        end
        if (((state == PIXEL_LOAD) && alpha_en_q && (alpha_q != 255)) || vec_issue)begin
            background_read_tail<=background_read_address[8];background_tail_q<=background_tail;
        end
        if ((state == WR_LOAD) && !solid_fill) begin
            output_read_tail<=write_buffer_address[8];output_tail_q<=output_tail;
            buffered_write_strobe <= strobe_buffer[write_buffer_address];
        end
    end

    // Registered RAM read -> multiply -> exact blend -> one output beat.
    // Kept/key bits and destination lane validity travel with the same beat.
    wire [31:0] vec_blend0 = !alpha_en_q || alpha_q == 255 ? vec_fg1[31:0] :
        alpha_q == 0 ? vec_bg1[31:0] : {8'd0,
        divide_255({1'b0,fg_r_product}+{1'b0,bg_r_product}+17'd127),
        divide_255({1'b0,fg_g_product}+{1'b0,bg_g_product}+17'd127),
        divide_255({1'b0,fg_b_product}+{1'b0,bg_b_product}+17'd127)};
    always @(posedge clk) begin
        if (!resetn) begin vec_v0<=0;vec_v1<=0;vec_v2<=0;end
        else begin
            vec_v0<=vec_issue;vec_v1<=vec_v0;vec_v2<=vec_v1;
            if (vec_issue) begin
                vec_index0<=output_index;vec_lo_valid0<=vec_lo_valid;vec_hi_valid0<=vec_hi_valid;
            end
            if (vec_v0) begin vec_index1<=vec_index0;vec_fg1<=vec_foreground;vec_bg1<=background_word;end
            if (vec_v1) begin vec_index2<=vec_index1;vec_keep2<=vec_keep1;vec_result2[31:0]<=vec_blend0;end
        end
    end
    genvar vl;
    generate for(vl=0;vl<4;vl=vl+1)begin:vector_lane
        wire [31:0] fg = vec_foreground[vl*32+:32];
        wire [31:0] bg = background_word[vl*32+:32];
        always @(posedge clk) begin
            if(vec_issue)vec_valid0[vl]<=vec_beat_pixel+vl >= {9'd0,dst_row[3:2]} &&
                vec_beat_pixel+vl < {9'd0,dst_row[3:2]}+{1'b0,width_q};
            if(vec_v0)vec_keep1[vl]<=vec_valid0[vl] && !(key_en_q && fg[23:0]==key_q);
        end
        if(vl!=0)begin:extra_multiplier
            (* syn_use_dsp="yes" *) reg [15:0] fr,fgp,fb,br,bgp,bb;
            wire [31:0] result = !alpha_en_q || alpha_q==255 ? vec_fg1[vl*32+:32] :
                alpha_q==0 ? vec_bg1[vl*32+:32] : {8'd0,
                divide_255({1'b0,fr}+{1'b0,br}+17'd127),
                divide_255({1'b0,fgp}+{1'b0,bgp}+17'd127),
                divide_255({1'b0,fb}+{1'b0,bb}+17'd127)};
            always @(posedge clk)begin
                if(vec_v0)begin
                    fr<=fg[23:16]*alpha_q;fgp<=fg[15:8]*alpha_q;fb<=fg[7:0]*alpha_q;
                    br<=bg[23:16]*inverse_alpha;bgp<=bg[15:8]*inverse_alpha;bb<=bg[7:0]*inverse_alpha;
                end
                if(vec_v1)vec_result2[vl*32+:32]<=result;
            end
        end
    end endgenerate

    always @(posedge clk) begin
        if (!resetn) begin
            state <= IDLE;
            busy <= 0; done <= 0; error <= 0;
            cycles <= 0; read_bytes <= 0; write_bytes <= 0;
            m_awaddr <= 0; m_awlen <= 0; m_araddr <= 0; m_arlen <= 0;
            solid_write_strobe <= 0; m_wlast <= 0;
            op_q <= 0; src_row <= 0; dst_row <= 0;
            src_stride_q <= 0; dst_stride_q <= 0; fill_q <= 0;
            width_q <= 0; height_q <= 0; row_index <= 0;
            alpha_q <= 0; key_q <= 0; alpha_en_q <= 0; key_en_q <= 0;
            cached_source <= 0;
            bad_parameter <= 0; read_background <= 0; read_failed <= 0;
            rd_remaining <= 0; rd_base <= 0; rd_count <= 0; rd_index <= 0;
            wr_remaining <= 0; wr_base <= 0; wr_count <= 0; wr_index <= 0;
            rd_address <= 0; wr_address <= 0; dst_beats <= 0;
            pixel_index <= 0; output_index <= 0;
            foreground_pixel <= 0; background_pixel <= 0; pixel_result <= 0;
            pixel_write <= 0; pack_accumulator <= 0; strobe_accumulator <= 0;
            fg_r_product <= 0; fg_g_product <= 0; fg_b_product <= 0;
            bg_r_product <= 0; bg_g_product <= 0; bg_b_product <= 0;
        end else begin
            done <= 0;
            if (busy) cycles <= cycles + 1;
            if (state == PIXEL_MULT || vec_v0) begin
                fg_r_product <= multiply_foreground0[23:16] * alpha_q;
                fg_g_product <= multiply_foreground0[15:8] * alpha_q;
                fg_b_product <= multiply_foreground0[7:0] * alpha_q;
                bg_r_product <= multiply_background0[23:16] * inverse_alpha;
                bg_g_product <= multiply_background0[15:8] * inverse_alpha;
                bg_b_product <= multiply_background0[7:0] * inverse_alpha;
            end
            case (state)
                IDLE: if (start) begin
                    busy <= 1; error <= 0; cycles <= 0; read_bytes <= 0; write_bytes <= 0;
                    op_q <= op; src_row <= src_addr; dst_row <= dst_addr;
                    src_stride_q <= src_stride; dst_stride_q <= dst_stride;
                    width_q <= width; height_q <= height; fill_q <= fill_color;
                    alpha_q <= alpha; key_q <= color_key;
                    alpha_en_q <= alpha_enable; key_en_q <= key_enable;
                    cached_source <= (op == 1) && (src_addr[3:0] == 0) &&
                        (width[1:0] == 0) && (width <= 32) && (height <= 16) &&
                        (src_stride == ({16'd0,width} << 2));
                    row_index <= 0; bad_parameter <= invalid_input;
                    state <= CHECK;
                end
                CHECK: begin
                    if ((width_q == 0) || (height_q == 0)) state <= FINISH;
                    else if (bad_parameter) begin error <= 1; state <= FINISH; end
                    else state <= ROW_START;
                end
                ROW_START: begin
                    dst_beats <= row_beat_count(dst_row,width_q);
                    pixel_index <= 0; output_index <= 0;
                    pack_accumulator <= 0; strobe_accumulator <= 0;
                    rd_base <= 0; rd_index <= 0; read_failed <= 0;
                    if (solid_fill) begin
                        wr_address <= {dst_row[31:4],4'd0};
                        wr_remaining <= row_beat_count(dst_row,width_q);
                        wr_base <= 0; wr_index <= 0; state <= WR_PLAN;
                    end else if (cached_source && (row_index != 0)) begin
                        if (alpha_en_q && (alpha_q != 255)) begin
                            rd_address <= {dst_row[31:4],4'd0};
                            rd_remaining <= row_beat_count(dst_row,width_q);
                            read_background <= 1; state <= RD_PLAN;
                        end else if (aligned_copy) begin
                            wr_address <= dst_row; wr_remaining <= row_beat_count(dst_row,width_q);
                            wr_base <= 0; wr_index <= 0; state <= WR_PLAN;
                        end else if (vector_copy) state <= VEC_RUN;
                        else state <= PIXEL_LOAD;
                    end else if (op_q == 1) begin
                        rd_address <= {src_row[31:4],4'd0};
                        rd_remaining <= cached_source ? ((width_q >> 2) * height_q) : row_beat_count(src_row,width_q);
                        read_background <= 0; state <= RD_PLAN;
                    end else if (alpha_en_q && (alpha_q != 255)) begin
                        rd_address <= {dst_row[31:4],4'd0};
                        rd_remaining <= row_beat_count(dst_row,width_q);
                        read_background <= 1; state <= RD_PLAN;
                    end else if (vector_copy) state <= VEC_RUN;
                        else state <= PIXEL_LOAD;
                end
                RD_PLAN: begin
                    rd_count <= burst_count(rd_address,rd_remaining);
                    rd_index <= 0; m_araddr <= rd_address;
                    m_arlen <= burst_count(rd_address,rd_remaining) - 1;
                    state <= RD_ADDR;
                end
                RD_ADDR: if (m_arready) state <= RD_DATA;
                RD_DATA: if (m_rvalid) begin
                    read_bytes <= read_bytes + 16;
                    if ((m_rresp != 0) || (m_rlast != (rd_index == rd_count-1))) begin
                        read_failed <= 1; error <= 1;
                        // Never fabricate completion for an accepted read.
                        // Hold BUSY/RREADY until the actual final tail arrives.
                        state <= m_rlast ? FINISH : RD_DRAIN;
                    end else if (m_rlast) begin
                        if (read_failed) begin
                            error <= 1; state <= FINISH;
                        end else if (rd_remaining == rd_count) begin
                            if (!read_background && alpha_en_q && (alpha_q != 255)) begin
                                read_background <= 1; rd_base <= 0;
                                rd_address <= {dst_row[31:4],4'd0};
                                rd_remaining <= row_beat_count(dst_row,width_q);
                                state <= RD_PLAN;
                            end else if (aligned_copy) begin
                                wr_address <= dst_row; wr_remaining <= dst_beats;
                                wr_base <= 0; wr_index <= 0; state <= WR_PLAN;
                            end else if (vector_copy) state <= VEC_RUN;
                        else state <= PIXEL_LOAD;
                        end else begin
                            rd_base <= rd_base + rd_count;
                            rd_remaining <= rd_remaining - rd_count;
                            rd_address <= rd_address + (rd_count << 4);
                            state <= RD_PLAN;
                        end
                    end else rd_index <= rd_index + 1;
                end
                RD_DRAIN: if (m_rvalid) begin
                    read_bytes <= read_bytes + 16;
                    if (m_rlast) state <= FINISH;
                end
                PIXEL_LOAD: begin
                    state <= PIXEL_PICK;
                end
                PIXEL_PICK: begin
                    foreground_pixel <= picked_foreground;
                    background_pixel <= picked_background;
                    pixel_write <= !(key_en_q && (picked_foreground[23:0] == key_q));
                    if (key_en_q && (picked_foreground[23:0] == key_q)) begin
                        pixel_result <= 0; state <= PIXEL_PACK;
                    end else if (!alpha_en_q || (alpha_q == 255)) begin
                        pixel_result <= picked_foreground; state <= PIXEL_PACK;
                    end else if (alpha_q == 0) begin
                        pixel_result <= picked_background; state <= PIXEL_PACK;
                    end else state <= PIXEL_MULT;
                end
                PIXEL_MULT: begin
                    state <= PIXEL_BLEND;
                end
                PIXEL_BLEND: begin
                    pixel_result <= {8'd0,
                        divide_255({1'b0,fg_r_product}+{1'b0,bg_r_product}+17'd127),
                        divide_255({1'b0,fg_g_product}+{1'b0,bg_g_product}+17'd127),
                        divide_255({1'b0,fg_b_product}+{1'b0,bg_b_product}+17'd127)};
                    state <= PIXEL_PACK;
                end
                PIXEL_PACK: begin
                    if ((dst_pixel_offset[1:0] == 3) || (pixel_index == width_q-1)) begin
                        output_index <= output_index + 1;
                        pack_accumulator <= 0; strobe_accumulator <= 0;
                    end else begin
                        pack_accumulator <= packed_data; strobe_accumulator <= packed_strobe;
                    end
                    if (pixel_index == width_q-1) begin
                        wr_address <= {dst_row[31:4],4'd0}; wr_remaining <= dst_beats;
                        wr_base <= 0; wr_index <= 0; state <= WR_PLAN;
                    end else begin pixel_index <= pixel_index + 1; state <= PIXEL_LOAD; end
                end
                VEC_RUN: begin
                    output_index <= output_index + 1;
                    if (output_index + 1 == dst_beats) state <= VEC_DRAIN;
                end
                VEC_DRAIN: if (!(vec_v0 || vec_v1 || vec_v2)) begin
                    wr_address <= {dst_row[31:4],4'd0}; wr_remaining <= dst_beats;
                    wr_base <= 0; wr_index <= 0; state <= WR_PLAN;
                end
                WR_PLAN: begin
                    wr_count <= burst_count(wr_address,wr_remaining);
                    wr_index <= 0; m_awaddr <= wr_address;
                    m_awlen <= burst_count(wr_address,wr_remaining) - 1;
                    state <= WR_ADDR;
                end
                WR_ADDR: if (m_awready) state <= WR_LOAD;
                WR_LOAD: begin
                    if (solid_fill) solid_write_strobe <= fill_strobe;
                    m_wlast <= (wr_index == wr_count-1); state <= WR_DATA;
                end
                WR_DATA: if (m_wready) begin
                    write_bytes <= write_bytes + byte_count(m_wstrb);
                    if (wr_index == wr_count-1) state <= WR_RESP;
                    else begin
                        wr_index <= wr_index + 1;
                        if (solid_fill) begin
                            // No per-beat loading bubble for solid fill. Payload
                            // advances only on handshake and is stable if stalled.
                            solid_write_strobe <= next_fill_strobe;
                            m_wlast <= (wr_index + 1 == wr_count-1);
                        end else state <= WR_LOAD;
                    end
                end
                WR_RESP: if (m_bvalid) begin
                    if (m_bresp != 0) begin error <= 1; state <= FINISH; end
                    else if (wr_remaining == wr_count) state <= ROW_END;
                    else begin
                        wr_base <= wr_base + wr_count;
                        wr_remaining <= wr_remaining - wr_count;
                        wr_address <= wr_address + (wr_count << 4); state <= WR_PLAN;
                    end
                end
                ROW_END: begin
                    if (row_index == height_q-1) state <= FINISH;
                    else begin
                        row_index <= row_index + 1;
                        src_row <= src_row + src_stride_q; dst_row <= dst_row + dst_stride_q;
                        state <= ROW_START;
                    end
                end
                FINISH: begin busy <= 0; done <= 1; state <= IDLE; end
                default: begin error <= 1; state <= FINISH; end
            endcase
        end
    end
endmodule
