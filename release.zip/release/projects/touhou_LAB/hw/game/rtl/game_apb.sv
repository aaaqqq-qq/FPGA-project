// PIPE5 independent contexts; the C2 register range remains compatible.
module game_apb(
 input wire clk,resetn,input wire [15:0] paddr,input wire psel,penable,pwrite,
 input wire [31:0] pwdata,output reg [31:0] prdata,output wire pready,pslverror,
 output reg [7:0] tile_first,output reg [14:0] sprite_count,output reg [31:0] texture_addr,
 output reg start,input wire busy,done,error,snapshot_decided,snapshot_no_draw,snapshot_ready_pulse,
 output reg [1:0] op,output reg [31:0] src_addr,dst_addr,src_stride,dst_stride,fill_color,
 input wire [31:0] cycles,read_bytes,write_bytes,
 output reg [15:0] width,height,output reg [7:0] alpha,output reg [23:0] color_key,
 output reg alpha_enable,key_enable,batch32_enable,preflight_enable,preflight8_enable,display_enable,swap_start,
 output reg [31:0] swap_addr,input wire [31:0] front_addr,input wire swap_pending,
 input wire [31:0] frame_count,swap_count,underflow_count,input wire cal_done,
 output reg r_pipe_start,m_pipe_start,output reg [31:0] m_pipe_job,m_pipe_epoch,
 input wire r_busy,r_done,r_error,m_busy,m_done,m_error,axi_protocol_error,
 input wire [31:0] r_cycles,r_read_bytes,r_write_bytes,m_cycles,m_read_bytes,m_write_bytes
);
 reg done_sticky,error_sticky;reg [1:0] snapshot_sticky;
 reg r_done_sticky,r_error_sticky,m_done_sticky,m_error_sticky;
 reg [31:0] r_epoch_shadow,m_epoch_shadow,m_job_shadow,r_active_epoch,m_active_epoch;
 reg [31:0] r_done_epoch,m_done_epoch;
 // READY is the validity bit; a valid snapshot always belongs to the locked R epoch.
 reg [2:0] r_snap_status,pipe_fault;reg r_pipe_active,m_pipe_active,r_nodraw_hold;
 wire [31:0] r_snap_epoch=r_snap_status[2]?r_active_epoch:32'b0;
 reg [31:0] r_terminal_cycles,r_terminal_read,r_terminal_write,m_terminal_cycles,m_terminal_read,m_terminal_write;
 wire write_access=psel&&penable&&pwrite;
 wire legacy_motion=op==3&&width==1&&height==1;
 wire pending_any=start||r_pipe_start||m_pipe_start;
 wire global_busy=busy||pending_any||r_pipe_active||m_pipe_active;
 wire r_context_busy=r_busy||r_pipe_active||r_pipe_start||(start&&!legacy_motion);
 wire m_context_busy=m_busy||m_pipe_active||m_pipe_start||(start&&legacy_motion);
 wire fault_r=r_error&&r_pipe_active&&(r_busy||r_done);
 wire fault_m=m_error&&m_pipe_active&&(m_busy||m_done);
 wire fault_axi=axi_protocol_error&&(r_pipe_active||m_pipe_active);
 wire fault_now=(|pipe_fault)||fault_r||fault_m||fault_axi;
 wire accepted_legacy=write_access&&paddr==16'h04&&pwdata[0]&&!global_busy&&!fault_now;
 wire accepted_r=write_access&&paddr==16'ha0&&pwdata==1&&!r_nodraw_hold&&!global_busy&&!fault_now&&op==2&&r_epoch_shadow!=0&&r_epoch_shadow!=r_active_epoch;
 wire r_release=r_pipe_active&&r_snap_epoch==r_active_epoch&&r_snap_epoch!=0&&r_snap_status[2]&&!r_snap_status[1];
 wire accepted_m=write_access&&paddr==16'hc0&&pwdata[0]&&!r_nodraw_hold&&!m_context_busy&&!fault_now&&(!r_context_busy||r_release)&&m_epoch_shadow!=0&&m_epoch_shadow!=m_active_epoch;
 wire accepted_fallback_ack=write_access&&paddr==16'ha0&&pwdata==2&&r_nodraw_hold&&!global_busy&&!done&&!fault_now&&!error_sticky&&!error&&r_done_sticky&&r_snap_status[1]&&!r_snap_status[2]&&r_active_epoch!=0&&r_epoch_shadow==r_active_epoch&&r_done_epoch==r_active_epoch;
 assign pready=1'b1,pslverror=1'b0;
 always @(posedge clk or negedge resetn)begin
  if(!resetn)begin
   snapshot_sticky<=0;preflight_enable<=0;preflight8_enable<=0;
   sprite_count<=0;texture_addr<=0;tile_first<=0;start<=0;swap_start<=0;done_sticky<=0;error_sticky<=0;op<=0;
   src_addr<=0;dst_addr<=0;src_stride<=5120;dst_stride<=5120;width<=0;height<=0;fill_color<=0;alpha<=255;color_key<=24'hff00ff;
   alpha_enable<=0;key_enable<=0;batch32_enable<=0;display_enable<=0;swap_addr<=32'h01000000;
   r_pipe_start<=0;m_pipe_start<=0;m_pipe_job<=0;m_pipe_epoch<=0;
   r_done_sticky<=0;r_error_sticky<=0;m_done_sticky<=0;m_error_sticky<=0;
   r_epoch_shadow<=0;m_epoch_shadow<=0;m_job_shadow<=0;r_active_epoch<=0;m_active_epoch<=0;
   r_done_epoch<=0;m_done_epoch<=0;r_snap_status<=0;pipe_fault<=0;r_pipe_active<=0;m_pipe_active<=0;r_nodraw_hold<=0;
   r_terminal_cycles<=0;r_terminal_read<=0;r_terminal_write<=0;m_terminal_cycles<=0;m_terminal_read<=0;m_terminal_write<=0;
  end else begin
   start<=0;swap_start<=0;r_pipe_start<=0;m_pipe_start<=0;
   if(snapshot_decided)snapshot_sticky<={snapshot_no_draw,1'b1};
   if(accepted_legacy||accepted_r)snapshot_sticky<=0;
   if(write_access)case(paddr)
    16'h04:if(pwdata[0])begin if(accepted_legacy)begin start<=1;done_sticky<=0;error_sticky<=0;end else error_sticky<=1;end
    16'h08:begin if(pwdata[1])done_sticky<=0;if(pwdata[2])error_sticky<=0;end
    16'h0c:op<=pwdata[1:0];16'h10:src_addr<=pwdata;16'h14:dst_addr<=pwdata;
    16'h18:src_stride<=pwdata;16'h1c:dst_stride<=pwdata;16'h20:width<=pwdata[15:0];16'h24:height<=pwdata[15:0];
    16'h28:fill_color<=pwdata;16'h2c:alpha<=pwdata[7:0];16'h30:color_key<=pwdata[23:0];
    16'h34:begin alpha_enable<=pwdata[0];key_enable<=pwdata[1];batch32_enable<=pwdata[2];preflight_enable<=pwdata[3];preflight8_enable<=pwdata[4];end
    16'h44:sprite_count<=pwdata[14:0];16'h48:texture_addr<=pwdata;16'h50:tile_first<=pwdata[7:0];
    16'h80:display_enable<=pwdata[0];16'h88:swap_addr<=pwdata;
    16'h8c:if(pwdata[0])begin
     if(!swap_pending&&!swap_start&&!r_pipe_active&&!r_pipe_start&&!m_pipe_active&&!m_pipe_start&&!r_nodraw_hold&&!fault_now&&swap_addr[11:0]==0&&swap_addr<=32'h0fc7c000)swap_start<=1;
     else error_sticky<=1;
    end
    16'ha0:if(pwdata!=0)begin
     if(accepted_r)begin
      r_pipe_start<=1;r_pipe_active<=1;r_active_epoch<=r_epoch_shadow;r_done_sticky<=0;r_error_sticky<=0;r_snap_status<=0;
      r_terminal_cycles<=0;r_terminal_read<=0;r_terminal_write<=0;
     end else if(accepted_fallback_ack)r_nodraw_hold<=0;else r_error_sticky<=1;
    end
    16'ha4:begin if(pwdata[1])r_done_sticky<=0;if(pwdata[2])r_error_sticky<=0;end
    16'ha8:r_epoch_shadow<=pwdata;
    16'hc0:if(pwdata[0])begin
     if(accepted_m)begin
      m_pipe_start<=1;m_pipe_active<=1;m_active_epoch<=m_epoch_shadow;m_pipe_epoch<=m_epoch_shadow;m_pipe_job<=m_job_shadow;
      m_done_sticky<=0;m_error_sticky<=0;m_terminal_cycles<=0;m_terminal_read<=0;m_terminal_write<=0;
     end else m_error_sticky<=1;
    end
    16'hc4:begin if(pwdata[1])m_done_sticky<=0;if(pwdata[2])m_error_sticky<=0;end
    16'hc8:m_epoch_shadow<=pwdata;16'hd0:m_job_shadow<=pwdata;
    default:;
   endcase
   if(r_pipe_active&&snapshot_decided)begin r_snap_status[0]<=1;r_snap_status[1]<=snapshot_no_draw;if(snapshot_no_draw)r_nodraw_hold<=1;end
   if(r_pipe_active&&snapshot_ready_pulse)r_snap_status[2]<=1;
   if(r_done&&r_pipe_active)begin
    r_done_sticky<=1;r_error_sticky<=r_error_sticky|r_error;r_done_epoch<=r_active_epoch;r_pipe_active<=0;
    r_terminal_cycles<=r_cycles;r_terminal_read<=r_read_bytes;r_terminal_write<=r_write_bytes;
   end
   if(m_done&&m_pipe_active)begin
    m_done_sticky<=1;m_error_sticky<=m_error_sticky|m_error;m_done_epoch<=m_active_epoch;m_pipe_active<=0;
    m_terminal_cycles<=m_cycles;m_terminal_read<=m_read_bytes;m_terminal_write<=m_write_bytes;
   end
   if(done)done_sticky<=1;if(done&&error)error_sticky<=1;
   if(fault_r)pipe_fault[0]<=1;if(fault_m)pipe_fault[1]<=1;if(fault_axi)pipe_fault[2]<=1;
   // A late error cannot revoke the old pulse; it revokes readable release and
   // blocks swaps/new commands. Existing accepted R/M transactions may drain.
   if(fault_now)begin r_snap_status[2]<=0;swap_start<=0;end
  end
 end
 always @*begin
  prdata=0;
  case(paddr)
   16'h00:prdata=32'h424c5431;16'h08:prdata={29'b0,(error_sticky|(|pipe_fault)),done_sticky,global_busy};
   16'h0c:prdata={30'b0,op};16'h10:prdata=src_addr;16'h14:prdata=dst_addr;16'h18:prdata=src_stride;16'h1c:prdata=dst_stride;
   16'h20:prdata={16'b0,width};16'h24:prdata={16'b0,height};16'h28:prdata=fill_color;16'h2c:prdata={24'b0,alpha};16'h30:prdata={8'b0,color_key};
   16'h34:prdata={27'b0,preflight8_enable,preflight_enable,batch32_enable,key_enable,alpha_enable};
   16'h38:prdata=cycles;16'h3c:prdata=read_bytes;16'h40:prdata=write_bytes;16'h44:prdata={17'b0,sprite_count};16'h48:prdata=texture_addr;
   16'h4c:prdata=126;16'h50:prdata={24'b0,tile_first};16'h54:prdata={30'b0,snapshot_sticky};
   16'h80:prdata={31'b0,display_enable};16'h84:prdata=front_addr;16'h88:prdata=swap_addr;
   16'h90:prdata={29'b0,cal_done,(underflow_count!=0),swap_pending};16'h94:prdata=frame_count;16'h98:prdata=swap_count;16'h9c:prdata=underflow_count;
   16'ha4:prdata={28'b0,r_nodraw_hold,(r_error_sticky|pipe_fault[0]|pipe_fault[2]),r_done_sticky,r_context_busy};
   16'ha8:prdata=r_epoch_shadow;16'hac:prdata=r_done_epoch;16'hb0:prdata=r_snap_epoch;
   16'hb4:prdata=r_terminal_cycles;16'hb8:prdata=r_terminal_read;16'hbc:prdata=r_terminal_write;
   16'hc4:prdata={29'b0,(m_error_sticky|pipe_fault[1]|pipe_fault[2]),m_done_sticky,m_context_busy};
   16'hc8:prdata=m_epoch_shadow;16'hcc:prdata=m_done_epoch;16'hd0:prdata=m_job_shadow;
   16'hd4:prdata=m_terminal_cycles;16'hd8:prdata=m_terminal_read;16'hdc:prdata=m_terminal_write;
   16'he0:prdata={29'b0,r_snap_status};16'he4:prdata={29'b0,pipe_fault};default:;
  endcase
 end
endmodule
