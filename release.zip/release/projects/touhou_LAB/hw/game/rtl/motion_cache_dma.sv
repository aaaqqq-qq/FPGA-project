// Private zero-BRAM eight-record front / single-record read-only tail cache.
// The tail supplies only swap-delete source records; front always wins on hits.
// Global reset is a whole-platform reset; no soft reset/cancel discards AXI.
module motion_cache_dma(
 input wire clk,resetn,invalidate,
 input wire [31:0] shots_base,effects_base,owners_base,
 input wire fetch,fetch_tail,input wire [14:0] fetch_index,
 output reg [127:0] record_shot,output reg [95:0] record_effect,output reg [7:0] record_owner,
 input wire store,input wire [14:0] store_index,input wire [127:0] store_shot,
 input wire [95:0] store_effect,input wire [7:0] store_owner,
 input wire store_shot_dirty,input wire [11:0] store_effect_dirty,input wire store_owner_dirty,
 input wire flush,
 input wire raw,input wire raw_write,input wire [31:0] raw_address,input wire [127:0] raw_data,input wire [15:0] raw_strobe,
 output reg [127:0] raw_result,output reg ack,busy,error,
 output reg [31:0] read_bytes,write_bytes,stall_cycles,
 output reg [31:0] m_awaddr,output reg [7:0] m_awlen,output wire m_awvalid,input wire m_awready,
 output reg [127:0] m_wdata,output reg [15:0] m_wstrb,output wire m_wlast,m_wvalid,input wire m_wready,
 input wire [1:0] m_bresp,input wire m_bvalid,output wire m_bready,
 output reg [31:0] m_araddr,output reg [7:0] m_arlen,output wire m_arvalid,input wire m_arready,
 input wire [127:0] m_rdata,input wire [1:0] m_rresp,input wire m_rlast,m_rvalid,output wire m_rready
);
 localparam IDLE=0,SELECT=1,FLUSH_SHOT=2,FLUSH_FX=3,FLUSH_OWNER=4,
  LOAD_SHOT=5,LOAD_FX=6,LOAD_OWNER=7,RETURN_RECORD=8,
  RD_ADDR=9,RD_DATA=10,RD_DRAIN=11,WR_ADDR=12,WR_DATA=13,WR_RESP=14,FINISH=15;
 reg [4:0] state,ret;
 reg front_valid,tail_valid,pending_fetch,pending_tail,load_tail;
 reg [11:0] front_block,wanted_block;
 reg [14:0] tail_index;
 reg [14:0] wanted_index;
 // Packed vectors deliberately have no inferred RAM ports; only the trig ROM
 // may consume the one remaining physical memory block.
 reg [1023:0] front_shot;
 reg [127:0] tail_shot;
 // Eight normalized records. DDR alignment is decoded at the DMA boundary,
 // never folded into a wide variable-position record write/read.
 reg [767:0] front_fx;
 reg [95:0] tail_fx;
 reg [63:0] front_owner;
 reg [7:0] tail_owner;
 reg [7:0] shot_dirty;
 reg [95:0] fx_dirty;
 reg [7:0] owner_dirty;
 reg [3:0] beat,beats,burst_count,burst_position;
 reg [3:0] write_index,write_beats,write_chunk,write_position;
 reg [1:0] write_kind;
 reg [127:0] write_masks;
 reg [1:0] load_kind;
 reg [3:0] fx_offset,owner_offset,front_owner_offset,tail_owner_offset;
 reg [31:0] block_shots,block_effects,block_owners;
 reg [1:0] target; // 0 raw; 1 shot; 2 effect; 3 owner
 reg bad_read;
 wire [2:0] slot=wanted_index[2:0];
 wire [255:0] aligned_owner={192'b0,front_owner}<<{front_owner_offset,3'b0};
 wire [111:0] aligned_fx_masks={16'b0,fx_dirty}<<{effects_base[3:2],2'b0};
 wire [31:0] aligned_owner_masks={24'b0,owner_dirty}<<front_owner_offset;
 // One shared front/tail read address for IDLE hits and RETURN_RECORD.
 // No live payload is read before full block fill and the valid commit.
 wire [2:0] read_slot=state==IDLE?fetch_index[2:0]:wanted_index[2:0];
 wire [127:0] front_read_shot=front_shot[read_slot*128+:128],tail_read_shot=tail_shot;
 wire [95:0] front_read_fx=front_fx[read_slot*96+:96],tail_read_fx=tail_fx;
 wire [7:0] front_read_owner=front_owner[read_slot*8+:8],tail_read_owner=tail_owner;
 assign m_arvalid=state==RD_ADDR;
 assign m_rready=state==RD_DATA||state==RD_DRAIN;
 assign m_awvalid=state==WR_ADDR;
 assign m_wvalid=state==WR_DATA;
 assign m_wlast=write_position==write_chunk-1'b1;
 assign m_bready=state==WR_RESP;
 function automatic [3:0] bounded_burst(input [31:0] address,input [3:0] count);
  reg [8:0] boundary;
  begin boundary=9'd256-{1'b0,address[11:4]};bounded_burst=boundary<count?boundary[3:0]:count;end
 endfunction
 task automatic rd(input [31:0] address,input [3:0] count,input [1:0] kind,input [4:0] next_state);
 begin m_araddr<=address;m_arlen<=bounded_burst(address,count)-1'b1;burst_count<=bounded_burst(address,count);burst_position<=0;beats<=count;beat<=0;target<=kind;bad_read<=0;ret<=next_state;state<=RD_ADDR;end
 endtask
 task automatic wr(input [31:0] address,input [127:0] data,input [15:0] strobe,input [4:0] next_state);
 begin m_awaddr<=address;m_awlen<=0;m_wdata<=data;m_wstrb<=strobe;write_index<=0;write_beats<=1;write_chunk<=1;write_position<=0;write_kind<=0;write_masks<={112'b0,strobe};ret<=next_state;state<=WR_ADDR;end
 endtask
 function automatic [31:0] fx_bank0(input [3:0] row);
  begin case(row)
   4'd0:fx_bank0=front_fx[0+:32];
   4'd1:fx_bank0=front_fx[128+:32];
   4'd2:fx_bank0=front_fx[256+:32];
   4'd3:fx_bank0=front_fx[384+:32];
   4'd4:fx_bank0=front_fx[512+:32];
   4'd5:fx_bank0=front_fx[640+:32];
   default:fx_bank0=0;endcase end
 endfunction
 function automatic [31:0] fx_bank1(input [3:0] row);
  begin case(row)
   4'd0:fx_bank1=front_fx[32+:32];
   4'd1:fx_bank1=front_fx[160+:32];
   4'd2:fx_bank1=front_fx[288+:32];
   4'd3:fx_bank1=front_fx[416+:32];
   4'd4:fx_bank1=front_fx[544+:32];
   4'd5:fx_bank1=front_fx[672+:32];
   default:fx_bank1=0;endcase end
 endfunction
 function automatic [31:0] fx_bank2(input [3:0] row);
  begin case(row)
   4'd0:fx_bank2=front_fx[64+:32];
   4'd1:fx_bank2=front_fx[192+:32];
   4'd2:fx_bank2=front_fx[320+:32];
   4'd3:fx_bank2=front_fx[448+:32];
   4'd4:fx_bank2=front_fx[576+:32];
   4'd5:fx_bank2=front_fx[704+:32];
   default:fx_bank2=0;endcase end
 endfunction
 function automatic [31:0] fx_bank3(input [3:0] row);
  begin case(row)
   4'd0:fx_bank3=front_fx[96+:32];
   4'd1:fx_bank3=front_fx[224+:32];
   4'd2:fx_bank3=front_fx[352+:32];
   4'd3:fx_bank3=front_fx[480+:32];
   4'd4:fx_bank3=front_fx[608+:32];
   4'd5:fx_bank3=front_fx[736+:32];
   default:fx_bank3=0;endcase end
 endfunction
 // Read each fixed modulo4 bank once, then rotate only128bits.
 // offset is the GLOBAL write beat; it is not reset on a4KiB split.
 function automatic [127:0] cache_word(input [1:0] kind,input [3:0] offset);
  reg [31:0] a,b,c,d;
  begin
   a=fx_bank0(offset);
   b=fx_bank1(offset-{3'b0,(effects_base[3:2]==3)});
   c=fx_bank2(offset-{3'b0,(effects_base[3:2]>=2)});
   d=fx_bank3(offset-{3'b0,(effects_base[3:2]>=1)});
   case(kind)
    1:cache_word=front_shot[offset[2:0]*128+:128];
    2:case(effects_base[3:2])
      0:cache_word={d,c,b,a};1:cache_word={c,b,a,d};
      2:cache_word={b,a,d,c};default:cache_word={a,d,c,b};endcase
    default:cache_word=offset[0]?aligned_owner[128+:128]:aligned_owner[0+:128];
   endcase
  end
 endfunction
 task automatic wr_cache(input [31:0] address,input [3:0] count,input [1:0] kind,input [127:0] masks,input [4:0] next_state);
 begin
  m_awaddr<=address;m_awlen<=bounded_burst(address,count)-1'b1;
  m_wdata<=cache_word(kind,0);m_wstrb<=masks[0+:16];
  write_index<=0;write_beats<=count;write_chunk<=bounded_burst(address,count);write_position<=0;
  write_kind<=kind;write_masks<=masks;ret<=next_state;state<=WR_ADDR;
 end endtask
 reg [127:0] shot_masks;
 always @*begin for(integer s=0;s<8;s=s+1)shot_masks[s*16+:16]=shot_dirty[s]?16'hffff:16'h0000;end
 integer k;
 always @(posedge clk)begin
  if(!resetn)begin
   state<=IDLE;ret<=IDLE;ack<=0;busy<=0;error<=0;front_valid<=0;tail_valid<=0;
   shot_dirty<=0;fx_dirty<=0;owner_dirty<=0;pending_fetch<=0;pending_tail<=0;load_tail<=0;
   front_block<=0;tail_index<=0;wanted_block<=0;wanted_index<=0;
   // Payload reset deliberately omitted: reset/invalidate clear all valid and
   // dirty state; complete eight-record loads precede the sole valid commit.
   // On R/B fault the parent fails closed and never consumes/publishes payload.
   block_shots<=0;block_effects<=0;block_owners<=0;fx_offset<=0;owner_offset<=0;front_owner_offset<=0;tail_owner_offset<=0;
   beat<=0;beats<=0;burst_count<=0;burst_position<=0;load_kind<=0;target<=0;bad_read<=0;
   write_index<=0;write_beats<=0;write_chunk<=0;write_position<=0;write_kind<=0;write_masks<=0;
   record_shot<=0;record_effect<=0;record_owner<=0;raw_result<=0;
   m_araddr<=0;m_arlen<=0;m_awaddr<=0;m_awlen<=0;m_wdata<=0;m_wstrb<=0;
   read_bytes<=0;write_bytes<=0;stall_cycles<=0;
  end else begin
   ack<=0;
   if((m_arvalid&&!m_arready)||(m_rready&&!m_rvalid)||(m_awvalid&&!m_awready)||(m_wvalid&&!m_wready)||(m_bready&&!m_bvalid))stall_cycles<=stall_cycles+1;
   case(state)
    IDLE:begin
     if(invalidate)begin front_valid<=0;tail_valid<=0;shot_dirty<=0;fx_dirty<=0;owner_dirty<=0;error<=0;read_bytes<=0;write_bytes<=0;stall_cycles<=0;end
     if(raw)begin busy<=1;if(raw_write)wr({raw_address[31:4],4'b0},raw_data,raw_strobe,FINISH);else rd({raw_address[31:4],4'b0},1,0,FINISH);end
     else if(store)begin
      if(!front_valid||store_index[14:3]!=front_block)begin error<=1;state<=FINISH;busy<=1;end
      else begin
       for(k=0;k<8;k=k+1)if(store_index[2:0]==k)begin
        if(store_shot_dirty)begin front_shot[k*128+:128]<=store_shot;shot_dirty[k]<=1;end
        if(store_effect_dirty!=0)begin front_fx[k*96+:96]<=store_effect;fx_dirty[k*12+:12]<=fx_dirty[k*12+:12]|store_effect_dirty;end
        if(store_owner_dirty)begin front_owner[k*8+:8]<=store_owner;owner_dirty[k]<=1;end
       end
       ack<=1;
      end
     end else if(fetch)begin
      if(front_valid&&fetch_index[14:3]==front_block)begin
       record_shot<=front_read_shot;
       record_effect<=front_read_fx;
       record_owner<=front_read_owner;ack<=1;
      end else if(fetch_tail&&tail_valid&&fetch_index==tail_index)begin
       record_shot<=tail_read_shot;
       record_effect<=tail_read_fx;
       record_owner<=tail_read_owner;ack<=1;
      end else begin busy<=1;pending_fetch<=1;pending_tail<=fetch_tail;wanted_index<=fetch_index;wanted_block<=fetch_index[14:3];state<=SELECT;end
     end else if(flush)begin busy<=1;pending_fetch<=0;beat<=0;state<=FLUSH_SHOT;end
    end
    SELECT:begin
     // Current front always wins over an older tail copy, including last==i.
     if(front_valid&&wanted_block==front_block)begin load_tail<=0;state<=RETURN_RECORD;end
     else if(pending_tail&&tail_valid&&wanted_index==tail_index)begin load_tail<=1;state<=RETURN_RECORD;end
     else if(pending_tail)begin
      // Tail misses fetch exactly one record, tagged by its complete index.
      // Never advertise a new tail tag until its entire checked load completes.
      load_tail<=1;tail_valid<=0;tail_index<=wanted_index;
      block_shots<=shots_base+({17'b0,wanted_index}<<4);
      block_effects<=effects_base+({17'b0,wanted_index}*32'd12);
      block_owners<=owners_base+{17'b0,wanted_index};
      fx_offset<=(effects_base+({17'b0,wanted_index}*32'd12))&15;
      owner_offset<=(owners_base+{17'b0,wanted_index})&15;
      tail_owner_offset<=(owners_base+{17'b0,wanted_index})&15;state<=LOAD_SHOT;
     end else if(front_valid&&(shot_dirty!=0||fx_dirty!=0||owner_dirty!=0))begin beat<=0;state<=FLUSH_SHOT;end
     else begin
      load_tail<=0;front_block<=wanted_block;block_shots<=shots_base+({17'b0,wanted_block,3'b0}<<4);
      block_effects<=effects_base+({17'b0,wanted_block,3'b0}*12);block_owners<=owners_base+{17'b0,wanted_block,3'b0};
      fx_offset<=effects_base[3:0];owner_offset<=(owners_base+{17'b0,wanted_block,3'b0})&15;front_owner_offset<=(owners_base+{17'b0,wanted_block,3'b0})&15;state<=LOAD_SHOT;
     end
    end
    FLUSH_SHOT:begin
     if(shot_dirty!=0)begin
      wr_cache(shots_base+({17'b0,front_block,3'b0}<<4),8,1,shot_masks,FLUSH_FX);shot_dirty<=0;
     end else state<=FLUSH_FX;
    end
    FLUSH_FX:begin
     if(fx_dirty!=0)begin
      wr_cache((effects_base+({17'b0,front_block,3'b0}*12))&32'hfffffff0,effects_base[3:0]==0?6:7,2,{16'b0,aligned_fx_masks},FLUSH_OWNER);fx_dirty<=0;
     end else state<=FLUSH_OWNER;
    end
    FLUSH_OWNER:begin
     if(owner_dirty!=0)begin
      wr_cache((owners_base+{17'b0,front_block,3'b0})&32'hfffffff0,front_owner_offset>8?2:1,3,{96'b0,aligned_owner_masks},FLUSH_OWNER);owner_dirty<=0;
     end else begin
      if(pending_fetch)begin front_valid<=0;state<=SELECT;end else state<=FINISH;
     end
    end
    LOAD_SHOT:rd(block_shots,load_tail?4'd1:4'd8,1,LOAD_FX);
    LOAD_FX:rd(block_effects&32'hfffffff0,load_tail?(fx_offset>4?4'd2:4'd1):(fx_offset==0?4'd6:4'd7),2,LOAD_OWNER);
    LOAD_OWNER:rd(block_owners&32'hfffffff0,load_tail?4'd1:(owner_offset>8?4'd2:4'd1),3,RETURN_RECORD);
    RETURN_RECORD:begin
     if(load_tail)begin tail_valid<=1;record_shot<=tail_read_shot;record_effect<=tail_read_fx;record_owner<=tail_read_owner;end
     else begin front_valid<=1;record_shot<=front_read_shot;record_effect<=front_read_fx;record_owner<=front_read_owner;end
     pending_fetch<=0;state<=FINISH;
    end
    RD_ADDR:if(m_arready)state<=RD_DATA;
    RD_DATA:if(m_rvalid)begin
     read_bytes<=read_bytes+16;
     if(target==0)raw_result<=m_rdata;
     else if(target==1)begin
      if(load_tail)tail_shot<=m_rdata;
      else for(k=0;k<8;k=k+1)if(beat==k)front_shot[k*128+:128]<=m_rdata;
     end else if(target==2)begin
      if(load_tail)begin
       for(k=0;k<3;k=k+1)if(beat==((k+fx_offset[3:2])>>2))
        tail_fx[k*32+:32]<=m_rdata[((k+fx_offset[3:2])&3)*32+:32];
      end else begin
       for(k=0;k<24;k=k+1)if(beat==((k+effects_base[3:2])>>2))
        front_fx[k*32+:32]<=m_rdata[((k+effects_base[3:2])&3)*32+:32];
      end
     end else begin
      if(load_tail)tail_owner<=m_rdata[owner_offset*8+:8];
      else for(k=0;k<8;k=k+1)if(beat==((k+owner_offset)>>4))
       front_owner[k*8+:8]<=m_rdata[((k+owner_offset)&15)*8+:8];
     end
     if(m_rresp!=0||m_rlast!=(burst_position==burst_count-1))begin
      error<=1;bad_read<=1;
      if(m_rlast)state<=FINISH;else state<=RD_DRAIN;
     end else if(beat==beats-1)state<=ret;
     else if(burst_position==burst_count-1)begin
      beat<=beat+1;burst_position<=0;m_araddr<=m_araddr+(burst_count<<4);
      burst_count<=bounded_burst(m_araddr+(burst_count<<4),beats-beat-1'b1);
      m_arlen<=bounded_burst(m_araddr+(burst_count<<4),beats-beat-1'b1)-1'b1;state<=RD_ADDR;
     end else begin beat<=beat+1;burst_position<=burst_position+1;end
    end
    RD_DRAIN:if(m_rvalid)begin read_bytes<=read_bytes+16;if(m_rlast)state<=FINISH;end
    WR_ADDR:if(m_awready)state<=WR_DATA;
    WR_DATA:if(m_wready)begin
     write_bytes<=write_bytes+16;
     if(write_index!=write_beats-1)begin m_wdata<=cache_word(write_kind,write_index+1'b1);m_wstrb<=write_masks[(write_index+1'b1)*16+:16];end
     if(m_wlast)state<=WR_RESP;
     else begin write_index<=write_index+1'b1;write_position<=write_position+1'b1;end
    end
    WR_RESP:if(m_bvalid)begin
     if(m_bresp!=0)begin error<=1;state<=FINISH;end
     else if(write_index==write_beats-1)state<=ret;
     else begin
      write_index<=write_index+1'b1;write_position<=0;m_awaddr<=m_awaddr+(write_chunk<<4);
      write_chunk<=bounded_burst(m_awaddr+(write_chunk<<4),write_beats-write_index-1'b1);
      m_awlen<=bounded_burst(m_awaddr+(write_chunk<<4),write_beats-write_index-1'b1)-1'b1;state<=WR_ADDR;
     end
    end
    FINISH:begin busy<=0;ack<=1;state<=IDLE;end
    default:begin error<=1;state<=FINISH;end
   endcase
  end
 end
endmodule
