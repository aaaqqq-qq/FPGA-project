module render_engine (
    input wire clk, resetn, start,
    input wire [1:0] op,
    input wire [31:0] src_addr, dst_addr, src_stride, dst_stride,
    input wire [15:0] width, height,
    input wire [31:0] fill_color,
    input wire [7:0] alpha,
    input wire [23:0] color_key,
    input wire alpha_enable, key_enable, batch32_enable,preflight_enable,preflight8_enable,
    output wire snapshot_decided,snapshot_no_draw,snapshot_ready_pulse,
    input wire r_pipe_start,m_pipe_start,input wire [31:0] m_pipe_job,m_pipe_epoch,
    output wire r_busy,r_done,r_error,m_busy,m_done,m_error,axi_protocol_error,
    output wire [31:0] r_cycles,r_read_bytes,r_write_bytes,m_cycles,m_read_bytes,m_write_bytes,
    input wire [7:0] tile_first,input wire [14:0] sprite_count,input wire [31:0] texture_addr,
    output wire busy, done, error,
    output wire [31:0] cycles, read_bytes, write_bytes,
    output wire [31:0] m_awaddr,
    output wire [7:0] m_awlen,
    output wire m_awvalid,
    input wire m_awready,
    output wire [127:0] m_wdata,
    output wire [15:0] m_wstrb,
    output wire m_wlast,
    output wire m_wvalid,
    input wire m_wready,
    input wire [1:0] m_bresp,
    input wire m_bvalid,
    output wire m_bready,
    output wire [31:0] m_araddr,
    output wire [7:0] m_arlen,
    output wire m_arvalid,
    input wire m_arready,
    input wire [127:0] m_rdata,
    input wire [1:0] m_rresp,
    input wire m_rlast, m_rvalid,
    output wire m_rready
);
reg batch_selected,motion_selected,legacy_inflight,r_pipe_context,r_released;
wire legacy_busy,batch_busy,motion_busy,legacy_done,batch_done,motion_done,legacy_error,batch_error,motion_error;
wire [31:0] legacy_cycles,batch_cycles,motion_cycles,legacy_read_bytes,batch_read_bytes,motion_read_bytes,legacy_write_bytes,batch_write_bytes,motion_write_bytes;
assign r_busy=legacy_busy|batch_busy;assign m_busy=motion_busy;assign busy=r_busy|m_busy;
wire accepted_start=start&&!busy;
wire motion_command=op==3&&width==1&&height==1;
// Unconnected PIPE inputs on legacy named-port test harnesses are inert; all
// real fabric connections are explicit0/1. Never normalize AXI data/status.
wire pipe_r_request=r_pipe_start===1'b1,pipe_m_request=m_pipe_start===1'b1;
wire legacy_r_start=accepted_start&&!motion_command;
wire legacy_m_start=accepted_start&&motion_command;
wire pipe_r_accept=pipe_r_request&&!busy&&!accepted_start&&op==2;
// This pulse is already ACCEPTED by APB with a locked valid snapshot token.
// A subsequent R fault may forbid future jobs/swaps, but must not swallow M.
wire pipe_m_accept=pipe_m_request&&!m_busy&&!accepted_start&&!pipe_r_accept;
wire draw_start=legacy_r_start|pipe_r_accept,motion_start=legacy_m_start|pipe_m_accept;
assign r_done=batch_selected?batch_done:legacy_done;assign r_error=batch_selected?batch_error:legacy_error;
assign r_cycles=batch_selected?batch_cycles:legacy_cycles;assign r_read_bytes=batch_selected?batch_read_bytes:legacy_read_bytes;assign r_write_bytes=batch_selected?batch_write_bytes:legacy_write_bytes;
assign m_done=motion_done;assign m_error=motion_error;assign m_cycles=motion_cycles;assign m_read_bytes=motion_read_bytes;assign m_write_bytes=motion_write_bytes;
reg [31:0] legacy_last_cycles,legacy_last_read,legacy_last_write;reg legacy_last_error;
wire legacy_terminal=legacy_inflight&&(motion_selected?motion_done:r_done);
assign done=legacy_terminal;
assign error=legacy_inflight?(motion_selected?motion_error:r_error):legacy_last_error;
assign cycles=legacy_inflight?(motion_selected?motion_cycles:r_cycles):legacy_last_cycles;
assign read_bytes=legacy_inflight?(motion_selected?motion_read_bytes:r_read_bytes):legacy_last_read;
assign write_bytes=legacy_inflight?(motion_selected?motion_write_bytes:r_write_bytes):legacy_last_write;
always @(posedge clk)begin
 if(!resetn)begin batch_selected<=0;motion_selected<=0;legacy_inflight<=0;r_pipe_context<=0;r_released<=0;legacy_last_cycles<=0;legacy_last_read<=0;legacy_last_write<=0;legacy_last_error<=0;end
 else begin
  if(draw_start)begin batch_selected<=op==2;r_pipe_context<=pipe_r_accept;r_released<=0;end
  else if(r_pipe_context&&snapshot_ready_pulse)r_released<=1;
  if((r_error&&(r_busy||r_done))||(m_error&&(m_busy||m_done))||axi_protocol_error)r_released<=0;
  if(accepted_start)begin legacy_inflight<=1;motion_selected<=motion_command;if(motion_command)batch_selected<=0;end
  else if(legacy_terminal)begin
   legacy_inflight<=0;legacy_last_cycles<=motion_selected?motion_cycles:r_cycles;legacy_last_read<=motion_selected?motion_read_bytes:r_read_bytes;
   legacy_last_write<=motion_selected?motion_write_bytes:r_write_bytes;legacy_last_error<=motion_selected?motion_error:r_error;
  end
 end
end
wire [31:0] legacy_m_awaddr,batch_m_awaddr,motion_m_awaddr;
wire [31:0] legacy_m_araddr,batch_m_araddr,motion_m_araddr;
wire [7:0] legacy_m_awlen,batch_m_awlen,motion_m_awlen;
wire [7:0] legacy_m_arlen,batch_m_arlen,motion_m_arlen;
wire legacy_m_awvalid,batch_m_awvalid,motion_m_awvalid;
wire legacy_m_wlast,batch_m_wlast,motion_m_wlast;
wire legacy_m_wvalid,batch_m_wvalid,motion_m_wvalid;
wire legacy_m_bready,batch_m_bready,motion_m_bready;
wire legacy_m_arvalid,batch_m_arvalid,motion_m_arvalid;
wire legacy_m_rready,batch_m_rready,motion_m_rready;
wire [127:0] legacy_m_wdata,batch_m_wdata,motion_m_wdata;
wire [15:0] legacy_m_wstrb,batch_m_wstrb,motion_m_wstrb;
wire [31:0] draw_m_awaddr=batch_selected?batch_m_awaddr:legacy_m_awaddr;
wire [31:0] draw_m_araddr=batch_selected?batch_m_araddr:legacy_m_araddr;
wire [7:0] draw_m_awlen=batch_selected?batch_m_awlen:legacy_m_awlen;
wire [7:0] draw_m_arlen=batch_selected?batch_m_arlen:legacy_m_arlen;
wire draw_m_awvalid=batch_selected?batch_m_awvalid:legacy_m_awvalid;
wire draw_m_wlast=batch_selected?batch_m_wlast:legacy_m_wlast;
wire draw_m_wvalid=batch_selected?batch_m_wvalid:legacy_m_wvalid;
wire draw_m_bready=batch_selected?batch_m_bready:legacy_m_bready;
wire draw_m_arvalid=batch_selected?batch_m_arvalid:legacy_m_arvalid;
wire draw_m_rready=batch_selected?batch_m_rready:legacy_m_rready;
wire [127:0] draw_m_wdata=batch_selected?batch_m_wdata:legacy_m_wdata;
wire [15:0] draw_m_wstrb=batch_selected?batch_m_wstrb:legacy_m_wstrb;
wire draw_awready,draw_wready,draw_bvalid,draw_arready,draw_rlast,draw_rvalid;
wire motion_awready,motion_wready,motion_bvalid,motion_arready,motion_rlast,motion_rvalid;
wire [127:0] draw_rdata,motion_rdata;wire [1:0] draw_rresp,motion_rresp,draw_bresp,motion_bresp;
wire [1:0] arb_awready,arb_wready,arb_bvalid,arb_arready,arb_rlast,arb_rvalid;
wire [255:0] arb_rdata;wire [3:0] arb_rresp,arb_bresp;
assign {motion_awready,draw_awready}=arb_awready;assign {motion_wready,draw_wready}=arb_wready;
assign {motion_bvalid,draw_bvalid}=arb_bvalid;assign {motion_bresp,draw_bresp}=arb_bresp;
assign {motion_arready,draw_arready}=arb_arready;assign {motion_rvalid,draw_rvalid}=arb_rvalid;
assign {motion_rlast,draw_rlast}=arb_rlast;assign {motion_rresp,draw_rresp}=arb_rresp;assign {motion_rdata,draw_rdata}=arb_rdata;
render_axi_arbiter busarb(.clk(clk),.resetn(resetn),
 .s_awaddr({motion_m_awaddr,draw_m_awaddr}),.s_awlen({motion_m_awlen,draw_m_awlen}),.s_awvalid({motion_m_awvalid,draw_m_awvalid}),.s_awready(arb_awready),
 .s_wdata({motion_m_wdata,draw_m_wdata}),.s_wstrb({motion_m_wstrb,draw_m_wstrb}),.s_wlast({motion_m_wlast,draw_m_wlast}),.s_wvalid({motion_m_wvalid,draw_m_wvalid}),.s_wready(arb_wready),
 .s_bresp(arb_bresp),.s_bvalid(arb_bvalid),.s_bready({motion_m_bready,draw_m_bready}),
 .s_araddr({motion_m_araddr,draw_m_araddr}),.s_arlen({motion_m_arlen,draw_m_arlen}),.s_arvalid({motion_m_arvalid,draw_m_arvalid}),.s_arready(arb_arready),
 .s_rdata(arb_rdata),.s_rresp(arb_rresp),.s_rlast(arb_rlast),.s_rvalid(arb_rvalid),.s_rready({motion_m_rready,draw_m_rready}),
 .m_awaddr(m_awaddr),.m_awlen(m_awlen),.m_awvalid(m_awvalid),.m_awready(m_awready),
 .m_wdata(m_wdata),.m_wstrb(m_wstrb),.m_wlast(m_wlast),.m_wvalid(m_wvalid),.m_wready(m_wready),
 .m_bresp(m_bresp),.m_bvalid(m_bvalid),.m_bready(m_bready),
 .m_araddr(m_araddr),.m_arlen(m_arlen),.m_arvalid(m_arvalid),.m_arready(m_arready),
 .m_rdata(m_rdata),.m_rresp(m_rresp),.m_rlast(m_rlast),.m_rvalid(m_rvalid),.m_rready(m_rready),.protocol_error(axi_protocol_error));
bitblt_engine legacy(
 .clk(clk),
 .resetn(resetn),
 .start(draw_start && op!=2),
 .op(op),
 .src_addr(src_addr),
 .dst_addr(dst_addr),
 .src_stride(src_stride),
 .dst_stride(dst_stride),
 .width(width),
 .height(height),
 .fill_color(fill_color),
 .alpha(alpha),
 .color_key(color_key),
 .alpha_enable(alpha_enable),
 .key_enable(key_enable),
 .m_awready(draw_awready && !batch_selected),
 .m_wready(draw_wready && !batch_selected),
 .m_bresp(draw_bresp),
 .m_bvalid(draw_bvalid && !batch_selected),
 .m_arready(draw_arready && !batch_selected),
 .m_rdata(draw_rdata),
 .m_rresp(draw_rresp),
 .m_rlast(draw_rlast),
 .m_rvalid(draw_rvalid && !batch_selected),
 .busy(legacy_busy),
 .done(legacy_done),
 .error(legacy_error),
 .cycles(legacy_cycles),
 .read_bytes(legacy_read_bytes),
 .write_bytes(legacy_write_bytes),
 .m_awaddr(legacy_m_awaddr),
 .m_awlen(legacy_m_awlen),
 .m_awvalid(legacy_m_awvalid),
 .m_wdata(legacy_m_wdata),
 .m_wstrb(legacy_m_wstrb),
 .m_wlast(legacy_m_wlast),
 .m_wvalid(legacy_m_wvalid),
 .m_bready(legacy_m_bready),
 .m_araddr(legacy_m_araddr),
 .m_arlen(legacy_m_arlen),
 .m_arvalid(legacy_m_arvalid),
 .m_rready(legacy_m_rready)
);
sprite_batch_engine batch(
 .batch32_enable(batch32_enable),.preflight_enable(preflight_enable),.preflight8_enable(preflight8_enable),
 .snapshot_decided(snapshot_decided),.snapshot_no_draw(snapshot_no_draw),.snapshot_ready_pulse(snapshot_ready_pulse),
 .clk(clk),
 .resetn(resetn),
 .start(draw_start && op==2),
 .src_addr(src_addr),
 .dst_addr(dst_addr),
 .src_stride(src_stride),
 .dst_stride(dst_stride),
 .width(width),
 .height(height),
 .alpha(alpha),
 .color_key(color_key),
 .alpha_enable(alpha_enable),
 .key_enable(key_enable),
 .m_awready(draw_awready && batch_selected),
 .m_wready(draw_wready && batch_selected),
 .m_bresp(draw_bresp),
 .m_bvalid(draw_bvalid && batch_selected),
 .m_arready(draw_arready && batch_selected),
 .m_rdata(draw_rdata),
 .m_rresp(draw_rresp),
 .m_rlast(draw_rlast),
 .m_rvalid(draw_rvalid && batch_selected),
 .sprite_count(sprite_count),
 .descriptor_addr(fill_color),
 .tile_first(tile_first),
 .texture_addr(texture_addr),
 .busy(batch_busy),
 .done(batch_done),
 .error(batch_error),
 .cycles(batch_cycles),
 .read_bytes(batch_read_bytes),
 .write_bytes(batch_write_bytes),
 .m_awaddr(batch_m_awaddr),
 .m_awlen(batch_m_awlen),
 .m_awvalid(batch_m_awvalid),
 .m_wdata(batch_m_wdata),
 .m_wstrb(batch_m_wstrb),
 .m_wlast(batch_m_wlast),
 .m_wvalid(batch_m_wvalid),
 .m_bready(batch_m_bready),
 .m_araddr(batch_m_araddr),
 .m_arlen(batch_m_arlen),
 .m_arvalid(batch_m_arvalid),
 .m_rready(batch_m_rready)
);
motion_engine motion(
 .clk(clk),
 .resetn(resetn),
 .start(motion_start),
 .job_address(pipe_m_accept?m_pipe_job:fill_color),
 .epoch_check(pipe_m_accept),.expected_epoch(m_pipe_epoch),
 .m_awready(motion_awready),
 .m_wready(motion_wready),
 .m_bresp(motion_bresp),
 .m_bvalid(motion_bvalid),
 .m_arready(motion_arready),
 .m_rdata(motion_rdata),
 .m_rresp(motion_rresp),
 .m_rlast(motion_rlast),
 .m_rvalid(motion_rvalid),
 .busy(motion_busy),
 .done(motion_done),
 .error(motion_error),
 .cycles(motion_cycles),
 .read_bytes(motion_read_bytes),
 .write_bytes(motion_write_bytes),
 .m_awaddr(motion_m_awaddr),
 .m_awlen(motion_m_awlen),
 .m_awvalid(motion_m_awvalid),
 .m_wdata(motion_m_wdata),
 .m_wstrb(motion_m_wstrb),
 .m_wlast(motion_m_wlast),
 .m_wvalid(motion_m_wvalid),
 .m_bready(motion_m_bready),
 .m_araddr(motion_m_araddr),
 .m_arlen(motion_m_arlen),
 .m_arvalid(motion_m_arvalid),
 .m_rready(motion_m_rready)
);
endmodule
