#include "bitblt.h"

static int in_ddr(uint32_t address, uint32_t stride, uint32_t w, uint32_t h,
                  uint64_t *end) {
    /* Exclude the reserved first MiB and MMIO. Demo pools start at 16 MiB. */
    if ((address & 3u) || (stride & 3u) || address < 0x00100000u) return 0;
    if (h > 1u && stride < w * 4u) return 0;
    *end = (uint64_t)address + (uint64_t)(h - 1u) * stride + (uint64_t)w * 4u;
    return *end <= BB_DDR_END;
}
bb_result bb_validate(const bb_job *j) {
    uint64_t src_end = 0, dst_end = 0;
    if (!j || j->op > BB_COPY_OP || j->alpha > 255u || (j->flags & ~3u))
        return BB_E_ARGUMENT;
    if (!j->width || !j->height) return BB_OK;
    /* APB WIDTH/HEIGHT are 16-bit; reject a nonempty height before truncation. */
    if (j->width > 1024u || j->height > 65535u) return BB_E_ARGUMENT;
    if (!in_ddr(j->dst, j->dst_stride, j->width, j->height, &dst_end))
        return BB_E_RANGE;
    if (j->op == BB_COPY_OP) {
        if (!in_ddr(j->src, j->src_stride, j->width, j->height, &src_end))
            return BB_E_RANGE;
        if (j->src == j->dst && j->src_stride == j->dst_stride && !j->flags)
            return BB_OK;
        /* Conservative span overlap check: never issue an unsafe in-place DMA. */
        if ((uint64_t)j->src < dst_end && (uint64_t)j->dst < src_end)
            return BB_E_OVERLAP;
    } else if (j->flags) return BB_E_ARGUMENT;
    return BB_OK;
}
uint32_t bb_blend(uint32_t s, uint32_t d, unsigned a) {
    uint32_t result = 0;
    if (!a) return d;
    if (a == 255u) return s;
    for (unsigned shift = 0; shift < 24; shift += 8) {
        unsigned v = (((s >> shift) & 255u) * a +
                      ((d >> shift) & 255u) * (255u - a) + 127u) / 255u;
        result |= v << shift;
    }
    return result;
}
