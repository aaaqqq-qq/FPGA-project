#include "tick_profile.h"
#include "segment_diag_impl.inc"
#if TICK_PROFILE_REAL
#include <string.h>
#ifdef __riscv
#include "bsp.h"
#define TP_TIMER_HZ BSP_CLINT_HZ
#else
#ifndef TICK_PROFILE_HOST_HZ
#define TICK_PROFILE_HOST_HZ 1000000u
#endif
#define TP_TIMER_HZ TICK_PROFILE_HOST_HZ
#endif
unsigned tick_profile_active;
static unsigned enabled,epoch,read_min,read_max,overflow;
static TickPhase phases[TP_PHASES];
void tick_profile_restart(void){
 if(!enabled)return;
 memset(phases,0,sizeof phases);overflow=0;++epoch;tick_profile_active=1;
}
void tick_profile_enable(unsigned value){
 tick_profile_active=0;enabled=!!value;segment_diag_enable(value);
 if(enabled){
  read_min=UINT32_MAX;read_max=0;
  /* A lower-bound timer-read interval, not a total-overhead estimate. Never
     subtract it from measured durations. Calibration is menu-only. */
  for(unsigned i=0;i<16;++i){uint64_t a=bb_ticks(),b=bb_ticks();uint64_t dt=b-a;unsigned d=dt>UINT32_MAX?UINT32_MAX:(unsigned)dt;if(d<read_min)read_min=d;if(d>read_max)read_max=d;}
  tick_profile_restart();
 }
}
void tick_profile_stop(void){tick_profile_active=0;segment_diag_stop();}
TickProfileInfo tick_profile_info(void){TickProfileInfo p={enabled,tick_profile_active,epoch,TP_TIMER_HZ,read_min,read_max,overflow};return p;}
TickPhase tick_profile_phase(unsigned phase){TickPhase p={0};return phase<TP_PHASES?phases[phase]:p;}
void tick_profile_record(unsigned phase,uint64_t elapsed){
 if(phase>=TP_PHASES||!tick_profile_active)return;
 TickPhase *p=&phases[phase];
 if(UINT64_MAX-p->sum<elapsed){p->sum=UINT64_MAX;overflow=1;}else p->sum+=elapsed;
 if(elapsed>UINT32_MAX){elapsed=UINT32_MAX;overflow=1;}
 p->last=(uint32_t)elapsed;if(p->last>p->maximum)p->maximum=p->last;
 if(p->calls==UINT32_MAX)overflow=1;else ++p->calls;
}
#endif
