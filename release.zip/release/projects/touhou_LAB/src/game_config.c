#include "game_config.h"
#include <stddef.h>
#include <string.h>

GameConfig game_cfg;
unsigned hud_dma_tail_enabled;

void game_config_defaults(void) {
    GameConfig c = {
        3,                  /* boss_count */
        3000,               /* boss_max_hp */
        1500,               /* boss_half_hp */
        36,                 /* enrage_intro_ticks */
        72,                 /* enter_ticks */
        512,                /* first_burst */
        256,                /* other_burst */
        1,                  /* refill_first */
        0,                  /* refill_others (first version) */
        7, 5,               /* enrage_fire 1.4x */
        5, 4,               /* enrage_move 1.25x */
        3, 2,               /* enrage bullets 1.5x */
        4,                  /* burst_rings */
        8192, 2048,         /* burst speed Q12 */
        100,                /* player_max_hp */
        15,                 /* player_hit_damage */
        48,                 /* hit_invuln_ticks */
        120,                /* spawn_invuln_ticks */
        120,                /* bomb_invuln_ticks */
        120,                /* bomb_damage */
        300,                /* regen_wait_ticks */
        60,                 /* regen_period_ticks */
        5,                  /* regen_amount */
        48,                 /* upgrade_ticks */
        48,                 /* upgrade_invuln_ticks */
        18,                 /* hp_delay_ticks */
        4,                  /* hp_drop_rate */
        128,                /* player_shot_cap */
        180,                /* player_shot_life */
        5,                  /* player_shot_damage */
        18,                 /* player_shot_speed */
        15,                 /* homing_shot_speed */
        5,                  /* max_level */
        {0, 0, 1000, 3500, 7000, 12000},
        {0, 1, 3, 3, 5, 7},
        {0, 0, 0, 2, 2, 4},
        5,                  /* main_fire_period */
        15,                 /* homing_fire_period */
        1,                  /* damage_score */
        2000,               /* boss_kill_score */
        10,                 /* graze_score */
        12,                 /* effect_job_budget */
        16384,              /* effect_area_budget */
        60000,              /* bullet_age_max */
        60,                 /* logic_hz */
        2,                  /* logic_max_catchup */
        .adaptive_density=1,.density_high_pct=80,.density_low_pct=70,
        .density_slow_num=1,.density_slow_den=2,
        .boss_profiles_enabled=1,
        .boss_fire_num={7,7,7,7,7,7},.boss_fire_den={5,5,5,5,5,5},
        .boss_move_num={5,5,3,5,5,3},.boss_move_den={4,4,2,4,4,2},
        .boss_bullets_num={3,2,3,3,2,3},.boss_bullets_den={2,1,2,2,1,2},
        .boss_burst_rings={6,4,4,6,4,4},.boss_burst_scale_num={3,1,1,3,1,1},.boss_burst_scale_den={2,1,1,2,1,1},
        .homing_retarget_ticks=4,.near_enabled=1,
        .graze_feedback_enabled=1,.graze_feedback_cooldown=8,
        .low_hp_threshold=30,.low_hp_pulse_ticks=60,
        .death_slowmo_enabled=1,.death_slowmo_ticks=12,.death_slowmo_divisor=3,
        .death_star_budget=8,.vignette_enabled=1,.hud_dirty_enabled=1,.stress_gather_enabled=1,.stress_overlap_enabled=1,
        .enemy_count=0,.background_depth_enabled=1,
        .layer_pipeline_enabled=1,.layer_y_sort=1,.layer_visuals_enabled=1,
        .layer_order={10,20,30,40,50,60,70,80},.layer_visuals_strength=2,
        .battle_gather_enabled=1,.opaque_sprites=1,.render_budget_enabled=1,.enemy_bullet_size=8
    };
    game_cfg = c;hud_dma_tail_enabled=0;
}

/* No hardware clocks, DDR addresses or array capacities are mutable here.
 * Topology setters are menu-only at the command/game integration layer. */
typedef struct { const char *name; size_t offset; unsigned lo,hi; } ConfigField;
#define FIELD(n,lo,hi) {#n,offsetof(GameConfig,n),lo,hi}
static const ConfigField hot_fields[]={
    FIELD(boss_count,1,MAX_BOSSES),FIELD(enemy_count,0,12),FIELD(background_depth_enabled,0,1),
    FIELD(layer_pipeline_enabled,0,1),FIELD(layer_y_sort,0,1),FIELD(layer_visuals_enabled,0,1),
    FIELD(layer_visuals_strength,1,2),
    FIELD(enemy_bullet_size,8,56),FIELD(battle_gather_enabled,0,1),FIELD(opaque_sprites,0,1),FIELD(render_budget_enabled,0,1),
    FIELD(adaptive_density,0,1),FIELD(density_high_pct,1,99),FIELD(density_low_pct,0,98),
    FIELD(density_slow_num,1,16),FIELD(density_slow_den,1,16),FIELD(boss_profiles_enabled,0,1),
    FIELD(homing_retarget_ticks,1,16),FIELD(near_enabled,0,1),
    FIELD(graze_feedback_enabled,0,1),FIELD(graze_feedback_cooldown,1,600),
    FIELD(low_hp_threshold,1,100),FIELD(low_hp_pulse_ticks,8,600),
    FIELD(death_slowmo_enabled,0,1),FIELD(death_slowmo_ticks,1,180),FIELD(death_slowmo_divisor,1,8),
    FIELD(death_star_budget,0,8),FIELD(vignette_enabled,0,1),FIELD(hud_dirty_enabled,0,1),FIELD(stress_gather_enabled,0,1),FIELD(stress_overlap_enabled,0,1),
    FIELD(main_fire_period,1,120),FIELD(homing_fire_period,1,240),
    FIELD(player_shot_damage,1,100),FIELD(player_shot_life,1,600),
    FIELD(player_shot_speed,1,24),FIELD(homing_shot_speed,1,24),
    FIELD(player_hit_damage,1,100),FIELD(hit_invuln_ticks,0,600),
    FIELD(regen_wait_ticks,0,3600),FIELD(regen_period_ticks,1,600),FIELD(regen_amount,1,100),
    FIELD(effect_job_budget,0,12),FIELD(effect_area_budget,0,16384),
    FIELD(first_burst,0,4096),FIELD(other_burst,0,4096),FIELD(burst_rings,1,8)
};
#undef FIELD
static int array_index(const char *name,const char *base,unsigned max){
    size_t n=strlen(base);
    if(strncmp(name,base,n)||name[n]!='['||name[n+1]<'0'||name[n+1]>'9'||
       name[n+2]!=']'||name[n+3]!=0)return -1;
    unsigned index=(unsigned)(name[n+1]-'0');
    return index<max?(int)index:-1;
}
static int valid_hot(const GameConfig *c){
    if(c->enemy_bullet_size<8||c->enemy_bullet_size>56||(c->enemy_bullet_size&7u))return 0;
    if(c->boss_count<1||c->boss_count>MAX_BOSSES||c->enemy_count>12||c->background_depth_enabled>1)return 0;
    if(c->layer_pipeline_enabled>1||c->layer_y_sort>1||c->layer_visuals_enabled>1)return 0;
    if(c->layer_visuals_strength<1||c->layer_visuals_strength>2)return 0;
    if(c->battle_gather_enabled>1||c->opaque_sprites>1||c->render_budget_enabled>1)return 0;
    for(unsigned k=0;k<8;++k)if(c->layer_order[k]>255)return 0;
    if(c->density_low_pct>=c->density_high_pct||c->density_slow_num>c->density_slow_den)return 0;
    for(unsigned k=0;k<MAX_BOSSES;++k){
        if(!c->boss_fire_den[k]||!c->boss_move_den[k]||!c->boss_bullets_den[k]||!c->boss_burst_scale_den[k])return 0;
        if(c->boss_fire_num[k]<c->boss_fire_den[k]||c->boss_fire_num[k]>4*c->boss_fire_den[k])return 0;
        if(c->boss_move_num[k]<c->boss_move_den[k]||c->boss_move_num[k]>4*c->boss_move_den[k])return 0;
        if(c->boss_bullets_num[k]<c->boss_bullets_den[k]||c->boss_bullets_num[k]>4*c->boss_bullets_den[k])return 0;
        if(c->boss_burst_scale_num[k]<c->boss_burst_scale_den[k]||c->boss_burst_scale_num[k]>4*c->boss_burst_scale_den[k])return 0;
    }
    for(unsigned k=2;k<=5;++k)if(c->level_threshold[k]<=c->level_threshold[k-1])return 0;
    return 1;
}
int game_config_set(const char *field,unsigned value){
    if(!field||!field[0])return 0;
    if(!strcmp(field,"hud_dma_tail_enabled")){if(value>1)return 0;hud_dma_tail_enabled=value;return 1;}
    GameConfig next=game_cfg;unsigned *slot=0;
    for(unsigned i=0;i<sizeof(hot_fields)/sizeof(hot_fields[0]);++i)if(!strcmp(field,hot_fields[i].name)){
        if(value<hot_fields[i].lo||value>hot_fields[i].hi)return 0;
        slot=(unsigned *)((unsigned char *)&next+hot_fields[i].offset);break;
    }
#define ARRAY(n,max,lo,hi) if(!slot){int k=array_index(field,#n,max);if(k>=0){if(value<lo||value>hi)return 0;slot=&next.n[k];}}
    ARRAY(boss_fire_num,MAX_BOSSES,1,16);ARRAY(boss_fire_den,MAX_BOSSES,1,16);
    ARRAY(boss_move_num,MAX_BOSSES,1,16);ARRAY(boss_move_den,MAX_BOSSES,1,16);
    ARRAY(boss_bullets_num,MAX_BOSSES,1,16);ARRAY(boss_bullets_den,MAX_BOSSES,1,16);
    ARRAY(boss_burst_rings,MAX_BOSSES,1,8);ARRAY(boss_burst_scale_num,MAX_BOSSES,1,16);ARRAY(boss_burst_scale_den,MAX_BOSSES,1,16);
    ARRAY(level_threshold,6,1,1000000);
    ARRAY(layer_order,8,0,255);
#undef ARRAY
    if(!slot)return 0;
    if(!strncmp(field,"level_threshold",15)&&(slot==&next.level_threshold[0]||slot==&next.level_threshold[1]))return 0;
    *slot=value;
    if(!valid_hot(&next))return 0;
    game_cfg=next;return 1;
}
