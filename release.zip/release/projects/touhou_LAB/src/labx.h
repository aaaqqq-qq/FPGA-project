#ifndef TI60_LABX_H
#define TI60_LABX_H
#include "lab.h"
#define LABX_SOURCE0 0x02400000u
#define LABX_SOURCE1 0x02600000u
#define LABX_REFERENCE 0x02800000u
#define LABX_SNAPSHOT 0x02c00000u
#define LABX_SOURCE_SLOT 0x00200000u
#define LABX_REFERENCE_SLOT 0x00400000u
void labx_init(lab_reply_fn emit, lab_restore_fn restore);
int labx_command(const char *line);
unsigned labx_active(void);
unsigned labx_pending(void);
unsigned labx_cancelled(void);
int labx_cpu_poll(void);
void labx_service(void);
/* Cooperative UART pump; called outside measured sections, and within CPU
   rows so cancellation remains responsive. Must never dispatch game drawing. */
void labx_io_service(void);
#endif
