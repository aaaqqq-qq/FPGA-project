#ifndef ADV_MODEL_H
#define ADV_MODEL_H
#include <stdint.h>
#include <stddef.h>
#define ADV_MAX 20000u
#define ADV_PHYS_MAX 512u
#define ADV_W 1024u
#define ADV_H 512u
/* Q12 coordinates are exactly old Q8 coordinates *16. Velocities retain Q8.
   Meta is explicit, avoiding bit-field ABI assumptions. The batch RTL reads
   only x,y and byte14(color), never the mass/alive metadata or size byte. */
#define ADV_LIVE 0x8000u
#define ADV_MASS_MASK 0x7fffu
#define ADV_SHIFT 12
#define ADV_OLD_SHIFT 4
#define ADV_FRAMES_MAX 36000u
typedef struct {int32_t x,y;union {uint32_t velocity;struct {int16_t vx,vy;};};uint16_t meta;uint8_t color,size;} AdvParticle;
_Static_assert(sizeof(AdvParticle)==16 && offsetof(AdvParticle,color)==14 && offsetof(AdvParticle,size)==15,"batch-compatible particle ABI");
_Static_assert(offsetof(AdvParticle,vx)==8 && offsetof(AdvParticle,vy)==10,"velocity ABI");
static inline unsigned adv_alive(const AdvParticle *p){return (p->meta&ADV_LIVE)!=0;}
static inline unsigned adv_mass(const AdvParticle *p){return p->meta&ADV_MASS_MASK;}
void adv_particles_step_draw(AdvParticle *p,unsigned n,unsigned size);
typedef struct {uint64_t pairs,collisions,merges;unsigned count,minimum,maximum;} AdvStats;
uint32_t adv_random(uint32_t *seed);
uint32_t adv_color(uint32_t a,uint32_t b,uint32_t c,unsigned mode,unsigned index);
unsigned adv_shape(unsigned shape,unsigned size,unsigned x,unsigned y);
uint32_t adv_golden(uint32_t s,uint32_t d,unsigned alpha,uint32_t key,unsigned flags);
void adv_particles_init(AdvParticle *p,unsigned n,unsigned size,unsigned colors,uint32_t seed);
void adv_particles_step(AdvParticle *p,unsigned n,unsigned physics,AdvStats *stats);
#endif
