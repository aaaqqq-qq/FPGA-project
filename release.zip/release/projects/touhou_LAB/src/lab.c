#include "lab.h"
#include "bitblt.h"
#include <stdint.h>
#include <string.h>

/* Dedicated DDR scratch; distinct from art/background/damage and both FBs.
   Never accepts a host-supplied address. Basic 1 always flags=0 (no AB/CK). */
#define TILE_BYTES (LAB_TILE_SIZE * LAB_TILE_SIZE * 4u)
#define SOURCE_BYTES (TILE_BYTES * LAB_TILE_COUNT)
#define GUARD_WORDS 16u
#define GUARD_VALUE 0x6b4d2f19u
enum { OP_ENTER, OP_EXIT, OP_CLEAR, OP_FILL, OP_COPY, OP_PATTERN, OP_VERIFY, OP_IMGBEGIN, OP_IMGDATA, OP_IMGCOMMIT, OP_IMGCOPY, OP_IMGABORT, OP_IMGSTATUS, OP_BAD };
typedef struct { uint32_t id, a[8]; unsigned op; } LabRequest;
static LabRequest pending_request;
static unsigned active, pending, running;
static lab_reply_fn reply;
static lab_restore_fn restore_game;
static uint32_t cycles;
static const uint32_t palette[4] = {0x4c8dffu,0x7c6df0u,0x35b89bu,0xf2b65cu};
static const uint32_t bars[8] = {0xf2f2f2u,0xf1c75bu,0x42c5c2u,0x51b875u,
    0xdc6d9bu,0xe76565u,0x5788d9u,0x24262cu};
static const char *const op_names[] = {"enter","exit","clear","fill","copy","pattern","verify","imgbegin","imgdata","imgcommit","imgcopy","imgabort","imgstatus","unknown"};
static char response[512];
static struct {uint32_t session,w,h,total,received,expected_crc,stream_crc,ready;} image;
static uint32_t image_verified;
static char image_payload[385];
static unsigned response_n;

static void add(const char *s) {
    while (*s && response_n+1u < sizeof response) response[response_n++]=*s++;
    response[response_n]=0;
}
static void number(uint32_t v) {
    char b[10]; unsigned n=0;
    do { b[n++]=(char)('0'+v%10u);v/=10u; } while(v);
    while(n) { char t[2]={b[--n],0};add(t); }
}
static void start_line(const char *prefix,uint32_t id) {
    response_n=0;response[0]=0;add(prefix);add(" id=");number(id);
}
static void send_line(void) { if(reply)reply(response); }
static void done(const LabRequest *r,const char *code,uint32_t errors,uint32_t us,
                 unsigned passed,unsigned failed) {
    start_line("LAB_DONE",r->id);add(" op=");add(op_names[r->op]);
    add(code?" status=ERROR code=":" status=PASS");if(code)add(code);
    add(" errors=");number(errors);add(" us=");number(us);
    add(" hw_cycles=");number(cycles);
    add(" width=1280 height=720 refresh=60 active=");number(active);
    if(r->op==OP_VERIFY){add(" passed=");number(passed);add(" failed=");number(failed);}
    if(r->op>=OP_IMGBEGIN && r->op<=OP_IMGSTATUS){
        add(" session=");number(r->op==OP_IMGABORT&&!code?r->a[0]:image.session);add(" received=");number(image.received);add(" total=");number(image.total);
        add(" imgw=");number(image.w);add(" imgh=");number(image.h);add(" crc=");number(image.session?image.stream_crc^0xffffffffu:0);
        add(" ready=");number(image.ready);add(" verified=");number(r->op==OP_IMGCOPY&&!code?image_verified:0);
    }
    send_line();
}
static int same(const char *a,const char *b) {
    while(*a && *a==*b){++a;++b;}return *a==*b;
}
static int digit_value(char c,unsigned base) {
    if(c>='0' && c<='9')return c-'0';
    if(base==16u && c>='a' && c<='f')return c-'a'+10;
    if(base==16u && c>='A' && c<='F')return c-'A'+10;
    return -1;
}
static int parse_uint(const char *s,uint32_t *v,unsigned allow_hex) {
    unsigned base=10,n=0;uint32_t out=0;
    if(allow_hex && s[0]=='0' && (s[1]=='x'||s[1]=='X')){base=16;s+=2;}
    while(*s){int d=digit_value(*s++,base);
        if(d<0 || (unsigned)d>=base || out>(UINT32_MAX-(unsigned)d)/base)return 0;
        out=out*base+(unsigned)d;++n;
    }
    if(!n)return 0;
    *v=out;return 1;
}
static int rect_ok(uint32_t x,uint32_t y,uint32_t w,uint32_t h,uint32_t maxw,uint32_t maxh) {
    return w && h && x<maxw && y<maxh && w<=maxw-x && h<=maxh-y;
}
static const char *validate(const LabRequest *r) {
    const uint32_t *a=r->a;
    if(r->op==OP_FILL && (!rect_ok(a[0],a[1],a[2],a[3],1280,720) || a[4]>0xffffffu))return "RANGE";
    if(r->op==OP_COPY && (a[0]>=LAB_TILE_COUNT ||
        !rect_ok(a[1],a[2],a[3],a[4],64,64) ||
        !rect_ok(a[5],a[6],a[3],a[4],1280,720)))return "RANGE";
    if(r->op==OP_PATTERN && a[0]>2u)return "RANGE";
    if(r->op==OP_IMGBEGIN && (!a[0] || a[0]>2147483647u || !a[1] || a[1]>1280 || !a[2] || a[2]>720))return "RANGE";
    if(r->op>=OP_IMGDATA && r->op<=OP_IMGABORT && (!a[0] || a[0]>2147483647u))return "SESSION";
    return 0;
}
void lab_init(lab_reply_fn emit,lab_restore_fn restore) {
    reply=emit;restore_game=restore;active=pending=running=0;cycles=0;memset(&image,0,sizeof image);image_verified=0;
}
unsigned lab_active(void){return active;}
unsigned lab_pending(void){return pending||running;}
int lab_command(const char *line) {
    LabRequest r;memset(&r,0,sizeof r);r.op=OP_BAD;char text[LAB_REQUEST_MAX+1u];char *tokens[12];
    unsigned len=0,count=0,expected=0;
    if(!line)return 0;
    if(*line==':')++line;
    if(line[0]!='l'||line[1]!='a'||line[2]!='b'||(line[3] && line[3]!=' ' && line[3]!='\t'))return 0;
    while(line[len] && len<=LAB_REQUEST_MAX)++len;
    if(len>LAB_REQUEST_MAX){cycles=0;done(&r,"PARSE",0,0,0,0);return 1;}
    for(unsigned i=0;i<=len;++i)text[i]=line[i];
    char *p=text;
    while(*p){while(*p==' '||*p=='\t')++p;if(!*p)break;
        if(count==12u){cycles=0;done(&r,"PARSE",0,0,0,0);return 1;}
        tokens[count++]=p;while(*p && *p!=' '&&*p!='\t')++p;if(*p)*p++=0;
    }
    if(count<3 || !parse_uint(tokens[1],&r.id,0) || !r.id || r.id>2147483647u){r.id=0;cycles=0;done(&r,"PARSE",0,0,0,0);return 1;}
    for(unsigned i=0;i<OP_BAD;++i)if(same(tokens[2],op_names[i])){r.op=i;break;}
    if(r.op==OP_FILL)expected=5;else if(r.op==OP_COPY)expected=7;else if(r.op==OP_PATTERN)expected=1;else if(r.op==OP_IMGBEGIN)expected=4;else if(r.op==OP_IMGDATA||r.op==OP_IMGCOPY)expected=3;else if(r.op==OP_IMGCOMMIT||r.op==OP_IMGABORT)expected=1;
    if(r.op==OP_BAD || count!=expected+3u){cycles=0;done(&r,"PARSE",0,0,0,0);return 1;}
    if(r.op==OP_IMGDATA){if(strlen(tokens[5])>384u){cycles=0;image_verified=0;done(&r,"ENCODING",0,0,0,0);return 1;}}
    for(unsigned i=0;i<expected;++i)if(!(r.op==OP_IMGDATA&&i==2u)&&!parse_uint(tokens[i+3],r.a+i,r.op==OP_FILL&&i==4u)){
        cycles=0;done(&r,"PARSE",0,0,0,0);return 1;}
    const char *error=validate(&r);
    if(!error && (pending||running))error="BUSY";
    if(!error && r.op!=OP_ENTER && r.op!=OP_IMGSTATUS && !active)error="MODE";
    if(!error && r.op==OP_ENTER && active)error="MODE";
    if(error){cycles=0;done(&r,error,0,0,0,0);return 1;}
    if(r.op==OP_IMGDATA)strcpy(image_payload,tokens[5]);
    pending_request=r;pending=1;
    start_line("LAB_ACK",r.id);add(" op=");add(op_names[r.op]);add(" status=QUEUED");send_line();
    return 1;
}

static volatile uint32_t *at(uint32_t address){return (volatile uint32_t *)(uintptr_t)address;}
static uint32_t source_pixel(unsigned tile,unsigned x,unsigned y) {
    return palette[(tile?x/8u:x/8u+y/8u)%4u];
}
static void source_init(void) {
    for(unsigned t=0;t<LAB_TILE_COUNT;++t)for(unsigned y=0;y<64;++y)for(unsigned x=0;x<64;++x)
        at(LAB_SOURCE_BASE+t*TILE_BYTES)[y*64u+x]=source_pixel(t,x,y);
}
static uint32_t guard_address(unsigned n) {
    return n==0?BB_FB0+BB_FRAME_BYTES:n==1?BB_FB1+BB_FRAME_BYTES:LAB_SOURCE_BASE+SOURCE_BYTES;
}
static void guards_init(void) {
    for(unsigned n=0;n<3;++n)for(unsigned k=0;k<GUARD_WORDS;++k)at(guard_address(n))[k]=GUARD_VALUE^(n*37u+k);
}
static uint32_t check_guards_source(void) {
    uint32_t errors=0;
    for(unsigned n=0;n<3;++n)for(unsigned k=0;k<GUARD_WORDS;++k)
        errors+=at(guard_address(n))[k]!=(GUARD_VALUE^(n*37u+k));
    for(unsigned t=0;t<LAB_TILE_COUNT;++t)for(unsigned y=0;y<64;++y)for(unsigned x=0;x<64;++x)
        errors+=at(LAB_SOURCE_BASE+t*TILE_BYTES)[y*64u+x]!=source_pixel(t,x,y);
    return errors;
}
static int execute(bb_job *j) {
    bb_metrics m={0,0,0};bb_result result=bb_execute(j,&m);
    if(UINT32_MAX-cycles<m.cycles)cycles=UINT32_MAX;else cycles+=m.cycles;
    return result==BB_OK;
}
static int fill(uint32_t fb,unsigned x,unsigned y,unsigned w,unsigned h,uint32_t color) {
    /* Public driver and RTL limit one command to 1024 pixels wide. */
    while(w){unsigned part=w>1024u?1024u:w;
        bb_job j={BB_FILL_OP,0,fb+y*BB_SCREEN_STRIDE+x*4u,0,BB_SCREEN_STRIDE,
            part,h,color,255,0,0};
        if(!execute(&j))return 0;
        x+=part;w-=part;
    }return 1;
}
static int make_pattern(uint32_t fb,unsigned kind) {
    if(kind==0){
        if(!fill(fb,0,0,1280,720,LAB_BACKGROUND))return 0;
        for(unsigned x=0;x<1280;x+=40)if(!fill(fb,x,0,1,720,0xd4d8e2u))return 0;
        for(unsigned y=0;y<720;y+=40)if(!fill(fb,0,y,1280,1,0xd4d8e2u))return 0;
    }else if(kind==1){for(unsigned n=0;n<8;++n)if(!fill(fb,n*160u,0,160,720,bars[n]))return 0;}
    else {
        if(!fill(fb,0,0,1280,720,0xffffffu) || !fill(fb,640,0,1,720,palette[0]) ||
           !fill(fb,0,360,1280,1,palette[0]))return 0;
        for(unsigned n=0;n<4;++n)if(!fill(fb,n&1u?1252:12,n&2u?692:12,16,16,palette[n]))return 0;
    }
    unsigned b=kind==2?4:2;
    return fill(fb,0,0,1280,b,0x40444fu)&&fill(fb,0,720-b,1280,b,0x40444fu)&&
        fill(fb,0,b,b,720-2*b,0x40444fu)&&fill(fb,1280-b,b,b,720-2*b,0x40444fu);
}
static uint32_t expected_pixel(const LabRequest *r,unsigned x,unsigned y) {
    const uint32_t *a=r->a;
    if(r->op==OP_FILL && x>=a[0] && x-a[0]<a[2] && y>=a[1] && y-a[1]<a[3])return a[4];
    if(r->op==OP_COPY && x>=a[5] && x-a[5]<a[3] && y>=a[6] && y-a[6]<a[4])
        return source_pixel(a[0],a[1]+x-a[5],a[2]+y-a[6]);
    if(r->op==OP_PATTERN || r->op==OP_ENTER){
        unsigned kind=r->op==OP_ENTER?0:a[0],b=kind==2?4:2;
        if(x<b||x>=1280-b||y<b||y>=720-b)return 0x40444fu;
        if(kind==0)return x%40u==0||y%40u==0?0xd4d8e2u:LAB_BACKGROUND;
        if(kind==1)return bars[x/160u];
        if(y>=12&&y<28){if(x>=12&&x<28)return palette[0];if(x>=1252&&x<1268)return palette[1];}
        if(y>=692&&y<708){if(x>=12&&x<28)return palette[2];if(x>=1252&&x<1268)return palette[3];}
        return x==640||y==360?palette[0]:0xffffffu;
    }return LAB_BACKGROUND;
}
static uint32_t check_frame(const LabRequest *r,uint32_t fb) {
    uint32_t errors=0;
    bb_acquire();
    for(unsigned y=0;y<720;++y)for(unsigned x=0;x<1280;++x)
        errors+=at(fb)[y*1280u+x]!=expected_pixel(r,x,y);
    return errors+check_guards_source();
}
static const char *draw(const LabRequest *r,uint32_t *errors) {
    uint32_t front=bb_read(BB_FRONT),fb;
    if(front!=BB_FB0&&front!=BB_FB1)return "ENGINE";
    fb=front==BB_FB0?BB_FB1:BB_FB0;
    guards_init();
    if(bb_publish()!=BB_OK)return "ENGINE";
    if(r->op==OP_ENTER||r->op==OP_PATTERN){if(!make_pattern(fb,r->op==OP_ENTER?0:r->a[0]))return "ENGINE";}
    else {
        if(!fill(fb,0,0,1280,720,LAB_BACKGROUND))return "ENGINE";
        if(r->op==OP_FILL && !fill(fb,r->a[0],r->a[1],r->a[2],r->a[3],r->a[4]))return "ENGINE";
        if(r->op==OP_COPY){const uint32_t *a=r->a;
            bb_job j={BB_COPY_OP,LAB_SOURCE_BASE+a[0]*TILE_BYTES+(a[2]*64u+a[1])*4u,
                fb+a[6]*BB_SCREEN_STRIDE+a[5]*4u,256,BB_SCREEN_STRIDE,a[3],a[4],0,255,0,0};
            if(!execute(&j))return "ENGINE";
        }
    }
    *errors=check_frame(r,fb);if(*errors)return "VERIFY";
    return bb_swap_wait(fb,200000u)==BB_OK?0:"ENGINE";
}
static void case_reply(uint32_t id,const char *name,uint32_t errors,const char *error,uint32_t us) {
    start_line("LAB_CASE",id);add(" case=");add(name);add(error?" status=FAIL":" status=PASS");
    if(error){add(" code=");add(error);}add(" errors=");number(errors);add(" us=");number(us);send_line();
}
static void verify_suite(const LabRequest *request,unsigned *passed,unsigned *failed,uint32_t *all_errors) {
    static const struct {const char *name;unsigned op;uint32_t a[8];} cases[]={
        {"fill",OP_FILL,{17,23,127,91,0x35b89b}},
        {"fill_edges",OP_FILL,{0,0,1280,720,0x4c8dff}},
        {"copy",OP_COPY,{0,7,11,31,29,123,77}},
        {"copy_edges",OP_COPY,{1,0,0,64,64,1216,656}},
        {"grid",OP_PATTERN,{0}},{"bars",OP_PATTERN,{1}},{"border",OP_PATTERN,{2}}
    };
    for(unsigned n=0;n<sizeof cases/sizeof cases[0];++n){
        LabRequest r=*request;r.op=cases[n].op;
        for(unsigned k=0;k<8;++k)r.a[k]=cases[n].a[k];
        uint32_t errors=0;uint64_t begin=bb_ticks();const char *error=draw(&r,&errors);
        case_reply(request->id,cases[n].name,errors,error,bb_us(bb_ticks()-begin));
        if(error)++*failed;else ++*passed;*all_errors+=errors;
        if(error && same(error,"ENGINE"))return;
    }
    /* Reject before issuing a job. Full front-frame compare also detects any
       accidental memory change during validation; this is not a parser-only test. */
    LabRequest border=*request;border.op=OP_PATTERN;border.a[0]=2;
    static const LabRequest invalid[]={
        {1,{0,0,0,1,0},OP_FILL},{1,{1279,719,2,1,0},OP_FILL},
        {1,{0xffffffffu,1,2,2,0},OP_FILL},
        {1,{0,63,0,2,2,0,0},OP_COPY},{1,{2,0,0,1,1,0,0},OP_COPY},
        {1,{1,0,0,1,1,1280,0},OP_COPY}
    };
    uint64_t begin=bb_ticks();uint32_t errors=0;
    for(unsigned n=0;n<sizeof invalid/sizeof invalid[0];++n)errors+=validate(&invalid[n])==0;
    errors+=check_frame(&border,bb_read(BB_FRONT));
    case_reply(request->id,"boundary_reject",errors,errors?"VERIFY":0,bb_us(bb_ticks()-begin));
    if(errors)++*failed;else ++*passed;*all_errors+=errors;
    begin=bb_ticks();bb_acquire();errors=check_guards_source();
    case_reply(request->id,"guards_source",errors,errors?"VERIFY":0,bb_us(bb_ticks()-begin));
    if(errors)++*failed;else ++*passed;*all_errors+=errors;
}
static const uint32_t image_crc_table[256]={
 0x00000000u,0x77073096u,0xee0e612cu,0x990951bau,0x076dc419u,0x706af48fu,0xe963a535u,0x9e6495a3u,
 0x0edb8832u,0x79dcb8a4u,0xe0d5e91eu,0x97d2d988u,0x09b64c2bu,0x7eb17cbdu,0xe7b82d07u,0x90bf1d91u,
 0x1db71064u,0x6ab020f2u,0xf3b97148u,0x84be41deu,0x1adad47du,0x6ddde4ebu,0xf4d4b551u,0x83d385c7u,
 0x136c9856u,0x646ba8c0u,0xfd62f97au,0x8a65c9ecu,0x14015c4fu,0x63066cd9u,0xfa0f3d63u,0x8d080df5u,
 0x3b6e20c8u,0x4c69105eu,0xd56041e4u,0xa2677172u,0x3c03e4d1u,0x4b04d447u,0xd20d85fdu,0xa50ab56bu,
 0x35b5a8fau,0x42b2986cu,0xdbbbc9d6u,0xacbcf940u,0x32d86ce3u,0x45df5c75u,0xdcd60dcfu,0xabd13d59u,
 0x26d930acu,0x51de003au,0xc8d75180u,0xbfd06116u,0x21b4f4b5u,0x56b3c423u,0xcfba9599u,0xb8bda50fu,
 0x2802b89eu,0x5f058808u,0xc60cd9b2u,0xb10be924u,0x2f6f7c87u,0x58684c11u,0xc1611dabu,0xb6662d3du,
 0x76dc4190u,0x01db7106u,0x98d220bcu,0xefd5102au,0x71b18589u,0x06b6b51fu,0x9fbfe4a5u,0xe8b8d433u,
 0x7807c9a2u,0x0f00f934u,0x9609a88eu,0xe10e9818u,0x7f6a0dbbu,0x086d3d2du,0x91646c97u,0xe6635c01u,
 0x6b6b51f4u,0x1c6c6162u,0x856530d8u,0xf262004eu,0x6c0695edu,0x1b01a57bu,0x8208f4c1u,0xf50fc457u,
 0x65b0d9c6u,0x12b7e950u,0x8bbeb8eau,0xfcb9887cu,0x62dd1ddfu,0x15da2d49u,0x8cd37cf3u,0xfbd44c65u,
 0x4db26158u,0x3ab551ceu,0xa3bc0074u,0xd4bb30e2u,0x4adfa541u,0x3dd895d7u,0xa4d1c46du,0xd3d6f4fbu,
 0x4369e96au,0x346ed9fcu,0xad678846u,0xda60b8d0u,0x44042d73u,0x33031de5u,0xaa0a4c5fu,0xdd0d7cc9u,
 0x5005713cu,0x270241aau,0xbe0b1010u,0xc90c2086u,0x5768b525u,0x206f85b3u,0xb966d409u,0xce61e49fu,
 0x5edef90eu,0x29d9c998u,0xb0d09822u,0xc7d7a8b4u,0x59b33d17u,0x2eb40d81u,0xb7bd5c3bu,0xc0ba6cadu,
 0xedb88320u,0x9abfb3b6u,0x03b6e20cu,0x74b1d29au,0xead54739u,0x9dd277afu,0x04db2615u,0x73dc1683u,
 0xe3630b12u,0x94643b84u,0x0d6d6a3eu,0x7a6a5aa8u,0xe40ecf0bu,0x9309ff9du,0x0a00ae27u,0x7d079eb1u,
 0xf00f9344u,0x8708a3d2u,0x1e01f268u,0x6906c2feu,0xf762575du,0x806567cbu,0x196c3671u,0x6e6b06e7u,
 0xfed41b76u,0x89d32be0u,0x10da7a5au,0x67dd4accu,0xf9b9df6fu,0x8ebeeff9u,0x17b7be43u,0x60b08ed5u,
 0xd6d6a3e8u,0xa1d1937eu,0x38d8c2c4u,0x4fdff252u,0xd1bb67f1u,0xa6bc5767u,0x3fb506ddu,0x48b2364bu,
 0xd80d2bdau,0xaf0a1b4cu,0x36034af6u,0x41047a60u,0xdf60efc3u,0xa867df55u,0x316e8eefu,0x4669be79u,
 0xcb61b38cu,0xbc66831au,0x256fd2a0u,0x5268e236u,0xcc0c7795u,0xbb0b4703u,0x220216b9u,0x5505262fu,
 0xc5ba3bbeu,0xb2bd0b28u,0x2bb45a92u,0x5cb36a04u,0xc2d7ffa7u,0xb5d0cf31u,0x2cd99e8bu,0x5bdeae1du,
 0x9b64c2b0u,0xec63f226u,0x756aa39cu,0x026d930au,0x9c0906a9u,0xeb0e363fu,0x72076785u,0x05005713u,
 0x95bf4a82u,0xe2b87a14u,0x7bb12baeu,0x0cb61b38u,0x92d28e9bu,0xe5d5be0du,0x7cdcefb7u,0x0bdbdf21u,
 0x86d3d2d4u,0xf1d4e242u,0x68ddb3f8u,0x1fda836eu,0x81be16cdu,0xf6b9265bu,0x6fb077e1u,0x18b74777u,
 0x88085ae6u,0xff0f6a70u,0x66063bcau,0x11010b5cu,0x8f659effu,0xf862ae69u,0x616bffd3u,0x166ccf45u,
 0xa00ae278u,0xd70dd2eeu,0x4e048354u,0x3903b3c2u,0xa7672661u,0xd06016f7u,0x4969474du,0x3e6e77dbu,
 0xaed16a4au,0xd9d65adcu,0x40df0b66u,0x37d83bf0u,0xa9bcae53u,0xdebb9ec5u,0x47b2cf7fu,0x30b5ffe9u,
 0xbdbdf21cu,0xcabac28au,0x53b39330u,0x24b4a3a6u,0xbad03605u,0xcdd70693u,0x54de5729u,0x23d967bfu,
 0xb3667a2eu,0xc4614ab8u,0x5d681b02u,0x2a6f2b94u,0xb40bbe37u,0xc30c8ea1u,0x5a05df1bu,0x2d02ef8du,
};
static uint32_t image_crc_byte(uint32_t crc,unsigned byte){return (crc>>8)^image_crc_table[(crc^byte)&255u];}
static void image_reset(void){memset(&image,0,sizeof image);image_verified=0;}
static uint32_t image_guard_address(unsigned n){return n==0?LAB_IMAGE_BASE-64u:n==1?LAB_IMAGE_BASE+(image.total/3u)*4u:LAB_IMAGE_BASE+BB_FRAME_BYTES;}
static uint32_t image_guard_value(unsigned n,unsigned k){return 0x7349b12du^image.session^(n*59u+k);}
static void image_guards_init(void){for(unsigned n=0;n<3;++n){if(n==2&&image_guard_address(1)==image_guard_address(2))continue;for(unsigned k=0;k<16;++k)at(image_guard_address(n))[k]=image_guard_value(n,k);}}
static uint32_t image_guards_check(void){uint32_t errors=0;for(unsigned n=0;n<3;++n){if(n==2&&image_guard_address(1)==image_guard_address(2))continue;for(unsigned k=0;k<16;++k)errors+=at(image_guard_address(n))[k]!=image_guard_value(n,k);}return errors;}
static uint32_t image_ddr_crc(uint32_t *errors){uint32_t crc=0xffffffffu;for(unsigned i=0;i<image.total/3u;++i){uint32_t p=at(LAB_IMAGE_BASE)[i];*errors+=(p&0xff000000u)!=0;crc=image_crc_byte(crc,p>>16);crc=image_crc_byte(crc,p>>8);crc=image_crc_byte(crc,p);}return crc^0xffffffffu;}
static int b64value(char c){if(c>='A'&&c<='Z')return c-'A';if(c>='a'&&c<='z')return c-'a'+26;if(c>='0'&&c<='9')return c-'0'+52;return c=='+'?62:c=='/'?63:-1;}
static unsigned image_decode(const char *s,uint8_t bytes[LAB_IMAGE_CHUNK_BYTES]){
 unsigned len=(unsigned)strlen(s);if(!len||len>384u||len%4u)return 0;
 /* RGB chunks are multiples of3 bytes. Their only canonical RFC4648 form is
    groups of4 alphabet chars with no '=' padding, whitespace or aliases. */
 for(unsigned i=0;i<len;i+=4){int a=b64value(s[i]),b=b64value(s[i+1]),c=b64value(s[i+2]),d=b64value(s[i+3]);if(a<0||b<0||c<0||d<0)return 0;
  bytes[i/4*3]=(uint8_t)((a<<2)|(b>>4));bytes[i/4*3+1]=(uint8_t)((b<<4)|(c>>2));bytes[i/4*3+2]=(uint8_t)((c<<6)|d);}
 return len/4*3;
}
static const char *image_validate_source(uint32_t *errors){
 bb_acquire();uint32_t guards=image_guards_check();*errors+=guards;if(guards){image.ready=0;return "GUARD";}
 uint32_t source_errors=0,crc=image_ddr_crc(&source_errors);if(crc!=image.expected_crc)++source_errors;*errors+=source_errors;if(source_errors){image.ready=0;return "CRC";}return 0;
}
static const char *image_copy(const LabRequest *r,uint32_t *errors){
 if(!image.ready)return "INCOMPLETE";
 if(!rect_ok(r->a[1],r->a[2],image.w,image.h,1280,720))return "RANGE";
 const char *error=image_validate_source(errors);if(error)return error;
 *errors+=check_guards_source();if(*errors)return "GUARD";
 uint32_t front=bb_read(BB_FRONT);if(front!=BB_FB0&&front!=BB_FB1)return "ENGINE";uint32_t fb=front==BB_FB0?BB_FB1:BB_FB0;
 if(bb_publish()!=BB_OK||!fill(fb,0,0,1280,720,LAB_BACKGROUND))return "ENGINE";
 for(unsigned x=0;x<image.w;x+=1024){unsigned w=image.w-x;if(w>1024)w=1024;
  bb_job j={BB_COPY_OP,LAB_IMAGE_BASE+x*4,fb+r->a[2]*5120+(r->a[1]+x)*4,image.w*4,5120,w,image.h,0,255,0,0};if(!execute(&j))return "ENGINE";}
 if(bb_swap_wait(fb,200000u)!=BB_OK||bb_read(BB_FRONT)!=fb)return "ENGINE";
 /* Compare the actual new FRONT, all921600 pixels including empty margins.
    Its source is separately protected by the PC CRC + streamCRC + DDR CRC. */
 bb_acquire();for(unsigned y=0;y<720;++y)for(unsigned x=0;x<1280;++x){uint32_t expected=LAB_BACKGROUND;
  if(x>=r->a[1]&&x-r->a[1]<image.w&&y>=r->a[2]&&y-r->a[2]<image.h)expected=at(LAB_IMAGE_BASE)[(y-r->a[2])*image.w+x-r->a[1]]&0xffffffu;
  *errors+=at(fb)[y*1280+x]!=expected;}
 uint32_t guard_errors=check_guards_source();*errors+=guard_errors;
 error=image_validate_source(errors);if(error)return error;if(guard_errors)return "GUARD";if(*errors)return "VERIFY";image_verified=1280u*720u;return 0;
}
static const char *image_service(const LabRequest *r,uint32_t *errors){image_verified=0;
 if(r->op==OP_IMGSTATUS)return 0;
 if(r->op==OP_IMGBEGIN){image_reset();image.session=r->a[0];image.w=r->a[1];image.h=r->a[2];image.total=image.w*image.h*3;image.expected_crc=r->a[3];image.stream_crc=0xffffffffu;image_guards_init();return bb_publish()==BB_OK?0:"ENGINE";}
 if(!image.session||r->a[0]!=image.session)return "SESSION";
 if(r->op==OP_IMGABORT){image_reset();return 0;}
 if(r->op==OP_IMGDATA){uint8_t bytes[LAB_IMAGE_CHUNK_BYTES];unsigned n=image_decode(image_payload,bytes);if(!n)return "ENCODING";
  if(r->a[1]!=image.received)return "OFFSET";
  if(image.ready||image.received>image.total||n>image.total-image.received)return "RANGE";
  bb_acquire();*errors=image_guards_check();if(*errors){image.ready=0;return "GUARD";}
  for(unsigned i=0;i<n;i+=3){uint32_t pixel=((uint32_t)bytes[i]<<16)|((uint32_t)bytes[i+1]<<8)|bytes[i+2];at(LAB_IMAGE_BASE)[(image.received+i)/3]=pixel;}
  for(unsigned i=0;i<n;++i)image.stream_crc=image_crc_byte(image.stream_crc,bytes[i]);
  image.received+=n;return 0;
 }
 if(r->op==OP_IMGCOMMIT){image.ready=0;if(image.received!=image.total)return "INCOMPLETE";if((image.stream_crc^0xffffffffu)!=image.expected_crc){++*errors;return "CRC";}
  if(bb_publish()!=BB_OK)return "ENGINE";
  const char *error=image_validate_source(errors);if(error)return error;image.ready=1;return 0;
 }
 return image_copy(r,errors);
}
void lab_service(void) {
    if(!pending)return;
    LabRequest r=pending_request;pending=0;running=1;cycles=0;
    uint64_t begin=bb_ticks();uint32_t errors=0;unsigned passed=0,failed=0;const char *error=0;
    if(r.op==OP_EXIT){
        if(!restore_game||restore_game()!=0)error="RESTORE";else {active=0;image_reset();}
    }else if(r.op>=OP_IMGBEGIN && r.op<=OP_IMGSTATUS){error=image_service(&r,&errors);
    }else {
        if(r.op==OP_ENTER){active=1;image_reset();source_init();}
        if(r.op==OP_VERIFY){verify_suite(&r,&passed,&failed,&errors);if(failed)error="VERIFY";}
        else error=draw(&r,&errors);
    }
    running=0;done(&r,error,errors,bb_us(bb_ticks()-begin),passed,failed);
}
