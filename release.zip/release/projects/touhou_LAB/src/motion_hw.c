#include "motion_hw.h"
#include "bitblt.h"
#include "segment_diag.h"
#include "scene.h"
#include "stage.h"
#include "pipe5_abi.h"
#include <string.h>
#if defined(__riscv) || defined(MOTION_HW_HOST_TEST)

/* Only this sequential driver uses OP3. Never submit during a render job and
 * never recover a partially written motion by executing the CPU path. */
enum {MOTION_TIMEOUT_US=200000u,MOTION_GUARD_WORDS=16u};
typedef struct {uint32_t before[16];MotionJobV1 value;uint32_t after[16];} JobSlot;
typedef struct {uint32_t before[16];MotionCompletionV1 value;uint32_t after[16];} CompletionSlot;
typedef struct {uint32_t before[16];MotionSinCos value[1024];uint32_t after[16];} LutSlot;
static JobSlot job_slot __attribute__((aligned(64)));
static CompletionSlot completion_slot __attribute__((aligned(64)));
static LutSlot lut_slot __attribute__((aligned(64)));
_Static_assert(offsetof(JobSlot,value)==64&&offsetof(CompletionSlot,value)==64&&offsetof(LutSlot,value)==64,"separate cacheline-aligned DMA payloads");
static unsigned enabled,initialized,next_epoch;
static MotionHwCounters counters;
static struct {unsigned active,done,parallel,input,size;int py;unsigned *counts;uint64_t start;} async_motion;

#ifdef MOTION_HW_HOST_TEST
/* Native pointers may be64-bit. The test maps each real backing array to a
 * disjoint legal32-bit DMA window; MMIO backend must actually read/write it. */
extern uint32_t motion_hw_test_dma_address(const void *pointer,unsigned bytes);
static uint32_t dma_address(const void *p,unsigned bytes){return motion_hw_test_dma_address(p,bytes);}
#else
static uint32_t dma_address(const void *p,unsigned bytes){(void)bytes;return (uint32_t)(uintptr_t)p;}
#endif
static void motion_barrier(void){
#ifdef __riscv
    __asm__ volatile("fence iorw,iorw" ::: "memory");
#endif
}
static uint32_t guard_value(unsigned bank,unsigned side,unsigned word){return 0x6d6f7434u^(bank*0x1f1f101u)^(side*0xa5567812u)^word;}
static void initialize_guards(uint32_t *before,uint32_t *after,unsigned bank){
    for(unsigned i=0;i<16;++i){before[i]=guard_value(bank,0,i);after[i]=guard_value(bank,1,i);}
}
static int check_guards(const uint32_t *before,const uint32_t *after,unsigned bank){
    for(unsigned i=0;i<16;++i)if(before[i]!=guard_value(bank,0,i)||after[i]!=guard_value(bank,1,i))return 0;
    return 1;
}
#endif
static void require_guards(void){
    if(!check_guards(job_slot.before,job_slot.after,0)||
       !check_guards(completion_slot.before,completion_slot.after,1)||
       !check_guards(lut_slot.before,lut_slot.after,2)||!battle_scratch_guards_ok())fatal("MOTION GUARD",-1);
}
void motion_hw_init(void){
    if(initialized)return;
    initialize_guards(job_slot.before,job_slot.after,0);
    initialize_guards(completion_slot.before,completion_slot.after,1);
    initialize_guards(lut_slot.before,lut_slot.after,2);
    for(unsigned i=0;i<1024;++i){lut_slot.value[i].sin=(int16_t)turn_sin((int)i*64);lut_slot.value[i].cos=(int16_t)turn_cos((int)i*64);}
    initialized=1;
}
void motion_hw_set_enabled(unsigned value){enabled=!!value;}
MotionHwCounters motion_hw_counters(void){return counters;}
static unsigned bucket(int y){if(y<0)return 0;unsigned b=(unsigned)y/86u;return b<8?b:7;}
static void validate_regions(const MotionJobV1 *j,uint32_t job_address){
    const uint32_t base[]={job_address,j->shots,j->effects,j->owners,j->contact_index,j->contact_count,j->sincos_lut,j->result};
    const uint32_t bytes[]={128,320000,240000,20000,65536,32,4096,128};
    const unsigned align[]={16,16,4,1,2,4,16,16};
    for(unsigned i=0;i<8;++i){
        uint64_t end=(uint64_t)base[i]+bytes[i];
        if(base[i]<0x1000u||end>0xf00000u||(base[i]&(align[i]-1u)))fatal("MOTION RANGE",(int)i);
        for(unsigned k=0;k<i;++k)if(base[i]<(uint64_t)base[k]+bytes[k]&&base[k]<end)fatal("MOTION OVERLAP",(int)i);
    }
}
static void validate_completion(unsigned input,unsigned size,int py,unsigned *counts,unsigned parallel){
    const MotionCompletionV1 *r=&completion_slot.value;
    if(r->magic!=MOTION_MAGIC||r->abi!=MOTION_ABI_V1||r->epoch!=job_slot.value.epoch||r->status!=MOTION_OK||r->flags!=MOTION_SW3_INDEXLESS)fatal("MOTION PACKET",-1);
    for(unsigned i=0;i<10;++i)if(r->reserved[i])fatal("MOTION RESERVED",(int)i);
    if(r->count>input||r->processed!=input||r->removed!=input-r->count||r->hit>1||r->grazes>r->count||(!r->count&&r->hit)||
       (uint64_t)r->delay_steps+r->turn_partial_steps+r->turn_complete_steps>input||
       (uint64_t)r->cache_hits+r->cache_misses>r->turn_partial_steps||
       (uint64_t)r->cache_misses*33u!=r->divider_cycles||r->stall_cycles>r->cycles)fatal("MOTION COUNTERS",-1);
    unsigned graze=size/2u+9u,lo=bucket(py-(int)graze),hi=bucket(py+(int)graze),sum=0,overflow=0;
    for(unsigned i=0;i<8;++i){
        if(counts[i]>r->count||(i!=lo&&i!=hi&&counts[i]))fatal("MOTION BUCKET",(int)i);
        sum+=counts[i];if(counts[i]>MOTION_BUCKET_CAP)overflow=1;
    }
    if(sum>r->count||r->fallbacks!=overflow||r->candidates!=(overflow?r->count:sum))fatal("MOTION CONTACT",-1);
    if(r->read_bytes>8192u+input*128u||r->write_bytes>8192u+input*128u||
       bb_read(parallel?PIPE5_M_READ_BYTES:0x3c)!=r->read_bytes||bb_read(parallel?PIPE5_M_WRITE_BYTES:0x40)!=r->write_bytes+128u||bb_read(parallel?PIPE5_M_CYCLES:0x38)<r->cycles)fatal("MOTION METRICS",-1);
}
int motion_hw_begin(void *shots,void *effects,uint8_t *owners,void *index,
                  unsigned *counts,unsigned count,unsigned size,unsigned age_max,
                  int px,int py,unsigned snapshot_epoch){
    if(!enabled)return 0;
    unsigned caps=bb_read(0x4c),parallel=!!(caps&PIPE5_CAP_CONCURRENT_EPOCH);
    if(!(caps&MOTION_CAPABILITY)||size<8||size>56||(size&7u)||px< -65536||px>65536||py< -65536||py>65536)return 0;
    if(count>MOTION_MAX_COUNT||async_motion.active)fatal("MOTION INPUT",-1);
    /* finish_job then invalidate the scene's register-difference cache before
       OP3 changes shared OP/W/H/FILL. It stays invalid even on fatal exit. */
    if(parallel){
        if(bb_read(PIPE5_FAULT))fatal("PIPE MOTION FAULT",-1);
        if(bb_read(PIPE5_M_STATUS)&PIPE5_BUSY)fatal("PIPE MOTION BUSY",-1);
        if(bb_read(PIPE5_R_STATUS)&PIPE5_BUSY){
            unsigned snapshot=bb_read(PIPE5_R_SNAP_STATUS);
            if(!snapshot_epoch||bb_read(PIPE5_R_SNAP_EPOCH)!=snapshot_epoch||!(snapshot&PIPE5_SNAP_READY)||(snapshot&PIPE5_SNAP_NO_DRAW))fatal("PIPE MOTION LEASE",-1);
        }
    }else{
        scene_external_begin();
        if(bb_read(BB_STATUS)&BB_BUSY)fatal("MOTION BUSY",-1);
    }
    motion_hw_init();require_guards();
    memset(&job_slot.value,0,sizeof job_slot.value);memset(&completion_slot.value,0,sizeof completion_slot.value);
    MotionJobV1 *j=&job_slot.value;
    if(!++next_epoch)++next_epoch;
    j->magic=MOTION_MAGIC;j->abi=MOTION_ABI_V1;j->epoch=next_epoch;j->count=count;j->capacity=MOTION_MAX_COUNT;
    j->shots=dma_address(shots,320000);j->effects=dma_address(effects,240000);j->owners=dma_address(owners,20000);
    j->contact_index=dma_address(index,65536);j->contact_count=dma_address(counts,32);
    j->sincos_lut=dma_address(lut_slot.value,4096);j->result=dma_address(&completion_slot.value,128);
    j->size=size;j->age_max=age_max;j->player_x=px;j->player_y=py;j->flags=MOTION_SW3_INDEXLESS;
    uint32_t job_address=dma_address(j,128);validate_regions(j,job_address);
    if(bb_publish()!=BB_OK)fatal("MOTION PUBLISH",-1);
    if(parallel){
        bb_write(PIPE5_M_STATUS,PIPE5_DONE|PIPE5_ERROR);bb_write(PIPE5_M_EPOCH,j->epoch);bb_write(PIPE5_M_JOB,job_address);
    }else{
        bb_write(BB_STATUS,BB_DONE|BB_ERROR);bb_write(BB_OP,3);bb_write(BB_WIDTH,1);bb_write(BB_HEIGHT,1);bb_write(BB_FILL,job_address);
    }
    async_motion.active=1;async_motion.done=0;async_motion.parallel=parallel;async_motion.input=count;async_motion.size=size;async_motion.py=py;async_motion.counts=counts;
    motion_barrier();async_motion.start=bb_ticks();++counters.submitted;bb_write(parallel?PIPE5_M_CMD:BB_CMD,1);if(parallel)segment_diag_event(SDE_M_SUBMIT);
    return 1;
}
unsigned motion_hw_last_epoch(void){return job_slot.value.epoch;}
unsigned motion_hw_active(void){return async_motion.active;}
int motion_hw_poll(void){
    if(!async_motion.active)fatal("MOTION NO JOB",-1);
    if(async_motion.parallel&&bb_read(PIPE5_FAULT))fatal("PIPE MOTION FAULT",-1);
    unsigned status=bb_read(async_motion.parallel?PIPE5_M_STATUS:BB_STATUS);
    if(status&BB_ERROR)fatal("MOTION ENGINE",(int)status);
    if((status&(BB_BUSY|BB_DONE))==BB_DONE){
        if(async_motion.parallel&&bb_read(PIPE5_M_DONE_EPOCH)!=job_slot.value.epoch)fatal("MOTION DONE EPOCH",-1);
        if(async_motion.parallel)segment_diag_event(SDE_M_DONE);
        async_motion.done=1;return 1;
    }
    if(bb_us(bb_ticks()-async_motion.start)>MOTION_TIMEOUT_US)fatal("MOTION TIMEOUT",(int)status);
    return 0;
}
void motion_hw_commit(MotionHwOutput *out){
    if(!out||!async_motion.active||!async_motion.done)fatal("MOTION COMMIT",-1);
    if(async_motion.parallel){
        if(bb_read(PIPE5_FAULT))fatal("PIPE MOTION FAULT",-1);
        /* The CPU may have posted disjoint frozen-HUD stores during M. Drain
           those before invalidating caches/consuming the completed DMA. */
        if(bb_publish()!=BB_OK)fatal("PIPE MOTION DRAIN",-1);
    }
    bb_acquire();require_guards();validate_completion(async_motion.input,async_motion.size,async_motion.py,async_motion.counts,async_motion.parallel);
    const MotionCompletionV1 *r=&completion_slot.value;
    ++counters.completed;counters.last_cycles=r->cycles;counters.last_read_bytes=r->read_bytes;counters.last_write_bytes=r->write_bytes;
    *out=(MotionHwOutput){r->count,r->hit,r->grazes,r->candidates,r->fallbacks};
    if(async_motion.parallel){segment_diag_value(SD_M_CYCLES,r->cycles);segment_diag_value(SD_M_READ,r->read_bytes);segment_diag_value(SD_M_WRITE,r->write_bytes);segment_diag_event(SDE_M_COMMIT);}
    async_motion.active=async_motion.done=0;
}
int motion_hw_try(void *shots,void *effects,uint8_t *owners,void *index,unsigned *counts,unsigned count,unsigned size,unsigned age_max,int px,int py,MotionHwOutput *out){
    if(!motion_hw_begin(shots,effects,owners,index,counts,count,size,age_max,px,py,0))return 0;
    while(!motion_hw_poll()){}
    motion_hw_commit(out);
    return 1;
}
