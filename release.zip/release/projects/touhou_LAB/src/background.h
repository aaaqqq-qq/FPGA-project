#pragma once
#include <stdint.h>
/* One cached procedural BACKGROUND, prepared only at scene initialization.
   This is layered 2.5D scenery, not a perspective 3D rendering engine. */
void background_prepare(unsigned depth_enabled);
uint32_t background_pixel(unsigned screen_x,unsigned screen_y);
