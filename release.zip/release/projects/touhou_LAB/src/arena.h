#pragma once
/* Pixel coordinates relative to the game field (HDMI origin 32,16). */
#define ARENA_W 1024
#define ARENA_H 688
#define ROUND_SECONDS 200
#define ROUND_FRAMES (ROUND_SECONDS*60u)
#define PLAYER_MIN_X 16
#define PLAYER_MAX_X (ARENA_W-16)
#define PLAYER_MIN_Y 24
#define PLAYER_MAX_Y (ARENA_H-24)
#define PLAYER_START_X (ARENA_W/2)
#define PLAYER_START_Y (ARENA_H-68)
#define PLAYER_SPEED 6
#define BOSS_MIN_X 16
#define BOSS_MAX_X (ARENA_W-16)
#define BOSS_MIN_Y 24
#define BOSS_MAX_Y (ARENA_H-24)
#define BAR_W (ARENA_W-16)
#define PANEL_W 460
#define PANEL_H 238
#define PANEL_X (32+(ARENA_W-PANEL_W)/2)
#define PANEL_Y (16+(ARENA_H-PANEL_H)/2)
/* Convert script Q12 positions from the original 384x448 field. */
static inline int arena_script_x(int v){return (int)((long long)v*8/3);}
static inline int arena_script_y(int v){return (int)((long long)v*43/28);}
