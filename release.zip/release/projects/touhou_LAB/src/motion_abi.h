#ifndef TI60_MOTION_ABI_H
#define TI60_MOTION_ABI_H
#include <stdint.h>
#include <stddef.h>
#define MOTION_MAGIC UINT32_C(0x4d4f5431)
#define MOTION_ABI_V1 1u
#define MOTION_SW3_INDEXLESS 1u
#define MOTION_MAX_COUNT 20000u
#define MOTION_BUCKETS 8u
#define MOTION_BUCKET_CAP 4096u
#define MOTION_Q 4096
#define MOTION_CAPABILITY 16u
/* OP=3, WIDTH=1, HEIGHT=1; FILL holds the16-byte aligned Job address.
   The1x1 sentinel preserves legacy zero-dimension NOP behavior for all opcodes.
   Single shared-AXI job.
   All arrays have MAX_COUNT capacity, even if count is zero. The entire index
   scratch is retained without access in this SW3-only ABI/flag combination.
   The LUT must equal the frozen actual SW3 sin/cos table, checked before writes.
   No new physical bullet/bullet interaction or rendering changes exist. */
typedef struct {int32_t x,y;int16_t vx,vy;uint16_t age;uint8_t tile,grazed;} MotionShot;
typedef struct {int16_t angle,speed,target,target_speed;uint16_t turn,delay;} MotionEffect;
typedef struct {int16_t sin,cos;} MotionSinCos;
typedef struct {
 uint32_t magic,abi,epoch,count,capacity;
 uint32_t shots,effects,owners,contact_index,contact_count,sincos_lut,result;
 uint32_t size,age_max;
 int32_t player_x,player_y;
 uint32_t flags,reserved[15];
} MotionJobV1;
typedef struct {
 uint32_t magic,abi,epoch,status,count,hit,grazes,candidates,fallbacks;
 uint32_t processed,removed,delay_steps,turn_partial_steps,turn_complete_steps;
 uint32_t cycles,read_bytes,write_bytes,flags;
 uint32_t cache_hits,cache_misses,divider_cycles,stall_cycles,reserved[10];
} MotionCompletionV1;
/* Completion cycles/read_bytes/write_bytes/stall_cycles snapshot is taken
   BEFORE writing this 128-byte packet. Final MMIO write_bytes includes the
   packet (completion.write_bytes + 128); final MMIO cycles includes its drained
   writes. All fields are little-endian. Errors NEVER publish a completion. */
enum {MOTION_OK=0,MOTION_BAD_JOB=1,MOTION_BAD_LUT=2,MOTION_AXI_READ=3,MOTION_AXI_WRITE=4,MOTION_INTERNAL=5};
_Static_assert(sizeof(MotionShot)==16&&offsetof(MotionShot,age)==12&&offsetof(MotionShot,tile)==14,"Shot ABI");
_Static_assert(sizeof(MotionEffect)==12&&offsetof(MotionEffect,turn)==8,"Effect ABI");
_Static_assert(sizeof(MotionJobV1)==128&&offsetof(MotionJobV1,flags)==64,"job ABI");
_Static_assert(sizeof(MotionCompletionV1)==128&&offsetof(MotionCompletionV1,cache_hits)==72,"completion ABI");
/* File-only host reference helpers. No DMA, hardware or performance claim. */
int motion_validate_job(const MotionJobV1 *,uint32_t job_address);
int motion_validate_lut(const MotionSinCos *);
void motion_oracle_tick(void *shots,void *effects,uint8_t *owners,uint32_t count,
 uint32_t size,uint32_t age_max,int32_t px,int32_t py,uint32_t bucket_counts[8],MotionCompletionV1 *result);
#endif
