#pragma once
#include <stdint.h>
typedef struct {
    unsigned initialized,raw,keys,pressed,menu_requested,hold_fired;
    uint32_t candidate_since,hold_since,last_sample;
} Controls;
static inline void controls_sample(Controls *c,unsigned raw,uint32_t now){
    if(c->initialized && (uint32_t)(now-c->last_sample)<5000)return;
    c->last_sample=now;
    if(!c->initialized){c->initialized=1;c->raw=raw;c->candidate_since=now;return;}
    if(raw!=c->raw){c->raw=raw;c->candidate_since=now;}
    if(raw!=c->keys && (uint32_t)(now-c->candidate_since)>=15000){
        unsigned old=c->keys;c->keys=raw;c->pressed|=raw&~old;
        if((raw&12)==12 && (old&12)!=12)c->hold_since=now;
    }
    if((c->keys&12)!=12)c->hold_fired=0;
    else if(!c->hold_fired && (uint32_t)(now-c->hold_since)>=600000){c->menu_requested=1;c->hold_fired=1;}
}
