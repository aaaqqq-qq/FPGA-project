#pragma once
#include <stdint.h>
#include "game_config.h"

enum {
    BOSS_WAIT = 0,
    BOSS_ENTER,
    BOSS_NORMAL,
    BOSS_ENRAGE_INTRO,
    BOSS_ENRAGED,
    BOSS_DEAD
};

/* State flags deliberately live outside the ECL VM: a spell-loop reset must
   never clear enrage/summon/death bookkeeping. The first five fields keep the
   layout used by the original host regression tests. */
typedef struct {
    int x, y, hp;
    unsigned fired, vulnerable;

    int max_hp;
    unsigned state, state_ticks, script_ticks;
    unsigned enraged, enrage_done, entered, dead, refilled;
    unsigned enter_sx, enter_sy, enter_tx, enter_ty;
    unsigned damage_dealt, damage_taken;
    unsigned shots_requested, shots_spawned, shots_rejected;
    unsigned volleys_dropped, death_tick;
} BattleBoss;

extern BattleBoss bosses[MAX_BOSSES];
extern unsigned battle_hit, battle_grazes, battle_materials;
extern unsigned summon_done, battle_cleared;

void battle_reset(unsigned difficulty, unsigned limit);
void battle_step(int px, int py);
void battle_set_legacy(unsigned enabled);
unsigned battle_legacy_mode(void);

/* Unified damage entry. Returns the damage actually applied. Damage crossing
   the half-HP line in NORMAL is clamped at the line and starts the one-shot
   enrage event; excess damage never carries into the next phase. */
int battle_apply_damage(unsigned boss_index, int amount, unsigned source);
int battle_can_damage(unsigned boss_index);
int battle_targetable(unsigned boss_index);
unsigned battle_all_defeated(void);
void battle_burst(unsigned boss_index, unsigned count);

/* R2 contact telemetry: all bullet integration still executes every tick. */
extern unsigned battle_density_slow,battle_density_skips;
extern unsigned battle_near_candidates,battle_near_fallbacks;

/* Removes owned enemy bullets while keeping private effect metadata aligned. */
unsigned battle_clear_owner(unsigned boss_index);

/* Replay checksum of VM, pending volleys/cadence and active private bullet effects. */
uint32_t battle_state_hash(uint32_t initial);

/* Ordinary-enemy owner tags128..255 use shared bullets/private effects but
 * never index boss arrays. Coordinates are integer arena pixels; speedQ12.
 * Tile54..69 is the existing sixteen-material enemy block. Returns1spawn/0reject. */
int battle_spawn_enemy_bullet(unsigned owner,int x,int y,int angle,int speed,unsigned tile);

/* Explicit synthetic GAME_LOAD controls. Ordinary gameplay always leaves active0.
 * Refill/recycle counters disclose every artificial sustaining operation. */
extern unsigned battle_load_active,battle_load_fills,battle_load_recycles,battle_load_keeps;
extern unsigned battle_load_boss_hits,battle_load_mob_hits,battle_load_player_hits,battle_load_player_damage;
void battle_load_begin(unsigned seed,unsigned count);
void battle_load_refill(unsigned count);
void battle_load_end(void);

/* CPU-only DDR scratch guards; initialization and checks are outside timed frames. */
int battle_scratch_init(void);
int battle_scratch_guards_ok(void);

/* PIPE5 preserves Boss-ECL -> motion -> later gameplay ordering. */
int battle_step_begin(int px,int py,unsigned immutable_render_epoch);
int battle_step_poll(void);
