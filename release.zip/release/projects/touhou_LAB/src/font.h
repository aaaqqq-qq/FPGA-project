#ifndef BITBLT_DEMO_FONT_H
#define BITBLT_DEMO_FONT_H
#include <stdint.h>
void draw_text(uint32_t framebuffer, unsigned x, unsigned y, const char *text,
               uint32_t color, unsigned scale);
void draw_text_clipped(uint32_t framebuffer, int x, int y, const char *text,
                       uint32_t color, unsigned scale,
                       int left, int top, int right, int bottom);
void format_uint(char *out, uint32_t value);
#endif
