#include "adv.h"
#include "adv_model.h"
#include "labx.h"
#include "bitblt.h"
#include "font.h"
#include "scene.h"
#include <stdint.h>
#include <string.h>

#define BG 0x03000000u
#define REF 0x03400000u
#define PARTICLES 0x03800000u
#define DESCRIPTORS 0x03900000u
#define MAT8 0x03a00000u
#define SOURCE0 0x03b00000u
#define SOURCE1 0x03b10000u
#define ATLAS 0x04000000u
#define MICRO_BANK 0x03a10000u
#define MICRO_MAP 0x03a20000u
#define MICRO_TEMPLATES 0x03c70000u
#define MICRO_TEMPLATE_CAP 1024u
#define ROW_PLANS 0x03c00000u
#define ROW_PLAN_CAP 8192u
#define ROW_MATERIALS 0x03c80000u
#define ROW_SORT 0x03d00000u
#define ROW_TEMPLATES 0x03c90000u
#define SLOT (64u*64u*4u)
#define VIEW_X 32u
#define VIEW_Y 160u
enum {ENTER,STATUS,EXIT,CANCEL,SHOW,VERIFY,STRESS,BAD};
enum {PATH_NONE,PATH_CPU,PATH_DIRECT8,PATH_TILE_ORDERED,PATH_TILE_COMMUTE,PATH_RECT,PATH_ROWRUN,PATH_ROW_MIXED};
enum {WHY_PREP,WHY_NONE,WHY_CPU,WHY_CAP,WHY_FUSION,WHY_64,WHY_ODD,WHY_CAPACITY,WHY_MATERIALS,WHY_FIT,WHY_MONO,WHY_ROW_FUSION,WHY_ROW_ODD,WHY_ROW_CAPACITY};
typedef struct {uint32_t id,task,v[12];unsigned op,kind,cpu;char args[192];} Request;
typedef struct {uint64_t logic,render,wait,elapsed,swaps,uf,late,scan_total,missed_scans,max_scan_gap,pixel_changes,max_logic,max_render,max_frame,min_frame,hw_cycles,overlap_cycles;uint32_t pixel_first,pixel_last,state_first,state_last,pipeline,warmup,path,reason,prime_steps,measured_steps,total_steps;uint64_t prime_logic;uint32_t frames,cases,initial,final,minimum,maximum,errors,guards,source,checked;} Result;
typedef struct {int32_t x,y;int16_t vx,vy;uint16_t age;uint8_t tile,pad;} Descriptor;
typedef struct {int32_t x,y;uint32_t word3;} MicroTemplate;
typedef struct {uint16_t first,count;} TemplateRange;
typedef struct {uint8_t x,y,w,h;} RowOp;
static Request request;
static unsigned active,pending,running,cancelled,timed_out;
static lab_reply_fn output;
static lab_restore_fn restore;
static char response[512];static unsigned used;
static uint64_t io_ticks,request_start;
static uint32_t colors[16],mask_key,guard_atlas_end;
static unsigned color_count,shape_current,dma_inflight,fast_cache_valid;
static bb_job fast_previous;
static uint64_t dma_cycles_total,batch_passes,batch_micro;
static unsigned dma_batch,dma_batch_count,micro_enabled,micro_unique,micro_size,micro_banks,micro_colors;
static uint8_t micro_ref_color[64],micro_ref_tile[64];
static TemplateRange micro_ranges[16][4],row_ranges[65];
static unsigned template_count,row_enabled,row_plan_count;

static const char *const paths[]={"none","cpu","direct8","tile8_ordered","tile8_commute","rect","rowrun","rowrun_mixed"};
static const char *const reasons[]={"not_prepared","none","cpu_reference","batch_unavailable","fusion_dynamic","size64_deferred","size_not_multiple8","descriptor_capacity","materials_over16","materials_fit","single_color_key","rowrun_fusion","rowrun_odd","rowrun_capacity_fallback"};
static const char *const ops[]={"enter","status","exit","cancel","show","verify","stress","unknown"};
static const char *const kinds[]={"alpha","key","joint"};
static volatile uint32_t *mem(uint32_t a){return (volatile uint32_t *)(uintptr_t)a;}
static AdvParticle *particles(void){return (AdvParticle *)(uintptr_t)PARTICLES;}
__attribute__((weak)) void adv_io_service(void){}
static uint64_t us(uint64_t t){return t/100u;}
int adv_cpu_poll(void){uint64_t t=bb_ticks();adv_io_service();io_ticks+=bb_ticks()-t;if(running&&us(bb_ticks()-request_start)>1800000000ull)timed_out=1;return cancelled||timed_out;}
static void add(const char *s){while(*s&&used+3<sizeof response)response[used++]=*s++;response[used]=0;}
static void number(uint64_t n){char b[21];unsigned k=0;do{b[k++]=(char)('0'+n%10);n/=10;}while(n);while(k){char s[2]={b[--k],0};add(s);}}
static void field(const char *k,uint64_t n){add(" ");add(k);add("=");number(n);}
static void begin(const char *tag,const Request *r){used=0;response[0]=0;add(tag);field("id",r->id);add(" op=");add(ops[r->op]);}
static void send(void){if(output)output(response);adv_io_service();}
static void done(const Request *r,const char *status,const char *code,unsigned completed,uint64_t elapsed){begin("ADV_DONE",r);add(" status=");add(status);add(" code=");add(code);field("completed",completed);field("active",active);field("elapsed_us",elapsed);send();}
static int index_of(const char *s,const char *const *list,unsigned n){for(unsigned i=0;i<n;++i)if(!strcmp(s,list[i]))return (int)i;return -1;}
static int decimal(const char *s,uint32_t *v){uint32_t n=0;if(!*s)return 0;while(*s){unsigned d=(unsigned)(*s++-'0');if(d>9||n>(UINT32_MAX-d)/10u)return 0;n=n*10u+d;}*v=n;return 1;}
static uint32_t hash_byte(uint32_t h,unsigned c){return (h^c)*16777619u;}
static void state(const Request *r){begin("ADV_STATE",r);field("active",active);field("running",running||dma_inflight);send();}
void adv_init(lab_reply_fn out,lab_restore_fn back){output=out;restore=back;active=pending=running=cancelled=timed_out=dma_inflight=fast_cache_valid=0;}
unsigned adv_active(void){return active;}
unsigned adv_pending(void){return pending||running||dma_inflight;}
int adv_command(const char *input){
 Request r;memset(&r,0,sizeof r);r.op=BAD;char copy[256],*t[20];unsigned n=0,nt=0;
 if(!input)return 0;if(*input==':')++input;if(strncmp(input,"adv",3)||(input[3]&&input[3]!=' '))return 0;
 while(input[n]&&n<sizeof copy-1)++n;if(input[n]){done(&r,"ERROR","PARSE",0,0);return 1;}memcpy(copy,input,n+1);
 char *p=copy;while(*p){while(*p==' ')++p;if(!*p)break;if(nt==20){done(&r,"ERROR","PARSE",0,0);return 1;}t[nt++]=p;while(*p&&*p!=' ')++p;if(*p)*p++=0;}
 if(nt<3||!decimal(t[1],&r.id)||!r.id||r.id>2147483647u){r.id=0;done(&r,"ERROR","PARSE",0,0);return 1;}
 int op=index_of(t[2],ops,BAD);r.op=op<0?BAD:(unsigned)op;unsigned good=1;
 if(r.op==SHOW){int k=nt==14?index_of(t[3],kinds,3):-1;if(k<0)good=0;else{r.kind=(unsigned)k;for(unsigned i=0;i<10;++i)good&=decimal(t[i+4],&r.v[i]);}
  if(good&&(r.v[0]>3||r.v[1]<8||r.v[1]>64||r.v[2]>5||r.v[3]>0xffffff||r.v[4]>0xffffff||r.v[5]>255||r.v[6]>0xffffff||r.v[7]>3||r.v[8]>2||r.v[9]>1))good=0;
 }else if(r.op==VERIFY){int k=nt==4?index_of(t[3],kinds,3):-1;if(k<0)good=0;else r.kind=(unsigned)k;
 }else if(r.op==STRESS){const char *const names[]={"fpga","cpu"};int b=nt==16?index_of(t[3],names,2):-1;if(b<0)good=0;else{r.cpu=(unsigned)b;for(unsigned i=0;i<12;++i)good&=decimal(t[i+4],&r.v[i]);}
  if(good&&(!r.v[0]||r.v[0]>ADV_MAX||r.v[1]<8||r.v[1]>64||r.v[2]>5||r.v[3]>0xffffff||r.v[4]>0xffffff||r.v[5]>0xffffff||r.v[6]>2||r.v[7]>255||r.v[8]>1||r.v[9]>5||!r.v[10]||r.v[10]>ADV_FRAMES_MAX||!r.v[11]||(r.v[9]&&r.v[0]>ADV_PHYS_MAX)))good=0;
 }else if(nt!=3||r.op==BAD)good=0;
 if(!good){done(&r,"ERROR","RANGE",0,0);return 1;}
 r.task=2166136261u;for(p=t[2];*p;++p)r.task=hash_byte(r.task,(unsigned char)*p);
 unsigned a=0;for(unsigned i=3;i<nt;++i){r.task=hash_byte(r.task,' ');if(i>3)r.args[a++]=',';for(p=t[i];*p;++p){if(a+1>=sizeof r.args){done(&r,"ERROR","PARSE",0,0);return 1;}r.args[a++]=*p;r.task=hash_byte(r.task,(unsigned char)*p);}}r.args[a]=0;
 if(r.op==CANCEL){if(pending||running)cancelled=1;begin("ADV_ACK",&r);add(" status=ACCEPTED");send();done(&r,"PASS","OK",0,0);return 1;}
 if(r.op==STATUS){begin("ADV_ACK",&r);add(" status=ACCEPTED");send();state(&r);done(&r,"PASS","OK",0,0);return 1;}
 if(lab_active()||lab_pending()||labx_active()||labx_pending()){done(&r,"ERROR","LEGACY_ACTIVE",0,0);return 1;}
 if(pending||running||(dma_inflight&&r.op!=EXIT)){done(&r,"ERROR","BUSY",0,0);return 1;}
 if((r.op==ENTER&&active)||(r.op!=ENTER&&!active)){done(&r,"ERROR","MODE",0,0);return 1;}
 request=r;pending=1;cancelled=timed_out=0;begin("ADV_ACK",&r);add(" status=QUEUED");send();return 1;
}
static void adv_fence(void){
#ifndef BB_HOST_TEST
 __asm__ volatile("fence iorw, iorw":::"memory");
#else
 __asm__ volatile("":::"memory");
#endif
}
static int wait_job(unsigned timeout){uint64_t start=bb_ticks();unsigned spins=0;for(;;){uint32_t status=bb_read(BB_STATUS);
 if(status&BB_ERROR){if(!(status&BB_BUSY))dma_inflight=0;fast_cache_valid=0;return 0;}
 if(!(status&BB_BUSY)&&(status&BB_DONE)){if(dma_inflight){dma_cycles_total+=bb_read(BB_CYCLES);if(dma_batch){++batch_passes;batch_micro+=dma_batch_count;}dma_inflight=0;}adv_fence();return 1;}
 if(!(++spins&127))adv_cpu_poll(); /* Cancel cannot release an unfinished DMA. */
 if(us(bb_ticks()-start)>=timeout){fast_cache_valid=0;return 0;}}}
/* The immutable BG/atlas/MAT8 were published before timing. Only the batch
   descriptor state needs a fresh publish each frame. No per-sprite cache flush. */
static int fast_launch(const bb_job *j){
 if(dma_inflight&&!wait_job(5000000))return 0;
 if(adv_cpu_poll()||(bb_read(BB_STATUS)&BB_BUSY))return 0;
 const unsigned regs[]={BB_OP,BB_SRC,BB_DST,BB_SRC_STRIDE,BB_DST_STRIDE,BB_WIDTH,BB_HEIGHT,BB_FILL,BB_ALPHA,BB_KEY_REG,BB_FLAGS};
 const uint32_t *v=(const uint32_t *)j;uint32_t *old=(uint32_t *)&fast_previous;
 bb_write(BB_STATUS,BB_DONE|BB_ERROR);
 for(unsigned i=0;i<11;++i)if(!fast_cache_valid||old[i]!=v[i]){bb_write(regs[i],v[i]);old[i]=v[i];}
 fast_cache_valid=1;dma_batch=j->op==2;dma_batch_count=dma_batch?bb_read(0x44):0;adv_fence();bb_write(BB_CMD,1);dma_inflight=1;return 1;
}
/* Do not mutate the live descriptor list before this request's complete DMA
   snapshot: NEW BUSY + >=1us + 4KiB materials + all N*16 descriptors, or DONE. */
static int batch_snapshot_ready(unsigned n){unsigned accepted=0,spins=0;uint64_t at=0,start=bb_ticks();adv_fence();
 for(;;){uint32_t status=bb_read(BB_STATUS);if(status&BB_ERROR)return 0;
  if((status&BB_BUSY)&&!accepted){accepted=1;at=bb_ticks();}
  if((status&(BB_BUSY|BB_DONE))==BB_DONE)return 1;
  if(accepted&&us(bb_ticks()-at)>=1&&bb_read(BB_READ_BYTES)>=4096u+n*16u){adv_fence();return 1;}
  if(!(++spins&127)&&adv_cpu_poll())return 0;
  if(us(bb_ticks()-start)>=5000000)return 0;
 }
}
static int execute(const bb_job *j,unsigned cpu){if(adv_cpu_poll())return 0;if(cpu)return bb_cpu_execute(j)==BB_OK;return bb_submit(j)==BB_OK&&wait_job(2000000);}

static int fill(uint32_t dst,unsigned x,unsigned y,unsigned w,unsigned h,uint32_t color){
 for(unsigned offset=0;offset<w;offset+=1024){unsigned k=w-offset;if(k>1024)k=1024;bb_job j={BB_FILL_OP,0,dst+y*5120+(x+offset)*4,0,5120,k,h,color,255,0,0};if(!execute(&j,0))return 0;}return 1;
}
static int copy_view(uint32_t fb,unsigned cpu){bb_job j={BB_COPY_OP,BG+VIEW_Y*5120+VIEW_X*4,fb+VIEW_Y*5120+VIEW_X*4,5120,5120,ADV_W,ADV_H,0,255,0,0};return execute(&j,cpu);}
static uint32_t back(void){uint32_t f=bb_read(BB_FRONT);return f==BB_FB0?BB_FB1:f==BB_FB1?BB_FB0:0;}
static void print_number(uint32_t fb,unsigned x,unsigned y,const char *s,uint64_t value){used=0;response[0]=0;add(s);number(value);draw_text(fb,x,y,response,0x354767,2);}
static int panel(uint32_t fb,const char *title){if(!fill(fb,0,0,1280,720,0xf3f5fa)||!fill(fb,0,0,1280,136,0xffffff))return 0;
 draw_text(fb,28,20,"TI60 / ADV1 / REAL FPGA OUTPUT",0x364363,2);draw_text(fb,28,52,title,0x2268ce,2);
 draw_text(fb,28,90,"TASK ALPHA + EXACT RGB KEY / PC CONTROL",0x677087,1);return bb_publish()==BB_OK;}
static uint32_t pattern_color(unsigned pattern,uint32_t bg,unsigned x,unsigned y){
 if(pattern==1)return ((x/24)^(y/24))&1?0xc5cfdf:0xf5f7fb;
 if(pattern==2){unsigned xx=32+x%1024,yy=16+y%688;return mem(0x01a00000u)[yy*1280+xx];}return bg;
}
static int make_background(unsigned pattern,uint32_t bg){
 for(unsigned y=0;y<720;++y){if(!(y&7)&&adv_cpu_poll())return 0;for(unsigned x=0;x<1280;++x)mem(BG)[y*1280+x]=(x>=VIEW_X&&x<VIEW_X+ADV_W&&y>=VIEW_Y&&y<VIEW_Y+ADV_H)?pattern_color(pattern,bg,x-VIEW_X,y-VIEW_Y):0xf3f5fa;}
 return bb_publish()==BB_OK;
}
static int background_check(unsigned pattern,uint32_t bg,Result *m){bb_acquire();for(unsigned y=0;y<720;++y){if(!(y&7)&&adv_cpu_poll())return 0;for(unsigned x=0;x<1280;++x){uint32_t expected=x>=VIEW_X&&x<VIEW_X+ADV_W&&y>=VIEW_Y&&y<VIEW_Y+ADV_H?pattern_color(pattern,bg,x-VIEW_X,y-VIEW_Y):0xf3f5fa;m->source+=mem(BG)[y*1280+x]!=expected;}}return !m->source;}
static int initialize_banks(const char *title){for(unsigned k=0;k<2;++k){uint32_t fb=back();if(!fb||!panel(fb,title)||!copy_view(fb,0)||bb_swap_wait(fb,1000000)!=BB_OK)return 0;}return 1;}
static const uint32_t guarded[]={BG+BB_FRAME_BYTES,REF+BB_FRAME_BYTES,PARTICLES+ADV_MAX*sizeof(AdvParticle),DESCRIPTORS+ADV_MAX*sizeof(Descriptor),MAT8+4096,SOURCE0+SLOT,SOURCE1+SLOT,BB_FB0+BB_FRAME_BYTES,BB_FB1+BB_FRAME_BYTES};
static void guards_init(void){for(unsigned t=0;t<sizeof guarded/sizeof guarded[0];++t)for(unsigned i=0;i<16;++i)mem(guarded[t])[i]=0x62e719b3u^(t*37+i);}
static void guards_check(Result *m){bb_acquire();for(unsigned t=0;t<sizeof guarded/sizeof guarded[0];++t)for(unsigned i=0;i<16;++i)m->guards+=mem(guarded[t])[i]!=(0x62e719b3u^(t*37+i));
 if(guard_atlas_end)for(unsigned i=0;i<16;++i)m->guards+=mem(guard_atlas_end)[i]!=(0x1bc873d2u+i);}
static uint32_t sample_material(unsigned material,unsigned size,unsigned shape,uint32_t color,unsigned x,unsigned y){
 if(!material)return adv_shape(shape,size,x,y)?color:BB_KEY;
 unsigned tile=material==1?0:material==2?4:8,w,h;uint32_t address;if(!scene_art_info(tile,&address,&w,&h))return BB_KEY;
 return mem(address)[(y*h/size)*w+(x*w/size)];
}
static int prepare_source(unsigned material,unsigned size,unsigned shape,uint32_t color){
 for(unsigned y=0;y<64;++y){if(!(y&7)&&adv_cpu_poll())return 0;for(unsigned x=0;x<64;++x){mem(SOURCE0)[y*64+x]=(x<size&&y<size)?sample_material(material,size,shape,color,x,y):0;mem(SOURCE1)[y*64+x]=(x<size&&y<size)?sample_material(0,size,1,color^0x00ffffu,x,y):0;}}
 return bb_publish()==BB_OK;
}
static int draw_source(uint32_t fb,unsigned x,unsigned y,unsigned size,uint32_t src,unsigned alpha,uint32_t key,unsigned flags,unsigned cpu){
 bb_job j={BB_COPY_OP,src,fb+y*5120+x*4,256,5120,size,size,0,alpha,key,flags};return execute(&j,cpu);
}
static int check_rect(uint32_t fb,unsigned x,unsigned y,unsigned size,unsigned alpha,uint32_t key,unsigned flags,Result *m){
 bb_acquire();for(unsigned yy=0;yy<size;++yy)for(unsigned xx=0;xx<size;++xx){uint32_t d=mem(BG)[(y+yy)*1280+x+xx],s=mem(SOURCE0)[yy*64+xx];uint32_t expected=adv_golden(s,d,alpha,key,flags);m->errors+=mem(fb)[(y+yy)*1280+x+xx]!=expected;++m->checked;}return !m->errors;
}
/* Snapshot untouched destination pixels, then compute expected changes with the
   independent scalar model before submitting hardware. This checks all test
   regions and destination pixels outside them without reusing the HW result. */
static int reference_begin(uint32_t fb){bb_acquire();for(unsigned y=0;y<720;++y){if(!(y&7)&&adv_cpu_poll())return 0;for(unsigned x=0;x<1280;++x)mem(REF)[y*1280+x]=mem(fb)[y*1280+x];}return 1;}
static void reference_job(uint32_t src,unsigned x,unsigned y,unsigned size,unsigned alpha,uint32_t key,unsigned flags){
 for(unsigned yy=0;yy<size;++yy)for(unsigned xx=0;xx<size;++xx){unsigned at=(y+yy)*1280+x+xx;mem(REF)[at]=adv_golden(mem(src)[yy*64+xx],mem(REF)[at],alpha,key,flags);}
}
static int reference_check(uint32_t fb,Result *m){bb_acquire();for(unsigned y=0;y<720;++y){if(!(y&7)&&adv_cpu_poll())return 0;for(unsigned x=0;x<1280;++x){m->errors+=mem(fb)[y*1280+x]!=mem(REF)[y*1280+x];++m->checked;}}return !m->errors;}
static uint32_t verify_pixel(unsigned kind,unsigned k,unsigned xx,unsigned yy){
 if(!kind)return ((xx&1)?0xff0000u:0x007fffu)^((yy*11u)<<8);
 if(kind==2){switch((xx+yy)%4){case 0:return BB_KEY;case 1:return BB_KEY^1u;case 2:return BB_KEY|0xa5000000u;default:return 0x10a0ffu;}}
 switch(k){case 0:return BB_KEY;case 1:return 0x102030u;case 2:return ((xx+yy)&1)?BB_KEY:0x10a0ffu;case 3:return BB_KEY^1u;case 4:return BB_KEY|0xa5000000u;default:return ((xx+yy)&1)?BB_KEY:0xff6000u;}
}
static int show_case(const Request *r,Result *m){unsigned size=r->v[1],panels=r->kind==0?1:r->kind==1?2:4;uint32_t fb=back();
 if(!make_background(r->v[8],r->v[4])||!panel(fb,r->kind==0?"ALPHA / LAYER ORDER":r->kind==1?"COLOR KEY / BEFORE AND AFTER":"ALPHA + COLOR KEY / FOUR STATES")||!copy_view(fb,0)||!prepare_source(r->v[0],size,r->v[2],r->v[3])||!reference_begin(fb))return 0;
 uint64_t t;
 for(unsigned p=0;p<panels;++p){unsigned x=VIEW_X+36+p*240,y=VIEW_Y+140,flags=r->kind==0?r->v[7]:r->kind==1?(p?2:0):p;
  if(r->kind==0){
   /* Two actual ordered layers: retain corresponding independent pixel reference. */
   uint32_t first=r->v[9]?SOURCE0:SOURCE1,last=r->v[9]?SOURCE1:SOURCE0;
   reference_job(first,x+size/3,y+size/3,size,r->v[5],r->v[6],flags);reference_job(last,x,y,size,r->v[5],r->v[6],flags);
   t=bb_ticks();uint64_t io=io_ticks;
   if(!draw_source(fb,x+size/3,y+size/3,size,first,r->v[5],r->v[6],flags,0)||!draw_source(fb,x,y,size,last,r->v[5],r->v[6],flags,0))return 0;m->render+=us(bb_ticks()-t-(io_ticks-io));
  }else {reference_job(SOURCE0,x,y,size,r->v[5],r->v[6],flags);t=bb_ticks();uint64_t io=io_ticks;if(!draw_source(fb,x,y,size,SOURCE0,r->v[5],r->v[6],flags,0))return 0;m->render+=us(bb_ticks()-t-(io_ticks-io));}
 }
 if(!reference_check(fb,m))return 0;
 for(unsigned p=0;p<panels;++p){unsigned x=VIEW_X+36+p*240,y=VIEW_Y+140;
  draw_text(fb,x,y-40,r->kind==1?(p?"KEY ON":"KEY OFF"):r->kind==2?(p==0?"OFF / OFF":p==1?"ALPHA ONLY":p==2?"KEY ONLY":"ALPHA + KEY"):"ORDERED LAYERS",0x263c63,1);
 }
 print_number(fb,32,118,"ALPHA ",r->v[5]);print_number(fb,340,118,"KEY RGB ",r->v[6]);print_number(fb,700,118,"PIXEL ERRORS ",m->errors);
 t=bb_ticks();if(bb_swap_wait(fb,1000000)!=BB_OK)return 0;m->wait=us(bb_ticks()-t);m->swaps=1;m->frames=1;m->cases=panels;m->initial=m->final=m->minimum=m->maximum=panels;
 bb_acquire();for(unsigned y=0;y<64;++y)for(unsigned x=0;x<64;++x){uint32_t expected=x<size&&y<size?sample_material(r->v[0],size,r->v[2],r->v[3],x,y):0;m->source+=mem(SOURCE0)[y*64+x]!=expected;uint32_t other=x<size&&y<size?sample_material(0,size,1,r->v[3]^0x00ffffu,x,y):0;m->source+=mem(SOURCE1)[y*64+x]!=other;}
 return !m->errors;
}
static int verify_case(const Request *r,Result *m){uint32_t fb=back();if(!make_background(1,0x244b71)||!panel(fb,"NUMERIC VERIFICATION / ACTUAL DDR READBACK")||!copy_view(fb,0)||!reference_begin(fb))return 0;
 unsigned cases=r->kind==0?256:r->kind==1?8:4;
 for(unsigned k=0;k<cases;++k){if(adv_cpu_poll())return 0;unsigned x=VIEW_X+(k%32)*28,y=VIEW_Y+(k/32)*36,size=16,alpha=r->kind==0?k:128,flags=r->kind==0?1:r->kind==1?2:k;uint32_t key=BB_KEY;
  for(unsigned i=0;i<SLOT/4;++i){mem(SOURCE0)[i]=0x839b17cdu;mem(SOURCE1)[i]=0x5cc713e9u;}
  for(unsigned yy=0;yy<size;++yy)for(unsigned xx=0;xx<size;++xx)mem(SOURCE0)[yy*64+xx]=verify_pixel(r->kind,k,xx,yy);
  if(bb_publish()!=BB_OK)return 0;
  /* Key cases6/7 exercise legal offset and non-tight row layout, respecting source guards. */
  unsigned off=r->kind==1&&k==6?4:r->kind==1&&k==7?4092:0;
  if(off){for(unsigned yy=0;yy<size;++yy)for(unsigned xx=0;xx<size;++xx)mem(SOURCE1+off)[yy*64+xx]=mem(SOURCE0)[yy*64+xx];if(bb_publish()!=BB_OK)return 0;}
  reference_job(off?SOURCE1+off:SOURCE0,x,y,size,alpha,key,flags);
  uint64_t start=bb_ticks(),io=io_ticks;
  if(!draw_source(fb,x,y,size,off?SOURCE1+off:SOURCE0,alpha,key,flags,0))return 0;m->render+=us(bb_ticks()-start-(io_ticks-io));
  bb_acquire();
  for(unsigned i=0;i<SLOT/4;++i){unsigned yy=i/64,xx=i%64;uint32_t expected=yy<size&&xx<size?verify_pixel(r->kind,k,xx,yy):0x839b17cdu;m->source+=mem(SOURCE0)[i]!=expected;
   uint32_t expected1=0x5cc713e9u;if(off&&i>=off/4){unsigned at=i-off/4;yy=at/64;xx=at%64;if(yy<size&&xx<size)expected1=verify_pixel(r->kind,k,xx,yy);}m->source+=mem(SOURCE1)[i]!=expected1;}
  ++m->cases;
 }
 if(!reference_check(fb,m))return 0;
 print_number(fb,32,118,"CASES PASS ",m->cases);print_number(fb,490,118,"PIXEL ERRORS ",m->errors);uint64_t t=bb_ticks();if(bb_swap_wait(fb,1000000)!=BB_OK)return 0;m->wait=us(bb_ticks()-t);m->swaps=1;m->frames=1;m->initial=m->final=m->minimum=m->maximum=cases;return 1;
}
static uint32_t atlas_address(unsigned size,unsigned color){return ATLAS+((size-8)*color_count+color)*SLOT;}
static uint32_t texture_pixel(unsigned size,unsigned color,unsigned x,unsigned y){return x<size&&y<size?(adv_shape(shape_current,size,x,y)?colors[color]:mask_key):0;}
static volatile uint8_t *micro_map(void){return (volatile uint8_t *)(uintptr_t)MICRO_MAP;}
static uint32_t micro_address(unsigned slot){return MICRO_BANK+slot*256u;}
static volatile MicroTemplate *micro_templates(void){return (volatile MicroTemplate *)(uintptr_t)MICRO_TEMPLATES;}
static int prepare_templates(void){unsigned side=micro_size/8,tiles=side*side;template_count=0;memset(micro_ranges,0,sizeof micro_ranges);
 for(unsigned c=0;c<micro_colors;++c)for(unsigned bank=0;bank<micro_banks;++bank){TemplateRange *range=&micro_ranges[c][bank];range->first=(uint16_t)template_count;
  for(unsigned tile=0;tile<tiles;++tile){unsigned slot=micro_map()[c*64+tile];if(slot==255||slot/16!=bank)continue;if(template_count==MICRO_TEMPLATE_CAP)return 0;
   volatile MicroTemplate *t=micro_templates()+template_count++;t->x=((int)(tile%side)*8+4-(int)micro_size/2)*4096;t->y=((int)(tile/side)*8+4-(int)micro_size/2)*4096;t->word3=(slot&15u)<<16;++range->count;}
 }
 /* Ignored word2 is initialized once, not on every emitted tile. */
 for(unsigned i=0;i<ADV_MAX;++i)mem(DESCRIPTORS)[i*4+2]=0;
 for(unsigned i=0;i<16;++i){mem(MICRO_TEMPLATES-64)[i]=0x29c7e591u+i;mem(MICRO_TEMPLATES+MICRO_TEMPLATE_CAP*sizeof(MicroTemplate))[i]=0x629f31d7u+i;}
 return 1;
}
static uint32_t micro_guard_address(unsigned i){return i==0?MICRO_BANK-64:i==1?MICRO_BANK+16384:i==2?MICRO_MAP-64:MICRO_MAP+1024;}
static void micro_guards_init(void){for(unsigned i=0;i<4;++i)for(unsigned k=0;k<16;++k)mem(micro_guard_address(i))[k]=0x46d93ba1u^(i*31+k);}
static uint32_t row_guard_address(unsigned i){return i==0?ROW_PLANS-64:i==1?ROW_PLANS+ROW_PLAN_CAP*4:i==2?ROW_MATERIALS-64:i==3?ROW_MATERIALS+4096:i==4?ROW_SORT-64:i==5?ROW_SORT+ADV_MAX*16:i==6?ROW_TEMPLATES-64:ROW_TEMPLATES+ROW_PLAN_CAP*sizeof(MicroTemplate);}
static uint32_t row_word(unsigned x,unsigned y,unsigned w,unsigned h){return x|(y<<8)|(w<<16)|(h<<24);}
static int row_append(unsigned size,unsigned x,unsigned y,unsigned w,unsigned h){if(row_plan_count==ROW_PLAN_CAP)return 0;mem(ROW_PLANS)[row_plan_count++]=row_word(x,y,w,h);++row_ranges[size].count;return 1;}
static int prepare_rowrun(const Request *r,Result *m,unsigned reason){
 unsigned used_colors=color_count<r->v[0]?color_count:r->v[0];if(!r->v[8])return 1;for(unsigned c=1;c<used_colors;++c)if(colors[c]!=colors[0])return 1;
 row_plan_count=0;memset(row_ranges,0,sizeof row_ranges);for(unsigned i=0;i<ROW_PLAN_CAP;++i)mem(ROW_PLANS)[i]=0;
 for(unsigned size=8;size<=64;++size){row_ranges[size].first=(uint16_t)row_plan_count;
  for(unsigned ty=0;ty<size;ty+=8){if(adv_cpu_poll())return 0;for(unsigned tx=0;tx<size;tx+=8){unsigned solid=tx+8<=size&&ty+8<=size;
   for(unsigned y=ty;y<ty+8&&y<size;++y)for(unsigned x=tx;x<tx+8&&x<size;++x)solid&=adv_shape(shape_current,size,x,y);
   if(solid){if(!row_append(size,tx,ty,8,8))return 0;continue;}
   for(unsigned y=ty;y<ty+8&&y<size;++y){unsigned x=tx,end=tx+8<size?tx+8:size;while(x<end){while(x<end&&!adv_shape(shape_current,size,x,y))++x;unsigned first=x;while(x<end&&adv_shape(shape_current,size,x,y))++x;if(x>first&&!row_append(size,first,y,x-first,1))return 0;}}
  }}
 }
 /* Compile relative Q12 geometry once. Only edge particles require scalar
    clipping; interior rows reuse the same 12-load gather as fixed microtiles. */
 for(unsigned i=0;i<row_plan_count;++i){uint32_t op=mem(ROW_PLANS)[i];volatile MicroTemplate *t=(volatile MicroTemplate *)(uintptr_t)ROW_TEMPLATES+i;t->x=((op&255u)+4)*4096;t->y=(((op>>8)&255u)+4)*4096;t->word3=(((op>>24)==8)?15:((op>>16)&255u)-1)<<16;}
 for(unsigned mat=0;mat<16;++mat)for(unsigned y=0;y<8;++y)for(unsigned x=0;x<8;++x){unsigned fg=mat==15||(!y&&(mat<8?x<mat+1:x>=8-(mat-7)));mem(ROW_MATERIALS)[mat*64+y*8+x]=fg?colors[0]:mask_key;}
 for(unsigned i=0;i<ADV_MAX;++i){mem(DESCRIPTORS)[i*4+2]=0;mem(ROW_SORT)[i*4+2]=0;}
 for(unsigned i=0;i<8;++i)for(unsigned k=0;k<16;++k)mem(row_guard_address(i))[k]=0x42e916cbu^(i*37+k);
 row_enabled=1;m->path=PATH_ROWRUN;m->reason=reason;return bb_publish()==BB_OK;
}
static int check_rowrun(Result *m){if(!row_enabled)return 1;bb_acquire();
 for(unsigned i=0;i<8;++i)for(unsigned k=0;k<16;++k)m->guards+=mem(row_guard_address(i))[k]!=(0x42e916cbu^(i*37+k));
 unsigned index=0;for(unsigned size=8;size<=64;++size){m->source+=row_ranges[size].first!=index;unsigned first=index;
  for(unsigned ty=0;ty<size;ty+=8){if(adv_cpu_poll())return 0;for(unsigned tx=0;tx<size;tx+=8){unsigned solid=tx+8<=size&&ty+8<=size;
   for(unsigned y=ty;y<ty+8&&y<size;++y)for(unsigned x=tx;x<tx+8&&x<size;++x)solid&=adv_shape(shape_current,size,x,y);
   if(solid){m->source+=index>=ROW_PLAN_CAP||mem(ROW_PLANS)[index]!=row_word(tx,ty,8,8);++index;continue;}
   for(unsigned y=ty;y<ty+8&&y<size;++y){unsigned x=tx,end=tx+8<size?tx+8:size;while(x<end){while(x<end&&!adv_shape(shape_current,size,x,y))++x;unsigned begin=x;while(x<end&&adv_shape(shape_current,size,x,y))++x;if(x>begin){m->source+=index>=ROW_PLAN_CAP||mem(ROW_PLANS)[index]!=row_word(begin,y,x-begin,1);++index;}}}
  }}m->source+=row_ranges[size].count!=index-first;
 }m->source+=index!=row_plan_count;for(;index<ROW_PLAN_CAP;++index)m->source+=mem(ROW_PLANS)[index]!=0;
 for(unsigned mat=0;mat<16;++mat)for(unsigned y=0;y<8;++y)for(unsigned x=0;x<8;++x){unsigned fg=mat==15||(!y&&(mat<8?x<mat+1:x>=8-(mat-7)));m->source+=mem(ROW_MATERIALS)[mat*64+y*8+x]!=(fg?colors[0]:mask_key);}
 for(unsigned i=0;i<row_plan_count;++i){uint32_t op=mem(ROW_PLANS)[i];volatile MicroTemplate *t=(volatile MicroTemplate *)(uintptr_t)ROW_TEMPLATES+i;m->source+=t->x!=(int32_t)(((op&255u)+4)*4096);m->source+=t->y!=(int32_t)((((op>>8)&255u)+4)*4096);m->source+=t->word3!=((((op>>24)==8)?15:((op>>16)&255u)-1)<<16);}
 return !m->source&&!m->guards;
}
static unsigned prepare_micro(const Request *r,Result *m){
 micro_enabled=micro_unique=row_enabled=0;m->path=r->cpu?PATH_CPU:PATH_RECT;m->reason=r->cpu?WHY_CPU:WHY_PREP;
 if(r->cpu)return 1;if(!(bb_read(0x4c)&2)){m->reason=WHY_CAP;return 1;}
 if(r->v[9]==2){m->reason=WHY_FUSION;return prepare_rowrun(r,m,WHY_ROW_FUSION);}if(r->v[1]==8){m->path=PATH_DIRECT8;m->reason=WHY_NONE;return 1;}
 if(r->v[1]==64){m->reason=WHY_64;return 1;}if(r->v[1]%8){m->reason=WHY_ODD;return prepare_rowrun(r,m,WHY_ROW_ODD);}
 micro_size=r->v[1];unsigned side=micro_size/8,tiles=side*side;if(r->v[0]>ADV_MAX/tiles){m->reason=WHY_CAPACITY;return 1;}
 micro_colors=color_count<r->v[0]?color_count:r->v[0];unsigned mono=r->v[8]!=0;for(unsigned c=1;c<micro_colors;++c)mono&=colors[c]==colors[0];unsigned limit=mono?64:16;
 for(unsigned i=0;i<1024;++i)micro_map()[i]=255;
 for(unsigned i=0;i<4096;++i)mem(MICRO_BANK)[i]=mask_key;
 for(unsigned c=0;c<micro_colors;++c)for(unsigned tile=0;tile<tiles;++tile){if(adv_cpu_poll())return 0;unsigned tx=tile%side*8,ty=tile/side*8,empty=1;
  for(unsigned y=0;y<8;++y)for(unsigned x=0;x<8;++x)empty&=texture_pixel(micro_size,c,tx+x,ty+y)==mask_key;
  if(empty&&r->v[8])continue;
  unsigned slot=0;for(;slot<micro_unique;++slot){unsigned equal=1;for(unsigned y=0;y<8&&equal;++y)for(unsigned x=0;x<8;++x)if(mem(micro_address(slot))[y*8+x]!=texture_pixel(micro_size,c,tx+x,ty+y)){equal=0;break;}if(equal)break;}
  if(slot==micro_unique){if(micro_unique==limit){m->reason=WHY_MATERIALS;return 1;}micro_ref_color[slot]=(uint8_t)c;micro_ref_tile[slot]=(uint8_t)tile;
   for(unsigned y=0;y<8;++y)for(unsigned x=0;x<8;++x)mem(micro_address(slot))[y*8+x]=texture_pixel(micro_size,c,tx+x,ty+y);++micro_unique;}
  micro_map()[c*64+tile]=(uint8_t)slot;
 }
 if(!micro_unique){m->reason=WHY_MATERIALS;return 1;}micro_banks=(micro_unique+15)/16;micro_enabled=1;
 m->path=micro_banks==1?PATH_TILE_ORDERED:PATH_TILE_COMMUTE;m->reason=micro_banks==1?WHY_FIT:WHY_MONO;
 micro_guards_init();return prepare_templates()&&bb_publish()==BB_OK;
}
static int check_micro(const Request *r,Result *m){if(!micro_enabled)return 1;bb_acquire();unsigned side=micro_size/8,tiles=side*side;
 for(unsigned i=0;i<4;++i)for(unsigned k=0;k<16;++k)m->guards+=mem(micro_guard_address(i))[k]!=(0x46d93ba1u^(i*31+k));
 for(unsigned slot=0;slot<64;++slot){unsigned tile=micro_ref_tile[slot],c=micro_ref_color[slot];for(unsigned y=0;y<8;++y)for(unsigned x=0;x<8;++x){uint32_t expected=slot<micro_unique?texture_pixel(micro_size,c,tile%side*8+x,tile/side*8+y):mask_key;m->source+=mem(micro_address(slot))[y*8+x]!=expected;}}
 for(unsigned c=0;c<16;++c)for(unsigned tile=0;tile<64;++tile){unsigned slot=micro_map()[c*64+tile];if(c>=micro_colors||tile>=tiles){m->source+=slot!=255;continue;}unsigned empty=1;
  for(unsigned y=0;y<8;++y)for(unsigned x=0;x<8;++x){uint32_t expected=texture_pixel(micro_size,c,tile%side*8+x,tile/side*8+y);empty&=expected==mask_key;if(slot!=255)m->source+=slot>=micro_unique||mem(micro_address(slot))[y*8+x]!=expected;}
  if(slot==255)m->source+=!(r->v[8]&&empty);
 }
 for(unsigned i=0;i<16;++i){m->guards+=mem(MICRO_TEMPLATES-64)[i]!=0x29c7e591u+i;m->guards+=mem(MICRO_TEMPLATES+MICRO_TEMPLATE_CAP*sizeof(MicroTemplate))[i]!=0x629f31d7u+i;}
 unsigned expected_index=0;for(unsigned c=0;c<micro_colors;++c)for(unsigned bank=0;bank<micro_banks;++bank){TemplateRange range=micro_ranges[c][bank];m->source+=range.first!=expected_index;unsigned count=0;
  for(unsigned tile=0;tile<tiles;++tile){unsigned slot=micro_map()[c*64+tile];if(slot==255||slot/16!=bank)continue;volatile MicroTemplate *t=micro_templates()+expected_index++;m->source+=t->x!=((int)(tile%side)*8+4-(int)micro_size/2)*4096;m->source+=t->y!=((int)(tile/side)*8+4-(int)micro_size/2)*4096;m->source+=t->word3!=(slot&15u)<<16;++count;}m->source+=range.count!=count;
 }m->source+=expected_index!=template_count;return !m->source&&!m->guards;
}
static int prepare_atlas(const Request *r){color_count=!r->v[6]?1:r->v[6]==1?3:16;shape_current=r->v[2];
 for(unsigned c=0;c<color_count;++c)colors[c]=adv_color(r->v[3],r->v[4],r->v[5],r->v[6],c);
 mask_key=BB_KEY;for(;;){unsigned match=0;for(unsigned c=0;c<color_count;++c)match|=colors[c]==mask_key;if(!match)break;mask_key=(mask_key+0x010101u)&0xffffffu;}
 unsigned first=r->v[9]==2?8:r->v[1],last=r->v[9]==2?64:r->v[1];
 for(unsigned size=first;size<=last;++size)for(unsigned c=0;c<color_count;++c)for(unsigned y=0;y<64;++y){if(!(y&7)&&adv_cpu_poll())return 0;for(unsigned x=0;x<64;++x)mem(atlas_address(size,c))[y*64+x]=texture_pixel(size,c,x,y);}
 for(unsigned c=0;c<16;++c)for(unsigned y=0;y<8;++y)for(unsigned x=0;x<8;++x)mem(MAT8)[c*64+y*8+x]=texture_pixel(8,c%color_count,x,y);
 guard_atlas_end=ATLAS+57*color_count*SLOT;for(unsigned i=0;i<16;++i)mem(guard_atlas_end)[i]=0x1bc873d2u+i;
 return bb_publish()==BB_OK;
}
static int check_atlas(const Request *r,Result *m){bb_acquire();unsigned first=r->v[9]==2?8:r->v[1],last=r->v[9]==2?64:r->v[1];
 for(unsigned size=first;size<=last;++size)for(unsigned c=0;c<color_count;++c)for(unsigned y=0;y<64;++y){if(!(y&15)&&adv_cpu_poll())return 0;for(unsigned x=0;x<64;++x)m->source+=mem(atlas_address(size,c))[y*64+x]!=texture_pixel(size,c,x,y);}
 for(unsigned c=0;c<16;++c)for(unsigned y=0;y<8;++y)for(unsigned x=0;x<8;++x)m->source+=mem(MAT8)[c*64+y*8+x]!=texture_pixel(8,c%color_count,x,y);return !m->source;
}
static unsigned can_batch(const Request *r){return !r->cpu&&r->v[1]==8&&r->v[9]!=2&&(bb_read(0x4c)&2);}
static int batch_launch(const Request *r,uint32_t fb){
 _Static_assert(sizeof(AdvParticle)==16&&offsetof(AdvParticle,color)==14,"direct particle DMA layout");
 if(bb_publish()!=BB_OK||(bb_read(BB_STATUS)&BB_BUSY))return 0;
 bb_write(0x50,0);bb_write(0x44,r->v[0]);bb_write(0x48,MAT8);
 bb_job j={2,BG+VIEW_Y*5120+VIEW_X*4,fb+VIEW_Y*5120+VIEW_X*4,5120,5120,1024,512,PARTICLES,r->v[7],mask_key,1u|(r->v[8]?2u:0u)};
 return fast_launch(&j);
}
static int draw_particles(const Request *r,uint32_t fb){AdvParticle *p=particles();unsigned n=r->v[0],alpha=r->v[7],flags=1u|(r->v[8]?2u:0u);
 if(r->cpu){if(!copy_view(fb,1))return 0;}
 else{bb_job bg={BB_COPY_OP,BG+VIEW_Y*5120+VIEW_X*4,fb+VIEW_Y*5120+VIEW_X*4,5120,5120,1024,512,0,255,0,0};if(!fast_launch(&bg))return 0;}
 for(unsigned i=0;i<n;++i)if(adv_alive(p+i)){if(!(i&31)&&adv_cpu_poll()){if(dma_inflight)wait_job(5000000);return 0;}unsigned size=p[i].size;int x=(p[i].x>>12)-(int)size/2,y=(p[i].y>>12)-(int)size/2;
  if(x<0||y<0||x+(int)size>1024||y+(int)size>512){if(dma_inflight)wait_job(5000000);return 0;}
  bb_job j={BB_COPY_OP,atlas_address(size,p[i].color),fb+(VIEW_Y+y)*5120+(VIEW_X+x)*4,256,5120,size,size,0,alpha,mask_key,flags};
  if(r->cpu){if(!execute(&j,1))return 0;}else if(!fast_launch(&j))return 0;}
 return r->cpu||wait_job(5000000);
}
/* All twelve immutable template loads precede output stores: avoid a DDR
   W->R drain per emitted descriptor on the generated CPU's AXI bridge. */
static inline void emit_template_four(uint32_t *out,const volatile MicroTemplate *t,int px,int py){
 int x0,y0,x1,y1,x2,y2,x3,y3;uint32_t z0,z1,z2,z3;
#if defined(__riscv) && !defined(BB_HOST_TEST)
 __asm__ volatile("lw %0,0(%12)\n\tlw %1,4(%12)\n\tlw %2,8(%12)\n\tlw %3,12(%12)\n\tlw %4,16(%12)\n\tlw %5,20(%12)\n\tlw %6,24(%12)\n\tlw %7,28(%12)\n\tlw %8,32(%12)\n\tlw %9,36(%12)\n\tlw %10,40(%12)\n\tlw %11,44(%12)"
 :"=&r"(x0),"=&r"(y0),"=&r"(z0),"=&r"(x1),"=&r"(y1),"=&r"(z1),"=&r"(x2),"=&r"(y2),"=&r"(z2),"=&r"(x3),"=&r"(y3),"=&r"(z3):"r"(t):"memory");
#else
 x0=t[0].x;y0=t[0].y;z0=t[0].word3;x1=t[1].x;y1=t[1].y;z1=t[1].word3;x2=t[2].x;y2=t[2].y;z2=t[2].word3;x3=t[3].x;y3=t[3].y;z3=t[3].word3;
#endif
 out[0]=(uint32_t)(px+x0);out[1]=(uint32_t)(py+y0);out[3]=z0;out[4]=(uint32_t)(px+x1);out[5]=(uint32_t)(py+y1);out[7]=z1;
 out[8]=(uint32_t)(px+x2);out[9]=(uint32_t)(py+y2);out[11]=z2;out[12]=(uint32_t)(px+x3);out[13]=(uint32_t)(py+y3);out[15]=z3;
}
static int draw_micro(const Request *r,uint32_t fb){AdvParticle *p=particles();uint32_t *d=(uint32_t *)(uintptr_t)DESCRIPTORS;
 for(unsigned bank=0;bank<micro_banks;++bank){unsigned count=0;
  for(unsigned i=0;i<r->v[0];++i){AdvParticle q=p[i];if(!adv_alive(&q))continue;if(!(i&31)&&adv_cpu_poll())return 0;int px=q.x&~4095,py=q.y&~4095,left=(px>>12)-(int)micro_size/2,top=(py>>12)-(int)micro_size/2;
   if(left<0||top<0||left+(int)micro_size>1024||top+(int)micro_size>512||q.color>=micro_colors)return 0;
   TemplateRange range=micro_ranges[q.color][bank];if(count+range.count>ADV_MAX)return 0;const volatile MicroTemplate *t=micro_templates()+range.first;unsigned k=0;
   for(;k+4<=range.count;k+=4)emit_template_four(d+(count+k)*4,t+k,px,py);
   for(;k<range.count;++k){int x=t[k].x,y=t[k].y;uint32_t word3=t[k].word3;uint32_t *out=d+(count+k)*4;out[0]=(uint32_t)(px+x);out[1]=(uint32_t)(py+y);out[3]=word3;}count+=range.count;
  }
  if(bb_publish()!=BB_OK)return 0;bb_write(0x50,0);bb_write(0x44,count);bb_write(0x48,MICRO_BANK+bank*4096);
  uint32_t dest=fb+VIEW_Y*5120+VIEW_X*4;bb_job j={2,bank?dest:BG+VIEW_Y*5120+VIEW_X*4,dest,5120,5120,1024,512,DESCRIPTORS,r->v[7],mask_key,1u|(r->v[8]?2u:0u)};
  if(!fast_launch(&j)||!wait_job(5000000))return 0;if(cancelled||timed_out)return 0;
 }return 1;
}
static inline uint32_t row_load(unsigned i){return mem(ROW_PLANS)[i];}
static void row_emit(uint32_t word,int bx,int by,unsigned *count){unsigned x=(word&255u)+(unsigned)bx,y=((word>>8)&255u)+(unsigned)by,w=(word>>16)&255u,h=word>>24,mat;
 if(h==8)mat=15;else{if(y>504)return;if(x>1016){x=x+w-8;mat=w+7;}else mat=w-1;}
 uint32_t *out=(uint32_t *)(uintptr_t)DESCRIPTORS+*count*4;out[0]=(x+4)*4096;out[1]=(y+4)*4096;out[3]=mat<<16;++*count;
}
static inline void row_emit_four(unsigned first,int bx,int by,unsigned *count){uint32_t a,b,c,d;const volatile uint32_t *p=mem(ROW_PLANS)+first;
#if defined(__riscv) && !defined(BB_HOST_TEST)
 __asm__ volatile("lw %0,0(%4)\n\tlw %1,4(%4)\n\tlw %2,8(%4)\n\tlw %3,12(%4)":"=&r"(a),"=&r"(b),"=&r"(c),"=&r"(d):"r"(p):"memory");
#else
 a=p[0];b=p[1];c=p[2];d=p[3];
#endif
 row_emit(a,bx,by,count);row_emit(b,bx,by,count);row_emit(c,bx,by,count);row_emit(d,bx,by,count);
}
static int draw_rowrun(const Request *r,uint32_t fb,Result *m){AdvParticle *p=particles();unsigned count=0;
 /* Preflight the actual dynamic size and bottom-edge expansion before any
    partial batch can run. Overflow means one complete exact legacy frame. */
 for(unsigned i=0;i<r->v[0];++i){AdvParticle q=p[i];if(!adv_alive(&q))continue;if(!(i&31)&&adv_cpu_poll())return 0;unsigned size=q.size;if(size<8||size>64)return 0;int x=(q.x>>12)-(int)size/2,y=(q.y>>12)-(int)size/2;
  if(x<0||y<0||x+(int)size>1024||y+(int)size>512)return 0;TemplateRange range=row_ranges[size];
  if(y+(int)size<=505)count+=range.count;else for(unsigned k=0;k<range.count;++k){uint32_t op=row_load(range.first+k);if((op>>24)==8||y+(int)((op>>8)&255u)<=504)++count;}
  if(count>ADV_MAX){m->path=PATH_ROW_MIXED;m->reason=WHY_ROW_CAPACITY;return draw_particles(r,fb);}
 }
 unsigned emitted=0;
 for(unsigned i=0;i<r->v[0];++i){AdvParticle q=p[i];if(!adv_alive(&q))continue;if(!(i&31)&&adv_cpu_poll())return 0;int bx=(q.x>>12)-(int)q.size/2,by=(q.y>>12)-(int)q.size/2;TemplateRange range=row_ranges[q.size];unsigned k=0;
  if(bx+(int)q.size<=1017&&by+(int)q.size<=505){
   const volatile MicroTemplate *t=(const volatile MicroTemplate *)(uintptr_t)ROW_TEMPLATES+range.first;uint32_t *d=(uint32_t *)(uintptr_t)DESCRIPTORS+emitted*4;int px=bx*4096,py=by*4096;
   for(;k+4<=range.count;k+=4)emit_template_four(d+k*4,t+k,px,py);
   for(;k<range.count;++k){int x=t[k].x,y=t[k].y;uint32_t z=t[k].word3;uint32_t *out=d+k*4;out[0]=(uint32_t)(px+x);out[1]=(uint32_t)(py+y);out[3]=z;}emitted+=range.count;
  }else{for(;k+4<=range.count;k+=4)row_emit_four(range.first+k,bx,by,&emitted);for(;k<range.count;++k)row_emit(row_load(range.first+k),bx,by,&emitted);}
 }if(emitted!=count)return 0;
 /* No histogram or second DDR scatter pass: all foreground operations have
    the exact same RGB/Alpha and KeyON, so original plan order is already exact. */
 if(bb_publish()!=BB_OK)return 0;bb_write(0x50,0);bb_write(0x44,count);bb_write(0x48,ROW_MATERIALS);
 bb_job j={2,BG+VIEW_Y*5120+VIEW_X*4,fb+VIEW_Y*5120+VIEW_X*4,5120,5120,1024,512,DESCRIPTORS,r->v[7],mask_key,3};if(!fast_launch(&j)||!wait_job(5000000))return 0;
 /* Only row ops below y=504 need a fill. A valid solid tile already covered
    its own final seven rows; never redraw those pixels a second time. */
 for(unsigned i=0;i<r->v[0];++i){AdvParticle q=p[i];if(!adv_alive(&q))continue;int bx=(q.x>>12)-(int)q.size/2,by=(q.y>>12)-(int)q.size/2;if(by+(int)q.size<=505)continue;TemplateRange range=row_ranges[q.size];
  for(unsigned a=0;a<range.count;++a){uint32_t op=row_load(range.first+a);if((op>>24)!=1)continue;unsigned x=(unsigned)bx+(op&255u),y=(unsigned)by+((op>>8)&255u),w=(op>>16)&255u;if(y<=504)continue;
   /* Public driver rejects Alpha+FILL although RTL supports it. An immutable
      solid material row copied with Alpha gives the identical exact result. */
   bb_job tail={BB_COPY_OP,ROW_MATERIALS+15*256,fb+(VIEW_Y+y)*5120+(VIEW_X+x)*4,32,5120,w,1,0,r->v[7],mask_key,1};if(!fast_launch(&tail))return 0;
  }
 }return !dma_inflight||wait_job(5000000);
}
static int check_stress(const Request *r,uint32_t fb,Result *m){bb_acquire();AdvParticle *p=particles();uint32_t seed=0x6af31025;unsigned flags=1u|(r->v[8]?2u:0u);
 for(unsigned s=0;s<64;++s){if(adv_cpu_poll())return 0;unsigned x=adv_random(&seed)%ADV_W,y=adv_random(&seed)%ADV_H;uint32_t expected=mem(BG)[(y+VIEW_Y)*1280+x+VIEW_X];
  for(unsigned i=0;i<r->v[0];++i)if(adv_alive(p+i)){int left=(p[i].x>>12)-(int)p[i].size/2,top=(p[i].y>>12)-(int)p[i].size/2;
   if((int)x>=left&&(int)y>=top&&(int)x<left+p[i].size&&(int)y<top+p[i].size){uint32_t source=texture_pixel(p[i].size,p[i].color,x-left,y-top);expected=adv_golden(source,expected,r->v[7],mask_key,flags);}}
  m->errors+=mem(fb)[(y+VIEW_Y)*1280+x+VIEW_X]!=expected;++m->checked;
 }return check_atlas(r,m)&&check_micro(r,m)&&check_rowrun(m)&&!m->errors;
}
static uint32_t particle_signature(unsigned n){const unsigned char *p=(const unsigned char *)particles();uint32_t h=2166136261u;for(unsigned i=0;i<n*sizeof(AdvParticle);++i)h=(h^p[i])*16777619u;return h;}
#define ADV_SAMPLE_POINTS 16u
static uint32_t screen_signature(uint32_t fb){uint32_t seed=0x734fe291u,h=2166136261u;
 /* Volatile DDR samples AFTER a confirmed swap. bb_swap_wait published and
    invalidated CPU cache, after DMA DONE; no framebuffer reads intervened. */
 for(unsigned i=0;i<ADV_SAMPLE_POINTS;++i){unsigned x=adv_random(&seed)&1023u,y=adv_random(&seed)&511u;h=(h^mem(fb)[(VIEW_Y+y)*1280+VIEW_X+x])*16777619u;}return h;
}
static void simulation_step(const Request *r,AdvStats *st,Result *m,uint64_t *logic_ticks,unsigned prime){uint64_t t=bb_ticks();
 if(!r->v[9])adv_particles_step_draw(particles(),r->v[0],r->v[1]);else adv_particles_step(particles(),r->v[0],r->v[9],st);
 uint64_t dt=bb_ticks()-t;*logic_ticks+=dt;++m->total_steps;if(prime)++m->prime_steps;else ++m->measured_steps;if(us(dt)>m->max_logic)m->max_logic=us(dt);
}
static void progress(const Request *r,const Result *m){begin("ADV_PROGRESS",r);field("task",r->task);field("frames",m->frames);field("total",r->v[10]);field("elapsed_us",m->elapsed);field("swaps",m->swaps);field("uf",m->uf);field("late",m->late);field("scan_total",m->scan_total);field("missed_scans",m->missed_scans);field("pixel_changes",m->pixel_changes);send();}
static int stress_case(const Request *r,Result *m,AdvStats *st){
 if(!make_background(1,0x10233d)||!initialize_banks("MULTI SIZE / COLOR / SHAPE / OPTIONAL PHYSICS")||!prepare_atlas(r)||!prepare_micro(r,m))return 0;
 adv_particles_init(particles(),r->v[0],r->v[1],color_count,r->v[11]);st->count=st->minimum=st->maximum=r->v[0];m->initial=r->v[0];
 m->state_first=particle_signature(r->v[0]);unsigned batch=can_batch(r),prepared=0;fast_cache_valid=0;dma_cycles_total=0;
 m->pipeline=batch&&!r->v[9];
 /* One explicit initial-state presentation aligns the measured window to a
    real swap edge. It does NOT advance simulation and is not counted in N. */
 uint32_t warm_fb=back();if(!warm_fb)return 0;
 int warm_ok;
 if(batch){warm_ok=batch_launch(r,warm_fb);if(warm_ok&&m->pipeline){warm_ok=batch_snapshot_ready(r->v[0]);if(warm_ok&&!adv_cpu_poll()){uint64_t prime_ticks=0;simulation_step(r,st,m,&prime_ticks,1);m->prime_logic=us(prime_ticks);prepared=1;}}
  if(dma_inflight&&!wait_job(5000000))warm_ok=0;
 }else warm_ok=row_enabled?draw_rowrun(r,warm_fb,m):micro_enabled?draw_micro(r,warm_fb):draw_particles(r,warm_fb);
 if(!warm_ok||dma_inflight||cancelled||timed_out)return 0;
 if(bb_swap_wait(warm_fb,1000000)!=BB_OK)return 0;m->warmup=1;dma_cycles_total=batch_passes=batch_micro=0;
 uint32_t first_swaps=bb_read(BB_SWAPS),first_uf=bb_read(BB_UNDERFLOWS),first_scan=bb_read(BB_FRAMES),previous_scan=first_scan,last_fb=0;
 uint64_t begin_tick=bb_ticks(),previous_present=begin_tick,logic_ticks=0,render_ticks=0,wait_ticks=0;
 for(unsigned f=0;f<r->v[10];++f){if(adv_cpu_poll())break;uint64_t frame_start=bb_ticks(),t;
  if(!prepared)simulation_step(r,st,m,&logic_ticks,0);prepared=0;
  uint32_t fb=back();if(!fb)break;t=bb_ticks();uint64_t io=io_ticks;int ok=1;
  if(batch){ok=batch_launch(r,fb);
   if(ok&&m->pipeline&&f+1<r->v[10]){
    ok=batch_snapshot_ready(r->v[0]);
    if(ok&&!adv_cpu_poll()){uint32_t c0=bb_read(BB_CYCLES);simulation_step(r,st,m,&logic_ticks,0);uint32_t c1=bb_read(BB_CYCLES);m->overlap_cycles+=(uint32_t)(c1-c0);prepared=1;}
   }
   if(dma_inflight&&!wait_job(5000000))ok=0;
  }else ok=row_enabled?draw_rowrun(r,fb,m):micro_enabled?draw_micro(r,fb):draw_particles(r,fb);
  uint64_t render_span=bb_ticks()-t,io_span=io_ticks-io;if(io_span<=render_span)render_span-=io_span;render_ticks+=render_span;if(us(render_span)>m->max_render)m->max_render=us(render_span);
  if(!ok||cancelled||timed_out)break;
  t=bb_ticks();if(bb_swap_wait(fb,1000000)!=BB_OK)break;wait_ticks+=bb_ticks()-t;uint64_t presented=bb_ticks(),period=us(presented-previous_present);previous_present=presented;
  if(!m->frames||period<m->min_frame)m->min_frame=period;if(period>m->max_frame)m->max_frame=period;
  uint32_t scan=bb_read(BB_FRAMES),gap=scan-previous_scan;previous_scan=scan;if(gap>m->max_scan_gap)m->max_scan_gap=gap;if(gap>1)m->missed_scans+=gap-1;
  uint32_t signature=screen_signature(fb);if(!m->frames)m->pixel_first=signature;else if(signature!=m->pixel_last)++m->pixel_changes;m->pixel_last=signature;
  ++m->frames;last_fb=fb;if(us(bb_ticks()-frame_start)>16667)++m->late;
  m->elapsed=us(bb_ticks()-begin_tick);m->swaps=(uint32_t)(bb_read(BB_SWAPS)-first_swaps);m->uf=(uint32_t)(bb_read(BB_UNDERFLOWS)-first_uf);m->scan_total=(uint32_t)(scan-first_scan);
  if(!(m->frames%600)&&f+1<r->v[10])progress(r,m);
 }
 if(dma_inflight)wait_job(5000000); /* Never release owner with an in-flight DMA. */
 m->logic=us(logic_ticks);m->render=us(render_ticks);m->wait=us(wait_ticks);m->hw_cycles=dma_cycles_total;
 m->elapsed=us(bb_ticks()-begin_tick);m->swaps=(uint32_t)(bb_read(BB_SWAPS)-first_swaps);m->uf=(uint32_t)(bb_read(BB_UNDERFLOWS)-first_uf);m->cases=m->frames; /* scan_total stays latched at the last confirmed swap. */
 m->final=st->count;m->minimum=st->minimum;m->maximum=st->maximum;m->state_last=particle_signature(r->v[0]);
 if(cancelled||timed_out||dma_inflight)return 0;if(m->frames!=r->v[10])return 0;
 if(!last_fb||!check_stress(r,last_fb,m))return 0;
 /* Result overlay is outside measured/validated field. */
 fast_cache_valid=0;uint32_t fb=back();if(!panel(fb,"STRESS RESULT / TIMINGS EXCLUDE VALIDATION")||!copy_view(fb,0))return 0;
 print_number(fb,32,118,"FRAMES ",m->frames);print_number(fb,330,118,"FINAL COUNT ",m->final);print_number(fb,760,118,"PIXEL ERRORS ",m->errors);
 print_number(fb,32,220,"DRAW WALL US ",m->render);print_number(fb,32,265,"LOGIC TOTAL US ",m->logic);print_number(fb,32,310,"ACTUAL FPS X100 ",m->elapsed?m->swaps*100000000ull/m->elapsed:0);
 print_number(fb,32,355,"MISSED SCANS ",m->missed_scans);print_number(fb,32,400,"PIXEL CHANGES ",m->pixel_changes);print_number(fb,32,445,"FINAL FRAME SAMPLES ",m->checked);
 return bb_swap_wait(fb,1000000)==BB_OK;
}
static void report(const Request *r,const Result *m,const AdvStats *st){
 begin("ADV_RESULT",r);field("task",r->task);field("frames",m->frames);field("cases",m->cases);field("initial",m->initial);field("final",m->final);field("minimum",m->minimum);field("maximum",m->maximum);field("pairs",st->pairs);field("collisions",st->collisions);field("merges",st->merges);send();
 begin("ADV_METRIC",r);field("task",r->task);field("logic_us",m->logic);field("render_us",m->render);field("wait_us",m->wait);field("elapsed_us",m->elapsed);field("swaps",m->swaps);field("uf",m->uf);field("late",m->late);send();
 begin("ADV_TIMING",r);field("task",r->task);field("scan_total",m->scan_total);field("max_scan_gap",m->max_scan_gap);field("missed_scans",m->missed_scans);field("pixel_changes",m->pixel_changes);field("pixel_first",m->pixel_first);field("pixel_last",m->pixel_last);field("max_logic_us",m->max_logic);field("max_render_us",m->max_render);field("max_frame_us",m->max_frame);field("min_frame_us",m->min_frame);field("pipeline",m->pipeline);field("state_first",m->state_first);field("state_last",m->state_last);field("sample_points",r->op==STRESS?ADV_SAMPLE_POINTS:0);field("hw_us",us(m->hw_cycles));field("overlap_us",us(m->overlap_cycles));field("warmup_frames",m->warmup);send();
 if(r->op==STRESS){begin("ADV_PATH",r);field("task",r->task);add(" path=");add(paths[m->path]);add(" reason=");add(reasons[m->reason]);field("passes",batch_passes);field("micro",batch_micro);field("prime_steps",m->prime_steps);field("prime_logic_us",m->prime_logic);field("measured_steps",m->measured_steps);field("total_steps",m->total_steps);send();}
 begin("ADV_CHECK",r);field("task",r->task);field("errors",m->errors);field("guards",m->guards);field("source",m->source);field("checked",m->checked);field("actual",m->checked?1:0);field("replayed",0);send();
}
void adv_service(void){if(!pending||running)return;Request r=request;pending=0;running=1;request_start=bb_ticks();io_ticks=0;
 if(cancelled){running=0;done(&r,"CANCELLED","CANCEL",0,us(bb_ticks()-request_start));return;}
 if(r.op==ENTER){active=1;guard_atlas_end=0;guards_init();if(!make_background(1,0x18345a)||!initialize_banks("ADVANCED ALPHA / COLOR KEY LABORATORY")){running=0;done(&r,cancelled?"CANCELLED":"ERROR",cancelled?"CANCEL":timed_out?"TIMEOUT":"HARDWARE",0,us(bb_ticks()-request_start));return;}running=0;state(&r);done(&r,"PASS","OK",0,us(bb_ticks()-request_start));return;}
 if(r.op==EXIT){if(dma_inflight&&!wait_job(5000000)){running=0;state(&r);done(&r,"ERROR","HARDWARE",0,us(bb_ticks()-request_start));return;}cancelled=0;active=0;guard_atlas_end=0;int restored=restore?restore():0;if(restored)active=1;running=0;state(&r);done(&r,restored?"ERROR":"PASS",restored?"RESTORE":"OK",0,us(bb_ticks()-request_start));return;}
 Result m;AdvStats st;memset(&m,0,sizeof m);memset(&st,0,sizeof st);guard_atlas_end=0;micro_enabled=row_enabled=0;batch_passes=batch_micro=0;guards_init();mask_key=r.op==SHOW?r.v[6]:BB_KEY;
 /* PLAN precedes all work; stress auto-key is known from selected palette. */
 if(r.op==STRESS){color_count=!r.v[6]?1:r.v[6]==1?3:16;for(unsigned c=0;c<color_count;++c)colors[c]=adv_color(r.v[3],r.v[4],r.v[5],r.v[6],c);mask_key=BB_KEY;for(;;){unsigned match=0;for(unsigned c=0;c<color_count;++c)match|=colors[c]==mask_key;if(!match)break;mask_key=(mask_key+0x010101)&0xffffff;}}
 unsigned expected=r.op==STRESS?r.v[10]:r.op==VERIFY?(r.kind==0?256:r.kind==1?8:4):(r.kind==0?1:r.kind==1?2:4);
 begin("ADV_PLAN",&r);field("task",r.task);add(" args=");add(r.args);field("expected",expected);add(r.op==STRESS?" scope=sampled":" scope=full");field("key",mask_key);send();
 uint32_t start_uf=bb_read(BB_UNDERFLOWS);int ok=r.op==SHOW?show_case(&r,&m):r.op==VERIFY?verify_case(&r,&m):stress_case(&r,&m,&st);
 if(!cancelled&&!timed_out){if(!background_check(r.op==SHOW?r.v[8]:1,r.op==SHOW?r.v[4]:0,&m))ok=0;guards_check(&m);}if(r.op!=STRESS){m.elapsed=us(bb_ticks()-request_start);m.uf=(uint32_t)(bb_read(BB_UNDERFLOWS)-start_uf);}
 if(m.errors||m.guards||m.source)ok=0;report(&r,&m,&st);if(us(bb_ticks()-request_start)>1800000000ull)timed_out=1;running=0;
 const char *status=cancelled?"CANCELLED":ok&&!timed_out?"PASS":"ERROR",*code=cancelled?"CANCEL":timed_out?"TIMEOUT":ok?"OK":m.errors||m.guards||m.source?"CHECK":"HARDWARE";
 done(&r,status,code,r.op==STRESS?m.frames:m.cases,us(bb_ticks()-request_start));
}
