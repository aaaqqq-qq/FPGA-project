#pragma once
#include <stdint.h>

#define PLAYER_SHOT_CAPACITY 128
#define PLAYER_KIND_MAIN 0
#define PLAYER_KIND_HOMING 2

typedef struct {
    int x, y, vx, vy;
    unsigned live, kind;
    int fx, fy;
    unsigned age;
    int target;
    unsigned retarget_wait,target_valid;
} PlayerShot;

typedef struct {
    int x, y;
    int hp, max_hp;
    unsigned lives, bombs;
    unsigned power_level;
    unsigned score, graze;
    unsigned spawn_invuln, hit_invuln, bomb_invuln, upgrade_invuln;
    unsigned regen_wait, regen_accum;
    unsigned hit_flash, upgrade_anim;
    unsigned hp_display, hp_delay;
    unsigned alive;
    unsigned shot_rejections;
    unsigned upgrades, level_events;
} PlayerState;

extern PlayerState player;
extern PlayerShot player_shots[PLAYER_SHOT_CAPACITY];

void player_reset(int x, int y);
void player_begin_tick(void);
void player_add_score(unsigned points);
unsigned player_level_for_score(unsigned score);
int player_update_level(void);
unsigned player_can_be_hit(unsigned demo_invincible);
int player_take_hit(int damage);
void player_regen_tick(void);
void player_fire_tick(unsigned tick);
void player_shots_reset(void);
void player_shots_tick(void);
unsigned player_alive(void);

/* Number of full nearest-target/steering refreshes since player reset. */
extern unsigned player_homing_retargets;
