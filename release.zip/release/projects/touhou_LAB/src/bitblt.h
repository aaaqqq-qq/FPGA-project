#ifndef BITBLT_DEMO_DRIVER_H
#define BITBLT_DEMO_DRIVER_H
#include <stdint.h>
#include <stddef.h>

#define BB_BASE          UINT32_C(0xf8100000)
#define BB_ID_VALUE      UINT32_C(0x424c5431)
#define BB_FB0           UINT32_C(0x01000000)
#define BB_FB1           UINT32_C(0x01400000)
#define BB_SPRITES       UINT32_C(0x01800000)
#define BB_DRAIN_WORD    UINT32_C(0x00ffffc0)
#define BB_DDR_END       UINT32_C(0x10000000)
#define BB_SCREEN_W     1280u
#define BB_SCREEN_H     720u
#define BB_SCREEN_STRIDE 5120u
#define BB_FRAME_BYTES  (BB_SCREEN_STRIDE * BB_SCREEN_H)
#define BB_KEY           UINT32_C(0x00ff00ff)

enum {
    BB_ID = 0x00, BB_CMD = 0x04, BB_STATUS = 0x08, BB_OP = 0x0c,
    BB_SRC = 0x10, BB_DST = 0x14, BB_SRC_STRIDE = 0x18,
    BB_DST_STRIDE = 0x1c, BB_WIDTH = 0x20, BB_HEIGHT = 0x24,
    BB_FILL = 0x28, BB_ALPHA = 0x2c, BB_KEY_REG = 0x30,
    BB_FLAGS = 0x34, BB_CYCLES = 0x38, BB_READ_BYTES = 0x3c,
    BB_WRITE_BYTES = 0x40, BB_DISPLAY_CTRL = 0x80,
    BB_FRONT = 0x84, BB_NEXT_FRONT = 0x88, BB_SWAP = 0x8c,
    BB_DISPLAY_STATUS = 0x90, BB_FRAMES = 0x94,
    BB_SWAPS = 0x98, BB_UNDERFLOWS = 0x9c
};
enum { BB_BUSY = 1, BB_DONE = 2, BB_ERROR = 4 };
enum { BB_ALPHA_ENABLE = 1, BB_KEY_ENABLE = 2 };
enum { BB_SWAP_PENDING = 1, BB_UNDERFLOW = 2, BB_CAL_DONE = 4 };
enum { BB_FILL_OP = 0, BB_COPY_OP = 1 };
typedef enum {
    BB_OK = 0, BB_E_ARGUMENT = -1, BB_E_RANGE = -2,
    BB_E_OVERLAP = -3, BB_E_BUSY = -4, BB_E_TIMEOUT = -5,
    BB_E_HARDWARE = -6, BB_E_ID = -7, BB_E_CANCELLED = -8
} bb_result;

typedef struct {
    uint32_t op, src, dst, src_stride, dst_stride;
    uint32_t width, height, fill, alpha, key, flags;
} bb_job;
typedef struct {
    uint32_t cycles, read_bytes, write_bytes;
} bb_metrics;

uint32_t bb_read(unsigned reg);
void bb_write(unsigned reg, uint32_t value);
uint64_t bb_ticks(void);
uint32_t bb_us(uint64_t ticks);
bb_result bb_probe(void);
bb_result bb_validate(const bb_job *job);
bb_result bb_publish(void);
void bb_acquire(void);
bb_result bb_submit(const bb_job *job);
bb_result bb_wait(uint32_t timeout_us, bb_metrics *metrics);
bb_result bb_execute(const bb_job *job, bb_metrics *metrics);
int bb_cpu_service(void); /* weak cooperative input hook; nonzero cancels incomplete CPU work */
bb_result bb_cpu_execute(const bb_job *job);
bb_result bb_swap_wait(uint32_t framebuffer, uint32_t timeout_us);
/* Wait until the display finishes the active scan following this blank.
   This does not request a swap. Capture FPS counters before calling it. */
bb_result bb_wait_frame_after(uint32_t frame, uint32_t timeout_us);
uint32_t bb_blend(uint32_t foreground, uint32_t background, unsigned alpha);
const char *bb_error_string(bb_result error);

#endif
