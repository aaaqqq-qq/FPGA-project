#include "stage.h"
#include "battle.h"
#include "game_config.h"
void fatal(const char *where,int error);
#include "tick_profile.h"
#include "player.h"
#include "effects.h"
#include "bitblt.h"
#include "motion_hw.h"
#include "original_battle_data.h"
#include <string.h>

BattleBoss bosses[MAX_BOSSES];
unsigned battle_hit, battle_grazes, battle_materials;
unsigned summon_done, battle_cleared;
static unsigned legacy_mode;
unsigned battle_load_active,battle_load_fills,battle_load_recycles,battle_load_keeps;
unsigned battle_load_boss_hits,battle_load_mob_hits,battle_load_player_hits,battle_load_player_damage;
static unsigned load_cursor;
unsigned battle_density_slow,battle_density_skips;
unsigned battle_near_candidates,battle_near_fallbacks;
#define CONTACT_BUCKETS 8u
#define CONTACT_BUCKET_CAP 4096u
/* CPU-only index scratch; separate from app/loader/frame/art regions. */
#define CONTACT_INDEX_BASE 0x00210000u
#define CONTACT_INDEX_BYTES (CONTACT_BUCKETS*CONTACT_BUCKET_CAP*sizeof(uint16_t))
_Static_assert(CONTACT_INDEX_BYTES==65536u,"contact scratch size");
_Static_assert(CONTACT_INDEX_BASE-64u>=0x00100000u,"contact beyond application");
_Static_assert(CONTACT_INDEX_BASE+CONTACT_INDEX_BYTES+64u<=0x00f00000u,"contact below loader");
#if defined(__riscv) || defined(CONTACT_INDEX_FIXED_DDR_TEST)
#define CONTACT_FIXED_DDR 1
extern void fatal(const char *where,int error);
#define contact_index (*(uint16_t (*)[CONTACT_BUCKETS][CONTACT_BUCKET_CAP])(uintptr_t)CONTACT_INDEX_BASE)
static unsigned contact_ready;
static volatile uint32_t *contact_guard(unsigned side){
    return (volatile uint32_t *)(uintptr_t)(side?CONTACT_INDEX_BASE+CONTACT_INDEX_BYTES:CONTACT_INDEX_BASE-64u);
}
static uint32_t contact_guard_value(unsigned side,unsigned i){return (side?0xc8743f12u:0x91e2ad40u)^i;}
int battle_scratch_guards_ok(void){
    if(!contact_ready)return 0;
#ifdef __riscv
    bb_acquire();
#endif
    for(unsigned side=0;side<2;++side)for(unsigned i=0;i<16;++i)
        if(contact_guard(side)[i]!=contact_guard_value(side,i))return 0;
    return 1;
}
int battle_scratch_init(void){
    /* Once initialized, never overwrite a corrupt guard on a later restart. */
    if(contact_ready)return battle_scratch_guards_ok();
    for(unsigned side=0;side<2;++side)for(unsigned i=0;i<16;++i)
        contact_guard(side)[i]=contact_guard_value(side,i);
#ifdef __riscv
    if(bb_publish()!=BB_OK)return 0;
#endif
    contact_ready=1;return battle_scratch_guards_ok();
}
#else
#define CONTACT_FIXED_DDR 0
static uint16_t contact_index[CONTACT_BUCKETS][CONTACT_BUCKET_CAP];
int battle_scratch_init(void){return 1;}
int battle_scratch_guards_ok(void){return 1;}
#endif
static unsigned contact_count[CONTACT_BUCKETS];


typedef struct { int v[12], pc, time, cmp; } Context;
typedef struct { Context c, saved; int depth, x, y, sx, sy, dx, dy, mt, mn, angle, speed, ex[8]; } Vm;

/* A fire instruction is snapshotted so the extra enraged volley can be spread
   a few ticks after the script event without re-reading ECL variables. */
typedef struct {
    int n, layers, a1, a2, speed1, speed2, type, color, aim, ex4, ex5, flags;
    int mode, aimed; /* mode 1: 67/68 alternating delta; 2: 69/70 fan */
    unsigned delay;
} Volley;

#define PENDING_MAX 4
typedef struct { Vm vm; Volley pending[PENDING_MAX]; unsigned pending_count, fire_acc, density_acc; } BattleVm;

typedef struct { int16_t angle, speed, target, target_speed; uint16_t turn, delay; } Effect;
_Alignas(16) static Effect effects[SHOT_CAPACITY];
static BattleVm vmb[MAX_BOSSES];

#define VM(k) (&vmb[k].vm)
static unsigned active_boss_count(void){return legacy_mode?3u:game_cfg.boss_count<MAX_BOSSES?game_cfg.boss_count:MAX_BOSSES;}

static int fval(Vm *v, int x) {
    if (x <= -10001 * 65536 && x >= -10012 * 65536) return v->c.v[-x / 65536 - 10001];
    return x;
}
static int ival(Vm *v, int x) {
    if (x <= -10001 && x >= -10012) return v->c.v[-x - 10001];
    return x;
}
static void put(Vm *v, int i, int x) {
    if (i <= -10001 && i >= -10012) v->c.v[-i - 10001] = x;
    else stage.fault = 210;
}
static int angle_fixed(int f) { return (int)((long long)f * 65536 / 411775); }
static int map_x(unsigned k, int x) { return (256 + (int)(k%3u) * 256) * Q + (x - 192 * Q) * 3 / 2; }
static int map_y(unsigned k,int y) { return y * 3 / 2+(int)(k/3u)*160*Q; }
static int half_hp(void) {
    unsigned h = game_cfg.boss_half_hp;
    if (h > (unsigned)game_cfg.boss_max_hp / 2 || !h) h = game_cfg.boss_max_hp / 2;
    return (int)h;
}

static void movement(unsigned k, Vm *v, int n, int x, int y, int enraged) {
    if (enraged && !legacy_mode) {
        int num = (int)(game_cfg.boss_profiles_enabled?game_cfg.boss_move_num[k]:game_cfg.enrage_move_num);
        int den = (int)(game_cfg.boss_profiles_enabled?game_cfg.boss_move_den[k]:game_cfg.enrage_move_den);
        if (num && den) {
            int scaled = (n * den + num - 1) / num;
            if (scaled < 1) scaled = 1;
            n = scaled;
        }
    }
    if (n < 1) n = 1;
    v->sx = v->x; v->sy = v->y; v->dx = x - v->x; v->dy = y - v->y;
    v->mn = n; v->mt = 0;
}

static unsigned material_for(int type, int color) {
    if (type == 1 && color >= 5 && color <= 8) return 54u + (unsigned)(color - 5);
    static const unsigned colors[] = {2, 4, 6, 8, 10, 11, 13, 14};
    if (type == 5) for (unsigned i = 0; i < 8; ++i) if (color == (int)colors[i]) return 58u + i;
    stage.fault = 211; return 54;
}

static int stage_shot_add(unsigned k, int x_q12, int y_q12, int an, int speed_q12,
                          unsigned tile, int target_angle, int target_speed,
                          unsigned turn, unsigned delay) {
    ++stage.requested;
    unsigned is_boss=k<MAX_BOSSES&&k<active_boss_count();
    if(is_boss)++bosses[k].shots_requested;
    unsigned index;
    if (stage.count >= stage.limit || stage.count >= SHOT_CAPACITY) {
        if(!battle_load_active||!stage.count){
            ++stage.rejected; if(is_boss)++bosses[k].shots_rejected;
            return 0;
        }
        /* A saturated synthetic scene still executes real AI emissions. Explicit
         * round-robin replacement keeps the workload fixed; it is not normal play. */
        index=load_cursor++%stage.count;++battle_load_recycles;
    }else index=stage.count++;
    Shot *b = &stage.shots[index];
    b->x = x_q12; b->y = y_q12;
    b->vx = (int16_t)((long long)turn_cos(an) * speed_q12 / 32768);
    b->vy = (int16_t)((long long)turn_sin(an) * speed_q12 / 32768);
    b->tile = (uint8_t)tile; b->age = 0; b->grazed = 0;
    stage.owner[index] = (uint8_t)k;
    effects[index] = (Effect){(int16_t)an, (int16_t)speed_q12, (int16_t)target_angle,
                              (int16_t)target_speed, (uint16_t)turn, (uint16_t)delay};
    ++stage.emitted; if(is_boss){++bosses[k].fired;++bosses[k].shots_spawned;}
    if (stage.count > stage.peak) stage.peak = stage.count;
    return 1;
}

static void volley_fire(unsigned k, const Volley *q) {
    int n = q->n, layers = q->layers;
    if (n < 1) n = 1;
    if (layers < 1) layers = 1;
    if (!legacy_mode && bosses[k].state == BOSS_ENRAGED) {
        unsigned num = game_cfg.boss_profiles_enabled?game_cfg.boss_bullets_num[k]:game_cfg.enrage_bullets_num;
        unsigned den = game_cfg.boss_profiles_enabled?game_cfg.boss_bullets_den[k]:game_cfg.enrage_bullets_den;
        if (num && den) {
            int scaled = (n * (int)num + (int)den - 1) / (int)den;
            if (scaled > n) n = scaled;
        }
    }
    unsigned tile = material_for(q->type, q->color);
    /* stage_shot_add mutates pool/counters only: these volley inputs stay fixed. */
    int x_q12 = bosses[k].x * Q, y_q12 = bosses[k].y * Q;
    int target_angle = angle_fixed(q->ex4);
    int target_speed = q->ex5 / 16 * 3 / 2;
    unsigned turn = (unsigned)((q->flags & 256) ? q->ex4 : 0);
    unsigned delay = (unsigned)((q->flags & 4) ? 16 : (q->flags & 2) ? 8 : 0);
    for (int j = 0; j < layers; ++j) {
        int speed = q->speed1 - (q->speed1 - q->speed2) * j / layers;
        /* Preserve both truncations and their order exactly. */
        speed = speed / 16 * 3 / 2;
        for (int i = 0; i < n; ++i) {
            int an = q->a1;
            if (q->mode == 1) {
                int delta = (n & 1) ? ((i + 1) / 2) * q->a2 : (i / 2) * q->a2 + q->a2 / 2;
                if (i & 1) delta = -delta;
                an += delta;
                if (q->aimed) an += q->aim;
            } else {
                an += i * 65536 / n + j * q->a2;
                if (q->aimed) an += q->aim;
            }
            stage_shot_add(k, x_q12, y_q12, an, speed, tile,
                           target_angle, target_speed, turn, delay);
        }
    }
}

/* ECL op 67/68 use the alternating-delta geometry, 69/70 the fan geometry;
   a[8] is retained verbatim for the per-bullet turn/delay effect. */
static void volley_build(Vm *v, const OriginalOp *o, int px, int py, Volley *out) {
    const int *a = o->a;
    memset(out, 0, sizeof(*out));
    out->type = a[0];
    out->color = ival(v, a[1]);
    out->n = ival(v, a[2]);
    out->layers = ival(v, a[3]);
    out->speed1 = fval(v, a[4]);
    out->speed2 = fval(v, a[5]);
    out->a1 = angle_fixed(fval(v, a[6]));
    out->a2 = angle_fixed(fval(v, a[7]));
    out->aim = turn_atan(px - bosses[0].x, py - bosses[0].y);
    out->ex4 = v->ex[4];
    out->ex5 = v->ex[5];
    out->flags = a[8];
    out->mode = (o->op == 67 || o->op == 68) ? 1 : 2;
    out->aimed = (o->op == 67 || o->op == 69);
    out->delay = 0;
}

static void fire_op(unsigned k, Vm *v, const OriginalOp *o, int px, int py) {
    /* Gate actual ordinary emissions only: ECL execution/time/movement keep advancing.
       Threshold bursts use battle_burst directly and never enter this limiter. */
    if(!legacy_mode&&game_cfg.adaptive_density&&battle_density_slow){
        unsigned den=game_cfg.density_slow_den?game_cfg.density_slow_den:2;
        unsigned num=game_cfg.density_slow_num?game_cfg.density_slow_num:1;
        vmb[k].density_acc%=den; /* A live denominator edit cannot retain old units. */
        vmb[k].density_acc+=num;
        if(vmb[k].density_acc<den){++battle_density_skips;return;}
        vmb[k].density_acc-=den;
    }else vmb[k].density_acc=0;
    Volley q;
    volley_build(v, o, px, py, &q);
    q.aim = turn_atan(px - bosses[k].x, py - bosses[k].y);
    volley_fire(k, &q);

    if (!legacy_mode && bosses[k].state == BOSS_ENRAGED) {
        BattleVm *bv = &vmb[k];
        unsigned den = game_cfg.boss_profiles_enabled?game_cfg.boss_fire_den[k]:game_cfg.enrage_fire_den;
        unsigned num = game_cfg.boss_profiles_enabled?game_cfg.boss_fire_num[k]:game_cfg.enrage_fire_num;
        if(!den)den=5;
        unsigned add = num>den?num-den:0;
        bv->fire_acc %= den;
        bv->fire_acc += add;
        while (bv->fire_acc >= den) {
            bv->fire_acc -= den;
            if (bv->pending_count < PENDING_MAX) {
                q.delay = 3;
                bv->pending[bv->pending_count++] = q;
            } else {
                ++bosses[k].volleys_dropped;
            }
        }
    }
}

static void pending_step(unsigned k) {
    BattleVm *bv = &vmb[k];
    for (unsigned i = 0; i < bv->pending_count;) {
        Volley *q = &bv->pending[i];
        if (q->delay) --q->delay;
        if (!q->delay) {
            volley_fire(k, q);
            bv->pending[i] = bv->pending[--bv->pending_count];
            continue;
        }
        ++i;
    }
}
static void pending_clear(unsigned k) { vmb[k].pending_count = 0; }

static unsigned code_length(unsigned k, unsigned difficulty) {
    static const unsigned lens[3][3] = {
        {sizeof(original_0_2) / sizeof(OriginalOp), sizeof(original_0_4) / sizeof(OriginalOp), sizeof(original_0_8) / sizeof(OriginalOp)},
        /* Cirno uses the Hard branch on Normal (same table as original_code). */
        {sizeof(original_1_4) / sizeof(OriginalOp), sizeof(original_1_4) / sizeof(OriginalOp), sizeof(original_1_8) / sizeof(OriginalOp)},
        {sizeof(original_2_2) / sizeof(OriginalOp), sizeof(original_2_4) / sizeof(OriginalOp), sizeof(original_2_8) / sizeof(OriginalOp)},
    };
    return lens[k % 3][difficulty % 3];
}

static void run(unsigned k, int px, int py) {
    Vm *v = VM(k);
    const OriginalOp *code = original_code[k%3u][stage.difficulty % 3];
    unsigned len = code_length(k, stage.difficulty);
    unsigned steps = 0;
    int enraged = (!legacy_mode && bosses[k].state == BOSS_ENRAGED);
    while (1) {
        if (v->c.pc == (int)len) {
            break; /* normal end of this ECL stream */
        }
        if (v->c.pc < 0 || (unsigned)v->c.pc > len) {
            stage.fault = 215; return;
        }
        if (code[v->c.pc].time != v->c.time) break;
        if (++steps > 512) { stage.fault = 212; return; }
        const OriginalOp *o = &code[v->c.pc++];
        const int *a = o->a;
        int jump = 0;
        switch (o->op) {
        case 2:
            jump = 1;
            break;
        case 3: { int i = -a[2] - 10001; jump = --v->c.v[i] > 0; break; }
        case 4: put(v, a[0], ival(v, a[1])); break;
        case 5: put(v, a[0], fval(v, a[1])); break;
        case 8: put(v, a[0], (int)((long long)(stage_random() & 65535) * fval(v, a[1]) / 65536)); break;
        case 13: put(v, a[0], ival(v, a[1]) + ival(v, a[2])); break;
        case 16: put(v, a[0], ival(v, a[1]) / ival(v, a[2])); break;
        case 17: put(v, a[0], ival(v, a[1]) % ival(v, a[2])); break;
        case 20: put(v, a[0], fval(v, a[1]) + fval(v, a[2])); break;
        case 21: put(v, a[0], fval(v, a[1]) - fval(v, a[2])); break;
        case 27: { int x = ival(v, a[0]), y = ival(v, a[1]); v->c.cmp = (x > y) - (x < y); break; }
        case 28: { int x = fval(v, a[0]), y = fval(v, a[1]); v->c.cmp = (x > y) - (x < y); break; }
        case 29: jump = v->c.cmp < 0; break;
        case 30: jump = v->c.cmp <= 0; break;
        case 31: jump = v->c.cmp == 0; break;
        case 32: jump = v->c.cmp > 0; break;
        case 33: jump = v->c.cmp >= 0; break;
        case 34: jump = v->c.cmp != 0; break;
        case 35:
            if (v->depth) { stage.fault = 213; return; }
            v->saved = v->c; v->depth = 1; memset(&v->c, 0, sizeof(v->c));
            v->c.pc = a[0]; v->c.v[0] = a[1]; v->c.v[4] = a[2];
            break;
        case 36:
            if (!v->depth) { stage.fault = 214; return; }
            v->c = v->saved; v->depth = 0;
            break;
        case 47: v->speed = fval(v, a[0]) / 16; break;
        case 50: {
            int lo = angle_fixed(a[0]), hi = angle_fixed(a[1]);
            v->angle = lo + (int)(stage_random() % (unsigned)(hi - lo));
            if (v->x < 96 * Q && (v->angle > 16384 || v->angle < -16384)) v->angle = 32768 - v->angle;
            if (v->x > 288 * Q && v->angle > -16384 && v->angle < 16384) v->angle = 32768 - v->angle;
            if (v->y < 48 * Q && v->angle < 0) v->angle = -v->angle;
            if (v->y > 220 * Q && v->angle > 0) v->angle = -v->angle;
            break;
        }
        case 57: movement(k, v, a[0], a[1] / 16, a[2] / 16, enraged); break;
        case 61:
            movement(k, v, a[0],
                     v->x + (int)((long long)turn_cos(v->angle) * v->speed * a[0] / 65536),
                     v->y + (int)((long long)turn_sin(v->angle) * v->speed * a[0] / 65536), enraged);
            break;
        case 67: case 68: case 69: case 70: fire_op(k, v, o, px, py); break;
        case 81: break;
        case 82: for (int i = 0; i < 8; ++i) v->ex[i] = i < 4 ? ival(v, a[i]) : fval(v, a[i]); break;
        case 105: bosses[k].vulnerable = (unsigned)a[0]; break;
        case 131: break;
        default: stage.fault = 200 + o->op; return;
        }
        if (jump) {
            v->c.time = a[0]; v->c.pc = a[1];
        }
    }
    if (v->mt < v->mn) {
        long long t = ++v->mt, n = v->mn, u = (2 * n * t - t * t) * 65536 / (n * n);
        v->x = v->sx + (int)(v->dx * u / 65536);
        v->y = v->sy + (int)(v->dy * u / 65536);
    }
    int x = map_x(k, v->x) / Q, y = map_y(k,v->y) / Q;
    if (x < 32) x = 32; if (x > ARENA_W - 32) x = ARENA_W - 32;
    if (y < 40) y = 40; if (y > ARENA_H - 40) y = ARENA_H - 40;
    bosses[k].x = x; bosses[k].y = y;
    ++v->c.time;
}

static void vm_init(unsigned k, int time, int x, int y) {
    memset(&vmb[k], 0, sizeof(vmb[k]));
    VM(k)->x = x; VM(k)->y = y; VM(k)->c.time = time;
}

static void trigger_enrage(unsigned k) {
    BattleBoss *b = &bosses[k];
    if (b->enrage_done) return;
    /* Lock the one-shot event before any effect/summon/refill can call back
       into this function. */
    b->enrage_done = 1;
    b->state = BOSS_ENRAGE_INTRO;
    b->state_ticks = 0;
    pending_clear(k);
    fx_boss_enrage_start(k);
}

static void summon_reinforcements(void) {
    if (summon_done) return;
    summon_done = 1; /* lock before touching either reinforcement */
    for (unsigned k = 1; k < active_boss_count(); ++k) {
        BattleBoss *b = &bosses[k];
        b->state = BOSS_ENTER; b->state_ticks = 0;
        b->entered = 0; b->dead = 0; b->enraged = 0; b->enrage_done = 0;
        b->refilled = 0; b->hp = b->max_hp;
        b->enter_sx = k%3u==1 ? 96u : k%3u==2 ? (unsigned)(ARENA_W-96) : (unsigned)(ARENA_W/2);
        b->enter_sy = (unsigned)(-72-(int)(k/3u)*32);
        b->enter_tx = 256u+(k%3u)*256u;
        b->enter_ty = 120u+(k/3u)*160u;
        b->x = (int)b->enter_sx; b->y = (int)b->enter_sy;
        vm_init(k, 0, 192 * Q, 80 * Q);
        pending_clear(k);
        fx_boss_enter(k);
    }
}

static void finish_enrage(unsigned k) {
    BattleBoss *b = &bosses[k];
    if (b->state != BOSS_ENRAGE_INTRO) return;
    b->state = BOSS_ENRAGED;
    b->enraged = 1;
    b->state_ticks = 0;
    b->refilled = 1;
    if (k == 0) {
        if (game_cfg.refill_first) b->hp = b->max_hp;
        summon_reinforcements();
    } else if (game_cfg.refill_others) {
        b->hp = b->max_hp;
    }
    fx_boss_enrage_finish(k);
    unsigned count = k == 0 ? game_cfg.first_burst : game_cfg.other_burst;
    battle_burst(k, count);
}

void battle_burst(unsigned k, unsigned count) {
    if (k >= active_boss_count() || !count) return;
    unsigned rings = game_cfg.burst_rings ? game_cfg.burst_rings : 1;
    if(!legacy_mode&&game_cfg.boss_profiles_enabled&&bosses[k].state==BOSS_ENRAGED){
        unsigned den=game_cfg.boss_burst_scale_den[k];
        if(den)count=(count*game_cfg.boss_burst_scale_num[k]+den-1)/den;
        rings=game_cfg.boss_burst_rings[k]?game_cfg.boss_burst_rings[k]:rings;
    }
    if(rings>8)rings=8; /* Q12 velocity remains within signed16 storage. */
    unsigned per = (count + rings - 1) / rings;
    for (unsigned ring = 0; ring < rings; ++ring) {
        unsigned start = ring * per;
        if(start>=count)break; /* Tiny configured bursts cannot underflow end-start. */
        unsigned end = start + per;
        if (end > count) end = count;
        unsigned m = end - start;
        if (!m) continue;
        unsigned speed = game_cfg.burst_speed_first + game_cfg.burst_speed_step * ring;
        unsigned tile = 54u + (k * rings + ring) % 16u;
        for (unsigned j = 0; j < m; ++j) {
            int an = (int)((unsigned long long)j * 65536u / m) + (int)(ring * 8192u);
            stage_shot_add(k, bosses[k].x * Q, bosses[k].y * Q, an, (int)speed,
                           tile, 0, 0, 0, 0);
        }
    }
}

int battle_can_damage(unsigned k) {
    if (k >= active_boss_count()) return 0;
    BattleBoss *b = &bosses[k];
    if (b->dead || !b->entered) return 0;
    if (b->state == BOSS_ENRAGED) return 1;
    return b->state == BOSS_NORMAL && b->vulnerable != 0;
}

int battle_targetable(unsigned k) { return battle_can_damage(k); }

static void add_damage_score(int actual) {
    if (actual > 0) player_add_score((unsigned)actual * game_cfg.damage_score);
}

int battle_apply_damage(unsigned k, int amount, unsigned source) {
    (void)source;
    if (amount <= 0 || k >= active_boss_count()) return 0;
    BattleBoss *b = &bosses[k];
    if (!battle_can_damage(k)) return 0;

    if (!b->enraged && b->state == BOSS_NORMAL) {
        int half = half_hp();
        if (b->hp <= half) {
            trigger_enrage(k);
            return 0;
        }
        if (b->hp - amount <= half) {
            int actual = b->hp - half;
            if (actual < 0) actual = 0;
            b->hp = half;
            b->damage_taken += (unsigned)actual;
            add_damage_score(actual);
            trigger_enrage(k);
            return actual;
        }
    }

    if(battle_load_active){
        ++battle_load_boss_hits;
        if(b->hp<=amount){b->hp=b->max_hp;++battle_load_keeps;}
    }
    int actual = amount;
    if (actual > b->hp) actual = b->hp;
    if (actual <= 0) return 0;
    b->hp -= actual;
    b->damage_taken += (unsigned)actual;
    add_damage_score(actual);
    if (b->hp <= 0) {
        b->hp = 0;
        if (!b->dead) {
            b->dead = 1;
            b->state = BOSS_DEAD;
            b->death_tick = stage.frame;
            pending_clear(k);
            player_add_score(game_cfg.boss_kill_score);
            fx_boss_death(k);
            if (battle_all_defeated()) battle_cleared = 1;
        }
    }
    return actual;
}

unsigned battle_all_defeated(void) {
    for (unsigned k = 0; k < active_boss_count(); ++k)
        if (!bosses[k].dead || !bosses[k].entered) return 0;
    return 1;
}

static void update_enter(unsigned k) {
    BattleBoss *b = &bosses[k];
    unsigned n = game_cfg.enter_ticks ? game_cfg.enter_ticks : 1;
    unsigned t = ++b->state_ticks;
    if (t >= n) {
        b->x = (int)b->enter_tx; b->y = (int)b->enter_ty;
        b->state = BOSS_NORMAL; b->state_ticks = 0;
        b->entered = 1; b->vulnerable = 0;
        vm_init(k, 0, 192 * Q, 80 * Q);
        return;
    }
    unsigned u = (2 * n * t - t * t) * 65536u / (n * n);
    b->x = (int)b->enter_sx + (int)((long long)((int)b->enter_tx - (int)b->enter_sx) * u / 65536);
    b->y = (int)b->enter_sy + (int)((long long)((int)b->enter_ty - (int)b->enter_sy) * u / 65536);
}

static void contact_check(unsigned i,int px,int py){
    ++battle_near_candidates;
    Shot *b=&stage.shots[i];
    int hit=(int)game_bullet_radius(),graze=hit+9;
    if((unsigned)(b->y/Q-py+graze)<(unsigned)(graze*2+1)){
        int dx=b->x/Q-px,dy=b->y/Q-py;
        if((unsigned)(dx+hit)<(unsigned)(hit*2+1)&&(unsigned)(dy+hit)<(unsigned)(hit*2+1)&&b->age>=effects[i].delay)battle_hit=1;
        if((unsigned)(dx+graze)<(unsigned)(graze*2+1)&&!b->grazed){b->grazed=1;++battle_grazes;}
    }
}
static unsigned contact_bucket(int y){
    if(y<0)return 0;
    unsigned b=(unsigned)y*CONTACT_BUCKETS/ARENA_H;
    return b<CONTACT_BUCKETS?b:CONTACT_BUCKETS-1;
}
static void density_update(void){
    if(!game_cfg.adaptive_density||!stage.limit){battle_density_slow=0;return;}
    unsigned fill=stage.count*100u;
    if(!battle_density_slow&&fill>stage.limit*game_cfg.density_high_pct)battle_density_slow=1;
    else if(battle_density_slow&&fill<=stage.limit*game_cfg.density_low_pct)battle_density_slow=0;
}
static void simulate_bullets_original(int px, int py) {
    unsigned collect=!legacy_mode&&game_cfg.near_enabled;
    battle_near_candidates=0;
    if(collect)memset(contact_count,0,sizeof(contact_count));
    int radius=(int)game_bullet_radius();
    for (unsigned i = 0; i < stage.count;) {
        Shot *b = &stage.shots[i];
        Effect *e = &effects[i];
        int vx = b->vx, vy = b->vy;
        if (b->age < e->delay) {
            vx = vx * 2 / 5; vy = vy * 2 / 5;
        } else if (e->turn) {
            unsigned t = b->age - e->delay;
            if (t >= e->turn) {
                /* Both factors are signed 16-bit; the exact product fits
                   int32_t. Keep C's signed division toward zero. */
                b->vx = (int16_t)((int32_t)turn_cos(e->target) * e->target_speed / 32768);
                b->vy = (int16_t)((int32_t)turn_sin(e->target) * e->target_speed / 32768);
                vx = b->vx; vy = b->vy; e->turn = 0;
            } else {
                vx = vx * (int)(e->turn - t) / (int)e->turn;
                vy = vy * (int)(e->turn - t) / (int)e->turn;
            }
        }
        b->x += vx; b->y += vy;
        if (b->age < game_cfg.bullet_age_max) ++b->age;
        if (b->x < radius * Q || b->x > (ARENA_W - radius) * Q ||
            b->y < radius * Q || b->y > (ARENA_H - radius) * Q) {
            unsigned last = --stage.count;
            *b = stage.shots[last];
            *e = effects[last];
            stage.owner[i] = stage.owner[last];
            continue;
        }
        if(collect){
            unsigned bucket=contact_bucket(b->y/Q),n=contact_count[bucket]++;
            if(n<CONTACT_BUCKET_CAP)contact_index[bucket][n]=(uint16_t)i;
        }else contact_check(i,px,py);
        ++i;
    }
    if(collect){
        unsigned lo=contact_bucket(py-(int)game_bullet_graze_radius()),hi=contact_bucket(py+(int)game_bullet_graze_radius()),overflow=0;
        for(unsigned b=lo;b<=hi;++b)if(contact_count[b]>CONTACT_BUCKET_CAP)overflow=1;
        if(overflow){
            ++battle_near_fallbacks;
            for(unsigned i=0;i<stage.count;++i)contact_check(i,px,py);
        }else for(unsigned b=lo;b<=hi;++b)
            for(unsigned n=0;n<contact_count[b];++n)contact_check(contact_index[b][n],px,py);
    }
}

static void simulate_bullets_relevant(int px, int py) {
    /* Only the one or two Y buckets queried by this player can affect contact.
       Keep their exact original ascending-index order and overflow threshold.
       All surviving bullets are positive-Y and 688/8 is exactly86 pixels. */
    enum { ROW_PIXELS=ARENA_H/CONTACT_BUCKETS };
    _Static_assert(ARENA_H%CONTACT_BUCKETS==0,"exact relevant bucket edges");
    unsigned lo=contact_bucket(py-(int)game_bullet_graze_radius()),hi=contact_bucket(py+(int)game_bullet_graze_radius());
    unsigned lower=lo*ROW_PIXELS*Q,span=(hi-lo+1)*ROW_PIXELS*Q;
    unsigned pair_counts=0,count=stage.count;
    _Static_assert(SHOT_CAPACITY<65536,"packed relevant bucket counts");
    battle_near_candidates=0;
    memset(contact_count,0,sizeof(contact_count));
    int radius=(int)game_bullet_radius();
    const unsigned age_max=game_cfg.bullet_age_max;
    _Static_assert(sizeof(Shot)==16 && __builtin_offsetof(Shot,vx)==8 && __builtin_offsetof(Shot,age)==12,"packed Shot read layout");
    _Static_assert(sizeof(Effect)==12 && __builtin_offsetof(Effect,target)==4 && __builtin_offsetof(Effect,turn)==8,"packed Effect read layout");
    _Static_assert(__BYTE_ORDER__==__ORDER_LITTLE_ENDIAN__,"packed fields require little endian");
    for (unsigned i = 0; i < count;) {
        Shot *b = &stage.shots[i];
        Effect *e = &effects[i];
        int bx,by;uint32_t velocity,age_word,timing_word;
#ifdef __riscv
        /* Publish no writes before all inputs are loaded. The AXI bridge
           otherwise has to drain pending writes before a subsequent read. */
        __asm__ volatile(
            "lw %0,0(%5)\n\tlw %1,4(%5)\n\tlw %2,8(%5)\n\t"
            "lw %3,12(%5)\n\tlw %4,8(%6)"
            : "=&r"(bx),"=&r"(by),"=&r"(velocity),"=&r"(age_word),"=&r"(timing_word)
            : "r"(b),"r"(e) : "memory");
#else
        bx=b->x;by=b->y;memcpy(&velocity,&b->vx,4);memcpy(&age_word,&b->age,4);
        memcpy(&timing_word,&e->turn,4);
#endif
        int vx=(int16_t)velocity,vy=(int16_t)(velocity>>16);
        unsigned age=(uint16_t)age_word,turn=(uint16_t)timing_word,delay=timing_word>>16;
        if (age < delay) {
            vx = vx * 2 / 5; vy = vy * 2 / 5;
        } else if (turn) {
            unsigned t = age - delay;
            if (t >= turn) {
                uint32_t target_word;memcpy(&target_word,&e->target,4);
                int target=(int16_t)target_word,speed=(int16_t)(target_word>>16);
                vx=(int16_t)((int32_t)turn_cos(target)*speed/32768);
                vy=(int16_t)((int32_t)turn_sin(target)*speed/32768);
                uint32_t changed=(uint16_t)vx|((uint32_t)(uint16_t)vy<<16);
                memcpy(&b->vx,&changed,4);e->turn=0;
            } else {
                vx = vx * (int)(turn - t) / (int)turn;
                vy = vy * (int)(turn - t) / (int)turn;
            }
        }
        int x=bx+vx,y=by+vy;
        if(age<age_max)++age;
        age=(uint16_t)age; /* contact reads the stored uint16 age, including wrap. */
        if (x < radius * Q || x > (ARENA_W - radius) * Q ||
            y < radius * Q || y > (ARENA_H - radius) * Q) {
            /* Preserve the updated removed-tail age before copying, even
               when last==i. Tile/grazed bytes are unchanged on this path. */
            b->x=x;b->y=y;b->age=(uint16_t)age;
            unsigned last = --count;stage.count=count;
            *b = stage.shots[last];
            *e = effects[last];
            stage.owner[i] = stage.owner[last];
            continue;
        }
        uint32_t updated=(age_word&0xffff0000u)|age;
        unsigned relative=(unsigned)y-lower;
        if(relative<span){
            /* Fused contact never consumes these index slots. Retain the
               exact bucket visit counts and overflow threshold, not stores. */
            if(lo!=hi&&relative>=ROW_PIXELS*Q)pair_counts+=65536u;else ++pair_counts;
            /* The motion inputs already contain all contact fields. Each
               surviving bullet has independent hit/graze side effects; keep
               exact candidate counts and overflow diagnostics below. */
            int graze=radius+9,dx=x/Q-px,dy=y/Q-py;
            if((unsigned)(dy+graze)<(unsigned)(graze*2+1)){
                if((unsigned)(dx+radius)<(unsigned)(radius*2+1)&&
                   (unsigned)(dy+radius)<(unsigned)(radius*2+1)&&age>=delay)battle_hit=1;
                if((unsigned)(dx+graze)<(unsigned)(graze*2+1)&&!(age_word&0xff000000u)){
                    updated|=0x01000000u;++battle_grazes;
                }
            }
        }
        /* One aligned word stores updated age plus the original tile and
           grazed byte (only a legal zero-to-one graze changes that byte). */
#ifdef __riscv
        /* Complete every input/spill read before this contiguous write group;
           the bridge must not drain for an inserted stack load between them. */
        __asm__ volatile("sw %1,0(%0)\n\tsw %2,4(%0)\n\tsw %3,12(%0)"
            : : "r"(b),"r"(x),"r"(y),"r"(updated) : "memory");
#else
        b->x=x;b->y=y;memcpy(&b->age,&updated,4);
#endif
        ++i;
    }
    /* No index scratch is consumed in this fused path. Counts, candidate
       totals and overflow diagnostics retain their original exact values. */
    unsigned nl=pair_counts&65535u,nh=pair_counts>>16;
    contact_count[lo]=nl;if(hi!=lo)contact_count[hi]=nh;
    {
        unsigned overflow=0;
        for(unsigned b=lo;b<=hi;++b)if(contact_count[b]>CONTACT_BUCKET_CAP)overflow=1;
        if(overflow){
            ++battle_near_fallbacks;
            /* The original fallback visits all survivors. Nonqueried Y
               buckets cannot hit/graze, but its visit count is observable. */
            battle_near_candidates=count;
        }else battle_near_candidates=nl+nh;
    }
}

static void simulate_bullets(int px,int py){
    if(!legacy_mode&&game_cfg.near_enabled&&game_cfg.battle_gather_enabled){
        MotionHwOutput result;
        if(motion_hw_try(stage.shots,effects,stage.owner,contact_index,contact_count,
                         stage.count,game_cfg.enemy_bullet_size,game_cfg.bullet_age_max,
                         px,py,&result)){
            stage.count=result.count;
            /* These globals may already hold values in direct callers. The
               original kernel only sets hit when a hit occurs and adds graze. */
            if(result.hit)battle_hit=1;
            battle_grazes+=result.grazes;
            battle_near_candidates=result.candidates;
            battle_near_fallbacks+=result.fallbacks;
        }else simulate_bullets_relevant(px,py);
    }else simulate_bullets_original(px,py);
}

static void step_legacy(int px, int py) {
    uint64_t tp_part=tick_profile_begin();
    battle_hit = battle_grazes = 0;
    static const unsigned periods[] = {1500, 2100, 1800};
    for (unsigned k = 0; k < 3; ++k) if (bosses[k].hp > 0) {
        if (stage.frame && stage.frame % periods[k] == 0) {
            int x = VM(k)->x, y = VM(k)->y;
            vm_init(k, 0, x, y);
        }
        run(k, px, py);
    }
    stage.bx = bosses[0].x * Q; stage.by = bosses[0].y * Q;
    tick_profile_end(TP_BOSS,tp_part);tp_part=tick_profile_begin();
    simulate_bullets(px, py);
    tick_profile_end(TP_MOTION,tp_part);++stage.frame;
}

void battle_set_legacy(unsigned enabled) { legacy_mode = enabled ? 1u : 0u; }
unsigned battle_legacy_mode(void) { return legacy_mode; }

void battle_reset(unsigned difficulty, unsigned limit) {
#if CONTACT_FIXED_DDR
    if(!battle_scratch_init())fatal("CONTACT GUARD",-1);
#endif
    battle_load_active=0;
    stage_reset(difficulty, limit);
    battle_materials = 1;
    battle_hit = battle_grazes = battle_cleared = 0;
    summon_done = 0;
    battle_density_slow=battle_density_skips=battle_near_candidates=battle_near_fallbacks=0;
    for (unsigned k = 0; k < MAX_BOSSES; ++k) {
        memset(&vmb[k], 0, sizeof(vmb[k]));
        memset(&bosses[k], 0, sizeof(bosses[k]));
        bosses[k].max_hp = (int)game_cfg.boss_max_hp;
        bosses[k].hp = (int)game_cfg.boss_max_hp;
        bosses[k].state = BOSS_WAIT;
        bosses[k].x = -100; bosses[k].y = -100;
    }
    if (legacy_mode) {
        static const int xs[3] = {256, 512, 768};
        for (unsigned k = 0; k < 3; ++k) {
            bosses[k].state = BOSS_NORMAL;
            bosses[k].entered = 1;
            bosses[k].x = xs[k]; bosses[k].y = 120;
            vm_init(k, 0, 192 * Q, 80 * Q);
        }
        return;
    }
    BattleBoss *b = &bosses[0];
    b->state = BOSS_NORMAL;
    b->entered = 1;
    b->x = 256; b->y = 120;
    vm_init(0, 0, 192 * Q, 80 * Q);
}

static void battle_prepare(int px,int py){
    uint64_t tp_part=tick_profile_begin();
    battle_hit = battle_grazes = 0;
    density_update();
    static const unsigned periods[] = {1500, 2100, 1800};
    unsigned count=active_boss_count();
    unsigned first=count?stage.frame%count:0;
    for (unsigned i=0;i<count;++i) {
        unsigned k=(first+i)%count;
        BattleBoss *b = &bosses[k];
        switch (b->state) {
        case BOSS_WAIT:
            continue;
        case BOSS_ENTER:
            update_enter(k);
            continue;
        case BOSS_ENRAGE_INTRO:
            if (++b->state_ticks >= game_cfg.enrage_intro_ticks) finish_enrage(k);
            continue;
        case BOSS_DEAD:
            pending_clear(k);
            continue;
        default:
            break;
        }
        if (b->state == BOSS_ENRAGED) pending_step(k);
        ++b->script_ticks;
        if (b->script_ticks >= periods[k%3u]) {
            int x = VM(k)->x, y = VM(k)->y;
            vm_init(k, 0, x, y);
            b->script_ticks = 0;
            pending_clear(k);
        }
        run(k, px, py);
    }
    stage.bx = bosses[0].x * Q; stage.by = bosses[0].y * Q;
    tick_profile_end(TP_BOSS,tp_part);
}

static unsigned battle_motion_pending;
static uint64_t battle_motion_started;
static void battle_accept_motion(const MotionHwOutput *r){
    stage.count=r->count;if(r->hit)battle_hit=1;battle_grazes+=r->grazes;
    battle_near_candidates=r->candidates;battle_near_fallbacks+=r->fallbacks;
}
void battle_step(int px,int py){
    if(battle_motion_pending)fatal("BATTLE PENDING",-1);
    if(legacy_mode){step_legacy(px,py);return;}
    battle_prepare(px,py);uint64_t tp_part=tick_profile_begin();
    simulate_bullets(px,py);tick_profile_end(TP_MOTION,tp_part);++stage.frame;
}
int battle_step_begin(int px,int py,unsigned render_epoch){
    if(battle_motion_pending)fatal("BATTLE DOUBLE BEGIN",-1);
    if(legacy_mode||!game_cfg.near_enabled||!game_cfg.battle_gather_enabled){battle_step(px,py);return 0;}
    battle_prepare(px,py);battle_motion_started=tick_profile_begin();
    if(motion_hw_begin(stage.shots,effects,stage.owner,contact_index,contact_count,
                       stage.count,game_cfg.enemy_bullet_size,game_cfg.bullet_age_max,
                       px,py,render_epoch)){
        battle_motion_pending=1;return 1;
    }
    simulate_bullets_relevant(px,py);tick_profile_end(TP_MOTION,battle_motion_started);++stage.frame;return 0;
}
int battle_step_poll(void){
    if(!battle_motion_pending)return 1;
    if(!motion_hw_poll())return 0;
    MotionHwOutput result;motion_hw_commit(&result);battle_accept_motion(&result);
    tick_profile_end(TP_MOTION,battle_motion_started);++stage.frame;battle_motion_pending=0;return 1;
}

unsigned battle_clear_owner(unsigned k){
    if(k>255u)return 0;
    uint64_t tp_part=tick_profile_begin();
    unsigned removed=0;
    for(unsigned i=0;i<stage.count;){
        if(stage.owner[i]!=(uint8_t)k){++i;continue;}
        unsigned last=--stage.count;
        stage.shots[i]=stage.shots[last];
        effects[i]=effects[last];
        stage.owner[i]=stage.owner[last];
        ++removed;
    }
    tick_profile_end(TP_CLEAR_OWNER,tp_part);return removed;
}

static uint32_t battle_hash_bytes(uint32_t h,const void *data,unsigned bytes){
    const unsigned char *p=(const unsigned char *)data;
    for(unsigned i=0;i<bytes;++i)h=(h^p[i])*16777619u;
    return h;
}
uint32_t battle_state_hash(uint32_t initial){
    uint32_t h=battle_hash_bytes(initial,&legacy_mode,sizeof(legacy_mode));
    h=battle_hash_bytes(h,&battle_density_slow,sizeof(battle_density_slow));
    h=battle_hash_bytes(h,vmb,sizeof(vmb));
    unsigned count=stage.count<SHOT_CAPACITY?stage.count:SHOT_CAPACITY;
    return battle_hash_bytes(h,effects,count*sizeof(Effect));
}

int battle_spawn_enemy_bullet(unsigned owner,int x,int y,int angle,int speed,unsigned tile){
    if(owner<128u||owner>255u||x<0||x>=ARENA_W||y<0||y>=ARENA_H||speed<0||speed>32767||tile<54u||tile>=70u)return 0;
    return stage_shot_add(owner,x*Q,y*Q,(int)((unsigned)angle&65535u),speed,tile,0,0,0,0);
}

void battle_load_begin(unsigned seed,unsigned count){
#if CONTACT_FIXED_DDR
    if(!battle_scratch_init())fatal("CONTACT GUARD",-1);
#endif
    battle_load_active=1;load_cursor=0;
    battle_load_fills=battle_load_recycles=battle_load_keeps=0;
    battle_load_boss_hits=battle_load_mob_hits=battle_load_player_hits=battle_load_player_damage=0;
    stage.seed=seed;stage.limit=count;summon_done=1;
    for(unsigned k=0;k<active_boss_count();++k){
        BattleBoss *b=&bosses[k];b->state=BOSS_ENRAGED;b->entered=b->enraged=b->enrage_done=b->refilled=1;
        b->hp=b->max_hp;b->dead=0;b->x=256+(int)(k%3)*256;b->y=120+(int)(k/3)*160;
        vm_init(k,0,192*Q,80*Q);
    }
    battle_load_refill(count);
}
void battle_load_refill(unsigned count){
    if(!battle_load_active)return;
    unsigned radius=game_bullet_radius(),w=ARENA_W-2*radius,h=ARENA_H-2*radius;
    while(stage.count<count){
        unsigned i=stage.count,random=stage_random();
        int x=(int)(radius+random%w),y=(int)(radius+stage_random()%h),an=(int)(stage_random()&65535u);
        int speed=Q+(int)(random&4095u);
        unsigned turn=(i%4u)==0?24u:0u,delay=(i%4u)==1?8u:0u;
        if(!stage_shot_add(255,x*Q,y*Q,an,speed,54+(random&15u),an+16384,speed,turn,delay))break;
        ++battle_load_fills;
    }
}
void battle_load_end(void){battle_load_active=0;}
