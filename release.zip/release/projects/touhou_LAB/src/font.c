#include "font.h"
#include "bitblt.h"

/* Original compact 5x7 bitmap glyphs; column bits run from top to bottom. */
static const unsigned char digits[10][5] = {
 {0x3e,0x51,0x49,0x45,0x3e},{0x00,0x42,0x7f,0x40,0x00},
 {0x62,0x51,0x49,0x49,0x46},{0x22,0x49,0x49,0x49,0x36},
 {0x18,0x14,0x12,0x7f,0x10},{0x2f,0x49,0x49,0x49,0x31},
 {0x3e,0x49,0x49,0x49,0x32},{0x01,0x71,0x09,0x05,0x03},
 {0x36,0x49,0x49,0x49,0x36},{0x26,0x49,0x49,0x49,0x3e}
};
static const unsigned char letters[26][5] = {
 {0x7e,0x09,0x09,0x09,0x7e},{0x7f,0x49,0x49,0x49,0x36},
 {0x3e,0x41,0x41,0x41,0x22},{0x7f,0x41,0x41,0x22,0x1c},
 {0x7f,0x49,0x49,0x49,0x41},{0x7f,0x09,0x09,0x09,0x01},
 {0x3e,0x41,0x49,0x49,0x7a},{0x7f,0x08,0x08,0x08,0x7f},
 {0x00,0x41,0x7f,0x41,0x00},{0x20,0x40,0x41,0x3f,0x01},
 {0x7f,0x08,0x14,0x22,0x41},{0x7f,0x40,0x40,0x40,0x40},
 {0x7f,0x02,0x0c,0x02,0x7f},{0x7f,0x04,0x08,0x10,0x7f},
 {0x3e,0x41,0x41,0x41,0x3e},{0x7f,0x09,0x09,0x09,0x06},
 {0x3e,0x41,0x51,0x21,0x5e},{0x7f,0x09,0x19,0x29,0x46},
 {0x26,0x49,0x49,0x49,0x32},{0x01,0x01,0x7f,0x01,0x01},
 {0x3f,0x40,0x40,0x40,0x3f},{0x1f,0x20,0x40,0x20,0x1f},
 {0x7f,0x20,0x18,0x20,0x7f},{0x63,0x14,0x08,0x14,0x63},
 {0x03,0x04,0x78,0x04,0x03},{0x61,0x51,0x49,0x45,0x43}
};
static unsigned column(char c, unsigned x) {
    if (c >= 'a' && c <= 'z') c -= 'a' - 'A';
    if (c >= '0' && c <= '9') return digits[c-'0'][x];
    if (c >= 'A' && c <= 'Z') return letters[c-'A'][x];
    if (c == '-') return 0x08;
    if (c == ':') return x == 2 ? 0x24 : 0;
    if (c == '.') return x == 2 ? 0x40 : 0;
    if (c == '/') return 0x40u >> x;
    if (c == '+') return x == 2 ? 0x3e : 0x08;
    if (c == '=') return 0x14;
    if (c == '[') return x == 0 ? 0x7f : x < 3 ? 0x41 : 0;
    if (c == ']') return x == 4 ? 0x7f : x > 1 ? 0x41 : 0;
    return 0;
}
static void draw_text_clipped_slow(uint32_t fb, int x, int y, const char *t,
               uint32_t color, unsigned scale,
               int clip_left, int clip_top, int clip_right, int clip_bottom) {
    int64_t pen_x = x, pen_y = y;
    if (!t || !scale || (fb & 3u) || fb < 0x00100000u ||
        (uint64_t)fb + BB_FRAME_BYTES > BB_DDR_END) return;
    while (*t) {
        if (*t == '\n') {
            pen_x = 8;
            pen_y += 9u * (uint64_t)scale;
            if (pen_y >= BB_SCREEN_H) return;
            ++t; continue;
        }
        for (unsigned col = 0; col < 5 && pen_x < BB_SCREEN_W && pen_y < BB_SCREEN_H; ++col) {
            unsigned bits = column(*t, col);
            int64_t left = pen_x + col * (int64_t)scale;
            if (left >= BB_SCREEN_W) break;
            unsigned width = scale;
            if (width > BB_SCREEN_W - (unsigned)left) width = BB_SCREEN_W - (unsigned)left;
            for (unsigned row = 0; row < 7; ++row) if (bits & (1u << row)) {
                int64_t top = pen_y + row * (int64_t)scale;
                if (top >= BB_SCREEN_H) break;
                unsigned height = scale;
                if (height > BB_SCREEN_H - (unsigned)top) height = BB_SCREEN_H - (unsigned)top;
                for (unsigned sy = 0; sy < height; ++sy)
                    for (unsigned sx = 0; sx < width; ++sx) {
                        int64_t px=left+sx, py=top+sy;
                        if(px>=0 && py>=0 && px<BB_SCREEN_W && py<BB_SCREEN_H &&
                           px>=clip_left && px<clip_right && py>=clip_top && py<clip_bottom)
                            *(volatile uint32_t *)(uintptr_t)(fb + (unsigned)py * BB_SCREEN_STRIDE +
                                (unsigned)px * 4u) = color;
                    }
            }
        }
        /* Saturate once beyond the screen; a later newline resets x to 8. */
        pen_x += 6u * (uint64_t)scale;
        if (pen_x > BB_SCREEN_W) pen_x = BB_SCREEN_W;
        ++t;
    }
}

/* Common positive screen coordinates, scale 1..4: resolve the clip once,
   then emit each glyph's contiguous horizontal runs with 32-bit arithmetic.
   The original implementation remains intact for uncommon inputs. */
/* Exact row masks and run endpoints derived from the same 5x7 glyphs.
   Avoid rebuilding five columns and scanning all five bits on every row. */
static const unsigned char glyph_rows[128][7] = {
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,4,4,31,4,4,0},
    {0,0,0,0,0,0,0},
    {0,0,0,31,0,0,0},
    {0,0,0,0,0,0,4},
    {0,0,16,8,4,2,1},
    {14,17,25,21,19,17,14},
    {4,6,4,4,4,4,14},
    {14,17,16,12,2,1,31},
    {14,17,16,14,16,17,14},
    {8,12,10,9,31,8,8},
    {31,1,1,15,16,17,14},
    {14,17,1,15,17,17,14},
    {31,16,8,4,2,2,2},
    {14,17,17,14,17,17,14},
    {14,17,17,30,16,17,14},
    {0,0,4,0,0,4,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,31,0,31,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {14,17,17,31,17,17,17},
    {15,17,17,15,17,17,15},
    {14,17,1,1,1,17,14},
    {7,9,17,17,17,9,7},
    {31,1,1,15,1,1,31},
    {31,1,1,15,1,1,1},
    {14,17,1,29,17,17,30},
    {17,17,17,31,17,17,17},
    {14,4,4,4,4,4,14},
    {28,8,8,8,8,9,6},
    {17,9,5,3,5,9,17},
    {1,1,1,1,1,1,31},
    {17,27,21,21,17,17,17},
    {17,17,19,21,25,17,17},
    {14,17,17,17,17,17,14},
    {15,17,17,15,1,1,1},
    {14,17,17,17,21,9,22},
    {15,17,17,15,5,9,17},
    {14,17,1,14,16,17,14},
    {31,4,4,4,4,4,4},
    {17,17,17,17,17,17,14},
    {17,17,17,17,17,10,4},
    {17,17,17,21,21,27,17},
    {17,17,10,4,10,17,17},
    {17,17,10,4,4,4,4},
    {31,16,8,4,2,1,31},
    {7,1,1,1,1,1,7},
    {0,0,0,0,0,0,0},
    {28,16,16,16,16,16,28},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {14,17,17,31,17,17,17},
    {15,17,17,15,17,17,15},
    {14,17,1,1,1,17,14},
    {7,9,17,17,17,9,7},
    {31,1,1,15,1,1,31},
    {31,1,1,15,1,1,1},
    {14,17,1,29,17,17,30},
    {17,17,17,31,17,17,17},
    {14,4,4,4,4,4,14},
    {28,8,8,8,8,9,6},
    {17,9,5,3,5,9,17},
    {1,1,1,1,1,1,31},
    {17,27,21,21,17,17,17},
    {17,17,19,21,25,17,17},
    {14,17,17,17,17,17,14},
    {15,17,17,15,1,1,1},
    {14,17,17,17,21,9,22},
    {15,17,17,15,5,9,17},
    {14,17,1,14,16,17,14},
    {31,4,4,4,4,4,4},
    {17,17,17,17,17,17,14},
    {17,17,17,17,17,10,4},
    {17,17,17,21,21,27,17},
    {17,17,10,4,10,17,17},
    {17,17,10,4,4,4,4},
    {31,16,8,4,2,1,31},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0},
};
static const unsigned char glyph_runs[32][7] = {
    {0,0,0,0,0,0,0},
    {1,0,1,0,0,0,0},
    {1,1,2,0,0,0,0},
    {1,0,2,0,0,0,0},
    {1,2,3,0,0,0,0},
    {2,0,1,2,3,0,0},
    {1,1,3,0,0,0,0},
    {1,0,3,0,0,0,0},
    {1,3,4,0,0,0,0},
    {2,0,1,3,4,0,0},
    {2,1,2,3,4,0,0},
    {2,0,2,3,4,0,0},
    {1,2,4,0,0,0,0},
    {2,0,1,2,4,0,0},
    {1,1,4,0,0,0,0},
    {1,0,4,0,0,0,0},
    {1,4,5,0,0,0,0},
    {2,0,1,4,5,0,0},
    {2,1,2,4,5,0,0},
    {2,0,2,4,5,0,0},
    {2,2,3,4,5,0,0},
    {3,0,1,2,3,4,5},
    {2,1,3,4,5,0,0},
    {2,0,3,4,5,0,0},
    {1,3,5,0,0,0,0},
    {2,0,1,3,5,0,0},
    {2,1,2,3,5,0,0},
    {2,0,2,3,5,0,0},
    {1,2,5,0,0,0,0},
    {2,0,1,2,5,0,0},
    {1,1,5,0,0,0,0},
    {1,0,5,0,0,0,0},
};

static void draw_text_wide(uint32_t fb,int x,int y,const char *t,uint32_t color,
                           unsigned scale,int l,int top,int right,int bottom){
    if(l<0)l=0;if(top<0)top=0;
    if(right>(int)BB_SCREEN_W)right=BB_SCREEN_W;
    if(bottom>(int)BB_SCREEN_H)bottom=BB_SCREEN_H;
    if(l>=right||top>=bottom)return;
    const unsigned step=6*scale;
    while(*t){
        if(*t=='\n'){
            x=8;y+=9*(int)scale;
            if(y>=(int)BB_SCREEN_H)return;
            ++t;continue;
        }
        if(x<(int)BB_SCREEN_W&&y<(int)BB_SCREEN_H){
            unsigned char ch=(unsigned char)*t;
            const unsigned char *rows=glyph_rows[ch<128?ch:0];
            for(unsigned row=0;row<7;++row){
                int y0=y+(int)(row*scale),y1=y0+(int)scale;
                if(y0<top)y0=top;if(y1>bottom)y1=bottom;
                if(y0>=y1)continue;
                const unsigned char *runs=glyph_runs[rows[row]];
                for(unsigned run=0;run<runs[0];++run){
                    unsigned first=runs[1+run*2],c=runs[2+run*2];
                    int x0=x+(int)(first*scale),x1=x+(int)(c*scale);
                    if(x0<l)x0=l;if(x1>right)x1=right;
                    if(x0>=x1)continue;
                    for(int sy=y0;sy<y1;++sy){
                        volatile uint32_t *p=(volatile uint32_t *)(uintptr_t)(fb+(unsigned)sy*BB_SCREEN_STRIDE+(unsigned)x0*4);
                        volatile uint32_t *end=p+(x1-x0);
                        while(p<end)*p++=color;
                    }
                }
            }
        }
        x+=(int)step;if(x>(int)BB_SCREEN_W)x=BB_SCREEN_W;
        ++t;
    }
}
static void draw_text_fast(uint32_t fb,int x,int y,const char *t,uint32_t color,
                           unsigned scale,int l,int top,int right,int bottom){
    if(l<0)l=0;if(top<0)top=0;
    if(right>(int)BB_SCREEN_W)right=BB_SCREEN_W;
    if(bottom>(int)BB_SCREEN_H)bottom=BB_SCREEN_H;
    if(l>=right||top>=bottom)return;
    const unsigned step=6*scale;
    if(y>=bottom)return;
    unsigned row_first=top>y?(unsigned)(top-y)/scale:0;
    unsigned row_end=(unsigned)(bottom-y+scale-1)/scale;
    if(row_end>7)row_end=7;
    while(*t){
        if(*t=='\n'){
            x=8;y+=9*(int)scale;
            if(y>=bottom)return;
            row_first=top>y?(unsigned)(top-y)/scale:0;
            row_end=(unsigned)(bottom-y+scale-1)/scale;
            if(row_end>7)row_end=7;
            ++t;continue;
        }
        /* Fast-path coordinates are nonnegative and scale is 1..4.
           Reject an entire clipped glyph before looking up its seven rows.
           Still advance the text cursor and process following newlines. */
        if(x<right&&y<bottom&&x+(int)(5*scale)>l&&y+(int)(7*scale)>top){
            unsigned char ch=(unsigned char)*t;
            const unsigned char *rows=glyph_rows[ch<128?ch:0];
            for(unsigned row=row_first;row<row_end;++row){
                int y0=y+(int)(row*scale),y1=y0+(int)scale;
                if(y0<top)y0=top;if(y1>bottom)y1=bottom;
                if(y0>=y1)continue;
                const unsigned char *runs=glyph_runs[rows[row]];
                for(unsigned run=0;run<runs[0];++run){
                    unsigned first=runs[1+run*2],c=runs[2+run*2];
                    int x0=x+(int)(first*scale),x1=x+(int)(c*scale);
                    if(x0<l)x0=l;if(x1>right)x1=right;
                    if(x0>=x1)continue;
                    for(int sy=y0;sy<y1;++sy){
                        volatile uint32_t *p=(volatile uint32_t *)(uintptr_t)(fb+(unsigned)sy*BB_SCREEN_STRIDE+(unsigned)x0*4);
                        volatile uint32_t *end=p+(x1-x0);
                        while(p<end)*p++=color;
                    }
                }
            }
        }
        x+=(int)step;if(x>(int)BB_SCREEN_W)x=BB_SCREEN_W;
        ++t;
    }
}
void draw_text_clipped(uint32_t fb,int x,int y,const char *t,uint32_t color,
                       unsigned scale,int left,int top,int right,int bottom){
    if(!t||!scale||(fb&3u)||fb<0x00100000u||
       (uint64_t)fb+BB_FRAME_BYTES>BB_DDR_END)return;
    if(scale<=4&&(unsigned)x<=BB_SCREEN_W&&(unsigned)y<=BB_SCREEN_H){
        /* A full first line keeps the established tight glyph loop. The
           original routine still clips any later lines after a newline. */
        if(x>=left&&right>=(int)BB_SCREEN_W&&y>=top&&y+(int)(7*scale)<=bottom)
            draw_text_wide(fb,x,y,t,color,scale,left,top,right,bottom);
        else draw_text_fast(fb,x,y,t,color,scale,left,top,right,bottom);
    }
    else draw_text_clipped_slow(fb,x,y,t,color,scale,left,top,right,bottom);
}
void draw_text(uint32_t fb, unsigned x, unsigned y, const char *t,
               uint32_t color, unsigned scale) {
    if(x>0x7fffffffu || y>0x7fffffffu)return;
    draw_text_clipped(fb,(int)x,(int)y,t,color,scale,0,0,BB_SCREEN_W,BB_SCREEN_H);
}
void format_uint(char *out, uint32_t value) {
    char reverse[10];
    unsigned n = 0;
    do { reverse[n++] = (char)('0' + value % 10u); value /= 10u; } while (value);
    for (unsigned i = 0; i < n; ++i) out[i] = reverse[n - i - 1u];
    out[n] = 0;
}
