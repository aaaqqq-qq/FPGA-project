#pragma once
#include <stdint.h>
#include "arena.h"
#include "battle.h"

#define SHOT_CAPACITY 20000
#define Q 4096
/* DMA-visible layout: do not insert fields. Owner/tag data is parallel. */
typedef struct { int32_t x,y; int16_t vx,vy; uint16_t age; uint8_t tile,grazed; } Shot;
typedef struct {
    Shot shots[SHOT_CAPACITY];
    unsigned count,limit,requested,emitted,rejected,peak,frame,pc,time;
    int32_t vars[12],bx,by,move_x,move_y,move_dx,move_dy;
    unsigned move_time,move_total,seed,difficulty,vulnerable;
    int angle,speed,fault;
    uint8_t owner[SHOT_CAPACITY]; /* parallel metadata, never read by DMA */
} Stage;
extern Stage stage;
void stage_reset(unsigned difficulty,unsigned limit);
void stage_step(int player_x,int player_y);
void stage_stress(unsigned count);
void stage_stress_step(void);
unsigned stage_random(void);
int turn_atan(int x,int y);
int turn_sin(int angle);
int turn_cos(int angle);

void stage_stress_step_near(int px,int py);
unsigned stage_near_ready(int px,int py);
extern unsigned stage_near_count,stage_near_indices[512];
