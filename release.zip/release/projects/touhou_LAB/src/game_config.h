#pragma once
#define MAX_BOSSES 6u

/*
 * Central tuning values: original three-boss baseline, optional six-slot expansion.
 *
 * The values are deliberately kept in one writable struct instead of being
 * scattered through game.c: the host regression tests change individual
 * values to prove the state machine does not contain hidden magic numbers.
 * Firmware resets the struct from game_config_defaults() before a new run.
 */

typedef struct {
    /* Bosses */
    unsigned boss_count;
    unsigned boss_max_hp;
    unsigned boss_half_hp;
    unsigned enrage_intro_ticks;   /* warning before the burst / summon */
    unsigned enter_ticks;          /* simultaneous reinforcement entry */
    unsigned first_burst;          /* first boss warning burst */
    unsigned other_burst;          /* second/third boss warning burst */
    unsigned refill_first;         /* first boss refills at enrage */
    unsigned refill_others;        /* reinforcements refill at enrage (v1: 0) */
    unsigned enrage_fire_num;      /* 7/5 = ~1.4x firing cadence */
    unsigned enrage_fire_den;
    unsigned enrage_move_num;      /* 5/4 = 1.25x movement speed */
    unsigned enrage_move_den;
    unsigned enrage_bullets_num;   /* 3/2 = 1.5x bullets per volley */
    unsigned enrage_bullets_den;
    unsigned burst_rings;
    unsigned burst_speed_first;    /* Q12 pixels/tick, first ring */
    unsigned burst_speed_step;     /* Q12 pixels/tick added per ring */

    /* Player */
    unsigned player_max_hp;
    unsigned player_hit_damage;
    unsigned hit_invuln_ticks;
    unsigned spawn_invuln_ticks;
    unsigned bomb_invuln_ticks;
    unsigned bomb_damage;
    unsigned regen_wait_ticks;     /* no regen for this long after real damage */
    unsigned regen_period_ticks;   /* then one heal step per period */
    unsigned regen_amount;
    unsigned upgrade_ticks;        /* level-up animation / real immunity */
    unsigned upgrade_invuln_ticks;
    unsigned hp_delay_ticks;       /* delayed-loss segment hold time */
    unsigned hp_drop_rate;         /* delayed HP pixels per tick */
    unsigned player_shot_cap;      /* <= 128 compile-time array */
    unsigned player_shot_life;
    unsigned player_shot_damage;
    unsigned player_shot_speed;
    unsigned homing_shot_speed;

    /* Progression */
    unsigned max_level;
    unsigned level_threshold[6];   /* [1]..[5] */
    unsigned level_main[6];        /* main shot paths per level */
    unsigned level_homing[6];      /* homing ofuda paths per level */
    unsigned main_fire_period;
    unsigned homing_fire_period;

    /* Score */
    unsigned damage_score;
    unsigned boss_kill_score;
    unsigned graze_score;

    /* Effects / presentation budget */
    unsigned effect_job_budget;
    unsigned effect_area_budget;
    unsigned bullet_age_max;

    /* Logic */
    unsigned logic_hz;
    unsigned logic_max_catchup;

    /* R2 optional policies; legacy ECL mode bypasses density/profiles/near. */
    unsigned adaptive_density,density_high_pct,density_low_pct;
    unsigned density_slow_num,density_slow_den;
    unsigned boss_profiles_enabled;
    unsigned boss_fire_num[MAX_BOSSES],boss_fire_den[MAX_BOSSES];
    unsigned boss_move_num[MAX_BOSSES],boss_move_den[MAX_BOSSES];
    unsigned boss_bullets_num[MAX_BOSSES],boss_bullets_den[MAX_BOSSES];
    unsigned boss_burst_rings[MAX_BOSSES],boss_burst_scale_num[MAX_BOSSES],boss_burst_scale_den[MAX_BOSSES];
    unsigned homing_retarget_ticks,near_enabled;
    unsigned graze_feedback_enabled,graze_feedback_cooldown;
    unsigned low_hp_threshold,low_hp_pulse_ticks;
    unsigned death_slowmo_enabled,death_slowmo_ticks,death_slowmo_divisor;
    unsigned death_star_budget,vignette_enabled,hud_dirty_enabled;
    unsigned stress_gather_enabled,stress_overlap_enabled;
    unsigned enemy_count,background_depth_enabled;
    /* Eight sparse presentation layers; the large enemy batch stays the base. */
    unsigned layer_pipeline_enabled,layer_y_sort,layer_visuals_enabled;
    unsigned layer_order[8];
    unsigned layer_visuals_strength; /* 1 restrained, 2 visible demonstration */
    unsigned battle_gather_enabled,opaque_sprites,render_budget_enabled;
    unsigned enemy_bullet_size; /* square visual size and hitbox diameter: 8..56 by8 */
} GameConfig;

extern GameConfig game_cfg;
/* Separate presentation policy preserves the established GameConfig ABI. */
extern unsigned hud_dma_tail_enabled;

void game_config_defaults(void);

/* Returns 1 only for a validated, atomic whitelist update; 0 leaves all values unchanged. */
int game_config_set(const char *field,unsigned value);

/* The historical 8px case has radius4 and graze radius13 exactly. */
static inline unsigned game_bullet_radius(void){return game_cfg.enemy_bullet_size?game_cfg.enemy_bullet_size/2u:4u;}
static inline unsigned game_bullet_graze_radius(void){return game_bullet_radius()+9u;}
