#pragma once
#include <stdint.h>
#include "motion_abi.h"

typedef struct {
    unsigned count,hit,grazes,candidates,fallbacks;
} MotionHwOutput;
typedef struct {unsigned submitted,completed,last_cycles,last_read_bytes,last_write_bytes;} MotionHwCounters;

#if defined(__riscv) || defined(MOTION_HW_HOST_TEST)
void motion_hw_init(void);
void motion_hw_set_enabled(unsigned enabled);
MotionHwCounters motion_hw_counters(void);
int motion_hw_begin(void *shots,void *effects,uint8_t *owners,void *index,
                    unsigned *counts,unsigned count,unsigned size,unsigned age_max,
                    int px,int py,unsigned render_snapshot_epoch);
int motion_hw_poll(void);
void motion_hw_commit(MotionHwOutput *output);
unsigned motion_hw_active(void);
unsigned motion_hw_last_epoch(void);
int motion_hw_try(void *shots,void *effects,uint8_t *owners,void *index,
                  unsigned *counts,unsigned count,unsigned size,unsigned age_max,
                  int px,int py,MotionHwOutput *output);
#else
/* Existing native logic harnesses model old/cap0 hardware unless their
 * dedicated backend test explicitly links the real driver. */
static inline void motion_hw_init(void){}
static inline void motion_hw_set_enabled(unsigned enabled){(void)enabled;}
static inline MotionHwCounters motion_hw_counters(void){return (MotionHwCounters){0};}
static inline int motion_hw_begin(void *s,void *e,uint8_t *o,void *i,unsigned *c,unsigned n,unsigned z,unsigned a,int x,int y,unsigned epoch){(void)s;(void)e;(void)o;(void)i;(void)c;(void)n;(void)z;(void)a;(void)x;(void)y;(void)epoch;return 0;}
static inline int motion_hw_poll(void){return 1;}
static inline void motion_hw_commit(MotionHwOutput *output){(void)output;}
static inline unsigned motion_hw_active(void){return 0;}
static inline unsigned motion_hw_last_epoch(void){return 0;}
static inline int motion_hw_try(void *s,void *e,uint8_t *o,void *i,unsigned *c,
                               unsigned n,unsigned z,unsigned a,int x,int y,
                               MotionHwOutput *r){
    (void)s;(void)e;(void)o;(void)i;(void)c;(void)n;(void)z;(void)a;(void)x;(void)y;(void)r;
    return 0;
}
#endif
