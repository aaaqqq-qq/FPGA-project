#include "pipe5_control.h"
#include "remote_input.h"
#include <string.h>
typedef struct {uint64_t received;unsigned held,pressed;} RxEvent;
static RxEvent events[PIPE5_INPUT_EVENTS];
static unsigned head,count,overflows,sampled_held,epoch,hz;
static uint64_t due,last_valid,last_received;
static unsigned period,remainder,phase;
static char cli_commands[PIPE5_CLI_EVENTS][PIPE5_CLI_BYTES];
static unsigned cli_head,cli_count;
static void advance(void){due+=period;phase+=remainder;if(phase>=60){++due;phase-=60;}}
void pipe5_input_reset(uint64_t origin,unsigned timer_hz,unsigned held,unsigned immediate){
    head=count=overflows=epoch=phase=0;sampled_held=held;hz=timer_hz?timer_hz:1;
    period=hz/60;remainder=hz%60;due=last_valid=last_received=origin;
    if(!immediate)advance();
}
int pipe5_input_record(uint64_t received,unsigned held,unsigned pressed){
    if(received<last_received||count==PIPE5_INPUT_EVENTS){++overflows;return 0;}
    unsigned i=(head+count)%PIPE5_INPUT_EVENTS;events[i]=(RxEvent){received,held,pressed};
    ++count;last_received=received;return 1;
}
int pipe5_input_due(uint64_t now){return now>=due;}
unsigned pipe5_input_backlog(uint64_t now){
    if(now<due)return 0;
    uint64_t n=(now-due)*60u/hz+1u;
    /* Rational deadlines carry phase: the cheap quotient can be one early.
       Correct against the exact same integer sequence used by advance(). */
    while(due+n*period+(phase+n*remainder)/60u<=now)++n;
    while(n>1&&due+(n-1u)*period+(phase+(n-1u)*remainder)/60u>now)--n;
    return n>0xffffffffu?0xffffffffu:(unsigned)n;
}
int pipe5_input_take(uint64_t now,Pipe5Input *s){
    if(!s||now<due)return 0;
    unsigned bombs=0,controls=0;
    while(count&&events[head].received<=due){
        RxEvent e=events[head];head=(head+1)%PIPE5_INPUT_EVENTS;--count;
        sampled_held=e.held;last_valid=e.received;
        if(e.pressed&REMOTE_BOMB){if(bombs==255){++overflows;return -1;}++bombs;}
        controls|=e.pressed&(REMOTE_MENU|REMOTE_START|REMOTE_PAUSE);
    }
    if(due-last_valid>=(uint64_t)REMOTE_HOLD_TIMEOUT_US*hz/1000000u)sampled_held=0;
    *s=(Pipe5Input){due,++epoch,sampled_held&15u,bombs,controls};advance();return 1;
}
unsigned pipe5_input_overflows(void){return overflows;}
int pipe5_cli_push(const char *s){
    size_t n=strlen(s);if(n>=PIPE5_CLI_BYTES||cli_count==PIPE5_CLI_EVENTS){++overflows;return 0;}
    memcpy(cli_commands[(cli_head+cli_count)%PIPE5_CLI_EVENTS],s,n+1);++cli_count;return 1;
}
int pipe5_cli_pop(char *s,unsigned bytes){
    if(!cli_count)return 0;size_t n=strlen(cli_commands[cli_head]);if(n+1>bytes)return -1;
    memcpy(s,cli_commands[cli_head],n+1);cli_head=(cli_head+1)%PIPE5_CLI_EVENTS;--cli_count;return 1;
}
void pipe5_cli_clear(void){cli_head=cli_count=0;}
