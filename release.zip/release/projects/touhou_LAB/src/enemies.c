#include "enemies.h"
#include "stage.h"
#include "battle.h"
#include "game_config.h"
#include "effects.h"
#include "scene.h"
#include <string.h>

OrdinaryEnemy ordinary_enemies[ENEMY_CAPACITY];
unsigned enemies_kills,enemies_spawns,enemies_despawns;
unsigned enemies_requested,enemies_spawned,enemies_rejected,enemies_volleys_deferred;
unsigned enemies_bullets_cleared,enemies_config_rejections;
static unsigned configured,last_tick,seed,seed_ready,stopped;

static int absolute(int x){return x<0?-x:x;}
static int visible(const OrdinaryEnemy *e){return e->hp>0&&e->state!=ENEMY_WAIT&&e->y>=0&&e->y<ARENA_H;}
static void clear_owned(unsigned i){enemies_bullets_cleared+=battle_clear_owner(ENEMY_OWNER_BASE+i);}
static void wait_again(unsigned i,unsigned delay){
    OrdinaryEnemy *e=&ordinary_enemies[i];clear_owned(i);e->state=ENEMY_WAIT;e->hp=0;e->age=0;e->next_spawn=last_tick+delay;e->grazed=e->hit_flash=0;
}
void enemies_reset(unsigned count){
    for(unsigned i=0;i<ENEMY_CAPACITY;++i)battle_clear_owner(ENEMY_OWNER_BASE+i);
    memset(ordinary_enemies,0,sizeof(ordinary_enemies));
    enemies_kills=enemies_spawns=enemies_despawns=0;
    enemies_requested=enemies_spawned=enemies_rejected=enemies_volleys_deferred=0;
    enemies_bullets_cleared=0;enemies_config_rejections=count>ENEMY_CAPACITY;
    configured=count>ENEMY_CAPACITY?ENEMY_CAPACITY:count;last_tick=seed=seed_ready=stopped=0;
    for(unsigned i=0;i<configured;++i){ordinary_enemies[i].state=ENEMY_WAIT;ordinary_enemies[i].next_spawn=i*18;}
}
unsigned enemies_configured_count(void){return configured;}
unsigned enemies_active_count(void){unsigned n=0;for(unsigned i=0;i<configured;++i)n+=ordinary_enemies[i].state!=ENEMY_WAIT;return n;}
static void spawn(unsigned i){
    OrdinaryEnemy *e=&ordinary_enemies[i];unsigned generation=e->generation+1;
    memset(e,0,sizeof(*e));e->generation=generation;e->state=ENEMY_ENTER;
    e->anchor_x=72+(int)((i*173u+(seed&127u)+generation*41u)%880u);
    e->anchor_y=104+(int)(i%3)*52;e->x=e->anchor_x;e->y=-16;
    e->hp=e->max_hp=20+(int)(i%3)*10;e->fire_wait=36+(i*13)%54;++enemies_spawns;
}
void enemies_tick(unsigned tick,int px,int py){
    if(!configured||stopped)return;last_tick=tick;
    if(!seed_ready){seed=stage.seed^0x66616972u;seed_ready=1;}
    for(unsigned i=0;i<configured;++i){
        OrdinaryEnemy *e=&ordinary_enemies[i];
        if(e->state==ENEMY_WAIT){if((int32_t)(tick-e->next_spawn)>=0)spawn(i);continue;}
        if(e->hit_flash)--e->hit_flash;++e->age;
        if(e->state==ENEMY_ENTER){
            e->y=-16+(e->anchor_y+16)*(int)e->age/48;
            if(e->age>=48){e->state=ENEMY_ACTIVE;e->age=0;}
        }else if(e->state==ENEMY_ACTIVE){
            unsigned phase=(e->age*181u+i*7001u+(seed&65535u))&65535u;
            e->x=e->anchor_x+turn_sin((int)phase)*48/32768;
            e->y=e->anchor_y+turn_sin((int)(phase*2u))*16/32768;
            if(e->x<24)e->x=24;if(e->x>ARENA_W-24)e->x=ARENA_W-24;
            if(e->fire_wait)--e->fire_wait;
            if(e->age>=480){if(battle_load_active){e->age=0;++battle_load_keeps;}else{e->state=ENEMY_EXIT;e->age=0;}}
        }else{
            e->y+=4;
            if(e->y>ARENA_H+16){++enemies_despawns;wait_again(i,120+(i%4)*18);continue;}
        }
        if(visible(e)&&player_alive()){
            int dx=absolute(px-e->x),dy=absolute(py-e->y);
            if(!e->grazed&&dx<28&&dy<28&&(dx>13||dy>15)){
                e->grazed=1;++player.graze;player_add_score(game_cfg.graze_score);fx_graze(px,py);
            }
        }
    }
    /* Two three-shot volleys per logic tick, round-robin across all slots. */
    unsigned budget=6;
    for(unsigned j=0;j<configured;++j){
        unsigned i=(tick+j)%configured;OrdinaryEnemy *e=&ordinary_enemies[i];
        if(e->state!=ENEMY_ACTIVE||e->fire_wait)continue;
        if(budget<3||(game_cfg.adaptive_density&&battle_density_slow)){
            e->fire_wait=1;++enemies_volleys_deferred;continue;
        }
        int aim=turn_atan(px-e->x,py-e->y);budget-=3;
        for(int lane=-1;lane<=1;++lane){
            ++enemies_requested;
            int ok=battle_spawn_enemy_bullet(ENEMY_OWNER_BASE+i,e->x,e->y,(aim+lane*1300)&65535,
                (2*Q)+(int)(i%3)*(Q/4),54+(i%8));
            if(ok)++enemies_spawned;else ++enemies_rejected;
        }
        e->fire_wait=90+(i%3)*12;
    }
}
unsigned enemies_apply_damage(unsigned i,unsigned amount){
    if(i>=configured||!amount||stopped)return 0;OrdinaryEnemy *e=&ordinary_enemies[i];
    if(!visible(e))return 0;if(battle_load_active){++battle_load_mob_hits;if((unsigned)e->hp<=amount){e->hp=e->max_hp;++battle_load_keeps;}}unsigned actual=amount>(unsigned)e->hp?(unsigned)e->hp:amount;
    e->hp-=(int)actual;e->hit_flash=6;player_add_score(actual*game_cfg.damage_score);
    if(!e->hp){++enemies_kills;player_add_score(ENEMY_KILL_SCORE);fx_cancel_star(e->x,e->y);wait_again(i,180+(i%4)*18);}
    return actual;
}
int enemies_hit_shot(PlayerShot *s){
    if(!s||!s->live||!player_alive())return 0;
    for(unsigned i=0;i<configured;++i){OrdinaryEnemy *e=&ordinary_enemies[i];
        if(visible(e)&&absolute(s->x-e->x)<14&&absolute(s->y-e->y)<16&&enemies_apply_damage(i,game_cfg.player_shot_damage)){
            s->live=0;return 1;
        }
    }return 0;
}
int enemies_contact_hit(int px,int py){
    for(unsigned i=0;i<configured;++i){const OrdinaryEnemy *e=&ordinary_enemies[i];
        if(visible(e)&&absolute(px-e->x)<13&&absolute(py-e->y)<15)return 1;
    }return 0;
}
unsigned enemies_bomb(unsigned damage){unsigned total=0;for(unsigned i=0;i<configured;++i)total+=enemies_apply_damage(i,damage);return total;}
void enemies_clear_all(void){
    for(unsigned i=0;i<configured;++i){clear_owned(i);ordinary_enemies[i].state=ENEMY_WAIT;ordinary_enemies[i].hp=0;}
    stopped=1;
}
void enemies_render(void){
    for(unsigned i=0;i<configured;++i){const OrdinaryEnemy *e=&ordinary_enemies[i];if(e->state==ENEMY_WAIT)continue;
        scene_layer(SCENE_LAYER_ACTOR,game_cfg.layer_y_sort?e->y+15:0);
        unsigned base=i&1?ENEMY_PINK_TILE_BASE:ENEMY_BLUE_TILE_BASE;
        scene_tile(32+e->x-15,16+e->y-15,base+((last_tick/8+i)&3u),e->hit_flash?255:240);
        if(e->y>=0&&e->y+19<ARENA_H&&(e->state==ENEMY_ACTIVE||e->hit_flash)){
            scene_rect(32+e->x-12,16+e->y+17,24,2,0x28273bu);
            unsigned w=e->max_hp?(unsigned)e->hp*24/(unsigned)e->max_hp:0;
            if(w)scene_rect(32+e->x-12,16+e->y+17,(int)w,2,i&1?0xf39ac6u:0x7bd8edu);
        }
    }
}
static uint32_t hash_word(uint32_t h,uint32_t v){for(unsigned b=0;b<4;++b){h=(h^(v&255u))*16777619u;v>>=8;}return h;}
uint32_t enemies_state_hash(uint32_t h){
    unsigned values[]={configured,last_tick,seed,seed_ready,stopped,enemies_kills,enemies_spawns,enemies_despawns,enemies_requested,enemies_spawned,enemies_rejected,enemies_volleys_deferred,enemies_bullets_cleared,enemies_config_rejections};
    for(unsigned i=0;i<sizeof(values)/sizeof(values[0]);++i)h=hash_word(h,values[i]);
    for(unsigned i=0;i<configured;++i){const OrdinaryEnemy *e=&ordinary_enemies[i];
        uint32_t fields[]={(uint32_t)e->x,(uint32_t)e->y,(uint32_t)e->hp,(uint32_t)e->max_hp,(uint32_t)e->anchor_x,(uint32_t)e->anchor_y,e->state,e->age,e->next_spawn,e->generation,e->fire_wait,e->grazed,e->hit_flash};
        for(unsigned j=0;j<sizeof(fields)/sizeof(fields[0]);++j)h=hash_word(h,fields[j]);
    }return h;
}

void enemies_load_begin(void){
    seed=stage.seed^0x66616972u;seed_ready=1;stopped=0;
    for(unsigned i=0;i<configured;++i){spawn(i);OrdinaryEnemy *e=&ordinary_enemies[i];e->state=ENEMY_ACTIVE;e->x=e->anchor_x;e->y=e->anchor_y;e->age=0;}
}
unsigned enemies_fighting_count(void){unsigned n=0;for(unsigned i=0;i<configured;++i)n+=visible(&ordinary_enemies[i])&&ordinary_enemies[i].state==ENEMY_ACTIVE;return n;}
