#ifndef RENDER_QUEUE_H
#define RENDER_QUEUE_H
#include <stdint.h>
#define RQ_CAPACITY 384u
#define RQ_TEXT_BYTES 4096u
#define RQ_LAYER_COUNT 8u
enum { RQ_TILE=0, RQ_RECT=1, RQ_TEXT=2 };
enum { RQ_OK=0, RQ_E_CAPACITY=-1, RQ_E_TEXT=-2, RQ_E_ARGUMENT=-3 };
typedef struct {
    int32_t x,y,w,h,depth;
    uint32_t color;
    uint16_t tile,text_at,scale;
    int16_t left,top,right,bottom;
    uint8_t kind,layer,alpha,reserved;
} RqCommand;
typedef void (*RqPrepare)(RqCommand *command,const char *text,void *context);
/* Sort/prepare immutable captured commands before the output engine is free. */
void rq_prepare(RqPrepare prepare,void *context);
typedef void (*RqSink)(const RqCommand *command,const char *text,void *context);
void rq_reset(void);
int rq_set_order(const unsigned ranks[RQ_LAYER_COUNT]);
int rq_push(const RqCommand *command,const char *text);
void rq_flush(RqSink sink,void *context);
unsigned rq_count(void);
extern unsigned rq_total,rq_peak,rq_reordered;
#endif
