#pragma once
#include <stdint.h>
#define PIPE5_INPUT_EVENTS 128u
#define PIPE5_CLI_EVENTS 8u
#define PIPE5_CLI_BYTES 640u
typedef struct {uint64_t deadline;unsigned epoch,keys,bombs,controls;} Pipe5Input;
void pipe5_input_reset(uint64_t origin,unsigned timer_hz,unsigned held,unsigned immediate);
int pipe5_input_record(uint64_t received,unsigned held,unsigned pressed);
int pipe5_input_due(uint64_t now);
int pipe5_input_take(uint64_t now,Pipe5Input *sample);
unsigned pipe5_input_backlog(uint64_t now);
unsigned pipe5_input_overflows(void);
int pipe5_cli_push(const char *command);
int pipe5_cli_pop(char *command,unsigned bytes);
void pipe5_cli_clear(void);
