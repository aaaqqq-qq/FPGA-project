#include "bitblt.h"
#include "segment_diag.h"
#ifndef BB_HOST_TEST
#include "bsp.h"
#include "vexriscv.h"

static void barrier(void) { __asm__ volatile("fence iorw, iorw" ::: "memory"); }
uint32_t bb_read(unsigned reg) {
    return *(volatile uint32_t *)(uintptr_t)(BB_BASE + reg);
}
void bb_write(unsigned reg, uint32_t value) {
    *(volatile uint32_t *)(uintptr_t)(BB_BASE + reg) = value;
}
uint64_t bb_ticks(void) { return clint_getTime(BSP_CLINT); }
uint32_t bb_us(uint64_t ticks) { return (uint32_t)(ticks / (BSP_CLINT_HZ / 1000000u)); }

#else
static void barrier(void) { }
#endif

bb_result bb_probe(void) {
    uint64_t start = bb_ticks();
    if (bb_read(BB_ID) != BB_ID_VALUE) return BB_E_ID;
    while (!(bb_read(BB_DISPLAY_STATUS) & BB_CAL_DONE)) {
        if (bb_us(bb_ticks() - start) >= 5000000u) return BB_E_TIMEOUT;
    }
    return BB_OK;
}

static int no_work(const bb_job *j) {
    return !j->width || !j->height ||
        (j->op == BB_COPY_OP && j->src == j->dst &&
         j->src_stride == j->dst_stride && !j->flags);
}
static unsigned software_nop;

#ifndef BB_HOST_TEST
bb_result bb_publish(void) {
    uint64_t sd_begin=segment_diag_nested_begin();
    /* This generated CPU has no CSR 0x810 and uses write-through DCache.
       Force an actual DDR read: its AXI bridge forbids W->R transition while
       previous write responses are pending. A fence alone is not the drain. */
    barrier();
    /* Invalidate the drain address's one cache index.  This generated CPU
       decodes nonzero rs1 as a single-line invalidation; keeping this read a
       miss preserves the existing DDR write-response drain without evicting
       the other 63 write-through cache lines.  bb_acquire still invalidates all. */
    uintptr_t drain_address = (uintptr_t)BB_DRAIN_WORD;
    __asm__ volatile(".word ((0x500f) | (regnum_%0 << 15))"
                     :: "r"(drain_address) : "memory");
    uint32_t observed = *(const volatile uint32_t *)(uintptr_t)BB_DRAIN_WORD;
    __asm__ volatile("" :: "r"(observed) : "memory");
    barrier();
    segment_diag_nested_end(SD_PUBLISH,sd_begin);
    return BB_OK;
}
void bb_acquire(void) {
    uint64_t sd_begin=segment_diag_nested_begin();
    barrier();
    /* BSP data_cache_invalidate_all instruction, made volatile with a clobber. */
    __asm__ volatile(".word 0x500f" ::: "memory");
    barrier();
    segment_diag_nested_end(SD_ACQUIRE,sd_begin);
}
#endif

bb_result bb_submit(const bb_job *j) {
    bb_result r = bb_validate(j);
    if (r != BB_OK) return r;
    if (bb_read(BB_STATUS) & BB_BUSY) return BB_E_BUSY;
    software_nop = 0;
    if (no_work(j)) { software_nop = 1; return BB_OK; }
    r = bb_publish();
    if (r != BB_OK) return r;
    bb_write(BB_STATUS, BB_DONE | BB_ERROR);
    bb_write(BB_OP, j->op); bb_write(BB_SRC, j->src); bb_write(BB_DST, j->dst);
    bb_write(BB_SRC_STRIDE, j->src_stride); bb_write(BB_DST_STRIDE, j->dst_stride);
    bb_write(BB_WIDTH, j->width); bb_write(BB_HEIGHT, j->height);
    bb_write(BB_FILL, j->fill); bb_write(BB_ALPHA, j->alpha);
    bb_write(BB_KEY_REG, j->key); bb_write(BB_FLAGS, j->flags);
    barrier();
    bb_write(BB_CMD, 1u);
    return BB_OK;
}

bb_result bb_wait(uint32_t timeout_us, bb_metrics *m) {
    if (software_nop) {
        software_nop = 0;
        if (m) { m->cycles = 0; m->read_bytes = 0; m->write_bytes = 0; }
        return BB_OK;
    }
    uint64_t start = bb_ticks();
    for (;;) {
        uint32_t status = bb_read(BB_STATUS);
        if (status & BB_ERROR) return BB_E_HARDWARE;
        if (!(status & BB_BUSY) && (status & BB_DONE)) {
            barrier(); /* RTL DONE is after every AXI B response, not after W. */
            if (m) {
                m->cycles = bb_read(BB_CYCLES);
                m->read_bytes = bb_read(BB_READ_BYTES);
                m->write_bytes = bb_read(BB_WRITE_BYTES);
            }
            return BB_OK;
        }
        if (bb_us(bb_ticks() - start) >= timeout_us) return BB_E_TIMEOUT;
    }
}
bb_result bb_execute(const bb_job *j, bb_metrics *m) {
    bb_result r = bb_submit(j);
    if (r != BB_OK) return r;
    return bb_wait(2000000u, m);
}

__attribute__((weak)) int bb_cpu_service(void){return 0;}

bb_result bb_cpu_execute(const bb_job *j) {
    bb_result r = bb_validate(j);
    if (r != BB_OK || no_work(j)) return r;
    if (bb_read(BB_STATUS) & BB_BUSY) return BB_E_BUSY;
    /* Acquire once before a CPU batch when preceding DMA may have changed DDR. */
    for (uint32_t y = 0; y < j->height; ++y) {
        if(!(y&3u) && bb_cpu_service())return BB_E_CANCELLED;
        volatile uint32_t *d = (volatile uint32_t *)(uintptr_t)(j->dst + y * j->dst_stride);
        const volatile uint32_t *s = (const volatile uint32_t *)(uintptr_t)(j->src + y * j->src_stride);
        for (uint32_t x = 0; x < j->width; ++x) {
            uint32_t pixel = j->op == BB_FILL_OP ? j->fill : s[x];
            if (j->op == BB_COPY_OP && (j->flags & BB_KEY_ENABLE) &&
                (pixel & 0xffffffu) == (j->key & 0xffffffu)) continue;
            if ((j->flags & BB_ALPHA_ENABLE) && !j->alpha) continue;
            d[x] = (j->flags & BB_ALPHA_ENABLE) ? bb_blend(pixel, d[x], j->alpha) : pixel;
        }
    }
    return BB_OK;
}

bb_result bb_swap_wait(uint32_t framebuffer, uint32_t timeout_us) {
    uint64_t start;
    uint32_t before;
    bb_result r;
    if ((framebuffer & 4095u) || framebuffer < 0x00100000u ||
        (uint64_t)framebuffer + BB_FRAME_BYTES > BB_DDR_END) return BB_E_RANGE;
    if ((bb_read(BB_STATUS) & BB_BUSY) ||
        (bb_read(BB_DISPLAY_STATUS) & BB_SWAP_PENDING)) return BB_E_BUSY;
    r = bb_publish();
    if (r != BB_OK) return r;
    before = bb_read(BB_SWAPS);
    bb_write(BB_NEXT_FRONT, framebuffer);
    barrier();
    bb_write(BB_SWAP, 1u);
    start = bb_ticks();
    while ((bb_read(BB_DISPLAY_STATUS) & BB_SWAP_PENDING) ||
           bb_read(BB_SWAPS) == before || bb_read(BB_FRONT) != framebuffer) {
        if (bb_us(bb_ticks() - start) >= timeout_us) return BB_E_TIMEOUT;
    }
    barrier();
    return BB_OK;
}

bb_result bb_wait_frame_after(uint32_t frame, uint32_t timeout_us) {
    uint64_t start = bb_ticks();
    while (bb_read(BB_FRAMES) == frame) {
        if (bb_us(bb_ticks() - start) >= timeout_us) return BB_E_TIMEOUT;
    }
    barrier();
    return BB_OK;
}

const char *bb_error_string(bb_result r) {
    switch (r) {
    case BB_OK: return "OK";
    case BB_E_ARGUMENT: return "invalid argument";
    case BB_E_RANGE: return "DDR/alignment/stride range";
    case BB_E_OVERLAP: return "overlapping DMA ranges";
    case BB_E_BUSY: return "engine or swap pending";
    case BB_E_TIMEOUT: return "hardware timeout";
    case BB_E_ID: return "BitBlt ID not found: load integrated FPGA image";
    default: return "AXI/engine error";
    }
}
