#include "player.h"
#include "enemies.h"
#include "stage.h"
#include "battle.h"
#include "game_config.h"
#include "arena.h"
#include <string.h>

PlayerState player;
PlayerShot player_shots[PLAYER_SHOT_CAPACITY];
unsigned player_homing_retargets;

static int abs_i(int x) { return x < 0 ? -x : x; }

static unsigned isqrt(unsigned x) {
    unsigned r = 0, b = 1u << 30;
    while (b > x) b >>= 2;
    while (b) {
        if (x >= r + b) { x -= r + b; r = (r >> 1) + b; }
        else r >>= 1;
        b >>= 2;
    }
    return r;
}

void player_reset(int x, int y) {
    memset(&player, 0, sizeof(player));
    memset(player_shots, 0, sizeof(player_shots));
    player_homing_retargets=0;
    player.x = x; player.y = y;
    player.max_hp = (int)game_cfg.player_max_hp;
    player.hp = player.max_hp;
    player.hp_display = (unsigned)player.max_hp;
    player.lives = 3;
    player.bombs = 3;
    player.power_level = 1;
    player.alive = 1;
    player.spawn_invuln = game_cfg.spawn_invuln_ticks;
    player.level_events = 1;
}

unsigned player_alive(void) { return player.alive && player.hp > 0; }

unsigned player_level_for_score(unsigned score) {
    unsigned level = 1;
    unsigned max = game_cfg.max_level;
    if (max > 5) max = 5;
    for (unsigned i = 2; i <= max; ++i) {
        if (score >= game_cfg.level_threshold[i]) level = i;
    }
    return level;
}

void player_add_score(unsigned points) {
    unsigned next = player.score + points;
    if (next < player.score) next = 0xffffffffu; /* saturate, never wrap */
    player.score = next;
}

int player_update_level(void) {
    if (!player_alive()) return 0;
    unsigned target = player_level_for_score(player.score);
    if (target <= player.power_level) return 0;
    player.power_level = target;
    player.upgrade_anim = game_cfg.upgrade_ticks;
    if (game_cfg.upgrade_invuln_ticks > player.upgrade_invuln)
        player.upgrade_invuln = game_cfg.upgrade_invuln_ticks;
    ++player.upgrades;
    ++player.level_events;
    return 1;
}

unsigned player_can_be_hit(unsigned demo_invincible) {
    if (!player_alive() || demo_invincible) return 0;
    return !(player.spawn_invuln || player.hit_invuln ||
             player.bomb_invuln || player.upgrade_invuln);
}

int player_take_hit(int damage) {
    if (damage <= 0 || !player_alive()) return 0;
    if (!player_can_be_hit(0)) return 0;
    if(battle_load_active){
        if(player.hp<=damage){player.hp=player.max_hp;++battle_load_keeps;}
        ++battle_load_player_hits;
    }
    if (damage > player.hp) damage = player.hp;
    if(battle_load_active)battle_load_player_damage+=(unsigned)damage;
    player.hp -= damage;
    player.regen_wait = game_cfg.regen_wait_ticks;
    player.regen_accum = 0;
    if (game_cfg.hit_invuln_ticks > player.hit_invuln)
        player.hit_invuln = game_cfg.hit_invuln_ticks;
    player.hit_flash = 6;
    player.hp_delay = game_cfg.hp_delay_ticks;
    if (player.hp <= 0) {
        player.hp = 0;
        player.alive = 0;
    }
    return damage;
}

void player_begin_tick(void) {
    if (player.spawn_invuln) --player.spawn_invuln;
    if (player.hit_invuln) --player.hit_invuln;
    if (player.bomb_invuln) --player.bomb_invuln;
    if (player.upgrade_invuln) --player.upgrade_invuln;
    if (player.upgrade_anim) --player.upgrade_anim;
    if (player.hit_flash) --player.hit_flash;

    if (!player_alive()) {
        player.regen_wait = 0;
        player.regen_accum = 0;
    } else if (player.regen_wait) {
        if (--player.regen_wait == 0) player.regen_accum = game_cfg.regen_period_ticks;
        else player.regen_accum = 0;
    } else if (player.regen_accum < game_cfg.regen_period_ticks) {
        ++player.regen_accum;
    }

    if (player.hp_display > (unsigned)player.hp) {
        if (player.hp_delay) --player.hp_delay;
        else {
            unsigned drop = game_cfg.hp_drop_rate ? game_cfg.hp_drop_rate : 1;
            if (player.hp_display - player.hp <= drop) player.hp_display = (unsigned)player.hp;
            else player.hp_display -= drop;
        }
    } else if (player.hp_display < (unsigned)player.hp) {
        unsigned rise = game_cfg.hp_drop_rate ? game_cfg.hp_drop_rate : 1;
        if ((unsigned)player.hp - player.hp_display <= rise) player.hp_display = (unsigned)player.hp;
        else player.hp_display += rise;
    }
}

void player_regen_tick(void) {
    if (!player_alive() || player.regen_wait) return;
    if (player.regen_accum < game_cfg.regen_period_ticks) return;
    player.regen_accum -= game_cfg.regen_period_ticks;
    if (player.hp >= player.max_hp) return;
    unsigned next = (unsigned)player.hp + game_cfg.regen_amount;
    player.hp = next >= (unsigned)player.max_hp ? player.max_hp : (int)next;
}

static int spawn_player_shot(int angle, int speed, unsigned kind, int ox, int oy) {
    unsigned cap = game_cfg.player_shot_cap;
    if (cap > PLAYER_SHOT_CAPACITY) cap = PLAYER_SHOT_CAPACITY;
    for (unsigned i = 0; i < cap; ++i) if (!player_shots[i].live) {
        int a = angle * 65536 / 360;
        PlayerShot *s = &player_shots[i];
        s->x = player.x + ox; s->y = player.y + oy;
        s->vx = turn_cos(a) * speed / 128;
        s->vy = turn_sin(a) * speed / 128;
        s->live = 1; s->kind = kind; s->age = 0;
        s->target=-1;s->retarget_wait=0;s->target_valid=0;
        s->fx = s->x * 256; s->fy = s->y * 256;
        return 1;
    }
    ++player.shot_rejections;
    return 0;
}

void player_fire_tick(unsigned tick) {
    if (!player_alive()) return;
    unsigned level = player.power_level;
    if (level > 5) level = 5;
    unsigned main = game_cfg.level_main[level];
    unsigned homing = game_cfg.level_homing[level];
    if (main > 7) main = 7;
    if (homing > 4) homing = 4;
    unsigned main_period = game_cfg.main_fire_period ? game_cfg.main_fire_period : 5;
    unsigned homing_period = game_cfg.homing_fire_period ? game_cfg.homing_fire_period : 15;

    if (tick % main_period == 0) {
        int spacing = main >= 7 ? 20 : 14;
        for (unsigned i = 0; i < main; ++i) {
            int slot = (int)i - (int)(main - 1) / 2;
            int an = -90 + slot * spacing;
            spawn_player_shot(an, (int)game_cfg.player_shot_speed, PLAYER_KIND_MAIN, 0, -20);
        }
    }
    if (homing && tick % homing_period == 0) {
        for (unsigned i = 0; i < homing; ++i) {
            int slot = (int)i - (int)(homing - 1) / 2;
            int an = -90 + slot * 18;
            spawn_player_shot(an, (int)game_cfg.homing_shot_speed, PLAYER_KIND_HOMING, 0, -18);
        }
    }
}

void player_shots_reset(void) { memset(player_shots, 0, sizeof(player_shots));player_homing_retargets=0; }

void player_shots_tick(void) {
    unsigned cap = game_cfg.player_shot_cap;
    if (cap > PLAYER_SHOT_CAPACITY) cap = PLAYER_SHOT_CAPACITY;
    for (unsigned i = 0; i < cap; ++i) if (player_shots[i].live) {
        PlayerShot *s = &player_shots[i];
        if(s->kind==PLAYER_KIND_HOMING&&s->age<40){
            unsigned valid=s->target_valid&&s->target>=0&&s->target<(int)MAX_BOSSES&&battle_targetable((unsigned)s->target);
            unsigned refresh=!valid||!s->retarget_wait||battle_legacy_mode();
            if(refresh){
            ++player_homing_retargets;
            unsigned period=game_cfg.homing_retarget_ticks?game_cfg.homing_retarget_ticks:1;
            if(battle_legacy_mode())period=1;
            s->retarget_wait=period-1;
            int nearest = -1, dist = 0x7fffffff;
            for (unsigned k = 0; k < game_cfg.boss_count && k < MAX_BOSSES; ++k) {
                if (!battle_targetable(k)) continue;
                int d = abs_i(s->x - bosses[k].x) + abs_i(s->y - bosses[k].y);
                if (d < dist) { dist = d; nearest = (int)k; }
            }
            s->target=nearest;s->target_valid=nearest>=0;
            if (nearest >= 0) {
                int dx = bosses[nearest].x - s->x, dy = bosses[nearest].y - s->y;
                unsigned distance = isqrt((unsigned)(dx * dx + dy * dy));
                unsigned speed = isqrt((unsigned)(s->vx * s->vx + s->vy * s->vy));
                if (distance) {
                    s->vx += dx * (int)speed / (int)(4 * distance);
                    s->vy += dy * (int)speed / (int)(4 * distance);
                    unsigned length = isqrt((unsigned)(s->vx * s->vx + s->vy * s->vy));
                    if (length > 15 * 256) {
                        s->vx = s->vx * 15 * 256 / (int)length;
                        s->vy = s->vy * 15 * 256 / (int)length;
                    }
                }
            }
            }else --s->retarget_wait;
        }
        s->fx += s->vx; s->fy += s->vy;
        s->x = s->fx / 256; s->y = s->fy / 256;
        ++s->age;
        if (s->age >= game_cfg.player_shot_life ||
            s->x < 4 || s->x > ARENA_W - 4 || s->y < 4 || s->y > ARENA_H - 4) {
            s->live = 0;
            continue;
        }
        if(enemies_hit_shot(s))continue;
        for (unsigned k = 0; k < game_cfg.boss_count && k < MAX_BOSSES; ++k) {
            if (!battle_can_damage(k)) continue;
            if (abs_i(s->x - bosses[k].x) < 20 && abs_i(s->y - bosses[k].y) < 24) {
                s->live = 0;
                battle_apply_damage(k, (int)game_cfg.player_shot_damage, 1);
                break;
            }
        }
    }
}
