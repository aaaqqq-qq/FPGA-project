#ifndef TI60_PIPE5_ABI_H
#define TI60_PIPE5_ABI_H
#include <stdint.h>
/* PIPE5 frozen interface v2. Legacy0x00..0x9c retain their C2 meanings.
   Epochs are nonzero opaque tokens, unique since the previous accepted job of
   the same context. Active tokens/job pointers are latched at accepted CMD.
   R_CMD only accepts OP2 field (includingN0). M Job/Completion ABI stays v1;
   a new M command enforces Job.epoch==accepted M_EPOCH before any AW. */
#define PIPE5_CAP_CONCURRENT_EPOCH UINT32_C(32)
#define PIPE5_CAP_PREFLIGHT8 UINT32_C(64)
#define PIPE5_CAPS UINT32_C(126) /* C2cap30 |32 |64 */
#define PIPE5_FLAG_PREFLIGHT8 UINT32_C(16)
enum {
 PIPE5_R_CMD=0xa0, PIPE5_R_STATUS=0xa4, PIPE5_R_EPOCH=0xa8,
 PIPE5_R_DONE_EPOCH=0xac, PIPE5_R_SNAP_EPOCH=0xb0,
 PIPE5_R_CYCLES=0xb4, PIPE5_R_READ_BYTES=0xb8, PIPE5_R_WRITE_BYTES=0xbc,
 PIPE5_M_CMD=0xc0, PIPE5_M_STATUS=0xc4, PIPE5_M_EPOCH=0xc8,
 PIPE5_M_DONE_EPOCH=0xcc, PIPE5_M_JOB=0xd0,
 PIPE5_M_CYCLES=0xd4, PIPE5_M_READ_BYTES=0xd8, PIPE5_M_WRITE_BYTES=0xdc,
 PIPE5_R_SNAP_STATUS=0xe0, PIPE5_FAULT=0xe4
};
enum {PIPE5_START=1,PIPE5_FALLBACK_DONE=2,PIPE5_BUSY=1,PIPE5_DONE=2,PIPE5_ERROR=4,PIPE5_FALLBACK_PENDING=8};
enum {PIPE5_SNAP_DECIDED=1,PIPE5_SNAP_NO_DRAW=2,PIPE5_SNAP_READY=4};
enum {PIPE5_FAULT_R=1,PIPE5_FAULT_M=2,PIPE5_FAULT_AXI=4};
#endif
