#include "remote_input.h"
#include <string.h>

void remote_input_init(RemoteInput *r){memset(r,0,sizeof(*r));}
void remote_input_expire(RemoteInput *r,uint32_t now){
    if(r->position&&(uint32_t)(now-r->partial_since_us)>=REMOTE_PACKET_TIMEOUT_US)
        r->position=0;
    if(r->have_sequence&&(uint32_t)(now-r->last_valid_us)>=REMOTE_HOLD_TIMEOUT_US){
        r->held=r->pressed=0;r->have_sequence=0;++r->timeouts;
    }
}
unsigned remote_input_pressed(RemoteInput *r){unsigned p=r->pressed;r->pressed=0;return p;}
int remote_input_feed(RemoteInput *r,uint8_t byte,uint32_t now){
    unsigned was_partial=r->position;
    remote_input_expire(r,now);
    /* Expired fragment bytes cannot become ASCII control text. */
    if(was_partial&&!r->position&&byte!=0xa5)return 1;
    if(!r->position){
        if(byte!=0xa5)return 0;
        r->position=1;r->partial_since_us=now;return 1;
    }
    if(r->position==1){
        if(byte==0x5a)r->position=2;
        else if(byte==0xa5)r->partial_since_us=now;
        else {r->position=0;++r->rejected;}
        return 1;
    }
    r->packet[r->position-2]=byte;
    if(++r->position<6)return 1;
    r->position=0;
    uint8_t seq=r->packet[0],lo=r->packet[1],hi=r->packet[2];
    if(hi||r->packet[3]!=(uint8_t)(seq^lo^hi^0xa7)){++r->rejected;return 1;}
    if(r->have_sequence){
        uint8_t delta=(uint8_t)(seq-r->sequence);
        if(!delta){
            if(r->held!=lo){++r->rejected;return 1;}
            r->last_valid_us=now;++r->duplicates;return 1;
        }
        if(delta>=128){++r->rejected;return 1;}
    }
    r->pressed|=(uint16_t)(lo&~r->held);r->held=lo;
    r->sequence=seq;r->have_sequence=1;r->last_valid_us=now;++r->accepted;
    return 1;
}
