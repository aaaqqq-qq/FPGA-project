#include "replay.h"
#include <string.h>
_Static_assert(sizeof(ReplayEvent)==8,"replay event ABI must be 8 bytes");

static ReplayHeader header;
static ReplayEvent records[REPLAY_CAPACITY];
static unsigned state,error,record_keys,play_keys,cursor;
static uint32_t next_tick;

static int fail(int code){if(error)return -(int)error;error=(unsigned)(-code);state=REPLAY_ERROR;return code;}
unsigned replay_state(void){return state;}
int replay_status(void){return -(int)error;}
const ReplayHeader *replay_header(void){return &header;}
const ReplayEvent *replay_events(void){return records;}
void replay_reset(void){memset(&header,0,sizeof(header));state=REPLAY_IDLE;error=0;record_keys=play_keys=cursor=0;next_tick=0;}
uint32_t replay_hash_u32(uint32_t h,uint32_t v){for(unsigned k=0;k<4;++k){h=(h^(v&255u))*16777619u;v>>=8;}return h;}
static uint32_t crc_word(uint32_t crc,uint32_t v){
    for(unsigned k=0;k<4;++k){crc^=v&255u;v>>=8;for(unsigned b=0;b<8;++b)crc=(crc>>1)^((0u-(crc&1u))&0xedb88320u);}
    return crc;
}
static uint32_t checksum(const ReplayHeader *h,const ReplayEvent *e){
    uint32_t c=0xffffffffu;
    c=crc_word(c,h->magic);c=crc_word(c,h->version);c=crc_word(c,h->seed);c=crc_word(c,h->config_hash);
    c=crc_word(c,h->event_count);c=crc_word(c,h->final_tick);c=crc_word(c,h->final_state_hash);
    for(unsigned i=0;i<h->event_count;++i){c=crc_word(c,e[i].tick);c=crc_word(c,(unsigned)e[i].keys|((unsigned)e[i].bombs<<8));}
    return c^0xffffffffu;
}
static int validate(const ReplayHeader *h,const ReplayEvent *e,uint32_t cfg){
    if(!h||!e||h->magic!=REPLAY_MAGIC||h->version!=REPLAY_VERSION||!h->event_count||h->event_count>REPLAY_CAPACITY||!h->final_tick)return REPLAY_E_HEADER;
    if(h->config_hash!=cfg)return REPLAY_E_CONFIG;
    for(unsigned i=0;i<h->event_count;++i){
        if(e[i].reserved||e[i].keys>15||e[i].tick>=h->final_tick||(!i&&e[i].tick)|| (i&&e[i].tick<=e[i-1].tick))return REPLAY_E_HEADER;
    }
    if(checksum(h,e)!=h->crc32)return REPLAY_E_CRC;
    return REPLAY_OK;
}
int replay_record_begin(uint32_t seed,uint32_t cfg){
    replay_reset();header.magic=REPLAY_MAGIC;header.version=REPLAY_VERSION;header.seed=seed;header.config_hash=cfg;state=REPLAY_RECORDING;return REPLAY_OK;
}
int replay_record_input(uint32_t tick,unsigned keys,unsigned bombs){
    if(state!=REPLAY_RECORDING)return fail(REPLAY_E_STATE);
    if(tick!=next_tick||tick==0xffffffffu)return fail(REPLAY_E_TICK);
    if(keys>15||bombs>255)return fail(REPLAY_E_INPUT);
    if(!header.event_count||keys!=record_keys||bombs){
        if(header.event_count>=REPLAY_CAPACITY)return fail(REPLAY_E_OVERFLOW);
        ReplayEvent *e=&records[header.event_count++];e->tick=tick;e->keys=(uint8_t)keys;e->bombs=(uint8_t)bombs;e->reserved=0;
    }
    record_keys=keys;next_tick=tick+1;return REPLAY_OK;
}
int replay_record_end(uint32_t tick,uint32_t hash){
    if(state!=REPLAY_RECORDING)return fail(REPLAY_E_STATE);
    if(!header.event_count||tick!=next_tick)return fail(REPLAY_E_TICK);
    header.final_tick=tick;header.final_state_hash=hash;header.crc32=checksum(&header,records);state=REPLAY_READY;return REPLAY_OK;
}
int replay_finish(uint32_t tick,uint32_t hash){return replay_record_end(tick,hash);}
int replay_play_begin(uint32_t cfg){
    if(state!=REPLAY_READY&&state!=REPLAY_FINISHED)return fail(REPLAY_E_STATE);
    int r=validate(&header,records,cfg);if(r)return fail(r);
    state=REPLAY_PLAYING;next_tick=0;cursor=0;play_keys=0;return REPLAY_OK;
}
int replay_play_input(uint32_t tick,unsigned *keys,unsigned *bombs){
    if(state!=REPLAY_PLAYING)return fail(REPLAY_E_STATE);
    if(!keys||!bombs)return fail(REPLAY_E_INPUT);
    if(tick!=next_tick||tick>header.final_tick)return fail(REPLAY_E_TICK);
    *bombs=0;
    if(tick==header.final_tick){*keys=play_keys;return 0;}
    if(cursor<header.event_count&&records[cursor].tick==tick){play_keys=records[cursor].keys;*bombs=records[cursor].bombs;++cursor;}
    *keys=play_keys;++next_tick;return 1;
}
int replay_play_end(uint32_t hash){
    if(state!=REPLAY_PLAYING)return fail(REPLAY_E_STATE);
    if(next_tick!=header.final_tick)return fail(REPLAY_E_TICK);
    if(hash!=header.final_state_hash)return fail(REPLAY_E_HASH);
    state=REPLAY_FINISHED;return REPLAY_OK;
}
int replay_abort(void){
    if(state==REPLAY_PLAYING||state==REPLAY_FINISHED){state=REPLAY_READY;next_tick=0;cursor=play_keys=0;return REPLAY_OK;}
    if(state==REPLAY_READY||state==REPLAY_IDLE)return REPLAY_OK;
    return fail(REPLAY_E_STATE); /* recorder must be explicitly finished first */
}
int replay_load(const ReplayHeader *h,const ReplayEvent *e,uint32_t cfg){
    int r=validate(h,e,cfg);if(r)return fail(r);
    header=*h;memmove(records,e,header.event_count*sizeof(records[0]));
    state=REPLAY_READY;error=0;next_tick=0;cursor=play_keys=record_keys=0;return REPLAY_OK;
}
unsigned replay_export_words(void){return (state==REPLAY_READY||state==REPLAY_PLAYING||state==REPLAY_FINISHED)?8+header.event_count*2:0;}
int replay_export_word(unsigned i,uint32_t *word){
    if(!word||i>=replay_export_words())return REPLAY_E_INPUT;
    if(i<8){switch(i){case 0:*word=header.magic;break;case 1:*word=header.version;break;case 2:*word=header.seed;break;case 3:*word=header.config_hash;break;case 4:*word=header.event_count;break;case 5:*word=header.final_tick;break;case 6:*word=header.final_state_hash;break;default:*word=header.crc32;break;}}
    else{unsigned n=(i-8)/2;*word=(i&1)?(unsigned)records[n].keys|((unsigned)records[n].bombs<<8):records[n].tick;}
    return REPLAY_OK;
}
