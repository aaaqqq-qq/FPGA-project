#pragma once
#include <stdint.h>

/* Input ticks are zero-based; final_tick is exclusive. One call per logic tick.
 * Key changes and nonzero bomb-event counts form bounded RLE change records.
 * This buffer is ordinary BSS/DDR (32768 bytes), never a new FPGA BRAM/IP. */
#define REPLAY_CAPACITY 4096u
#define REPLAY_MAGIC 0x52504c32u
#define REPLAY_VERSION 2u
enum { REPLAY_IDLE,REPLAY_RECORDING,REPLAY_READY,REPLAY_PLAYING,REPLAY_FINISHED,REPLAY_ERROR };
enum { REPLAY_OK=0,REPLAY_E_STATE=-1,REPLAY_E_OVERFLOW=-2,REPLAY_E_TICK=-3,
       REPLAY_E_CONFIG=-4,REPLAY_E_HEADER=-5,REPLAY_E_CRC=-6,REPLAY_E_HASH=-7,
       REPLAY_E_INPUT=-8 };
typedef struct { uint32_t tick; uint8_t keys,bombs; uint16_t reserved; } ReplayEvent;
typedef struct {
    uint32_t magic,version,seed,config_hash,event_count,final_tick,final_state_hash,crc32;
} ReplayHeader;

void replay_reset(void);
unsigned replay_state(void);
int replay_status(void); /* sticky error; zero means no error */
const ReplayHeader *replay_header(void);
const ReplayEvent *replay_events(void); /* read-only; valid count is header count */
int replay_record_begin(uint32_t seed,uint32_t config_hash);
int replay_record_input(uint32_t tick,unsigned keys,unsigned bomb_events);
int replay_record_end(uint32_t final_tick,uint32_t final_state_hash);
int replay_finish(uint32_t final_tick,uint32_t final_state_hash); /* record-end alias */
int replay_play_begin(uint32_t expected_config_hash);
/* 1=input ready, 0=exclusive final tick reached, negative=sticky error.
 * Call replay_play_end with a real production-state hash after 0, or on outcome. */
int replay_play_input(uint32_t tick,unsigned *keys,unsigned *bomb_events);
int replay_play_end(uint32_t final_state_hash);
int replay_abort(void); /* cancel playback, retain validated recording as READY */
int replay_load(const ReplayHeader *header,const ReplayEvent *events,uint32_t expected_config_hash);
unsigned replay_export_words(void);
int replay_export_word(unsigned index,uint32_t *word); /* little-endian words */
uint32_t replay_hash_u32(uint32_t hash,uint32_t value); /* explicit LE FNV-1a */
