#include "layer_visuals.h"
#include "scene.h"
#include "arena.h"
#include "art_ids.h"
#include <stdint.h>

/* Decorations stay sparse and away from the central bullet-reading area.
   Worst visible area with all seven shadows, the ring and four ribbons is
   Strength1: 7*40*2 + 32*32 + (48*2+32+44*2+28) = 1828 pixels.
   Strength2: 7*40*3 + 64*64 + (88*3+60*2+80*3+52*2) = 5664 pixels.
   Both retain the same hard ceiling and 12-job maximum.
   No full-screen pass, dynamic background bake or new atlas material. */
unsigned layer_visuals_jobs,layer_visuals_area;
unsigned layer_visuals_dropped,layer_visuals_clipped;
static unsigned active,frame_tick,shadow_count,glow_count,foreground_done;
static unsigned strength=1;
static unsigned busy_quality;
static int camera_x,camera_y;

static int clamp(int value,int low,int high){
    if(value<low)return low;
    return value>high?high:value;
}
void layer_visuals_strength(unsigned level){strength=level<1?1:level>2?2:level;}
void layer_visuals_quality(unsigned busy){busy_quality=!!busy;}

void layer_visuals_begin(unsigned tick,unsigned enabled,int px,int py){
    frame_tick=tick;active=!!enabled;shadow_count=glow_count=foreground_done=0;
    layer_visuals_jobs=layer_visuals_area=0;
    layer_visuals_dropped=layer_visuals_clipped=0;
    camera_x=clamp(px,0,ARENA_W);camera_y=clamp(py,0,ARENA_H);
}

/* Compute clipping in wide arithmetic, before converting back to renderer int
   coordinates. A rejected or empty primitive never reaches the scene API. */
static unsigned clipped_area(int64_t x,int64_t y,unsigned w,unsigned h,
                             int *cx,int *cy,int *cw,int *ch){
    int64_t right=x+w,bottom=y+h;
    int64_t left=x<0?0:x,top=y<0?0:y;
    if(right>ARENA_W)right=ARENA_W;
    if(bottom>ARENA_H)bottom=ARENA_H;
    if(left>=right||top>=bottom){++layer_visuals_clipped;return 0;}
    if(left!=x||top!=y||right!=x+w||bottom!=y+h)++layer_visuals_clipped;
    *cx=(int)left;*cy=(int)top;*cw=(int)(right-left);*ch=(int)(bottom-top);
    return (unsigned)*cw*(unsigned)*ch;
}

static int budget(unsigned area){
    if(layer_visuals_jobs>=LAYER_VISUAL_JOB_LIMIT||
       layer_visuals_area>LAYER_VISUAL_AREA_LIMIT||
       area>LAYER_VISUAL_AREA_LIMIT-layer_visuals_area){
        ++layer_visuals_dropped;return 0;
    }
    ++layer_visuals_jobs;layer_visuals_area+=area;return 1;
}

static int ribbon(int64_t x,int64_t y,unsigned w,unsigned h,uint32_t color){
    int cx,cy,cw,ch;unsigned area=clipped_area(x,y,w,h,&cx,&cy,&cw,&ch);
    if(!area||!budget(area))return 0;
    scene_rect(32+cx,16+cy,cw,ch,color);return 1;
}

void layer_visuals_shadow(int x,int y,unsigned width){
    if(!active||!width)return;
    if(shadow_count>=7){++layer_visuals_dropped;return;}
    if(width>40)width=40;
    if(strength==2)width=width>32?40:width+8;
    /* Thin dark projection, shifted towards the lower right. One small fill
       per actor; tiny flying fairies deliberately need no ground projection. */
    if(ribbon((int64_t)x+3-(int)(width/2),(int64_t)y+3,width,strength==2?3:2,strength==2?0x020b13u:0x07141fu))
        ++shadow_count;
}

void layer_visuals_glow(int x,int y){
    if(!active)return;
    if(glow_count){++layer_visuals_dropped;return;}
    int cx,cy,cw,ch;
    unsigned large=strength==2&&!busy_quality;
    unsigned size=large?64:32;
    int64_t left=(int64_t)x-size/2,top=(int64_t)y-size/2;
    unsigned area=clipped_area(left,top,size,size,&cx,&cy,&cw,&ch);
    if(!area||!budget(area))return;
    /* A keyed cyan ring with one uniform Alpha value. The label is an
       artistic local aura, not per-pixel lighting, HDR bloom or illumination. */
    unsigned phase=(frame_tick>>2)&31u;
    unsigned pulse=phase<16?phase:31-phase;
    scene_tile(32+(int)left,16+(int)top,large?ART_RING_CYAN64:ART_RING_CYAN32,strength==2?100+pulse*2:38+pulse);
    ++glow_count;
}

void layer_visuals_foreground(void){
    if(!active||foreground_done)return;
    foreground_done=1;
    /* Low-frequency breeze and a small counter-motion to the player's
       position provide near-field parallax while the far background remains
       cached. The four slivers remain within the outer 160 pixels. */
    unsigned p=(frame_tick/3u)&127u;
    int triangle=(int)(p<64?p:127-p);
    int amplitude=strength==2?12:8;
    int wind=triangle*(amplitude*2)/63-amplitude;
    int sx=(camera_x-ARENA_W/2)/(strength==2?32:48),sy=(camera_y-ARENA_H/2)/(strength==2?48:64);
    int left=18+wind-sx,right=ARENA_W-(strength==2?120:82)-wind/2-sx;
    int ly=ARENA_H-110-sy,ry=ARENA_H-188-sy;
    if(strength==2){
        ribbon(left,ly,88,3,0x34566bu);
        ribbon(left+14,ly+4,60,2,0x476a7eu);
        ribbon(right,ry,80,3,0x304e65u);
        ribbon(right+11,ry-4,52,2,0x416078u);
    }else{
        ribbon(left,ly,48,2,0x1b3546u);
        ribbon(left+10,ly+3,32,1,0x264456u);
        ribbon(right,ry,44,2,0x183143u);
        ribbon(right+7,ry-3,28,1,0x223d50u);
    }
}
