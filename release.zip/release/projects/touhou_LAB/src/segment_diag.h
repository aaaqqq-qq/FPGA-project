#ifndef SEGMENT_DIAG_H
#define SEGMENT_DIAG_H
#include <stdint.h>
#include "bitblt.h"
/* Sequential wall segments partition previous-swap -> this-swap. Nested
 * probes are separate accounting and must NEVER be added to those segments. */
enum {SD_INTERFRAME,SD_CAPTURE,SD_SNAPSHOT,SD_BEFORE_LOGIC,SD_RUNTIME_BEGIN,
 SD_CPU_HUD,SD_MOTION_COMMIT,SD_DMA_HUD,SD_LOGIC_END,SD_ACTOR_TAIL,
 SD_FRAME_DRAIN,SD_FRAME_PUBLISH,SD_BEFORE_SWAP,SD_SWAP_PUBLISH,SD_SWAP_WAIT,SD_WALL_COUNT,
 SD_R_WAIT=SD_WALL_COUNT,SD_LEGACY_WAIT,SD_PUBLISH,SD_ACQUIRE,SD_LEGACY_CYCLES,
 SD_R_CYCLES,SD_R_READ,SD_R_WRITE,SD_M_CYCLES,SD_M_READ,SD_M_WRITE,SD_COUNT};
enum {SDE_R_SUBMIT,SDE_SNAPSHOT,SDE_M_SUBMIT,SDE_M_DONE,SDE_M_COMMIT,SDE_R_DONE,SDE_COUNT};
typedef struct {uint64_t sum;uint32_t maximum,last,calls;} SegmentPhase;
typedef struct {unsigned enabled,active,epoch,samples,timer_hz,read_min,read_max,overflow,order_errors,peak_frame,peak_event_mask;uint64_t peak_render,peak_period;} SegmentInfo;
#if defined(__riscv) || defined(SEGMENT_DIAG_HOST_ENABLE)
#define SEGMENT_DIAG_REAL 1
extern unsigned segment_diag_active;
void segment_diag_enable(unsigned enabled);
void segment_diag_restart(uint64_t previous_swap);
void segment_diag_stop(void);
void segment_diag_frame_begin(uint64_t frame_begin);
void segment_diag_cut_at(unsigned phase,uint64_t stamp);
void segment_diag_frame_done(uint64_t render_end,uint64_t swap_end);
void segment_diag_nested_record(unsigned phase,uint64_t begin);
void segment_diag_value(unsigned phase,uint64_t value);
void segment_diag_event(unsigned event);
SegmentPhase segment_diag_event_info(unsigned event);
uint64_t segment_diag_peak_event(unsigned event);
SegmentInfo segment_diag_info(void);
SegmentPhase segment_diag_phase(unsigned phase);
uint64_t segment_diag_peak(unsigned phase);
static inline void segment_diag_cut(unsigned phase){if(segment_diag_active)segment_diag_cut_at(phase,bb_ticks());}
static inline uint64_t segment_diag_nested_begin(void){return segment_diag_active?bb_ticks():0;}
static inline void segment_diag_nested_end(unsigned phase,uint64_t begin){if(segment_diag_active)segment_diag_nested_record(phase,begin);}
#else
#define SEGMENT_DIAG_REAL 0
#define segment_diag_active 0u
static inline void segment_diag_enable(unsigned x){(void)x;}
static inline void segment_diag_restart(uint64_t x){(void)x;}
static inline void segment_diag_stop(void){}
static inline void segment_diag_frame_begin(uint64_t x){(void)x;}
static inline void segment_diag_cut_at(unsigned p,uint64_t x){(void)p;(void)x;}
static inline void segment_diag_cut(unsigned p){(void)p;}
static inline void segment_diag_frame_done(uint64_t a,uint64_t b){(void)a;(void)b;}
static inline uint64_t segment_diag_nested_begin(void){return 0;}
static inline void segment_diag_nested_end(unsigned p,uint64_t b){(void)p;(void)b;}
static inline void segment_diag_value(unsigned p,uint64_t v){(void)p;(void)v;}
static inline void segment_diag_event(unsigned e){(void)e;}
static inline SegmentPhase segment_diag_event_info(unsigned e){SegmentPhase x={0};(void)e;return x;}
static inline uint64_t segment_diag_peak_event(unsigned e){(void)e;return 0;}
static inline SegmentInfo segment_diag_info(void){SegmentInfo x={0};return x;}
static inline SegmentPhase segment_diag_phase(unsigned p){SegmentPhase x={0};(void)p;return x;}
static inline uint64_t segment_diag_peak(unsigned p){(void)p;return 0;}
#endif
#endif
