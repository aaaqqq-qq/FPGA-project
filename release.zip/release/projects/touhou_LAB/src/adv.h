#ifndef TI60_ADV_H
#define TI60_ADV_H
#include "lab.h"
void adv_init(lab_reply_fn output,lab_restore_fn restore);
int adv_command(const char *line);
unsigned adv_active(void);
unsigned adv_pending(void);
int adv_cpu_poll(void);
void adv_service(void);
void adv_io_service(void);
#endif
