#ifndef TICK_PROFILE_H
#define TICK_PROFILE_H
#include <stdint.h>
#include "bitblt.h"
enum {TP_CONTROL,TP_BOSS,TP_MOTION,TP_ENEMY,TP_PLAYER_FIRE,TP_PLAYER_SHOTS,
 TP_OWNER_DEATH,TP_CLEAR_OWNER,TP_VITALS_FX,TP_REFILL,TP_TOTAL,TP_PHASES};
typedef struct {uint64_t sum;uint32_t maximum,last,calls;} TickPhase;
typedef struct {uint32_t enabled,active,epoch,timer_hz,read_min,read_max,overflow;} TickProfileInfo;
#if defined(__riscv) || defined(TICK_PROFILE_HOST_ENABLE)
#define TICK_PROFILE_REAL 1
extern unsigned tick_profile_active;
void tick_profile_enable(unsigned enabled);
void tick_profile_restart(void);
void tick_profile_stop(void);
TickProfileInfo tick_profile_info(void);
TickPhase tick_profile_phase(unsigned phase);
void tick_profile_record(unsigned phase,uint64_t elapsed);
static inline uint64_t tick_profile_begin(void){return tick_profile_active?bb_ticks():0;}
static inline void tick_profile_end(unsigned phase,uint64_t begin){if(tick_profile_active)tick_profile_record(phase,bb_ticks()-begin);}
#else
/* Existing standalone host harnesses retain a disabled profiler. Dedicated
   on/off tests define TICK_PROFILE_HOST_ENABLE and link tick_profile.c. */
#define TICK_PROFILE_REAL 0
static inline void tick_profile_enable(unsigned enabled){(void)enabled;}
static inline void tick_profile_restart(void){}
static inline void tick_profile_stop(void){}
static inline TickProfileInfo tick_profile_info(void){TickProfileInfo p={0};return p;}
static inline TickPhase tick_profile_phase(unsigned phase){TickPhase p={0};(void)phase;return p;}
static inline uint64_t tick_profile_begin(void){return 0;}
static inline void tick_profile_end(unsigned phase,uint64_t begin){(void)phase;(void)begin;}
#endif
#endif
