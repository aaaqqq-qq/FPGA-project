#include "render_queue.h"
#include <string.h>
static RqCommand commands[RQ_CAPACITY];
static uint16_t order[RQ_CAPACITY];
static char strings[RQ_TEXT_BYTES];
static unsigned count,text_used,order_ready;
static unsigned rank[RQ_LAYER_COUNT]={0,1,2,3,4,5,6,7};
unsigned rq_total,rq_peak,rq_reordered;
void rq_reset(void){count=text_used=order_ready=0;rq_total=rq_peak=rq_reordered=0;}
unsigned rq_count(void){return count;}
int rq_set_order(const unsigned ranks[RQ_LAYER_COUNT]){
    if(!ranks)return 0;
    for(unsigned i=0;i<RQ_LAYER_COUNT;++i)if(ranks[i]>255)return 0;
    for(unsigned i=0;i<RQ_LAYER_COUNT;++i)rank[i]=ranks[i];
    order_ready=0;
    return 1;
}
int rq_push(const RqCommand *c,const char *text){
    if(!c||c->layer>=RQ_LAYER_COUNT||c->kind>RQ_TEXT)return RQ_E_ARGUMENT;
    if(count>=RQ_CAPACITY)return RQ_E_CAPACITY;
    unsigned n=0;
    if(c->kind==RQ_TEXT){
        if(!text)return RQ_E_ARGUMENT;
        while(n<RQ_TEXT_BYTES&&text[n])++n;
        if(n==RQ_TEXT_BYTES||n+1>RQ_TEXT_BYTES-text_used)return RQ_E_TEXT;
    }
    commands[count]=*c;
    if(c->kind==RQ_TEXT){commands[count].text_at=(uint16_t)text_used;memcpy(strings+text_used,text,n+1);text_used+=n+1;}
    ++count;order_ready=0;++rq_total;if(count>rq_peak)rq_peak=count;
    return RQ_OK;
}
static int earlier(unsigned a,unsigned b){
    const RqCommand *x=&commands[a],*y=&commands[b];
    unsigned xr=rank[x->layer],yr=rank[y->layer];
    if(xr!=yr)return xr<yr;
    if(x->layer!=y->layer)return x->layer<y->layer;
    if(x->depth!=y->depth)return x->depth<y->depth;
    return a<b;
}
static void rq_sort(void){
    if(order_ready)return;
    /* Read the insertion position first, then move only 16-bit indices. The
       sparse actor list is sorted, never the 20,000-bullet descriptor pool. */
    for(unsigned i=0;i<count;++i){
        unsigned at=i;
        while(at&&earlier(i,order[at-1]))--at;
        if(at!=i)memmove(&order[at+1],&order[at],(i-at)*sizeof(order[0]));
        order[at]=(uint16_t)i;
    }
    order_ready=1;
}
void rq_prepare(RqPrepare prepare,void *context){
    if(!prepare)return;
    rq_sort();
    for(unsigned i=0;i<count;++i){
        RqCommand *c=&commands[order[i]];
        prepare(c,c->kind==RQ_TEXT?strings+c->text_at:0,context);
    }
}
void rq_flush(RqSink sink,void *context){
    if(!sink)return;
    rq_sort();
    for(unsigned i=0;i<count;++i){
        unsigned j=order[i];if(j!=i)++rq_reordered;
        const RqCommand *c=&commands[j];sink(c,c->kind==RQ_TEXT?strings+c->text_at:0,context);
    }
    count=text_used=order_ready=0;
}
