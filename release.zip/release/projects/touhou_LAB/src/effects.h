#pragma once

enum {
    FX_RING_WARN = 0,
    FX_RING_BURST,
    FX_PLAYER_HIT,
    FX_LEVELUP,
    FX_REGEN,
    FX_BOSS_ENTER,
    FX_BOSS_DEATH,
    FX_GRAZE,
    FX_CANCEL_STAR
};

void effects_reset(void);
void effects_tick(void);
void effects_render(void);
/* Cosmetic-only quality hysteresis. Call once per rendered frame. Returns
   0 for original size, 1 for busy 32px ring substitutes; no simulation skips. */
unsigned effects_render_budget(unsigned enabled,unsigned active_bosses,
                               unsigned live_player_shots,unsigned enemy_bullets,
                               unsigned previous_frame_us);
extern unsigned effects_quality,effects_lod_jobs;

void fx_player_hit(int x, int y);
void fx_levelup(int x, int y);
void fx_regen(int x, int y);
void fx_boss_enrage_start(unsigned boss_index);
void fx_boss_enrage_finish(unsigned boss_index);
void fx_boss_enter(unsigned boss_index);
void fx_boss_death(unsigned boss_index);

extern unsigned effects_jobs, effects_area, effects_over_budget, effects_active;

void fx_graze(int x,int y);
void fx_cancel_star(int x,int y);
unsigned effects_hp_color(unsigned hp,unsigned maxhp,unsigned tick);
unsigned effects_hitpoint_color(unsigned hp,unsigned maxhp,unsigned tick);
void effects_vignette(unsigned tick,unsigned hp,unsigned maxhp,unsigned warning);

/* Monotonic rejected-effect jobs since effects_reset(); wrap-safe deltas. */
extern unsigned effects_drop_total;
