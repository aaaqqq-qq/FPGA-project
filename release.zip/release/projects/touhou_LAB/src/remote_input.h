#ifndef REMOTE_INPUT_H
#define REMOTE_INPUT_H
#include <stdint.h>

/* LAB1 state packet: A5 5A seq mask_lo mask_hi (seq^lo^hi^A7).
 * A complete state, not a key repeat, is sent every 75ms by the PC. */
enum {
    REMOTE_LEFT=1, REMOTE_RIGHT=2, REMOTE_UP=4, REMOTE_DOWN=8,
    REMOTE_BOMB=16, REMOTE_PAUSE=32, REMOTE_START=64, REMOTE_MENU=128,
    REMOTE_MASK=255, REMOTE_HOLD_TIMEOUT_US=500000,
    REMOTE_PACKET_TIMEOUT_US=50000
};
typedef struct {
    uint16_t held,pressed;
    uint8_t sequence,have_sequence,position,packet[4];
    uint32_t last_valid_us,partial_since_us;
    uint32_t accepted,rejected,duplicates,timeouts;
} RemoteInput;
void remote_input_init(RemoteInput *r);
/* Returns 1 for every byte consumed by the binary parser, including rejected
 * packets. A return of 0 permits the caller's colon-only ASCII parser. */
int remote_input_feed(RemoteInput *r,uint8_t byte,uint32_t now_us);
void remote_input_expire(RemoteInput *r,uint32_t now_us);
unsigned remote_input_pressed(RemoteInput *r);
#endif
