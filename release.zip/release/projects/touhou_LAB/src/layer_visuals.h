#pragma once

/* Small, deterministic decorations for the layered renderer. Coordinates are
   relative to the 1024x688 play field. The caller chooses the render layer.
   No gameplay state or random generator is read or changed here. */
void layer_visuals_begin(unsigned tick,unsigned enabled,int player_x,int player_y);
/* 1 = restrained R7 look, 2 = clearer demonstration. Other values clamp. */
void layer_visuals_strength(unsigned level);
/* Cosmetic busy quality from effects_render_budget; keeps strength setting but
   substitutes a bright32px aura for the64px demonstration aura under load. */
void layer_visuals_quality(unsigned busy);
/* x/y are the foot projection centre, not the actor sprite's top-left. */
void layer_visuals_shadow(int x,int y,unsigned width);
/* Existing low-alpha ring sprite: a local aura approximation, not a light map. */
void layer_visuals_glow(int x,int y);
void layer_visuals_foreground(void);

#define LAYER_VISUAL_JOB_LIMIT 12u
#define LAYER_VISUAL_AREA_LIMIT 8192u
extern unsigned layer_visuals_jobs,layer_visuals_area;
extern unsigned layer_visuals_dropped,layer_visuals_clipped;
