#include "labx.h"
#include "bitblt.h"
#include "font.h"
#include <stdint.h>
#include <string.h>

/* All scratch is external DDR. No host supplied pointer can reach the driver.
   Every operation is opaque; the platform bitstream and 100MHz clock stay fixed. */
enum { ENTER, EXIT, STATUS, MEM, COMPARE, DOUBLE, CANCEL, BAD };
typedef struct { uint32_t id; unsigned op,kind,size,layout,frames,warmup,repeats,action; } Request;
typedef struct {
    uint64_t render,wait,elapsed,check_us,cycles,read,write,pixels;
    uint32_t frames,jobs,swaps,uf,errors,guards,source,samples,checked,actual,replayed;
} Measurement;
static Request request;
static unsigned active,pending,running,cancelled,phase,ready;
static uint32_t double_front,double_back,double_swaps,double_errors;
static lab_reply_fn emit;
static lab_restore_fn restore;
static char line[384];static unsigned used;
static uint32_t width,height,source_stride,source_offset;
static uint32_t checked_sources;
static uint64_t io_ticks;
int labx_cpu_poll(void){uint64_t t=bb_ticks();labx_io_service();io_ticks+=bb_ticks()-t;return cancelled!=0;}
static const char *const ops[]={"enter","exit","status","mem","compare","double","cancel","unknown"};
static const char *const sizes[]={"small","medium","large"};
static const char *const layouts[]={"aligned","offset","boundary"};
static Measurement screen_cpu,screen_hw;
static unsigned screen_memory;
__attribute__((weak)) void labx_io_service(void){}
static volatile uint32_t *ptr(uint32_t a){return (volatile uint32_t *)(uintptr_t)a;}
static void add(const char *s){while(*s&&used+1<sizeof line)line[used++]=*s++;line[used]=0;}
static void num(uint64_t v){char s[21];unsigned n=0;do{s[n++]=(char)('0'+v%10u);v/=10u;}while(v);while(n){char c[2]={s[--n],0};add(c);}}
static void field(const char *key,uint64_t v){add(" ");add(key);add("=");num(v);}
static void begin(const char *tag,uint32_t id){used=0;line[0]=0;add(tag);field("id",id);}
static void send(void){if(emit)emit(line);labx_io_service();}
static void terminal(const Request *r,const char *status,const char *code,unsigned completed,uint64_t elapsed,uint32_t uf){
    begin("LABX_DONE",r->id);add(" op=");add(ops[r->op]);add(" status=");add(status);add(" code=");add(code);
    field("completed",completed);field("active",active);field("elapsed_us",elapsed);field("uf",uf);send();
}
static int uint_value(const char *s,uint32_t *out){uint32_t n=0;if(!*s)return 0;while(*s){unsigned d=(unsigned)(*s++-'0');if(d>9||n>(UINT32_MAX-d)/10u)return 0;n=n*10u+d;}*out=n;return 1;}
static int index_of(const char *s,const char *const *names,unsigned count){for(unsigned i=0;i<count;++i)if(!strcmp(s,names[i]))return (int)i;return -1;}
static int service_cancel(void){return labx_cpu_poll();}
void labx_init(lab_reply_fn out,lab_restore_fn back){emit=out;restore=back;active=pending=running=cancelled=phase=ready=0;memset(&screen_cpu,0,sizeof screen_cpu);memset(&screen_hw,0,sizeof screen_hw);}
unsigned labx_active(void){return active;}
unsigned labx_pending(void){return pending||running;}
unsigned labx_cancelled(void){return cancelled;}
static void state(uint32_t id){
    uint32_t f=0,sw=0,pend=0;
    for(unsigned attempt=0;attempt<16;++attempt){f=bb_read(BB_FRONT);sw=bb_read(BB_SWAPS);pend=bb_read(BB_DISPLAY_STATUS)&BB_SWAP_PENDING;
        if(f==bb_read(BB_FRONT)&&sw==bb_read(BB_SWAPS))break;}
    begin("LABX_STATE",id);field("active",active);field("phase",phase);field("front",f);
    field("back",f==BB_FB0?BB_FB1:BB_FB0);field("swaps",sw);field("pending",pend!=0);
    field("ready",ready);field("errors",double_errors);send();
}
int labx_command(const char *input){
    Request r={0,BAD,0,0,0,1,0,1,0};char text[160],*t[12];unsigned n=0,count=0;uint32_t v;
    if(!input)return 0;if(*input==':')++input;
    if(strncmp(input,"labx",4)||(input[4]&&input[4]!=' '&&input[4]!='\t'))return 0;
    while(input[n]&&n<sizeof text-1)++n;
    if(input[n]){terminal(&r,"ERROR","PARSE",0,0,0);return 1;}
    memcpy(text,input,n+1);char *p=text;
    while(*p){while(*p==' '||*p=='\t')++p;if(!*p)break;if(count==12)break;t[count++]=p;while(*p&&*p!=' '&&*p!='\t')++p;if(*p)*p++=0;}
    if(count<3||!uint_value(t[1],&r.id)||!r.id||r.id>2147483647u){r.id=0;terminal(&r,"ERROR","PARSE",0,0,0);return 1;}
    int op=index_of(t[2],ops,BAD);r.op=op<0?BAD:(unsigned)op;
    if(r.op==MEM){
        const char *const kinds[]={"fill","copy"};int k=count==7?index_of(t[3],kinds,2):-1;
        int s=count==7?index_of(t[4],sizes,3):-1,a=count==7?index_of(t[5],layouts,3):-1;
        if(k<0||s<0||a<0||!uint_value(t[6],&v)||v<1||v>3)r.op=BAD;
        else{r.kind=(unsigned)k;r.size=(unsigned)s;r.layout=(unsigned)a;r.repeats=v;}
    }else if(r.op==COMPARE){
        const char *const kinds[]={"blocks","image"};int k=count==8?index_of(t[3],kinds,2):-1;
        int s=count==8?index_of(t[4],sizes,3):-1;
        if(k<0||s<0||!uint_value(t[5],&v)||v<1||v>120)r.op=BAD;
        else{r.kind=(unsigned)k;r.size=(unsigned)s;r.frames=v;
            if(!uint_value(t[6],&v)||v>8)r.op=BAD;else r.warmup=v;
            if(!uint_value(t[7],&v)||v<1||v>3)r.op=BAD;else r.repeats=v;}
    }else if(r.op==DOUBLE){const char *const actions[]={"reset","next","auto"};int a=count==4?index_of(t[3],actions,3):-1;if(a<0)r.op=BAD;else r.action=(unsigned)a;}
    else if(count!=3)r.op=BAD;
    if(r.op==BAD){terminal(&r,"ERROR","PARSE",0,0,0);return 1;}
    if(lab_active()||lab_pending()){terminal(&r,"ERROR","LEGACY_ACTIVE",0,0,0);return 1;}
    if(r.op==CANCEL){if(pending||running)cancelled=1;begin("LABX_ACK",r.id);add(" op=cancel status=ACCEPTED");send();terminal(&r,"PASS","OK",0,0,0);return 1;}
    if(r.op==STATUS){begin("LABX_ACK",r.id);add(" op=status status=ACCEPTED");send();state(r.id);terminal(&r,"PASS","OK",0,0,0);return 1;}
    if(pending||running){terminal(&r,"ERROR","BUSY",0,0,0);return 1;}
    if((r.op==ENTER&&active)||(r.op!=ENTER&&!active)){terminal(&r,"ERROR","MODE",0,0,0);return 1;}
    request=r;pending=1;cancelled=0;
    begin("LABX_ACK",r.id);add(" op=");add(ops[r.op]);add(" status=QUEUED");send();return 1;
}
static uint64_t microseconds(uint64_t ticks){return ticks/100u;}
static uint32_t back_buffer(void){uint32_t f=bb_read(BB_FRONT);return f==BB_FB0?BB_FB1:f==BB_FB1?BB_FB0:0;}
static int execute(const bb_job *j,unsigned cpu,Measurement *m){
    bb_metrics hw={0,0,0};if(service_cancel())return 0;
    bb_result e=cpu?bb_cpu_execute(j):bb_execute(j,&hw);
    if(e!=BB_OK)return 0;if(m){++m->jobs;m->pixels+=(uint64_t)j->width*j->height;m->cycles+=hw.cycles;m->read+=hw.read_bytes;m->write+=hw.write_bytes;}return 1;
}
static int fill(uint32_t fb,unsigned x,unsigned y,unsigned w,unsigned h,uint32_t color){
    for(unsigned offset=0;offset<w;offset+=1024){unsigned part=w-offset;if(part>1024)part=1024;
        bb_job j={BB_FILL_OP,0,fb+y*5120u+(x+offset)*4u,0,5120,part,h,color,255,0,0};if(!execute(&j,0,0))return 0;}return 1;
}
static void text(uint32_t fb,unsigned x,unsigned y,const char *s,uint32_t color,unsigned scale){draw_text(fb,x,y,s,color,scale);}
static void text_number(uint32_t fb,unsigned x,unsigned y,const char *label,uint64_t value){
    used=0;line[0]=0;add(label);num(value);text(fb,x,y,line,0x27324bu,2);
}
static int panel(uint32_t fb,const char *title){
    if(!fill(fb,0,0,1280,720,0xf4f6fa)||!fill(fb,0,0,1280,184,0xffffff))return 0;
    text(fb,28,20,"TI60 LAB23 / REAL BOARD EXPERIMENT",0x324264,2);text(fb,28,48,title,0x175ccd,2);
    text(fb,32,90,screen_memory?"FPGA / SPLIT":"CPU / LAST COMPLETED",0x604eaf,2);text(fb,658,90,screen_memory?"FPGA / MERGED":"FPGA / LAST COMPLETED",0x008e79,2);
    text_number(fb,32,116,"DRAW US ",screen_cpu.frames?screen_cpu.render/screen_cpu.frames:0);
    text_number(fb,658,116,"DRAW US ",screen_hw.frames?screen_hw.render/screen_hw.frames:0);
    text_number(fb,32,142,"SWAPS ",screen_cpu.swaps);text_number(fb,658,142,"SWAPS ",screen_hw.swaps);
    return bb_publish()==BB_OK;
}
static uint32_t material(unsigned which,unsigned x,unsigned y){
    unsigned tile=((x/24u)^(y/24u))&1u;
    return which?((x*255u/960u)<<16)|((y*220u/480u)<<8)|(tile?0x9au:0x48u):
        (tile?0x99d8cbu:0x3c7995u)^((x&31u)<<8)^((y&31u)<<16);
}
static uint32_t source_address(unsigned which){return (which?LABX_SOURCE1:LABX_SOURCE0)+source_offset;}
static uint32_t span(void){return (height-1u)*source_stride+width*4u;}
static int prepare_sources(void){
    if((uint64_t)source_offset+span()+64u>LABX_SOURCE_SLOT||BB_FRAME_BYTES+64u>LABX_REFERENCE_SLOT)return 0;
    for(unsigned t=0;t<2;++t)for(unsigned y=0;y<height;++y){if(!(y&7u)&&service_cancel())return 0;
        for(unsigned x=0;x<width;++x)ptr(source_address(t)+y*source_stride)[x]=material(t,x,y);}
    for(unsigned t=0;t<2;++t)for(unsigned k=0;k<16;++k)ptr(source_address(t)+span())[k]=0x71b5a63du^(t*31u+k);
    for(unsigned t=0;t<4;++t)for(unsigned k=0;k<16;++k)ptr((t==0?BB_FB0:t==1?BB_FB1:t==2?LABX_REFERENCE:LABX_SNAPSHOT)+BB_FRAME_BYTES)[k]=0x71b5a63du^(t*17u+k);
    checked_sources=1;return bb_publish()==BB_OK;
}
static int guards(Measurement *m){
    bb_acquire();for(unsigned t=0;t<4;++t)for(unsigned k=0;k<16;++k)m->guards+=ptr((t==0?BB_FB0:t==1?BB_FB1:t==2?LABX_REFERENCE:LABX_SNAPSHOT)+BB_FRAME_BYTES)[k]!=(0x71b5a63du^(t*17u+k));
    for(unsigned t=0;t<2;++t)for(unsigned k=0;k<16;++k)m->guards+=ptr(source_address(t)+span())[k]!=(0x71b5a63du^(t*31u+k));
    if(checked_sources)for(unsigned t=0;t<2;++t)for(unsigned y=0;y<height;++y){if(!(y&7u)&&service_cancel())return 0;
        for(unsigned x=0;x<width;++x)m->source+=ptr(source_address(t)+y*source_stride)[x]!=material(t,x,y);}
    return !m->guards&&!m->source;
}
static int copy_memory(uint32_t dst,uint32_t src){for(unsigned y=0;y<720;++y){if(!(y&7u)&&service_cancel())return 0;
    for(unsigned x=0;x<1280;++x)ptr(dst)[y*1280u+x]=ptr(src)[y*1280u+x];}return 1;}
static int verify_frame(uint32_t fb,Measurement *m){bb_acquire();for(unsigned y=0;y<720;++y){if(!(y&7u)&&service_cancel())return 0;
    for(unsigned x=0;x<1280;++x)m->errors+=ptr(fb)[y*1280u+x]!=ptr(LABX_REFERENCE)[y*1280u+x];}
    ++m->samples;m->checked+=1280u*720u;return guards(m)&&!m->errors;}
static uint32_t task_hash(const Request *r){uint32_t h=2166136261u;const uint32_t words[]={r->op,r->kind,r->size,r->layout,r->frames,r->warmup,width,height,0x23a0917du};
    for(unsigned i=0;i<sizeof words/sizeof words[0];++i)h=(h^words[i])*16777619u;return h;}
static void key(const Request *r,unsigned group,unsigned cpu,const char *method){field("group",group);add(" backend=");add(cpu?"CPU":"FPGA");add(" method=");add(method);(void)r;}
static void result(const Request *r,unsigned group,unsigned cpu,const char *method,const Measurement *m,uint32_t task){
    begin("LABX_RESULT",r->id);key(r,group,cpu,method);field("task",task);field("frames",m->frames);field("jobs",m->jobs);field("pixels",m->pixels);field("render_us",m->render);field("wait_us",m->wait);send();
    begin("LABX_METRIC",r->id);key(r,group,cpu,method);field("elapsed_us",m->elapsed);field("swaps",m->swaps);field("cycles",m->cycles);field("read",m->read);field("write",m->write);field("uf",m->uf);field("check_us",m->check_us);send();
    begin("LABX_CHECK",r->id);key(r,group,cpu,method);field("samples",m->samples);field("errors",m->errors);field("guards",m->guards);field("source",m->source);field("checked",m->checked);field("actual",m->actual);field("replayed",m->replayed);field("first",0);field("middle",r->frames/2);field("last",r->frames-1);send();
}
static void plan(const Request *r){
    begin("LABX_PLAN",r->id);add(" op=");add(ops[r->op]);add(" kind=");add(r->op==MEM?(r->kind?"copy":"fill"):(r->kind?"image":"blocks"));
    add(" size=");add(sizes[r->size]);add(" layout=");add(layouts[r->layout]);field("frames",r->frames);field("warmup",r->warmup);field("repeats",r->repeats);field("expected",r->repeats*2u);field("w",width);field("h",height);field("task",task_hash(r));send();
    begin("LABX_SCOPE",r->id);field("first",0);field("middle",r->frames/2u);field("last",r->frames-1u);add(" check=full_frame units=bytes hz=100000000 fps=display_wall sample_mode=last_actual actual_last=1");send();
}
static uint32_t color(unsigned block){return 0x3266b0u+block*0x0b0703u;}
static unsigned roi_x(const Request *r){return r->op==MEM?(r->layout==1?33u:r->layout==2?255u:32u):32u;}
static unsigned roi_y(const Request *r){return r->op==MEM&&r->layout==2?219u:216u;}
static void expected(const Request *r,unsigned frame){
    unsigned x0=roi_x(r),y0=roi_y(r);for(unsigned y=0;y<height;++y)for(unsigned x=0;x<width;++x)
        ptr(LABX_REFERENCE)[(y0+y)*1280u+x0+x]=r->op==MEM?(r->kind?material(0,x,y):0x62b6a1u):0xe6ebf3u;
    if(r->op==MEM)return;
    if(r->kind){for(unsigned y=0;y<height;++y)for(unsigned x=0;x<width;++x)ptr(LABX_REFERENCE)[(y0+y)*1280u+x0+x]=material(frame&1u,x,y);}
    else for(unsigned n=0;n<12;++n){unsigned sz=width/12u;if(sz>40)sz=40;if(sz<8)sz=8;
        unsigned bx=(frame*7u+n*41u)%(width-sz+1u),by=(frame*3u+n*23u)%(height-sz+1u);
        for(unsigned y=0;y<sz;++y)for(unsigned x=0;x<sz;++x)ptr(LABX_REFERENCE)[(y0+by+y)*1280u+x0+bx+x]=color(n);}
}
static int jobs(const Request *r,unsigned frame,uint32_t fb,unsigned cpu,unsigned split,Measurement *m){
    bb_job j={BB_FILL_OP,0,fb+roi_y(r)*5120u+roi_x(r)*4u,source_stride,5120,width,height,0xe6ebf3u,255,0,0};
    if(r->op==MEM){j.op=r->kind?BB_COPY_OP:BB_FILL_OP;j.src=source_address(0);j.fill=0x62b6a1u;
        unsigned tw=split?32u:width,th=split?16u:height;
        for(unsigned y=0;y<height;y+=th)for(unsigned x=0;x<width;x+=tw){bb_job part=j;part.width=width-x<tw?width-x:tw;part.height=height-y<th?height-y:th;
            part.src+=y*source_stride+x*4u;part.dst+=y*5120u+x*4u;if(!execute(&part,cpu,m))return 0;}return 1;}
    if(!execute(&j,cpu,m))return 0;
    if(r->kind){j.op=BB_COPY_OP;j.src=source_address(frame&1u);return execute(&j,cpu,m);}
    unsigned sz=width/12u;if(sz>40)sz=40;if(sz<8)sz=8;j.width=j.height=sz;
    for(unsigned n=0;n<12;++n){unsigned bx=(frame*7u+n*41u)%(width-sz+1u),by=(frame*3u+n*23u)%(height-sz+1u);
        j.dst=fb+(216u+by)*5120u+(32u+bx)*4u;j.fill=color(n);if(!execute(&j,cpu,m))return 0;}return 1;
}
static int measured_run(const Request *r,unsigned cpu,unsigned split,Measurement *m){
    memset(m,0,sizeof *m);uint32_t fb=back_buffer();if(!fb||!panel(fb,r->op==MEM?"MEMORY: EQUAL PIXELS / SPLIT VS MERGED":"DRIVER: IDENTICAL CPU / FPGA TASKS"))return 0;
    if(bb_swap_wait(fb,200000)!=BB_OK)return 0;
    /* Rebuild the other bank too, before measurement. No front writes. */
    fb=back_buffer();if(!panel(fb,r->op==MEM?"MEMORY: EQUAL PIXELS / SPLIT VS MERGED":"DRIVER: IDENTICAL CPU / FPGA TASKS"))return 0;
    if(!copy_memory(LABX_SNAPSHOT,fb))return 0;
    for(unsigned f=0;f<r->warmup;++f){fb=back_buffer();bb_acquire();if(!jobs(r,f,fb,cpu,split,0)||bb_publish()!=BB_OK||bb_swap_wait(fb,200000)!=BB_OK)return 0;}
    uint64_t start=bb_ticks();uint32_t swap_start=bb_read(BB_SWAPS),uf=bb_read(BB_UNDERFLOWS);
    for(unsigned f=0;f<r->frames;++f){
        if(service_cancel())return 0;if(microseconds(bb_ticks()-start)>180000000u)return -1;
        fb=back_buffer();if(!fb)return 0;uint64_t draw=bb_ticks(),io_before=io_ticks;bb_acquire();
        if(!jobs(r,f,fb,cpu,split,m)||bb_publish()!=BB_OK)return 0;
        m->render+=microseconds(bb_ticks()-draw-(io_ticks-io_before));++m->frames;
        uint64_t wait=bb_ticks();if(bb_swap_wait(fb,200000)!=BB_OK)return 0;m->wait+=microseconds(bb_ticks()-wait);
    }
    m->elapsed=microseconds(bb_ticks()-start);m->swaps=bb_read(BB_SWAPS)-swap_start;m->uf=bb_read(BB_UNDERFLOWS)-uf;
    if(m->swaps!=r->frames)return 0;
    /* Timed counters are already frozen. Inspect the actual final displayed
       product BEFORE any replay can erase evidence. Never write the front.
       Earlier registered first/middle frames are deterministic BACK replays. */
    uint64_t check_start=bb_ticks();
    if(!copy_memory(LABX_REFERENCE,LABX_SNAPSHOT))return 0;expected(r,r->frames-1u);
    if(!verify_frame(bb_read(BB_FRONT),m))return 0;++m->actual;
    unsigned sample_frames[2]={0,r->frames/2u};
    for(unsigned sample=0;sample<2;++sample){unsigned f=sample_frames[sample];if(f==r->frames-1u||(sample&&f==sample_frames[sample-1]))continue;
        fb=back_buffer();bb_acquire();if(!jobs(r,f,fb,cpu,split,0)||bb_publish()!=BB_OK)return 0;
        if(!copy_memory(LABX_REFERENCE,LABX_SNAPSHOT))return 0;expected(r,f);if(!verify_frame(fb,m))return 0;++m->replayed;
    }
    m->check_us=microseconds(bb_ticks()-check_start);return 1;
}
static int show_results(uint32_t id){
    uint32_t fb=back_buffer();if(!fb||!panel(fb,screen_memory?"MEMORY: SAME IMAGE / SPLIT AND MERGED":"CPU / FPGA: SAME TASK ID / REAL SWAPS"))return 0;
    text_number(fb,32,174,"REQUEST ",id);text_number(fb,658,174,"CHECK ERRORS ",screen_cpu.errors+screen_hw.errors);
    text_number(fb,32,216,"FPS X100 ",screen_cpu.elapsed?(uint64_t)screen_cpu.swaps*100000000u/screen_cpu.elapsed:0);
    text_number(fb,658,216,"FPS X100 ",screen_hw.elapsed?(uint64_t)screen_hw.swaps*100000000u/screen_hw.elapsed:0);
    if(!screen_memory&&screen_hw.render&&screen_cpu.frames&&screen_hw.frames)text_number(fb,32,260,"DRAW SPEEDUP X100 ",screen_cpu.render*100u*screen_hw.frames/(screen_hw.render*screen_cpu.frames));
    text(fb,32,310,"CHECK: LAST DISPLAYED + FIRST / MIDDLE REPLAY",0x008e79,2);
    text(fb,32,344,"MEASURED SWAP FPS / VALIDATION IS SEPARATE",0x737d91,2);
    text(fb,32,390,"ALL CONTROL FROM PC / EXIT RETURNS TO TOUHOU",0x324264,2);
    return bb_publish()==BB_OK&&bb_swap_wait(fb,200000)==BB_OK;
}
static int settle_swap(void){
    uint64_t start=bb_ticks();while(bb_read(BB_DISPLAY_STATUS)&BB_SWAP_PENDING){labx_io_service();if(microseconds(bb_ticks()-start)>200000u)return 0;}return 1;
}
static int double_check_front(void){bb_acquire();for(unsigned y=0;y<720;++y){if(!(y&7u)&&service_cancel())return 0;
    for(unsigned x=0;x<1280;++x)double_errors+=ptr(double_front)[y*1280u+x]!=ptr(LABX_SNAPSHOT)[y*1280u+x];}return !double_errors;}
static int double_step(unsigned reset){
    if(reset||phase==0||phase==5){uint32_t fb=back_buffer();if(!fb||!panel(fb,"DOUBLE BUFFER / A IS FRONT"))return 0;
        text(fb,500,300,"A / FRONT",0x175ccd,5);if(bb_publish()!=BB_OK||bb_swap_wait(fb,200000)!=BB_OK)return 0;
        double_front=bb_read(BB_FRONT);double_back=back_buffer();double_swaps=bb_read(BB_SWAPS);double_errors=0;ready=0;phase=1;
        return copy_memory(LABX_SNAPSHOT,double_front);}
    if(phase==1){if(!fill(double_back,0,0,1280,360,0xd3e8ffu))return 0;phase=2;return double_check_front();}
    if(phase==2){if(!fill(double_back,0,360,1280,360,0xc5eee4u))return 0;text(double_back,480,300,"B / READY",0x175ccd,5);
        if(bb_publish()!=BB_OK)return 0;ready=1;phase=3;return double_check_front();}
    if(phase==3){if(!ready||!double_check_front()||bb_read(BB_FRONT)!=double_front||bb_read(BB_SWAPS)!=double_swaps||bb_read(BB_DISPLAY_STATUS)&BB_SWAP_PENDING)return 0;
        if(bb_publish()!=BB_OK)return 0;bb_write(BB_NEXT_FRONT,double_back);bb_write(BB_SWAP,1);phase=4;return 1;}
    if(phase==4){uint64_t start=bb_ticks();while((bb_read(BB_DISPLAY_STATUS)&BB_SWAP_PENDING)||bb_read(BB_FRONT)!=double_back||bb_read(BB_SWAPS)==double_swaps){
            if(service_cancel()||microseconds(bb_ticks()-start)>200000u)return 0;}
        phase=5;ready=1;return 1;}return 0;
}
void labx_service(void){
    if(!pending)return;Request r=request;pending=0;running=1;uint64_t start=bb_ticks();uint32_t uf=bb_read(BB_UNDERFLOWS);unsigned completed=0;const char *error=0;
    if(!settle_swap()){error="SWAP_TIMEOUT";}
    if(error){}
    else if(r.op==ENTER){active=1;phase=ready=0;uint32_t fb=back_buffer();if(!fb||!panel(fb,"MEMORY / DRIVER / DOUBLE BUFFER LAB" )||bb_swap_wait(fb,200000)!=BB_OK)error="ENGINE";}
    else if(r.op==EXIT){if(!restore||restore()!=0)error="RESTORE";else{active=0;phase=ready=0;}}
    else if(r.op==MEM||r.op==COMPARE){
        phase=ready=0;screen_memory=r.op==MEM;memset(&screen_cpu,0,sizeof screen_cpu);memset(&screen_hw,0,sizeof screen_hw);
        static const unsigned ws[]={128,512,960},hs[]={96,256,480};width=ws[r.size];height=hs[r.size];source_stride=width*4u;source_offset=r.layout==1?4u:r.layout==2?4092u:0u;
        if(!prepare_sources())error=cancelled?"CANCEL":"MEMORY";else{plan(&r);
            for(unsigned group=1;group<=r.repeats&&!error;++group)for(unsigned method=0;method<2&&!error;++method){
                unsigned cpu=r.op==COMPARE&&method==0;Measurement m;int ok=measured_run(&r,cpu,r.op==MEM&&method==0,&m);
                result(&r,group,cpu,r.op==MEM?(method?"merged":"split"):(r.kind?"image":"blocks"),&m,task_hash(&r));++completed;
                if(cpu||(r.op==MEM&&method==0))screen_cpu=m;else screen_hw=m;
                if(ok<=0)error=cancelled?"CANCEL":ok<0?"TIMEOUT":m.errors||m.guards||m.source?"VERIFY":"ENGINE";
            }
            if(!error&&!show_results(r.id))error="ENGINE";
        }
    }else if(r.op==DOUBLE){
        if(r.action==2){if(!double_step(1))error="ENGINE";else state(r.id);
            while(!error&&phase<5){if(service_cancel()){error="CANCEL";break;}
                if(!double_step(0))error=cancelled?"CANCEL":"VERIFY";else state(r.id);}
        }else{if(!double_step(r.action==0))error=cancelled?"CANCEL":"VERIFY";else state(r.id);}
    }
    if(!settle_swap())error="SWAP_TIMEOUT";running=0;if(cancelled&&(!error||strcmp(error,"SWAP_TIMEOUT")))error="CANCEL";
    terminal(&r,error&&!strcmp(error,"CANCEL")?"CANCELLED":error?"ERROR":"PASS",error?error:"OK",completed,microseconds(bb_ticks()-start),bb_read(BB_UNDERFLOWS)-uf);
    cancelled=0;
}
