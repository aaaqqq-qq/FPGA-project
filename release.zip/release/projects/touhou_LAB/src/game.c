#include "bsp.h"
#include "riscv.h"
#include "bitblt.h"
#include "segment_diag.h"
#include "scene.h"
#include "stage.h"
#include "font.h"
#include "remote_input.h"
#include "lab.h"
#include "labx.h"
#include "adv.h"
#include "game_config.h"
#include "tick_profile.h"
#include "motion_hw.h"
#include "pipe5_abi.h"
#include "pipe5_control.h"
#include "player.h"
#include "effects.h"
#include "art_ids.h"
#include "replay.h"
#include "enemies.h"
#include "layer_visuals.h"
#include <stdarg.h>
#include <string.h>

enum {MENU,PLAY,STRESS,CLEARED,LOST,DODGE};
extern unsigned scene_list_us,scene_batch_cycles;
static unsigned telemetry_pending,clock_reset_requested,stress_warmup_frames;
static unsigned play_warmup_frames,play_warmup_scan,play_warmup_swaps;
static uint64_t play_warmup_start;
static void telemetry(void);
static unsigned logic_us,overlap_us,stress_prepared,window_peak;
static unsigned validate_requested,validation_active,demo_invincible;
static RemoteInput remote;
static unsigned paused;
static unsigned mode=MENU,choice=0,capacity_level=14,difficulty,hardware=1,autoplay;
static const unsigned limits[]={64,128,256,512,1024,2048,4096,6144,8192,10240,12288,14336,16384,18432,20000};
static unsigned keys,edges,ticks,bomb_requests;
static unsigned frames,missed,underflows,peak_us,fps100,render_us,last_frame,window_frames,window_swaps,window_underflows,window_missed;
static uint64_t window_start;
static unsigned custom_limit,bench_hw_fps,bench_cpu_fps,bench_hw_n,bench_cpu_n;
static unsigned logic_drops,logic_overruns,logic_steps,frame_us,window_effect_drops;
static unsigned selected_limit(void){return custom_limit?custom_limit:limits[capacity_level];}
/* Subtract absolute converted timestamps: converting each raw interval first
   would discard up to 99 CLINT cycles every loop on the 100MHz baseline. */
static uint32_t frame_elapsed_us(uint64_t now,uint64_t before){return (uint32_t)(bb_us(now)-bb_us(before));}
static char tx[1536];static unsigned txpos,txlen,log_drops;
static unsigned runtime_tick,slowmo_remaining,slowmo_phase,dead_seen,last_frame_sprites;
static unsigned hud_render_sample,hud_sample_tick;
static unsigned replay_export_at,replay_export_active;
static unsigned presentation_revision;
static unsigned last_layer_commands,last_layer_clipped,last_layer_reordered;
static unsigned last_decor_jobs,last_decor_area,last_decor_dropped;
static unsigned profile_battle_us,profile_player_us,profile_collect_us,profile_flush_us,profile_hud_us;
static unsigned profile_battle_peak,profile_player_peak,profile_flush_peak,profile_hud_peak;
static unsigned last_fx_quality,last_fx_lod;
#define COMMAND_REPLY_CAP 16u
#define COMMAND_REPLY_BYTES 512u
static char command_rx[640],command_replies[COMMAND_REPLY_CAP][COMMAND_REPLY_BYTES];
static unsigned command_reply_head,command_reply_count,command_reply_overruns;
static unsigned command_len,command_since,command_overflow;
static unsigned deferred_ascii;
static char deferred_ascii_byte;
static unsigned pipe_world_locked,pipe_clock_active,pipe_live_epoch,pipe_live_input,pipe_input_base;
static unsigned pipe_backlog_peak,pipe_fallbacks,pipe_deferred_controls;
static unsigned pipe_prime_pending,pipe_finishing_frame;
static uint64_t pipe_logic_total,pipe_logic_phase;
static unsigned pipe_runtime_pending;
static void pipe_render_service(void);
static void pipe_barrier_commands(void);
static unsigned pipe_supported(void);
static void runtime_step(void);
static uint32_t runtime_state_hash(void);
static int replay_record_start(unsigned seed);
static int replay_start_playback(void);
static int replay_stop_recording(void);
static void service_command_output(void);
static void cancel_replay(void);
static void command_message(const char *message);
static void render(uint32_t fb);
static void tick_profile_report(unsigned request_id);
static void segment_diag_report(unsigned request_id);
static int game_lab_restore(void);
static void input(void);
static void labx_reply(const char *message);
static unsigned game_load_running,game_load_cancel;
static unsigned game_load_hud_fps100(void);
static int game_load_command(char *line);
static void game_load_ready(uint64_t swap_epoch);
static void game_load_after_swap(unsigned n,unsigned b,unsigned m);
static void game_load_finish(const char *status,const char *reason);
static void game_load_poll_cancel(void);
static unsigned game_load_report_blocked(void);
static void game_load_report_drain(void);
static void game_load_report_abort(void);
/* Prototypes also live in scene.h in the integrated renderer candidate. */
extern int scene_bullets_prepare(unsigned size);
extern void scene_bullets_reset(void);
extern int scene_bullets_guards_ok(void);

/* Integer-only formatter: avoid pulling a desktop printf/float runtime into BRAM. */
static unsigned textfmt(char *out,unsigned cap,const char *fmt,...){
    va_list ap;va_start(ap,fmt);unsigned n=0;
    while(*fmt&&n+1<cap){
        if(*fmt!='%'){out[n++]=*fmt++;continue;}
        ++fmt;unsigned width=0;if(*fmt=='0'){++fmt;width=(unsigned)(*fmt++-'0');}
        if(*fmt=='s'){const char *v=va_arg(ap,const char*);while(*v&&n+1<cap)out[n++]=*v++;++fmt;continue;}
        if(*fmt=='u'){char b[11];format_uint(b,va_arg(ap,unsigned));unsigned len=strlen(b);while(width>len&&n+1<cap){out[n++]='0';--width;}for(unsigned i=0;i<len&&n+1<cap;++i)out[n++]=b[i];++fmt;}
    }
    out[n]=0;va_end(ap);return n;
}
void fatal(const char *where,int error){game_load_report_abort();bsp_printf("\r\nFAIL %s %d\r\n",where,error);for(;;){}}
void trap(void){fatal("TRAP",csr_read(mcause));}
static void pump(void){if(txpos==txlen)service_command_output();unsigned n=uart_writeAvailability(BSP_UART_TERMINAL);while(n--&&txpos<txlen)uart_write(BSP_UART_TERMINAL,tx[txpos++]);}
static void reset_stats(void){window_effect_drops=effects_drop_total;telemetry_pending=0;profile_battle_peak=profile_player_peak=profile_flush_peak=profile_hud_peak=0;frames=missed=underflows=peak_us=window_peak=0;last_frame=bb_read(BB_FRAMES);window_frames=last_frame;window_swaps=bb_read(BB_SWAPS);window_underflows=bb_read(BB_UNDERFLOWS);window_missed=0;window_start=bb_ticks();}
static void start(void){
    scene_pipe_set_service(pipe_render_service);
    pipe_clock_active=0;pipe_live_epoch=pipe_live_input=0;pipe_backlog_peak=pipe_fallbacks=0;
    stress_prepared=0;overlap_us=0;bomb_requests=0;edges=0;paused=0;clock_reset_requested=1;
    runtime_tick=slowmo_remaining=slowmo_phase=dead_seen=0;
    hud_render_sample=hud_sample_tick=0;
    scene_hud_invalidate();
    mode=choice==5?DODGE:choice>=3?STRESS:PLAY;hardware=choice!=4;difficulty=choice%3;ticks=0;
    stress_warmup_frames=(mode==STRESS&&hardware)?2:0;
    play_warmup_frames=(mode==PLAY&&hardware)?2:0;
    if(play_warmup_frames){play_warmup_start=bb_ticks();play_warmup_scan=bb_read(BB_FRAMES);play_warmup_swaps=bb_read(BB_SWAPS);}
    logic_drops=logic_overruns=logic_steps=0;
    if(!scene_bullets_prepare(mode==PLAY?game_cfg.enemy_bullet_size:8)){mode=MENU;command_message("ERR bullet preparation");return;}
    if(mode==PLAY){
        battle_set_legacy(0);battle_materials=1;
        player_reset(PLAYER_START_X,PLAYER_START_Y);
        battle_reset(difficulty,selected_limit());
        enemies_reset(game_cfg.enemy_count);
        effects_reset();
    }else if(mode==DODGE){
        enemies_reset(0);
        battle_set_legacy(0);battle_materials=0;
        player_reset(PLAYER_START_X,PLAYER_START_Y);
        player.lives=3;player.bombs=3;
        stage_stress(selected_limit());
        effects_reset();
    }else{
        enemies_reset(0);
        battle_set_legacy(0);battle_materials=0;
        player_reset(PLAYER_START_X,PLAYER_START_Y);
        stage_stress(selected_limit());
        effects_reset();
    }
    tick_profile_restart();reset_stats();
}
static unsigned poll_controls(void){
    remote_input_expire(&remote,bb_us(bb_ticks()));return 1;
}
int bb_cpu_service(void){
    if(adv_active()||adv_pending())return adv_cpu_poll();
    if(labx_active()||labx_pending())return labx_cpu_poll();
    if(pipe_world_locked){pump();input();return 0;}
    poll_controls();
    if(validation_active)return 0;
    pump();
    /* Heartbeats must not cancel a long CPU reference render every 75ms.
       Decode only binary state here; defer the first text byte and any game
       mutation until the outer loop has cancelled this frame. */
    if(deferred_ascii)return 1;
    unsigned budget=64;
    while(budget--&&uart_readOccupancy(BSP_UART_TERMINAL)){
        uint8_t byte=(uint8_t)uart_read(BSP_UART_TERMINAL);
        if(!remote_input_feed(&remote,byte,bb_us(bb_ticks()))){
            deferred_ascii=1;deferred_ascii_byte=(char)byte;return 1;
        }
    }
    return (remote.pressed&(REMOTE_BOMB|REMOTE_PAUSE|REMOTE_START|REMOTE_MENU))!=0;
}
static void show_menu(void){
    tick_profile_stop();pipe_clock_active=0;bomb_requests=edges=keys=paused=0;mode=MENU;hardware=1;
    clock_reset_requested=1;scene_hud_invalidate();reset_stats();command_message("UI MENU");
}
/* Prepare both backbuffers before advancing a fresh round's fixed clock.
   Preparation is reported separately; no gameplay tick is discarded. */
static unsigned render_warmup_pending(void){return hardware&&((mode==STRESS&&stress_warmup_frames)||(mode==PLAY&&play_warmup_frames));}
static void render_warmup_advance(void){
    if(!render_warmup_pending())return;
    if(mode==STRESS)--stress_warmup_frames;
    else if(!--play_warmup_frames){
        char ready[144];
        textfmt(ready,sizeof(ready),"PLAY_READY prepare_us=%u scan=%u swaps=%u ticks=%u",bb_us(bb_ticks()-play_warmup_start),bb_read(BB_FRAMES)-play_warmup_scan,bb_read(BB_SWAPS)-play_warmup_swaps,ticks);
        command_message(ready);
    }
    if(!render_warmup_pending())reset_stats();
}
static void buttons(void){
    poll_controls();
    unsigned pressed=remote_input_pressed(&remote);
    if(lab_active()||lab_pending()||labx_active()||labx_pending()||adv_active()||adv_pending()){keys=edges=bomb_requests=0;return;}
    if(game_load_running){if(pressed&REMOTE_MENU)game_load_cancel=1;keys=edges=bomb_requests=0;return;}
    keys=remote.held&15u;edges=0;
    if(pressed&REMOTE_MENU){cancel_replay();show_menu();return;}
    if(pressed&REMOTE_START){cancel_replay();start();return;}
    if((pressed&REMOTE_PAUSE)&&(mode==PLAY||mode==DODGE||mode==STRESS)){
        paused^=1;clock_reset_requested=1;scene_hud_invalidate();
    }
    /* Actions are edge events. Heartbeats and catch-up ticks never repeat a
       bomb; opposite directions have no special board-button meaning. */
    if((pressed&REMOTE_BOMB)&&!paused&&(mode==PLAY||mode==DODGE)&&replay_state()!=REPLAY_PLAYING)
        if(bomb_requests<255)++bomb_requests;
}
static void command_message(const char *message){
    if(command_reply_count==COMMAND_REPLY_CAP){++command_reply_overruns;return;}
    char *reply=command_replies[(command_reply_head+command_reply_count)%COMMAND_REPLY_CAP];
    unsigned n=0;while(message[n]&&n+3<COMMAND_REPLY_BYTES){reply[n]=message[n];++n;}
    reply[n++]='\r';reply[n++]='\n';reply[n]=0;++command_reply_count;
}
static void service_command_output(void){
    if(game_load_report_blocked())return;
    if(command_reply_count){const char *reply=command_replies[command_reply_head];txlen=(unsigned)strlen(reply);memcpy(tx,reply,txlen+1);txpos=0;command_reply_head=(command_reply_head+1)%COMMAND_REPLY_CAP;--command_reply_count;return;}
    if(command_reply_overruns){txlen=textfmt(tx,sizeof(tx),"ERR reply queue overflow count=%u\r\n",command_reply_overruns);txpos=0;command_reply_overruns=0;return;}
    if(replay_export_active){
        uint32_t word=0;
        if(replay_export_at<replay_export_words()&&replay_export_word(replay_export_at,&word)==REPLAY_OK){
            txlen=textfmt(tx,sizeof(tx),"REPLAY_WORD %u %u\r\n",replay_export_at++,word);txpos=0;
        }else {replay_export_active=0;txlen=textfmt(tx,sizeof(tx),"REPLAY_END %u\r\n",replay_export_at);txpos=0;}
    }
}
static int decimal_value(const char *s,unsigned *out){
    unsigned n=0;if(!*s)return 0;
    while(*s){unsigned d=(unsigned)(*s++-'0');if(d>9||n>429496729u||(n==429496729u&&d>5))return 0;n=n*10+d;}
    *out=n;return 1;
}
static void command_line(char *line){
    if(!strcmp(line,"hello")){
        remote_input_init(&remote);keys=edges=bomb_requests=0;
        char caps[320];
        unsigned hw_caps=bb_read(0x4c);
        textfmt(caps,sizeof(caps),"CAPS fw=LAB23 proto=2 controls=PC lab=1 labx=1 adv=1 img=1 perf=1 game_load=1 gsizes=7 tprof=1 width=1280 height=720 hz=60 batch32=%u motion=%u pref=%u pipe=%u pref8=%u hud_dma=%u hud_dma_proof=1 segprof=1",(hw_caps&4u)?1u:0u,(hw_caps&16u)?1u:0u,(hw_caps&8u)?1u:0u,(hw_caps&32u)?1u:0u,(hw_caps&64u)?1u:0u,hud_dma_tail_enabled);
        command_message(caps);return;
    }
    if(!strncmp(line,"gload",5)&&(line[5]==' '||!line[5])){game_load_command(line);return;}
    if(!strncmp(line,"timing",6)&&(line[6]==' '||!line[6])){
        if(mode!=MENU||game_load_running){command_message("ERR timing requires idle menu");return;}
        if(!strcmp(line,"timing 0")){tick_profile_enable(0);command_message("OK timing 0");}
        else if(!strcmp(line,"timing 1")){tick_profile_enable(1);command_message("OK timing 1");}
        else if(!strcmp(line,"timing report")){tick_profile_stop();tick_profile_report(0);}
        else command_message("ERR timing syntax: timing 0|1|report");
        return;
    }
    if(game_load_running){if(!strcmp(line,"menu"))game_load_cancel=1;else command_message("ERR GAME_LOAD active; cancel first");return;}
    if(!strncmp(line,"adv",3)){if(adv_command(line))return;}
    if((adv_active()||adv_pending())&&(!strncmp(line,"labx",4)||!strncmp(line,"lab ",4))){command_message("ERR adv active; exit adv first");return;}
    if(!strncmp(line,"labx",4)){
        if(labx_command(line))return;
    }
    if((labx_active()||labx_pending())&&!strncmp(line,"lab ",4)){command_message("ERR labx active; exit labx first");return;}
    if(lab_command(line))return;
    if(lab_active()||lab_pending()||labx_active()||labx_pending()||adv_active()||adv_pending()){command_message("ERR lab active; exit lab first");return;}
    if(!strcmp(line,"menu")){cancel_replay();show_menu();return;}
    const char *pc_commands[]={"mode","limit","pause","autoplay","invincible","backend","validate"};
    for(unsigned i=0;i<sizeof(pc_commands)/sizeof(pc_commands[0]);++i){
        unsigned n=(unsigned)strlen(pc_commands[i]);
        if(strncmp(line,pc_commands[i],n)||line[n]!=' ')continue;
        unsigned value;char msg[80];
        if(!decimal_value(line+n+1,&value)) {command_message("ERR invalid value; unchanged");return;}
        if(i!=2&&(replay_state()==REPLAY_RECORDING||replay_state()==REPLAY_PLAYING)){
            command_message("ERR replay active; stop or menu first");return;
        }
        if(i==0){
            if(value>5){command_message("ERR mode range 0..5");return;}
            choice=value;start();textfmt(msg,sizeof(msg),"OK mode %u",value);
        }else if(i==1){
            if(mode!=MENU){command_message("ERR limit requires menu");return;}
            if(!value||value>SHOT_CAPACITY){command_message("ERR limit range 1..20000");return;}
            custom_limit=value;if(mode==STRESS||mode==DODGE)start();
            textfmt(msg,sizeof(msg),"OK limit %u",value);
        }else if(i==2){
            if(value>1){command_message("ERR pause range 0..1");return;}
            paused=value;clock_reset_requested=1;scene_hud_invalidate();
            textfmt(msg,sizeof(msg),"OK paused %u",paused);
        }else if(i==3||i==4){
            if(value>1){command_message("ERR boolean range 0..1");return;}
            if(i==3)autoplay=value;else demo_invincible=value;
            scene_hud_invalidate();
            textfmt(msg,sizeof(msg),i==3?"OK autoplay %u":"OK invincible %u",value);
        }else if(i==5){
            if(value>1){command_message("ERR backend range 0..1");return;}
            hardware=value;clock_reset_requested=1;stress_prepared=0;
            stress_warmup_frames=(mode==STRESS&&hardware)?2:0;
            scene_hud_invalidate();reset_stats();
            command_message(hardware?"OK backend FPGA":"OK backend CPU");return;
        }else{
            if(value<1||value>2){command_message("ERR validate range 1..2");return;}
            validate_requested=value;textfmt(msg,sizeof(msg),"OK validate %u",value);
        }
        command_message(msg);return;
    }
    if(!strncmp(line,"set ",4)){
        if(replay_state()==REPLAY_RECORDING||replay_state()==REPLAY_PLAYING){command_message("ERR replay active; stop first");return;}
        char *field=line+4,*sep=strchr(field,' ');unsigned value;
        if(!sep){command_message("ERR usage: set field value");return;}
        *sep++=0;
        if(!strcmp(field,"tick_profile")){
            if(mode!=MENU||!decimal_value(sep,&value)||value>1){command_message("ERR tick_profile requires menu and 0|1");return;}
            tick_profile_enable(value);command_message("OK set");return;
        }
        if((!strcmp(field,"hud_dma_tail_enabled")||!strcmp(field,"boss_count")||!strcmp(field,"enemy_count")||!strcmp(field,"background_depth_enabled")||!strcmp(field,"enemy_bullet_size"))&&mode!=MENU){command_message("ERR topology requires menu");return;}
        GameConfig old_cfg=game_cfg;
        if(!decimal_value(sep,&value)||!game_config_set(field,value)){command_message("ERR invalid field/value; unchanged");return;}
        if(!strcmp(field,"enemy_bullet_size")&&!scene_bullets_prepare(value)){game_cfg=old_cfg;command_message("ERR bullet preparation; unchanged");return;}
        ++presentation_revision;
        if(!strcmp(field,"background_depth_enabled")){scene_init();clock_reset_requested=1;reset_stats();}
        scene_hud_invalidate();command_message("OK set");return;
    }
    if(!strcmp(line,"record")||!strncmp(line,"record ",7)){
        unsigned seed=0x6e697468u;
        if(line[6]&&(!decimal_value(line+7,&seed))){command_message("ERR seed");return;}
        command_message(replay_record_start(seed)==REPLAY_OK?"OK record started (normal/live)":"ERR record state");return;
    }
    if(!strcmp(line,"stop")){
        int ok=replay_stop_recording();command_message(ok==REPLAY_OK?"OK record saved":"ERR not recording");return;
    }
    if(!strcmp(line,"replay")){command_message(replay_start_playback()==REPLAY_OK?"OK replay started":"ERR replay validation/config");return;}
    if(!strcmp(line,"replay dump")){
        if(replay_state()!=REPLAY_READY&&replay_state()!=REPLAY_FINISHED){command_message("ERR stop recording/playback first");return;}
        replay_export_at=0;replay_export_active=1;command_message("REPLAY_BEGIN");return;
    }
    if(!strcmp(line,"replay status")){
        char msg[128];textfmt(msg,sizeof(msg),"REPLAY_STATUS state=%u error=%u events=%u ticks=%u",replay_state(),(unsigned)(-replay_status()),replay_header()->event_count,replay_header()->final_tick);command_message(msg);return;
    }
    command_message("ERR unknown command");
}
static void cancel_replay(void){
    if(replay_state()==REPLAY_RECORDING)replay_stop_recording();
    else if(replay_state()==REPLAY_PLAYING)replay_abort();
}
static void uart_character(char c){
    if(!command_len){
        if(c==':'){command_rx[0]=c;command_len=1;command_since=bb_us(bb_ticks());}
        return; /* Unprefixed legacy bytes, noise and lost binary headers are inert. */
    }
    if(c=='\r'||c=='\n'){
        if(command_overflow)command_message("ERR command too long; ignored");
        else {command_rx[command_len]=0;command_len=0;if(pipe_world_locked){if(!pipe5_cli_push(command_rx+1))fatal("PIPE CLI OVERFLOW",-1);}else command_line(command_rx+1);}
        command_len=command_overflow=0;return;
    }
    if((unsigned char)c<32||(unsigned char)c>126){command_len=command_overflow=0;return;}
    if(command_len+1<sizeof(command_rx))command_rx[command_len++]=c;else command_overflow=1;
}
static void input(void){
    unsigned budget=1024;
    if(deferred_ascii){deferred_ascii=0;uart_character(deferred_ascii_byte);}
    while(budget--&&uart_readOccupancy(BSP_UART_TERMINAL)){
        uint8_t byte=(uint8_t)uart_read(BSP_UART_TERMINAL);
        uint64_t received=bb_ticks();unsigned accepted=remote.accepted,duplicates=remote.duplicates;
        if(!remote_input_feed(&remote,byte,bb_us(received)))uart_character((char)byte);
        if(pipe_world_locked&&(accepted!=remote.accepted||duplicates!=remote.duplicates)){
            unsigned pressed=remote_input_pressed(&remote);
            if(!pipe5_input_record(received,remote.held,pressed))fatal("PIPE INPUT OVERFLOW",-1);
        }
    }
    /* Abandoned ASCII input cannot be completed by a later session. */
    if(command_len&&(uint32_t)(bb_us(bb_ticks())-command_since)>=500000u)
        command_len=command_overflow=0;
    if(!pipe_world_locked)buttons();
}
static void pipe_render_service(void){pump();input();}
/* LAB23 is the only owner while this cooperative pump is active. Binary
   controls are consumed but ignored by buttons(); text can only status/cancel. */
void labx_io_service(void){pump();input();}
void adv_io_service(void){pump();input();}
static void labx_reply(const char *message){
    /* Lossless bounded backpressure outside measured drawing time. */
    while(command_reply_count==COMMAND_REPLY_CAP)pump();
    command_message(message);
}
static int abs_i(int x){return x<0?-x:x;}

static void player_movement(void){
    if(autoplay){player.x=ARENA_W/2+turn_sin(ticks*90)*(ARENA_W/2-64)/32768;player.y=PLAYER_START_Y;}
    else {if((keys&3)!=3)player.x+=((keys&2)?PLAYER_SPEED:0)-((keys&1)?PLAYER_SPEED:0);if((keys&12)!=12)player.y+=((keys&8)?PLAYER_SPEED:0)-((keys&4)?PLAYER_SPEED:0);}
    if(player.x<PLAYER_MIN_X)player.x=PLAYER_MIN_X;if(player.x>PLAYER_MAX_X)player.x=PLAYER_MAX_X;
    if(player.y<PLAYER_MIN_Y)player.y=PLAYER_MIN_Y;if(player.y>PLAYER_MAX_Y)player.y=PLAYER_MAX_Y;
}
static void bomb(void){
    if(!bomb_requests)return;
    --bomb_requests;
    if(!player.bombs)return;
    --player.bombs;
    player.bomb_invuln=game_cfg.bomb_invuln_ticks>player.bomb_invuln?game_cfg.bomb_invuln_ticks:player.bomb_invuln;
    if(mode==PLAY){
        stage.count=0;enemies_bomb(game_cfg.bomb_damage);
        for(unsigned k=0;k<game_cfg.boss_count&&k<MAX_BOSSES;++k)battle_apply_damage(k,(int)game_cfg.bomb_damage,2);
    }
}
static int stress_lives_hit(void){
    unsigned near_ok=stage_near_ready(player.x,player.y);
    unsigned n=near_ok?stage_near_count:stage.count;
    for(unsigned j=0;j<n;++j){unsigned i=near_ok?stage_near_indices[j]:j;Shot *b=&stage.shots[i];
        int dy=abs_i(b->y/Q-player.y);if(dy>=14)continue;int dx=abs_i(b->x/Q-player.x);
        if((mode==DODGE||b->age>=16)&&dx<5&&dy<5&&player_can_be_hit(demo_invincible)){
            if(player.lives)--player.lives;
            player.hit_invuln=player.hit_invuln>150?player.hit_invuln:150;
            fx_player_hit(player.x,player.y);
            if(!player.lives)mode=LOST;
            return 1;
        }
        if(dx<14&&dy<14&&!b->grazed){b->grazed=1;++player.graze;player_add_score(game_cfg.graze_score);fx_graze(player.x,player.y);}
    }
    return 0;
}

static void resolve_outcome(void){
    if(mode!=PLAY)return;
    if(!player_alive()){mode=LOST;enemies_clear_all();}
    else if(battle_all_defeated()){
        enemies_clear_all();
        /* Keep the final defeat visible for the same 200ms ceremony. */
        if(!game_cfg.death_slowmo_enabled||!slowmo_remaining)mode=CLEARED;
    }
}

static void logic_play_tail(uint64_t tp_total,uint64_t phase_begin){
    uint64_t tp_part;
    tp_part=tick_profile_begin();
    if(!battle_all_defeated())enemies_tick(ticks,player.x,player.y);
    unsigned enemy_contact=enemies_contact_hit(player.x,player.y);
    tick_profile_end(TP_ENEMY,tp_part);tp_part=tick_profile_begin();
    player_fire_tick(ticks);
    tick_profile_end(TP_PLAYER_FIRE,tp_part);tp_part=tick_profile_begin();
    player_shots_tick();
    tick_profile_end(TP_PLAYER_SHOTS,tp_part);
    profile_player_us+=bb_us(bb_ticks()-phase_begin);
    tp_part=tick_profile_begin();
    for(unsigned k=0;k<game_cfg.boss_count&&k<MAX_BOSSES;++k)if(bosses[k].dead&&!(dead_seen&(1u<<k))){
        dead_seen|=1u<<k;
        unsigned owned=0;for(unsigned j=0;j<stage.count;++j)if(stage.owner[j]==k)++owned;
        unsigned cap=game_cfg.death_star_budget;if(cap>8)cap=8;
        unsigned stride=cap?(owned+cap-1)/cap:owned+1,seen=0,drawn=0;
        for(unsigned j=0;j<stage.count&&drawn<cap;++j)if(stage.owner[j]==k){
            if((seen++%stride)==0){fx_cancel_star(stage.shots[j].x/Q,stage.shots[j].y/Q);++drawn;}
        }
        battle_clear_owner(k);
        if(game_cfg.death_slowmo_enabled){slowmo_remaining=game_cfg.death_slowmo_ticks;slowmo_phase=0;}
    }
    tick_profile_end(TP_OWNER_DEATH,tp_part);tp_part=tick_profile_begin();
    if(battle_grazes){player.graze+=battle_grazes;player_add_score(battle_grazes*game_cfg.graze_score);fx_graze(player.x,player.y);}
    if((battle_hit||enemy_contact)&&player_can_be_hit(demo_invincible)){
        int lost=player_take_hit((int)game_cfg.player_hit_damage);
        if(lost)fx_player_hit(player.x,player.y);
    }
    int hp_before=player.hp;
    player_regen_tick();
    if(player.hp>hp_before)fx_regen(player.x,player.y);
    if(player_update_level())fx_levelup(player.x,player.y);
    effects_tick();
    tick_profile_end(TP_VITALS_FX,tp_part);tp_part=tick_profile_begin();
    if(battle_load_active)battle_load_refill(stage.limit);
    tick_profile_end(TP_REFILL,tp_part);
    ++ticks;
    resolve_outcome();tick_profile_end(TP_TOTAL,tp_total);
}
static void logic(void){
    if(mode==STRESS){if(stress_prepared)stress_prepared=0;else stage_stress_step();++ticks;return;}
    if(mode!=PLAY&&mode!=DODGE)return;
    motion_hw_set_enabled(hardware); /* pure CPU comparison cannot use OP3 */
    uint64_t tp_total=tick_profile_begin(),tp_part=tick_profile_begin();
    player_begin_tick();
    player_movement();
    bomb();
    tick_profile_end(TP_CONTROL,tp_part);
    if(mode==DODGE){
        if(stress_prepared)stress_prepared=0;else stage_stress_step_near(player.x,player.y);
        stress_lives_hit();
        if(mode==DODGE){
            ++ticks;
            if(ticks>=ROUND_FRAMES&&!demo_invincible){player_add_score(50000);mode=CLEARED;}
        }
        effects_tick();tick_profile_end(TP_TOTAL,tp_total);
        return;
    }
    uint64_t phase_begin=bb_ticks();
    battle_step(player.x,player.y);
    profile_battle_us+=bb_us(bb_ticks()-phase_begin);phase_begin=bb_ticks();
    logic_play_tail(tp_total,phase_begin);

}

/* Replay hashes authoritative logic only: no wall clock, renderer, UART or
 * cosmetic RNG. All hashed structs are reset before a recording starts. */
static uint32_t hash_bytes(uint32_t h,const void *data,unsigned bytes){
    const unsigned char *p=(const unsigned char *)data;
    for(unsigned i=0;i<bytes;++i)h=(h^p[i])*16777619u;
    return h;
}
static uint32_t runtime_config_hash(void){uint32_t h=hash_bytes(2166136261u,&game_cfg,sizeof(game_cfg));return hud_dma_tail_enabled?hash_bytes(h,&hud_dma_tail_enabled,sizeof(hud_dma_tail_enabled)):h;}
static uint32_t runtime_state_hash(void){
    uint32_t h=2166136261u;
    unsigned values[]={mode,ticks,runtime_tick,stage.count,stage.frame,stage.seed,stage.requested,stage.emitted,stage.rejected,
        summon_done,battle_cleared,battle_hit,battle_grazes,slowmo_remaining,slowmo_phase,dead_seen};
    h=hash_bytes(h,values,sizeof(values));h=hash_bytes(h,&player,sizeof(player));
    h=hash_bytes(h,player_shots,sizeof(player_shots));h=hash_bytes(h,bosses,sizeof(bosses));
    h=hash_bytes(h,stage.shots,stage.count*sizeof(Shot));h=hash_bytes(h,stage.owner,stage.count);
    h=battle_state_hash(h);h=enemies_state_hash(h);
    return h;
}
static int replay_record_start(unsigned seed){
    if(replay_state()==REPLAY_RECORDING||replay_state()==REPLAY_PLAYING)return REPLAY_E_STATE;
    replay_export_active=0;choice=0;demo_invincible=autoplay=0;start();keys=edges=bomb_requests=0;
    stage.seed=seed;
    return replay_record_begin(seed,runtime_config_hash());
}
static int replay_start_playback(void){
    if(replay_state()==REPLAY_RECORDING||replay_state()==REPLAY_PLAYING)return REPLAY_E_STATE;
    unsigned seed=replay_header()->seed;
    int result=replay_play_begin(runtime_config_hash());if(result!=REPLAY_OK)return result;
    replay_export_active=0;choice=0;demo_invincible=autoplay=0;start();keys=edges=bomb_requests=0;stage.seed=seed;
    return REPLAY_OK;
}
static int replay_stop_recording(void){
    if(replay_state()!=REPLAY_RECORDING)return REPLAY_E_STATE;
    return replay_record_end(runtime_tick,runtime_state_hash());
}
static int runtime_prepare(void){
    if(paused)return 0;
    unsigned state=replay_state();
    if(state==REPLAY_ERROR)return 0;
    if(state==REPLAY_PLAYING){
        unsigned recorded_keys=0,recorded_bombs=0;
        int next=replay_play_input(runtime_tick,&recorded_keys,&recorded_bombs);
        if(next<=0){
            if(!next)replay_play_end(runtime_state_hash());
            command_message(replay_status()==REPLAY_OK?"REPLAY PASS state hash":"ERR replay mismatch");return 0;
        }
        keys=recorded_keys;edges=0;bomb_requests=recorded_bombs;
    }else if(state==REPLAY_RECORDING){
        if(replay_record_input(runtime_tick,keys,bomb_requests)!=REPLAY_OK){command_message("ERR replay overflow/input; recording stopped");return 0;}
    }
    if(slowmo_remaining&&(mode==PLAY)){
        --slowmo_remaining;
        unsigned divisor=game_cfg.death_slowmo_divisor?game_cfg.death_slowmo_divisor:1;
        if(++slowmo_phase%divisor){++runtime_tick;return 0;}
    }
    return 1;
}
static void runtime_finish(void){
    ++runtime_tick;
    if(replay_state()==REPLAY_RECORDING&&(mode==CLEARED||mode==LOST))replay_stop_recording();
    else if(replay_state()==REPLAY_PLAYING&&(mode==CLEARED||mode==LOST)){
        int ok=replay_play_end(runtime_state_hash());
        command_message(ok==REPLAY_OK?"REPLAY PASS state hash":"ERR replay outcome/tick mismatch");
    }
}
static void runtime_step(void){if(!runtime_prepare())return;logic();runtime_finish();}
/* Same authoritative runtime split only at the enemy-motion DMA boundary.
   Control and Boss ECL execute once; no player/owner/FX work crosses acquire. */
static void runtime_pipe_begin(unsigned snapshot){
    if(pipe_runtime_pending)fatal("PIPE TICK ACTIVE",-1);
    if(!runtime_prepare())return;
    if(mode!=PLAY){logic();runtime_finish();return;}
    motion_hw_set_enabled(hardware);
    pipe_logic_total=tick_profile_begin();uint64_t part=tick_profile_begin();
    player_begin_tick();player_movement();bomb();tick_profile_end(TP_CONTROL,part);
    pipe_logic_phase=bb_ticks();
    if(battle_step_begin(player.x,player.y,snapshot)){pipe_runtime_pending=1;return;}
    profile_battle_us+=bb_us(bb_ticks()-pipe_logic_phase);
    logic_play_tail(pipe_logic_total,bb_ticks());runtime_finish();
}
static void runtime_pipe_complete(void){
    if(!pipe_runtime_pending)return;
    while(!battle_step_poll()){pump();input();scene_pipe_check_fault();}
    profile_battle_us+=bb_us(bb_ticks()-pipe_logic_phase);
    logic_play_tail(pipe_logic_total,bb_ticks());runtime_finish();pipe_runtime_pending=0;
}

static void number(int x,int y,unsigned n,unsigned color,unsigned scale){char b[12];format_uint(b,n);scene_text(x,y,b,color,scale);}
static const char *boss_state_name(unsigned s){
    switch(s){
    case BOSS_WAIT:return "WAIT";case BOSS_ENTER:return "ENTER";case BOSS_NORMAL:return "ACTIVE";
    case BOSS_ENRAGE_INTRO:return "WARNING";case BOSS_ENRAGED:return "ENRAGED";default:return "DEFEATED";
    }
}
static unsigned visible_boss_count(void){
    if(mode!=PLAY&&mode!=CLEARED&&mode!=LOST)return 0;
    unsigned n=0;for(unsigned k=0;k<game_cfg.boss_count&&k<MAX_BOSSES;++k)n+=bosses[k].state!=BOSS_WAIT&&bosses[k].state!=BOSS_DEAD;
    return n;
}
static unsigned visible_actor_count(void){
    if(mode!=PLAY&&mode!=CLEARED&&mode!=LOST)return 0;
    return visible_boss_count()+enemies_active_count()+((mode==PLAY||mode==CLEARED)&&player_alive());
}
static unsigned next_threshold(unsigned level){
    if(level>=game_cfg.max_level||level>=5)return 0;
    return game_cfg.level_threshold[level+1];
}
#include "hud_frozen.inc"

static void menu_panel(void){
    scene_rect(PANEL_X,PANEL_Y,PANEL_W,mode==MENU?84:PANEL_H,0x121326);
    if(mode==MENU){
        static const char *modes[]={"NORMAL PHASE BATTLE","HARD PHASE BATTLE","LUNATIC PHASE BATTLE","SPRITE STRESS - FPGA","SPRITE STRESS - CPU","200 SECOND DODGE"};
        scene_text(PANEL_X+18,PANEL_Y+20,modes[choice],0x8bd3d8,1);
        scene_text(PANEL_X+18,PANEL_Y+46,demo_invincible?"INVINCIBLE ON":"INVINCIBLE OFF",0xf5cf77,1);
    }else{
    const char *title=mode==CLEARED?(choice==5?"DODGE CLEARED":"PHASE CLEAR"):mode==LOST?"CHALLENGE OVER":"NIGHT SIGN";
    scene_text(PANEL_X+18,PANEL_Y+14,title,0xf0cc8d,2);
    scene_text(PANEL_X+18,PANEL_Y+40,"RUMIA / CIRNO / HONG MEILING",0xf1e5ef,1);

        char line[64];
        textfmt(line,sizeof(line),"SCORE %u",player.score);scene_text(PANEL_X+18,PANEL_Y+72,line,0xe9e5f2,1);
        textfmt(line,sizeof(line),"LEVEL %u   GRAZE %u",player.power_level,player.graze);scene_text(PANEL_X+18,PANEL_Y+92,line,0xe9e5f2,1);
        textfmt(line,sizeof(line),"TIME %us",ticks/60);scene_text(PANEL_X+18,PANEL_Y+112,line,0xe9e5f2,1);
        scene_text(PANEL_X+18,PANEL_Y+146,"ENTER: RESTART",0xc3bbd5,1);
        scene_text(PANEL_X+18,PANEL_Y+164,"ESC: MENU",0xc3bbd5,1);
        if(demo_invincible)scene_text(PANEL_X+18,PANEL_Y+190,"TEST/DEMO GUARD WAS ON",0xf5cf77,1);
    }
}

/* A finished round has no moving field state. Keep one complete image in
   each framebuffer; the independently tracked HUD can continue updating. */
static unsigned terminal_key,terminal_banks,terminal_revision;
typedef struct {unsigned old_mode,terminal,reuse_terminal,bank_bit,fx_quality,fx_lod;} RenderFrozen;
static RenderFrozen render_frozen;
static void render_capture(uint32_t fb,unsigned deferred){
    unsigned terminal=(mode==LOST||mode==CLEARED)&&hardware&&!validation_active;
    unsigned key=mode|(demo_invincible<<4)|(choice<<8)|(hardware<<12);
    if(!terminal||key!=terminal_key||terminal_revision!=presentation_revision){terminal_banks=0;terminal_key=key;terminal_revision=presentation_revision;}
    unsigned bank_bit=fb==BB_FB1?2u:1u;
    unsigned reuse_terminal=terminal&&(terminal_banks&bank_bit);
    scene_hud_cache_enable(game_cfg.hud_dirty_enabled);
    unsigned dodge_ui=mode==DODGE||((mode==CLEARED||mode==LOST)&&choice==5);
    scene_set_batch(mode==PLAY||mode==STRESS||mode==DODGE||mode==CLEARED||mode==LOST);
    scene_begin(fb,hardware);
    unsigned batch_scene=mode==PLAY||mode==STRESS||mode==DODGE||mode==CLEARED||mode==LOST;
    if(batch_scene&&!reuse_terminal){if(deferred)scene_batch_shots_deferred();else scene_batch_shots();}
    unsigned layered=game_cfg.layer_pipeline_enabled&&(mode==PLAY||mode==DODGE||mode==CLEARED||mode==LOST);
    scene_layers_begin(layered);
    if(!scene_layer_order(game_cfg.layer_order))fatal("LAYER ORDER",-1);
    unsigned live_shots=0;
    if(layered)for(unsigned i=0;i<PLAYER_SHOT_CAPACITY;++i)live_shots+=!!player_shots[i].live;
    unsigned quality=effects_quality;
    if(!reuse_terminal)quality=effects_render_budget(game_cfg.render_budget_enabled&&layered&&!dodge_ui,visible_boss_count(),live_shots,stage.count,frame_us);
    layer_visuals_quality(quality);
    layer_visuals_strength(game_cfg.layer_visuals_strength);
    layer_visuals_begin(ticks,layered&&game_cfg.layer_visuals_enabled&&!dodge_ui,player.x,player.y);
    if(mode==STRESS&&hardware&&!paused&&!stress_warmup_frames&&!validation_active&&game_cfg.stress_overlap_enabled&&!stress_prepared&&!scene_pipe_fallback()){
        scene_batch_snapshot_ready();
        uint64_t prepared_begin=bb_ticks();stage_stress_step();
        overlap_us=bb_us(bb_ticks()-prepared_begin);stress_prepared=1;
    }else overlap_us=0;
    if(telemetry_pending&&!validation_active){telemetry_pending=0;if(!game_load_running)telemetry();}

    uint64_t collect_begin=bb_ticks();
    unsigned actor_alpha=game_cfg.opaque_sprites?255:240;
    if(!reuse_terminal&&(mode==PLAY||mode==DODGE||mode==CLEARED||mode==LOST)){
        scene_layer(SCENE_LAYER_SHADOW,0);
        if(!dodge_ui){
            if(player_alive()&&(mode==PLAY||mode==CLEARED))layer_visuals_shadow(player.x,player.y+23,22);
            for(unsigned k=0;k<game_cfg.boss_count&&k<MAX_BOSSES;++k)
                if(bosses[k].state!=BOSS_WAIT&&bosses[k].state!=BOSS_DEAD)
                    layer_visuals_shadow(bosses[k].x,bosses[k].y+(k%3==1?32:24),k%3==1?28:24);
            scene_layer(SCENE_LAYER_DECOR,0);
            if(player_alive()&&(mode==PLAY||mode==CLEARED))layer_visuals_glow(player.x,player.y);
        }
        if(mode==PLAY||mode==CLEARED||mode==LOST){
            if(!dodge_ui)enemies_render();
            scene_layer(SCENE_LAYER_PROJECTILE,0);
            for(unsigned i=0;i<PLAYER_SHOT_CAPACITY;++i)if(player_shots[i].live)
                scene_tile(32+player_shots[i].x-7,16+player_shots[i].y-7,player_shots[i].kind==PLAYER_KIND_HOMING?50:40,actor_alpha);
        }
        if(!dodge_ui)for(unsigned k=0;k<game_cfg.boss_count&&k<MAX_BOSSES;++k){
            unsigned s=bosses[k].state;
            if(s==BOSS_WAIT||s==BOSS_DEAD)continue;
            unsigned type=k%3;unsigned tile=type==0?4+((ticks/8)&3):type==1?43+(ticks/10)%3:47;
            int w=type==0?16:24,h=type==0?24:type==1?32:24;
            scene_layer(SCENE_LAYER_ACTOR,game_cfg.layer_y_sort?bosses[k].y+h:0);
            scene_tile(32+bosses[k].x-w,16+bosses[k].y-h,tile,actor_alpha);
            if(s==BOSS_ENTER){
                scene_layer(SCENE_LAYER_WORLD_UI,0);
                static const char *enter_names[]={"RUMIA","CIRNO","MEILING","RUMIA II","CIRNO II","MEILING II"};const char *nm=enter_names[k];
                scene_text(32+bosses[k].x-18,16+bosses[k].y-46,nm,0xe9e5f2,1);
            }
        }
        if(!dodge_ui){
            scene_layer(SCENE_LAYER_EFFECT,0);
            effects_render();unsigned warning=0;
            for(unsigned k=0;k<game_cfg.boss_count&&k<MAX_BOSSES;++k)if(bosses[k].state==BOSS_ENRAGE_INTRO)warning=1;
            effects_vignette(ticks,player.hp,player.max_hp,warning);
        }
        if(player_alive()&&(mode==PLAY||mode==CLEARED||mode==DODGE)){
            unsigned frame=(ticks/8)&3;
            int blink=player.hit_invuln&&(ticks&4);
            scene_layer(SCENE_LAYER_ACTOR,game_cfg.layer_y_sort?player.y+23:0);
            if(!blink){
                if(player.hit_flash)scene_tile(32+player.x-15,16+player.y-23,ART_WHITE_PLAYER0+frame,255);
                else scene_tile(32+player.x-15,16+player.y-23,frame,actor_alpha);
            }
            unsigned point=effects_hitpoint_color(player.hp,player.max_hp,ticks);
            scene_layer(SCENE_LAYER_OVERLAY,0);
            if(player.hp>0&&(unsigned)player.hp<game_cfg.low_hp_threshold){
                scene_rect(32+player.x-2,16+player.y-2,5,5,point);
                point=0xffffff;
            }
            scene_rect(32+player.x-1,16+player.y-1,3,3,point);
            if(player.upgrade_anim){
                char up[20];textfmt(up,sizeof(up),"POWER UP LV%u",player.power_level);
                scene_text(32+player.x-28,16+player.y-56,up,0x80cfff,1);
            }
        }
        scene_layer(SCENE_LAYER_FOREGROUND,0);
        layer_visuals_foreground();
    }
    if(paused&&(mode==PLAY||mode==DODGE||mode==STRESS)){
        scene_layer(SCENE_LAYER_OVERLAY,0);
        scene_text(PANEL_X+90,PANEL_Y+108,"PAUSED - SPACE",0xe9e5f2,2);
    }
    profile_collect_us=bb_us(bb_ticks()-collect_begin);
    if(deferred)scene_batch_resolve(); /* exact fallback before HUD/snapshot ownership transfer */
    /* Right HUD can use the CPU while OP2 composes the disjoint field.
       scene_hud_begin keeps queued layers intact only for that safe case;
       all other render modes retain its synchronous flush fallback. */
    uint64_t hud_begin=bb_ticks();
    scene_pipe_defer_hud(deferred);
    if(mode!=MENU){if(deferred&&!scene_pipe_fallback())hud_freeze_deferred();else hud();}
    profile_hud_us=bb_us(bb_ticks()-hud_begin);
    render_frozen=(RenderFrozen){mode,terminal,reuse_terminal,bank_bit,effects_quality,reuse_terminal?0:effects_lod_jobs};
}
static void render_draw_frozen_hud(void){uint64_t begin=bb_ticks();hud_emit_deferred();scene_layers_prepare();scene_pipe_draw_hud();profile_hud_us+=bb_us(bb_ticks()-begin);}
static void render_complete(void){
    uint64_t flush_begin=bb_ticks();scene_layers_flush();profile_flush_us=bb_us(bb_ticks()-flush_begin);
    if(segment_diag_active&&!scene_pipe_fallback())segment_diag_cut(SD_ACTOR_TAIL);
    uint64_t hud_begin=bb_ticks();
    if(render_frozen.old_mode==MENU||((render_frozen.old_mode==LOST||render_frozen.old_mode==CLEARED)&&!render_frozen.reuse_terminal))menu_panel();
    scene_end();last_frame_sprites=scene_sprite_count;
    profile_hud_us+=bb_us(bb_ticks()-hud_begin);
    last_fx_quality=render_frozen.fx_quality;last_fx_lod=render_frozen.fx_lod;
    last_layer_commands=scene_layer_commands;last_layer_clipped=scene_layer_clipped;last_layer_reordered=scene_layer_reordered;
    last_decor_jobs=layer_visuals_jobs;last_decor_area=layer_visuals_area;last_decor_dropped=layer_visuals_dropped;
    if(render_frozen.terminal&&!scene_cancelled())terminal_banks|=render_frozen.bank_bit;
}
static void render(uint32_t fb){render_capture(fb,0);render_complete();}
/* Experiments draw into the same framebuffers. Rebuild both banks and reset
 * scene damage/HUD/terminal history before handing display ownership back. */
static int game_lab_restore(void){
    uint32_t front=bb_read(BB_FRONT);
    if(front!=BB_FB0&&front!=BB_FB1)return -1;
    uint32_t back=front==BB_FB0?BB_FB1:BB_FB0;
    cancel_replay();show_menu();stress_prepared=0;
    terminal_key=terminal_banks=terminal_revision=0;
    scene_init();scene_hud_invalidate();remote_input_init(&remote);
    /* Build only the non-scanned bank, swap at vblank, then rebuild the bank
       just retired. Never restore a test card by drawing into scanout. */
    render(back);if(scene_cancelled())return -1;
    if(bb_swap_wait(back,2000000)!=BB_OK)return -1;
    render(front);if(scene_cancelled())return -1;
    bb_write(BB_DISPLAY_CTRL,1);clock_reset_requested=1;reset_stats();return 0;
}

static void validate_renderers(void){
    unsigned battle=validate_requested==2;validate_requested=0;validation_active=1;bb_write(BB_DISPLAY_CTRL,0);
    choice=battle?0:3;custom_limit=4096;start();
    unsigned saved_demo=demo_invincible;
    demo_invincible=1; /* explicit test guard, reported in telemetry */
    if(battle){for(unsigned f=0;f<120;++f)logic();}
    for(unsigned frame=0;frame<3;++frame){
        if(battle)logic();else stage_stress_step();hardware=0;render(BB_FB0);hardware=1;render(BB_FB1);bb_acquire();
        unsigned errors=0,first=0;uint32_t crc=2166136261u;
        for(unsigned y=16;y<704;++y)for(unsigned x=32;x<1056;++x){
            unsigned offset=y*BB_SCREEN_STRIDE+x*4;
            uint32_t a=*(volatile uint32_t *)(uintptr_t)(BB_FB0+offset),b=*(volatile uint32_t *)(uintptr_t)(BB_FB1+offset);
            crc=(crc^b)*16777619u;if(a!=b){if(!errors)first=offset;++errors;}
        }
        /* Right-side HUD is part of the frame and must match in both modes. */
        for(unsigned y=118;y<704;++y)for(unsigned x=1072;x<1280;++x){
            unsigned offset=y*BB_SCREEN_STRIDE+x*4;
            uint32_t a=*(volatile uint32_t *)(uintptr_t)(BB_FB0+offset),b=*(volatile uint32_t *)(uintptr_t)(BB_FB1+offset);
            crc=(crc^b)*16777619u;if(a!=b){if(!errors)first=offset;++errors;}
        }
        char report[192];textfmt(report,sizeof(report),"BATCH_COMPARE frame=%u N=%u errors=%u first=%u hash=%u battle=%u guard=1\r\n",frame,stage.count,errors,first,crc,battle);bsp_printf("%s",report);
        if(errors)fatal("BATCH PIXELS",errors);
    }
    if(bb_swap_wait(BB_FB1,2000000))fatal("VALIDATE SWAP",-1);
    demo_invincible=saved_demo;bb_write(BB_DISPLAY_CTRL,1);validation_active=0;reset_stats();
}

static void telemetry(void){
    uint32_t frame,scan_before,swap_total;
    do{scan_before=bb_read(BB_FRAMES);swap_total=bb_read(BB_SWAPS);frame=bb_read(BB_FRAMES);}while(scan_before!=frame);
    uint32_t delta=frame-last_frame;last_frame=frame;
    if(delta>1)missed+=delta-1;++frames;
    uint64_t now=bb_ticks();uint32_t elapsed=bb_us(now-window_start);
    if(elapsed<2000000)return;
    unsigned swaps=swap_total-window_swaps,scan=frame-window_frames;
    fps100=(uint32_t)((uint64_t)swaps*100000000/elapsed);
    if(mode==STRESS){if(hardware){bench_hw_fps=fps100;bench_hw_n=stage.count;}else{bench_cpu_fps=fps100;bench_cpu_n=stage.count;}}
    unsigned uf=bb_read(BB_UNDERFLOWS)-window_underflows;underflows+=uf;
    unsigned bhp=0,enraged_mask=0;
    for(unsigned k=0;k<game_cfg.boss_count&&k<MAX_BOSSES;++k){
        if(bosses[k].hp>0)bhp+=(unsigned)bosses[k].hp;
        if(bosses[k].enraged)enraged_mask|=1u<<k;
    }
    if(txpos==txlen){
        txlen=textfmt(tx,sizeof(tx),"STAT mode=%u hw=%u N=%u limit=%u fps100=%u swaps=%u scan=%u us=%u frame=%u logic=%u render=%u max=%u window_peak=%u missed=%u uf=%u emitted=%u req=%u rejected=%u prej=%u keys=%u drops=%u px=%u py=%u bhp=%u php=%u lv=%u bombs=%u b0=%u b1=%u b2=%u s0=%u s1=%u s2=%u enr=%u summon=%u fx=%u/%u fxo=%u ldrop=%u lover=%u runtime=%u slow=%u dens=%u ncan=%u nfb=%u hret=%u hudrows=%u hudjobs=%u fxdrop=%u list=%u batchcy=%u overlap=%u scan_total=%u swap_total=%u bosses=%u mobs=%u actors=%u sprites=%u kills=%u b3=%u b4=%u b5=%u s3=%u s4=%u s5=%u layer=%u ysort=%u qcmd=%u qclip=%u qsort=%u decor=%u darea=%u ddrop=%u vstr=%u bg=%u opaque=%u rb=%u qly=%u lod=%u b_us=%u p_us=%u c_us=%u f_us=%u h_us=%u b_pk=%u p_pk=%u f_pk=%u h_pk=%u fw=LAB23 paused=%u control=PC adv=1 img=1 perf=1\r\n",
            mode,hardware,stage.count,stage.limit,fps100,swaps,scan,(unsigned)elapsed,frame_us,logic_us,render_us,peak_us,window_peak,missed-window_missed,uf,stage.emitted,stage.requested,stage.rejected,player.shot_rejections,keys,log_drops,player.x,player.y,bhp,(unsigned)player.hp,player.power_level,player.bombs,
            (unsigned)bosses[0].hp,(unsigned)bosses[1].hp,(unsigned)bosses[2].hp,(unsigned)bosses[0].state,(unsigned)bosses[1].state,(unsigned)bosses[2].state,
            enraged_mask,summon_done,effects_jobs,effects_area,effects_over_budget,logic_drops,logic_overruns,runtime_tick,slowmo_remaining,battle_density_slow,battle_near_candidates,battle_near_fallbacks,player_homing_retargets,scene_hud_restored_rows,scene_hud_redraw_jobs,effects_drop_total-window_effect_drops,scene_list_us,scene_batch_cycles,overlap_us,frame,swap_total,game_cfg.boss_count,enemies_active_count(),visible_actor_count(),last_frame_sprites,enemies_kills,(unsigned)(game_cfg.boss_count>3?bosses[3].hp:0),(unsigned)(game_cfg.boss_count>4?bosses[4].hp:0),(unsigned)(game_cfg.boss_count>5?bosses[5].hp:0),(unsigned)bosses[3].state,(unsigned)bosses[4].state,(unsigned)bosses[5].state,game_cfg.layer_pipeline_enabled,game_cfg.layer_y_sort,last_layer_commands,last_layer_clipped,last_layer_reordered,last_decor_jobs,last_decor_area,last_decor_dropped,game_cfg.layer_visuals_strength,game_cfg.battle_gather_enabled,game_cfg.opaque_sprites,game_cfg.render_budget_enabled,last_fx_quality,last_fx_lod,profile_battle_us,profile_player_us,profile_collect_us,profile_flush_us,profile_hud_us,profile_battle_peak,profile_player_peak,profile_flush_peak,profile_hud_peak,paused);txpos=0;
    }else ++log_drops;
    window_start=now;window_frames=frame;window_swaps=swap_total;window_underflows=bb_read(BB_UNDERFLOWS);window_missed=missed;window_peak=0;profile_battle_peak=profile_player_peak=profile_flush_peak=profile_hud_peak=0;window_effect_drops=effects_drop_total;
}
static void tick_profile_report(unsigned request_id){
    TickProfileInfo info=tick_profile_info();
    if(info.active){command_message("ERR timing report requires stopped window");return;}
    char msg[256];
    textfmt(msg,sizeof msg,"TICK_PROFILE id=%u epoch=%u enabled=%u active=%u timer_hz=%u read_min=%u read_max=%u overflow=%u nested_clear=1",
        request_id,info.epoch,info.enabled,info.active,info.timer_hz,info.read_min,info.read_max,info.overflow);
    while(command_reply_count==COMMAND_REPLY_CAP){pump();}
    command_message(msg);
    static const char *names[TP_PHASES]={"control","boss_ecl","motion_contact","ordinary_enemy","player_fire","player_shots","owner_death","clear_owner_nested","vitals_fx","gload_refill","total"};
    for(unsigned i=0;i<TP_PHASES;++i){
        TickPhase p=tick_profile_phase(i);
        textfmt(msg,sizeof msg,"TICK_PHASE id=%u epoch=%u phase=%s calls=%u sum_lo=%u sum_hi=%u max=%u last=%u",
            request_id,info.epoch,names[i],p.calls,(unsigned)p.sum,(unsigned)(p.sum>>32),p.maximum,p.last);
        while(command_reply_count==COMMAND_REPLY_CAP){pump();}
        command_message(msg);
    }
}
#include "pipe5_frame.inc"
#include "segment_diag_report.inc"
#include "game_load.inc"
#include "pipe5_runtime.inc"

int main(void){
    game_config_defaults();
    bsp_init();remote_input_init(&remote);
    bsp_printf("\r\nPHASE BATTLE v3 LAB23 PC CONTROL GAME60_PIPELINE_5\r\n");
    if(bb_probe())fatal("PROBE",-1);motion_hw_init();if(!battle_scratch_init())fatal("CONTACT INIT",-1);bb_write(BB_DISPLAY_CTRL,0);scene_init();if(!battle_scratch_guards_ok())fatal("CONTACT GUARD",-1);lab_init(command_message,game_lab_restore);labx_init(labx_reply,game_lab_restore);adv_init(labx_reply,game_lab_restore);
    bsp_printf("Phase battle: Rumia solo -> enrage summon -> three bosses; player HP/regen/LV. capacity=20000.\r\n");
    battle_set_legacy(0);battle_materials=0;stage_reset(0,selected_limit());
    render(BB_FB0);render(BB_FB1);if(bb_swap_wait(BB_FB0,2000000))fatal("INITIAL SWAP",-1);bb_write(BB_DISPLAY_CTRL,1);reset_stats();
    uint64_t last=bb_ticks();uint32_t acc_us=0;
    for(;;){
        unsigned pipeline=pipe_supported()&&!render_warmup_pending();
        if(pipeline)pipe_world_locked=1;
        pump();input();
        if(pipeline){
            pipe_world_locked=0;pipe_barrier_commands();
            if(pipe_supported()&&!render_warmup_pending()){pipe_frame();last=bb_ticks();acc_us=0;clock_reset_requested=0;continue;}
        }
        game_load_report_drain(); /* Serialized path cannot leave reserved samples pending. */
        game_load_poll_cancel();
        if(lab_active()||lab_pending()||labx_active()||labx_pending()||adv_active()||adv_pending()){
            if(adv_active()||adv_pending())adv_service();else if(labx_active()||labx_pending())labx_service();else lab_service();keys=edges=bomb_requests=0;remote_input_init(&remote);
            last=bb_ticks();acc_us=0;clock_reset_requested=1;continue;
        }
        if(validate_requested){validate_renderers();last=bb_ticks();acc_us=0;continue;}
        if(render_warmup_pending()||paused){last=bb_ticks();acc_us=0;}
        if(clock_reset_requested){last=bb_ticks();acc_us=0;clock_reset_requested=0;}
        uint64_t now=bb_ticks();uint32_t delta=frame_elapsed_us(now,last);last=now;
        if(delta>1000000)delta=1000000;
        acc_us+=delta*60u; /* exact rational 60Hz; units are 1/60 microsecond */
        profile_battle_us=profile_player_us=0;
        uint64_t logic_begin=bb_ticks();
        unsigned steps=0,allowed=game_cfg.logic_max_catchup+1;
        while(acc_us>=1000000u&&steps<allowed){runtime_step();acc_us-=1000000u;++steps;}
        if(acc_us>=1000000u){logic_drops+=acc_us/1000000u;acc_us%=1000000u;++logic_overruns;}
        logic_us=bb_us(bb_ticks()-logic_begin);logic_steps=steps;
        /* A prepared tick is future state until the next fixed tick consumes it.
           Never submit that state on an iteration with zero logic steps. */
        if(mode==STRESS&&hardware&&stress_prepared&&!steps&&!paused)continue;
        uint32_t front=bb_read(BB_FRONT),back=front==BB_FB0?BB_FB1:BB_FB0;
        if(front!=BB_FB0&&front!=BB_FB1)fatal("FRONT",front);
        unsigned measured_n=stage.count,measured_b=visible_boss_count(),measured_m=enemies_fighting_count();
        uint64_t render_begin=bb_ticks();
        render(back);if(scene_cancelled())continue;
        render_us=bb_us(bb_ticks()-render_begin);frame_us=logic_us+render_us;
        if(profile_battle_us>profile_battle_peak)profile_battle_peak=profile_battle_us;
        if(profile_player_us>profile_player_peak)profile_player_peak=profile_player_us;
        if(profile_flush_us>profile_flush_peak)profile_flush_peak=profile_flush_us;
        if(profile_hud_us>profile_hud_peak)profile_hud_peak=profile_hud_us;
        if(frame_us>peak_us)peak_us=frame_us;if(frame_us>window_peak)window_peak=frame_us;
        if(bb_swap_wait(back,2000000))fatal("SWAP",-1);
        if(render_warmup_pending()){
            /* The second prepared swap is the measured interval boundary.
               Snapshot it before READY formatting; charge that work to the
               interval, and make the first real simulation tick due at T0. */
            uint64_t swap_epoch=bb_ticks();
            if(game_load_running&&mode==PLAY&&play_warmup_frames==1&&!gl.pipe)game_load_ready(swap_epoch);
            render_warmup_advance();
            if(game_load_running&&gl.pipe&&!render_warmup_pending())pipe_clock_reset(swap_epoch,1);
            if(game_load_running&&gl.ready){last=swap_epoch;acc_us=1000000u;}
            else {last=bb_ticks();acc_us=0;}
        }else {if(game_load_running)game_load_after_swap(measured_n,measured_b,measured_m);else telemetry_pending=1;}
    }
}

