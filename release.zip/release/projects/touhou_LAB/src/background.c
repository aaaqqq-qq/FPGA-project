#include "background.h"
#define FIELD_W 1024u
#define FIELD_H 688u
static uint16_t far_ridge[FIELD_W],mid_ridge[FIELD_W],pine_ridge[FIELD_W];
static uint32_t sky_color[488],ground_color[FIELD_H-488];
static int16_t ground_rays[FIELD_H-522][7];
static unsigned prepared,enabled;
static uint32_t hash32(uint32_t x){x^=x>>16;x*=0x7feb352du;x^=x>>15;x*=0x846ca68bu;return x^(x>>16);}
static unsigned noise(unsigned x,unsigned period,unsigned seed){
 unsigned i=x/period,f=x%period,a=hash32(i+seed)&255u,b=hash32(i+1+seed)&255u;
 return (a*(period-f)+b*f)/period;
}
static uint32_t rgb(unsigned r,unsigned g,unsigned b){return (r<<16)|(g<<8)|b;}
static uint32_t mix(uint32_t a,uint32_t b,unsigned n,unsigned d){
 return rgb((((a>>16)&255u)*(d-n)+((b>>16)&255u)*n)/d,
            (((a>>8)&255u)*(d-n)+((b>>8)&255u)*n)/d,
            ((a&255u)*(d-n)+(b&255u)*n)/d);
}
void background_prepare(unsigned depth_enabled){
 enabled=!!depth_enabled;prepared=1;
 for(unsigned x=0;x<FIELD_W;++x){
  far_ridge[x]=(uint16_t)(263+noise(x,192,37)/4+noise(x,71,91)/8);
  mid_ridge[x]=(uint16_t)(337+noise(x,148,121)/5+noise(x,43,15)/12);
  unsigned ridge=486;
  int cell=(int)(x/40);
  for(int n=cell-1;n<=cell+1;++n){
   unsigned h=hash32((unsigned)(n+1024)+55);int center=n*40+8+(int)(h&23u);
   int d=(int)x-center;if(d<0)d=-d;
   unsigned width=14+((h>>8)&15u),peak=412+((h>>16)&47u);
   if((unsigned)d<width){unsigned edge=peak+(unsigned)d*65/width;if(edge<ridge)ridge=edge;}
  }
  pine_ridge[x]=(uint16_t)ridge;
 }
 for(unsigned y=0;y<FIELD_H;++y){
  unsigned k=y<430?y:430;
  if(y<488)sky_color[y]=mix(0x080e25u,0x23394fu,k,430);
  unsigned d=y>472?y-472:0;if(d>215)d=215;
  if(y>=488)ground_color[y-488]=mix(0x112a36u,0x091a29u,d,215);
  if(y>=522)for(unsigned n=0;n<7;++n){int delta=((int)n-3)*200;ground_rays[y-522][n]=(int16_t)(512+delta*((int)y-430)/258);}
 }
}
static uint32_t classic_pixel(unsigned x,unsigned y){
 unsigned shade=(y-16)*14/688,c=((10+shade)<<16)|((13+shade)<<8)|(30+shade*2);
 int mx=(int)x-955,my=(int)y-92;if(mx*mx+my*my<44*44)c=0x3a3948;
 if(mx*mx+my*my<40*40)c=0x625f70;
 unsigned h=x*19349663u^y*73856093u;if((h&2047)==7&&y<290)c=0x7c7a94;
 int edge=x<544?(int)x-32:1055-(int)x;if(edge<(int)((y/23*17+9)%29)&&y>180)c=0x080e18;
 return c;
}
uint32_t background_pixel(unsigned screen_x,unsigned screen_y){
 if(screen_x>=1280||screen_y>=720)return 0x0b0d1cu;
 if(screen_x==30||screen_x==1057)return 0x64607cu;
 if(screen_x<32||screen_x>=1056||screen_y<16||screen_y>=704)return 0x0b0d1cu;
 if(!prepared)background_prepare(1);
 if(!enabled)return classic_pixel(screen_x,screen_y);
 unsigned x=screen_x-32,y=screen_y-16;
 uint32_t c=y<488?sky_color[y]:ground_color[y-488];
 /* Large, quiet moon halo: bounded region, no per-frame blend pass. */
 if(x>744&&y<220){
  int dx=(int)x-866,dy=(int)y-96;unsigned d=(unsigned)(dx*dx+dy*dy);
  if(d<112u*112u)c=mix(c,0x40546fu,112u*112u-d,112u*112u*3u);
  if(d<34u*34u){
   c=mix(0x889bb2u,0x6e839fu,y<96?0:((y-96)>34?34:y-96),68);
   int ax=dx+11,ay=dy-7,bx=dx-13,by=dy+12;
   if(ax*ax+ay*ay<8*8||bx*bx+by*by<6*6)c=mix(c,0x526b89u,1,5);
  }
 }
 if(y<265){unsigned h=hash32(x+y*FIELD_W+0x1987u);if((h&4095u)==9)c=0x4d607cu;}
 /* Three silhouettes are precomputed once. Haze separates their depths. */
 if(y>=far_ridge[x])c=mix(0x233b53u,0x1c334au,y>355?90:y-263,184);
 if(y>=mid_ridge[x])c=0x162e40u;
 if(y>=pine_ridge[x])c=0x0c2432u;
 if(y>=394&&y<415)c=mix(c,0x294454u,(y<404?y-394:414-y),32);
 if(y>=464&&y<487)c=mix(c,0x284451u,(y<475?y-464:486-y),44);
 if(y>=488){
  c=ground_color[y-488];
  /* Sparse perspective grid below the action horizon; dark enough for white,
     cyan and red projectiles to remain the dominant foreground. */
  if(y>=522){
   for(unsigned n=0;n<7;++n)if((int)x==ground_rays[y-522][n]){c=0x1b3342u;break;}
   if(y==526||y==551||y==587||y==631||y==685)c=mix(c,0x203a46u,1,3);
  }
  /* Moonlight on a narrow central path, with quiet broken paving edges. */
  int dist=(int)x-512;if(dist<0)dist=-dist;
  unsigned half=(y-430)/3;
  if((unsigned)dist<half)c=mix(c,0x203442u,1,8);
 }
 /* Near silhouettes only at the two sides: central combat stays uncluttered. */
 if(y>350&&(x<90||x>934)){
  unsigned side=x<90?x:1023-x;
  unsigned trunk=19+(hash32(side/18+73)&7u);
  if(side%24<trunk/5&&y>365+(side*7)%85)c=0x071923u;
  if(y>568+side/2)c=mix(c,0x06151fu,1,2);
 }
 return c;
}
