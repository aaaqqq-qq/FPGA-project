#pragma once
#include <stdint.h>
void scene_init(void);
int scene_art_info(unsigned tile,uint32_t *address,unsigned *width,unsigned *height);
void scene_begin(uint32_t fb,unsigned hardware);
void scene_tile(int x,int y,unsigned tile,unsigned alpha);
void scene_rect(int x,int y,int w,int h,uint32_t color);
void scene_text(int x,int y,const char *text,uint32_t color,unsigned scale);
void scene_end(void);
extern unsigned scene_jobs;
void fatal(const char *where,int error);

void scene_set_batch(unsigned enabled);
void scene_batch_shots(void);
void scene_batch_shots_deferred(void);
void scene_batch_resolve(void);
void scene_batch_snapshot_ready(void);
/* Call while applying menu settings, before starting a measurement window.
   These change presentation only; Shot layout, movement and contact stay exact. */
int scene_bullets_prepare(unsigned size);
void scene_bullets_reset(void);
int scene_bullets_guards_ok(void);

unsigned scene_cancelled(void);

/* Wrap HUD submissions in begin/end; normal scene_text/rect are captured. */
void scene_hud_begin(void);
void scene_hud_end(void);
void scene_hud_invalidate(void);
void scene_hud_cache_enable(unsigned enabled);
extern unsigned scene_hud_restored_rows,scene_hud_redraw_jobs;

extern unsigned scene_sprite_count;

/* Sparse post-batch world layers. The background/enemy batch is a fixed base
   node; it is never split or replayed through this command queue. */
enum {
    SCENE_LAYER_SHADOW=0, SCENE_LAYER_DECOR, SCENE_LAYER_ACTOR,
    SCENE_LAYER_PROJECTILE, SCENE_LAYER_EFFECT, SCENE_LAYER_FOREGROUND,
    SCENE_LAYER_WORLD_UI, SCENE_LAYER_OVERLAY, SCENE_LAYER_COUNT
};
void scene_layers_begin(unsigned enabled);
void scene_layer(unsigned layer,int depth);
void scene_layers_flush(void);
void scene_layers_prepare(void);
void scene_clip(int x,int y,int w,int h);
void scene_clip_reset(void);
int scene_layer_order(const unsigned ranks[SCENE_LAYER_COUNT]);
extern unsigned scene_layer_commands,scene_layer_peak,scene_layer_clipped,scene_layer_reordered;

/* Sequential external MMIO job: drain renderer, invalidate shadow cache. */
void scene_external_begin(void);
/* PIPE5 keeps this frame's captured RQ and owned HUD text immutable while
 * its independent motion job updates only the following game state. */
#define SCENE_PIPE5_API 1
void scene_pipe_set_service(void (*service)(void));
void scene_pipe_defer_hud(unsigned enabled);
void scene_pipe_draw_hud(void);
unsigned scene_pipe_snapshot_epoch(void);
unsigned scene_pipe_frame_epoch(void);
unsigned scene_pipe_fallback(void);
void scene_pipe_check_fault(void);
typedef struct {unsigned epoch,count,alpha,flags,key,material;} SceneSubmission;
SceneSubmission scene_pipe_submission(void);
