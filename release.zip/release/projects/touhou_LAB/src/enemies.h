#pragma once
#include <stdint.h>
#include "player.h"

#define ENEMY_CAPACITY 12u
#define ENEMY_OWNER_BASE 128u
#define ENEMY_BLUE_TILE_BASE 83u
#define ENEMY_PINK_TILE_BASE 87u
#define ENEMY_KILL_SCORE 200u
enum { ENEMY_WAIT,ENEMY_ENTER,ENEMY_ACTIVE,ENEMY_EXIT };
typedef struct {
    int x,y,hp,max_hp,anchor_x,anchor_y;
    unsigned state,age,next_spawn,generation,fire_wait,grazed,hit_flash;
} OrdinaryEnemy;
extern OrdinaryEnemy ordinary_enemies[ENEMY_CAPACITY];
extern unsigned enemies_kills,enemies_spawns,enemies_despawns;
extern unsigned enemies_requested,enemies_spawned,enemies_rejected,enemies_volleys_deferred;
extern unsigned enemies_bullets_cleared,enemies_config_rejections;

void enemies_reset(unsigned count); /* clamps to12, records invalid request */
void enemies_tick(unsigned tick,int player_x,int player_y);
void enemies_render(void);
unsigned enemies_active_count(void);
unsigned enemies_configured_count(void);
int enemies_hit_shot(PlayerShot *shot); /* consumes live shot once on hit */
int enemies_contact_hit(int player_x,int player_y); /* root applies unified HP damage */
unsigned enemies_apply_damage(unsigned index,unsigned damage);
unsigned enemies_bomb(unsigned damage);
void enemies_clear_all(void); /* no score; clear owned bullets and stop respawn */
uint32_t enemies_state_hash(uint32_t initial); /* excludes render/cosmetic work */

void enemies_load_begin(void);
unsigned enemies_fighting_count(void);
