#include "effects.h"
#include "battle.h"
#include "game_config.h"
#include "scene.h"
#include "art_ids.h"
#include <string.h>

/* Generated atlas IDs live in art_ids.h; the 54..69 8x8 DMA material block is
   never reused for rings or silhouettes. */

typedef struct {
    uint8_t kind, active;
    int16_t x, y;
    uint16_t age, life;
} Fx;

#define FX_CAP 32
static Fx fx[FX_CAP];
static unsigned fx_overflow,graze_wait;
unsigned effects_jobs, effects_area, effects_over_budget, effects_active;
unsigned effects_drop_total;
unsigned effects_quality,effects_lod_jobs;
static unsigned quality_recovery;

unsigned effects_render_budget(unsigned enabled,unsigned active_bosses,
                               unsigned live_player_shots,unsigned enemy_bullets,
                               unsigned previous_frame_us){
    effects_lod_jobs=0;
    if(!enabled){effects_quality=quality_recovery=0;return 0;}
    unsigned high=active_bosses>=3||live_player_shots>=32||
                  enemy_bullets>=512||previous_frame_us>14000;
    unsigned low=active_bosses<=2&&live_player_shots<=16&&
                 enemy_bullets<=256&&previous_frame_us<12000;
    if(high){effects_quality=1;quality_recovery=0;}
    else if(effects_quality){
        if(low){if(++quality_recovery>=60){effects_quality=0;quality_recovery=0;}}
        else quality_recovery=0;
    }
    return effects_quality;
}

void effects_reset(void) {
    memset(fx, 0, sizeof(fx));
    effects_jobs = effects_area = effects_over_budget = effects_active = 0;
    fx_overflow = 0;graze_wait=0;effects_drop_total=0;
    effects_quality=effects_lod_jobs=quality_recovery=0;
}

static void fx_add(unsigned kind, int x, int y, unsigned life) {
    for (unsigned i = 0; i < FX_CAP; ++i) if (!fx[i].active) {
        fx[i].kind = (uint8_t)kind; fx[i].x = (int16_t)x; fx[i].y = (int16_t)y;
        fx[i].age = 0; fx[i].life = (uint16_t)life; fx[i].active = 1;
        return;
    }
    /* Cosmetic particles cannot reserve the last slot from a gameplay cue. */
    if(kind!=FX_GRAZE&&kind!=FX_CANCEL_STAR)for(unsigned i=0;i<FX_CAP;++i)
        if(fx[i].kind==FX_GRAZE||fx[i].kind==FX_CANCEL_STAR){
            fx[i]=(Fx){(uint8_t)kind,1,(int16_t)x,(int16_t)y,0,(uint16_t)life};return;
        }
    ++fx_overflow;
}

void fx_player_hit(int x, int y) {
    fx_add(FX_PLAYER_HIT, x, y, 14);
    fx_add(FX_RING_WARN, x, y, 10);
}
void fx_levelup(int x, int y) { fx_add(FX_LEVELUP, x, y, game_cfg.upgrade_ticks); }
void fx_regen(int x, int y) { fx_add(FX_REGEN, x, y, 18); }
void fx_boss_enrage_start(unsigned k) {
    if (k >= MAX_BOSSES) return;
    fx_add(FX_RING_WARN, bosses[k].x, bosses[k].y, game_cfg.enrage_intro_ticks);
}
void fx_boss_enrage_finish(unsigned k) {
    if (k >= MAX_BOSSES) return;
    fx_add(FX_RING_BURST, bosses[k].x, bosses[k].y, 26);
}
void fx_boss_enter(unsigned k) {
    if (k >= MAX_BOSSES) return;
    fx_add(FX_BOSS_ENTER, (int)bosses[k].enter_tx, (int)bosses[k].enter_ty, game_cfg.enter_ticks);
}
void fx_boss_death(unsigned k) {
    if (k >= MAX_BOSSES) return;
    fx_add(FX_BOSS_DEATH, bosses[k].x, bosses[k].y, 30);
}

void fx_graze(int x,int y){
    if(!game_cfg.graze_feedback_enabled||graze_wait)return;
    fx_add(FX_GRAZE,x,y,10);graze_wait=game_cfg.graze_feedback_cooldown;
}
void fx_cancel_star(int x,int y){
    unsigned count=0,limit=game_cfg.death_star_budget;if(limit>8)limit=8;
    for(unsigned i=0;i<FX_CAP;++i)if(fx[i].active&&fx[i].kind==FX_CANCEL_STAR)++count;
    if(count<limit)fx_add(FX_CANCEL_STAR,x,y,18);
}
static unsigned low_hp_phase(unsigned hp,unsigned maxhp,unsigned tick){
    if(!hp||!maxhp||hp*100u>=maxhp*game_cfg.low_hp_threshold)return 0;
    unsigned period=game_cfg.low_hp_pulse_ticks;if(period<2)period=2;
    return tick%period<period/2?2:1;
}
unsigned effects_hp_color(unsigned hp,unsigned maxhp,unsigned tick){
    unsigned phase=low_hp_phase(hp,maxhp,tick);
    if(phase)return phase==2?0xffb4ad:0xd55c78;
    return maxhp&&hp*2>maxhp?0x80d89b:0xf5cf77;
}
unsigned effects_hitpoint_color(unsigned hp,unsigned maxhp,unsigned tick){
    unsigned phase=low_hp_phase(hp,maxhp,tick);
    return phase==2?0xffb4ad:phase?0xd55c78:0x80e9ed;
}

void effects_tick(void) {
    if(graze_wait)--graze_wait;
    effects_active = 0;
    for (unsigned i = 0; i < FX_CAP; ++i) if (fx[i].active) {
        ++fx[i].age;
        if (fx[i].age >= fx[i].life) fx[i].active = 0;
        else ++effects_active;
    }
}

/* Enforce the baseline ceilings even when a host harness writes the struct
   directly or a future tuning interface accepts an out-of-range value. */
static int fx_budget_accept(unsigned area){
    unsigned jobs=game_cfg.effect_job_budget,limit=game_cfg.effect_area_budget;
    if(jobs>12)jobs=12;
    if(limit>16384)limit=16384;
    if(effects_jobs>=jobs||effects_area>limit||area>limit-effects_area){
        ++effects_over_budget;++effects_drop_total;return 0;
    }
    ++effects_jobs;effects_area+=area;return 1;
}
static int fx_draw(int x,int y,unsigned w,unsigned h,unsigned tile,unsigned alpha){
    if(!fx_budget_accept(w*h))return 0;
    scene_tile(32+x-(int)w/2,16+y-(int)h/2,tile,alpha);
    return 1;
}

/* Preserve the event, colour family and Alpha animation. The busy variant
   changes only the ring's visual footprint; it does not omit hit/level cues. */
static void fx_ring(int x,int y,unsigned full_tile,unsigned small_tile,unsigned alpha){
    if(effects_quality){
        if(fx_draw(x,y,32,32,small_tile,alpha))++effects_lod_jobs;
    }else fx_draw(x,y,64,64,full_tile,alpha);
}

void effects_render(void) {
    effects_jobs = effects_area = effects_over_budget = effects_lod_jobs = 0;
    for(unsigned pass=0;pass<2;++pass)for (unsigned i = 0; i < FX_CAP; ++i) {
        Fx *e = &fx[i];
        if (!e->active) continue;
        unsigned cosmetic=e->kind==FX_GRAZE||e->kind==FX_CANCEL_STAR;
        if(cosmetic!=pass)continue;
        unsigned t = e->age, life = e->life;
        unsigned alpha = 210;
        switch (e->kind) {
        case FX_RING_WARN:
            if (t < life / 2) fx_ring(e->x,e->y,ART_RING_WARN64,ART_RING_ROSE32,220-t*2);
            else fx_draw(e->x, e->y, 32, 32, ART_RING_ROSE32, 120 + t);
            break;
        case FX_RING_BURST:
            alpha = life > t ? 230 - (t * 120 / life) : 100;
            fx_ring(e->x,e->y,ART_RING_GOLD64,ART_RING_GOLD32,alpha);
            break;
        case FX_PLAYER_HIT:
            fx_draw(e->x - 10, e->y - 8, 16, 16, ART_STAR16, 230 - t * 8);
            fx_draw(e->x + 10, e->y + 6, 16, 16, ART_STAR16, 200 - t * 6);
            break;
        case FX_LEVELUP:
            fx_ring(e->x,e->y,ART_RING_CYAN64,ART_RING_CYAN32,150+(t&31));
            if (t < 24) fx_draw(e->x + 26, e->y - 22, 16, 16, ART_STAR16, 220 - t * 3);
            break;
        case FX_REGEN:
            fx_draw(e->x, e->y, 16, 16, ART_PLUS16, 200 - t * 4);
            break;
        case FX_BOSS_ENTER:
            fx_draw(e->x, e->y, 32, 32, ART_RING_CYAN32, 160 + (t & 31));
            break;
        case FX_BOSS_DEATH:
            fx_ring(e->x,e->y,ART_RING_WARN64,ART_RING_ROSE32,230-t*5);
            break;
        case FX_GRAZE:
            fx_draw(e->x+12,e->y-8-(int)t,16,16,ART_STAR16,220-t*16);
            break;
        case FX_CANCEL_STAR:
            fx_draw(e->x+((int)(i%3)-1)*(int)t/2,e->y-(int)t,16,16,ART_STAR16,230-t*10);
            break;
        default:
            break;
        }
    }
    if (fx_overflow) {
        effects_over_budget += fx_overflow;
        effects_drop_total += fx_overflow;
        fx_overflow = 0;
    }
}

/* Four sparse warning-edge accents: 1664 pixels, never a full-frame pass.
   This is submitted after primary effects and shares their hard budget. */
static void fx_edge_rect(int x,int y,unsigned w,unsigned h,uint32_t color){
    if(!fx_budget_accept(w*h))return;
    scene_rect(x,y,(int)w,(int)h,color);
}
void effects_vignette(unsigned tick,unsigned hp,unsigned maxhp,unsigned warning){
    if(!game_cfg.vignette_enabled)return;
    unsigned low=low_hp_phase(hp,maxhp,tick);
    if(!low&&!warning)return;
    uint32_t color=warning?((tick&8)?0x784042:0x492b39):low==2?0x713443:0x402336;
    fx_edge_rect(416,16,256,2,color);fx_edge_rect(416,702,256,2,color);
    fx_edge_rect(32,280,2,160,color);fx_edge_rect(1054,280,2,160,color);
}
