#ifndef TI60_LAB_H
#define TI60_LAB_H

/* LAB1 owns both framebuffers until exit restoration has completed.
   The caller must suspend game simulation AND rendering while active/pending. */
typedef void (*lab_reply_fn)(const char *line);
typedef int (*lab_restore_fn)(void);
void lab_init(lab_reply_fn emit, lab_restore_fn restore);
int lab_command(const char *line); /* "lab <id> ...", optional leading ':' */
unsigned lab_active(void);
unsigned lab_pending(void);
void lab_service(void);

#define LAB_SOURCE_BASE 0x02200000u
#define LAB_TILE_SIZE 64u
#define LAB_TILE_COUNT 2u
#define LAB_BACKGROUND 0x00f4f6fau
#define LAB_REQUEST_MAX 576u
#define LAB_IMAGE_BASE 0x05000000u
#define LAB_IMAGE_MAX_PIXELS (1280u*720u)
#define LAB_IMAGE_CHUNK_BYTES 288u

#endif
