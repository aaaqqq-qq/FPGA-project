`timescale 1ns/1ps
module tb_video_contention;
 parameter real PIXEL_HALF_NS=6.7340067;
 reg clk=0,pixel_clk=0;
 always #5 clk=~clk;
 always #(PIXEL_HALF_NS) pixel_clk=~pixel_clk;
 reg resetn=0,pixel_resetn=0,display_enable=0,swap_start=0;
 reg [31:0] swap_addr=32'h01400000;
 wire [31:0] front_addr,frame_count,swap_count,underflow_count;
 wire swap_pending;
 wire [23:0] rgb;wire hs,vs,de;
 wire [31:0] araddr;wire [7:0] arlen;wire arvalid;reg arready=0;
 reg [127:0] rdata=0;reg [1:0] rresp=0;reg rlast=0,rvalid=0;wire rready;

 wire [31:0] v_araddr;wire [7:0] v_arlen;wire v_arvalid,v_arready,v_rlast,v_rvalid,v_rready;
 wire [127:0] v_rdata;wire [1:0] v_rresp;
 wire [27:0] shared_addr;wire [2:0] sarready,srlast,srvalid;wire [383:0] srdata;wire [5:0] srresp;
 assign araddr={4'b0,shared_addr};assign v_arready=sarready[0];assign v_rdata=srdata[127:0];
 assign v_rresp=srresp[1:0];assign v_rlast=srlast[0];assign v_rvalid=srvalid[0];
 axi_shared arb(.clk(clk),.resetn(resetn),
 .s_awaddr(96'b0),.s_awid(24'b0),.s_awlen(24'b0),.s_awsize(9'b0),.s_awburst(6'b0),
 .s_awlock(3'b0),.s_awcache(12'b0),.s_awprot(9'b0),.s_awvalid(3'b0),.m_awready(1'b0),
 .s_wdata(384'b0),.s_wstrb(48'b0),.s_wlast(3'b0),.s_wvalid(3'b0),.m_wready(1'b0),
 .m_bid(4'b0),.m_bresp(2'b0),.m_bvalid(1'b0),.s_bready(3'b111),
 .s_araddr({32'b0,32'h00800000,v_araddr}),.m_araddr(shared_addr),.s_arid(24'b0),
 .s_arlen({8'b0,8'd63,v_arlen}),.m_arlen(arlen),.s_arsize({3'd4,3'd4,3'd4}),
 .s_arburst({2'd1,2'd1,2'd1}),.s_arlock(3'b0),.s_arcache(12'b0),.s_arprot(9'b0),
 .s_arvalid({1'b0,display_enable,v_arvalid}),.m_arvalid(arvalid),.s_arready(sarready),.m_arready(arready),
 .m_rid(4'b0),.s_rdata(srdata),.m_rdata(rdata),.s_rresp(srresp),.m_rresp(rresp),
 .s_rlast(srlast),.m_rlast(rlast),.s_rvalid(srvalid),.m_rvalid(rvalid),
 .s_rready({1'b1,1'b1,v_rready}),.m_rready(rready));
 video_scanout dut(.clk(clk),.resetn(resetn),.pixel_clk(pixel_clk),
  .pixel_resetn(pixel_resetn),.display_enable(display_enable),.swap_start(swap_start),
  .swap_addr(swap_addr),.front_addr(front_addr),.swap_pending(swap_pending),
  .frame_count(frame_count),.swap_count(swap_count),.underflow_count(underflow_count),
  .rgb(rgb),.hs(hs),.vs(vs),.de(de),.m_araddr(v_araddr),.m_arlen(v_arlen),
  .m_arvalid(v_arvalid),.m_arready(v_arready),.m_rdata(v_rdata),.m_rresp(v_rresp),
  .m_rlast(v_rlast),.m_rvalid(v_rvalid),.m_rready(v_rready));
 reg blocked=0,reading=0;
 reg [31:0] address=0,lfsr=32'h67534ade;
 integer beats=0,read_requests=0,returned_beats=0;
 function [31:0] memory_pixel(input [31:0] addr);
  memory_pixel={8'h00,(addr[23:0]^24'h58a369)};
 endfunction
 // A single-outstanding AXI memory. Both address and read channels stall;
 // once RVALID is asserted, data/last are held until RREADY acknowledges.
 always @(posedge clk) begin
  if(!resetn)begin
   arready<=0;rvalid<=0;reading<=0;beats<=0;lfsr<=32'h67534ade;
  end else begin
   lfsr<={lfsr[30:0],lfsr[31]^lfsr[21]^lfsr[1]^lfsr[0]};
   arready<=!blocked && !reading && lfsr[0];
   if(arvalid && arready)begin
    if(reading)$fatal(1,"overlapping AXI reads");
    if(arlen!=63 || araddr[7:0]!=0)$fatal(1,"incorrect DMA burst");
    if({1'b0,araddr[11:0]}+((arlen+1)*16)>4096)$fatal(1,"4KiB crossing");
    address<=araddr;beats<=arlen+1;reading<=1;arready<=0;
    read_requests<=read_requests+1;
   end
   if(rvalid && rready)begin
    rvalid<=0;address<=address+16;beats<=beats-1;
    returned_beats<=returned_beats+1;
    if(beats==1)reading<=0;
   end
   if(reading && !rvalid && !blocked && lfsr[2:1]!=0)begin
    rdata<={memory_pixel(address+12),memory_pixel(address+8),
            memory_pixel(address+4),memory_pixel(address)};
    rlast<=(beats==1);rresp<=0;rvalid<=1;
   end
  end
 end
 integer old_x=1649,old_y=719,frame_pixels=0,verified_frames=0,verified_pixels=0;
 integer pixel_errors=0,sync_errors=0,magenta_pixels=0;
 reg check_pixels=1,have_frame=0;
 reg [23:0] expected;
 // The output pipeline is one pixel behind the current raster counters.
 // Save pre-edge x/y, and check output against the prior pre-edge position.
 always @(posedge pixel_clk)begin
  if(pixel_resetn)begin
   #0.001;
   if(de !== (old_x<1280 && old_y<720))begin
    sync_errors=sync_errors+1;if(sync_errors<4)$display("DE mismatch x=%0d y=%0d",old_x,old_y);
   end
   if(hs !== (old_x>=1390 && old_x<1430) || vs !== (old_y>=725 && old_y<730))
    sync_errors=sync_errors+1;
   if(de && dut.scan_enabled)begin
    have_frame=1;
    frame_pixels=frame_pixels+1;
    if(rgb==24'hff00ff)magenta_pixels=magenta_pixels+1;
    if(check_pixels)begin
     expected=memory_pixel(front_addr+(old_y*1280+old_x)*4);
     if(rgb!==expected)begin
      pixel_errors=pixel_errors+1;
      if(pixel_errors<9)$display("PIXEL mismatch x=%0d y=%0d rgb=%06x expected=%06x front=%08x",old_x,old_y,rgb,expected,front_addr);
     end
     verified_pixels=verified_pixels+1;
    end
   end
   if(old_x==0 && old_y==720)begin
    if(have_frame && check_pixels)begin
     if(frame_pixels!=921600)$fatal(1,"frame pixel count %0d",frame_pixels);
     verified_frames=verified_frames+1;
     $display("FRAME checked %0d pixels=%0d swaps=%0d underflow=%0d",verified_frames,frame_pixels,swap_count,underflow_count);
    end
    have_frame=0;frame_pixels=0;
   end
   // dut counters already advanced in NBA: subtract one to reconstruct the
   // current pre-edge raster position for the next output pipeline step.
   if(dut.px==0)begin old_x=1649;old_y=(dut.py==0)?749:dut.py-1;end
   else begin old_x=dut.px-1;old_y=dut.py;end
  end
 end
 reg [31:0] last_swap=0;
 reg prior_tag0_toggle=0,prior_tag1_toggle=0;
 reg [11:0] prior_tag0=0,prior_tag1=0;
 reg [11:0] prior_latched0=0,prior_latched1=0;
 reg prior_seen0=0,prior_seen1=0;
 reg [9:0] prior_requested=0;
 reg prior_line_toggle=0;
 realtime published0=-10000.0,published1=-10000.0,requested_at=-10000.0;
 integer publications0=0,publications1=0;
 // Bundled-data CDC assertions: one publication toggle per payload change,
 // sufficient hold interval, and payload capture only after synchronizing
 // the event. RTL simulation cannot model analog metastability; these are
 // protocol checks alongside the implementation's routing constraints.
 always @(posedge clk)if(resetn)begin
  #0.003;
  if(dut.tag0_toggle!=prior_tag0_toggle)begin
   if($realtime-published0<119.04)$fatal(1,"bank0 publication interval too short");
   published0=$realtime;publications0=publications0+1;
  end else if(dut.tag0!==prior_tag0)$fatal(1,"tag0 payload changed without event");
  if(dut.tag1_toggle!=prior_tag1_toggle)begin
   if($realtime-published1<119.04)$fatal(1,"bank1 publication interval too short");
   published1=$realtime;publications1=publications1+1;
  end else if(dut.tag1!==prior_tag1)$fatal(1,"tag1 payload changed without event");
  prior_tag0=dut.tag0;prior_tag1=dut.tag1;
  prior_tag0_toggle=dut.tag0_toggle;prior_tag1_toggle=dut.tag1_toggle;
 end
 always @(posedge pixel_clk)if(pixel_resetn)begin
  #0.004;
  if(dut.tag0_seen!=prior_seen0)begin
   if($realtime-published0<4*PIXEL_HALF_NS-0.15)$fatal(1,"tag0 captured before bundled payload settled");
   if(dut.tag0_latched!==dut.tag0)$fatal(1,"tag0 capture mismatch");
  end else if(dut.tag0_latched!==prior_latched0)$fatal(1,"tag0 latched without publication");
  if(dut.tag1_seen!=prior_seen1)begin
   if($realtime-published1<4*PIXEL_HALF_NS-0.15)$fatal(1,"tag1 captured before bundled payload settled");
   if(dut.tag1_latched!==dut.tag1)$fatal(1,"tag1 capture mismatch");
  end else if(dut.tag1_latched!==prior_latched1)$fatal(1,"tag1 latched without publication");
  if(dut.line_toggle!=prior_line_toggle)begin
   if($realtime-requested_at<3280*PIXEL_HALF_NS)$fatal(1,"line request payload hold violated");
   requested_at=$realtime;
  end else if(dut.requested_line!==prior_requested)$fatal(1,"line payload changed without event");
  prior_seen0=dut.tag0_seen;prior_seen1=dut.tag1_seen;
  prior_latched0=dut.tag0_latched;prior_latched1=dut.tag1_latched;
  prior_line_toggle=dut.line_toggle;prior_requested=dut.requested_line;
 end
 always @(posedge clk)if(resetn)begin
  #0.002;
  if(swap_count!=last_swap)begin
   if(dut.py<720)$fatal(1,"swap acknowledged inside active frame");
   if(swap_pending)$fatal(1,"swap acknowledgement failed to clear pending");
   last_swap=swap_count;
  end
 end
 integer before_fault;
 initial begin
  #200;@(negedge clk);resetn=1;pixel_resetn=1;display_enable=1;
`ifdef LONG_STALL
  wait(frame_count>=2);
  wait(dut.py==714 && dut.px==1290);
  check_pixels=0;
  @(negedge clk);blocked=1;
  wait(dut.py==719 && dut.px==100);
  @(negedge clk);swap_addr=32'h01400000;swap_start=1;
  @(negedge clk);swap_start=0;
  wait(dut.py==3 && dut.px==100);
  @(negedge clk);blocked=0;
  wait(swap_count==1);
  #1;
  $display("PASS long-stall swap was deferred until a vertical blank");
  $finish;
`endif
  wait(frame_count>=2);
  wait(dut.py==200 && dut.px==100);
  @(negedge clk);swap_addr=32'h01400000;swap_start=1;
  @(negedge clk);swap_start=0;
  repeat(10)@(posedge clk);
  if(!swap_pending || front_addr!=32'h01000000)$fatal(1,"swap request incorrectly immediate");
  wait(verified_frames>=3);
  if(pixel_errors || sync_errors || underflow_count!=0 || swap_count!=1)
   $fatal(1,"normal test errors pixels=%0d sync=%0d uf=%0d swaps=%0d",pixel_errors,sync_errors,underflow_count,swap_count);
  $display("NORMAL PASS: %0d pixels, backpressure, tear-free vblank swap",verified_pixels);
  check_pixels=0;
  wait(dut.py==60 && dut.px==0);before_fault=underflow_count;
  @(negedge clk);blocked=1;
  wait(dut.py==66 && dut.px==0);
  @(negedge clk);blocked=0;
  repeat(10)@(posedge clk);
  if(underflow_count<=before_fault || magenta_pixels==0)
   $fatal(1,"underflow injection was not detected");
  $display("FAULT PASS: underflow count=%0d, magenta pixels=%0d",underflow_count,magenta_pixels);
  wait(dut.py==720 && dut.px==100);
  check_pixels=1;
  wait(verified_frames>=4);
  if(pixel_errors || sync_errors)$fatal(1,"recovery mismatch");
  $display("PASS video_scanout: verified_frames=%0d verified_pixels=%0d requests=%0d beats=%0d",verified_frames,verified_pixels,read_requests,returned_beats);
  $finish;
 end
 initial begin #110000000;$fatal(1,"simulation timeout");end
endmodule
