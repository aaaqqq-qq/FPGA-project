`timescale 1ns/1ps
module tb_batch32;
    reg clk=0; always #5 clk=~clk;
    reg resetn=0,start=0;
    reg [1:0] op=0;
    reg [31:0] src_addr=0,dst_addr=0,src_stride=0,dst_stride=0,fill_color=0;
    reg [15:0] width=0,height=0;
    reg [7:0] alpha=255;
    reg [23:0] color_key=0;
    reg alpha_enable=0,key_enable=0;
    wire busy,done,error;
    wire [31:0] cycles,read_bytes,write_bytes;
    wire [31:0] awaddr,araddr;
    wire [7:0] awlen,arlen;
    wire awvalid,wvalid,wlast,bready,arvalid,rready;
    wire [127:0] wdata;
    wire [15:0] wstrb;
    wire [127:0] engine_wdata;
    wire [15:0] engine_wstrb;
    wire engine_wlast,engine_wvalid,engine_wready;
    reg [127:0] rdata=0;
    reg [1:0] bresp=0,rresp=0;
    reg bvalid=0,rvalid=0,rlast=0;
    reg aw_gate=0,w_gate=0,ar_gate=0,r_gate=0;
    reg w_active=0,r_active=0,b_pending=0;
    wire awready=aw_gate && !w_active && !bvalid && !b_pending;
    wire wready=w_gate && w_active;
    wire arready=ar_gate && !r_active && !rvalid;
    integer w_address,r_address,w_count,r_count,w_position,r_position,b_delay;
    integer fault_mode=0;
    // -1 retains the original fault injection; directed tests select a burst.
    integer fault_transaction=-1,fault_beat=0;
    reg [31:0] random_state=32'h456789ab;
    localparam integer MEMORY_SIZE=8388608;
    reg [7:0] memory [0:MEMORY_SIZE-1];
    reg [7:0] expected [0:MEMORY_SIZE-1];
    integer i,j,k,test_count=0,ar_transactions=0,aw_transactions=0;
    integer allowed_begin=0,allowed_end=0;
    integer multi_read=0,multi_write=0,page_splits=0,w_beats=0,b_responses=0;
    integer last_ar_transactions,last_aw_transactions;
    reg aw_held=0,ar_held=0,w_held=0;
    reg [31:0] aw_held_addr,ar_held_addr;
    reg [7:0] aw_held_len,ar_held_len;
    reg [127:0] w_held_data;
    reg [15:0] w_held_strb;
    reg w_held_last;
    reg engine_w_held=0,engine_held_last;
    reg [127:0] engine_held_data;
    reg [15:0] engine_held_strb;

`ifdef WITH_WRITE_FIFO
    write_beat_fifo write_queue(
        .clk(clk),.resetn(resetn),
        .s_valid(engine_wvalid),.s_ready(engine_wready),
        .s_data({engine_wlast,engine_wstrb,engine_wdata}),
        .m_valid(wvalid),.m_ready(wready),.m_data({wlast,wstrb,wdata})
    );
`else
    assign wdata=engine_wdata;
    assign wstrb=engine_wstrb;
    assign wlast=engine_wlast;
    assign wvalid=engine_wvalid;
    assign engine_wready=wready;
`endif

    reg [14:0] sprite_count=0;
    reg mode32=0;
    render_engine dut(.batch32_enable(mode32),.op(op),
        .clk(clk),.resetn(resetn),.start(start),.tile_first(8'd24),.sprite_count(sprite_count),.fill_color(fill_color),.texture_addr(32'h1000),
        .src_addr(src_addr),.dst_addr(dst_addr),.src_stride(src_stride),.dst_stride(dst_stride),
        .width(width),.height(height),.alpha(alpha),.color_key(color_key),
        .alpha_enable(alpha_enable),.key_enable(key_enable),
        .busy(busy),.done(done),.error(error),.cycles(cycles),.read_bytes(read_bytes),.write_bytes(write_bytes),
        .m_awaddr(awaddr),.m_awlen(awlen),.m_awvalid(awvalid),.m_awready(awready),
        .m_wdata(engine_wdata),.m_wstrb(engine_wstrb),.m_wlast(engine_wlast),.m_wvalid(engine_wvalid),.m_wready(engine_wready),
        .m_bresp(bresp),.m_bvalid(bvalid),.m_bready(bready),
        .m_araddr(araddr),.m_arlen(arlen),.m_arvalid(arvalid),.m_arready(arready),
        .m_rdata(rdata),.m_rresp(rresp),.m_rlast(rlast),.m_rvalid(rvalid),.m_rready(rready)
    );

    function automatic [31:0] get_pixel;
        input integer address;
        begin get_pixel={memory[address+3],memory[address+2],memory[address+1],memory[address]}; end
    endfunction
    task put_pixel;
        input integer address;
        input [31:0] pixel;
        integer n;
        begin for(n=0;n<4;n=n+1) memory[address+n]=pixel[n*8+:8]; end
    endtask
    function automatic [31:0] blended;
        input [31:0] foreground,background;
        input [7:0] a;
        integer n,value;
        begin
            if(a==0) blended=background;
            else if(a==255) blended=foreground;
            else begin
                blended=0;
                for(n=0;n<3;n=n+1) begin
                    value=(foreground[n*8+:8]*a+background[n*8+:8]*(255-a)+127)/255;
                    blended[n*8+:8]=value;
                end
            end
        end
    endfunction

    // Deterministic backpressure on every channel, including delayed B replies.
    always @(negedge clk) begin
        random_state={random_state[30:0],random_state[31]^random_state[21]^random_state[1]^random_state[0]};
        aw_gate=random_state[0]|random_state[1];
        w_gate=random_state[2]|random_state[3];
        ar_gate=random_state[4]|random_state[5];
        r_gate=random_state[6]|random_state[7];
    end

    always @(posedge clk) begin
        if(!resetn) begin
            w_active<=0; r_active<=0; b_pending<=0; bvalid<=0; rvalid<=0;
            aw_held<=0; ar_held<=0; w_held<=0;
            engine_w_held<=0;
            b_delay<=0; rresp<=0; bresp<=0; rlast<=0;
        end else begin
            if(aw_held && (!awvalid || awaddr!==aw_held_addr || awlen!==aw_held_len))
                $fatal(1,"AW changed while stalled");
            if(ar_held && (!arvalid || araddr!==ar_held_addr || arlen!==ar_held_len))
                $fatal(1,"AR changed while stalled");
            if(w_held && (!wvalid || wdata!==w_held_data || wstrb!==w_held_strb || wlast!==w_held_last))
                $fatal(1,"W changed while stalled");
            if(engine_w_held && (!engine_wvalid || engine_wdata!==engine_held_data ||
                engine_wstrb!==engine_held_strb || engine_wlast!==engine_held_last))
                $fatal(1,"Engine W changed while stalled at FIFO input");
            aw_held<=awvalid&&!awready; aw_held_addr<=awaddr; aw_held_len<=awlen;
            ar_held<=arvalid&&!arready; ar_held_addr<=araddr; ar_held_len<=arlen;
            w_held<=wvalid&&!wready; w_held_data<=wdata; w_held_strb<=wstrb; w_held_last<=wlast;
            engine_w_held<=engine_wvalid&&!engine_wready;
            engine_held_data<=engine_wdata;engine_held_strb<=engine_wstrb;engine_held_last<=engine_wlast;
            if(awvalid&&awready) begin
                if(awlen>63 || awaddr[3:0]!=0 || (awaddr[11:0]+((awlen+1)*16)>4096))
                    $fatal(1,"Bad write burst address/length %x %d",awaddr,awlen);
                if(awaddr<allowed_begin || awaddr+((awlen+1)*16)>allowed_end)
                    $fatal(1,"DUT write outside designated destination/stride range");
                if(awaddr+((awlen+1)*16)>MEMORY_SIZE) $fatal(1,"Test memory write bounds");
                w_address<=awaddr; w_count<=awlen+1; w_position<=0; w_active<=1;
                aw_transactions<=aw_transactions+1;
                if(awlen>0) multi_write<=multi_write+1;
                if(awaddr[11:0]+((awlen+1)*16)==4096) page_splits<=page_splits+1;
            end
            if(wvalid&&wready) begin
                if(wlast!==(w_position==w_count-1)) $fatal(1,"Wrong WLAST");
                for(j=0;j<16;j=j+1) if(wstrb[j]) memory[w_address+j]<=wdata[j*8+:8];
                w_beats<=w_beats+1;
                if(wlast) begin
                    w_active<=0; b_pending<=1; b_delay<=2+random_state[11:8];
                    bresp<=(fault_mode==2 &&
                        (fault_transaction<0 || aw_transactions==fault_transaction))?2'b10:2'b00;
                end else begin w_position<=w_position+1; w_address<=w_address+16; end
            end
            if(b_pending) begin
                if(b_delay==0) begin b_pending<=0; bvalid<=1; end
                else b_delay<=b_delay-1;
            end
            if(bvalid&&bready) begin bvalid<=0; b_responses<=b_responses+1; end
            if(arvalid&&arready) begin
                if(arlen>63 || araddr[3:0]!=0 || (araddr[11:0]+((arlen+1)*16)>4096))
                    $fatal(1,"Bad read burst address/length %x %d",araddr,arlen);
                if(araddr+((arlen+1)*16)>MEMORY_SIZE) $fatal(1,"Test memory read bounds");
                r_address<=araddr; r_count<=arlen+1; r_position<=0; r_active<=1;
                ar_transactions<=ar_transactions+1;
                if(arlen>0) multi_read<=multi_read+1;
                if(araddr[11:0]+((arlen+1)*16)==4096) page_splits<=page_splits+1;
            end
            if(r_active&&!rvalid&&r_gate) begin
                for(k=0;k<16;k=k+1) rdata[k*8+:8]<=memory[r_address+k];
                rresp<=(fault_mode==1 && r_position==fault_beat &&
                    (fault_transaction<0 || ar_transactions==fault_transaction))?2'b10:2'b00;
                if(fault_mode==3) rlast<=1;
                else if(fault_mode==4) rlast<=0;
                else rlast<=(r_position==r_count-1);
                rvalid<=1;
            end
            if(rvalid&&rready) begin
                rvalid<=0;
                if(r_position==r_count-1 || fault_mode==3) r_active<=0;
                else begin r_address<=r_address+16; r_position<=r_position+1; end
            end
            if(done && (w_active||b_pending||bvalid||r_active||rvalid))
                $fatal(1,"DONE before AXI completion");
`ifdef WITH_WRITE_FIFO
            if(done && write_queue.count!=0) $fatal(1,"DONE before queued W beats reached DDR");
`endif
        end
    end


 function automatic [31:0] expected_pixel(input integer a);
  expected_pixel={expected[a+3],expected[a+2],expected[a+1],expected[a]};
 endfunction
 function automatic integer xpos(input integer n,size,layout);
  case(layout)
   1:xpos=n%8;
   2:xpos=(n%2)?1024-size:0;
   3:xpos=401;
   default:xpos=(n*73)%(1025-size);
  endcase
 endfunction
 function automatic integer ypos(input integer n,size,rows,layout);
  case(layout)
   1:ypos=(n/8)%8;
   2:ypos=((n/2)%2)?rows-size:0;
   3:ypos=17;
   default:ypos=(n*11)%(rows-size+1);
  endcase
 endfunction
 task run_batch(input integer count,rows,a,ae,ke,size,layout);
  integer n,x,y,t,b,addr,sprite,timeout,mutated,xx,yy,shift;
  reg [31:0] fg,bg,result;
  begin
   shift=size==32?2:0;
   for(n=0;n<1024;n=n+1)put_pixel('h1000+n*4,n%5==0?32'habff00ff:(32'hcd123456^(n*21357)));
   for(n=0;n<count;n=n+1)begin
    x=xpos(n,size,layout);y=ypos(n,size,rows,layout);t=n%16;
    put_pixel('h7a0000+n*16,(x+size/2)<<12);
    put_pixel('h7a0004+n*16,(y+size/2)<<12);
    put_pixel('h7a0008+n*16,32'h12345678);
    put_pixel('h7a000c+n*16,32'hab00f00d|((t+24)<<16));
   end
   for(n='h400000;n<'h400080+rows*5120+128;n=n+1)expected[n]=memory[n];
   for(y=0;y<rows;y=y+1)for(x=0;x<1024;x=x+1)begin
    fg=get_pixel('h20080+y*5120+x*4);addr='h400080+y*5120+x*4;
    for(b=0;b<4;b=b+1)expected[addr+b]=fg[b*8+:8];
   end
   for(sprite=0;sprite<count;sprite=sprite+1)begin
    xx=xpos(sprite,size,layout);yy=ypos(sprite,size,rows,layout);
    for(y=0;y<size;y=y+1)for(x=0;x<size;x=x+1)begin
     fg=get_pixel('h1000+(sprite%16)*256+((y>>shift)*8+(x>>shift))*4);
     addr='h400080+(yy+y)*5120+(xx+x)*4;
     bg=expected_pixel(addr);result=ae?blended(fg,bg,a):fg;
     if(!(ke&&fg[23:0]==24'hff00ff))for(b=0;b<4;b=b+1)expected[addr+b]=result[b*8+:8];
    end
   end
   @(negedge clk);src_addr='h20080;dst_addr='h400080;src_stride=5120;dst_stride=5120;
   allowed_begin='h400080;allowed_end='h400080+rows*5120;
   fill_color='h7a0000;width=1024;height=rows;alpha=a;alpha_enable=ae;key_enable=ke;
   color_key=24'hff00ff;sprite_count=count;op=2;mode32=size==32;start=1;
   @(negedge clk);start=0;src_addr=0;dst_addr=0;width=1;height=1;sprite_count=0;alpha=0;mode32=~mode32;
   timeout=0;mutated=0;
   while(!done)begin
    @(negedge clk);timeout=timeout+1;
    if($test$plusargs("SNAPSHOT") && !mutated && read_bytes>=4096+count*16)begin
     for(n=0;n<count*16;n=n+1)begin memory['h7a0000+n]=n^8'h5a;expected['h7a0000+n]=n^8'h5a;end
     mutated=1;
    end
    if(timeout>5000000)$fatal(1,"timeout state=%d",dut.batch.state);
   end
   if($test$plusargs("SNAPSHOT") && !mutated)$fatal(1,"snapshot test not exercised");
   if(error||busy)$fatal(1,"unexpected batch error size=%d",size);
   for(n='h400000;n<'h400080+rows*5120+128;n=n+1)if(memory[n]!==expected[n])
    $fatal(1,"pixel mismatch N=%d size=%d a=%d layout=%d address=%x actual=%x expected=%x",count,size,a,layout,n,memory[n],expected[n]);
   if(write_bytes!=rows*4096 || read_bytes!=4096+count*16+rows*4096)$fatal(1,"byte counters");
   $display("PASS batch N=%d rows=%d size=%d layout=%d alpha=%d AE=%d KEY=%d cycles=%d",count,rows,size,layout,a,ae,ke,cycles);
   @(negedge clk);
  end
 endtask

 task error_case(input integer fm,bad_width,bad_count);
  integer timeout,old_ar,old_aw;
  begin
   fault_mode=fm;fault_transaction=fm==1?ar_transactions+1:aw_transactions+1;fault_beat=2;
   old_ar=ar_transactions;old_aw=aw_transactions;
   @(negedge clk);src_addr='h20080;dst_addr='h400080;src_stride=5120;dst_stride=5120;
   fill_color='h7a0000;width=bad_width?1000:1024;height=16;alpha=224;alpha_enable=1;key_enable=1;color_key=24'hff00ff;
   sprite_count=bad_count?24577:0;op=2;mode32=0;start=1;@(negedge clk);start=0;
   timeout=0;while(!done)begin @(negedge clk);timeout=timeout+1;if(timeout>3000000)$fatal(1,"error timeout");end
   if(!error||busy)$fatal(1,"missing error flag");
   if((bad_width||bad_count)&&(ar_transactions!=old_ar||aw_transactions!=old_aw))$fatal(1,"invalid header touched bus");
   fault_mode=0;fault_transaction=-1;fault_beat=0;
   $display("PASS error drain mode=%d width=%d count=%d",fm,bad_width,bad_count);
   @(negedge clk);
  end
 endtask
 initial begin
  for(i=0;i<MEMORY_SIZE;i=i+1)memory[i]=(i*37+(i>>7)+19)&255;
  repeat(5)@(negedge clk);resetn=1;
  if($test$plusargs("FULL32"))begin
   run_batch(5000,688,224,1,1,32,0);
   $display("PASS full field 5000 32px batch");$finish;
  end
  run_batch(0,72,224,1,1,32,0);
  run_batch(64,72,224,1,1,32,1);
  run_batch(64,72,128,1,1,32,1);
  run_batch(64,72,0,1,1,32,1);
  run_batch(64,72,255,1,1,32,1);
  run_batch(64,72,224,0,1,32,1);
  run_batch(64,72,128,1,0,32,1);
  run_batch(64,72,128,0,0,32,1);
  run_batch(16,72,224,1,1,32,2);
  run_batch(67,72,224,1,1,32,3);
  run_batch(1,720,224,1,1,32,2);
  run_batch(67,688,224,1,1,32,0);
  run_batch(17,48,224,1,1,8,0);
  error_case(1,0,0);run_batch(17,48,224,1,1,32,0);
  error_case(2,0,0);run_batch(17,48,224,1,1,32,0);
  error_case(0,1,0);error_case(0,0,1);
  run_batch(17,48,224,1,1,8,0);
  $display("PASS all 8/32 ordered batch pixel/protocol tests");$finish;
 end
 initial begin #500000000;$fatal(1,"global timeout");end
endmodule
