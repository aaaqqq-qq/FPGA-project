#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scene.h"
#include "bitblt.h"
#include "stage.h"
Stage stage;
unsigned battle_materials;
#define stage (*(Stage *)(uintptr_t)0x02100000u)
static uint32_t regs[64];static unsigned pending,abort_after;static uint64_t ticks;
void fatal(const char *where,int code){fprintf(stderr,"FAIL %s %d\n",where,code);exit(2);}
static void render_job(const bb_job *j){
 if(j->op==2){
  bb_job bg=*j;bg.op=BB_COPY_OP;bg.flags=0;render_job(&bg);
  const uint32_t *list=(const uint32_t *)(uintptr_t)j->fill;
  for(unsigned i=0;i<regs[0x44/4];++i){
   unsigned x=(int32_t)list[4*i]/Q-4,y=(int32_t)list[4*i+1]/Q-4,tile=((list[4*i+3]>>16)&255)-regs[0x50/4];
   bb_job sprite={BB_COPY_OP,regs[0x48/4]+tile*256,j->dst+y*j->dst_stride+x*4,32,j->dst_stride,8,8,0,j->alpha,j->key,j->flags};render_job(&sprite);
  }
  return;
 }

 for(unsigned y=0;y<j->height;y++)for(unsigned x=0;x<j->width;x++){
  uint32_t *d=(uint32_t *)(uintptr_t)(j->dst+y*j->dst_stride+x*4);
  uint32_t s=j->op==BB_COPY_OP?*(uint32_t *)(uintptr_t)(j->src+y*j->src_stride+x*4):j->fill;
  if(j->op==BB_COPY_OP&&(j->flags&BB_KEY_ENABLE)&&(s&0xffffff)==j->key)continue;
  if(j->flags&BB_ALPHA_ENABLE)*d=bb_blend(s,*d,j->alpha);else *d=s;
 }
}
uint32_t bb_read(unsigned reg){
 if(reg==0x4c)return 2;
 if(reg==BB_STATUS){if(pending){bb_job j;memcpy(&j,&regs[BB_OP/4],sizeof(j));render_job(&j);pending=0;regs[BB_STATUS/4]=BB_DONE;}return regs[reg/4];}
 return regs[reg/4];
}
void bb_write(unsigned reg,uint32_t v){
 if(pending)fatal("register write while command pending",reg);
 if(reg==BB_CMD){pending=1;regs[BB_STATUS/4]=BB_BUSY;return;}
 if(reg==BB_STATUS){regs[reg/4]&=~v;return;}regs[reg/4]=v;
}
uint64_t bb_ticks(void){return ++ticks;}
uint32_t bb_us(uint64_t t){return (uint32_t)t;}
bb_result bb_publish(void){if(pending)fatal("publish before wait",0);return BB_OK;}
void bb_acquire(void){if(pending)fatal("acquire before wait",0);}
bb_result bb_cpu_execute(const bb_job *j){if(abort_after&&!--abort_after)return BB_E_CANCELLED;if(pending)fatal("CPU draw before wait",0);render_job(j);return BB_OK;}
void font_draw_text(uint32_t,unsigned,unsigned,const char*,uint32_t,unsigned);
void draw_text(uint32_t f,unsigned x,unsigned y,const char*t,uint32_t c,unsigned s){if(pending && !(regs[BB_OP/4]==2 && x>=1072 && x+strlen(t)*6*s<=1280 && y+7*s<=720))fatal("CPU text before wait",0);font_draw_text(f,x,y,t,c,s);}
__declspec(dllexport) void init_test(void){pending=0;ticks=0;memset(regs,0,sizeof(regs));scene_init();}
__declspec(dllexport) void frame_test(unsigned frame,unsigned hw){
 uint32_t fb=(frame&1)?BB_FB1:BB_FB0;unsigned batch=frame%8<6;scene_set_batch(batch);scene_begin(fb,hw);
 if(batch){
  stage.count=frame%7==0?4096:257;
  for(unsigned i=0;i<stage.count;++i){stage.shots[i].x=(4+(i*73+frame*17)%1017)*Q;stage.shots[i].y=(4+(i*11+frame*7)%681)*Q;stage.shots[i].tile=24+(i%16);}
  scene_batch_shots();
 }

 /* Vary overlap, clipping, sprite dimensions, alpha extremes and edge positions. */
 for(unsigned i=0;i<75;i++)scene_tile((int)((frame*17+i*23)%1100),(int)((frame*7+i*41)%740),i%41,(unsigned[]){0,1,127,224,255}[i%5]);
 /* Generated effect tiles and the new phase HUD. */
 for(unsigned i=0;i<8;i++)scene_tile(40+(int)((frame*29+i*71)%960),30+(int)((frame*13+i*53)%620),70+(i+frame)%13,(unsigned[]){255,210,180}[i%3]);
 scene_rect(220,390,3,3,0xffffff);scene_rect(40,23,368,3,0x383143);
 scene_text(1078,124,"SCORE",0x8786a3,1);
 scene_text(1078,138,frame%2?"123456789":"1",0xffffff,2);
 scene_text(1078,166,"PLAYER HP",0x8786a3,1);
 scene_rect(1078,178,186,10,0x383143);
 {unsigned w=(frame*7)%187; if(w)scene_rect(1078,178,w,10,0x80d89b);}
 scene_text(1078,192,frame%3?"HP 85/100":"HP 5/100",0xffffff,1);
 scene_text(1078,210,"LEVEL / NEXT",0x8786a3,1);
 scene_text(1078,224,frame%3?"LV 5":"LV 1",0xf0cc8d,2);
 scene_rect(1078,252,186,8,0x383143);
 {unsigned w=(frame*11)%187; if(w)scene_rect(1078,252,w,8,0x80cfff);}
 scene_text(1078,240,frame%3?"MAX":"NEXT 1000",0x8786a3,1);
 scene_text(1078,270,frame%2?"BOMBS 3":"BOMBS 0",0xe9e5f2,1);
 scene_text(1078,306,"BOSS STATUS",0x8786a3,1);
 for(unsigned k=0;k<3;++k){
  int y=320+(int)k*80;
  scene_text(1078,y,k==0?"RUMIA":k==1?"CIRNO":"HONG MEILING",0xe9e5f2,1);
  scene_text(1210,y,frame%4==0?"WAIT":frame%4==1?"ENRAGED":"ACTIVE",0xf5cf77,1);
  scene_rect(1078,y+14,186,8,0x383143);
  unsigned w=(unsigned)((frame*7+k*31)%187); if(w)scene_rect(1078,y+14,w,8,0xeb859a);
  scene_rect(1078+93,y+14,1,8,0xffffff);
  scene_text(1078,y+26,frame%5?"1500/3000":"DEFEATED",0xe9e5f2,1);
 }
 scene_text(1078,572,"N 1234/20000",0x8be2cc,1);
 scene_text(1078,588,"FPS 60.00 R 1200",0x8be2cc,1);
 scene_text(1078,604,"MISS 0 UF 0",0xc3bbd5,1);
 scene_text(1078,620,"KEYS 0 DROP 0",0xc3bbd5,1);
 scene_text(1078,636,"PHASE BATTLE",0xe9e5f2,1);
 scene_text(1078,652,"EFF 2/4096",0x8786a3,1);
 scene_text(1078,668,"LIVE",0x80d89b,1);
 if(frame%5==0){scene_rect(PANEL_X,PANEL_Y,PANEL_W,PANEL_H,0x121326);scene_text(PANEL_X+18,PANEL_Y+14,"NIGHT SIGN",0xf0cc8d,2);}
 scene_end();
}

__declspec(dllexport) void cancelled_frame_test(void){
 abort_after=2;scene_set_batch(1);scene_begin(BB_FB0,0);scene_batch_shots();scene_end();
 if(!scene_cancelled())fatal("CPU cancellation not propagated",0);
 abort_after=0;
}
