`timescale 1ns/1ps
// Common-reset integration check. DDR memory is preserved across reset; only
// engine/FIFO/arbiter/slave transaction state is reset. Accepted writes do not
// roll back. No payload is required to be cleared when its VALID is low.
module tb_bitblt_reset;
    reg clk=0; always #5 clk=~clk;
    reg resetn=0,start=0,c_arvalid=0,c_awvalid=0;
    reg [1:0] op=1;
    reg [31:0] src_addr=32'h2004,dst_addr=32'h5008,src_stride=160,dst_stride=168,fill_color=32'hde571234;
    reg [15:0] width=33,height=2;
    reg [7:0] alpha=255;
    reg [23:0] color_key=24'h112233;
    reg alpha_enable=0,key_enable=0;
    wire busy,done,error;
    wire [31:0] cycles,read_bytes,write_bytes;
    wire [31:0] e_awaddr,e_araddr;
    wire [7:0] e_awlen,e_arlen;
    wire e_awvalid,e_wvalid,e_wlast,e_bready,e_arvalid,e_rready,e_wready;
    wire [127:0] e_wdata,f_wdata;
    wire [15:0] e_wstrb,f_wstrb;
    wire f_wvalid,f_wlast;
    wire [2:0] s_awready,s_wready,s_bvalid,s_arready,s_rvalid,s_rlast;
    wire [5:0] s_bresp,s_rresp;
    wire [383:0] s_rdata;
    wire [27:0] m_awaddr,m_araddr;
    wire [7:0] m_awlen,m_arlen;
    wire [2:0] m_awsize,m_arsize;
    wire [1:0] m_awburst,m_arburst;
    wire m_awvalid,m_wvalid,m_wlast,m_bready,m_arvalid,m_rready;
    wire [127:0] m_wdata;
    wire [15:0] m_wstrb;
    reg [127:0] m_rdata=0;
    reg [1:0] m_rresp=0,m_bresp=0;
    reg m_rvalid=0,m_rlast=0,m_bvalid=0;
    reg r_active=0,w_active=0,b_pending=0;
    reg hold_ar=0,hold_aw=0,hold_b=0;
    integer hold_r_limit=-1,hold_w_limit=-1;
    reg [31:0] rng=32'h9153ac72;
    integer r_address=0,r_count=0,r_position=0,w_address=0,w_count=0,w_position=0,b_delay=0;
    wire m_arready=!hold_ar&&!r_active&&!m_rvalid&&rng[0];
    wire m_awready=!hold_aw&&!w_active&&!m_bvalid&&!b_pending&&rng[1];
    wire m_wready=w_active&&rng[2]&&((hold_w_limit<0)||(w_position<hold_w_limit));
    integer ar_total=0,aw_total=0,r_total=0,w_total=0,b_total=0;
    integer reset_cases=0,recovery_commands=0,quiet_cycles=0,byte_checks=0,i,scenario;
    localparam integer MEMORY_SIZE=65536;
    reg [7:0] memory [0:MEMORY_SIZE-1];
    reg [7:0] expected [0:MEMORY_SIZE-1];
    reg [7:0] quiet_expected [0:MEMORY_SIZE-1];
    integer rb,wb;

    bitblt_engine engine(
        .clk(clk),.resetn(resetn),.start(start),.op(op),
        .src_addr(src_addr),.dst_addr(dst_addr),.src_stride(src_stride),.dst_stride(dst_stride),
        .width(width),.height(height),.fill_color(fill_color),.alpha(alpha),.color_key(color_key),
        .alpha_enable(alpha_enable),.key_enable(key_enable),
        .busy(busy),.done(done),.error(error),.cycles(cycles),.read_bytes(read_bytes),.write_bytes(write_bytes),
        .m_awaddr(e_awaddr),.m_awlen(e_awlen),.m_awvalid(e_awvalid),.m_awready(s_awready[1]),
        .m_wdata(e_wdata),.m_wstrb(e_wstrb),.m_wlast(e_wlast),.m_wvalid(e_wvalid),.m_wready(e_wready),
        .m_bresp(s_bresp[3:2]),.m_bvalid(s_bvalid[1]),.m_bready(e_bready),
        .m_araddr(e_araddr),.m_arlen(e_arlen),.m_arvalid(e_arvalid),.m_arready(s_arready[1]),
        .m_rdata(s_rdata[255:128]),.m_rresp(s_rresp[3:2]),.m_rlast(s_rlast[1]),.m_rvalid(s_rvalid[1]),.m_rready(e_rready)
    );
    write_beat_fifo queue(
        .clk(clk),.resetn(resetn),.s_valid(e_wvalid),.s_ready(e_wready),
        .s_data({e_wlast,e_wstrb,e_wdata}),.m_valid(f_wvalid),.m_ready(s_wready[1]),.m_data({f_wlast,f_wstrb,f_wdata})
    );
    axi_shared shared(
        .clk(clk),.resetn(resetn),
        .s_awaddr({32'd0,e_awaddr,32'h1000}),.m_awaddr(m_awaddr),
        .s_awid(24'h004200),.m_awid(),.s_awlen({8'd0,e_awlen,8'd0}),.m_awlen(m_awlen),
        .s_awsize({3{3'd4}}),.m_awsize(m_awsize),.s_awburst({3{2'd1}}),.m_awburst(m_awburst),
        .s_awlock(3'd0),.m_awlock(),.s_awcache(12'd0),.m_awcache(),.s_awprot(9'd0),.m_awprot(),
        .s_awvalid({1'b0,e_awvalid,c_awvalid}),.m_awvalid(m_awvalid),.s_awready(s_awready),.m_awready(m_awready),
        .s_wdata({128'd0,f_wdata,128'd0}),.m_wdata(m_wdata),.s_wstrb({16'd0,f_wstrb,16'd0}),.m_wstrb(m_wstrb),
        .s_wlast({1'b0,f_wlast,1'b0}),.m_wlast(m_wlast),.s_wvalid({1'b0,f_wvalid,1'b0}),
        .m_wvalid(m_wvalid),.s_wready(s_wready),.m_wready(m_wready),
        .s_bid(),.m_bid(4'd0),.s_bresp(s_bresp),.m_bresp(m_bresp),
        .s_bvalid(s_bvalid),.m_bvalid(m_bvalid),.s_bready({1'b0,e_bready,1'b0}),.m_bready(m_bready),
        .s_araddr({32'd0,e_araddr,32'h1000}),.m_araddr(m_araddr),
        .s_arid(24'h004200),.m_arid(),.s_arlen({8'd0,e_arlen,8'd0}),.m_arlen(m_arlen),
        .s_arsize({3{3'd4}}),.m_arsize(m_arsize),.s_arburst({3{2'd1}}),.m_arburst(m_arburst),
        .s_arlock(3'd0),.m_arlock(),.s_arcache(12'd0),.m_arcache(),.s_arprot(9'd0),.m_arprot(),
        .s_arvalid({1'b0,e_arvalid,c_arvalid}),.m_arvalid(m_arvalid),.s_arready(s_arready),.m_arready(m_arready),
        .s_rid(),.m_rid(4'd0),.s_rdata(s_rdata),.m_rdata(m_rdata),.s_rresp(s_rresp),.m_rresp(m_rresp),
        .s_rlast(s_rlast),.m_rlast(m_rlast),.s_rvalid(s_rvalid),.m_rvalid(m_rvalid),
        .s_rready({1'b0,e_rready,1'b0}),.m_rready(m_rready)
    );

    always @(negedge clk) rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};
    // The model shares the same common reset as all three actual RTL modules.
    // Reset drops pending responses/transactions without clearing memory.
    always @(posedge clk) begin
        if(!resetn) begin
            r_active<=0;w_active<=0;b_pending<=0;m_rvalid<=0;m_bvalid<=0;m_rlast<=0;m_rresp<=0;m_bresp<=0;
            r_address<=0;r_count<=0;r_position<=0;w_address<=0;w_count<=0;w_position<=0;b_delay<=0;
            ar_total<=0;aw_total<=0;r_total<=0;w_total<=0;b_total<=0;
        end else begin
            if(m_arvalid&&m_arready) begin
                if(m_araddr[3:0]!=0||m_arlen>15||m_arsize!=4||m_arburst!=1||
                    m_araddr[11:0]+((m_arlen+1)*16)>4096||m_araddr+((m_arlen+1)*16)>MEMORY_SIZE)
                    $fatal(1,"Invalid AR metadata/bounds");
                r_active<=1;r_address<=m_araddr;r_count<=m_arlen+1;r_position<=0;ar_total<=ar_total+1;
            end
            if(r_active&&!m_rvalid&&rng[3]&&((hold_r_limit<0)||(r_position<hold_r_limit))) begin
                for(rb=0;rb<16;rb=rb+1) m_rdata[rb*8+:8]<=memory[r_address+rb];
                m_rresp<=0;m_rlast<=(r_position==r_count-1);m_rvalid<=1;
            end
            if(m_rvalid&&m_rready) begin
                m_rvalid<=0;r_total<=r_total+1;
                if(m_rlast) r_active<=0;
                else begin r_address<=r_address+16;r_position<=r_position+1;end
            end
            if(m_awvalid&&m_awready) begin
                if(m_awaddr[3:0]!=0||m_awlen>15||m_awsize!=4||m_awburst!=1||
                    m_awaddr[11:0]+((m_awlen+1)*16)>4096||m_awaddr+((m_awlen+1)*16)>MEMORY_SIZE)
                    $fatal(1,"Invalid AW metadata/bounds");
                w_active<=1;w_address<=m_awaddr;w_count<=m_awlen+1;w_position<=0;aw_total<=aw_total+1;
            end
            if(m_wvalid&&m_wready) begin
                if(m_wlast!==(w_position==w_count-1)) $fatal(1,"Wrong WLAST");
                for(wb=0;wb<16;wb=wb+1) if(m_wstrb[wb]) memory[w_address+wb]<=m_wdata[wb*8+:8];
                w_total<=w_total+1;
                if(m_wlast) begin w_active<=0;b_pending<=1;b_delay<=4+rng[7:4];end
                else begin w_address<=w_address+16;w_position<=w_position+1;end
            end
            if(b_pending&&!hold_b) begin
                if(b_delay==0) begin b_pending<=0;m_bvalid<=1;m_bresp<=0;end
                else b_delay<=b_delay-1;
            end
            if(m_bvalid&&m_bready) begin m_bvalid<=0;b_total<=b_total+1;end
        end
    end

    function automatic [31:0] get_pixel;
        input integer address;
        begin get_pixel={memory[address+3],memory[address+2],memory[address+1],memory[address]};end
    endfunction
    function automatic [31:0] blend;
        input [31:0] fg,bg;
        input integer a;
        integer channel,value;
        begin
            if(a==0) blend=bg;
            else if(a==255) blend=fg;
            else begin
                blend=0;
                for(channel=0;channel<3;channel=channel+1) begin
                    value=(fg[channel*8+:8]*a+bg[channel*8+:8]*(255-a)+127)/255;
                    blend[channel*8+:8]=value;
                end
            end
        end
    endfunction
    task launch;
        begin @(negedge clk);start=1;@(negedge clk);start=0;end
    endtask
    task assert_reset_idle;
        begin
            if(busy||error||done||cycles!=0||read_bytes!=0||write_bytes!=0||engine.state!=0||
                queue.count!=0||queue.read_pointer!=0||queue.write_pointer!=0||f_wvalid||
                e_awvalid||e_arvalid||e_wvalid||m_awvalid||m_arvalid||m_wvalid||
                shared.rs!=0||shared.ws!=0||r_active||w_active||b_pending||m_rvalid||m_bvalid)
                $fatal(1,"Common reset left stale state/VALID/response");
        end
    endtask
    task common_reset_and_quiet;
        integer n;
        begin
            for(n=0;n<MEMORY_SIZE;n=n+1) quiet_expected[n]=memory[n];
            resetn=0;start=0;c_arvalid=0;c_awvalid=0;
            hold_ar=0;hold_aw=0;hold_b=0;hold_r_limit=-1;hold_w_limit=-1;
            repeat(5) begin @(negedge clk);assert_reset_idle;end
            resetn=1;
            repeat(50) begin @(negedge clk);assert_reset_idle;quiet_cycles=quiet_cycles+1;end
            if(ar_total!=0||aw_total!=0||r_total!=0||w_total!=0||b_total!=0)
                $fatal(1,"Old AXI transaction appeared after reset");
            for(n=0;n<MEMORY_SIZE;n=n+1) begin
                if(memory[n]!==quiet_expected[n]) $fatal(1,"Old queued write changed memory after reset address=%x",n);
                byte_checks=byte_checks+1;
            end
        end
    endtask
    // Independent reference, including all 64 KiB outside the rectangle.
    task normal_command;
        input integer which;
        integer n,row,col,address,timeout,expected_read,expected_write;
        reg [31:0] fg,bg,result;
        begin
            if(which==0) begin
                op=1;src_addr=32'h2004;dst_addr=32'h6008;width=33;height=3;
                src_stride=160;dst_stride=168;alpha=255;alpha_enable=0;key_enable=0;
                // Row RAMs intentionally have no reset. Change the source on
                // every recovery so stale pre-reset RAM contents cannot pass.
                for(n=32'h2000;n<32'h2600;n=n+1) memory[n]=(n*37+(n>>3)+reset_cases*61)&255;
            end else if(which==1) begin
                op=1;src_addr=32'h200c;dst_addr=32'h8004;width=19;height=2;
                src_stride=96;dst_stride=100;alpha=73;alpha_enable=1;key_enable=1;color_key=24'h112233;
                for(row=0;row<height;row=row+1) for(col=0;col<width;col=col+1)
                    if((row+col)%5==0) begin
                        address=src_addr+row*src_stride+col*4;
                        memory[address]=8'h33;memory[address+1]=8'h22;memory[address+2]=8'h11;memory[address+3]=8'hab;
                    end
            end else begin
                op=0;src_addr=0;dst_addr=32'ha00c;width=45;height=2;
                src_stride=0;dst_stride=192;alpha=255;alpha_enable=0;key_enable=0;
                fill_color=32'hfe6582a1^(reset_cases*32'h00010101);
            end
            for(n=0;n<MEMORY_SIZE;n=n+1) expected[n]=memory[n];
            expected_read=0;expected_write=0;
            for(row=0;row<height;row=row+1) begin
                if(op==1) expected_read=expected_read+((((src_addr+row*src_stride)%16)+width*4+15)/16)*16;
                if(alpha_enable&&alpha!=255) expected_read=expected_read+((((dst_addr+row*dst_stride)%16)+width*4+15)/16)*16;
                for(col=0;col<width;col=col+1) begin
                    fg=(op==0)?fill_color:get_pixel(src_addr+row*src_stride+col*4);
                    address=dst_addr+row*dst_stride+col*4;bg=get_pixel(address);
                    if(!(key_enable&&fg[23:0]==color_key)) begin
                        result=alpha_enable?blend(fg,bg,alpha):fg;
                        for(n=0;n<4;n=n+1) expected[address+n]=result[n*8+:8];
                        expected_write=expected_write+4;
                    end
                end
            end
            launch;
            timeout=0;
            while(!done) begin
                @(negedge clk);timeout=timeout+1;
                if(timeout>10000) $fatal(1,"Recovery timeout command=%0d state=%0d",which,engine.state);
            end
            if(busy||error||read_bytes!=expected_read||write_bytes!=expected_write||
                queue.count!=0||shared.rs!=0||shared.ws!=0||r_active||w_active||b_pending||m_rvalid||m_bvalid)
                $fatal(1,"Recovery completion/counter/outstanding mismatch command=%0d",which);
            for(n=0;n<MEMORY_SIZE;n=n+1) begin
                if(memory[n]!==expected[n]) $fatal(1,"Recovery byte mismatch command=%0d address=%x actual=%x expected=%x",which,n,memory[n],expected[n]);
                byte_checks=byte_checks+1;
            end
            recovery_commands=recovery_commands+1;
            @(negedge clk);if(done) $fatal(1,"Recovery DONE is not a pulse");
        end
    endtask
    function automatic reached;
        input integer target;
        begin
            case(target)
                0: reached=engine.state==4&&shared.rs==1&&shared.ro==0;
                1: reached=engine.state==5&&engine.rd_index==2&&r_position==2&&!m_rvalid;
                2: reached=engine.state==12&&shared.ws==1&&shared.wo==0;
                3: reached=engine.state==14&&queue.count==4&&w_position==2&&shared.ws==2;
                4: reached=engine.state==15&&queue.count==0&&b_pending&&!m_bvalid;
                5: reached=engine.state==5&&r_position==2&&m_rvalid;
                6: reached=engine.state==15&&queue.count==0&&m_bvalid;
                7: reached=done&&error&&!busy;
                default: reached=0;
            endcase
        end
    endfunction
    task exercise_reset;
        input integer target;
        integer timeout,prior_w;
        begin
            prior_w=w_total;
            op=1;src_addr=32'h2004;dst_addr=32'h5008;width=33;height=2;
            src_stride=160;dst_stride=168;alpha=255;alpha_enable=0;key_enable=0;fill_color=32'hde571234;
            if(target==0||target==2) begin
                // Internal client acceptance is decoupled from DDR AR/AWREADY.
                // A competing request owns the stalled bus to hold the engine
                // at RD_ADDR/WR_ADDR for several cycles before common reset.
                if(target==0) begin hold_ar=1;c_arvalid=1;end
                else begin hold_aw=1;c_awvalid=1;end
                timeout=0;
                while((target==0&&shared.rs!=1)||(target==2&&shared.ws!=1)) begin
                    @(negedge clk);timeout=timeout+1;if(timeout>100) $fatal(1,"Could not prime competing client");
                end
                c_arvalid=0;c_awvalid=0;
            end
            if(target==1) hold_r_limit=2;
            if(target==3||target==4||target==6) begin
                op=0;dst_addr=32'h5004;width=64;height=2;dst_stride=272;
                if(target==3) hold_w_limit=2;
                if(target==4) hold_b=1;
            end
            if(target==7) op=3;
            launch;timeout=0;
            while(!reached(target)) begin
                @(negedge clk);timeout=timeout+1;
                if(timeout>10000) $fatal(1,"Could not reach reset case=%0d state=%0d queue=%0d",target,engine.state,queue.count);
            end
            if(target<=4) repeat(6) begin
                @(negedge clk);if(!reached(target)||!busy||done) $fatal(1,"Reset stall case not stable target=%0d",target);
            end
            $display("RESET case=%0d state=%0d FIFO=%0d ARstate=%0d AWstate=%0d RVALID=%b BVALID=%b ERROR=%b DONE=%b acceptedCommandW=%0d",target,engine.state,queue.count,shared.rs,shared.ws,m_rvalid,m_bvalid,error,done,w_total-prior_w);
            common_reset_and_quiet;
            reset_cases=reset_cases+1;
            normal_command(0);normal_command(1);normal_command(2);
            $display("PASS reset case=%0d: quiet 50 cycles, retained committed bytes, Copy/Alpha+Key/Fill correct across full 64 KiB",target);
        end
    endtask
    initial begin
        for(i=0;i<MEMORY_SIZE;i=i+1) memory[i]=(i*43+(i>>6)+29)&255;
        repeat(5) @(negedge clk);resetn=1;
        for(scenario=0;scenario<8;scenario=scenario+1) exercise_reset(scenario);
        $display("PASS BitBlt common-reset integration: resetCases=%0d recoveryCommands=%0d quietCycles=%0d byteChecks=%0d FIFOQueuedReset=1 RVALIDReset=1 BVALIDReset=1 errorDoneCleared=1",reset_cases,recovery_commands,quiet_cycles,byte_checks);
        $finish;
    end
    initial begin #10000000;$fatal(1,"Global common-reset test timeout");end
endmodule
