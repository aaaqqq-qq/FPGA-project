`timescale 1ns/1ps
// Targeted integration boundary test: engine -> actual axi_shared -> AXI model.
// Missing RLAST is intentionally an illegal slave response. It must not be
// confused with a legal SLVERR/DECERR burst ending in RLAST.
module tb_bitblt_bad_rlast;
    reg clk=0; always #5 clk=~clk;
    reg resetn=0,start=0,c_arvalid=0;
    wire busy,done,error;
    wire [31:0] cycles,read_bytes,write_bytes;
    wire [31:0] e_awaddr,e_araddr;
    wire [7:0] e_awlen,e_arlen;
    wire e_awvalid,e_wvalid,e_wlast,e_bready,e_arvalid,e_rready;
    wire [127:0] e_wdata;
    wire [15:0] e_wstrb;
    wire [2:0] s_awready,s_wready,s_bvalid,s_arready,s_rvalid,s_rlast;
    wire [5:0] s_bresp,s_rresp;
    wire [383:0] s_rdata;
    wire [27:0] m_awaddr,m_araddr;
    wire [7:0] m_awlen,m_arlen;
    wire [2:0] m_awsize,m_arsize;
    wire [1:0] m_awburst,m_arburst;
    wire m_awvalid,m_wvalid,m_wlast,m_bready,m_arvalid,m_rready;
    wire [127:0] m_wdata;
    wire [15:0] m_wstrb;
    reg [127:0] m_rdata=0;
    reg [1:0] m_rresp=0;
    reg m_rvalid=0,m_rlast=0,m_bvalid=0;
    reg r_active=0,w_active=0;
    reg [31:0] rng=32'h58c44a13;
    wire m_arready=!r_active && !m_rvalid && rng[0];
    wire m_awready=!w_active && !m_bvalid && rng[1];
    wire m_wready=w_active && rng[2];
    integer r_count=0,r_position=0,w_count=0,w_position=0;
    integer ar_total=0,aw_total=0,w_total=0,b_total=0;
    // mode 1: legal RRESP fault with correct count/RLAST. mode 2: omit final RLAST.
    integer fault_mode=0,fault_position=0;
    reg [1:0] fault_resp=2'b10;
    integer legal_fault_cases=0,successful_followups=0,n,p,rc;

    bitblt_engine engine(
        .clk(clk),.resetn(resetn),.start(start),.op(2'd1),
        .src_addr(32'h2000),.dst_addr(32'h8000),
        .src_stride(32'd0),.dst_stride(32'd0),.width(16'd20),.height(16'd1),
        .fill_color(32'd0),.alpha(8'd255),.color_key(24'd0),
        .alpha_enable(1'b0),.key_enable(1'b0),
        .busy(busy),.done(done),.error(error),.cycles(cycles),
        .read_bytes(read_bytes),.write_bytes(write_bytes),
        .m_awaddr(e_awaddr),.m_awlen(e_awlen),.m_awvalid(e_awvalid),.m_awready(s_awready[1]),
        .m_wdata(e_wdata),.m_wstrb(e_wstrb),.m_wlast(e_wlast),.m_wvalid(e_wvalid),.m_wready(s_wready[1]),
        .m_bresp(s_bresp[3:2]),.m_bvalid(s_bvalid[1]),.m_bready(e_bready),
        .m_araddr(e_araddr),.m_arlen(e_arlen),.m_arvalid(e_arvalid),.m_arready(s_arready[1]),
        .m_rdata(s_rdata[255:128]),.m_rresp(s_rresp[3:2]),
        .m_rlast(s_rlast[1]),.m_rvalid(s_rvalid[1]),.m_rready(e_rready)
    );
    axi_shared shared(
        .clk(clk),.resetn(resetn),
        .s_awaddr({32'd0,e_awaddr,32'd0}),.m_awaddr(m_awaddr),
        .s_awid(24'h004200),.m_awid(),.s_awlen({8'd0,e_awlen,8'd0}),.m_awlen(m_awlen),
        .s_awsize({3{3'd4}}),.m_awsize(m_awsize),.s_awburst({3{2'd1}}),.m_awburst(m_awburst),
        .s_awlock(3'd0),.m_awlock(),.s_awcache(12'd0),.m_awcache(),.s_awprot(9'd0),.m_awprot(),
        .s_awvalid({1'b0,e_awvalid,1'b0}),.m_awvalid(m_awvalid),.s_awready(s_awready),.m_awready(m_awready),
        .s_wdata({128'd0,e_wdata,128'd0}),.m_wdata(m_wdata),
        .s_wstrb({16'd0,e_wstrb,16'd0}),.m_wstrb(m_wstrb),
        .s_wlast({1'b0,e_wlast,1'b0}),.m_wlast(m_wlast),
        .s_wvalid({1'b0,e_wvalid,1'b0}),.m_wvalid(m_wvalid),.s_wready(s_wready),.m_wready(m_wready),
        .s_bid(),.m_bid(4'd0),.s_bresp(s_bresp),.m_bresp(2'd0),
        .s_bvalid(s_bvalid),.m_bvalid(m_bvalid),.s_bready({1'b0,e_bready,1'b0}),.m_bready(m_bready),
        .s_araddr({32'd0,e_araddr,32'h3000}),.m_araddr(m_araddr),
        .s_arid(24'h004200),.m_arid(),.s_arlen({8'd0,e_arlen,8'd0}),.m_arlen(m_arlen),
        .s_arsize({3{3'd4}}),.m_arsize(m_arsize),.s_arburst({3{2'd1}}),.m_arburst(m_arburst),
        .s_arlock(3'd0),.m_arlock(),.s_arcache(12'd0),.m_arcache(),.s_arprot(9'd0),.m_arprot(),
        .s_arvalid({1'b0,e_arvalid,c_arvalid}),.m_arvalid(m_arvalid),.s_arready(s_arready),.m_arready(m_arready),
        .s_rid(),.m_rid(4'd0),.s_rdata(s_rdata),.m_rdata(m_rdata),.s_rresp(s_rresp),.m_rresp(m_rresp),
        .s_rlast(s_rlast),.m_rlast(m_rlast),.s_rvalid(s_rvalid),.m_rvalid(m_rvalid),
        .s_rready({1'b0,e_rready,1'b1}),.m_rready(m_rready)
    );

    always @(negedge clk)
        rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};
    always @(posedge clk) begin
        if(!resetn) begin
            r_active<=0;w_active<=0;m_rvalid<=0;m_bvalid<=0;m_rlast<=0;m_rresp<=0;
            r_count<=0;r_position<=0;w_count<=0;w_position<=0;
            ar_total<=0;aw_total<=0;w_total<=0;b_total<=0;
        end else begin
            if(m_arvalid&&m_arready) begin
                if(m_araddr!=28'h2000 || m_arlen!=4 || m_arsize!=4 || m_arburst!=1)
                    $fatal(1,"Unexpected read burst metadata");
                r_active<=1;r_count<=m_arlen+1;r_position<=0;ar_total<=ar_total+1;
            end
            if(r_active&&!m_rvalid&&rng[3]) begin
                m_rdata<={4{32'h009abced}};
                m_rresp<=(fault_mode==1&&r_position==fault_position)?fault_resp:2'b00;
                m_rlast<=(fault_mode!=2)&&(r_position==r_count-1);
                m_rvalid<=1;
            end
            if(m_rvalid&&m_rready) begin
                m_rvalid<=0;
                // For mode 2 the intentionally broken model sends the promised
                // count and then stops, although no RLAST has completed AXI.
                if(r_position==r_count-1) r_active<=0;
                else r_position<=r_position+1;
            end
            if(m_awvalid&&m_awready) begin
                if(m_awaddr!=28'h8000 || m_awlen!=4 || m_awsize!=4 || m_awburst!=1)
                    $fatal(1,"Unexpected write burst metadata");
                w_active<=1;w_count<=m_awlen+1;w_position<=0;aw_total<=aw_total+1;
            end
            if(m_wvalid&&m_wready) begin
                if(m_wlast!==(w_position==w_count-1) || m_wstrb!==16'hffff || m_wdata!=={4{32'h009abced}})
                    $fatal(1,"Wrong write payload/strobe/WLAST");
                w_total<=w_total+1;
                if(m_wlast) begin w_active<=0;m_bvalid<=1;end
                else w_position<=w_position+1;
            end
            if(m_bvalid&&m_bready) begin m_bvalid<=0;b_total<=b_total+1;end
        end
    end

    task launch;
        begin
            @(negedge clk);start=1;
            @(negedge clk);start=0;
        end
    endtask
    task execute;
        input integer expected_error;
        integer timeout,prior_aw;
        begin
            prior_aw=aw_total;
            launch;
            timeout=0;
            while(!done) begin
                @(negedge clk);timeout=timeout+1;
                if(timeout>2000) $fatal(1,"Unexpected timeout mode=%0d state=%0d arbiter=%0d",fault_mode,engine.state,shared.rs);
            end
            if(error!==expected_error[0] || busy || read_bytes!=80)
                $fatal(1,"Wrong engine completion mode=%0d error=%b read_bytes=%0d",fault_mode,error,read_bytes);
            if(expected_error && (aw_total!=prior_aw || write_bytes!=0))
                $fatal(1,"Read fault issued destination writes");
            if(!expected_error && (write_bytes!=80 || shared.rs!=0 || shared.ws!=0 || w_active || m_bvalid))
                $fatal(1,"Normal command did not finish complete AXI transactions");
            @(negedge clk);
            if(done) $fatal(1,"DONE is not a pulse");
        end
    endtask

    initial begin
        repeat(5) @(negedge clk);resetn=1;
        // SLVERR and DECERR on first/middle/last beat all drain to legal RLAST.
        for(rc=2;rc<=3;rc=rc+1) begin
            for(p=0;p<5;p=p+2) begin
                fault_mode=1;fault_resp=rc;fault_position=p;
                execute(1);
                if(shared.rs!=0 || r_active || m_rvalid)
                    $fatal(1,"Legal RRESP fault did not release the real arbiter");
                legal_fault_cases=legal_fault_cases+1;
                fault_mode=0;execute(0);successful_followups=successful_followups+1;
                $display("PASS legal RRESP=%0d position=%0d: drained, no write, next command completed",rc,p);
            end
        end
        fault_mode=2;execute(1);
        if(shared.rs!=2 || shared.ro!=1 || r_active || m_rvalid)
            $fatal(1,"Missing-RLAST boundary was not reproduced");
        $display("OBSERVED illegal missing RLAST: engine DONE/error, real arbiter retains read owner 1");
        fault_mode=0;c_arvalid=1;launch;
        repeat(100) begin
            @(negedge clk);
            if(done || !busy || s_arready[0] || s_arready[1] || m_arvalid || shared.rs!=2)
                $fatal(1,"Read ownership unexpectedly recovered without RLAST/reset");
        end
        if(engine.state!=4) $fatal(1,"Next command is not blocked at RD_ADDR");
        $display("OBSERVED next engine command and competing client blocked for 100 cycles; system reset required");
        c_arvalid=0;start=0;resetn=0;
        repeat(5) @(negedge clk);resetn=1;
        execute(0);
        if(ar_total!=1 || aw_total!=1 || w_total!=5 || b_total!=1)
            $fatal(1,"System reset did not restore normal transactions");
        $display("PASS system reset recovered engine, actual arbiter and slave model");
        $display("PASS BitBlt actual-arbiter error boundary: legalFaultCases=%0d successfulFollowups=%0d missingRlastDetected=1 missingRlastBlocksReads=1 commonResetRecovery=1",legal_fault_cases,successful_followups);
        $finish;
    end
    initial begin #1000000;$fatal(1,"Global boundary-test timeout");end
endmodule
