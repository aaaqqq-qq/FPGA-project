`timescale 1ns/1ps
module tb_batch32_apb;
 reg clk=0;always #5 clk=~clk;
 reg resetn=0,psel=0,penable=0,pwrite=0;
 reg [15:0] paddr=0;reg [31:0] pwdata=0;
 wire [31:0] prdata;wire alpha_enable,key_enable,batch32_enable;
 game_apb dut(.clk(clk),.resetn(resetn),.paddr(paddr),.psel(psel),.penable(penable),
  .pwrite(pwrite),.pwdata(pwdata),.prdata(prdata),.busy(1'b0),.done(1'b0),.error(1'b0),
  .cycles(32'd0),.read_bytes(32'd0),.write_bytes(32'd0),.front_addr(32'd0),.swap_pending(1'b0),
  .frame_count(32'd0),.swap_count(32'd0),.underflow_count(32'd0),.cal_done(1'b1),
  .alpha_enable(alpha_enable),.key_enable(key_enable),.batch32_enable(batch32_enable));
 task flags(input [31:0] value);
  begin
   @(negedge clk);paddr='h34;pwdata=value;psel=1;penable=1;pwrite=1;
   @(negedge clk);psel=0;penable=0;pwrite=0;
   if(prdata!==value || {batch32_enable,key_enable,alpha_enable}!==value[2:0])
    $fatal(1,"FLAGS readback/control mismatch value=%h data=%h",value,prdata);
  end
 endtask
 initial begin
  repeat(3)@(negedge clk);resetn=1;
  @(negedge clk);paddr='h4c;#1;
  if(prdata!==6)$fatal(1,"capabilities do not advertise legacy batch and batch32");
  flags(0);flags(3);flags(7);flags(4);flags(0);
  @(negedge clk);resetn=0;@(negedge clk);
  if(batch32_enable!==0)$fatal(1,"batch32 reset");
  $display("PASS APB capability6, FLAGS0/3/7/4/0 and reset");$finish;
 end
endmodule
