`timescale 1ns/1ps
module tb_bitblt;
    reg clk=0; always #5 clk=~clk;
    reg resetn=0,start=0;
    reg [1:0] op=0;
    reg [31:0] src_addr=0,dst_addr=0,src_stride=0,dst_stride=0,fill_color=0;
    reg [15:0] width=0,height=0;
    reg [7:0] alpha=255;
    reg [23:0] color_key=0;
    reg alpha_enable=0,key_enable=0;
    wire busy,done,error;
    wire [31:0] cycles,read_bytes,write_bytes;
    wire [31:0] awaddr,araddr;
    wire [7:0] awlen,arlen;
    wire awvalid,wvalid,wlast,bready,arvalid,rready;
    wire [127:0] wdata;
    wire [15:0] wstrb;
    wire [127:0] engine_wdata;
    wire [15:0] engine_wstrb;
    wire engine_wlast,engine_wvalid,engine_wready;
    reg [127:0] rdata=0;
    reg [1:0] bresp=0,rresp=0;
    reg bvalid=0,rvalid=0,rlast=0;
    reg aw_gate=0,w_gate=0,ar_gate=0,r_gate=0;
    reg w_active=0,r_active=0,b_pending=0;
    wire awready=aw_gate && !w_active && !bvalid && !b_pending;
    wire wready=w_gate && w_active;
    wire arready=ar_gate && !r_active && !rvalid;
    integer w_address,r_address,w_count,r_count,w_position,r_position,b_delay;
    integer fault_mode=0;
    // -1 retains the original fault injection; directed tests select a burst.
    integer fault_transaction=-1,fault_beat=0;
    reg [31:0] random_state=32'h456789ab;
    localparam integer MEMORY_SIZE=2097152;
    reg [7:0] memory [0:MEMORY_SIZE-1];
    reg [7:0] expected [0:MEMORY_SIZE-1];
    integer i,j,k,test_count=0,ar_transactions=0,aw_transactions=0;
    integer multi_read=0,multi_write=0,page_splits=0,w_beats=0,b_responses=0;
    integer last_ar_transactions,last_aw_transactions;
    reg aw_held=0,ar_held=0,w_held=0;
    reg [31:0] aw_held_addr,ar_held_addr;
    reg [7:0] aw_held_len,ar_held_len;
    reg [127:0] w_held_data;
    reg [15:0] w_held_strb;
    reg w_held_last;
    reg engine_w_held=0,engine_held_last;
    reg [127:0] engine_held_data;
    reg [15:0] engine_held_strb;

`ifdef WITH_WRITE_FIFO
    write_beat_fifo write_queue(
        .clk(clk),.resetn(resetn),
        .s_valid(engine_wvalid),.s_ready(engine_wready),
        .s_data({engine_wlast,engine_wstrb,engine_wdata}),
        .m_valid(wvalid),.m_ready(wready),.m_data({wlast,wstrb,wdata})
    );
`else
    assign wdata=engine_wdata;
    assign wstrb=engine_wstrb;
    assign wlast=engine_wlast;
    assign wvalid=engine_wvalid;
    assign engine_wready=wready;
`endif

    bitblt_engine dut(
        .clk(clk),.resetn(resetn),.start(start),.op(op),
        .src_addr(src_addr),.dst_addr(dst_addr),.src_stride(src_stride),.dst_stride(dst_stride),
        .width(width),.height(height),.fill_color(fill_color),.alpha(alpha),.color_key(color_key),
        .alpha_enable(alpha_enable),.key_enable(key_enable),
        .busy(busy),.done(done),.error(error),.cycles(cycles),.read_bytes(read_bytes),.write_bytes(write_bytes),
        .m_awaddr(awaddr),.m_awlen(awlen),.m_awvalid(awvalid),.m_awready(awready),
        .m_wdata(engine_wdata),.m_wstrb(engine_wstrb),.m_wlast(engine_wlast),.m_wvalid(engine_wvalid),.m_wready(engine_wready),
        .m_bresp(bresp),.m_bvalid(bvalid),.m_bready(bready),
        .m_araddr(araddr),.m_arlen(arlen),.m_arvalid(arvalid),.m_arready(arready),
        .m_rdata(rdata),.m_rresp(rresp),.m_rlast(rlast),.m_rvalid(rvalid),.m_rready(rready)
    );

    function automatic [31:0] get_pixel;
        input integer address;
        begin get_pixel={memory[address+3],memory[address+2],memory[address+1],memory[address]}; end
    endfunction
    task put_pixel;
        input integer address;
        input [31:0] pixel;
        integer n;
        begin for(n=0;n<4;n=n+1) memory[address+n]=pixel[n*8+:8]; end
    endtask
    function automatic [31:0] blended;
        input [31:0] foreground,background;
        input [7:0] a;
        integer n,value;
        begin
            if(a==0) blended=background;
            else if(a==255) blended=foreground;
            else begin
                blended=0;
                for(n=0;n<3;n=n+1) begin
                    value=(foreground[n*8+:8]*a+background[n*8+:8]*(255-a)+127)/255;
                    blended[n*8+:8]=value;
                end
            end
        end
    endfunction

    // Deterministic backpressure on every channel, including delayed B replies.
    always @(negedge clk) begin
        random_state={random_state[30:0],random_state[31]^random_state[21]^random_state[1]^random_state[0]};
        aw_gate=random_state[0]|random_state[1];
        w_gate=random_state[2]|random_state[3];
        ar_gate=random_state[4]|random_state[5];
        r_gate=random_state[6]|random_state[7];
    end

    always @(posedge clk) begin
        if(!resetn) begin
            w_active<=0; r_active<=0; b_pending<=0; bvalid<=0; rvalid<=0;
            aw_held<=0; ar_held<=0; w_held<=0;
            engine_w_held<=0;
            b_delay<=0; rresp<=0; bresp<=0; rlast<=0;
        end else begin
            if(aw_held && (!awvalid || awaddr!==aw_held_addr || awlen!==aw_held_len))
                $fatal(1,"AW changed while stalled");
            if(ar_held && (!arvalid || araddr!==ar_held_addr || arlen!==ar_held_len))
                $fatal(1,"AR changed while stalled");
            if(w_held && (!wvalid || wdata!==w_held_data || wstrb!==w_held_strb || wlast!==w_held_last))
                $fatal(1,"W changed while stalled");
            if(engine_w_held && (!engine_wvalid || engine_wdata!==engine_held_data ||
                engine_wstrb!==engine_held_strb || engine_wlast!==engine_held_last))
                $fatal(1,"Engine W changed while stalled at FIFO input");
            aw_held<=awvalid&&!awready; aw_held_addr<=awaddr; aw_held_len<=awlen;
            ar_held<=arvalid&&!arready; ar_held_addr<=araddr; ar_held_len<=arlen;
            w_held<=wvalid&&!wready; w_held_data<=wdata; w_held_strb<=wstrb; w_held_last<=wlast;
            engine_w_held<=engine_wvalid&&!engine_wready;
            engine_held_data<=engine_wdata;engine_held_strb<=engine_wstrb;engine_held_last<=engine_wlast;
            if(awvalid&&awready) begin
                if(awlen>15 || awaddr[3:0]!=0 || (awaddr[11:0]+((awlen+1)*16)>4096))
                    $fatal(1,"Bad write burst address/length %x %d",awaddr,awlen);
                if(awaddr+((awlen+1)*16)>MEMORY_SIZE) $fatal(1,"Test memory write bounds");
                w_address<=awaddr; w_count<=awlen+1; w_position<=0; w_active<=1;
                aw_transactions<=aw_transactions+1;
                if(awlen>0) multi_write<=multi_write+1;
                if(awaddr[11:0]+((awlen+1)*16)==4096) page_splits<=page_splits+1;
            end
            if(wvalid&&wready) begin
                if(wlast!==(w_position==w_count-1)) $fatal(1,"Wrong WLAST");
                for(j=0;j<16;j=j+1) if(wstrb[j]) memory[w_address+j]<=wdata[j*8+:8];
                w_beats<=w_beats+1;
                if(wlast) begin
                    w_active<=0; b_pending<=1; b_delay<=2+random_state[11:8];
                    bresp<=(fault_mode==2 &&
                        (fault_transaction<0 || aw_transactions==fault_transaction))?2'b10:2'b00;
                end else begin w_position<=w_position+1; w_address<=w_address+16; end
            end
            if(b_pending) begin
                if(b_delay==0) begin b_pending<=0; bvalid<=1; end
                else b_delay<=b_delay-1;
            end
            if(bvalid&&bready) begin bvalid<=0; b_responses<=b_responses+1; end
            if(arvalid&&arready) begin
                if(arlen>15 || araddr[3:0]!=0 || (araddr[11:0]+((arlen+1)*16)>4096))
                    $fatal(1,"Bad read burst address/length %x %d",araddr,arlen);
                if(araddr+((arlen+1)*16)>MEMORY_SIZE) $fatal(1,"Test memory read bounds");
                r_address<=araddr; r_count<=arlen+1; r_position<=0; r_active<=1;
                ar_transactions<=ar_transactions+1;
                if(arlen>0) multi_read<=multi_read+1;
                if(araddr[11:0]+((arlen+1)*16)==4096) page_splits<=page_splits+1;
            end
            if(r_active&&!rvalid&&r_gate) begin
                for(k=0;k<16;k=k+1) rdata[k*8+:8]<=memory[r_address+k];
                rresp<=(fault_mode==1 && r_position==fault_beat &&
                    (fault_transaction<0 || ar_transactions==fault_transaction))?2'b10:2'b00;
                if(fault_mode==3) rlast<=1;
                else if(fault_mode==4) rlast<=0;
                else rlast<=(r_position==r_count-1);
                rvalid<=1;
            end
            if(rvalid&&rready) begin
                rvalid<=0;
                if(r_position==r_count-1 || fault_mode==3) r_active<=0;
                else begin r_address<=r_address+16; r_position<=r_position+1; end
            end
            if(done && (w_active||b_pending||bvalid||r_active||rvalid))
                $fatal(1,"DONE before AXI completion");
`ifdef WITH_WRITE_FIFO
            if(done && write_queue.count!=0) $fatal(1,"DONE before queued W beats reached DDR");
`endif
        end
    end

    task execute;
        input [1:0] operation;
        input integer source,destination,pixels,rows,source_step,destination_step;
        input [31:0] color;
        input integer a,alpha_on,key_on;
        input [23:0] key;
        input integer expected_error,should_model;
        integer row,col,n,address,timeout,expected_written,expected_read,compare_bytes;
        reg [31:0] fg,bg,out;
        begin
            compare_bytes=131072;
            if(should_model && destination+(rows-1)*destination_step+pixels*4>compare_bytes)
                compare_bytes=MEMORY_SIZE;
            for(n=0;n<compare_bytes;n=n+1) expected[n]=memory[n];
            expected_written=0; expected_read=0;
            if(should_model) begin
                for(row=0;row<rows;row=row+1) begin
                    if(operation==1) expected_read=expected_read+((((source+row*source_step)%16)+pixels*4+15)/16)*16;
                    if(alpha_on&&a!=255) expected_read=expected_read+((((destination+row*destination_step)%16)+pixels*4+15)/16)*16;
                    for(col=0;col<pixels;col=col+1) begin
                        fg=(operation==0)?color:get_pixel(source+row*source_step+col*4);
                        address=destination+row*destination_step+col*4;
                        bg=get_pixel(address);
                        if(!(key_on && fg[23:0]==key)) begin
                            out=alpha_on?blended(fg,bg,a):fg;
                            for(n=0;n<4;n=n+1) expected[address+n]=out[n*8+:8];
                            expected_written=expected_written+4;
                        end
                    end
                end
            end
            last_ar_transactions=ar_transactions; last_aw_transactions=aw_transactions;
            @(negedge clk);
            op=operation;src_addr=source;dst_addr=destination;width=pixels;height=rows;
            src_stride=source_step;dst_stride=destination_step;fill_color=color;
            alpha=a;alpha_enable=alpha_on;key_enable=key_on;color_key=key;start=1;
            @(negedge clk);start=0;
            // Registers are free to change immediately after START acceptance.
            op=3;src_addr=32'hffffffff;dst_addr=32'hfffffffe;width=65535;height=65535;
            src_stride=3;dst_stride=3;fill_color=~color;alpha=17;alpha_enable=0;key_enable=0;color_key=~key;
            timeout=0;
            while(!done) begin
                @(negedge clk); timeout=timeout+1;
                if(timeout>500000) $fatal(1,"Timeout test %0d state=%0d",test_count,dut.state);
                // A second START while BUSY must not replace the latched command.
                if(timeout==10 && busy && !done) start=1;
                if(timeout==11) start=0;
            end
            start=0;
            if(error!==expected_error[0]) $fatal(1,"Error flag test %0d expected %0d actual %b",test_count,expected_error,error);
            if(busy) $fatal(1,"BUSY remains after DONE");
            for(n=0;n<compare_bytes;n=n+1) if(memory[n]!==expected[n])
                $fatal(1,"Memory mismatch test=%0d address=%x actual=%x expected=%x",test_count,n,memory[n],expected[n]);
            if(!expected_error) begin
                if(read_bytes!=expected_read || write_bytes!=expected_written)
                    $fatal(1,"Counters test %0d read=%0d/%0d write=%0d/%0d",test_count,read_bytes,expected_read,write_bytes,expected_written);
            end
            if(!should_model && fault_mode==0 && (ar_transactions!=last_ar_transactions||aw_transactions!=last_aw_transactions))
                $fatal(1,"Invalid/NOP operation touched AXI");
            test_count=test_count+1;
            @(negedge clk); if(done) $fatal(1,"DONE is not a one-cycle pulse");
        end
    endtask

    integer rcase,rw,rh,soff,doff,ss,ds,ra,ka,ae,ke;
    initial begin
        for(i=0;i<MEMORY_SIZE;i=i+1) memory[i]=(i*37+(i>>7)+19)&255;
        for(i=0;i<=65152;i=i+1)
            if(dut.divide_255(i)!=(i/255)) $fatal(1,"Exact divide255 mismatch input=%0d",i);
        repeat(5) @(negedge clk);resetn=1;
        // Packed tile prefetch: multiple source bursts, destination lane shift,
        // partial/keyed writes and opaque cached copy across all rows.
        execute(1,16'h2ff0,16'h8ffc,32,16,128,140,0,224,1,1,24'h112233,0,1);
        execute(1,16'h2000,16'h8004,8,8,32,36,0,224,1,1,24'h112233,0,1);
        execute(1,16'h2000,16'h8000,16,16,64,64,0,255,0,0,0,0,1);
        // New aligned path: page crossings, row-stride alignment changes,
        // and flags that must fall back to the existing pixel blender.
        execute(1,16'h2ff0,16'h8ff0,128,3,528,544,0,255,0,0,0,0,1);
        execute(1,16'h2000,16'h8000,80,3,324,328,0,255,0,0,0,0,1);
        execute(1,16'h2000,16'h8000,80,3,320,320,0,224,1,1,24'h112233,0,1);
        fault_mode=1;execute(1,16'h2000,16'h8000,128,1,0,0,0,255,0,0,0,1,0);fault_mode=0;
        if($test$plusargs("TARGETED")) begin
            // Fill must ignore unused source alignment/range, while Copy must not.
            execute(0,1,16'h5004,19,3,1,84,32'had678901,255,0,0,0,0,1);
            execute(0,32'hffffffff,16'h600c,23,2,32'hffffffff,100,32'h12345678,255,0,0,0,0,1);
            execute(1,16'h2001,16'h8004,19,1,80,84,0,255,0,0,0,1,0);
            execute(1,16'h2004,16'h8004,19,2,81,84,0,255,0,0,0,1,0);
            // Both read buffers reach 257 beats; key includes a nonzero X byte.
            for(i=0;i<2;i=i+1) for(j=0;j<1024;j=j+1)
                if(j%7==0) put_pixel(16'h2ffc+i*4100+j*4,32'hfd112233);
            execute(1,16'h2ffc,16'h8ffc,1024,2,4100,4124,0,128,1,1,24'h112233,0,1);
            // Non-first source-burst response error drains all accepted beats.
            fault_mode=1;fault_transaction=ar_transactions+3;fault_beat=2;
            execute(1,16'h2ffc,16'h8ffc,81,1,0,0,0,255,0,0,0,1,0);
            fault_mode=0;fault_transaction=-1;fault_beat=0;
            execute(1,16'h2004,16'ha00c,13,1,0,0,0,255,0,0,0,0,1);
            // Error on a background-read burst must not write the current row.
            fault_mode=1;fault_transaction=ar_transactions+5;fault_beat=7;
            execute(1,16'h2ffc,16'h8ffc,81,1,0,0,0,73,1,1,24'h112233,1,0);
            fault_mode=0;fault_transaction=-1;fault_beat=0;
            execute(1,16'h200c,16'ha004,17,1,0,0,0,73,1,1,24'h112233,0,1);
            // A late B error follows accepted writes; next command clears ERROR.
            fault_mode=2;fault_transaction=aw_transactions+3;
            execute(0,0,16'h5ffc,81,1,0,0,32'h007755aa,255,0,0,0,1,1);
            fault_mode=0;fault_transaction=-1;
            execute(0,3,16'h7008,17,1,3,0,32'h00aabbcc,255,0,0,0,0,1);
            if(aw_transactions!=b_responses) $fatal(1,"Directed response accounting incomplete");
            $display("PASS BitBlt targeted tests=%0d AR=%0d AW=%0d multiread=%0d multiwrite=%0d pageends=%0d Wbeats=%0d B=%0d",
                test_count,ar_transactions,aw_transactions,multi_read,multi_write,page_splits,w_beats,b_responses);
            $finish;
        end
        // Every source/destination lane pair, thin/tail rectangles and stride.
        for(soff=0;soff<4;soff=soff+1) begin
            for(doff=0;doff<4;doff=doff+1) begin
                execute(0,0,16'h5000+doff*4,1+soff*4,3,0,64,32'h00a1b2c3,255,0,0,0,0,1);
                execute(1,16'h2000+soff*4,16'h8000+doff*4,7+soff,4,64,68,0,255,0,0,0,0,1);
            end
        end
        // 4-KiB splitting, maximum line-buffer occupancy and non-word tails.
        execute(0,0,16'h0ffc,1024,2,0,4108,32'h00ff0080,255,0,0,0,0,1);
        execute(1,16'h2ff8,16'h8ffc,1024,1,0,0,0,255,0,0,0,0,1);
        execute(1,16'h1ff4,16'h6ff8,81,3,352,360,0,255,0,0,0,0,1);
        // Endpoint alpha and repeated channel rounding; key checks original RGB.
        execute(1,16'h2004,16'h8008,37,3,160,164,0,0,1,0,0,0,1);
        execute(1,16'h2008,16'h8004,37,3,160,164,0,255,1,0,0,0,1);
        execute(1,16'h200c,16'h800c,79,4,336,340,0,128,1,0,0,0,1);
        execute(0,0,16'h7004,55,2,0,240,32'h009b6a37,73,1,0,0,0,1);
        for(i=0;i<31;i=i+1) if(i%3==0) put_pixel(16'h3004+i*4,32'hfe123456);
        execute(1,16'h3004,16'h9008,31,1,0,0,0,101,1,1,24'h123456,0,1);
        execute(1,16'h3004,16'h900c,31,1,0,0,0,255,0,1,24'h123456,0,1);
        execute(0,0,16'ha004,21,2,0,100,32'hab123456,77,1,1,24'h123456,0,1);
        execute(1,16'h3004,16'h9004,31,1,0,0,0,0,1,1,24'h123456,0,1);
        put_pixel(16'ha004,32'h00000000);
        execute(0,0,16'ha004,1,1,0,0,32'h00ffffff,1,1,0,0,0,1);
        put_pixel(16'ha008,32'h00000000);
        execute(0,0,16'ha008,1,1,0,0,32'h00ffffff,254,1,0,0,0,1);
        put_pixel(16'ha00c,32'h00ffffff);
        execute(0,0,16'ha00c,1,1,0,0,32'h00000000,1,1,0,0,0,1);
        put_pixel(16'ha000,32'h00ffffff);
        execute(0,0,16'ha000,1,1,0,0,32'h00ffffff,127,1,0,0,0,1);
        // Zero dimensions are successful NOPs even with unused bad parameters.
        execute(3,1,3,0,6,1,3,0,1,1,1,0,0,0);
        execute(1,1,3,9,0,1,3,0,1,1,1,0,0,0);
        execute(2,0,16'h5000,7,1,0,0,0,255,0,0,0,1,0);
        execute(0,0,16'h5002,7,1,0,0,0,255,0,0,0,1,0);
        execute(1,16'h2002,16'h5000,7,1,0,0,0,255,0,0,0,1,0);
        execute(0,0,16'h5000,1025,1,0,0,0,255,0,0,0,1,0);
        execute(0,0,16'h5000,8,2,0,28,0,255,0,0,0,1,0);
        execute(1,16'h2000,16'h5000,8,2,28,32,0,255,0,0,0,1,0);
        execute(0,0,32'h0ffffffc,2,1,0,0,0,255,0,0,0,1,0);
        execute(1,32'h0ffffffc,16'h5000,2,1,0,0,0,255,0,0,0,1,0);
        execute(0,0,16'h5000,2,65535,0,32'hfffffff0,0,255,0,0,0,1,0);
        // R error drains the accepted burst; no destination writes are issued.
        fault_mode=1; execute(1,16'h2004,16'h8008,48,1,0,0,0,255,0,0,0,1,0);
        fault_mode=3; execute(1,16'h2004,16'h8008,48,1,0,0,0,255,0,0,0,1,0);
        fault_mode=4; execute(1,16'h2004,16'h8008,48,1,0,0,0,255,0,0,0,1,0);
        // B error is reported only after accepted data and returned B response.
        fault_mode=2; execute(0,0,16'h5004,11,1,0,0,32'h00998877,255,0,0,0,1,1);
        fault_mode=0;
        for(rcase=0;rcase<100;rcase=rcase+1) begin
            rw=1+(random_state%93);rh=1+(random_state[15:8]%5);
            ss=(rw+(random_state[7:5]%7))*4;ds=(rw+(random_state[20:16]%9))*4;
            ra=random_state[23:16];ae=random_state[27];ke=random_state[28];ka=random_state[25:24];
            // Seed matching key pixels without assuming their high X byte.
            for(i=0;i<rh;i=i+1) for(j=0;j<rw;j=j+1)
                if((i+j)%5==0) put_pixel(16'h2000+ka*4+i*ss+j*4,32'hab112233);
            execute(rcase%2,16'h2000+ka*4,16'h8000+(random_state[3:2]*4),rw,rh,ss,ds,
                32'h005eaf17,ra,ae,ke,24'h112233,0,1);
        end
        execute(0,0,0,640,480,0,2560,32'h00417bc9,255,0,0,0,0,1);
        if(cycles>=250000) $fatal(1,"640x480 solid fill too slow cycles=%0d",cycles);
        $display("640x480 solid fill cycles=%0d bytes=%0d",cycles,write_bytes);
`ifdef WITH_WRITE_FIFO
        $display("Write path: engine -> 4-beat FIFO -> DDR model");
`else
        $display("Write path: engine -> DDR model (direct)");
`endif
        if(multi_read==0||multi_write==0||page_splits<2||aw_transactions!=b_responses)
            $fatal(1,"Coverage/response accounting incomplete");
        $display("PASS BitBlt tests=%0d AR=%0d AW=%0d multiread=%0d multiwrite=%0d pageends=%0d Wbeats=%0d B=%0d",
            test_count,ar_transactions,aw_transactions,multi_read,multi_write,page_splits,w_beats,b_responses);
        $finish;
    end
    initial begin #100000000; $fatal(1,"Global simulation timeout"); end
endmodule
