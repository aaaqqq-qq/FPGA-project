#include "stage.h"
#include <stdio.h>
int main(void){stage_stress(4096);int maxx=0,maxy=0;for(int f=0;f<3600;f++){stage_stress_step();if(stage.count!=4096||stage.rejected)return 1;for(unsigned i=0;i<stage.count;i++){Shot *b=&stage.shots[i];if(b->x<8*Q||b->x>1016*Q||b->y<8*Q||b->y>680*Q||b->tile<24||b->tile>39)return 2;if(b->x/Q>maxx)maxx=b->x/Q;if(b->y/Q>maxy)maxy=b->y/Q;}}printf("PASS 4096 sprites, 3600 updates; extent %d,%d; no rejected or out-of-field sprites\n",maxx,maxy);return 0;}
