`timescale 1ns/1ps
// Sparse DDR model: verify the final legal 32-bit pixel without a 256-MiB array.
module tb_bitblt_top_address;
    localparam [31:0] TOP_BEAT = 32'h0ffffff0;
    localparam [31:0] LAST_PIXEL = 32'h0ffffffc;
    localparam [31:0] SRC_BEAT = 32'h00102000;
    localparam [31:0] DST_BEAT = 32'h00203000;
    reg clk=0,resetn=0,start=0;
    always #5 clk=~clk;
    reg [1:0] op=0;
    reg [31:0] src_addr=0,dst_addr=0,src_stride=0,dst_stride=0,fill_color=0;
    reg [15:0] width=0,height=0;
    wire busy,done,error;
    wire [31:0] cycles,read_bytes,write_bytes,awaddr,araddr;
    wire [7:0] awlen,arlen;
    wire awvalid,arvalid,bready,rready;
    wire [127:0] engine_wdata,wdata;
    wire [15:0] engine_wstrb,wstrb;
    wire engine_wlast,engine_wvalid,engine_wready,wlast,wvalid;
    reg [127:0] rdata=0;
    reg rvalid=0,rlast=0,bvalid=0;
    reg aw_gate=0,ar_gate=0,w_gate=0,r_gate=0;
    reg write_active=0,read_active=0,b_pending=0;
    wire awready=aw_gate && !write_active && !b_pending && !bvalid;
    wire arready=ar_gate && !read_active && !rvalid;
    wire wready=w_gate && write_active;
    reg [31:0] read_address=0,write_address=0;
    reg [15:0] wanted_strobe=0;
    integer b_delay=0;
    reg [31:0] random_state=32'hb751a93d;
    reg [127:0] top_word,source_word,destination_word;
    reg [127:0] expected_top,expected_source,expected_destination;
    integer tests=0,ars=0,aws=0,ws=0,bs=0;
    integer aw_stalls=0,ar_stalls=0,w_stalls=0,r_delays=0;
    integer n,repeat_case;
    reg aw_held=0,ar_held=0,w_held=0,engine_held=0;
    reg [31:0] held_awaddr,held_araddr;
    reg [7:0] held_awlen,held_arlen;
    reg [144:0] held_w,held_engine;

`ifdef WITH_WRITE_FIFO
    write_beat_fifo write_queue(
        .clk(clk),.resetn(resetn),.s_valid(engine_wvalid),.s_ready(engine_wready),
        .s_data({engine_wlast,engine_wstrb,engine_wdata}),
        .m_valid(wvalid),.m_ready(wready),.m_data({wlast,wstrb,wdata}));
`else
    assign wdata=engine_wdata;
    assign wstrb=engine_wstrb;
    assign wlast=engine_wlast;
    assign wvalid=engine_wvalid;
    assign engine_wready=wready;
`endif
    bitblt_engine dut(
        .clk(clk),.resetn(resetn),.start(start),.op(op),
        .src_addr(src_addr),.dst_addr(dst_addr),.src_stride(src_stride),.dst_stride(dst_stride),
        .width(width),.height(height),.fill_color(fill_color),.alpha(8'd255),
        .color_key(24'd0),.alpha_enable(1'b0),.key_enable(1'b0),
        .busy(busy),.done(done),.error(error),.cycles(cycles),
        .read_bytes(read_bytes),.write_bytes(write_bytes),
        .m_awaddr(awaddr),.m_awlen(awlen),.m_awvalid(awvalid),.m_awready(awready),
        .m_wdata(engine_wdata),.m_wstrb(engine_wstrb),.m_wlast(engine_wlast),
        .m_wvalid(engine_wvalid),.m_wready(engine_wready),.m_bresp(2'b00),
        .m_bvalid(bvalid),.m_bready(bready),
        .m_araddr(araddr),.m_arlen(arlen),.m_arvalid(arvalid),.m_arready(arready),
        .m_rdata(rdata),.m_rresp(2'b00),.m_rlast(rlast),.m_rvalid(rvalid),.m_rready(rready));

    function automatic [127:0] sparse_read;
        input [31:0] address;
        begin
            case(address)
                TOP_BEAT: sparse_read=top_word;
                SRC_BEAT: sparse_read=source_word;
                DST_BEAT: sparse_read=destination_word;
                default: begin sparse_read=0; $fatal(1,"Unexpected sparse DDR read %x",address); end
            endcase
        end
    endfunction

    always @(negedge clk) begin
        random_state={random_state[30:0],random_state[31]^random_state[21]^random_state[1]^random_state[0]};
        aw_gate=random_state[0]; ar_gate=random_state[3];
        w_gate=random_state[6]; r_gate=random_state[9];
    end
    always @(posedge clk) begin
        if(!resetn) begin
            write_active<=0;read_active<=0;b_pending<=0;bvalid<=0;rvalid<=0;
            aw_held<=0;ar_held<=0;w_held<=0;engine_held<=0;
        end else begin
            if(aw_held && (!awvalid || awaddr!==held_awaddr || awlen!==held_awlen))
                $fatal(1,"AW payload changed while stalled");
            if(ar_held && (!arvalid || araddr!==held_araddr || arlen!==held_arlen))
                $fatal(1,"AR payload changed while stalled");
            if(w_held && (!wvalid || {wlast,wstrb,wdata}!==held_w))
                $fatal(1,"W payload changed while stalled");
            if(engine_held && (!engine_wvalid || {engine_wlast,engine_wstrb,engine_wdata}!==held_engine))
                $fatal(1,"Engine W payload changed while stalled");
            aw_held<=awvalid&&!awready;held_awaddr<=awaddr;held_awlen<=awlen;
            ar_held<=arvalid&&!arready;held_araddr<=araddr;held_arlen<=arlen;
            w_held<=wvalid&&!wready;held_w<={wlast,wstrb,wdata};
            engine_held<=engine_wvalid&&!engine_wready;
            held_engine<={engine_wlast,engine_wstrb,engine_wdata};
            if(awvalid&&!awready) aw_stalls<=aw_stalls+1;
            if(arvalid&&!arready) ar_stalls<=ar_stalls+1;
            if(wvalid&&!wready) w_stalls<=w_stalls+1;
            if(read_active&&!rvalid&&!r_gate) r_delays<=r_delays+1;
            if(awvalid&&awready) begin
                if(awaddr!=={dst_addr[31:4],4'd0} || awlen!==0 || awaddr[3:0]!=0)
                    $fatal(1,"Wrong AW upper-bound alignment/address/length %x %d",awaddr,awlen);
                if({1'b0,awaddr}+33'd16>33'h010000000) $fatal(1,"AW crosses DDR end");
                if(awaddr!=TOP_BEAT && awaddr!=DST_BEAT) $fatal(1,"Unexpected write beat");
                write_address<=awaddr;write_active<=1;aws<=aws+1;
            end
            if(wvalid&&wready) begin
                if(!wlast || wstrb!==wanted_strobe) $fatal(1,"Wrong final-pixel WLAST/WSTRB %x",wstrb);
                for(n=0;n<16;n=n+1) if(wstrb[n]) begin
                    case(write_address)
                        TOP_BEAT: top_word[n*8+:8]<=wdata[n*8+:8];
                        DST_BEAT: destination_word[n*8+:8]<=wdata[n*8+:8];
                        default: $fatal(1,"Unexpected sparse DDR write");
                    endcase
                end
                write_active<=0;b_pending<=1;b_delay<=2+random_state[13:10];ws<=ws+1;
            end
            if(b_pending) begin
                if(b_delay==0) begin b_pending<=0;bvalid<=1;end
                else b_delay<=b_delay-1;
            end
            if(bvalid&&bready) begin bvalid<=0;bs<=bs+1;end
            if(arvalid&&arready) begin
                if(araddr!=={src_addr[31:4],4'd0} || arlen!==0 || araddr[3:0]!=0)
                    $fatal(1,"Wrong AR upper-bound alignment/address/length %x %d",araddr,arlen);
                if({1'b0,araddr}+33'd16>33'h010000000) $fatal(1,"AR crosses DDR end");
                if(araddr!=TOP_BEAT && araddr!=SRC_BEAT) $fatal(1,"Unexpected read beat");
                read_address<=araddr;read_active<=1;ars<=ars+1;
            end
            if(read_active&&!rvalid&&r_gate) begin
                rdata<=sparse_read(read_address);rlast<=1;rvalid<=1;
            end
            if(rvalid&&rready) begin rvalid<=0;read_active<=0;end
            if(done && (write_active||read_active||rvalid||bvalid||b_pending))
                $fatal(1,"DONE before AXI responses completed");
`ifdef WITH_WRITE_FIFO
            if(done && write_queue.count!=0) $fatal(1,"DONE with queued write beats");
`endif
        end
    end

    task execute;
        input [1:0] operation;
        input [31:0] source,destination;
        input [15:0] pixels;
        input [31:0] color;
        input expected_error;
        integer before_ar,before_aw,before_w,before_b,timeout;
        reg [31:0] foreground;
        reg [127:0] foreground_beat;
        begin
            // Distinct byte sentinels protect every nonselected lane in all beats.
            top_word=128'hd3c2b1a09f8e7d6c5b4a39281706f5e4;
            source_word=128'h7f6e5d4c3b2a1908f7e6d5c4b3a29180;
            destination_word=128'h7766554433221100ffeeddccbbaa9988;
            expected_top=top_word;expected_source=source_word;expected_destination=destination_word;
            wanted_strobe=16'h000f << (destination[3:2]*4);
            if(!expected_error) begin
                if(operation==0) foreground=color;
                else begin
                    foreground_beat=sparse_read({source[31:4],4'd0});
                    foreground=foreground_beat[source[3:2]*32+:32];
                end
                if({destination[31:4],4'd0}==TOP_BEAT)
                    expected_top[destination[3:2]*32+:32]=foreground;
                else expected_destination[destination[3:2]*32+:32]=foreground;
            end
            before_ar=ars;before_aw=aws;before_w=ws;before_b=bs;
            @(negedge clk);
            op=operation;src_addr=source;dst_addr=destination;src_stride=0;dst_stride=0;
            width=pixels;height=1;fill_color=color;start=1;
            @(negedge clk);start=0;timeout=0;
            while(!done) begin
                @(negedge clk);timeout=timeout+1;
                if(timeout>5000) $fatal(1,"Top-address command timeout test=%0d",tests);
            end
            if(error!==expected_error || busy) $fatal(1,"Wrong completion/error test=%0d",tests);
            if(top_word!==expected_top || source_word!==expected_source || destination_word!==expected_destination)
                $fatal(1,"Final pixel or protected lanes changed test=%0d",tests);
            if(expected_error) begin
                if(ars!=before_ar || aws!=before_aw || ws!=before_w || bs!=before_b || read_bytes!=0 || write_bytes!=0)
                    $fatal(1,"Rejected +4-byte overflow touched AXI test=%0d",tests);
            end else begin
                if(ars-before_ar!=operation || aws-before_aw!=1 || ws-before_w!=1 || bs-before_b!=1 ||
                    read_bytes!=operation*16 || write_bytes!=4)
                    $fatal(1,"Final legal pixel transaction/counter mismatch test=%0d",tests);
            end
            tests=tests+1;
            @(negedge clk);if(done) $fatal(1,"DONE is not a pulse");
        end
    endtask

    initial begin
        repeat(5) @(negedge clk);resetn=1;
        // The exclusive pixel limit is exactly 0x10000000; AXI beat ends there too.
        for(repeat_case=0;repeat_case<8;repeat_case=repeat_case+1) begin
            execute(0,0,LAST_PIXEL,1,32'hdeabcdef,0);
            execute(1,LAST_PIXEL,DST_BEAT+4,1,0,0);
            execute(1,SRC_BEAT+8,LAST_PIXEL,1,0,0);
        end
        // Add one pixel beyond the end, separately for each used address field.
        execute(0,0,LAST_PIXEL,2,32'hdeadbeef,1);
        execute(1,LAST_PIXEL,DST_BEAT+4,2,0,1);
        execute(1,SRC_BEAT+8,LAST_PIXEL,2,0,1);
        execute(0,0,32'h10000000,1,32'hdeadbeef,1);
        execute(1,32'h10000000,DST_BEAT+4,1,0,1);
        execute(1,SRC_BEAT+8,32'h10000000,1,0,1);
        if(aw_stalls==0 || ar_stalls==0 || w_stalls==0 || r_delays==0 || aws!=bs)
            $fatal(1,"Top-address pause/response coverage incomplete");
        $display("PASS BitBlt top-address tests=%0d AR=%0d AW=%0d W=%0d B=%0d AWstalls=%0d ARstalls=%0d Wstalls=%0d Rdelays=%0d",tests,ars,aws,ws,bs,aw_stalls,ar_stalls,w_stalls,r_delays);
        $finish;
    end
    initial begin #1000000;$fatal(1,"Top-address global timeout");end
endmodule
