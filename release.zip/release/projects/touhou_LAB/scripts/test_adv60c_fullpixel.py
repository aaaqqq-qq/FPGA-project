"""C3 real C renderer compared every viewport pixel against frozen source order."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess,time
r=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser();p.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=p.parse_args();b=r/'build/adv60c_fullpixel';b.mkdir(parents=True,exist_ok=True)
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)];flags=['-std=c99','-O2','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-Wno-unused-function','-DBB_HOST_TEST','-Isrc'];rename=['-Dadv_particles_init=old_init','-Dadv_particles_step=old_step']+['-Dadv_'+n+'=old_'+n for n in ['random','color','shape','golden']]
cmds=[cc+flags+rename+['-c','tests/adv60_reference/adv_model.c','-o',str(b/'old.o')],cc+flags+['-Dbb_cpu_execute=host_cpu_execute','-c','src/adv.c','-o',str(b/'adv.o')],cc+flags+['src/bitblt.c','src/pixels.c','src/font.c','src/adv_model.c','tests/adv60c_fullpixel_host.c',str(b/'old.o'),str(b/'adv.o'),'-o',str(b/'fullpixel.exe'),'-Wl,--image-base,0x180000000'],[str(b/'fullpixel.exe')]]
start=time.monotonic();runs=[]
for cmd in cmds:
 q=subprocess.run(cmd,cwd=r,capture_output=True,text=True,timeout=180);out=q.stdout+q.stderr;print(out,end='');runs.append(dict(command=cmd,exit=q.returncode,output=out))
 if q.returncode:break
passed=not runs[-1]['exit'] and 'ADV60C_FULLPIX_PASS' in runs[-1]['output'];names=['src/adv.c','src/adv_model.c','src/adv_model.h','tests/adv60c_fullpixel_host.c']
(r/'results/adv60c_fullpixel.json').write_text(json.dumps(dict(status='PASS' if passed else 'FAIL',hardware_accessed=False,scope='actualrenderer+productiondriver compared every warmup/measured viewport pixel to frozen Q8 primitive painter order; all alpha endpoints,Keyoff/multicolor gates,physics and raggedfallback',elapsed_seconds=round(time.monotonic()-start,3),runs=runs,sha256={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in names}),indent=2),encoding='utf8');raise SystemExit(0 if passed else 1)
