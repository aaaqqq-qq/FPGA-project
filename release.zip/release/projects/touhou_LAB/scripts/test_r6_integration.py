"""Exercise actual game.c/player/enemy/boss integration, not a reconstructed game."""
from pathlib import Path
import argparse,hashlib,json,os,re,shlex,subprocess
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=ap.parse_args()
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)];B=R/'build/r6_integration';B.mkdir(parents=True,exist_ok=True)
prefix=(R/'tests/phase_gameplay.c').read_text(encoding='utf-8-sig').split('static int failures;',1)[0]
prefix=prefix.replace('capture_hud&&y>=530&&y<=558&&','capture_hud&&')
for name,args in [('scene_hud_begin','void'),('scene_hud_end','void'),('scene_hud_invalidate','void'),('scene_hud_cache_enable','unsigned enabled')]:
 if ('void '+name+'(') not in prefix:prefix+='\nvoid '+name+'('+args+') {'+('(void)enabled;' if 'enabled' in args else '')+'}\n'
if not re.search(r'^unsigned[^;\n]*\bscene_sprite_count\b[^;\n]*;',prefix,re.M):prefix+='\nunsigned scene_sprite_count;\n'
host=B/'r6_game_host.c';host.write_text(prefix+'\n#include "r6_integration_body.h"\n',encoding='utf-8');exe=B/'r6_game_host.exe'
cmd=cc+['-std=gnu11','-O2','-UNDEBUG','-Wall','-Wextra','-Wno-unused-function','-Wno-unused-parameter','-Wno-misleading-indentation','-Isrc','-Itests/stub','-Itests',str(host),'src/stage.c','src/battle.c','src/player.c','src/enemies.c','src/layer_visuals.c','src/effects.c','src/game_config.c','src/font.c','src/replay.c','src/remote_input.c','-o',str(exe)]
p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=60);log=p.stdout+p.stderr;code=p.returncode
if not code:
 p=subprocess.run([str(exe)],cwd=R,capture_output=True,text=True,timeout=90);log+=p.stdout+p.stderr;code=p.returncode
print(log,end='');status='PASS' if not code and 'ALL_R6_INTEGRATION_PASS' in log else 'FAIL'
(R/'results/r6_integration.json').write_text(json.dumps({'status':status,'hardware_accessed':False,'command':cmd,'exit_code':code,'output':log,'source_sha256':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ('src/game.c','src/player.c','src/battle.c','src/enemies.c','src/layer_visuals.c','src/game_config.c')},'scope':'Production4/6boss +6/12ordinary game integration and replay on host; not board FPS.'},indent=2),encoding='utf-8')
raise SystemExit(0 if status=='PASS' else 1)
