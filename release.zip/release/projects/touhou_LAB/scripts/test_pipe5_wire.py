"""Run the actual native firmware main and capture its real C wire protocol."""
from pathlib import Path
import json,subprocess,argparse,re,hashlib
P=Path(__file__).resolve().parents[1];O=P/'build/pipe5';R=P/'results/pipe5';R.mkdir(exist_ok=True)
a=argparse.ArgumentParser();a.add_argument('--host-cc',default='E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe');a=a.parse_args()
seal=json.loads((O/'source_seal.json').read_text());assert seal=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((P/'src').glob('*')) if p.is_file()},'run scripts/test_pipe5.py first for this exact source identity'
text=(O/'candidate_host.c').read_text()
# All game/renderer/motion functions are unchanged. Only board terminal and
# bounded process exit replace the original no-output gameplay harness stubs.
text=text.replace('unsigned uart_writeAvailability(unsigned u) { (void)u; return 0; }','unsigned uart_writeAvailability(unsigned u) { (void)u; return 128; }')
text=text.replace('void uart_write(unsigned u, unsigned c) { (void)u; (void)c; }',r'''static char wire_line[1024];static unsigned wire_at;
void uart_write(unsigned u,unsigned c){(void)u;putchar(c);if(c=='\n'){wire_line[wire_at]=0;if(!strncmp(wire_line,"GLOAD_DONE ",11)){fflush(stdout);exit(0);}wire_at=0;}else if(c!='\r'){assert(wire_at+1<sizeof wire_line);wire_line[wire_at++]=(char)c;}}''')
text=text.replace('return 128; }','return 128; }')
text=text.replace('return host_uart_end-host_uart_at;','return bb_read(BB_DISPLAY_CTRL)?host_uart_end-host_uart_at:0;')
# native main calls the actual original infinite firmware_main; only receiving
# DONE on its real UART after final evidence terminates this bounded process.
text+=r'''
#include <windows.h>
#include <io.h>
#include <fcntl.h>
extern void backend_reset(unsigned,unsigned,unsigned);
int main(int argc,char **argv){_setmode(_fileno(stdout),_O_BINARY);unsigned side=argc>1?atoi(argv[1]):8,n=side==32?5000:20000,cap=argc>2?atoi(argv[2]):126,inject=argc>3?atoi(argv[3]):0;
 for(unsigned i=0;i<3;++i){uintptr_t a=(uintptr_t[]){0x1000000,0x7000000,0x5ff0000}[i];unsigned z=(unsigned[]){0x1200000,0x400000,0x90000}[i];assert(VirtualAlloc((void*)a,z,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE)==(void*)a);}
 backend_reset(cap,1,inject);host_uart_at=0;host_uart_end=sprintf((char*)host_uart,":hello\n:gload run %u 6 12 %u %u 60 123456789\n",314000+side,n,side);firmware_main();return 99;}
'''
h=O/'wire_main.c';h.write_text(text)
cmd=json.loads((O/'candidate_argv.json').read_text());cmd[0]=a.host_cc;cmd.remove('-shared');ix=cmd.index(str(O/'candidate_host.c'));cmd[ix]=str(h);exe=O/'wire_main.exe';cmd+=['-Wl,--image-base,0x180000000,--high-entropy-va,--dynamicbase','-o',str(exe)]
q=subprocess.run(cmd,cwd=P,capture_output=True,text=True);(O/'wire_compile.log').write_text(q.stdout+q.stderr);assert not q.returncode,q.stderr
summaries=[]
for hz in [1000000,100000000]:
 args=cmd[:]
 # Recompile this exact real main with matching raw CLINT + conversion rates.
 args=args[:-2]+['-DP5_NATIVE_HZ='+str(hz),'-DBSP_CLINT_HZ='+str(hz),'-o',str(exe)]
 q=subprocess.run(args,cwd=P,capture_output=True,text=True);(O/('wire_compile_'+str(hz)+'.log')).write_text(q.stdout+q.stderr);assert not q.returncode,q.stderr
 for side,cap,inject in [(8,126,0),(32,126,0),(8,30,0),(16,126,0),(8,126,14)]:
  q=subprocess.run([str(exe),str(side),str(cap),str(inject)],cwd=P,capture_output=True,text=True,timeout=120);f=R/f'wire_v3_{side}_{cap}_{hz}_fault{inject}.log';f.write_text(q.stdout+q.stderr)
  assert q.returncode==0,(side,cap,hz,q.returncode,q.stdout[-2000:],q.stderr)
  lines=[x for x in q.stdout.splitlines() if x];
  for md in [x for x in lines if x.startswith('MOTION_DIAG ')]:
   mf={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',md)};assert mf['read_last']>=4224 and mf['read_last']%16==0 and mf['write_last']%16==0 and mf['cycles_last']>=max(mf['read_last'],mf['write_last'])//16,md
  done=[x for x in lines if x.startswith('GLOAD_DONE ')];expect='CANCEL' if inject else 'PASS';assert len(done)==1 and 'status='+expect in done[0],(side,cap,hz,done,q.stdout[-4500:])
  names=[x.split(' ',1)[0] for x in lines];pipe=cap==126 and side in (8,32)
  if pipe:
   assert names.index('GLOAD_PIPE')<names.index('GLOAD_READY')
   i=names.index('GLOAD_DONE');assert names[i-3:i]==['MOTION_DIAG','GLOAD_PIPE','GLOAD_VIEW'],names[i-6:i+1]
  assert all(len(x.encode())<512 for x in lines if x.startswith(('GLOAD_','MOTION_')))
  stat=[x for x in lines if x.startswith('GLOAD_STAT ')][-1];detail=[x for x in lines if x.startswith('GLOAD_DETAIL ')][-1]
  ack=[x for x in lines if x.startswith('GLOAD_ACK ') and 'op=run' in x][0];assert 'pipe='+str(int(pipe)) in ack
  prime=[x for x in lines if x.startswith('GLOAD_PIPE ') and 'phase=prime' in x];final=[x for x in lines if x.startswith('GLOAD_PIPE ') and 'phase=final' in x]
  if inject:
   def fields(line):return {k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)}
   a1=fields(stat);a2=fields(final[0]);assert a1['frames']==a1['swaps']==a2['presented_delta']==a2['logic_committed_delta']
  summaries.append(dict(size=side,cap=cap,raw_hz=hz,injection=inject,log=str(f),stat=stat,detail=detail,prime=prime,final=final,done=done[0]))
(R/'native_main_wire.json').write_text(json.dumps(dict(status='PASS',source_sha256=seal,scope='Actual C firmware main/runtime/scene/driver and native DMA/video model; fake video clock is not physical FPS; DMA diagnostics use ceil16 approximate beat accounting per mock request, not measured RTL counts',targets=summaries),indent=2));print('PIPE5 NATIVE MAIN WIRE PASS 10 cases: both targets/raw1M+100MHz,cap30,size16 fallback,mid-M cancel; actual prime/READY/final evidence before DONE')
