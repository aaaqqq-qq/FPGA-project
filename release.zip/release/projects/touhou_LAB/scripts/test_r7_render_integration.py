#!/usr/bin/env python3
"""Actual game render -> production queue and gameplay invariance; no hardware."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,re,shlex,subprocess
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=ap.parse_args()
cc=[x.strip('"')for x in shlex.split(a.host_cc,posix=False)];b=R/'build/r7_render_integration';b.mkdir(parents=True,exist_ok=True)
prefix=(R/'tests/phase_gameplay.c').read_text(encoding='utf-8-sig').split('static int failures;',1)[0]
prefix=prefix.replace('#include "scene_layers_stubs.h"','')
start=prefix.index('unsigned scene_list_us,');end=prefix.index('static uint64_t host_ticks;')
hook=r'''
#include "render_queue.h"
unsigned scene_list_us,scene_batch_cycles,scene_jobs,scene_sprite_count,scene_hud_restored_rows,scene_hud_redraw_jobs;
unsigned scene_layer_commands,scene_layer_peak,scene_layer_clipped,scene_layer_reordered;
typedef struct{RqCommand c;char text[128];}Trace;
static Trace submitted[RQ_CAPACITY],emitted[RQ_CAPACITY];
static unsigned submitted_count,emitted_count,current_layer,layer_on,in_hud,batch_calls,batch_descriptors,layer_begins,flush_calls,hud_begins;
static int current_depth;static unsigned ranks[8];
static unsigned capture_hud;static char hud_capture[2048];
static void copy_trace(Trace *p,const RqCommand *c,const char *text){p->c=*c;p->text[0]=0;if(text){assert(strlen(text)<sizeof(p->text));strcpy(p->text,text);}}
static void sink(const RqCommand *c,const char *text,void *ctx){(void)ctx;assert(emitted_count<RQ_CAPACITY);copy_trace(&emitted[emitted_count++],c,text);if(c->kind==RQ_TILE)++scene_sprite_count;}
static void submit(RqCommand *c,const char *text){if(in_hud)return;c->layer=current_layer;c->depth=current_depth;c->left=32;c->top=16;c->right=1056;c->bottom=704;
 if(layer_on){assert(submitted_count<RQ_CAPACITY);copy_trace(&submitted[submitted_count++],c,text);assert(rq_push(c,text)==RQ_OK);}else sink(c,text,0);}
void scene_init(void){}
void scene_begin(uint32_t fb,unsigned hw){(void)fb;(void)hw;submitted_count=emitted_count=batch_calls=batch_descriptors=layer_begins=flush_calls=hud_begins=0;scene_sprite_count=0;in_hud=layer_on=0;rq_reset();}
void scene_tile(int x,int y,unsigned t,unsigned alpha){RqCommand c={0};c.kind=RQ_TILE;c.x=x;c.y=y;c.tile=t;c.alpha=alpha;submit(&c,0);}
void scene_rect(int x,int y,int w,int h,uint32_t color){RqCommand c={0};c.kind=RQ_RECT;c.x=x;c.y=y;c.w=w;c.h=h;c.color=color;submit(&c,0);}
void scene_text(int x,int y,const char *text,uint32_t color,unsigned scale){RqCommand c={0};c.kind=RQ_TEXT;c.x=x;c.y=y;c.color=color;c.scale=scale;submit(&c,text);}
void scene_layers_begin(unsigned enabled){assert(!rq_count());rq_reset();layer_on=!!enabled;current_layer=current_depth=0;++layer_begins;scene_layer_commands=scene_layer_peak=scene_layer_clipped=scene_layer_reordered=0;}
void scene_layer(unsigned layer,int depth){assert(layer<8);current_layer=layer;current_depth=depth;}
void scene_layers_flush(void){rq_flush(sink,0);layer_on=0;++flush_calls;scene_layer_commands=rq_total;scene_layer_peak=rq_peak;scene_layer_reordered=rq_reordered;}
int scene_layer_order(const unsigned order[8]){if(!rq_set_order(order))return 0;memcpy(ranks,order,sizeof(ranks));return 1;}
void scene_clip(int x,int y,int w,int h){(void)x;(void)y;(void)w;(void)h;}void scene_clip_reset(void){}
void scene_hud_begin(void){scene_layers_flush();assert(!rq_count());in_hud=1;++hud_begins;}void scene_hud_end(void){in_hud=0;}
void scene_hud_invalidate(void){}void scene_hud_cache_enable(unsigned e){(void)e;}
void scene_end(void){assert(!rq_count());}void scene_set_batch(unsigned e){(void)e;}
void scene_batch_shots(void){++batch_calls;batch_descriptors=stage.count;scene_sprite_count+=stage.count;}void scene_batch_snapshot_ready(void){}
unsigned scene_cancelled(void){return 0;}
'''
prefix=prefix[:start]+hook+prefix[end:]
host=b/'r7_game_host.c';host.write_text(prefix+'\n#include "r7_render_integration_body.h"\n',encoding='utf-8');exe=b/'r7_game_host.exe'
cmd=cc+['-std=gnu11','-O2','-UNDEBUG','-Wall','-Wextra','-Wno-unused-function','-Wno-unused-parameter','-Wno-misleading-indentation','-Isrc','-Itests/stub','-Itests',str(host),'src/render_queue.c','src/layer_visuals.c','src/stage.c','src/battle.c','src/player.c','src/enemies.c','src/effects.c','src/game_config.c','src/font.c','src/replay.c','src/remote_input.c','-o',str(exe)]
p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=60);log=p.stdout+p.stderr;code=p.returncode
if not code:p=subprocess.run([str(exe)],cwd=R,capture_output=True,text=True,timeout=90);log+=p.stdout+p.stderr;code=p.returncode
print(log,end='');status='PASS'if not code and 'R7_RENDER_INTEGRATION PASS' in log else 'FAIL'
(R/'results/r7_render_integration.json').write_text(json.dumps({'status':status,'generated_utc':datetime.now(timezone.utc).isoformat(),'command':cmd,'exit_code':code,'output':log,'scope':'Actual game.c render/runtime + production queue ordering, independent pair-order oracle. R8 checks permitted opacity changes and four policies x600tick physics invariance (gather/layers/visuals/opacity/renderbudget). Raster/MMIO stubbed; fullpixels, physicaltiming andFPSseparate.','hardware_accessed':False,'source_sha256':{n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in ['src/game.c','src/battle.c','src/enemies.c','src/render_queue.c','src/layer_visuals.c','src/effects.c','src/game_config.c','tests/r7_render_integration_body.h']}},indent=2),encoding='utf-8')
raise SystemExit(0 if status=='PASS' else 1)
