"""Actual UART -> GAME_LOAD lifecycle regression for the HUD rendering policy.

Links production game/config/battle/profile code; display and timer are host
fixtures. Does not claim physical rendering, board timing or FPS.
"""
from pathlib import Path
import argparse, hashlib, json, os, shlex, subprocess, sys

R = Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser()
ap.add_argument('--host-cc', default=os.environ.get('HOST_CC', 'gcc'))
a = ap.parse_args()
cc = [x.strip('"') for x in shlex.split(a.host_cc, posix=False)]
B = R / 'build/hud_dma_lifecycle'
B.mkdir(parents=True, exist_ok=True)
V = R / 'results/validation'
V.mkdir(parents=True, exist_ok=True)
H = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = {str(p.relative_to(R)): H(p) for p in (R / 'src').glob('*') if p.is_file()}
s = (R / 'tests/phase_gameplay.c').read_text('utf-8-sig').split('static int failures;', 1)[0]
s = s.replace('#include "game.c"', '#include "' + (R / 'src/game.c').as_posix() + '"')
s = s.replace('void scene_init(void) {}', 'static unsigned host_bg_calls,host_bg_policy;\nvoid scene_init(void){++host_bg_calls;host_bg_policy=hud_dma_tail_enabled;scene_bullets_reset();}')
s = s.replace('#include "lab_stubs.h"', '''
#define scene_bullets_prepare host_base_bullet_prepare
#include "lab_stubs.h"
#undef scene_bullets_prepare
static unsigned host_prepare_policy,host_prepare_calls;
int scene_bullets_prepare(unsigned n){++host_prepare_calls;host_prepare_policy=hud_dma_tail_enabled;return host_base_bullet_prepare(n);}
''')
s = s.replace('uint32_t bb_read(unsigned reg) { (void)reg; return 0; }',
              'static unsigned host_scan,host_swap,host_uf;\nuint32_t bb_read(unsigned reg){return reg==BB_FRAMES?host_scan:reg==BB_SWAPS?host_swap:reg==BB_UNDERFLOWS?host_uf:0;}')
s = s.replace('unsigned uart_writeAvailability(unsigned u) { (void)u; return 0; }',
              'unsigned uart_writeAvailability(unsigned u){(void)u;return 4096;}')
s = s.replace('void uart_write(unsigned u, unsigned c) { (void)u; (void)c; }', '''
static char wire[65536];static unsigned wire_at;
void uart_write(unsigned u,unsigned c){(void)u;assert(wire_at+1<sizeof wire);wire[wire_at++]=(char)c;wire[wire_at]=0;}
''')
for name, args in [('scene_hud_begin', 'void'), ('scene_hud_end', 'void'),
                   ('scene_hud_invalidate', 'void'), ('scene_hud_cache_enable', 'unsigned enabled')]:
    if 'void ' + name + '(' not in s:
        s += '\nvoid ' + name + '(' + args + '){}\n'
core = r'''
static unsigned checks,cases;
#define CK(x) do{++checks;if(!(x)){fprintf(stderr,"HUD_LIFECYCLE FAIL line=%u %s\n",__LINE__,#x);exit(1);}}while(0)
static GameConfig caller;
static uint32_t policy_hashes[2];
static void drain(void){unsigned budget=10000;while(command_reply_count||txpos<txlen){CK(budget--);pump();}}
static void cli(const char *s){while(*s)uart_character(*s++);drain();}
static void wipe(void){wire[0]=0;wire_at=0;}
static unsigned field(const char *prefix,const char *name){
 const char *p=strstr(wire,prefix);CK(p);const char *end=strchr(p,'\n');CK(end);
 char key[64];snprintf(key,sizeof key," %s=",name);p=strstr(p,key);CK(p&&p<end);p+=strlen(key);
 char *last;unsigned value=(unsigned)strtoul(p,&last,10);CK(last>p&&last<=end);return value;
}
static void setup(unsigned policy,unsigned profile){
 game_load_running=game_load_cancel=validate_requested=validation_active=0;battle_load_end();
 game_config_defaults();replay_reset();mode=MENU;choice=1;custom_limit=400;autoplay=0;demo_invincible=1;
 host_bullet_prepare_fail=host_bullet_guard_fail=0;host_ticks=host_scan=host_swap=host_uf=0;
 command_reply_head=command_reply_count=command_reply_overruns=txpos=txlen=0;
 command_len=command_overflow=deferred_ascii=0;remote_input_init(&remote);wipe();
 host_bg_calls=host_prepare_calls=0;frame_us=logic_us=render_us=0;
 game_cfg.main_fire_period=17;game_cfg.background_depth_enabled=0;caller=game_cfg;
 char cmd[96];snprintf(cmd,sizeof cmd,":set hud_dma_tail_enabled %u\n:set tick_profile %u\n:hello\n",policy,profile);cli(cmd);
 CK(hud_dma_tail_enabled==policy&&tick_profile_info().enabled==profile);
 CK(field("CAPS ","hud_dma")==policy&&field("CAPS ","hud_dma_proof")==1);wipe();
}
static void begin(unsigned policy,unsigned size,unsigned n){
 char cmd[128];snprintf(cmd,sizeof cmd,":gload run 99 6 12 %u %u 60 123456789\n",n,size);cli(cmd);
 CK(game_load_running&&mode==PLAY&&!gl.ready&&gl.hud_dma==policy&&gl.saved_hud_dma==policy);
 CK(hud_dma_tail_enabled==policy&&host_prepare_policy==policy&&host_bg_policy==policy&&host_bg_calls==1);
 CK(gl.b==6&&gl.m==12&&gl.n==n&&gl.size==size&&stage.count==n&&stage.limit==n);
 CK(!game_cfg.adaptive_density&&game_cfg.boss_count==6&&game_cfg.enemy_count==12);
 CK(gl.cfg==runtime_config_hash()&&field("GLOAD_ACK ","hud_dma")==policy);
 policy_hashes[policy]=gl.cfg;cli(":gload status 99\n");CK(field("GLOAD_ACK id=99 op=status ","hud_dma")==policy);wipe();
}
static void ready(unsigned policy){
 render_warmup_advance();render_warmup_advance();game_load_ready(bb_ticks());drain();
 CK(game_load_running&&gl.ready&&field("GLOAD_READY ","hud_dma")==policy);wipe();
}
static void frame(void){
 runtime_step();++host_swap;++host_scan;host_ticks=gl.start+(uint64_t)(gl.frames+1)*1000000/60;
 logic_us=1000;render_us=2000;frame_us=3000;
 game_load_after_swap(stage.count,visible_boss_count(),enemies_fighting_count());drain();
}
static void restored(unsigned policy,unsigned profile){
 CK(!game_load_running&&!game_load_cancel&&!battle_load_active&&mode==MENU);
 CK(hud_dma_tail_enabled==policy&&!memcmp(&game_cfg,&caller,sizeof caller));
 CK(custom_limit==400&&choice==1&&!autoplay&&demo_invincible==1);
 CK(host_bg_calls==2&&host_bg_policy==policy&&host_prepare_policy==policy);
 CK(tick_profile_info().enabled==profile&&!tick_profile_info().active);
 CK(!command_reply_overruns);++cases;
}
static void successful(unsigned policy,unsigned size,unsigned n){
 setup(policy,0);begin(policy,size,n);ready(policy);
 FILE *log=fopen(policy?"results/validation/hud_policy1_native_protocol.log":"results/validation/hud_policy0_native_protocol.log","ab");CK(log);
 for(unsigned i=0;i<60;++i)frame();
 CK(strstr(wire,"GLOAD_DONE id=99 status=PASS reason=complete"));
 CK(field("GLOAD_DETAIL ","hud_dma")==policy&&gl.nmin==n&&gl.nmax==n&&gl.bmin==6&&gl.mmin==12);
 fputs(wire,log);fclose(log);restored(policy,0);
}
static void lifecycle(unsigned policy,unsigned profile){
 /* Caller choices must survive an allocation/preparation failure. */
 setup(policy,profile);host_bullet_prepare_fail=1;cli(":gload run 99 6 12 20000 8 60 123456789\n");
 CK(strstr(wire,"reason=prepare")&&!game_load_running&&hud_dma_tail_enabled==policy);
 CK(!memcmp(&caller,&game_cfg,sizeof caller)&&host_bg_calls==2&&host_bg_policy==policy&&host_prepare_policy==policy);
 CK(tick_profile_info().enabled==profile);++cases;
 /* Invalid requests cannot mutate the caller policy or configuration. */
 setup(policy,profile);cli(":gload run 99 7 12 20000 8 60 123456789\n");
 CK(strstr(wire,"reason=range")&&!game_load_running&&hud_dma_tail_enabled==policy&&!memcmp(&caller,&game_cfg,sizeof caller));++cases;
 /* Cancel during warmup and after a real runtime tick. */
 for(unsigned warm=0;warm<2;++warm){setup(policy,profile);begin(policy,8,20000);if(!warm){ready(policy);frame();}
  cli(":gload cancel 99\n");game_load_poll_cancel();drain();CK(strstr(wire,"status=CANCEL reason=cancel"));restored(policy,profile);
 }
 /* Actual state failure, time limit and display guard failure share cleanup. */
 setup(policy,profile);begin(policy,32,5000);ready(policy);mode=STRESS;frame();
 CK(strstr(wire,"status=FAIL reason=state"));restored(policy,profile);
 setup(policy,profile);begin(policy,32,5000);ready(policy);host_ticks=gl.start+gl.deadline;host_scan=1200;host_swap=1;
 game_load_after_swap(5000,6,12);drain();CK(strstr(wire,"status=FAIL reason=timeout"));restored(policy,profile);
 setup(policy,profile);begin(policy,32,5000);ready(policy);host_bullet_guard_fail=1;game_load_finish("PASS","complete");drain();
 CK(strstr(wire,"status=FAIL reason=guards"));restored(policy,profile);
 /* An accidental policy change must never be reported as a passing run. */
 for(unsigned where=0;where<4;++where){setup(policy,profile);begin(policy,8,20000);if(where!=0)ready(policy);
  hud_dma_tail_enabled=policy^1u;
  if(where==0)game_load_ready(bb_ticks());else if(where==1)game_load_poll_cancel();
  else if(where==2)frame();else game_load_finish("PASS","complete");drain();
  CK(strstr(wire,"status=FAIL reason=hud_policy")&&!strstr(wire,"status=PASS"));
  CK(field("GLOAD_DETAIL ","hud_dma")== (policy^1u));restored(policy,profile);
 }
}
static void payload(void){
 setup(1,0);memset(&gl,255,sizeof gl);gl.hud_dma=gl.saved_hud_dma=1;logic_drops=logic_overruns=~0u;
 memset(&pipe_presented,255,sizeof pipe_presented);effects_drop_total=stage.fault=runtime_tick=~0u;
 game_load_stat();CK(command_reply_count==2);
 for(unsigned i=0;i<2;++i){const char *p=command_replies[(command_reply_head+i)%COMMAND_REPLY_CAP];size_t n=strlen(p);
  CK(n<COMMAND_REPLY_BYTES&&n>=2&&p[n-2]=='\r'&&p[n-1]=='\n');printf("HUD_LIFECYCLE maxpayload=%u\n",(unsigned)n);
 }
 CK(strstr(command_replies[(command_reply_head+1)%COMMAND_REPLY_CAP],"hud_dma=1\r\n"));drain();
}
int main(void){
 remove("results/validation/hud_policy0_native_protocol.log");remove("results/validation/hud_policy1_native_protocol.log");
 for(unsigned p=0;p<=1;++p){successful(p,8,20000);successful(p,32,5000);for(unsigned t=0;t<=1;++t)lifecycle(p,t);}
 CK(policy_hashes[0]!=policy_hashes[1]);payload();
 printf("HUD_LIFECYCLE PASS cases=%u checks=%u actual_uart_start_cleanup policies0and1 full_target_N; display_timer_stubs not_physical_FPS\n",cases,checks);return 0;
}
'''
host = B / 'host.c'
host.write_text(s + core, 'utf-8')
exe = B / 'test.exe'
cmd = cc + ['-std=gnu11', '-O2', '-UNDEBUG', '-DTICK_PROFILE_HOST_ENABLE', '-Wno-misleading-indentation',
    '-Isrc', '-Itests/stub', '-Itests', str(host), 'src/stage.c', 'src/battle.c', 'src/player.c',
    'src/enemies.c', 'src/layer_visuals.c', 'src/effects.c', 'src/game_config.c', 'src/font.c',
    'src/replay.c', 'src/remote_input.c', 'src/tick_profile.c', '-o', str(exe)]
p = subprocess.run(cmd, cwd=R, capture_output=True, text=True)
log = p.stdout + p.stderr
rc = p.returncode
if not rc:
    p = subprocess.run([str(exe)], cwd=R, capture_output=True, text=True, timeout=180)
    log += p.stdout + p.stderr
    rc = p.returncode
for rel, sha in sources.items():
    assert H(R / rel) == sha, 'Source changed while testing: ' + rel
(V / 'hud_dma_lifecycle.log').write_text(log, 'utf-8')
(R / 'results/hud_dma_lifecycle.json').write_text(json.dumps(dict(
    status='PASS' if not rc else 'FAIL', command=cmd, exit_code=rc, source_sha256=sources,
    source_inputs_unchanged=True, log='results/validation/hud_dma_lifecycle.log',
    log_sha256=H(V / 'hud_dma_lifecycle.log'), scope='actual UART/parser/game lifecycle; display/timer host fixtures',
    hardware_accessed=False, physical_FPS='NOT_RUN', output=log), indent=2) + '\n', 'utf-8')
print(log)
sys.exit(rc)
