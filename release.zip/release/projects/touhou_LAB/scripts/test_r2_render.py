#!/usr/bin/env python3
"""Run production renderer pixel and effect-policy host regressions."""
from pathlib import Path
import argparse,json,os,shlex,subprocess,sys
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=ap.parse_args()
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
tests={}
def run(name,cmd):
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=120)
 print(p.stdout,end='');print(p.stderr,end='',file=sys.stderr)
 tests[name]={'exit_code':p.returncode,'command':cmd,'stdout':p.stdout,'stderr':p.stderr}
 if p.returncode:raise RuntimeError(name+' failed')
try:
 run('hud_pixels',[sys.executable,'tests/r2_render/test_render.py','--host-cc',a.host_cc])
 exe=R/'build/r2_effects_budget.exe'
 run('effects_build',cc+['-O2','-UNDEBUG','-Wall','-Wextra','-Isrc','tests/r2_render/effects_budget.c','src/game_config.c','-o',str(exe)])
 run('effects_budget',[str(exe)])
 status='PASS'
except Exception as e:status='FAIL';tests['error']=str(e)
(R/'results/r2_render_tests.json').write_text(json.dumps({'status':status,'hardware_accessed':False,'tests':tests},indent=2),encoding='utf-8')
print('R2_RENDER='+status)
raise SystemExit(0 if status=='PASS' else 1)
