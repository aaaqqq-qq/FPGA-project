"""Compile real lab.c and independently verify complete framebuffer pixels."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shlex
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--host-cc', default=os.environ.get('HOST_CC', 'gcc'))
a = p.parse_args()
root = Path(__file__).resolve().parents[1]
build = root / 'build' / 'lab_test'
build.mkdir(parents=True, exist_ok=True)
cc = [part.strip('"') for part in shlex.split(a.host_cc, posix=False)]
exe = build / ('lab_test.exe' if os.name == 'nt' else 'lab_test')
command = cc + ['-std=c99', '-O2', '-Wall', '-Wextra', '-Werror', '-DBB_HOST_TEST',
                '-Isrc', 'src/lab.c', 'src/pixels.c', 'tests/lab_host.c', '-o', str(exe)]
if os.name == 'nt':
    # Keep the PE image/static reference buffer away from modeled low DDR.
    command.insert(-2, '-Wl,--image-base,0x180000000')
start = time.time()
subprocess.run(command, cwd=root, check=True)
result = subprocess.run([str(exe)], cwd=root, text=True, capture_output=True)
print(result.stdout, end='')
if result.stderr:
    print(result.stderr, end='')
report = {
    'passed': result.returncode == 0,
    'scope': 'real lab.c; independent whole framebuffer pixel reference; host DMA memory model',
    'hardware': 'NOT_RUN: UART/cache/HDMI/physical timing/refresh measurement',
    'elapsed_seconds': round(time.time() - start, 3),
    'source_sha256': hashlib.sha256((root / 'src/lab.c').read_bytes()).hexdigest(),
    'checks': ['opaque flags=0', '1280-wide split', 'fill/copy/readback',
               'all three exact output patterns', 'two precise source materials',
               'zero/overflow/bounds/length/token rejection without memory mutation',
               'one request in flight', 'queue ACK before execution', 'nine verify cases',
               'pixel/guard/engine fault injection', 'restore success/failure ownership'],
    'stdout': result.stdout,
    'stderr': result.stderr,
}
(root / 'results').mkdir(exist_ok=True)
(root / 'results/lab_host.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
raise SystemExit(result.returncode)
