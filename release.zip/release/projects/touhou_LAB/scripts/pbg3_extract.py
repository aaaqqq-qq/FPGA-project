import glob, os, sys, struct

class BitReader:
    def __init__(self, data, pos=0):
        self.data = data; self.pos = pos; self.byte = 0; self.bits = 0
    def read(self, nbits):
        if nbits > 25:
            r = self.read(24); nbits -= 24
            return ((r << nbits) | self.read(nbits)) & 0xFFFFFFFF
        while nbits > self.bits:
            c = self.data[self.pos]; self.pos += 1
            self.byte = ((self.byte << 8) | c) & 0xFFFFFFFF
            self.bits += 8
        self.bits -= nbits
        return (self.byte >> self.bits) & ((1 << nbits) - 1)

def read_u32(br):
    size = br.read(2)
    return br.read((size + 1) * 8)

def read_string(br, maxlen):
    out = bytearray()
    for _ in range(maxlen):
        c = br.read(8)
        if c == 0:
            break
        out.append(c)
    return bytes(out)

LZSS_DICTSIZE = 0x2000
LZSS_MASK = 0x1fff
LZSS_MIN_MATCH = 3

def unlzss(data, out_size):
    br = BitReader(data)
    dict_ = bytearray(LZSS_DICTSIZE)
    dict_head = 1
    out = bytearray()
    while len(out) < out_size:
        if br.read(1):
            c = br.read(8)
            out.append(c)
            dict_[dict_head] = c
            dict_head = (dict_head + 1) & LZSS_MASK
        else:
            match_offset = br.read(13)
            if match_offset == 0:
                break
            match_len = br.read(4) + LZSS_MIN_MATCH
            for i in range(match_len):
                c = dict_[(match_offset + i) & LZSS_MASK]
                out.append(c)
                dict_[dict_head] = c
                dict_head = (dict_head + 1) & LZSS_MASK
    return bytes(out)

def parse(path):
    d = open(path, 'rb').read()
    br = BitReader(d); br.pos = 4
    entry_count = read_u32(br)
    table_off = read_u32(br)
    hdr_end = br.pos
    br2 = BitReader(d); br2.pos = table_off
    entries = []
    for i in range(entry_count):
        u1 = read_u32(br2); u2 = read_u32(br2); extra = read_u32(br2)
        off = read_u32(br2); size = read_u32(br2)
        name = read_string(br2, 255)
        entries.append(dict(u1=u1, u2=u2, extra=extra, off=off, size=size, name=name))
    return dict(data=d, count=entry_count, table_off=table_off, hdr_end=hdr_end,
                table_end=br2.pos, entries=entries)

