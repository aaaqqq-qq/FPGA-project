"""Select a paired HDMI PLL/SDC profile; rebuild hardware after use. No programming."""
from pathlib import Path
import argparse,re,json
r=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('hz',type=int,choices=(60,90));a=p.parse_args()
f=r/'hw/game/par/ddr_demo_ti60/ddr_demo_ti60.peri.xml';s=f.read_text()
begin=s.index('<efxpt:pll name="pll_hdmi"');end=s.index('</efxpt:pll>',begin)+len('</efxpt:pll>')
b=s[begin:end]
b=re.sub(r'pre_divider="\d+"',f'pre_divider="{1 if a.hz==60 else 2}"',b)
b=re.sub(r'post_divider="\d+"',f'post_divider="{2 if a.hz==60 else 1}"',b)
b=re.sub(r'(name="FB"[^>]*out_divider=")\d+',lambda m:m[1]+str(55 if a.hz==60 else 165),b)
f.write_text(s[:begin]+b+s[end:])
f=r/'hw/game/par/ddr_demo_ti60/sdc/game.sdc';s=f.read_text()
pixel=1000/(74.25*a.hz/60);fast=pixel/5;shift=fast*3/8
s=re.sub(r'create_clock -period [0-9.]+ -name hdmi_tx_slow_clk',f'create_clock -period {pixel:.6f} -name hdmi_tx_slow_clk',s)
s=re.sub(r'create_clock -waveform \{[^}]+\} -period [0-9.]+ -name hdmi_tx_fast_clk',f'create_clock -waveform {{{shift:.6f} {shift+fast/2:.6f}}} -period {fast:.6f} -name hdmi_tx_fast_clk',s)
lines=[]
for line in s.splitlines():
 if line.startswith('set_max_delay') and 'tag' in line and 'latched' in line:line=re.sub(r'[0-9.]+$', '20.000' if a.hz==60 else '15.000',line)
 if line.startswith(('set_max_delay','set_bus_skew')) and 'underflow_' in line:line=re.sub(r'[0-9.]+$', '10.000' if a.hz==60 else '7.000',line)
 lines.append(line)
f.write_text('\n'.join(lines)+'\n')
(r/'src/display_profile.h').write_text('#pragma once\n#define DISPLAY_HZ '+str(a.hz)+'\n')
(r/'results/display_profile.json').write_text(json.dumps({'hz':a.hz,'pixel_mhz':74.25*a.hz/60,'serial_clock_mhz':371.25*a.hz/60,'total':[1650,750],'flash_written':False},indent=2))
print('Configured',a.hz,'Hz; rebuild and check timing before JTAG loading.')
