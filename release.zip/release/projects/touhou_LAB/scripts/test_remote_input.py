#!/usr/bin/env python3
"""LAB1 binary framing and actual production game input integration; no hardware."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=ap.parse_args()
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
B=R/'build/remote_input';B.mkdir(parents=True,exist_ok=True)
prefix=(R/'tests/phase_gameplay.c').read_text(encoding='utf-8-sig').split('static int failures;',1)[0]
prefix=prefix.replace('void scene_init(void) {}','static unsigned host_scene_inits,host_bank_mask,host_pause_text,host_order[64],host_order_n;static uint32_t host_front=BB_FB0;\nvoid scene_init(void) {++host_scene_inits;}')
prefix=prefix.replace('void scene_begin(uint32_t fb, unsigned hw) { (void)fb; (void)hw; }','void scene_begin(uint32_t fb, unsigned hw) {host_bank_mask|=fb==BB_FB1?2:1;if(host_order_n<64)host_order[host_order_n++]=fb==BB_FB1?2:1;(void)hw;}')
prefix=prefix.replace('uint32_t bb_read(unsigned reg) { (void)reg; return 0; }','uint32_t bb_read(unsigned reg) {return reg==BB_FRONT?host_front:0;}')
prefix=prefix.replace('bb_result bb_swap_wait(uint32_t fb, uint32_t t) { (void)fb; (void)t; return BB_OK; }','bb_result bb_swap_wait(uint32_t fb, uint32_t t) {host_front=fb;if(host_order_n<64)host_order[host_order_n++]=fb==BB_FB1?4:3;(void)t;return BB_OK;}')
prefix=prefix.replace('(void)x; (void)c; (void)s;','(void)x; (void)c; (void)s;if(strstr(t,"PAUSED"))++host_pause_text;')
for name,args in [('scene_hud_begin','void'),('scene_hud_end','void'),('scene_hud_invalidate','void'),('scene_hud_cache_enable','unsigned enabled')]:
 if ('void '+name+'(') not in prefix:prefix+='\nvoid '+name+'('+args+') {'+('(void)enabled;' if 'enabled' in args else '')+'}\n'
host=B/'pc_controls.c';host.write_text(prefix+'\n#include "pc_controls_body.h"\n',encoding='utf-8')
flags=['-std=gnu11','-O2','-UNDEBUG','-Wall','-Wextra','-Wno-unused-function','-Wno-unused-parameter','-Wno-misleading-indentation','-Isrc','-Itests/stub','-Itests']
cases=[('protocol',['tests/remote_input_host.c','src/remote_input.c'],'ALL_REMOTE_INPUT_PASS'),('game',[str(host),'src/remote_input.c','src/stage.c','src/battle.c','src/player.c','src/enemies.c','src/layer_visuals.c','src/effects.c','src/game_config.c','src/font.c','src/replay.c'],'ALL_PC_CONTROLS_PASS')]
results=[]
for name,sources,marker in cases:
 exe=B/(name+'.exe');cmd=cc+flags+sources+['-o',str(exe)]
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=90);log=p.stdout+p.stderr;code=p.returncode
 if not code:
  p=subprocess.run([str(exe)],cwd=R,capture_output=True,text=True,timeout=90);log+=p.stdout+p.stderr;code=p.returncode
 print(log,end='');results.append({'case':name,'status':'PASS' if not code and marker in log else 'FAIL','exit_code':code,'command':cmd,'output':log})
status='PASS' if all(x['status']=='PASS' for x in results) else 'FAIL'
(R/'results/remote_input.json').write_text(json.dumps({'status':status,'hardware_accessed':False,'tests':results,'source_sha256':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['src/remote_input.c','src/remote_input.h','src/game.c']}},indent=2),encoding='utf-8')
print('REMOTE_INPUT='+status);raise SystemExit(0 if status=='PASS' else 1)
