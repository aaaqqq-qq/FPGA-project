from pathlib import Path
import argparse,time,serial
p=argparse.ArgumentParser();p.add_argument('--port',default='COM6');p.add_argument('--seconds',type=int,default=3600);a=p.parse_args()
r=Path(__file__).resolve().parents[1]/'results';commands=r/'serial_commands.txt';stop=r/'stop_monitor'
stop.unlink(missing_ok=True);commands.touch();sent=commands.stat().st_size
with serial.Serial(a.port,115200,timeout=.1) as uart,(r/'validation/touhou_uart.log').open('a',encoding='utf-8') as f:
 print('UART ready',flush=True);deadline=time.monotonic()+a.seconds
 while time.monotonic()<deadline and not stop.exists():
  data=uart.read(uart.in_waiting or 1)
  if data:f.write(data.decode('ascii',errors='replace'));f.flush()
  pending=commands.read_bytes()
  if len(pending)>sent:
   payload=pending[sent:];sent=len(pending);uart.write(payload);uart.flush();f.write(f'\n[HOST UART COMMAND {payload!r}]\n');f.flush()
