#!/usr/bin/env python3
"""Receive and strictly analyse a bounded profile on already-loaded firmware.

No compilation/JTAG/Flash. --execute is required for serial access.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,subprocess,sys,time
from analyze_stability import policy_description,policy_digest

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--count',type=int,default=8192)
    p.add_argument('--seconds',type=int,default=600)
    p.add_argument('--warmup',type=int,default=10)
    p.add_argument('--port',default='COM16')
    p.add_argument('--execute',action='store_true')
    a=p.parse_args()
    if not 1<=a.count<=20000 or not 10<=a.seconds<=3600 or not 0<=a.warmup<=60:p.error('invalid count/duration')
    root=Path(__file__).resolve().parents[1]
    identity=json.loads((root/'build/identity.json').read_text())
    for group in ('sources','scripts'):
        for name,digest in identity[group].items():
            assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,('changed build input',name)
    assert hashlib.sha256((root/'build/rumia.elf').read_bytes()).hexdigest()==identity['elf_sha256']
    if not a.execute:
        print('CHECK ONLY: source identity PASS; no serial access. Use --execute for the already-loaded board.')
        return 0
    out=root/'review_board_tools/long_runs'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S_')
    out=out.with_name(out.name+str(a.count));out.mkdir(parents=True)
    meta={'status':'IN_PROGRESS','count':a.count,'minimum_seconds':a.seconds,'warmup_seconds':a.warmup,
          'elf_sha256':identity['elf_sha256'],'flash_written':False,'source_script':str(Path(__file__))}
    policy=policy_description(2,a.count,a.seconds,60,1,True)
    analyzer_sha=hashlib.sha256((root/'scripts/analyze_stability.py').read_bytes()).hexdigest()
    meta.update(policy_registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                policy_sha256=policy_digest(policy),analyzer_sha256=analyzer_sha)
    (out/'policy_before_run.json').write_text(json.dumps({'policy':policy,'policy_sha256':meta['policy_sha256'],'registered_utc':meta['policy_registered_utc'],'analyzer_sha256':analyzer_sha},indent=2),encoding='utf-8')
    def save():(out/'long_session.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    save();print('LONG_SESSION '+str(out),flush=True)
    env=os.environ.copy();env.update(PYTHONHOME='D:/ELSFPGA/python311',PYTHONPATH='D:/ELSFPGA/pgm/bin;D:/ELSFPGA/debugger/bin',PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
    receiver=subprocess.Popen(['D:/ELSFPGA/python311/bin/python.exe','-B','-X','utf8',str(root/'review_board_tools/capture_uart.py'),str(out),a.port,str(a.seconds+a.warmup+80)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
    failure=None
    try:
        for _ in range(100):
            if (out/'uart_ready').exists():break
            if receiver.poll() is not None:raise RuntimeError('serial receiver ended during open')
            time.sleep(.1)
        else:raise RuntimeError('serial ready timeout')
        (out/'uart_commands.bin').write_bytes(('mn'+str(a.count)+'\ns\n').encode('ascii'))
        meta['command_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
        time.sleep(a.warmup)
        meta['measurement_start_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
        print('WARMUP_COMPLETE',flush=True)
        deadline=time.monotonic()+a.seconds+50;previous_count=0
        while time.monotonic()<deadline:
            if receiver.poll() is not None:raise RuntimeError('serial receiver ended before native duration')
            rows=[json.loads(x) for x in (out/'uart_lines.jsonl').read_text().splitlines()]
            stats=[{k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',x['line'])} for x in rows if x.get('utc','')>=meta['measurement_start_utc'] and x.get('line','').startswith('STAT ')]
            measured=sum(x.get('us',0) for x in stats[1:])
            if len(stats)!=previous_count:
                previous_count=len(stats)
                if len(stats)%30==0:print('PROGRESS windows=%d native_seconds=%.3f'%(len(stats),measured/1e6),flush=True)
            if measured>=a.seconds*1000000:break
            time.sleep(.15)
        else:raise RuntimeError('native duration timeout')
    except BaseException as error:failure=repr(error)
    finally:
        (out/'stop_uart').write_text('stop')
        try:receiver.wait(timeout=5)
        except subprocess.TimeoutExpired:receiver.terminate();receiver.wait(timeout=5)
    clean=os.environ.copy();clean.pop('PYTHONHOME',None);clean.pop('PYTHONPATH',None);clean['PYTHONUTF8']='1'
    if not failure:
        assert hashlib.sha256((root/'scripts/analyze_stability.py').read_bytes()).hexdigest()==analyzer_sha,'analysis source changed during measurement'
        cmd=[sys.executable,'-B','-X','utf8',str(root/'scripts/analyze_stability.py'),'--log',str(out/'uart_lines.jsonl'),'--mode2','--count',str(a.count),'--seconds',str(a.seconds),'--hz','60','--start-utc',meta['measurement_start_utc'],'--output',str(out/'stability_600s.json'),'--require-zero-fxdrop']
        result=subprocess.run(cmd,env=clean,cwd=root,capture_output=True,text=True)
        (out/'analysis.log').write_text(result.stdout+result.stderr,encoding='utf-8')
        print(result.stdout,flush=True);meta['status']='PASS' if result.returncode==0 else 'FAIL';meta['analysis_exit_code']=result.returncode
    else:meta.update(status='FAIL',error=failure)
    meta['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
    print('LONG_COMPLETE '+meta['status'],flush=True)
    return 0 if meta['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
