#!/usr/bin/env python3
"""Stage/ECL differential regression and full-pool boundary checks.

The raw floating ECL parser remains the reference for the original Rumia
stage script. The firmware structure is read with its current parallel owner
metadata. This is host-only; board timing is separate.
"""
from __future__ import annotations

import argparse
import ctypes as C
import json
import math
import os
import re
import shlex
import struct
import subprocess
from pathlib import Path

R = Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser()
ap.add_argument("--host-cc", default=os.environ.get("HOST_CC", "gcc"))
ap.add_argument("--out", default="build")
a = ap.parse_args()
cc = [x.strip('"') for x in shlex.split(a.host_cc, posix=False)]
out = R / a.out
out.mkdir(exist_ok=True)
CAP = int(re.search(r'SHOT_CAPACITY (\d+)', (R / 'src/stage.h').read_text())[1])
libpath = out / ("stage_host.dll" if os.name == "nt" else "stage_host.so")
subprocess.run(cc + ["-shared", "-O2", "-UNDEBUG", "-Isrc", "-Itests/stub",
                     "src/stage.c", "src/battle.c", "src/player.c", "src/enemies.c","src/layer_visuals.c", "src/effects.c",
                     "src/game_config.c", "tests/host_scene_stubs.c",
                     "-o", str(libpath)], cwd=R, check=True)


class Shot(C.Structure):
    _fields_ = [('x', C.c_int32), ('y', C.c_int32), ('vx', C.c_int16),
                ('vy', C.c_int16), ('age', C.c_uint16), ('tile', C.c_uint8),
                ('grazed', C.c_uint8)]


class Stage(C.Structure):
    _fields_ = ([('shots', Shot * CAP)] +
                [(n, C.c_uint) for n in 'count limit requested emitted rejected peak frame pc time'.split()] +
                [('vars', C.c_int32 * 12)] +
                [(n, C.c_int32) for n in 'bx by move_x move_y move_dx move_dy'.split()] +
                [(n, C.c_uint) for n in 'move_time move_total seed difficulty vulnerable'.split()] +
                [(n, C.c_int) for n in 'angle speed fault'.split()] +
                [('owner', C.c_uint8 * CAP)])


lib = C.CDLL(str(libpath))
st = Stage.in_dll(lib, 'stage')
data = (R / 'assets/source/th06e_ST.DAT__ecldata1.ecl').read_bytes()
start, end = struct.unpack_from('<II', data, 16 + 22 * 4)
code = {}
off = start
while off < end:
    t, op, size, rank, _ = struct.unpack_from('<i4H', data, off)
    if t == -1:
        break
    code[off] = (t, op, rank >> 8, data[off + 12:off + size], off + size)
    off += size
results = []
for difficulty, rank in enumerate([2, 4, 8]):
    lib.stage_reset(difficulty, 4096)
    pc = start
    time = 0
    vars = {}
    events = []
    total = 0
    bounds = [1024, 0, 688, 0]
    for frame in range(12000):
        fired = 0
        guard = 0
        velocities = []
        while pc in code and code[pc][0] == time:
            guard += 1
            assert guard < 256
            t, op, mask, p, nxt = code[pc]
            old = pc
            pc = nxt
            if not mask & rank:
                continue
            if op == 4:
                i, v = struct.unpack('<ii', p)
                vars[i] = v
            elif op == 5:
                i, v = struct.unpack('<if', p)
                vars[i] = v
            elif op == 20:
                i, x, y = struct.unpack('<iff', p)
                vars[i] = vars.get(x, x) + vars.get(y, y)
            elif op == 2:
                time, rel = struct.unpack('<ii', p)
                pc = old + rel
            elif op == 3:
                tm, rel, i = struct.unpack('<iii', p)
                vars[i] -= 1
                if vars[i] > 0:
                    time = tm
                    pc = old + rel
            elif op == 67:
                args = struct.unpack('<hh iiff ffi'.replace(' ', ''), p)
                fired += args[2] * args[3]
                angle = math.atan2(620 * 4096 - st.by, 512 * 4096 - st.bx) + vars.get(args[6], args[6])
                sp1 = vars.get(args[4], args[4])
                sp2 = vars.get(args[5], args[5])
                for j in range(args[3]):
                    speed = (sp1 - (sp1 - sp2) * j / args[3]) * 43 / 28
                    velocities.append((math.cos(angle) * speed, math.sin(angle) * speed))
        bounds = [min(bounds[0], st.bx / 4096), max(bounds[1], st.bx / 4096),
                  min(bounds[2], st.by / 4096), max(bounds[3], st.by / 4096)]
        before = st.emitted
        lib.stage_step(512, 620)
        assert st.fault == 0, (difficulty, frame, st.fault)
        assert st.emitted - before == fired, (difficulty, frame, st.emitted - before, fired)
        launched = [b for b in st.shots[:st.count] if b.age == 1]
        assert len(launched) == len(velocities)
        for b in launched:
            best = min(range(len(velocities)), key=lambda i: abs(b.vx / 4096 - velocities[i][0]) + abs(b.vy / 4096 - velocities[i][1]))
            vx, vy = velocities.pop(best)
            assert abs(b.vx / 4096 - vx) < 0.065 and abs(b.vy / 4096 - vy) < 0.065, (frame, b.vx, b.vy, vx, vy)
        assert st.count <= 4096 and st.rejected == 0
        assert 16 * 4096 <= st.bx <= 1008 * 4096 and 24 * 4096 <= st.by <= 664 * 4096
        if fired:
            events.append([frame, fired])
        total += fired
        time += 1
    assert bounds[0] < 100 and bounds[1] > 900 and bounds[3] > 448, bounds
    results.append({'difficulty': difficulty, 'frames': 12000, 'fired': total,
                    'peak': st.peak, 'first_events': events[:8], 'boss_extent_xy': bounds})

lib.stage_reset(0, 4096)
st.count = 1
st.shots[0] = Shot(900 * 4096, 600 * 4096, 100, 100, 30, 13, 0)
lib.stage_step(512, 620)
assert st.count == 1 and st.shots[0].x > 900 * 4096
st.shots[0].x = 1041 * 4096
lib.stage_step(512, 620)
assert st.count == 0
lib.stage_stress(CAP)
for _ in range(10000):
    lib.stage_stress_step()
assert st.count == CAP and st.rejected == 0
assert all(8 * 4096 <= b.x <= 1016 * 4096 and 8 * 4096 <= b.y <= 680 * 4096 for b in st.shots)
lib.stage_reset(2, 16)
for _ in range(12000):
    lib.stage_step(512, 620)
    assert st.count <= 16 and not st.fault
assert st.rejected > 0
report = {'passed': True, 'raw_ecl_vs_c': results, 'stress_frames': 10000,
          'stress_count': CAP, 'limit_test_rejected': st.rejected}
(R / 'results/stage_tests.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
