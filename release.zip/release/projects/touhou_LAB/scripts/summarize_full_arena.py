from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parents[1]
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
elf=H(R/'build/rumia.elf');bit=H(R/'hw/game/par/ddr_demo_ti60/outflow/ddr_demo_ti60.bit')
names=['fullarena_4096_endurance.json','fullarena_dodge4096.json','fullarena_cpu4096.json','game_v2.json']
d={n:json.loads((R/'results'/n).read_text())for n in names}
assert all(x['elf_sha256']==elf for x in d.values())
assert all(x.get('bit_sha256',bit)==bit for x in d.values())
for n in names:
 if 'cpu4096'not in n:assert all(x['passed_60fps']for x in d[n]['runs']),n
s=d[names[0]]['runs'][0];g=d[names[1]]['runs'][0];c=d[names[2]]['runs'][0]['windows'][1:]
assert len(c)>=3 and all(x['uf']==0 and x['N']==4096 and x['hw']==0 for x in c)
pixels=json.loads((R/'results/fullarena_board_pixels.json').read_text());assert pixels['passed']and pixels['elf_sha256']==elf
report={'passed':True,'elf_sha256':elf,'bit_sha256':bit,'flash_written':False,'resolution':[1280,720],'sprite_count':4096,'sprite_size':[8,8],'alpha':224,'color_key':'FF00FF',
 'stress':{'seconds_requested':s['seconds_requested'],'full_windows':s['full_windows'],'measured_us':s['measured_us'],'max_frame_us':s['max_render_us'],'missed':sum(x['missed']for x in s['windows'][1:]),'underflows':sum(x['uf']for x in s['windows'][1:])},
 'interactive_dodge':{'full_windows':g['full_windows'],'measured_us':g['measured_us'],'autoplay_during_endurance':True,'initial_transition_excluded':True,'max_sampled_frame_us':max(x['render']for x in g['windows'][1:]),'missed':sum(x['missed']for x in g['windows'][1:]),'underflows':sum(x['uf']for x in g['windows'][1:])},
 'cpu_fps_min':min(x['fps100']for x in c)/100,'cpu_fps_max':max(x['fps100']for x in c)/100,
 'original_difficulties':{x['difficulty']:x['passed_60fps']for x in d['game_v2.json']['runs']},'arena':[1024,688],'player_center_bounds':[16,1008,24,664],'boss_center_bounds':[16,1008,24,664],'panel_origin':[377,269],'visual_confirmation':'Full-arena movement and centered UI awaiting user inspection.'}
(R/'results/fullarena_summary.json').write_text(json.dumps(report,indent=2))
manifest=json.loads((R/'results/baseline_source_hashes.json').read_text());original=Path('D:/FPGA/hdmi_rumia')
assert all(H(original/n)==h for n,h in manifest.items())
(R/'results/original_preserved.json').write_text(json.dumps({'files_checked':len(manifest),'unchanged':True,'flash_written':False},indent=2))
archive=R/'reference/fullarena_4096_checkpoint.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for directory in ['src','scripts','hw/game/rtl']:
  for p in (R/directory).rglob('*'):
   if p.is_file() and '__pycache__'not in p.parts:z.write(p,str(p.relative_to(R)))
 for p in (R/'sim').glob('*'):
  if p.is_file():z.write(p,str(p.relative_to(R)))
 for p in (R/'results').glob('*.json'):z.write(p,str(p.relative_to(R)))
 for p in R.glob('*.txt'):z.write(p,p.name)
 for name in ['build/rumia.elf','build/identity.json','hw/game/par/ddr_demo_ti60/outflow/ddr_demo_ti60.bit','hw/game/par/ddr_demo_ti60/ddr_demo_ti60.xml','hw/game/par/ddr_demo_ti60/ddr_demo_ti60.sdc']:
  p=R/name
  if p.exists():z.write(p,name)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
(R/'results/optimization_status.txt').write_text('COMPLETE: measured 4096 moving 8x8 sprites at720p60, zero missed/underflow; CPU comparison, interactive endurance, all three original difficulties pass. Final sources/build/evidence in D:/FPGA/hdmi_rumia_720p. Original and Flash unchanged. See fullarena_summary.json. Board left at manual full-arena Normal menu; SW3 starts. Full-arena UI visual response pending.\n')
print(json.dumps(report,indent=2));print('Checkpoint verified',archive)
