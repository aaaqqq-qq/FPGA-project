#!/usr/bin/env python3
"""Validate bounded UART replay-word exports and create portable JSON/word input.

Does not open a COM port or operate hardware. Feed a fresh raw UART text log
containing REPLAY_WORD <index> <unsigned value> from the firmware's dump command.
"""
import argparse,json,re,struct,zlib
from pathlib import Path
MAGIC=0x52504c32
FIELDS=('magic','version','seed','config_hash','event_count','final_tick','final_state_hash','crc32')

def decode_words(words):
    if len(words)<8:raise ValueError('missing replay header')
    h=dict(zip(FIELDS,words[:8]))
    if h['magic']!=MAGIC or h['version']!=2 or not 1<=h['event_count']<=4096 or not h['final_tick']:
        raise ValueError('invalid replay header')
    if len(words)!=8+2*h['event_count']:raise ValueError('missing/trailing replay words')
    events=[];previous=-1
    for t,k in zip(words[8::2],words[9::2]):
        if k>>16 or k&255>15 or t<=previous or t>=h['final_tick']:raise ValueError('invalid event ordering/key/reserved bits')
        events.append({'tick':t,'keys':k&255,'bombs':(k>>8)&255});previous=t
    if events[0]['tick']!=0:raise ValueError('first input must be tick zero')
    payload=struct.pack('<7I',*words[:7])+struct.pack('<%dI'%len(words[8:]),*words[8:])
    if zlib.crc32(payload)!=h['crc32']:raise ValueError('replay CRC mismatch')
    return {'schema':'ti60-replay-v2','header':h,'events':events,'words':words}

def parse_log(text):
    found={}
    for i,v in re.findall(r'REPLAY_WORD\s+(\d+)\s+(\d+)',text):
        i=int(i);v=int(v)
        if not 0<=v<=0xffffffff:raise ValueError('word out of range')
        if i in found and found[i]!=v:raise ValueError('conflicting duplicated replay word')
        found[i]=v
    if sorted(found)!=list(range(len(found))):raise ValueError('missing replay word index')
    return decode_words([found[i] for i in range(len(found))])

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('input',type=Path);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--words-output',type=Path);a=ap.parse_args()
    text=a.input.read_text(encoding='utf-8',errors='replace')
    obj=decode_words(json.loads(text)['words']) if a.input.suffix.lower()=='.json' else parse_log(text)
    a.output.write_text(json.dumps(obj,indent=2),encoding='utf-8')
    if a.words_output:a.words_output.write_text('\n'.join(str(w) for w in obj['words'])+'\n',encoding='ascii')
    print('REPLAY_EXPORT PASS events=%u ticks=%u seed=%u CRC=%08x'%(obj['header']['event_count'],obj['header']['final_tick'],obj['header']['seed'],obj['header']['crc32']))

if __name__=='__main__':main()
