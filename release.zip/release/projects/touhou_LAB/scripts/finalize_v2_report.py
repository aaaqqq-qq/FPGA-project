from pathlib import Path
import datetime,json,hashlib,shutil
r=Path(__file__).resolve().parents[1];res=r/'results'
def load(n):return json.loads((res/n).read_text())
e=load('endurance_v2_928.json');c=load('cpu_v2_928.json');d=load('dodge_full_v2_864.json');g=load('game_v2.json')
assert e['runs'][0]['passed_60fps'] and d['runs'][0]['passed_60fps']
assert all(x['passed_60fps'] for x in g['runs'])
identity=json.loads((r/'build/identity.json').read_text());digest=identity['elf_sha256']
for data in [e,c,d,g]:assert data['elf_sha256']==digest
assert load('load_v2_release/readback_report.json')['verified']
assert load('scene_pixels_v2.json')['passed'] and load('dodge_logic_v2.json')['passed']
def metrics(data):
 x=data['runs'][0];w=x['windows'][1:]
 return {'count':x['count'],'fps':sum(t['swaps'] for t in w)*1e6/sum(t['us'] for t in w),'full_windows':len(w),'measured_seconds':sum(t['us'] for t in w)/1e6,'requested_seconds':x['seconds_requested'],'max_render_us':x['max_render_us'],'missed':sum(t['missed'] for t in w),'underflows':sum(t['uf'] for t in w)}
report={'version':2,'created':datetime.datetime.now().isoformat(),'elf_sha256':digest,'bit_sha256':e['bit_sha256'],'hardware_unchanged_from_v1':True,'sprite_size':[8,8],'alpha':224,'color_key':'ff00ff','fpga_stress':metrics(e),'cpu_stress':metrics(c),'interactive_dodge':metrics(d),'game_difficulties':[],'ram_bytes':118720,'ram_capacity_bytes':126976,'loaded_verified_bytes':47570,'flash_written':False,'final_board_state':'Dodge challenge menu, limit 512, autoplay OFF','baseline_count_v1':672,'verified_count_increase_percent':(928/672-1)*100,'background_pixels_before':307200,'background_pixels_after':220288}
for x in g['runs']:
 w=x['play_windows'][1:];report['game_difficulties'].append({'difficulty':x['difficulty'],'passed_60fps':True,'windows':len(w),'max_render_us':max(t['max'] for t in w)})
for p in ['release_summary.json','验收结果.txt']:
 old=res/(Path(p).stem+'_v1'+Path(p).suffix)
 if not old.exists():shutil.copyfile(res/p,old)
(res/'release_summary_v2.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(res/'release_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
lines=['HDMI 露米娅 Demo v2：验收结果',report['created'],'','一、可复查实机成绩',
'固定弹丸压力：928 个 8×8 弹丸，Alpha=224 与 Color Key 同时开启，连续 300 秒测试通过。',
f"完整统计窗口 {report['fpga_stress']['full_windows']} 个，实际有效统计 {report['fpga_stress']['measured_seconds']:.2f} 秒；全部 60.00 FPS，漏帧 0、欠流 0、拒绝发射 0。",
f"同数量 CPU：{report['cpu_stress']['fps']:.2f} FPS；FPGA 输出帧率约为 CPU 的 {report['fpga_stress']['fps']/report['cpu_stress']['fps']:.2f} 倍。",
'与 v1 已验证的 672 个相比，v2 已验证数量增加 256 个，约 38.1%。不声称这是理论最大值。',
'互动躲弹挑战：864 个弹丸，加玩家绘制、逐弹碰撞、擦弹、计时；完整 60 秒挑战测试，自动移动免伤。',
f"互动模式完整窗口 {report['interactive_dodge']['full_windows']} 个，均为 60.00 FPS；漏帧 0、欠流 0、拒绝发射 0。",
'互动模式自动测试用于稳定负载；手动方向/扣命/护盾/重开/通关由主机直接运行实际逻辑检查。用户确认优化后画面无残影或闪烁。',
'首个包含初始化/模式切换的统计窗口不计入稳定窗口；未把菜单或结束界面的帧率当成游戏成绩。',
'建议有余量的演示档位：纯压力 864，互动躲弹 800；512 适合先练习操作。',
'4096 是数组容量，并非 60 FPS 数量承诺。所有帧率均来自实际前后缓冲交换。','',
'二、原符卡回归']
for x in report['game_difficulties']:lines.append(f"{x['difficulty']}：{x['windows']} 个完整 PLAY 窗口全部 60 FPS，最大逻辑+绘制 {x['max_render_us']} us。")
lines+=['','三、优化与正确性','CPU 准备下一条指令与当前 FPGA 作业重叠；最多一个作业在途，寄存器/CPU 写像素/交换前等待完成。','每帧只恢复游戏区与动态 HUD，共 220288 像素，比全屏恢复减少约 28.3%。CPU 对照执行相同工作。','减少热路径 MMIO 函数调用和反复计时读取，保持错误与超时检查。硬件 RTL/比特流未改动。','48 帧完整像素与冻结 v1 逐字节一致；覆盖裁剪、叠加、Alpha 极值、模式切换、双缓冲、HUD/菜单。','实际躲弹逻辑检查：四方向、相反方向、护盾不减负载、三次碰撞失败、重开、3600 帧通关、原符卡炸弹行为通过。','沿用已验证的 AXI 引擎和时序；本次全部 47570 字节固件完整读回通过。','','四、工程状态','片上 RAM 含栈：118720 / 126976 字节。DDR 资源布局不变，约 3.58 MiB。','当前板卡停在躲弹挑战菜单，512 弹丸，自动测试已关闭；SW3 开始。','未写 Flash，断电后需运行 START_HDMI_RUMIA.cmd。reference/release_v1_672_*.zip 保留旧版回退包。','','ELF SHA256: '+digest,'BIT SHA256: '+e['bit_sha256'],'','证据：endurance_v2_928.json、cpu_v2_928.json、dodge_full_v2_864.json、game_v2.json、scene_pixels_v2.json、dodge_logic_v2.json、load_v2_release、visual_v2.json。']
(res/'验收结果.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8-sig')
req=load('requirements.json')
for x in req['requirements']:
 if x[0]=='CPU versus FPGA FPS':x[1:]=['verified v2: same 928 sprites, FPGA 60 FPS vs CPU 5 FPS','results/cpu_v2_928.json; results/endurance_v2_928.json']
 if x[0]=='Stable 60FPS sprite limit':x[1:]=['verified v2: 928 sprites for 300s; 864 interactive dodge for full challenge','results/endurance_v2_928.json; results/dodge_full_v2_864.json']
(res/'requirements.json').write_text(json.dumps(req,indent=2))
p=r/'使用说明.txt';s=p.read_text(encoding='utf-8-sig')
s=s.replace('2026-10-26 / Ti60F225I3-V4','v2 / Ti60F225I3-V4')
s=s.replace('模式依次为 Normal、Hard、Lunatic、FPGA 压力测试、CPU 压力测试。','模式依次为 Normal、Hard、Lunatic、FPGA 压力测试、CPU 压力测试、60 秒躲弹挑战。\n躲弹挑战：保持选定弹丸数量，四方向移动、三条生命、擦弹计分，生存 60 秒获胜。\nSW0+SW1 在此模式为短时护盾，不清除弹丸；建议 512 先练习，800 档演示，864 档已通过完整挑战性能测试。')
s=s.replace('最终固件在 672 个 8×8 弹丸、Alpha+Key 同开时，连续 300 秒测试通过；147 个完整窗口均为 60.00 FPS，漏帧/欠流为零。','v2 最终固件在 928 个 8×8 弹丸、Alpha+Key 同开时，连续 300 秒测试通过；147 个完整窗口均为 60.00 FPS，漏帧/欠流为零。')
s=s.replace('建议演示压力测试使用 640 档，留出余量；672 是本次指定负载的已验证档位，不是所有场景的通用上限。','建议演示压力测试使用 864 档，留出余量；928 是本次指定负载的已验证档位，不是所有场景的通用上限。')
s=s.replace('同样 672 个弹丸的纯 CPU 对照','同样 928 个弹丸的纯 CPU 对照')
s=s.replace('118016 字节','118720 字节').replace('46874 字节','47570 字节')
s=s.replace('results/load_final：最终固件逐字节读回校验。','results/load_v2_release：v2 固件逐字节读回校验。')
s+='\n八、v2 新增优化与验证\n异步提交一个硬件作业，CPU 同时准备下一精灵；访问相关像素前等待完成。\n背景仅恢复 384×448 游戏区与 208×232 HUD 区，双缓冲首次使用时仍完整初始化。\n热路径 MMIO 内联，CMD 自带完成状态清除；超时检查保留但不为每个精灵重复读取计时器。\n主机逐帧像素对照：scripts/test_scene.py；躲弹玩法逻辑：scripts/test_dodge.py。\n上板监测：scripts/monitor_board.py；压力：scripts/benchmark_board.py；详细成绩见 results/验收结果.txt。\n回退包位于 reference/release_v1_672_*.zip。答辩顺序见 答辩演示提纲.txt。\n'
p.write_text(s,encoding='utf-8-sig')
print(json.dumps(report,ensure_ascii=False,indent=2))
