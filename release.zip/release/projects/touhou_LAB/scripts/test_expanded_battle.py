#!/usr/bin/env python3
"""Production six-slot boss core regressions; hardware-free."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess,sys
from datetime import datetime,timezone
root=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));args=a.parse_args()
cc=[x.strip('"') for x in shlex.split(args.host_cc,posix=False)];out=root/'build';out.mkdir(exist_ok=True)
exe=out/('expanded_battle.exe' if os.name=='nt' else 'expanded_battle')
cmd=cc+['-std=gnu11','-O2','-UNDEBUG','-Wall','-Wextra','-Wno-unused-parameter','-Isrc','-Itests/stub','tests/expanded_battle.c','src/stage.c','src/player.c', 'src/enemies.c','src/layer_visuals.c','src/effects.c','src/game_config.c','tests/host_scene_stubs.c','-o',str(exe)]
p=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=45);log=p.stdout+p.stderr;code=p.returncode
if not code:
 p=subprocess.run([str(exe)],cwd=root,capture_output=True,text=True,timeout=45);log+=p.stdout+p.stderr;code=p.returncode
ok=not code and 'R6_EXPANDED_BATTLE PASS checks=' in log
val=root/'results/validation';val.mkdir(parents=True,exist_ok=True);(val/'expanded_battle.log').write_text(log,encoding='utf-8')
(root/'results/expanded_battle.json').write_text(json.dumps({'status':'PASS' if ok else 'FAIL','generated_utc':datetime.now(timezone.utc).isoformat(),'exit_code':code,'command':cmd,'scope':'1/2/3/4/5/6 active bosses,independentVM/enrage/HP,ordinaryowners128..255,6targetplayerlogic; hostonlynotFPS','source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['src/battle.c','src/battle.h','src/player.c', 'src/enemies.c','src/layer_visuals.c','src/game_config.c','src/game_config.h','tests/expanded_battle.c']}},indent=2),encoding='utf-8')
print(log,end='');sys.exit(0 if ok else 1)
