"""Real firmware main/scene/motion UART path, diagnostic off/on with native DMA.
The native video clock is synthetic and cannot establish physical FPS.
Run test_pipe5.py first to derive the unchanged production entry fixture.
"""
from pathlib import Path
import argparse, subprocess, json, hashlib, re
P=Path(__file__).resolve().parents[1];O=P/'build/pipe5';R=P/'results/segment_diag';R.mkdir(parents=True,exist_ok=True)
a=argparse.ArgumentParser();a.add_argument('--host-cc',default='E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe');a=a.parse_args()
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
seal={p.name:H(p) for p in sorted((P/'src').glob('*')) if p.is_file()}
assert json.loads((O/'source_seal.json').read_text())==seal,'run current test_pipe5 first'
s=(O/'candidate_host.c').read_text()
# A read-only fixture callback takes both variants at the same production
# completion boundary, before cleanup. UART delivery time is not this boundary:
# longer diagnostic tails deliberately drain while cleanup is still pending.
gl=(P/'src/game_load.inc').read_text();needle='static void game_load_finish(const char *status,const char *reason){\n    if(!game_load_running)return;'
assert gl.count(needle)==1
gl=gl.replace(needle,needle+'\n    host_capture_before_finish();')
capture_inc=O/'segment_capture_game_load.inc';capture_inc.write_text(gl)
game=(O/'candidate_game.c').read_text().replace('#include "game_load.inc"','void host_capture_before_finish(void);\n#include "'+capture_inc.as_posix()+'"')
capture_game=O/'segment_capture_game.c';capture_game.write_text(game)
s=s.replace((O/'candidate_game.c').as_posix(),capture_game.as_posix())
s=s.replace('unsigned uart_writeAvailability(unsigned u) { (void)u; return 0; }','unsigned uart_writeAvailability(unsigned u) { (void)u; return 128; }')
s=s.replace('void uart_write(unsigned u, unsigned c) { (void)u; (void)c; }',r'''
static char capture_prefix[1024],wire_line[1024];static unsigned wire_at,host_saved;
const void *public_snapshot(void);unsigned public_bytes(void);
const void *private_snapshot(void);unsigned private_bytes(void);
void host_capture_before_finish(void){
 char path[1200];snprintf(path,sizeof path,"%s.state.bin",capture_prefix);FILE *f=fopen(path,"wb");assert(f);
 assert(fwrite(public_snapshot(),1,public_bytes(),f)==public_bytes());assert(fwrite(private_snapshot(),1,private_bytes(),f)==private_bytes());fclose(f);
 snprintf(path,sizeof path,"%s.field.bin",capture_prefix);f=fopen(path,"wb");assert(f);uint32_t fb=bb_read(BB_FRONT);
 for(unsigned y=16;y<704;++y)assert(fwrite((void*)(uintptr_t)(fb+y*BB_SCREEN_STRIDE+32*4),4,1024,f)==1024);fclose(f);host_saved=1;
}
void uart_write(unsigned u,unsigned c){(void)u;putchar(c);if(c=='\n'){
 wire_line[wire_at]=0;
 if(!strncmp(wire_line,"GLOAD_DONE ",11)){fflush(stdout);exit(0);}wire_at=0;
 }else if(c!='\r'){assert(wire_at+1<sizeof wire_line);wire_line[wire_at++]=(char)c;}}
'''.replace("'\\n'","'\n'").replace("'\\r'","'\r'"))
# Keep text literal C escapes in the generated fixture (not physical newlines).
s=s.replace("c=='\n'",r"c=='\n'").replace("c!='\r'",r"c!='\r'")
s=s.replace('return host_uart_end-host_uart_at;','return bb_read(BB_DISPLAY_CTRL)?host_uart_end-host_uart_at:0;')
s+=r'''
#include <windows.h>
#include <io.h>
#include <fcntl.h>
extern void backend_reset(unsigned,unsigned,unsigned);
/* Match the target's real motion ownership check; scene's default host hook
 * intentionally fails closed unless a driver-backed fixture supplies it. */
unsigned scene_test_motion_committed(void){return !motion_hw_active();}
int main(int argc,char **argv){
 assert(argc==7);_setmode(_fileno(stdout),_O_BINARY);
 unsigned side=atoi(argv[1]),armed=atoi(argv[2]),policy=atoi(argv[3]),fault=atoi(argv[4]),frames=atoi(argv[5]),n=side==32?5000:20000;
 snprintf(capture_prefix,sizeof capture_prefix,"%s",argv[6]);
 for(unsigned i=0;i<3;++i){uintptr_t v=(uintptr_t[]){0x1000000,0x7000000,0x5ff0000}[i];unsigned z=(unsigned[]){0x1200000,0x400000,0x90000}[i];assert(VirtualAlloc((void*)v,z,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE)==(void*)v);}
 backend_reset(126,1,fault);host_uart_at=0;
 host_uart_end=sprintf((char*)host_uart,":set tick_profile %u\n:set hud_dma_tail_enabled %u\n:hello\n:gload run %u 6 12 %u %u %u 123456789\n",armed,policy,431000+side,n,side,frames);
 firmware_main();return 99;
}
'''
# Raw Python string above contains double C escapes; UART needs real newline escapes.
s=s.replace(r'\\n',r'\n').replace(r'\\r',r'\r')
h=O/'segment_wire_main.c';h.write_text(s)
cmd=json.loads((O/'candidate_argv.json').read_text());cmd[0]=a.host_cc;cmd.remove('-shared');cmd[cmd.index(str(O/'candidate_host.c'))]=str(h)
cmd+=['-DTICK_PROFILE_HOST_ENABLE','-DSEGMENT_DIAG_HOST_ENABLE',str(P/'src/tick_profile.c'),'-Wl,--image-base,0x180000000,--high-entropy-va,--dynamicbase']
summaries=[];maxline=0
wall=['interframe','capture','snapshot','before_logic','runtime_begin','cpu_hud','motion_commit','dma_hud','logic_end','actor_tail','frame_drain','frame_publish','before_swap','swap_publish','swap_wait']
events=['r_submit','snapshot','m_submit','m_done','m_commit','r_done']
def fields(line):return {k:(int(v) if v.isdecimal() else v) for k,v in re.findall(r'(\w+)=([^ ]+)',line)}
def u64(d,key):return d[key+'_lo']+(d[key+'_hi']<<32)
for hz in [1000000,100000000]:
 exe=O/('segment_wire_'+str(hz)+'.exe');cc=cmd+['-DP5_NATIVE_HZ='+str(hz),'-DBSP_CLINT_HZ='+str(hz),'-DTICK_PROFILE_HOST_HZ='+str(hz),'-o',str(exe)]
 q=subprocess.run(cc,cwd=P,capture_output=True,text=True);(R/('compile_'+str(hz)+'.log')).write_text(q.stdout+q.stderr);assert q.returncode==0,q.stderr
 for side,policy,fault in [(8,0,0),(32,0,0),(8,1,0),(32,1,0),(8,0,14)]:
  pair=[]
  for armed in [0,1]:
   tag=f'native_{hz}_{side}_hud{policy}_diag{armed}_fault{fault}';prefix=R/tag
   q=subprocess.run([str(exe),str(side),str(armed),str(policy),str(fault),'60',str(prefix)],cwd=P,capture_output=True,text=True,timeout=120)
   log=R/(tag+'.log');log.write_text(q.stdout+q.stderr);assert not q.returncode,(tag,q.returncode,q.stdout[-3000:],q.stderr)
   lines=q.stdout.splitlines();records=[fields(x)|{'type':x.split()[0]} for x in lines if x.startswith(('SEG_','GLOAD_','MOTION_'))]
   maxline=max(maxline,max(map(lambda x:len(x.encode()),lines)));assert all(len(x.encode())<512 for x in lines if x.startswith(('SEG_','GLOAD_','MOTION_')))
   done=[d for d in records if d['type']=='GLOAD_DONE'];assert len(done)==1 and done[0]['status']==('CANCEL' if fault else 'PASS'),(tag,done)
   stat=next(d for d in records if d['type']=='GLOAD_STAT');n=stat['frames']
   header=[d for d in records if d['type']=='SEG_PROFILE']
   if not armed:assert not header and not any(d['type'].startswith('SEG_') for d in records)
   else:
    assert len(header)==1 and header[0]['samples']==n and header[0]['timer_hz']==hz and not header[0]['overflow'] and not header[0]['order_errors'],(tag,header,n)
    assert header[0]['wall_count']==15 and header[0]['nested_count']==4 and header[0]['counter_count']==7 and header[0]['event_count']==6
    phases=[d for d in records if d['type']=='SEG_PHASE'];assert len(phases)==26
    wp=[d for d in phases if d['kind']=='wall'];assert [d['phase'] for d in wp]==wall and all(d['calls']==n for d in wp)
    ep=[d for d in records if d['type']=='SEG_EVENT'];assert [d['event'] for d in ep]==events and all(d['calls']==n for d in ep),(tag,ep,n)
    peak=next(d for d in records if d['type']=='SEG_PEAK');parts=[d for d in records if d['type']=='SEG_PEAK_PART'];pe=[d for d in records if d['type']=='SEG_PEAK_EVENT']
    if n:
     assert peak['event_mask']==63 and 1<=peak['frame']<=n and len(parts)==15 and all(d['frame']==peak['frame'] for d in parts)
     assert sum(u64(d,'value') for d in parts)==u64(peak,'period')
     offsets={d['event']:u64(d,'value') for d in pe};assert len(pe)==6 and all(d['valid']==1 and d['frame']==peak['frame'] for d in pe)
     assert offsets['r_submit']<=offsets['snapshot']<=offsets['m_submit']<=offsets['m_done']<=offsets['m_commit']<=u64(peak,'render')
     assert offsets['r_submit']<=offsets['r_done']<=u64(peak,'render')
    ready_at=next(i for i,x in enumerate(lines) if x.startswith('GLOAD_READY '));stat_at=next(i for i,x in enumerate(lines) if x.startswith('GLOAD_STAT '));seg_at=next(i for i,x in enumerate(lines) if x.startswith('SEG_PROFILE '));done_at=next(i for i,x in enumerate(lines) if x.startswith('GLOAD_DONE '));assert ready_at<stat_at<seg_at<done_at
   # The DMA/video backend is unchanged. Compare actual gameplay arrays and
   # immutable playfield pixels; numeric HUD diagnostics naturally differ.
   state=Path(str(prefix)+'.state.bin');field=Path(str(prefix)+'.field.bin');pair.append((state.read_bytes(),field.read_bytes()))
   summaries.append({'tag':tag,'frames':n,'log':str(log.relative_to(P)),'log_sha256':H(log),'status':'PASS','segment_header':header,'state_sha256':H(state),'field_sha256':H(field)})
  assert pair[0]==pair[1],('diagnostic changes gameplay/field pixels',hz,side,policy,fault)
assert seal=={p.name:H(p) for p in sorted((P/'src').glob('*')) if p.is_file()},'source changed while testing'
report={'status':'PASS','scope':'Actual native firmware main/UART/scene/motion and production diagnostic core with native display/DMA model. Not physical FPS. Off/on gameplay arrays and cropped playfield pixels compared byte-for-byte.','cases':len(summaries),'max_protocol_bytes':maxline,'source_sha256':seal,'targets':summaries}
(R/'native.json').write_text(json.dumps(report,indent=2));print('SEGMENT NATIVE PASS',len(summaries),'actual main off/on cases; exact gameplay and playfield; raw1M/100MHz; both HUD policies; active cancel; maxline',maxline)
