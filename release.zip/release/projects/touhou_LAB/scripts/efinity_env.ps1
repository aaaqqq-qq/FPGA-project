# Process-local environment; no registry, driver or permanent PATH changes.
if(-not $env:EFINITY_HOME){throw 'Set EFINITY_HOME to the Efinity installation directory.'}
$efinityRoot = $env:EFINITY_HOME
$env:EFINITY_HOME = $efinityRoot.Replace('\','/')
$env:EFXPT_HOME = "$env:EFINITY_HOME/pt"
$env:EFXPGM_HOME = "$env:EFINITY_HOME/pgm"
$env:EFXDBG_HOME = "$env:EFINITY_HOME/debugger"
$env:EFXIPM_HOME = "$env:EFINITY_HOME/ipm"
$env:EFXSVF_HOME = "$env:EFINITY_HOME/debugger/svf_player"
$env:PYTHONHOME = "$efinityRoot\python311"
$env:PYTHONPATH = $null
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTHONUTF8 = '1'
$env:QT_PLUGIN_PATH = "$efinityRoot\python311"
$env:QT_QPA_PLATFORM_PLUGIN_PATH = "$efinityRoot\python311\platforms"
$env:EFINITY_USER_DIR_INI = "$env:LOCALAPPDATA/efinity/user_dir.ini"
if (-not $env:EFINITY_USER_DIR -and (Test-Path -LiteralPath $env:EFINITY_USER_DIR_INI)) {
    $setting = Get-Content -LiteralPath $env:EFINITY_USER_DIR_INI | Where-Object { $_ -like 'EFINITY_USER_DIR=*' } | Select-Object -First 1
    if ($setting) { $env:EFINITY_USER_DIR = $setting.Split('=',2)[1].Replace('\\','\') }
}
if (-not $env:PROCESSOR_ARCHITECTURE) {
    $env:PROCESSOR_ARCHITECTURE = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
    if ($env:PROCESSOR_ARCHITECTURE -eq 'X64') { $env:PROCESSOR_ARCHITECTURE = 'AMD64' }
}
$env:PATH = "$efinityRoot\python311\bin;$efinityRoot\bin;$efinityRoot\pgm\bin;$efinityRoot\scripts;$env:PATH"
