#!/usr/bin/env python3
"""One hardware-free verification entry point.

Runs the real host C tests, static layout/boundary checks, and the RV32 build
when a toolchain is supplied. Unavailable board/Efinity steps are recorded as
NOT_RUN with a reason; the script never prints an unqualified "all PASS".
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
VAL = R / 'results/validation'
VAL.mkdir(parents=True, exist_ok=True)

ap = argparse.ArgumentParser()
ap.add_argument('--host-cc', default=os.environ.get('HOST_CC', 'gcc'))
ap.add_argument('--toolchain-bin', default=os.environ.get('RISCV_GCC_BIN'))
ap.add_argument('--skip-scene', action='store_true')
ap.add_argument('--json', default='verification.json')
a = ap.parse_args()

started = datetime.now(timezone.utc)
status = {}


def run(name: str, cmd: list[str], timeout: int = 900) -> dict:
    log = VAL / (name + '.log')
    print(f'\n=== {name}: {" ".join(cmd)}', flush=True)
    try:
        p = subprocess.run(cmd, cwd=R, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError as e:
        out = f'NOT_RUN missing executable: {e}'
        log.write_text(out, encoding='utf8')
        print(out)
        return {'status': 'NOT_RUN', 'reason': str(e), 'command': cmd, 'log': str(log.relative_to(R))}
    except subprocess.TimeoutExpired:
        out = f'FAIL timeout after {timeout}s'
        log.write_text(out, encoding='utf8')
        print(out)
        return {'status': 'FAIL', 'reason': 'timeout', 'command': cmd, 'log': str(log.relative_to(R))}
    text = p.stdout + p.stderr
    log.write_text(text, encoding='utf8')
    print(text[-4000:], end='')
    st = 'PASS' if p.returncode == 0 else 'FAIL'
    if name == 'rv32_build' and 'RV32_BUILD=NOT_RUN' in text:
        st = 'NOT_RUN'
    return {
        'status': st,
        'exit_code': p.returncode, 'command': cmd,
        'log': str(log.relative_to(R)),
        'stdout_tail': p.stdout[-2000:],
    }


host_cc = [x.strip('"') for x in shlex.split(a.host_cc, posix=False)]
if shutil.which(host_cc[0]) is None and not Path(host_cc[0]).is_file():
    status['host_tests'] = {'status': 'NOT_RUN', 'reason': f'host CC not found: {a.host_cc}'}
    print(status['host_tests'])
else:
    tests = {}
    tests['motion_hw'] = run('motion_hw', [sys.executable, 'scripts/test_motion_hw.py', '--host-cc', a.host_cc])
    tests['pipe5_control'] = run('pipe5_control', [sys.executable, 'scripts/test_pipe5_control.py', '--host-cc', a.host_cc])
    tests['pipe5_runtime_pixels'] = run('pipe5_runtime_pixels', [sys.executable, 'scripts/test_pipe5.py', '--host-cc', a.host_cc])
    tests['pipe5_native_main_wire'] = run('pipe5_native_main_wire', [sys.executable, 'scripts/test_pipe5_wire.py', '--host-cc', a.host_cc])
    tests['segment_unit'] = run('segment_unit', [sys.executable, 'scripts/test_segment_diag_unit.py', '--host-cc', a.host_cc])
    tests['segment_native'] = run('segment_native', [sys.executable, 'scripts/test_segment_diag_native.py', '--host-cc', a.host_cc])
    tests['preflight_driver'] = run('preflight_driver', [sys.executable, 'scripts/test_preflight_driver.py', '--host-cc', a.host_cc])
    tests['tick_profile'] = run('tick_profile', [sys.executable, 'scripts/test_tick_profile.py', '--host-cc', a.host_cc])
    tests['batch32_scene'] = run('batch32_scene', [sys.executable, 'tests/batch32_scene/test.py', '--host-cc', a.host_cc])
    tests['game_load'] = run('game_load', [sys.executable, 'scripts/test_game_load.py', '--host-cc', a.host_cc])
    tests['hud_dma_lifecycle'] = run('hud_dma_lifecycle', [sys.executable, 'scripts/test_hud_dma_lifecycle.py', '--host-cc', a.host_cc])
    tests['bullet_sizes'] = run('bullet_sizes', [sys.executable, 'tests/bullet_sizes/test.py', '--host-cc', a.host_cc])
    tests['hud_compact'] = run('hud_compact', [sys.executable, 'tests/hud_compact/test.py', '--host-cc', a.host_cc])
    tests['remote_input'] = run('remote_input', [sys.executable, 'scripts/test_remote_input.py', '--host-cc', a.host_cc])
    tests['advanced_alpha_key_physics'] = run('advanced_alpha_key_physics', [sys.executable, 'scripts/test_adv.py', '--host-cc', a.host_cc])
    tests['labx_memory_driver'] = run('labx_memory_driver', [sys.executable, 'scripts/test_labx.py', '--host-cc', a.host_cc])
    tests['lab_image_upload'] = run('lab_image_upload', [sys.executable, 'scripts/test_labimg.py', '--host-cc', a.host_cc])
    tests['lab_fill_copy'] = run('lab_fill_copy', [sys.executable, 'scripts/test_lab.py', '--host-cc', a.host_cc])
    tests['benchmark_acceptance'] = run('benchmark_acceptance', [sys.executable, 'scripts/test_benchmark_acceptance.py'])
    tests['enemies'] = run('enemies', [sys.executable, 'scripts/test_enemies.py', '--host-cc', a.host_cc])
    tests['expanded_battle'] = run('expanded_battle', [sys.executable, 'scripts/test_expanded_battle.py', '--host-cc', a.host_cc])
    tests['r6_integration'] = run('r6_integration', [sys.executable, 'scripts/test_r6_integration.py', '--host-cc', a.host_cc])
    tests['background'] = run('background', [sys.executable, 'scripts/test_background.py', '--host-cc', a.host_cc])
    tests['hud_dirty_fast'] = run('hud_dirty_fast', [sys.executable, 'tests/hud_dirty_fast/test.py', '--host-cc', a.host_cc])
    tests['terminal_render'] = run('terminal_render', [sys.executable, 'scripts/test_terminal_render.py', '--host-cc', a.host_cc])
    tests['layer_visuals'] = run('layer_visuals', [sys.executable, 'scripts/test_layer_visuals.py', '--host-cc', a.host_cc])
    tests['render_budget'] = run('render_budget', [sys.executable, 'scripts/test_render_budget.py', '--host-cc', a.host_cc])
    tests['battle_exact'] = run('battle_exact', [sys.executable, 'tests/battle_exact/test.py', '--host-cc', a.host_cc])
    tests['render_queue'] = run('render_queue', [sys.executable, 'tests/render_queue/test.py', '--host-cc', a.host_cc])
    tests['r7_render_integration'] = run('r7_render_integration', [sys.executable, 'scripts/test_r7_render_integration.py', '--host-cc', a.host_cc])
    tests['stability_analyzer'] = run('stability_analyzer', [sys.executable, 'scripts/test_stability_analyzer.py'])
    tests['stress_pipeline'] = run('stress_pipeline', [sys.executable, 'scripts/test_stress_pipeline.py', '--host-cc', a.host_cc])
    tests['telemetry_counters'] = run('telemetry_counters', [sys.executable, 'scripts/test_telemetry_counters.py', '--host-cc', a.host_cc])
    tests['frame_clock'] = run('frame_clock', [sys.executable, 'scripts/test_frame_clock.py', '--host-cc', a.host_cc])
    tests['game_clock_epoch'] = run('game_clock_epoch', [sys.executable, 'scripts/test_game_clock.py', '--host-cc', a.host_cc])
    tests['replay'] = run('replay', [sys.executable, 'scripts/test_replay.py', '--host-cc', a.host_cc])
    tests['runtime_cli'] = run('runtime_cli', [sys.executable, 'scripts/test_runtime_cli.py', '--host-cc', a.host_cc])
    tests['r2_core'] = run('r2_core', [sys.executable, 'scripts/test_r2_core.py', '--host-cc', a.host_cc])
    if os.name == 'nt':
        tests['font_equivalence'] = run('font_equivalence', [sys.executable, 'scripts/test_font_equivalence.py', '--host-cc', a.host_cc])
    else:
        tests['font_equivalence'] = {'status': 'NOT_RUN', 'reason': 'guarded font pixel comparison requires Win32 VirtualAlloc'}
    if os.name == 'nt':
        tests['r2_render'] = run('r2_render', [sys.executable, 'scripts/test_r2_render.py', '--host-cc', a.host_cc])
    else:
        tests['r2_render'] = {'status': 'NOT_RUN', 'reason': 'renderer pixel harness requires Win32 VirtualAlloc'}
    tests['phase_gameplay'] = run('phase_gameplay', [sys.executable, 'scripts/test_phase_gameplay.py', '--host-cc', a.host_cc])
    tests['legacy_battle'] = run('legacy_battle', [sys.executable, 'scripts/test_original_battle.py', '--host-cc', a.host_cc])
    tests['stage'] = run('stage', [sys.executable, 'scripts/test_stage.py', '--host-cc', a.host_cc])
    tests['dodge_controls'] = run('dodge_controls', [sys.executable, 'scripts/test_dodge.py', '--host-cc', a.host_cc])
    if a.skip_scene or os.name != 'nt':
        tests['scene_pixels'] = {'status': 'NOT_RUN', 'reason': 'scene host model requires Win32 VirtualAlloc'}
    else:
        tests['scene_pixels'] = run('scene_pixels', [sys.executable, 'scripts/test_scene.py', '--host-cc', a.host_cc])
    tests['game_load_render_diag'] = run('game_load_render_diag', [sys.executable, 'scripts/test_game_load_render.py', '--host-cc', a.host_cc])
    tests['sw3_state'] = run('sw3_state', [sys.executable, 'scripts/test_sw3_state.py', '--host-cc', a.host_cc])
    tests['hud_overlap'] = run('hud_overlap', [sys.executable, 'tests/hud_overlap/test.py', '--host-cc', a.host_cc])
    failed = [k for k, v in tests.items() if v['status'] == 'FAIL']
    skipped = [k for k, v in tests.items() if v['status'] == 'NOT_RUN']
    status['host_tests'] = {
        'status': 'FAIL' if failed else ('PASS' if not skipped else 'PARTIAL'),
        'tests': tests, 'failed': failed, 'not_run': skipped,
    }

# Static contract checks that do not need a board or a C compiler.
static = {}
stage_h = (R / 'src/stage.h').read_text()
art = (R / 'src/art_data.h').read_text()
ids = (R / 'src/art_ids.h').read_text()
game = (R / 'src/game.c').read_text()
battle = (R / 'src/battle.c').read_text()
static['shot_layout'] = ('int32_t x,y; int16_t vx,vy; uint16_t age; uint8_t tile,grazed;' in stage_h)
static['shot_capacity_20000'] = ('#define SHOT_CAPACITY 20000' in stage_h)
static['pc_controls_only'] = 'gpio_getInput' not in game and '#include "gpio.h"' not in game and 'remote_input_feed' in game
static['lab1_capability_identity'] = 'CAPS fw=LAB23 proto=2 controls=PC lab=1 labx=1' in game and 'fw=LAB23 paused=%u control=PC' in game
static['lab_game_display_ownership'] = 'if(lab_active()||lab_pending()||labx_active()||labx_pending()||adv_active()||adv_pending())' in game and 'game_lab_restore' in game
static['player_capacity_128'] = ('PLAYER_SHOT_CAPACITY 128' in (R / 'src/player.h').read_text())
_tiles = art.split('static const Tile tiles[] = {', 1)[-1].split('};', 1)[0]
_tile_rows = [tuple(int(x) for x in re.findall(r'\d+', row)) for row in _tiles.splitlines() if '},' in row]
static['material_block_54_69'] = len(_tile_rows) >= 70 and all(
    len(_tile_rows[i]) == 3 and _tile_rows[i][1:] == (8, 8) for i in range(54, 70))
static['art_tile_count_91'] = len(_tile_rows) == 91 and 'ART_TILE_COUNT = 91' in ids
static['no_direct_game_boss_damage'] = not re.search(r'bosses\[[^\]]+\]\.hp\s*[-+]?=', game)
static['unified_damage_entry'] = 'int battle_apply_damage(' in battle and 'battle_apply_damage' in (R / 'src/player.c').read_text()
static['batch_snapshot_frozen_count'] = 'batch_count' in (R / 'src/scene.c').read_text() and 'batch_count*16' in (R / 'src/scene.c').read_text()
static['effect_budget_config'] = 'effect_job_budget' in (R / 'src/game_config.c').read_text()
static['hud_restore_panel'] = 'restore_rect(1072,118,208,586)' in (R / 'src/scene.c').read_text()
static['art_bytes'] = int(re.search(r'#define ART_BYTES (\d+)u', art)[1])
static['art_under_2m'] = static['art_bytes'] < 0x200000
static_fail = [k for k, v in static.items() if isinstance(v, bool) and not v]
status['implementation'] = {'status': 'FAIL' if static_fail else 'PASS', 'checks': static, 'failed': static_fail}

# RV32 build: only a real compiler/linker result can be PASS.
if a.toolchain_bin:
    rv = run('rv32_build', [sys.executable, 'scripts/build_firmware.py', '--toolchain-bin', a.toolchain_bin])
else:
    rv = run('rv32_build', [sys.executable, 'scripts/build_firmware.py', '--allow-missing'])
status['rv32_build'] = rv

status['hardware_build'] = {'status': 'NOT_RUN', 'reason': 'not executed by this offline script; Efinity availability is not probed'}
status['board_function'] = {'status': 'NOT_RUN', 'reason': 'not executed by this offline script; board connection is not probed'}
status['board_fps'] = {'status': 'NOT_RUN', 'reason': 'not executed by this offline script; requires a separate board run and raw logs'}

result = {
    'schema': 'hdmi_rumia_phase_verification_v1',
    'generated_utc': started.isoformat(),
    'completed_utc': datetime.now(timezone.utc).isoformat(),
    'platform': {'os': os.name, 'host_cc': a.host_cc, 'toolchain_bin': a.toolchain_bin},
    'implementation': status['implementation'],
    'host_tests': status['host_tests'],
    'rv32_build': status['rv32_build'],
    'hardware_build': status['hardware_build'],
    'board_function': status['board_function'],
    'board_fps': status['board_fps'],
    'source_sha256': {str(p.relative_to(R)): hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in sorted((R / 'src').glob('*')) if p.is_file()},
    'notes': 'T11 scene model is host-only; board/FPS and Efinity build are not executed by this offline script.',
}
(R / 'results' / a.json).write_text(json.dumps(result, indent=2), encoding='utf8')
print('\n=== SUMMARY ===')
for key in ('implementation', 'host_tests', 'rv32_build', 'hardware_build', 'board_function', 'board_fps'):
    v = result[key]
    print(f'{key}: {v.get("status")}' + (f' ({v.get("reason")})' if v.get('reason') else ''))
print('verification:', R / 'results' / a.json)
if any(result[k].get('status') == 'FAIL' for k in ('implementation', 'host_tests', 'rv32_build')):
    raise SystemExit(1)
