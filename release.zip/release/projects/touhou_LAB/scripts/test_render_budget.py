#!/usr/bin/env python3
"""Actual R8 quality policy and draw traces, hardware-free; never an FPS claim."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, os, shlex, subprocess
R=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=p.parse_args()
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
b=R/'build/render_budget';b.mkdir(parents=True,exist_ok=True);exe=b/'test.exe'
cmd=cc+['-std=gnu11','-O2','-UNDEBUG','-Wall','-Wextra','-Isrc','tests/render_budget/test.c','src/layer_visuals.c','src/game_config.c','-o',str(exe)]
q=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=60);log=q.stdout+q.stderr;code=q.returncode
if not code:q=subprocess.run([str(exe)],cwd=R,capture_output=True,text=True,timeout=90);log+=q.stdout+q.stderr;code=q.returncode
print(log,end='');status='PASS' if not code and 'RENDER_BUDGET PASS' in log else 'FAIL'
(R/'results/render_budget.json').write_text(json.dumps({'status':status,'generated_utc':datetime.now(timezone.utc).isoformat(),'command':cmd,'exit_code':code,'output':log,'hardware_accessed':False,'scope':'Production effects.c/layer_visuals.c policy and traced scene calls; exact boundaries/hysteresis/cue retention/lifetimes/hard budgets. No physical timing or FPS evidence.','source_sha256':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['src/effects.c','src/effects.h','src/layer_visuals.c','src/layer_visuals.h','tests/render_budget/test.c']}},indent=2),encoding='utf-8')
raise SystemExit(0 if status=='PASS' else 1)
