"""Real current-main linepublish against frozen F288; no device access or native FPS claim."""
from pathlib import Path
import json,re,subprocess,hashlib,datetime,sys

P=Path(__file__).resolve().parents[1];B=P.parent/'game60_pipe5_actorfast_fw_20261103'
O=P/'results/linepublish_main'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S');O.mkdir(parents=True)
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
seal={str(p.relative_to(P)):H(p) for p in (P/'src').glob('*') if p.is_file()}
base_seal={str(p.relative_to(B)):H(p) for p in (B/'src').glob('*') if p.is_file()}

callbacks=r'''
#include <windows.h>
#include <wincrypt.h>
#include <io.h>
#include <fcntl.h>
static char capture_prefix[1024],wire_line[1024];static unsigned wire_at,test_mode;
const void *private_snapshot(void);unsigned private_bytes(void);
static void hash_parts(unsigned char digest[32],const void *p,unsigned n,const void *q,unsigned m){
 HCRYPTPROV provider=0;HCRYPTHASH hash=0;DWORD bytes=32;
 assert(CryptAcquireContext(&provider,0,0,PROV_RSA_AES,CRYPT_VERIFYCONTEXT));
 assert(CryptCreateHash(provider,CALG_SHA_256,0,0,&hash));assert(CryptHashData(hash,(const BYTE*)p,n,0));
 if(m)assert(CryptHashData(hash,(const BYTE*)q,m,0));
 assert(CryptGetHashParam(hash,HP_HASHVAL,digest,&bytes,0)&&bytes==32);CryptDestroyHash(hash);CryptReleaseContext(provider,0);
}
void host_capture_frame(void){
 unsigned char banks[32],state[32];hash_parts(banks,(void*)(uintptr_t)0x01000000,0x800000,0,0);
 hash_parts(state,public_snapshot(),public_bytes(),private_snapshot(),private_bytes());
 fprintf(stderr,"HDF frame=%u banks=",gl.frames);for(unsigned i=0;i<32;++i)fprintf(stderr,"%02x",banks[i]);
 fprintf(stderr," state=");for(unsigned i=0;i<32;++i)fprintf(stderr,"%02x",state[i]);fprintf(stderr,"\n");
 if(test_mode==1&&gl.frames==60)host_schedule_cli();
}
void host_after_motion_started(void){if(test_mode==2&&gl.frames==60)host_schedule_cli();}
void host_before_finish(void){
 char path[1200];snprintf(path,sizeof path,"%s.state.bin",capture_prefix);FILE *f=fopen(path,"wb");assert(f);
 assert(fwrite(public_snapshot(),1,public_bytes(),f)==public_bytes());assert(fwrite(private_snapshot(),1,private_bytes(),f)==private_bytes());fclose(f);
 snprintf(path,sizeof path,"%s.banks.bin",capture_prefix);f=fopen(path,"wb");assert(f);assert(fwrite((void*)(uintptr_t)0x01000000,1,0x800000,f)==0x800000);fclose(f);
}
void uart_write(unsigned u,unsigned c){(void)u;putchar(c);if(c=='\n'){
 wire_line[wire_at]=0;if(!strncmp(wire_line,"GLOAD_DONE ",11)){fflush(stdout);exit(0);}wire_at=0;
 }else if(c!='\r'){assert(wire_at+1<sizeof wire_line);wire_line[wire_at++]=(char)c;}}
unsigned scene_test_motion_committed(void){return !motion_hw_active();}
static void report_unit(unsigned mode){
 unsigned *g=(unsigned*)&gl;for(unsigned i=0;i<sizeof(gl)/4;++i)g[i]=i%17;
 gl.id=991;gl.pipe=1;gl.frames=60;gl.ready=1;game_load_running=1;
 unsigned *v=(unsigned*)&pipe_presented;for(unsigned i=0;i<sizeof(pipe_presented)/4;++i)v[i]=i+100;
 logic_drops=3;logic_overruns=4;runtime_tick=61;hud_dma_tail_enabled=1;pipe_live_epoch=62;pipe_backlog_peak=7;pipe_fallbacks=8;
 command_reply_head=14;command_reply_count=0;txpos=txlen=0;
#ifdef REPORT_OVERLAP_CANDIDATE
 fprintf(stderr,"REPORT_SNAPSHOT_BYTES=%u\n",(unsigned)sizeof(GameLoadReport));
 if(mode==11){command_reply_count=12;game_load_report_freeze();assert(!"full queue accepted");}
 game_load_report_freeze();
 unsigned head=command_reply_head,count=command_reply_count;service_command_output();assert(head==command_reply_head&&count==command_reply_count);
 if(mode==12){game_load_report_freeze();assert(!"duplicate snapshot accepted");}
 /* Capture all live sources, then poison them: no formatter may reread these. */
 memset(&gl,0xa5,sizeof gl);memset(&pipe_presented,0x5a,sizeof pipe_presented);
 logic_drops=logic_overruns=runtime_tick=hud_dma_tail_enabled=pipe_live_epoch=pipe_backlog_peak=pipe_fallbacks=0xffffffffu;
 battle_load_fills=battle_load_recycles=battle_load_keeps=battle_load_player_hits=battle_load_player_damage=battle_load_boss_hits=battle_load_mob_hits=0xffffffffu;
 effects_drop_total=stage.fault=mode=hardware=battle_load_active=paused=0xffffffffu;
 /* A later response must remain after the four reserved samples. */
 command_message("AFTER_SAMPLE");game_load_report_drain();assert(!game_load_report_pending&&command_reply_count==5);
#else
 game_load_stat();game_load_pipe_report("sample");command_message("AFTER_SAMPLE");
#endif
 for(unsigned i=0;i<command_reply_count;++i)fputs(command_replies[(command_reply_head+i)%COMMAND_REPLY_CAP],stdout);
 exit(0);
}
int main(int argc,char **argv){
 assert(argc==7);_setmode(_fileno(stdout),_O_BINARY);
 unsigned side=atoi(argv[1]),diag=atoi(argv[2]),frames=atoi(argv[3]),fast=atoi(argv[5]),n=side==32?5000:20000;
 test_mode=atoi(argv[4]);snprintf(capture_prefix,sizeof capture_prefix,"%s",argv[6]);
 for(unsigned i=0;i<3;++i){uintptr_t a=(uintptr_t[]){0x1000000,0x7000000,0x5ff0000}[i];unsigned z=(unsigned[]){0x1200000,0x400000,0x90000}[i];assert(VirtualAlloc((void*)a,z,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE)==(void*)a);}
 backend_reset(126,fast,0);if(test_mode>=10)report_unit(test_mode);
 host_uart_at=0;host_uart_end=sprintf((char*)host_uart,":set tick_profile %u\n:set hud_dma_tail_enabled 0\n:hello\n:gload run %u 6 12 %u %u %u 123456789\n",diag,471000+side,n,side,frames);
 firmware_main();return 99;
}
'''

def run(cmd,tag,timeout=300):
 q=subprocess.run(cmd,cwd=P,capture_output=True,text=True,timeout=timeout)
 (O/(tag+'.stdout.log')).write_text(q.stdout);(O/(tag+'.stderr.log')).write_text(q.stderr)
 return q

exes={}
for label,root in [('golden',B),('candidate',P)]:
 G=root/'build/pipe5';assert json.loads((G/'source_seal.json').read_text())=={p.name:H(p) for p in (root/'src').glob('*') if p.is_file()}
 gl=(root/'src/game_load.inc').read_text().replace('static void game_load_after_swap(','void host_capture_frame(void);\nstatic void game_load_after_swap(')
 gl=gl.replace('++gl.frames;gl.logic_ticks=','++gl.frames;host_capture_frame();gl.logic_ticks=')
 needle='static void game_load_finish(const char *status,const char *reason){\n    if(!game_load_running)return;';assert gl.count(needle)==1
 gl=gl.replace(needle,needle+'\n    host_before_finish();')
 gf=O/(label+'_game_load.inc');gf.write_text(gl)
 pipe=(root/'src/pipe5_runtime.inc').read_text().replace('runtime_pipe_begin(snapshot);segment_diag_cut(SD_RUNTIME_BEGIN);','runtime_pipe_begin(snapshot);host_after_motion_started();segment_diag_cut(SD_RUNTIME_BEGIN);')
 pf=O/(label+'_pipe.inc');pf.write_text(pipe)
 game=(root/'src/game.c').read_text().replace('for(;;){}','host_test_fatal(where,error);')
 game=game.replace('#include "game_load.inc"','#include "'+gf.as_posix()+'"').replace('#include "pipe5_runtime.inc"','#include "'+pf.as_posix()+'"')
 game='void host_before_finish(void);void host_after_motion_started(void);\n'+game
 gamefile=O/(label+'_game.c');gamefile.write_text(game)
 host=(G/'candidate_host.c').read_text().replace((G/'candidate_game.c').as_posix(),gamefile.as_posix())
 host=host.replace('unsigned uart_writeAvailability(unsigned u) { (void)u; return 0; }','unsigned uart_writeAvailability(unsigned u) { (void)u; return 128; }')
 host=host.replace('void uart_write(unsigned u, unsigned c) { (void)u; (void)c; }','void uart_write(unsigned,unsigned);')
 host=host.replace('return host_uart_end-host_uart_at;','return bb_read(BB_DISPLAY_CTRL)?host_uart_end-host_uart_at:0;')
 hf=O/(label+'_host.c');hf.write_text(host+callbacks)
 cmd=json.loads((G/'candidate_argv.json').read_text());cmd.remove('-shared');cmd[cmd.index(str(G/'candidate_host.c'))]=str(hf)
 exe=O/(label+'.exe');cmd+=['-DTICK_PROFILE_HOST_ENABLE','-DSEGMENT_DIAG_HOST_ENABLE',str(root/'src/tick_profile.c'),'-DP5_NATIVE_HZ=100000000','-DBSP_CLINT_HZ=100000000','-DTICK_PROFILE_HOST_HZ=100000000','-Wl,--image-base,0x180000000,--high-entropy-va,--dynamicbase','-ladvapi32','-o',str(exe)]
 cmd+=['-DREPORT_OVERLAP_CANDIDATE']
 (O/(label+'_argv.json')).write_text(json.dumps(cmd,indent=2));q=run(cmd,label+'_compile');assert q.returncode==0,q.stderr
 exes[label]=exe

results=[]
try:
 # Explicitly rasterize all R/legacy pixels (fast=0); 600-frame samples at both N.
 for side,diag,frames,mode,fast in [(8,0,600,0,0),(32,0,600,0,0),(32,1,61,0,0),(32,0,600,1,0),(32,0,600,2,0)]:
  pair=[]
  for label in ['golden','candidate']:
   tag=f'{label}_{side}_diag{diag}_frames{frames}_mode{mode}_fast{fast}';prefix=O/tag
   q=run([str(exes[label]),str(side),str(diag),str(frames),str(mode),str(fast),str(prefix)],tag,600)
   assert q.returncode==0,(tag,q.returncode,q.stdout[-2000:],q.stderr[-2000:])
   protocol=[x for x in q.stdout.splitlines() if x.startswith(('GLOAD_','MOTION_DIAG '))]
   hashes=[x for x in q.stderr.splitlines() if x.startswith('HDF ')]
   pair.append((protocol,hashes,Path(str(prefix)+'.state.bin').read_bytes(),Path(str(prefix)+'.banks.bin').read_bytes()))
   print(tag,'completed',len(hashes),'frames',flush=True)
  assert pair[0][0]==pair[1][0],('protocol',side,diag,mode,[(a,b) for a,b in zip(pair[0][0],pair[1][0]) if a!=b][:2])
  assert pair[0][1:]==pair[1][1:],('state/pixels',side,diag,mode)
  expected=60 if mode==1 else 61 if mode==2 else frames
  assert len(pair[1][1])==expected
  samples=[x for x in pair[1][0] if x.startswith('GLOAD_PIPE ') and 'phase=sample' in x]
  assert len(samples)==(frames-1)//60 if not mode else len(samples)==1
  results.append({'side':side,'N':20000 if side==8 else 5000,'diag':diag,'mode':mode,'frames':expected,'samples':len(samples),'protocol_exact':True,'every_frame_state_and_8MiB_SHA_exact':True,'completion_bytes_exact':True,'fast_raster_skipped':False})
 for mode in [10,11,12]:
  out=[]
  for label in (['golden','candidate'] if mode==10 else ['candidate']):
   q=run([str(exes[label]),'32','0','60',str(mode),'0',str(O/f'unit_{label}_{mode}')],f'unit_{label}_{mode}')
   if mode==10:assert q.returncode==0;out.append(q.stdout)
   else:assert q.returncode==90 and ('GLOAD REPORT QUEUE' if mode==11 else 'GLOAD REPORT DUPLICATE') in q.stderr,(mode,q.returncode,q.stderr)
  if mode==10:assert out[0]==out[1],('snapshot poisoning/order',out)
  results.append({'unit_mode':mode,'status':'PASS'})
 assert seal=={str(p.relative_to(P)):H(p) for p in (P/'src').glob('*') if p.is_file()}
 assert base_seal=={str(p.relative_to(B)):H(p) for p in (B/'src').glob('*') if p.is_file()}
 result={'status':'PASS','source_sha256':seal,'golden_source_sha256':base_seal,'tests':results,'scope':'Real main native clock and full raster/DMA model. Exact protocol and per-frame complete state/8MiB SHA; no physical timing claim.'}
except BaseException as e:
 result={'status':'FAIL','error':repr(e),'source_sha256':seal,'golden_source_sha256':base_seal,'completed_tests':results};raise
finally:
 result['generated_sha256']={p.name:H(p) for p in O.iterdir() if p.suffix in ['.c','.inc','.json'] and p.name!='summary.json'}
 (O/'summary.json').write_text(json.dumps(result,indent=2));print('REPORT_OVERLAP',result['status'],O,flush=True)
