"""C289 strict offline authority; no device, GUI, seal, or staging action."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,shutil
F=Path(__file__).resolve().parents[1];W=F.parent;P=W/'game60_pipe5_actorfast_fw_20261103'
R=W/'c289_linepublish_cache_review_20261103';I=W/'c289_independent_cache_review_20261103';N=W/'gui289_native_policy1_20261103/native_policy1_fixture'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
J=lambda p:json.loads(Path(p).read_text('utf-8-sig'))
ELF='fe1c7091b16b5295433df1ca1f177bb8fa54f02cfb7903e547256cfcb98a7b77'
DRIVER='6c7ebe2bc114967582b4c63e0569dad3b8a8db5c92b824943a4c86c2d7dd2790'
V='results/verification_linepublish_final.json';MAIN='results/linepublish_main/20261103_190227/summary.json'
NATIVE='ac0d21693c10fc4b1f7d715de1b8e4bb2355b46c0fe136b4753b4df436425ed9'
POLICY='a8c481c9a52fbf433f64cf4df02586cf5da4f5cf9800ea9b78429ecb4aa8605a'
def save(p,x):
 assert not p.exists(),p
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n','utf8')
def row(rel,**kw):return dict(path=rel,sha256=H(F/rel),**kw)
def bind(m,root=F):
 for rel,sha in m.items():
  p=root/rel
  if not p.is_file():p=root/'src'/rel
  assert p.is_file()and H(p)==sha,p
def validate():
 parent=J(P/'evidence/ACTORFAST_SOURCE_MANIFEST.json');assert H(P/'evidence/ACTORFAST_SOURCE_MANIFEST.json')=='7698fd670375ecb8302fce5e7967dfd5c7f745f57960b410b83ba366bc0a060b';bind(parent,P)
 assert H(F/'src/bitblt.c')==DRIVER
 assert {p.name:H(p)for p in(F/'src').iterdir()if p.is_file()and p.name!='bitblt.c'}=={p.name:H(p)for p in(P/'src').iterdir()if p.is_file()and p.name!='bitblt.c'}
 assert (F/'src/bitblt.c').read_text().split('void bb_acquire(void)',1)[1]==(P/'src/bitblt.c').read_text().split('void bb_acquire(void)',1)[1]
 v=J(F/V);assert all(v[k]['status']=='PASS'for k in('implementation','host_tests','rv32_build'));assert len(v['host_tests']['tests'])==48 and not v['host_tests']['failed']and not v['host_tests']['not_run']
 assert all(q['status']=='PASS'and q['exit_code']==0 for q in v['host_tests']['tests'].values());bind(v['source_sha256'])
 i=J(F/'build/identity.json');assert i['status']=='PASS'and i['elf_sha256']==H(F/'build/rumia.elf')==ELF;bind(i['sources']);bind(i['scripts']);assert i['memory']['ram_remaining_above_reserved_stack']==10320
 main=J(F/MAIN);assert main['status']=='PASS'and len(main['tests'])==8;bind(main['source_sha256']);bind(main['golden_source_sha256'],P);md=(F/MAIN).parent
 for side,n in((8,20000),(32,5000)):
  q=next(q for q in main['tests']if q.get('side')==side and q.get('mode')==0 and q.get('diag')==0)
  assert q['N']==n and q['frames']==600 and q['samples']==9 and q['protocol_exact']and q['every_frame_state_and_8MiB_SHA_exact']and q['completion_bytes_exact']and not q['fast_raster_skipped']
 for golden in md.glob('golden_*.stdout.log'):assert golden.read_bytes()==golden.with_name(golden.name.replace('golden_','candidate_',1)).read_bytes()
 for suffix in('.stderr.log','.banks.bin','.state.bin'):
  for golden in md.glob('golden_*frames*'+suffix):assert golden.read_bytes()==golden.with_name(golden.name.replace('golden_','candidate_',1)).read_bytes()
 pix=J(F/'results/scene_pixels_batch720.json');assert pix['passed']is True and pix['frames_compared']==64 and len(pix['pixel_sha256'])==64
 assert pix['source_sha256']==hashlib.sha256((F/'src/scene.c').read_text().encode()).hexdigest()
 fresh=('results/pipe5/summary.json','results/hud_dma_lifecycle.json','results/segment_diag/unit.json','results/segment_diag/native.json','results/pipe5/native_main_wire.json')
 for rel in fresh:
  q=J(F/rel);assert q['status']=='PASS',rel
  if q.get('source_sha256'):bind(q['source_sha256'])
 assert J(F/fresh[0])['full_state_points']==424
 life=J(F/'results/hud_dma_lifecycle.json');original=life['output'].replace('\n','\r\n').encode();logged=(F/life['log']).read_bytes()
 assert len(original)==193 and len(logged)==195 and hashlib.sha256(original).hexdigest()==life['log_sha256']=='e2dc6084bc4e638bc6fc12984f534523044a01a4187791dff6ad80b1aa6f110a'
 assert logged==original+b'\r\n'and H(F/life['log'])=='c2271fb72fbda5acabbfc430e07b4e9e2dfdcf48c7a49e838a8f1234373b17d0'
 native=J(F/'results/validation/hud_policy1_native_provenance.json');assert H(F/'results/validation/hud_policy1_native_provenance.json')==H(N/'REVIEW.json')==NATIVE
 assert H(F/'results/validation/hud_policy1_complete.log')==POLICY and len(native['source_inputs'])==77 and native['source_inputs_unchanged']and native['compile_exit']==native['run_exit']==0
 assert Path(native['root']).resolve()==F and not native['hardware_accessed']and not native['product_modified'];bind(native['source_inputs'])
 for name,sha in native['raw_logs'].items():assert H(N/name)==sha
 assert H(N/'host.c')==native['fixture_source_sha256']and H(N/'policy1_fixture.exe')==native['fixture_executable_sha256']
 review=R/'source_review_20261103_190701_773975/REVIEW.json';assert H(review)=='c4dd9e95bf346aaaecc4a9100741f53e547f7b4b7fe1ae60d272d3920837b409'
 for x in J(review)['files']:assert H(x['path'])==x['sha256']and Path(x['path']).stat().st_size==x['bytes']
 assert H(I/'FINAL_READ_ONLY_REVIEW_RECEIPT.json')=='587f42523d3d5a49473e6e9ef56de2ff710f4ccc09d4d917a28dca3cccf97efd'
 assert J(R/'micro_20261103_185244_997724/SUMMARY.json')['cache_cases']==128 and J(R/'micro_20261103_185244_997724/SUMMARY.json')['bridge_cases']==256
 assert J(R/'readmiss_20261103_190448_217598/SUMMARY.json')['status']=='PASS_EXACT_GENERATED_DCACHE_HIT_TO_MISS_TO_HIT'
 assert J(I/'INDEPENDENT_COMPILE_AND_DECODER.json')['decoder_cases']==4096
 files=set(parent)
 for sub in('src','scripts','tests'):files.update(p.relative_to(F).as_posix()for p in(F/sub).rglob('*')if p.is_file()and '__pycache__'not in p.parts)
 files.update(p.relative_to(F).as_posix()for p in(F/'evidence/linepublish_cache_originals').rglob('*')if p.is_file()and p.suffix.lower()in('.c','.h','.py','.s','.sv','.v','.inc'))
 mf={rel:H(F/rel)for rel in sorted(files)};assert {rel for rel,sha in mf.items()if rel.startswith('src/')and parent.get(rel)!=sha}=={'src/bitblt.c'}
 return v,i,mf,fresh
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--check',action='store_true');a=ap.parse_args()
 final=F/'evidence/LINEPUBLISH_RELEASE_FINAL_RECEIPT.json';manifest=F/'evidence/LINEPUBLISH_SOURCE_MANIFEST.json';review=F/'evidence/ROOT_LINEPUBLISH_RELEASE_REVIEW.json'
 if not a.check:
  assert not final.exists()and not manifest.exists()and not review.exists()
  # Full original scoped proofs, including every failed harness attempt.
  # Preserve JSON bytes as .json.txt so historical absolute paths are not
  # interpreted by a relocating collector as current source identities.
  originals=[]
  for label,root in [('root',R),('independent',I),('native',N)]:
   for p in sorted(root.rglob('*')):
    if not p.is_file()or'__pycache__'in p.parts:continue
    rel=Path('evidence/linepublish_cache_originals')/label/p.relative_to(root)
    if p.suffix=='.json':rel=Path(str(rel)+'.txt')
    d=F/rel;assert not d.exists();d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d);assert H(d)==H(p)
    originals.append(dict(path=rel.as_posix(),sha256=H(d),bytes=d.stat().st_size,original=str(p)))
  save(F/'evidence/LINEPUBLISH_ORIGINAL_BLOBS.json',dict(status='EXACT_ORIGINALS_UNMODIFIED_ALL_ATTEMPTS_PRESERVED',files=originals))
 v,i,mf,fresh=validate()
 if a.check:
  assert J(manifest)==mf;q=J(final)
  for key in('ELF','identity','verification','source_manifest','native','native_log','product_diff','review_script'):assert H(F/q[key]['path'])==q[key]['sha256']
  for x in q['extra_evidence']:assert H(F/x['path'])==x['sha256']
  for x in J(F/'evidence/LINEPUBLISH_RAW_FILE_MANIFEST.json')['files']:assert H(F/x['path'])==x['sha256']and(F/x['path']).stat().st_size==x['bytes']
  assert J(review)['final_receipt_sha256']==H(final)
 else:
  save(manifest,mf)
  rawfiles={p for p in(F/'results').rglob('*')if p.is_file()}
  rawfiles.update(p for p in(F/'evidence/linepublish_cache_originals').rglob('*')if p.is_file());rawfiles.add(F/'build/compile.log')
  save(F/'evidence/LINEPUBLISH_RAW_FILE_MANIFEST.json',dict(status='CURRENT_C289_RAW_HASHES_AND_SIZES_PASS',files=[row(p.relative_to(F).as_posix(),bytes=p.stat().st_size)for p in sorted(rawfiles)]))
  save(F/'evidence/LINEPUBLISH_REPRESENTATION_RECONCILIATION.json',dict(status='ONLY_EXACT_NAMED_WRITER_REPRESENTATIONS_RECONCILED',scene_raw=row('src/scene.c'),scene_normalized_text_sha256=J(F/'results/scene_pixels_batch720.json')['source_sha256'],scene_test=row('results/scene_pixels_batch720.json'),scene_test_hash_method='read_text().encode(): universal newlines',lifecycle_report=row('results/hud_dma_lifecycle.json'),lifecycle_log=row('results/validation/hud_dma_lifecycle.log'),declared_bytes=193,actual_bytes=195,exact_extra_suffix_hex='0d0a',originals_unmodified=True,no_other_exception=True))
  limits=['100MHz original hardware unchanged; only bb_publish invalidate encoding changes; bb_acquire entire body unchanged.','Exact original DataCache128/DDRbridge256/decoder4096 cases, actual RV32 nonzero-rs1 sequence and cache hit->miss64B/refill->hit establish bounded source/module behavior, not wholeCPU or physical coherency/FPS.','Host BB_HOST_TEST cache stubs cannot prove cache behavior;48 groups/64frames/424points/dual600 actual-main full8MiB/state/alllogs establish game/render identity separately.','Retains63 cache indices and reduces tag iterations64->1; no cycles/ms/FPS benefit measured. C288 actual physical FAIL remains historical evidence, never relabeled.','Original failed micro/harness attempts preserved with scoped cause; no product failure ignored.','Parent scene/glyph historical receipts may be inherited only for unchanged source; no old C286/C287 main identity asserted for current driver.','Hardware fullCPU/cache coherency, physicalFlash, coldboot and FPS NOT_RUN.','Only the specifically named universal-newline/one-extra-CRLF test writer representations reconciled.']
  extras=[MAIN,'results/scene_pixels_batch720.json',*fresh,'evidence/LINEPUBLISH_RAW_FILE_MANIFEST.json','evidence/LINEPUBLISH_ORIGINAL_BLOBS.json','evidence/LINEPUBLISH_REPRESENTATION_RECONCILIATION.json','LINEPUBLISH_README.md']
  save(final,dict(status='FINAL_OFFLINE_PASS_NOT_READY_NOT_FLASHED',created_utc=datetime.now(timezone.utc).isoformat(),implementation='PASS',RV32='PASS',host_groups=48,host_failures=[],host_skips=[],ELF=row('build/rumia.elf'),identity=row('build/identity.json'),source_manifest=row('evidence/LINEPUBLISH_SOURCE_MANIFEST.json',files=len(mf)),verification=row(V),native=row('results/validation/hud_policy1_native_provenance.json'),native_log=row('results/validation/hud_policy1_complete.log'),extra_evidence=[row(r,scope='CURRENT_C289_OFFLINE_SOURCE_BOUND')for r in extras],memory=i['memory'],product_diff=row('evidence/LINEPUBLISH_MINIMAL.diff'),review_script=row('scripts/finalize_linepublish_firmware.py'),changed_product_files=['src/bitblt.c'],runtime_full_raster_frames=[600,600],diag_full_raster_frames=61,scene_full_frames=64,cache_flush_cases=128,DDR_bridge_cases=256,decoder_cases=4096,raw_evidence_files=len(rawfiles),board_FPS='NOT_RUN',physical_Flash='NOT_RUN',cold_boot='NOT_RUN',limits=limits))
  save(review,dict(status='ROOT_SOURCE_LOG_AND_ELF_REVIEW_PASS',approved_for_offline_image=True,approved_for_physical_FPS=False,ELF_sha256=ELF,source_manifest_sha256=H(manifest),source_files=len(mf),verification_sha256=H(F/V),final_receipt_sha256=H(final),clock_mhz=100,gameplay_N_Alpha_Key_unchanged=True,reviewer='Root-delegated c287_release_authority and independent c288_native_fixture: original generated module/source/actual RV32 review plus current host/main regressions; no physical performance claim.',limits=limits))
 print(json.dumps(dict(status='PASS',ELF=ELF,source_manifest_sha256=H(manifest),source_files=len(mf),verification_sha256=H(F/V),final_receipt_sha256=H(final),review_sha256=H(review),native_provenance_sha256=NATIVE,script_sha256=H(Path(__file__))),indent=2))
if __name__=='__main__':main()
