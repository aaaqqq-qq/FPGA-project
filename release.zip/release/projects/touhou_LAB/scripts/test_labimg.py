"""Compile and run production lab.c image upload with independent native oracle."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess,time
r=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser();p.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=p.parse_args();b=r/'build/labimg_host';b.mkdir(parents=True,exist_ok=True)
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)];exe=b/'labimg_host.exe'
cmd=cc+['-std=c99','-O2','-Wall','-Wextra','-Werror','-DBB_HOST_TEST','-Isrc','src/lab.c','src/pixels.c','tests/labimg_host.c','-Wl,--image-base,0x180000000','-o',str(exe)]
start=time.monotonic();runs=[]
for command in [cmd,[str(exe)]]:
 q=subprocess.run(command,cwd=r,capture_output=True,text=True,timeout=180);out=q.stdout+q.stderr;print(out,end='');runs.append(dict(command=command,exit=q.returncode,output=out))
 if q.returncode:break
passed=not runs[-1]['exit'] and 'LABIMG_PASS' in runs[-1]['output']
report=dict(status='PASS' if passed else 'FAIL',hardware='NOT_RUN',scope='production lab.c, independent native CRC/pixels, bounded opaque DMA model',elapsed_seconds=round(time.monotonic()-start,3),runs=runs,source_sha256={name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in ['src/lab.c','src/lab.h','src/game.c','tests/labimg_host.c']})
(r/'results/labimg_host.json').write_text(json.dumps(report,indent=2),encoding='utf8');raise SystemExit(0 if passed else 1)
