param([switch]$CheckOnly)
$ErrorActionPreference='Stop'
if(-not $env:RISCV_GCC_BIN){throw 'Set RISCV_GCC_BIN to the installed RISC-V toolchain bin directory.'}
$root=Split-Path $PSScriptRoot -Parent
& python -B "$PSScriptRoot/build_firmware.py" --toolchain-bin $env:RISCV_GCC_BIN
if($LASTEXITCODE -ne 0){throw 'Firmware build failed'}
Write-Output 'Build complete. This anonymous source package does not contain a pre-authorized Flash image. Rebuild and validate the complete release before programming.'
