"""PIPE5 native actual runtime/scene/DMA tests. Mock time never claims board FPS."""
from pathlib import Path
import ast,ctypes,hashlib,json,os,re,subprocess,sys,argparse
P=Path(__file__).resolve().parents[1];B=Path('E:/Ti60_builds/game60_motion_fw4_20261102')
a=argparse.ArgumentParser();a.add_argument('--host-cc',default='E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe');a.add_argument('--baseline-root',type=Path,default=B);a=a.parse_args();B=a.baseline_root.resolve()
assert hashlib.sha256((B/'src/battle.c').read_bytes()).hexdigest()=='59fda1c9430a70aaaa980b6bc75c722d9cdd07baa3fa09154c878f41fa7347a5'
assert hashlib.sha256((B/'src/game.c').read_bytes()).hexdigest()=='dbec755ed4cd8b819b69752e948143e882942ba4cf45cac9efc4686055a51598'
assert hashlib.sha256((B/'src/scene.c').read_bytes()).hexdigest()=='997115fa7ac016787ea772932c10d43be390fef96a212cdb51148ff87994eacd'
O=P/'build/pipe5';O.mkdir(parents=True,exist_ok=True);R=P/'results/pipe5';R.mkdir(parents=True,exist_ok=True)
def run(cmd,name,timeout=240):
 q=subprocess.run(cmd,cwd=P,capture_output=True,text=True,timeout=timeout);(O/(name+'.log')).write_text(q.stdout+q.stderr,encoding='utf8');assert q.returncode==0,(name,q.returncode,q.stdout[-3000:],q.stderr[-5000:]);return q
T=ast.parse((P/'scripts/test_tick_profile.py').read_text());parts={n.targets[0].id:ast.literal_eval(n.value) for n in T.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['core','private']}
private=parts['private']
core=parts['core'].split('__declspec(dllexport) unsigned read_count',1)[0]
core+=r'''
void host_schedule_cli(void){const char *s=":menu\n";host_uart_at=0;host_uart_end=(unsigned)strlen(s);memcpy(host_uart,s,host_uart_end);}

__declspec(dllexport) unsigned real_hash(void){return runtime_state_hash();}
static unsigned natural_fixture;
__declspec(dllexport) void natural(void){natural_fixture=1;battle_load_end();battle_reset(2,SHOT_CAPACITY);stage.seed=123456789;for(unsigned i=0;i<512;++i)battle_spawn_enemy_bullet(0,100+(int)(i%800),80+(int)(i%500),(int)(i*113),Q+(int)(i%4096),54+(i&15));enemies_reset(12);}
__declspec(dllexport) void prepare(unsigned n,unsigned side){
 natural_fixture=0;
 game_load_running=game_load_cancel=0;battle_load_end();game_config_defaults();replay_reset();mode=MENU;choice=2;custom_limit=n;autoplay=1;demo_invincible=0;
 game_cfg.boss_count=6;game_cfg.enemy_count=12;game_cfg.enemy_bullet_size=side;game_cfg.adaptive_density=0;
 command_reply_head=command_reply_count=command_reply_overruns=0;txpos=txlen=0;command_len=command_overflow=0;deferred_ascii=0;remote_input_init(&remote);
 frame_us=logic_us=render_us=0;scene_init();start();battle_load_begin(123456789,n);enemies_load_begin();play_warmup_frames=0;
 render(BB_FB0);render(BB_FB1);
}
__declspec(dllexport) void frame(unsigned f){
 if(natural_fixture&&(f==3||f==43))battle_apply_damage(0,f==3?1500:10000,1);
 frame_us=16000;render_us=14000;fps100=6000;missed=underflows=logic_drops=0;
 keys=(unsigned[]){0,1,2,4,8,3,12,0}[(f/3)%8];edges=0;bomb_requests=f==7?1:0;
 unsigned fb=(f&1)?BB_FB1:BB_FB0;
#ifdef TEST_PIPE5
 pipe_world_locked=1;pipe_stamp_capture(&pipe_captured);render_capture(fb,1);
 unsigned snap=scene_pipe_snapshot_epoch();pipe_stamp_submission(&pipe_captured);
 if(scene_pipe_fallback()){render_draw_frozen_hud();render_complete();}
 runtime_pipe_begin(snap);if(!scene_pipe_fallback())render_draw_frozen_hud();runtime_pipe_complete();
 if(!scene_pipe_fallback())render_complete();pipe_world_locked=0;++pipe_live_epoch;++pipe_live_input;
#else
 render(fb);runtime_step();
#endif
}
#ifdef TEST_PIPE5
__declspec(dllexport) unsigned queued_cli_and_barrier(void){
 if(mode!=PLAY||pipe_runtime_pending||motion_hw_active())return 0;
 pipe_barrier_commands();return mode==MENU;
}
#endif
'''
backend=(P/'tests/pipe5/backend.inc').read_text()
libs=[]
for label,root,pipe in [('reference',B,False),('candidate',P,True)]:
 game=(root/'src/game.c').read_text();game=re.sub(r'void fatal\(const char \*where,int error\)\{.*?for\(;;\)\{\}\}','void fatal(const char *where,int error){host_test_fatal(where,error);}',game)
 gf=O/(label+'_game.c');gf.write_text(game)
 prefix=(root/'tests/phase_gameplay.c').read_text('utf-8-sig').split('static int failures;',1)[0]
 prefix=prefix.replace('#include "scene_layers_stubs.h"','').replace('#include "pipe5_game_stubs.h"','')
 prefix=prefix.replace('#include "game.c"','void host_test_fatal(const char *,int);\n#include "'+gf.as_posix()+'"')
 x=prefix.index('unsigned scene_list_us,');y=prefix.index('static uint64_t host_ticks;');prefix=prefix[:x]+prefix[y:]
 for fn in ['bb_read','bb_write','bb_ticks','bb_us','bb_probe','bb_publish','bb_acquire','bb_swap_wait']:
  prefix,n=re.subn(r'^.*\b'+fn+r'\([^\n]*\{[^\n]*\}\s*$', '',prefix,flags=re.M);assert n==1,(label,fn,n)
 # Real scene exports these; the legacy lab display stubs only own experiments.
 prefix=re.sub(r'int scene_bullets_prepare\([^\n]+\n','',prefix)
 hf=O/(label+'_host.c');hf.write_text(prefix+core)
 battle=(root/'src/battle.c').read_text();needle='static void simulate_bullets_relevant(int px, int py) {';assert needle in battle;battle=battle.replace(needle,needle+'host_cpu_replay();');bf=O/(label+'_battle.c');bf.write_text('void host_cpu_replay(void);\n'+battle);priv=O/(label+'_private.c');priv.write_text(private.replace('BATTLE',bf.as_posix()).replace('EFFECTS',(root/'src/effects.c').as_posix()).replace('ENEMIES',(root/'src/enemies.c').as_posix())+'\n'+backend)
 # Remove scene bullet stubs from lab header via a local exact derivative.
 lab=(root/'tests/lab_stubs.h').read_text();lab=lab.split('/* The full scene renderer has independent raster/guard tests. */')[0]+'\n#endif\n'
 (O/'lab_stubs.h').write_text(lab)
 hf.write_text(hf.read_text().replace('#include "lab_stubs.h"','#include "'+(O/'lab_stubs.h').as_posix()+'"'))
 common=[a.host_cc,'-std=gnu11','-O2','-shared','-UNDEBUG','-DBB_HOST_TEST','-DMOTION_HW_HOST_TEST','-Wno-misleading-indentation','-I'+str(root/'src'),'-I'+str(P/'src'),'-I'+str(root/'tests'),'-I'+str(root/'tests/stub')]
 if pipe:common+=['-DTEST_PIPE5']
 cmd=common+[str(hf),str(priv),str(P/'tests/motion_hw/reference_kernel.c')]+[str(root/'src'/n) for n in ['motion_hw.c','stage.c','player.c','scene.c','render_queue.c','layer_visuals.c','background.c','pixels.c','game_config.c','font.c','replay.c','remote_input.c']]
 if pipe:cmd+=[str(P/'src/pipe5_control.c')]
 (O/(label+'_argv.json')).write_text(json.dumps(common+[str(hf),str(priv),str(P/'tests/motion_hw/reference_kernel.c')]+[str(root/'src'/n) for n in ['motion_hw.c','stage.c','player.c','scene.c','render_queue.c','layer_visuals.c','background.c','pixels.c','game_config.c','font.c','replay.c','remote_input.c']]+([str(P/'src/pipe5_control.c')] if pipe else [])));dll=O/(label+'.dll');run(cmd+['-o',str(dll)],label+'_compile');lib=ctypes.CDLL(str(dll));lib.public_snapshot.restype=lib.private_snapshot.restype=ctypes.c_void_p;lib.real_hash.restype=ctypes.c_uint32;libs.append(lib)
k=ctypes.WinDLL('kernel32',use_last_error=True);k.VirtualAlloc.restype=ctypes.c_void_p;k.VirtualAlloc.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32,ctypes.c_uint32]
for address,size in [(0x1000000,0x1200000),(0x7000000,0x400000),(0x5ff0000,0x90000)]:assert k.VirtualAlloc(address,size,0x3000,4)==address,ctypes.get_last_error()
points=0;pixels=0;results=[]
for side,n,frames,natural in [(8,20000,32,0),(32,5000,32,0),(8,128,90,0),(32,128,90,0),(8,512,90,1),(32,512,90,1)]:
 expected=[];state=[];hashes=[]
 for ix,lib in enumerate(libs):
  ctypes.memset(0x1000000,0xa5,0x1200000);ctypes.memset(0x7000000,0xa5,0x400000);ctypes.memset(0x5ff0000,0xa5,0x90000)
  lib.backend_reset(126 if ix else 30,0,0);lib.prepare(n,side)
  if natural:lib.natural()
  for f in range(frames):
   lib.frame(f);fb=0x1000000+(0x400000 if f&1 else 0)
   image=ctypes.string_at(fb,1280*720*4)
   # HUD diagnostic wall-time values are normalized by frame() above.
   sha=hashlib.sha256(image).hexdigest();blob=ctypes.string_at(lib.public_snapshot(),lib.public_bytes())+ctypes.string_at(lib.private_snapshot(),lib.private_bytes())
   if not ix:expected.append(sha);state.append(blob);hashes.append(lib.real_hash())
   else:
    assert blob==state[f],('state',side,n,f,next((i for i,(a,b) in enumerate(zip(blob,state[f])) if a!=b),None))
    assert lib.real_hash()==hashes[f],('replayhash',side,n,f)
    assert sha==expected[f],('pixels',side,n,f,sha,expected[f]);points+=1;pixels+=1280*720
  results.append({'size':side,'N':n,'variant':ix,'frames':frames,'counts':[lib.backend_value(i) for i in range(8)]})
fallback_points=[]
for side,n in [(8,20000),(32,5000)]:
 expected=[];expected_state=[]
 for ix,lib in enumerate(libs):
  ctypes.memset(0x1000000,0xa5,0x1200000);ctypes.memset(0x7000000,0xa5,0x400000);ctypes.memset(0x5ff0000,0xa5,0x90000)
  lib.backend_reset(126 if ix else 30,0,0);lib.prepare(n,side)
  if ix:lib.backend_inject(1)
  for f in range(2):
   lib.frame(f);image=ctypes.string_at(0x1000000+(0x400000 if f&1 else 0),1280*720*4);blob=ctypes.string_at(lib.public_snapshot(),lib.public_bytes())+ctypes.string_at(lib.private_snapshot(),lib.private_bytes())
   if not ix:expected.append(image);expected_state.append(blob)
   else:assert image==expected[f] and blob==expected_state[f],('fallback exact',side,f)
  if ix:assert lib.fallback_acks()==2;fallback_points.append(dict(size=side,N=n,fullframes=2,hardware_hold_acks=lib.fallback_acks()))
faults=[]
for fault in [2,3,4,5,7,8,9,11]:
 child=r"""import ctypes
k=ctypes.WinDLL('kernel32');k.VirtualAlloc.restype=ctypes.c_void_p
for a,s in [(0x1000000,0x1200000),(0x7000000,0x400000),(0x5ff0000,0x90000)]:assert k.VirtualAlloc(ctypes.c_void_p(a),s,0x3000,4)==a
f=ctypes.CDLL(DLL);f.backend_reset(126,1,0);f.prepare(20000,8);f.backend_inject(FAULT);f.frame(0)
""".replace('ctypes.CDLL(DLL)','ctypes.CDLL('+repr(str(O/'candidate.dll'))+')').replace('FAULT',str(fault))
 q=subprocess.run([sys.executable,'-c',child],capture_output=True,text=True);(R/f'fault_{fault}.log').write_text(q.stdout+q.stderr)
 assert q.returncode==90 and 'cpu_replays=0' in q.stderr,(fault,q.returncode,q.stdout,q.stderr)
 faults.append(dict(injection=fault,exit=q.returncode,fatal=q.stderr.strip()))
C=libs[1];ctypes.memset(0x1000000,0xa5,0x1200000);C.backend_reset(126,0,0);C.prepare(20000,8);C.backend_inject(12);C.frame(0);assert C.queued_cli_and_barrier()==1,'menu must defer until R/M/oldRQ drain'
report={'status':'PASS' ,'full_state_points':points,'pixels':pixels,'results':results,'NO_DRAW_fullordered_fallback':fallback_points,'faults_failclosed':faults,'CLI_during_M_deferred_until_safe_barrier':True,'scope':'True game render/runtime plus real scene/driver and actual-mapped DMA; native APB model; not RTL or physical timing'}
report['baseline_root']=str(B);report['baseline_src_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((B/'src').glob('*')) if p.is_file()};report['source_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((P/'src').glob('*')) if p.is_file()};(O/'source_seal.json').write_text(json.dumps(report['source_sha256'],indent=2));(R/'summary.json').write_text(json.dumps(report,indent=2));print('PIPE5 PASS',points,'fullstate/pixel frames',pixels,flush=True)


