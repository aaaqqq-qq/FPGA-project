"""Exercise production telemetry snapshot with a deliberately torn first read."""
from pathlib import Path
import argparse,json,os,re,shlex,subprocess,sys
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=ap.parse_args()
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)];B=R/'build/telemetry_counters';B.mkdir(parents=True,exist_ok=True)
production=(R/'src/game.c').read_text(encoding='utf-8-sig')
format_literal=re.search(r'txlen=textfmt\(tx,sizeof\(tx\),"(STAT [^"\n]+)"',production)[1]
fmt=bytes(format_literal,'ascii').decode('unicode_escape')
assert not re.search(r'%(?!u)',fmt), 'Update the independent format bound for new specifiers'
capacity=int(re.search(r'static char tx\[(\d+)\]',production)[1])
worst_bound=len(fmt.replace('%u',''))+10*fmt.count('%u')+1
assert worst_bound<=capacity,(worst_bound,capacity)
prefix=(R/'tests/phase_gameplay.c').read_text(encoding='utf-8-sig').split('static int failures;',1)[0]
needle='uint32_t bb_read(unsigned reg) { (void)reg; return 0; }';assert needle in prefix
prefix=prefix.replace(needle,'uint32_t bb_read(unsigned reg) { return telemetry_read(reg); }')
for name,args in [('scene_hud_begin','void'),('scene_hud_end','void'),('scene_hud_invalidate','void'),('scene_hud_cache_enable','unsigned enabled')]:
 if ('void '+name+'(') not in prefix:prefix+='\nvoid '+name+'('+args+') {'+('(void)enabled;' if 'enabled' in args else '')+'}\n'
host=B/'telemetry_host.c';host.write_text('#include <stdint.h>\nstatic uint32_t telemetry_read(unsigned reg);\n'+prefix+'\n#include "telemetry_counter_body.h"\n',encoding='utf-8');exe=B/'telemetry_host.exe'
cmd=cc+['-std=gnu11','-O2','-UNDEBUG','-Wno-unused-function','-Wno-unused-parameter','-Wno-misleading-indentation','-Isrc','-Itests/stub','-Itests',str(host),'src/stage.c','src/battle.c','src/player.c', 'src/enemies.c','src/layer_visuals.c','src/effects.c','src/game_config.c','src/font.c','src/replay.c','src/remote_input.c','-o',str(exe)]
p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=60);log=p.stdout+p.stderr;code=p.returncode
if not code:
 p=subprocess.run([str(exe)],cwd=R,capture_output=True,text=True,timeout=60);log+=p.stdout+p.stderr;code=p.returncode
print(log,end='');status='PASS' if not code and 'TELEMETRY PASS' in log else 'FAIL'
(R/'results/telemetry_counter_test.json').write_text(json.dumps({'status':status,'hardware_accessed':False,'command':cmd,'exit_code':code,'output':log,'independent_max_uint_format_bound_including_NUL':worst_bound,'tx_capacity':capacity},indent=2),encoding='utf-8')
raise SystemExit(0 if status=='PASS' else 1)
