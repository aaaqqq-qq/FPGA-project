"""Extract a small, auditable TH06 spell; do not invent an ECL replacement.
ANM rectangles and ECL instruction layouts are validated before conversion.
Original source files are never modified. Generated ROM uses palette indices.
"""
from pathlib import Path
import os
import struct, json, hashlib, math
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'assets/source'
src=DATA/'th06e_ST.DAT__ecldata1.ecl'
d=src.read_bytes()
subcount=struct.unpack_from('<H',d)[0]
offsets=struct.unpack_from('<%dI'%subcount,d,16)
start,end=offsets[22:24]
formats={2:'ii',3:'iii',4:'ii',5:'if',20:'iff',47:'f',50:'ff',57:'ifff',61:'i',67:'hh iiff ffi'.replace(' ',''),105:'i',112:'i',115:'i'}
meta={93:'spell title',106:'sound (no audio hardware)',112:'HP callback (practice scene)',115:'timeout handled by scene'}
manifest={'source':str(src),'sha256':hashlib.sha256(d).hexdigest(),'subroutine':22,'spell':'Night Sign: Night Bird','difficulty':'Normal','timeout_frames':1500,'omitted_presentation':meta,'assets':[]}
instructions=[]
for rank in [2,4,8]:
 a=start;raw=[]
 while a<end:
  t,op,size,mask,pm=struct.unpack_from('<i4H',d,a)
  if t==-1:break
  assert size>=12 and a+size<=end
  payload=d[a+12:a+size]
  if (mask>>8)&rank:
   assert op in formats or op in meta,(a,op)
   if op in formats and op not in meta:
    fmt=formats[op];args=list(struct.unpack('<'+fmt,payload))
    args=[int(round(v*65536)) if k=='f' else v for k,v in zip(fmt,args)]
    raw.append([a-start,t,op,args])
  a+=size
 for off,t,op,args in raw:
  if op in (2,3):
   dest=off+args[1];args[1]=next(i for i,r in enumerate(raw) if r[0]>=dest)
 instructions.append(raw)

def carray(name,values,ctype,cols=16):
 return 'static const %s %s[%d] = {\n%s\n};\n'%(ctype,name,len(values),'\n'.join(','.join(str(x)for x in values[i:i+cols])+','for i in range(0,len(values),cols)))
text='#pragma once\n#include <stdint.h>\ntypedef struct { int16_t time,op; int32_t arg[9]; } EclOp;\n'
text+='#define ECL_OP_COUNT 37u\n#define SPAWN_FRAMES 16u\n'
for rank,rows in zip(['normal','hard','lunatic'],instructions):
 text+='static const EclOp ecl_'+rank+'[] = {\n'
 for off,t,op,args in rows:text+='{%d,%d,{%s}}, /* original +%d */\n'%(t,op,','.join(map(str,args)),off)
 text+='};\n'
text+=carray('sin_lut',[round(math.sin(i*math.tau/1024)*32767)for i in range(1024)],'int16_t')
text+=carray('atan_lut',[round(math.atan(i/256)*65536/math.tau)for i in range(257)],'uint16_t')
(ROOT/'src/stage_data.h').write_text(text)

tiles=[]
def load_tile(name,sid,label):
 p=DATA/(name+'.anm');b=p.read_bytes();n=struct.unpack_from('<I',b)[0]
 rects=[struct.unpack_from('<I4f',b,a) for a in struct.unpack_from('<%dI'%n,b,64)]
 rect=next(r for r in rects if r[0]==sid);_,x,y,w,h=rect;x,y,w,h=map(int,(x,y,w,h))
 im=Image.open(DATA/(name+'.png')).convert('RGB');alpha=Image.open(DATA/(name+'_a.png')).convert('L')
 assert x>=0 and y>=0 and x+w<=im.width and y+h<=im.height
 tile=im.crop((x,y,x+w,y+h));mask=alpha.crop((x,y,x+w,y+h))
 # Use the separate original alpha plane, never the sheet background colour.
 tiles.append((label,tile,mask))
 manifest['assets'].append({'file':name,'sprite':sid,'rect':[x,y,w,h],'png_sha256':hashlib.sha256((DATA/(name+'.png')).read_bytes()).hexdigest()})
for i in range(4):load_tile('th06e_CM.DAT__player00',i,'REIMU'+str(i))
for i in range(4):load_tile('th06e_ST.DAT__stg1enm2',128+i,'RUMIA'+str(i))
for i in range(16):load_tile('th06e_CM.DAT__etama3',30+i,'BALL'+str(i))
for i in range(16):load_tile('th06e_CM.DAT__etama3',14+i,'SMALL'+str(i))
load_tile('th06e_CM.DAT__player00',64,'SHOT')
# Extra original character assets; existing tile IDs stay stable.
for i in range(6):load_tile('th06e_ST.DAT__stg2enm2',128+i,'CIRNO'+str(i))
for i in range(3):load_tile('th06e_ST.DAT__stg3enm',41+i,'MEILING'+str(i))
for i in [65,66,67,68]:load_tile('th06e_CM.DAT__player00',i,'REIMU_SHOT'+str(i))
# Dedicated battle materials retain original colours and silhouettes, resampled
# to the requested 8x8 enemy size. The stress atlas at 24..39 is untouched.
material_pairs=[(1,c)for c in [5,6,7,8]]+[(5,c)for c in [2,4,6,8,10,11,13,14]]
for typ,col in material_pairs+[(5,6)]*4:
 load_tile('th06e_CM.DAT__etama3',(30 if typ==1 else 94)+col,'BATTLE')
 label,im,mask=tiles[-1];tiles[-1]=(label,im.resize((8,8),Image.Resampling.NEAREST),mask.resize((8,8),Image.Resampling.NEAREST))
# Shared 255-colour palette plus exact transparent key, compact in instruction RAM.
strip=Image.new('RGB',(256,1024));pos=0
for _,im,mask in tiles:
 for rgb,a in zip(im.getdata(),mask.getdata()):
  if a>=48:strip.putpixel((pos%256,pos//256),rgb);pos+=1
pal=strip.quantize(colors=255,method=Image.Quantize.MEDIANCUT)
palette=pal.getpalette()[:765];palette=[0xff00ff]+[(palette[i]<<16)|(palette[i+1]<<8)|palette[i+2] for i in range(0,len(palette),3)]
packed=[];desc=[];off=0;atlas=Image.new('RGB',(768,640),(16,18,38))
for i,(label,im,mask) in enumerate(tiles):
 q=im.quantize(palette=pal,dither=Image.Dither.NONE);indices=[v+1 if a>=48 else 0 for v,a in zip(q.getdata(),mask.getdata())];desc.append((off,im.width,im.height));off+=im.width*im.height*4;packed+=indices
 preview=Image.new('RGB',im.size);preview.putdata([((palette[v]>>16)&255,(palette[v]>>8)&255,palette[v]&255)if v else (16,18,38)for v in indices]);atlas.paste(preview,(i%12*64,i//12*80))
# --- Generated effect atlas -------------------------------------------------
# These tiles are appended after the 70 original tiles, so IDs 0..69 and the
# contiguous 8x8 battle-material block 54..69 remain byte-for-byte stable.
# They use the already-quantised palette and are therefore not part of the
# palette training strip: adding effects cannot recolor the original sprites.
effect_dir=ROOT/'assets/generated/effects';effect_dir.mkdir(parents=True,exist_ok=True)
manifest['effects']=[]
base_tiles=len(tiles);assert base_tiles==70,base_tiles
effect_labels=[]

def append_effect(label,im,mask,force_index=None):
 global off
 effect_labels.append(label)
 im=im.convert('RGB');mask=mask.convert('L')
 im.save(effect_dir/(label+'.png'));mask.save(effect_dir/(label+'_a.png'))
 if force_index is None:
  q=im.quantize(palette=pal,dither=Image.Dither.NONE)
  indices=[v+1 if a>=48 else 0 for v,a in zip(q.getdata(),mask.getdata())]
 else:
  indices=[force_index if a>=48 else 0 for a in mask.getdata()]
 desc.append((off,im.width,im.height));packed.extend(indices)
 manifest['effects'].append({'tile':len(desc)-1,'label':label,'w':im.width,'h':im.height,
  'png':str((effect_dir/(label+'.png')).relative_to(ROOT)).replace('\\','/'),
  'alpha':str((effect_dir/(label+'_a.png')).relative_to(ROOT)).replace('\\','/')})
 off+=im.width*im.height*4

def make_ring(size,color,width=2):
 im=Image.new('RGB',(size,size),color);mask=Image.new('L',(size,size),0)
 d=ImageDraw.Draw(mask);m=2
 d.ellipse((m,m,size-1-m,size-1-m),outline=255,width=width)
 if size>=32:m2=m+5;d.ellipse((m2,m2,size-1-m2,size-1-m2),outline=110,width=1)
 return im,mask

def make_star(size,color):
 im=Image.new('RGB',(size,size),color);mask=Image.new('L',(size,size),0)
 d=ImageDraw.Draw(mask);c=size//2;r=size-2
 d.polygon([(c,1),(c+r//4,c-r//4),(size-2,c),(c+r//4,c+r//4),(c,size-2),(c-r//4,c+r//4),(1,c),(c-r//4,c-r//4)],fill=255)
 return im,mask

def make_plus(size,color):
 im=Image.new('RGB',(size,size),color);mask=Image.new('L',(size,size),0)
 d=ImageDraw.Draw(mask);t=size//4;c=size//2
 d.rectangle((c-t,1,c+t,size-2),fill=255);d.rectangle((1,c-t,size-2,c+t),fill=255)
 return im,mask

ROSE=(0xeb,0x85,0x9a);GOLD=(0xf5,0xcf,0x77);CYAN=(0x80,0xcf,0xff);GREEN=(0x80,0xd8,0x9b)
for i in range(4):
 _,im,mask=tiles[i]
 append_effect('white_player%d'%i,Image.new('RGB',im.size,(255,255,255)),mask,force_index=1)
append_effect('ring_warn64',*make_ring(64,ROSE,3))
append_effect('ring_gold64',*make_ring(64,GOLD,2))
append_effect('ring_cyan64',*make_ring(64,CYAN,2))
append_effect('ring_green32',*make_ring(32,GREEN,2))
append_effect('star16',*make_star(16,GOLD))
append_effect('plus16',*make_plus(16,GREEN))
append_effect('ring_rose32',*make_ring(32,ROSE,2))
append_effect('ring_gold32',*make_ring(32,GOLD,2))
append_effect('ring_cyan32',*make_ring(32,CYAN,2))
assert len(desc)==83,(len(desc),'art_ids.h expects 83 tiles')
manifest['effect_count']=len(manifest['effects'])
(ROOT/'assets/generated/effects_manifest.json').write_text(json.dumps(manifest['effects'],indent=2),encoding='utf8')
ids=['#pragma once',
     '/* Generated by scripts/prepare_stage.py; do not hand-edit. */',
     '/* IDs appended after the original 70 tiles. 54..69 remain the 8x8 DMA block. */',
     'enum {']
for i,label in enumerate(effect_labels):
 ids.append('    ART_%s = %d,'%(label.upper(),base_tiles+i))
ids.append('    ART_TILE_COUNT = %d'%(base_tiles+len(effect_labels)))
ids.append('};')
(ROOT/'src/art_ids.h').write_text('\n'.join(ids)+'\n')

text='#pragma once\n'+carray('art_palette',palette,'uint32_t')+carray('art_pixels',packed,'uint8_t')
text+='typedef struct { uint32_t off; uint16_t w,h; } Tile;\nstatic const Tile tiles[] = {\n'+''.join('{%d,%d,%d},\n'%v for v in desc)+'};\n'
text+='#define ART_BASE 0x01800000u\n#define ART_BYTES %du\n'%off
(ROOT/'src/art_data.h').write_text(text);atlas.save(ROOT/'research/extracted_atlas.png')
manifest['palette_bytes']=len(palette)*4;manifest['rom_pixel_bytes']=len(packed);manifest['ddr_tile_bytes']=off
(ROOT/'results/extraction.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf8')
print('base spell ops',list(map(len,instructions)),'base art ROM',len(packed)+1024,'base DDR',off,'base tiles',len(desc))

# Original ANM fairies are appended only after the unchanged83-tile base.
from append_original_enemies import append_original_enemies
append_original_enemies(ROOT,load_tile)
