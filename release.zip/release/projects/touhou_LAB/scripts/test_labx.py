"""Compile/run actual LAB23 experiments with real driver and independent DMA model."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess,time
p=argparse.ArgumentParser();p.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=p.parse_args()
r=Path(__file__).resolve().parents[1];b=r/'build/labx_host';b.mkdir(parents=True,exist_ok=True)
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
flags=['-std=c99','-O2','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-DBB_HOST_TEST','-Isrc']
commands=[cc+flags+['-Dbb_cpu_execute=host_cpu_execute','-c','src/labx.c','-o',str(b/'labx.o')],cc+flags+['src/bitblt.c','src/pixels.c','src/font.c','tests/labx_host.c',str(b/'labx.o'),'-o',str(b/'labx_host.exe')]+(['-Wl,--image-base,0x180000000'] if os.name=='nt' else [])]
start=time.monotonic();outputs=[];passed=True
for command in commands+[[str(b/'labx_host.exe')]]:
    proc=subprocess.run(command,cwd=r,capture_output=True,text=True,timeout=180)
    log=proc.stdout+proc.stderr;print(log,end='');outputs.append({'command':command,'exit':proc.returncode,'output':log})
    if proc.returncode:passed=False;break
passed=passed and 'ALL_LABX_PASS' in outputs[-1]['output']
report={'status':'PASS' if passed else 'FAIL','hardware':'NOT_RUN','scope':'actual labx.c, production bitblt.c CPU/submit/wait, independent bounded DMA+display model','elapsed_seconds':round(time.monotonic()-start,3),'runs':outputs,'source_sha256':{n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in ['src/labx.c','src/labx.h','src/game.c','src/bitblt.c']}}
(r/'results/labx_host.json').write_text(json.dumps(report,indent=2),encoding='utf8')
raise SystemExit(0 if passed else 1)
