from pathlib import Path
import os,subprocess,json,hashlib,argparse
P=Path(__file__).resolve().parents[1];O=P/'build/preflight_driver';O.mkdir(parents=True,exist_ok=True)
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default='E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe');a=ap.parse_args()
s=(P/'src/scene.c').read_text().replace('#include "stage.h"','#include "stage.h"\n#define stage (*(Stage *)(uintptr_t)0x02100000u)\nextern unsigned inside_calls;')
s=s.replace('static unsigned batch32_inside(void){','static unsigned batch32_inside(void){++inside_calls;')
(O/'scene_mapped.c').write_text(s,encoding='utf8')
exe=O/'driver.exe';cmd=[a.host_cc,'-Wl,--image-base,0x140000000','-std=gnu11','-O2','-UNDEBUG','-DBB_HOST_TEST','-I'+str(P/'src'),str(P/'tests/preflight_driver/host.c'),str(O/'scene_mapped.c'),*[str(P/'src'/n) for n in ['render_queue.c','background.c','font.c','pixels.c','game_config.c']],'-o',str(exe)]
q=subprocess.run(cmd,capture_output=True,text=True);(O/'compile.log').write_text(q.stdout+q.stderr,encoding='utf8');assert not q.returncode,q.stderr
cases={}
for name,extra,code,marker in [('cap30',{},0,'PREFLIGHT_SCAN_PROOF cap=30 inside_calls=0'),('cap6',{'PREFLIGHT_CAP6':'1'},0,'PREFLIGHT_SCAN_PROOF cap=6 inside_calls='),('bus_error',{'PREFLIGHT_FAULT':'1'},2,'PREFLIGHT ENGINE'),('missing_result',{'PREFLIGHT_FAULT':'2'},2,'PREFLIGHT MISSING RESULT'),('timeout',{'PREFLIGHT_FAULT':'3'},2,'PREFLIGHT TIMEOUT')]:
 env=os.environ.copy();env.update(extra);q=subprocess.run([str(exe)],env=env,capture_output=True,text=True)
 (O/(name+'.log')).write_text(q.stdout+q.stderr,encoding='utf8');assert q.returncode==code and marker in q.stdout+q.stderr,(name,q.returncode,q.stdout,q.stderr)
 if not code:assert 'EXTERNAL_MMIO_CACHE restored_same_fill=1 pixels=64' in q.stdout
 cases[name]={'status':'PASS','exit':q.returncode,'log_sha256':hashlib.sha256((O/(name+'.log')).read_bytes()).hexdigest()};print(name,'PASS',q.stdout[-220:],q.stderr[-80:],flush=True)
report={'status':'PASS','cases':cases,'full_frames_per_cap':195,'pixels_per_cap':179712000,'total_exact_pixels':359424000,'new_cap_inside_scan_calls':0,'old_cap_uses_old_checked_path':True,'external_MMIO_same_fill_cache_restored':True,'source_sha256':{str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [P/'src/scene.c',P/'tests/preflight_driver/host.c']},'hardware_accessed':False,'scope':'Actual candidate scene driver, independent original-art full-frame golden, delayed snapshot/NO_DRAW; explicit external OP3 shadow clobber + exact same FILL restoration. Not physical cycles/FPS.'}
(P/'results/preflight_driver.json').write_text(json.dumps(report,indent=2),encoding='utf8')
