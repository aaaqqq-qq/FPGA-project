from pathlib import Path
import re,json,hashlib
r=Path(__file__).resolve().parents[1];o=r/'hw/game/par/ddr_demo_ti60/outflow'
t=(o/'ddr_demo_ti60.timing.rpt').read_text();s=t.split('Setup (Max) Clock Relationship',1)[1].split('NOTE: Values',1)[0]
rows=[];kind='setup'
for line in s.splitlines():
 if line.startswith('Hold (Min)'):kind='hold'
 m=re.match(r'^\s*(\S+)\s+(\S+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+\(([RF]-[RF])\)',line)
 if m:rows.append({'kind':kind,'launch':m[1],'capture':m[2],'slack_ns':float(m[4])})
log=(o/'ddr_demo_ti60.log').read_text(errors='replace')
warnings=[x for x in log.splitlines() if any(s in x for s in ['No cells matched','No ports matched','No pins matched'])]
bit=o/'ddr_demo_ti60.bit'
passed=bool(rows) and all(a['slack_ns']>=0 for a in rows) and not warnings and 'Stage completed: pgm' in log and bit.stat().st_mtime >= (o/'ddr_demo_ti60.timing.rpt').stat().st_mtime
report={'relationships':rows,'empty_sdc':warnings,'pass':passed,'bit_sha256':hashlib.sha256(bit.read_bytes()).hexdigest(),'source_hashes':{str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest()for p in (r/'hw').rglob('*')if p.is_file() and p.suffix in ('.v','.sv','.vh','.xml','.sdc')and 'outflow' not in p.parts and 'work_syn'not in p.parts}}
(r/'results/timing.json').write_text(json.dumps(report,indent=2))
print('PASS' if passed else 'FAIL','setup',min(x['slack_ns']for x in rows if x['kind']=='setup'),'hold',min(x['slack_ns']for x in rows if x['kind']=='hold'),'empty SDC',warnings)
raise SystemExit(not passed)
