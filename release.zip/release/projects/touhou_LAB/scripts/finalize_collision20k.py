from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parents[1]
names=['collision20k_stationary_long','collision20k_moving_long','collision20k_hud_pixels','collision20k_hud_threeboss','collision20k_hud_cpu_input']
data={n:json.loads((r/'results'/f'{n}.json').read_text()) for n in names}
elf=hashlib.sha256((r/'build/rumia.elf').read_bytes()).hexdigest()
bit=hashlib.sha256((r/'hw/game/par/ddr_demo_ti60/outflow/ddr_demo_ti60.bit').read_bytes()).hexdigest()
for name,d in data.items():
 assert d['elf_sha256']==elf and d['bit_sha256']==bit,name
 if 'runs' in d:assert all(x['passed_60fps'] for x in d['runs']),name
 elif name.endswith('cpu_input'):assert d['responsive'],name
 else:assert d['passed'],name
health=[w for w in data['collision20k_hud_threeboss']['windows'] if w.get('mode')==1]
for k in range(3):
 values=[w[f'boss{k}'] for w in health]
 assert values and all(0<=v<=3000 for v in values)
 assert all(b<=a for a,b in zip(values,values[1:])),('boss HP increased',k,values)
assert any(health[-1][f'boss{k}']<health[0][f'boss{k}'] for k in range(3))
moving=data['collision20k_moving_long']['runs'][0]
assert len({w['px'] for w in moving['windows']})>10
runs=[data[n]['runs'][0] for n in names[:2]]
summary={'elf_sha256':elf,'bit_sha256':bit,'passed':True,'capacity':20000,'target_hz':60,'flash_written':False,'collision_runs':[],'boss_health':'independent 3000 HP; no resurrection even with player immunity; sidebar only'}
for n,d in zip(names,runs):
 w=d['windows'][1:]
 summary['collision_runs'].append({'test':n,'measured_us':d['measured_us'],'steady_windows':len(w),'frames':sum(x['swaps'] for x in w),'missed':sum(x['missed'] for x in w),'underflows':sum(x['uf'] for x in w),'peak_frame_us':d['steady_peak_us'],'min_fps100':min(x['fps100'] for x in w),'max_fps100':max(x['fps100'] for x in w)})
(r/'results/collision20k_final_summary.json').write_text(json.dumps(summary,indent=2))
report=r"""固定 20000 精灵：碰撞模式60FPS与三Boss血条修复（2026-10-27）
工程：D:\FPGA\hdmi_rumia_ultimate
保留的三Boss基线：D:\桌面\60FPS3BOSS（未覆盖）

本次修复：
- 固定20000精灵，不增加数量。通过分支布局优化减少CPU热循环停顿，撤回收益为负的循环展开和合并速度读取试验。
- 每一帧仍执行全部20000弹丸的运动、碰撞候选和精确碰撞/擦弹判断；未减小数量、跳过物理帧或改动统计阈值。
- 无敌仅保护主角；Boss击破不再恢复3000HP。普通模式三Boss全灭获胜，无敌模式不强制结束，等待用户返回菜单。
- 侧边栏分别显示RUMIA、CIRNO、HONG MEILING的名字、血条和独立剩余HP；击破显示DEFEATED。游戏顶部不再显示Boss合计血条。DODGE保留顶部挑战计时条。

性能验证（实际完成的DDR换帧数，非仅HDMI扫描频率）：
"""
for d in summary['collision_runs']:
 report+=f"{d['test']}: {d['measured_us']/1e6:.3f} seconds, {d['frames']} swaps, missed={d['missed']}, underflow={d['underflows']}, peak={d['peak_frame_us']/1000:.3f}ms."+chr(10)
report+="""
统计显示59.99~60.00属于微秒计时和整数截断；通过条件还要求每个稳定窗口scan==swaps、漏帧0、欠流0，旧版59.5的实际漏帧不再出现。
上述为有限时长的固定负载验证，不承诺任意人为构造的极端精灵重叠都满足同一帧率。
启动/切换模式需初始化双缓冲，首个混合窗口单独保留，不计入稳态成绩。
长测使用免伤保持连续运行，运动、碰撞距离和擦弹仍每帧计算；伤害/三次碰撞失败/无敌/超时/独立Boss击破由实际game.c主机回归覆盖。

其他验证：
- 三Boss Lunatic自然弹幕65秒60FPS验证通过，自然关卡不强制填满20000。
- CPU/FPGA实际DDR像素比较6帧，每帧739872像素（含侧边血条区域），错误0。
- 48帧完整画面与全背景重画逐像素一致，覆盖三条血条缩短、归零、模式切换和文字清除。
- 碰撞候选1000次全扫描对照，无漏选；超过512候选退回完整检查。
- CPU低帧模式菜单响应测试通过。CPU基准用于赛题软件/硬件对比，不承诺60FPS。

赛题路径保留：RISC-V游戏运动/碰撞，AXI4 Copy/Fill，Burst/FIFO，Alpha224和FF00FF颜色键同时开启，DDR材质->DDR双缓冲->HDMI。未改硬件、时钟或约束，既有setup0.260ns/hold0.026ns仍有效。
本次仅JTAG易失性下载，无Flash擦写；断电仍恢复原Flash程序。90Hz分支保持暂停，不属于本次通过版本。
运行 START_720P_JTAG_ONLY.cmd 可再次临时下载。

操作：SW0左/SW1右/SW2上/SW3下；按住SW2+SW3约0.6秒返回菜单。
菜单SW0/1选数量，SW2选模式，SW3开始；SW0+SW1切换主角无敌。
普通可玩关卡200秒，无敌关卡不限时。血条归零不会因无敌而回血；重新开始才重置Boss。

完整结果：results/collision20k_final_summary.json及collision20k_*.json。
旧fixed20k_dodge.json是修复前未通过记录，保留作为对照，不代表当前固件。
"""
report+=chr(10)+'ELF SHA256: '+elf+chr(10)+'BIT SHA256: '+bit+chr(10)
p=r/'固定20000精灵_验证说明.txt'
old=r/'reference/fixed20k_before_collision_hud/修复前验证说明.txt'
if not old.exists():old.write_bytes(p.read_bytes())
p.write_text(report,encoding='utf-8-sig')
print(json.dumps(summary,indent=2))
