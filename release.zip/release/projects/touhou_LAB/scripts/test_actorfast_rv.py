"""Count actual RV32 ELF instructions for bounded CPU-only paths.

Instruction stepping has zero modeled latency and no DDR/APB/cache/branch
timing. It establishes executed-instruction counts, never milliseconds/FPS.
"""
from pathlib import Path
from datetime import datetime
import hashlib,json,re,struct,subprocess
P=Path(__file__).resolve().parents[1];B=P.parent/'game60_pipe5_reportoverlap_fw_20261103'
O=P/'results/actorfast_rv'/datetime.now().strftime('%Y%m%d_%H%M%S_%f');O.mkdir(parents=True)
T=Path('D:/ELSFPGARSIC-V/toolchain/bin');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
U=lambda n:n&0xffffffff
S=lambda n:n-0x100000000 if n&0x80000000 else n
def sx(n,b):return n-(1<<b)if n&(1<<(b-1))else n

class Elf:
 def __init__(self,path,label):
  self.path=path;raw=path.read_bytes();self.memory=bytearray(0x110000)
  header=struct.unpack_from('<16sHHIIIIIHHHHHH',raw)
  for i in range(header[10]):
   typ,off,va,pa,fs,ms,flags,align=struct.unpack_from('<8I',raw,header[5]+i*header[9])
   if typ==1:self.memory[pa:pa+fs]=raw[off:off+fs]
  nm=subprocess.run([str(T/'riscv-none-elf-nm.exe'),'-a',str(path)],capture_output=True,check=True)
  (O/(label+'.nm.raw.log')).write_bytes(nm.stdout);self.symbol={}
  for line in nm.stdout.decode().splitlines():
   m=re.fullmatch(r'([0-9a-fA-F]+)\s+\w\s+(.+)',line)
   if m:self.symbol.setdefault(m[2],[]).append(int(m[1],16))
  self.refs={}
  for name in ('execute.part.0','scene_tile','scene_rect','clipped_bounds'):
   q=subprocess.run([str(T/'riscv-none-elf-objdump.exe'),'-d','--disassemble='+name,str(path)],capture_output=True,check=True)
   (O/(label+'.'+name+'.objdump.log')).write_bytes(q.stdout)
   refs={name:int(addr,16)for addr,name in re.findall(r'# ([0-9a-f]+) <([^>]+)>',q.stdout.decode())}
   self.refs[name]=refs

 def run(self,name,initial,arguments,stop=None):
  mem=self.memory[:];extra={};regs=[0]*32;regs[1]=0xdeadbeec;regs[2]=0x02000000;regs[3]=self.symbol['__global_pointer$'][0]
  def write(a,v,n=4):
   a=U(a)
   if a+n<=len(mem):mem[a:a+n]=U(v).to_bytes(4,'little')[:n]
   else:
    for k in range(n):extra[a+k]=(v>>(8*k))&255
  def read(a,n=4):
   a=U(a)
   if a+n<=len(mem):return int.from_bytes(mem[a:a+n],'little')
   return sum(extra.get(a+k,0)<<(8*k)for k in range(n))
  for key,value in initial.items():
   address=key if isinstance(key,int)else self.refs.get(name,{}).get(key,self.symbol[key][-1])
   write(address,value)
  for i,v in enumerate(arguments):
   if i<8:regs[10+i]=U(v)
   else:write(regs[2]+(i-8)*4,v)
  pc=self.symbol[name][0];steps=0;mmio=[]
  while pc!=0xdeadbeec and pc!=stop:
   assert steps<20000,(name,hex(pc));steps+=1;ins=read(pc);op=ins&127;rd=(ins>>7)&31;f3=(ins>>12)&7;rs1=(ins>>15)&31;rs2=(ins>>20)&31;f7=ins>>25
   a,b=regs[rs1],regs[rs2];nextpc=pc+4;value=None
   if op==0x37:value=ins&0xfffff000
   elif op==0x17:value=pc+(ins&0xfffff000)
   elif op==0x6f:
    imm=((ins>>31)<<20)|(((ins>>12)&255)<<12)|(((ins>>20)&1)<<11)|(((ins>>21)&1023)<<1)
    value=pc+4;nextpc=pc+sx(imm,21)
   elif op==0x67:value=pc+4;nextpc=(a+sx(ins>>20,12))&~1
   elif op==0x63:
    imm=((ins>>31)<<12)|(((ins>>7)&1)<<11)|(((ins>>25)&63)<<5)|(((ins>>8)&15)<<1)
    cond={0:a==b,1:a!=b,4:S(a)<S(b),5:S(a)>=S(b),6:a<b,7:a>=b}[f3]
    if cond:nextpc=pc+sx(imm,13)
   elif op==0x03:
    address=U(a+sx(ins>>20,12));n={0:1,1:2,2:4,4:1,5:2}[f3];value=read(address,n)
    if f3<2:value=sx(value,n*8)
    if address>=0xf8000000:mmio.append(('read',address,U(value)))
   elif op==0x23:
    address=U(a+sx(((ins>>25)<<5)|((ins>>7)&31),12));n={0:1,1:2,2:4}[f3];write(address,b,n)
    if address>=0xf8000000:mmio.append(('write',address,b))
   elif op==0x13:
    imm=sx(ins>>20,12)
    if f3==0:value=a+imm
    elif f3==1:value=a<<((ins>>20)&31)
    elif f3==2:value=int(S(a)<imm)
    elif f3==3:value=int(a<U(imm))
    elif f3==4:value=a^U(imm)
    elif f3==5:value=(S(a)if f7==32 else a)>>((ins>>20)&31)
    elif f3==6:value=a|U(imm)
    elif f3==7:value=a&U(imm)
   elif op==0x33:
    if f7==1:
     if f3==0:value=a*b
     elif f3==1:value=(S(a)*S(b))>>32
     elif f3==2:value=(S(a)*b)>>32
     elif f3==3:value=(a*b)>>32
     else:raise AssertionError(('unneededM',hex(pc),hex(ins)))
    elif f3==0:value=a-b if f7==32 else a+b
    elif f3==1:value=a<<(b&31)
    elif f3==2:value=int(S(a)<S(b))
    elif f3==3:value=int(a<b)
    elif f3==4:value=a^b
    elif f3==5:value=(S(a)if f7==32 else a)>>(b&31)
    elif f3==6:value=a|b
    elif f3==7:value=a&b
   elif op==0x0f:pass
   else:raise AssertionError(('unsupported',hex(pc),hex(ins)))
   if value is not None and rd:regs[rd]=U(value)
   regs[0]=0;pc=U(nextpc)
  return steps,mmio,'return'if pc==0xdeadbeec else 'rq_push'

try:
 images=[Elf(root/'build/rumia.elf',name)for name,root in [('golden',B),('candidate',P)]]
 engine=[]
 for valid in (0,1):
  counts=[[],[]]
  for mask in range(2048):
   traces=[]
   for k,e in enumerate(images):
    initial={'hud_dma_active':0,'hardware':1,'pending_job':0,'cache_valid':valid}
    for field in range(11):
     old=field*0x345+3 if field else 0
     initial[e.symbol['previous'][-1]+4*field]=old
     initial[0x2100000+4*field]=old+((mask>>field)&1)
    steps,trace,why=e.run('execute.part.0',initial,[0x2100000]);assert why=='return'
    counts[k].append(steps);traces.append(trace)
   assert traces[0]==traces[1],(valid,mask)
  engine.append(dict(cache_valid=valid,cases=2048,baseline_min=min(counts[0]),baseline_max=max(counts[0]),candidate_min=min(counts[1]),candidate_max=max(counts[1]),baseline_mean=sum(counts[0])/2048,candidate_mean=sum(counts[1])/2048,
                     no_change=[counts[0][0],counts[1][0]],dst_only=[counts[0][4],counts[1][4]],all_change=[counts[0][-1],counts[1][-1]],all_masks_instruction_delta=[b-a for a,b in zip(*counts)]))
 capture=[]
 for function,coords in [('scene_tile',(100,100,54,224)),('scene_tile',(33,17,54,224)),('scene_tile',(1053,700,54,224)),('scene_rect',(100,100,32,32,0xffffff)),('scene_rect',(33,17,8,8,0xffffff)),('scene_rect',(1053,700,32,32,0xffffff))]:
  points=[]
  for e in images:
   initial=dict(layer_capture=1,current_layer=4,current_depth=0,clip_left=32,clip_top=16,clip_right=1056,clip_bottom=704)
   points.append(e.run(function,initial,coords,e.symbol['rq_push'][0]))
  assert points[0][2]==points[1][2]
  capture.append(dict(function=function,arguments=coords,baseline_instructions=points[0][0],candidate_instructions=points[1][0],stop=points[0][2]))
 report=dict(status='ACTUAL_RV32_ELF_INSTRUCTION_PATHS_COUNTED',ELFs=[dict(path=str(e.path),sha256=H(e.path))for e in images],
             source_sha256={'src/scene.c':H(P/'src/scene.c')},engine=engine,capture=capture,hardware_accessed=False,physical_FPS='NOT_RUN',
             limits=['Tiny RV32I/M instruction interpreter counts only, no cycle or timing model.','Engine cases have pending_job0 and op0/1; separate native4102 covers pending/op2/fault/fence exactness.','Capture comparison stops before actual rq_push, retaining current stack/call/clipping costs but excluding its unchanged44B copy.','No DDR/APB/cache/branch latency modeled; no milliseconds or FPS inference.'])
 (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='engine'},indent=2));print([{k:v for k,v in x.items()if k!='all_masks_instruction_delta'}for x in engine])
except BaseException as error:
 (O/'FAILURE.json').write_text(json.dumps(dict(status='TOOL_OR_CANDIDATE_FAIL_PRESERVED',error=repr(error)),indent=2)+'\n');raise
