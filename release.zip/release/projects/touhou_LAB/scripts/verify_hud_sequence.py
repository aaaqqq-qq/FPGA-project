"""Adversarial changed-length painter-order HUD pixel comparisons."""
import random
import verify_hud_delta as test

original_cases=test.cases
def cases():
    out=original_cases()
    rng=random.Random(0x2865EA)
    commands=[test.rect(1078,252,186,8,0x383143),
              test.text(1078,240,'NEXT 100'),test.text(1078,286,'ACTORS 19 DRAWN 20000'),
              test.rect(1078,178,186,10,0x383143),test.rect(1078,178,93,10,0xffffff),
              test.text(1078,192,'HP 100/100'),test.text(1078,224,'LV 1',scale=2)]
    for frame in range(400):
        c=list(commands)
        if frame%3:c.insert(1,test.rect(1078,252,frame%187,8))
        if frame%4==0:c.insert(4,test.rect(1100,178,30,10,0x7a4050))
        if frame%5==0:c[2:2]=[test.text(1078,240,'NEXT 100')]*2
        if frame%7==0:c.reverse()
        for _ in range(rng.randrange(1,6)):
            op=rng.randrange(6)
            if op==0 and c:del c[rng.randrange(len(c))]
            elif op==1 and c:c.insert(rng.randrange(len(c)+1),rng.choice(c))
            elif op==2 and len(c)>1:
                a,b=rng.sample(range(len(c)),2);c[a],c[b]=c[b],c[a]
            elif op==3:c.insert(rng.randrange(len(c)+1),test.rect(1078+rng.randrange(100),178+8*rng.randrange(12),rng.randrange(1,100),rng.randrange(1,20),rng.getrandbits(32)))
            elif op==4:c.insert(rng.randrange(len(c)+1),test.text(1078+rng.randrange(10),180+rng.randrange(100),str(rng.randrange(100000)),rng.getrandbits(32),rng.randrange(1,5)))
            elif c:
                a=rng.randrange(len(c));v=list(c[a]);v[5]^=0x5a00ff;c[a]=tuple(v)
        i=len(out)
        out.append(dict(label='sequence_edits',commands=c,args=(i,frame%2,1,1,1,8 if frame%2 else 32,20000 if frame%2 else 5000,1)))
    return out
test.cases=cases
if __name__=='__main__':test.main()
