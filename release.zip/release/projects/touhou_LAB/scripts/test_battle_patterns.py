from pathlib import Path
import subprocess,json
R=Path(__file__).resolve().parents[1];out=R/'build/pattern_test';out.mkdir(exist_ok=True)
source=r"""
#include <assert.h>
#include <stdio.h>
#include "battle.c"
int main(void){
 battle_reset(0,4096);Vm v={0};
 OriginalOp fan={0,67,{1,6,5,2,4*65536,2*65536,0,25736,0}};
 fire(0,&v,&fan,bosses[0].x,bosses[0].y+100);
 assert(stage.count==10);int target[]={16384,12288,20480,8192,24576};
 for(unsigned i=0;i<5;i++){int vx=(int)((long long)turn_cos(target[i])*6*Q/32768);int vy=(int)((long long)turn_sin(target[i])*6*Q/32768);assert(stage.shots[i].vx-vx<5&&stage.shots[i].vx-vx>-5&&stage.shots[i].vy-vy<5&&stage.shots[i].vy-vy>-5);}
 battle_reset(0,4096);OriginalOp ring={0,70,{5,6,8,1,3*65536,1*65536,0,0,260}};
 v.ex[0]=60;v.ex[1]=1;v.ex[4]=102944;v.ex[5]=2*65536;
 fire(1,&v,&ring,512,620);assert(stage.count==8);
 for(unsigned k=0;k<3;k++)bosses[k].hp=0;
 for(unsigned f=0;f<16;f++)battle_step(512,620);
 assert(effects[0].turn==60);
 for(unsigned f=0;f<60;f++)battle_step(512,620);
 assert(stage.shots[0].vx>0);battle_step(512,620);
 assert(effects[0].turn==0&&stage.shots[0].vy>0&&stage.shots[0].vx<8&&stage.shots[0].vx>-8);
 puts("PASS: original alternating fan angles, speed layers, and Cirno delayed absolute-angle turn");
}
"""
(out/'test.c').write_text(source);exe=out/'test.exe'
subprocess.run([r'D:\MinGW\mingw-w64\mingw64\bin\gcc.exe','-O2','-Isrc',str(out/'test.c'),'src/stage.c','-o',str(exe)],cwd=R,check=True)
p=subprocess.run([str(exe)],check=True,capture_output=True,text=True);print(p.stdout)
(R/'results/original_battle_patterns.json').write_text(json.dumps({'passed':True,'checks':p.stdout.strip()},indent=2))
