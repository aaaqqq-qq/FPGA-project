#!/usr/bin/env python3
"""Run current src/font.c against the frozen pre-optimization reference."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parents[1]
raise SystemExit(subprocess.run([sys.executable,str(root/'tests/font_equivalence/test_font.py'),*sys.argv[1:]],cwd=root).returncode)
