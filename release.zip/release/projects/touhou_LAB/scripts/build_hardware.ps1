$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\efinity_env.ps1"
New-Item -ItemType Directory -Force -Path "$root/results" | Out-Null
$log=Join-Path $root ('results\hardware_'+(Get-Date -Format yyyyMMdd_HHmmss)+'.log')
Push-Location "$root\hw\game\par\ddr_demo_ti60"
try {
    & "$efinityRoot\python311\bin\python.exe" "$efinityRoot\scripts\efx_run.py" ddr_demo_ti60.xml --flow compile *> $log
    if($LASTEXITCODE -ne 0){throw "FPGA build failed: $log"}
    & "$efinityRoot\python311\bin\python.exe" "$PSScriptRoot\check_hardware.py"
    if($LASTEXITCODE -ne 0){throw 'Routed setup/hold check failed'}
} finally {Pop-Location}
