#!/usr/bin/env python3
"""Read-only bounded R7 board audit; never opens UART or programs hardware."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import argparse,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def parse_time(s):return datetime.fromisoformat(s.replace('Z','+00:00'))
def summary(rows):
 us=sum(x['us'] for x in rows);sw=sum(x['swaps'] for x in rows)
 def ranges(key):return {'min':min((x[key]for x in rows if key in x),default=None),'max':max((x[key]for x in rows if key in x),default=None)}
 cumulative={k:rows[-1][k]-rows[0][k]if len(rows)>1 else None for k in ('ldrop','lover','drops')}
 return {'windows':len(rows),'native_us':us,'completed_swaps':sw,'weighted_fps':sw*1e6/us if us else None,
  'window_delta_sum':{k:sum(x.get(k,0)for x in rows)for k in ('missed','uf','fxdrop')},
  'cumulative_sample_span_deltas':cumulative,
  'N':ranges('N'),'sampled_lastframe_ranges':{k:ranges(k)for k in ('frame','logic','render','qcmd','qclip','qsort','decor','darea','ddrop','vstr','sprites','actors','mobs')},
  'mode_tag_caveat':'STAT tags the state at emission; a transition window can contain processing from more than one state.'}
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--session',type=Path,required=True);ap.add_argument('--plan',type=Path);ap.add_argument('--host-cc',default='gcc');ap.add_argument('--output-dir',type=Path,default=R/'results/r7p1_board_audit');a=ap.parse_args()
 S=a.session.resolve();O=a.output_dir.resolve();O.mkdir(parents=True,exist_ok=True)
 session=json.loads((S/'session.json').read_text(encoding='utf-8'));assert session['status']=='LOADED_SHORT_CAPTURE_COMPLETE','Do not certify an unfinished capture'
 ident=json.loads((R/'build/identity.json').read_text());assert session['elf_sha256']==ident['elf_sha256']==sha(R/'build/rumia.elf')
 for group in ('sources','scripts'):
  for name,digest in ident[group].items():assert sha(R/name)==digest,name
 raw=S/'uart_lines.jsonl';raw_sha=sha(raw);records=[json.loads(x)for x in raw.read_text(encoding='utf-8').splitlines()if x.strip()]
 faults=[x for x in records if re.search(r'\b(?:FATAL|TRAP)\b',x.get('line','')) or x.get('line','').startswith(('ERR ','FAIL'))]
 plan_path=a.plan or (S/'r7p1_test_plan.jsonl' if (S/'r7p1_test_plan.jsonl').exists() else S/'r7_test_plan.jsonl');plan=[json.loads(x)for x in plan_path.read_text(encoding='utf-8').splitlines()if x.strip()]
 stats=[]
 for x in records:
  if x.get('line','').startswith('STAT '):
   d={k:int(v)for k,v in re.findall(r'(\w+)=(\d+)',x['line'])};d['utc']=x['utc'];stats.append(d)
 segments=[]
 for i,p in enumerate(plan):
  start=parse_time(p['utc']);end=start+timedelta(seconds=p['wait'])
  if i+1<len(plan):end=min(end,parse_time(plan[i+1]['utc']))
  group=[x for x in stats if start<=parse_time(x['utc'])<end]
  if not group:continue
  retained=group[1:]
  continuity=all(((group[j]['scan_total']-group[j-1]['scan_total'])&0xffffffff)==group[j]['scan'] and ((group[j]['swap_total']-group[j-1]['swap_total'])&0xffffffff)==group[j]['swaps']for j in range(1,len(group)))
  same_profile=all(x['mode']==group[0]['mode']and x['hw']==group[0]['hw']for x in group)
  segments.append({'label':p['label'],'command':p['command'],'start_utc':start.isoformat(),'end_utc':end.isoformat(),
   'excluded_first_STAT_once':True,'observed_windows':len(group),'counter_continuity':continuity,'all_windows_same_mode_backend':same_profile,
   'cumulative_counter_delta_from_warmup':{k:retained[-1][k]-group[0][k]if retained else None for k in ('ldrop','lover','drops')},
   'overall':summary(retained),'by_mode':{str(m):summary([x for x in retained if x['mode']==m])for m in sorted({x['mode']for x in retained})},
   'retained':retained,'warmup':group[0]})
 budget_bad=[x for x in stats if x.get('qcmd',0)>384 or x.get('decor',0)>12 or x.get('darea',0)>8192]
 report={'status':'AUDIT_COMPLETE','generated_utc':datetime.now(timezone.utc).isoformat(),'elf_sha256':ident['elf_sha256'],'source_log':str(raw),'raw_sha256':raw_sha,
  'raw_records':len(records),'STAT_records':len(stats),'faults':faults,'sampled_budget_violations':budget_bad,'segments':segments,
  'scope':'Short R7p1 auto-DEMO/tuned cases; no new600-second performance acceptance. A/B is not synchronized same-tick workload. Actual mode1 and terminal modes are separate.',
  'counter_semantics':'qcmd/qclip/qsort/decor/darea/ddrop/frame/logic/render are last-frame samples, not window maxima or totals. fxdrop/missed/uf are window deltas; ldrop/lover/drops are cumulative.'}
 (O/'native_short_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
 # Shared tool independently decodes CRC and executes the exported recording in
 # a fresh process linked with current production game/player/boss/enemy logic.
 cmd=[sys.executable,'-B','-X','utf8',str(R/'scripts/audit_short_capture.py'),'--session',str(S),'--plan',str(plan_path),'--output-dir',str(O/'replay'),'--host-cc',a.host_cc,'--boss-count','4','--enemy-count','6']
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=150);(O/'replay_audit.log').write_text(p.stdout+p.stderr,encoding='utf-8')
 assert p.returncode==0,p.stdout+p.stderr
 assert sha(raw)==raw_sha,'Raw evidence changed during audit'
 for s in segments:print(s['label'],json.dumps({m:{'fps':v['weighted_fps'],'windows':v['windows'],'missed':v['window_delta_sum']['missed'],'UF':v['window_delta_sum']['uf']}for m,v in s['by_mode'].items()}))
 print('R7_SHORT_AUDIT COMPLETE raw_unchanged=PASS sampled_budget_violations=%d faults=%d'%(len(budget_bad),len(faults)))
 return 0
if __name__=='__main__':raise SystemExit(main())
