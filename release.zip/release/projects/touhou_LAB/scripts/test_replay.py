#!/usr/bin/env python3
"""Build replay protocol and real production-game replay regressions (host only)."""
import argparse,json,os,shlex,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));ap.add_argument('--replay-json',type=Path);ap.add_argument('--boss-count',type=int,default=3);ap.add_argument('--enemy-count',type=int,default=0);a=ap.parse_args()
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
build=R/'build/replay_host';build.mkdir(parents=True,exist_ok=True)
flags=['-std=gnu11','-O2','-UNDEBUG','-Wall','-Wextra','-Wno-unused-function','-Wno-unused-parameter','-Wno-misleading-indentation','-Isrc','-Itests/stub','-Itests']
results={}
def run(name,cmd):
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=120)
 print(p.stdout,end='');print(p.stderr,end='',file=sys.stderr)
 results[name]={'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'command':cmd}
 if p.returncode:raise RuntimeError(name+' failed')
 return p
try:
 proto=build/('replay_protocol.exe' if os.name=='nt' else 'replay_protocol')
 run('protocol_build',cc+flags+['tests/replay_protocol.c','src/replay.c','src/remote_input.c','-o',str(proto)])
 p=run('protocol',[str(proto)])
 from replay_tool import parse_log,decode_words
 export=parse_log(p.stdout)
 invalid=[]
 for label,text in [('missing_word',p.stdout.replace('REPLAY_WORD 8 0\n','')),('conflicting_duplicate',p.stdout+'\nREPLAY_WORD 0 1\n'),('out_of_range',p.stdout+'\nREPLAY_WORD 999 4294967296\n')]:
  try:parse_log(text)
  except ValueError:invalid.append(label)
  else:raise AssertionError(label+' accepted')
 for label,index in [('bad_magic',0),('bad_seed_crc',2),('bad_payload_crc',9)]:
  words=export['words'][:];words[index]^=1
  try:decode_words(words)
  except ValueError:invalid.append(label)
  else:raise AssertionError(label+' accepted')
 results['python_export_validation']={'status':'PASS','reject_cases':invalid}
 (R/'results/replay_protocol_export.json').write_text(json.dumps(export,indent=2),encoding='utf-8')
 # Use the existing actual-production game.c harness stubs, not a game model.
 prefix=(R/'tests/phase_gameplay.c').read_text(encoding='utf-8-sig').split('static int failures;',1)[0]
 for name,args in [('scene_hud_begin','void'),('scene_hud_end','void'),('scene_hud_invalidate','void'),('scene_hud_cache_enable','unsigned enabled')]:
  if ('void '+name+'(') not in prefix:
   prefix+='\nvoid '+name+'('+args+') {'+('(void)enabled;' if 'enabled' in args else '')+'}\n'
 host=build/'replay_game.c';host.write_text(prefix+'\n#include "replay_game_body.h"\n',encoding='utf-8')
 game=build/('replay_game.exe' if os.name=='nt' else 'replay_game')
 sources=[str(host),'src/stage.c','src/battle.c','src/player.c', 'src/enemies.c','src/layer_visuals.c','src/effects.c','src/game_config.c','src/font.c','src/replay.c','src/remote_input.c']
 run('production_build',cc+flags+sources+['-o',str(game)])
 if a.replay_json:
  obj=decode_words(json.loads(a.replay_json.read_text(encoding='utf-8'))['words'])
  wordfile=build/'input_words.txt';wordfile.write_text('\n'.join(str(w) for w in obj['words'])+'\n',encoding='ascii')
  run('external_production_replay',[str(game),str(wordfile),str(a.boss_count),str(a.enemy_count)])
 else:
  run('production_determinism_and_win',[str(game)])
  default_words=build/'default_export_words.txt'
  run('production_default_export',[str(game),'--export-default',str(default_words)])
  model_export=decode_words([int(w) for w in default_words.read_text(encoding='ascii').split()])
  (R/'results/replay_production_export.json').write_text(json.dumps(model_export,indent=2),encoding='utf-8')
  run('production_file_roundtrip',[str(game),str(default_words)])
  for bosses,enemies in [(4,6),(6,12)]:
   words=build/('export_%uboss_%uenemy_words.txt'%(bosses,enemies))
   run('production_export_%u_%u'%(bosses,enemies),[str(game),'--export-topology',str(words),str(bosses),str(enemies)])
   obj=decode_words([int(w) for w in words.read_text(encoding='ascii').split()])
   (R/('results/replay_production_%uboss_%uenemy_export.json'%(bosses,enemies))).write_text(json.dumps(obj,indent=2),encoding='utf-8')
   run('production_file_roundtrip_%u_%u'%(bosses,enemies),[str(game),str(words),str(bosses),str(enemies)])
 status='PASS'
except Exception as e:
 status='FAIL';results['error']=str(e);print('REPLAY_TEST FAIL',e)
report={'status':status,'generated_utc':datetime.now(timezone.utc).isoformat(),'hardware_accessed':False,'results':results}
(R/'results/replay_tests.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('REPLAY_TEST='+status)
raise SystemExit(0 if status=='PASS' else 1)
