#!/usr/bin/env python3
"""Build and run the phase-battle host tests T01-T10 and T12-T14.

The C harness includes the production game.c and links the production
stage/battle/player/effects modules; only BSP/MMIO/render entry points are
stubbed. T11 (two-buffer pixels) is scripts/test_scene.py.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shlex
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser()
ap.add_argument("--host-cc", default=os.environ.get("HOST_CC", "gcc"))
ap.add_argument("--out", default="build")
ap.add_argument("--no-run", action="store_true")
a = ap.parse_args()
cc = [x.strip('"') for x in shlex.split(a.host_cc, posix=False)]
out = R / a.out
out.mkdir(exist_ok=True)
exe = out / ("phase_gameplay.exe" if os.name == "nt" else "phase_gameplay")
cmd = cc + ["-std=gnu11", "-O2", "-UNDEBUG", "-Wall", "-Wextra",
            "-Wno-unused-parameter", "-Isrc", "-Itests/stub",
            "tests/phase_gameplay.c", "src/stage.c", "src/battle.c",
            "src/player.c", "src/enemies.c","src/layer_visuals.c", "src/effects.c", "src/game_config.c", "src/replay.c", "src/remote_input.c",
            "src/font.c", "-o", str(exe)]
p = subprocess.run(cmd, cwd=R, capture_output=True, text=True)
if p.stdout:
    print(p.stdout, end="")
if p.stderr:
    print(p.stderr, end="", file=sys.stderr)
if p.returncode:
    print("PHASE_GAMEPLAY=FAIL phase=compile")
    raise SystemExit(p.returncode)
if a.no_run:
    print("PHASE_GAMEPLAY=BUILD_OK")
    raise SystemExit(0)
p = subprocess.run([str(exe)], cwd=R, capture_output=True, text=True)
print(p.stdout, end="")
print(p.stderr, end="", file=sys.stderr)
lines = [x.strip() for x in p.stdout.splitlines() if x.strip()]
passed = sorted({ln.split()[0] for ln in lines if len(ln.split()) >= 2 and ln.split()[1] == "PASS" and ln.split()[0].startswith("T")})
required = ["T01", "T02", "T03", "T04", "T05", "T06", "T07", "T08", "T09", "T10", "T12", "T13", "T14"]
ok = p.returncode == 0 and "ALL_PHASE_TESTS_PASS" in lines and all(t in passed for t in required)
result = {
    "status": "PASS" if ok else "FAIL",
    "generated_utc": datetime.now(timezone.utc).isoformat(),
    "command": " ".join(cmd),
    "run_command": str(exe),
    "exit_code": p.returncode,
    "tests": {t: ("PASS" if t in passed else "FAIL") for t in
              required},
    "stdout": p.stdout,
    "source_sha256": {str(x.relative_to(R)): hashlib.sha256(x.read_bytes()).hexdigest()
                      for x in [R / 'src/game.c', R / 'src/player.c', R / 'src/enemies.c',R / 'src/layer_visuals.c', R / 'src/battle.c',
                                R / 'src/effects.c', R / 'src/game_config.c']},
}
(R / 'results/phase_gameplay.json').write_text(json.dumps(result, indent=2), encoding='utf8')
print("PHASE_GAMEPLAY=" + result["status"])
raise SystemExit(0 if ok else 1)
