#!/usr/bin/env python3
"""Current STRESS source vs frozen scalar reference; no board/USB access."""
from pathlib import Path
import argparse,hashlib,json,os,re,shlex,subprocess,sys
from datetime import datetime,timezone
root=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));args=a.parse_args()
cc=[x.strip('"') for x in shlex.split(args.host_cc,posix=False)]
folder=root/'tests/stress_gather_equivalence';out=root/'build/stress_gather_equivalence';out.mkdir(parents=True,exist_ok=True)
names=['stage','turn_sin','turn_cos','turn_atan','stage_random','stage_reset','stage_step','stage_stress','stage_stress_step','stage_stress_step_near','stage_near_ready','stage_near_count','stage_near_indices']
common=cc+['-std=gnu11','-O2','-UNDEBUG','-I'+str(root/'src')]
commands=[];log='';code=0
for prefix,source in [('base',folder/'reference_stage_R2.c'),('cand',root/'src/stage.c')]:
    command=common+['-D'+n+'='+prefix+'_'+n for n in names]+['-c',str(source),'-o',str(out/(prefix+'.o'))]
    commands.append(command);p=subprocess.run(command,cwd=root,capture_output=True,text=True,timeout=45);log+=p.stdout+p.stderr
    if p.returncode:code=p.returncode;break
if not code:
    exe=out/('proof.exe' if os.name=='nt' else 'proof')
    command=common+[str(folder/'proof.c'),str(out/'base.o'),str(out/'cand.o'),str(root/'src/game_config.c'),'-o',str(exe)]
    commands.append(command);p=subprocess.run(command,cwd=root,capture_output=True,text=True,timeout=45);log+=p.stdout+p.stderr;code=p.returncode
if not code:
    commands.append([str(exe)]);p=subprocess.run([str(exe)],cwd=root,capture_output=True,text=True,timeout=90);log+=p.stdout+p.stderr;code=p.returncode
passed=not code and 'STAGE_CANDIDATE_SEMANTICS PASS checks=1200276' in log and 'GATHER_DISABLED_REFERENCE PASS11counts x128ticks byteexact' in log
validation=root/'results/validation';validation.mkdir(parents=True,exist_ok=True);(validation/'stress_gather.log').write_text(log,encoding='utf-8')
result={'status':'PASS' if passed else 'FAIL','generated_utc':datetime.now(timezone.utc).isoformat(),'exit_code':code,'commands':commands,'source_sha256':{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'src/stage.c',root/'src/stage.h',root/'src/game_config.c',root/'src/game_config.h',folder/'reference_stage_R2.c',folder/'proof.c']},'counts':[0,1,3,4,5,63,64,65,512,4096,20000],'ticks_each_enabled':36000,'enabled_assertions':1200276,'ticks_each_disabled':128,'explicit_near_overflow_candidates':513,'scope':'Host arithmetic/state equivalence, not target inline-asm dynamic execution or FPGA FPS. Actual target assembly evidence separate.'}
(root/'results/stress_gather_equivalence.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(log,end='');print('STRESS_GATHER='+result['status']);sys.exit(0 if passed else 1)
