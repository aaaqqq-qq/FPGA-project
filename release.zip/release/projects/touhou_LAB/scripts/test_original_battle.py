#!/usr/bin/env python3
"""Legacy ECL regression: raw floating original vs firmware fixed-point VM.

This intentionally runs the original three-boss behaviour (battle_set_legacy)
so the phase-battle adaptations do not hide parser/VM regressions. Emission
counts and timestamps are compared for 36,000 frames.
"""
from __future__ import annotations

import argparse
import ctypes as C
import hashlib
import json
import os
import shlex
import struct
import subprocess
import sys
from pathlib import Path

R = Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser()
ap.add_argument("--host-cc", default=os.environ.get("HOST_CC", "gcc"))
ap.add_argument("--out", default="build")
a = ap.parse_args()
cc = [x.strip('"') for x in shlex.split(a.host_cc, posix=False)]
out = R / a.out
out.mkdir(exist_ok=True)
libpath = out / ("legacy_battle.dll" if os.name == "nt" else "legacy_battle.so")
cmd = cc + ["-shared", "-O2", "-UNDEBUG", "-Isrc", "-Itests/stub",
            "src/stage.c", "src/battle.c", "src/player.c", "src/enemies.c","src/layer_visuals.c", "src/effects.c",
            "src/game_config.c", "tests/host_scene_stubs.c", "-o", str(libpath)]
subprocess.run(cmd, cwd=R, check=True)
lib = C.CDLL(str(libpath))


class Boss(C.Structure):
    _fields_ = [
        ("x", C.c_int), ("y", C.c_int), ("hp", C.c_int),
        ("fired", C.c_uint), ("vulnerable", C.c_uint), ("max_hp", C.c_int),
        ("state", C.c_uint), ("state_ticks", C.c_uint), ("script_ticks", C.c_uint),
        ("enraged", C.c_uint), ("enrage_done", C.c_uint), ("entered", C.c_uint),
        ("dead", C.c_uint), ("refilled", C.c_uint), ("enter_sx", C.c_uint),
        ("enter_sy", C.c_uint), ("enter_tx", C.c_uint), ("enter_ty", C.c_uint),
        ("damage_dealt", C.c_uint), ("damage_taken", C.c_uint),
        ("shots_requested", C.c_uint), ("shots_spawned", C.c_uint),
        ("shots_rejected", C.c_uint), ("volleys_dropped", C.c_uint),
        ("death_tick", C.c_uint),
    ]


bosses = (Boss * 3).in_dll(lib, "bosses")
formats = {2: 'ii', 3: 'iii', 4: 'ii', 5: 'if', 8: 'if', 13: 'iii', 16: 'iii',
           17: 'iii', 20: 'iff', 21: 'iff', 27: 'ii', 28: 'ff', 29: 'ii',
           30: 'ii', 31: 'ii', 32: 'ii', 33: 'ii', 34: 'ii', 35: 'iif',
           36: '', 67: 'hhiiffffi', 68: 'hhiiffffi', 69: 'hhiiffffi', 70: 'hhiiffffi'}


class Raw:
    def __init__(self, st, sub, rank):
        self.data = (R / f"assets/source/th06e_ST.DAT__ecldata{st}.ecl").read_bytes()
        n = struct.unpack_from('<H', self.data)[0]
        self.offsets = struct.unpack_from('<%dI' % n, self.data, 16)
        self.pc = self.offsets[sub]
        self.time = 0
        self.v = {}
        self.stack = []
        self.cmp = 0
        self.fired = 0
        self.rank = rank

    def val(self, x):
        return self.v.get(int(x), 0) if -10012 <= x <= -10001 else x

    def step(self):
        for _ in range(512):
            t, op, size, mask, _ = struct.unpack_from('<i4H', self.data, self.pc)
            if t != self.time:
                break
            old = self.pc
            self.pc += size
            if not mask >> 8 & self.rank:
                continue
            if op not in formats:
                continue
            args = struct.unpack_from('<' + formats[op], self.data, old + 12)
            jump = False
            if op == 2:
                jump = True
            elif op == 3:
                self.v[args[2]] = self.val(args[2]) - 1
                jump = self.v[args[2]] > 0
            elif op in (4, 5):
                self.v[args[0]] = self.val(args[1])
            elif op == 8:
                self.v[args[0]] = self.val(args[1]) * .37
            elif op in (13, 20):
                self.v[args[0]] = self.val(args[1]) + self.val(args[2])
            elif op == 21:
                self.v[args[0]] = self.val(args[1]) - self.val(args[2])
            elif op == 16:
                self.v[args[0]] = int(self.val(args[1]) / self.val(args[2]))
            elif op == 17:
                self.v[args[0]] = self.val(args[1]) % self.val(args[2])
            elif op in (27, 28):
                x, y = map(self.val, args)
                self.cmp = (x > y) - (x < y)
            elif 29 <= op <= 34:
                jump = [self.cmp < 0, self.cmp <= 0, self.cmp == 0,
                        self.cmp > 0, self.cmp >= 0, self.cmp != 0][op - 29]
            elif op == 35:
                self.stack.append((self.pc, self.time, self.v.copy(), self.cmp))
                self.pc = self.offsets[args[0]]
                self.time = 0
                self.v = {-10001: args[1], -10005: args[2]}
                self.cmp = 0
            elif op == 36:
                self.pc, self.time, self.v, self.cmp = self.stack.pop()
            elif 67 <= op <= 70:
                self.fired += max(1, int(self.val(args[2]))) * max(1, int(self.val(args[3])))
            if jump:
                self.time = args[0]
                self.pc = old + args[1]
        else:
            raise AssertionError('raw watchdog')
        self.time += 1


lib.game_config_defaults()
lib.battle_set_legacy(1)
runs = []
for difficulty in range(3):
    rank = [2, 4, 8][difficulty]
    raw = [Raw(1, 22, rank), Raw(2, 30, max(rank, 4)), Raw(3, 29, rank)]
    lib.battle_reset(difficulty, 4096)
    for frame in range(12000):
        for k, (st, sub) in enumerate([(1, 22), (2, 30), (3, 29)]):
            if frame and frame % [1500, 2100, 1800][k] == 0:
                old = raw[k].fired
                raw[k] = Raw(st, sub, max(rank, 4) if k == 1 else rank)
                raw[k].fired = old
        lib.battle_step(512, 620)
        for k, ref in enumerate(raw):
            ref.step()
            if bosses[k].fired != ref.fired:
                print(f"FAIL difficulty={difficulty} frame={frame} boss={k} "
                      f"firmware={bosses[k].fired} raw={ref.fired}")
                sys.exit(1)
    runs.append({'difficulty': difficulty, 'frames': 12000,
                 'per_boss_emitted': [b.fired for b in bosses]})
print('PASS: 36,000 frames, all 3 bosses match raw original ECL emission counts/timestamps')
result = {
    'passed': True,
    'checks': 'raw floating ECL vs fixed point C VM emission counts and timestamps; random angles excluded',
    'mode': 'legacy',
    'source_sha256': {p: hashlib.sha256((R / p).read_bytes()).hexdigest()
                      for p in ('src/battle.c', 'src/stage.c', 'src/player.c')},
    'runs': runs,
}
(R / 'results/original_battle_reference.json').write_text(json.dumps(result, indent=2))
