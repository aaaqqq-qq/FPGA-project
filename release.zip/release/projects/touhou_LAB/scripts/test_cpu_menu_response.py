from pathlib import Path
import time,json,re,hashlib
R=Path(__file__).resolve().parents[1];C=R/'results/serial_commands.txt';L=R/'results/validation/touhou_uart.log'
def send(s):
 with C.open('ab')as f:f.write(s.encode())
def tail(offset):
 with L.open('rb')as f:f.seek(offset);return f.read().decode(errors='replace')
rows=[]
for delay in [.11,.37,.61]:
 offset=L.stat().st_size;send('cn4096\n');deadline=time.monotonic()+8
 while time.monotonic()<deadline:
  if 'STAT mode=2 hw=0 N=4096' in tail(offset):break
  time.sleep(.02)
 else:raise RuntimeError('CPU mode not started')
 time.sleep(delay);offset=L.stat().st_size;t=time.monotonic();send('m')
 while time.monotonic()-t<2:
  if 'UI MENU' in tail(offset):break
  time.sleep(.005)
 else:raise RuntimeError('No responsive menu acknowledgment')
 ms=(time.monotonic()-t)*1000;rows.append(ms);print('CPU4096 menu acknowledgment ms',round(ms,2),flush=True)
 assert ms<300,ms
 time.sleep(.2)
(R/'results/cpu_menu_response.json').write_text(json.dumps({'passed':True,'elf_sha256':hashlib.sha256((R/'build/rumia.elf').read_bytes()).hexdigest(),'queue_to_menu_ack_ms':rows,'note':'Includes host serial-monitor polling and menu rendering. UART request tests cooperative CPU cancellation; physical debounce/chord separately host tested.'},indent=2))
