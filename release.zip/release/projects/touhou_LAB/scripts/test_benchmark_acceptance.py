"""Offline regression of production acceptance function; no serial/USB access."""
import ast
import copy
import json
from pathlib import Path
from types import SimpleNamespace

R=Path(__file__).resolve().parents[1]
tree=ast.parse((R/'scripts/benchmark_board.py').read_text(encoding='utf-8'))
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='assess_windows')
env={}
exec(compile(ast.Module(body=[node],type_ignores=[]),'production_assess_windows','exec'),env)
assess=env['assess_windows']
options=SimpleNamespace(battle=True,dodge=False,cpu=False,hz=60,seconds=600)
rows=[dict(mode=1,hw=1,N=2000,limit=20000,us=2000000,fps100=6000,
           swaps=120,scan=120,frame=14000,scan_total=(i+1)*120,missed=0,uf=0,
           ldrop=0,lover=0,drops=0,fxo=0,req=100,rejected=0,
           render=14000,max=15000) for i in range(301)]
results={}
def check(name,data,expected,opts=options,n=0):
    keep,steady,reasons=assess(data,n,opts)
    actual=not reasons
    assert actual==expected,(name,reasons)
    results[name]={'pass':True,'accepted':actual,'reasons':reasons,
                   'measured_us':sum(d.get('us',0) for d in steady)}
check('full_600s_36000_swaps',rows,True)
check('short_six_seconds_rejected',rows[:4],False)
for field in ('missed','uf','ldrop','lover','drops','fxo'):
    bad=copy.deepcopy(rows);bad[2][field]=1
    check('nonzero_'+field,bad,False)
bad=copy.deepcopy(rows);bad[20]['scan_total']+=120
check('counter_gap',bad,False)
bad=copy.deepcopy(rows);del bad[20]
check('missing_whole_window',bad,False)
bad=copy.deepcopy(rows);bad[20]['mode']=0
check('battle_ended_early',bad,False)
bad=copy.deepcopy(rows);bad[20]['hw']=0
check('backend_changed',bad,False)
bad=copy.deepcopy(rows);del bad[20]['scan_total']
check('required_field_missing',bad,False)
bad=copy.deepcopy(rows);bad[20]['us']=10000000
check('delayed_window',bad,False)
stress=copy.deepcopy(rows)
for d in stress:d.update(mode=2,N=4096,limit=4096)
opts=SimpleNamespace(battle=False,dodge=False,cpu=False,hz=60,seconds=600)
check('stress_full',stress,True,opts,4096)
stress[20]['limit']=8192
check('stress_capacity_changed',stress,False,opts,4096)
out=R/'results/benchmark_acceptance_regression.json'
out.write_text(json.dumps({'status':'PASS','hardware_accessed':False,'cases':results},indent=2),encoding='utf-8')
print('BENCHMARK_ACCEPTANCE PASS',len(results),'cases; no hardware access')
