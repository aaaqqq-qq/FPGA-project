#!/usr/bin/env python3
"""R6 preregistered native-hardware/PC-receipt stability analysis.

No serial/USB access. Native frame=processing microseconds, NEVER a frame ID.
scan_total is the hardware cumulative display counter required for continuity.
The first matching STAT is excluded once as an explicit warmup baseline.
After that, transitions/bad native rows/errors reject hardware acceptance.
PC timestamps describe receipt, not FPGA emission: their jitter is reported
separately. This policy applies to new R6 runs; it never rewrites R5 results.
"""
import argparse,hashlib,json,math,re
from pathlib import Path
from datetime import datetime

REQUIRED=('mode','hw','N','limit','fps100','swaps','scan','us','scan_total','swap_total',
          'missed','uf','drops','ldrop','lover','fxdrop')
POLICY_ID='R6-native-hardware-and-PC-receipt-v1'

def policy_description(mode=2,count=20000,seconds=600,hz=60,hw=1,require_zero_fxdrop=False):
    return {'policy_id':POLICY_ID,'applies_to':'New R6 runs preregistered before measurement; not a replacement for historical R5 verdicts',
        'requested':{'mode':mode,'hw':hw,'N':count,'limit':count,'seconds':seconds,'hz':hz},
        'warmup':'Predetermined acquisition warmup plus exactly one first matching STAT baseline; no later failed window may be removed',
        'required_native_fields':list(REQUIRED),'minimum_native_us':seconds*1000000,'minimum_completed_swaps':seconds*hz,
        'each_native_window_us':[1900000,2500000],'reported_and_recomputed_fps_tolerance_hz':0.05,
        'hardware_criteria':['Every retained mode/hw/N/limit identical to request','Modulo32 scan_total and swap_total differences equal this window scan and swaps',
            'Every scan equals swap count, missed=0 and uf=0','Cumulative drops/ldrop/lover never increase or reset after baseline',
            'No missing/malformed/duplicate/out-of-range required native fields, missing windows, reorder, restart, TRAP/FAIL/FATAL',
            'At least three steady windows, requested full native duration and completed swaps; all failed windows preserved'],
        'receipt_quality':'PC UTC/monotonic timestamps are receipt time. Missing/nonmonotonic/abs(receipt_delta-native_us)>500000 is WARNING only if native evidence remains complete; it never excuses a native gap or fault.',
        'visual_gate':{'require_zero_fxdrop':require_zero_fxdrop,'separate_from_FPS':True},
        'overall_status':'PASS only if hardware_status=PASS and configured visual gate passes; capture_quality WARNING remains explicit',
        'scope':'Native counter/window cadence only; no whole-game or per-frame render-time claim; frame is processing_us, never a counter'}

def policy_digest(policy):
    return hashlib.sha256(json.dumps(policy,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def native_issues(row,data):
    names=[k for k,v in re.findall(r'(\w+)=(\d+)',row.get('line',''))]
    issues=[]
    if len(names)!=len(set(names)):issues.append('duplicate_native_fields')
    if any(k in data and not 0<=data[k]<=0xffffffff for k in REQUIRED):issues.append('native_field_out_of_uint32_range')
    return issues

def stamp(row):
    if isinstance(row.get('monotonic'),(int,float)) and math.isfinite(row['monotonic']):return float(row['monotonic'])
    try:return datetime.fromisoformat(row['utc'].replace('Z','+00:00')).timestamp()
    except (KeyError,ValueError,TypeError):return None

def stat(row):
    text=row.get('line','')
    if not text.startswith('STAT'):return None
    return {k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',text)}

def assess(records,mode=2,count=20000,seconds=600,hz=60,hw=1,require_zero_fxdrop=False):
    def matches(d):
        return d is not None and d.get('mode')==mode and d.get('hw')==hw and d.get('N')==count and d.get('limit')==count
    first=next((i for i,r in enumerate(records) if matches(stat(r))),None)
    policy=policy_description(mode,count,seconds,hz,hw,require_zero_fxdrop)
    reasons=[];windows=[];capture_warnings=[];counter_steps_valid=True
    if any(re.search(r'\b(?:TRAP|FAIL|FATAL)\b',r.get('line','')) for r in records):reasons.append('runtime_fault_in_selected_capture')
    if first is None:
        reasons.append('no_matching_fresh_STAT_window');observed=[];baseline=None
    else:
        observed=records[first:];baseline=stat(observed[0])
    previous=baseline;previous_stamp=stamp(observed[0]) if observed else None
    same_us=same_swaps=qualified_us=qualified_swaps=scan_sum=missed_sum=uf_sum=fxdrop_total=0
    steady_stats=0;complete_continuity=baseline is not None
    if baseline is not None:
        reasons.extend(native_issues(observed[0],baseline))
        missing=[k for k in REQUIRED if k not in baseline]
        if missing:reasons.append('warmup_missing_required_telemetry:'+','.join(missing));complete_continuity=False
    for index,row in enumerate(observed):
        text=row.get('line','');d=stat(row)
        if re.search(r'\b(?:TRAP|FAIL|FATAL)\b',text):reasons.append('runtime_fault_in_capture')
        if index and text.startswith('RUMIA HDMI'):reasons.append('reboot_during_run')
        if d is None:continue
        if not index:continue
        steady_stats+=1;errors=native_issues(row,d);receipt_issues=[];now=stamp(row)
        missing=[k for k in REQUIRED if k not in d]
        if missing:errors.append('missing_required_telemetry:'+','.join(missing));complete_continuity=False
        if not matches(d):errors.append('mode_backend_count_or_capacity_changed')
        if d.get('us',0)<1900000 or d.get('us',0)>2500000:errors.append('irregular_STAT_window_duration')
        if matches(d):same_us+=d.get('us',0);same_swaps+=d.get('swaps',0)
        scan_sum+=d.get('scan',0);missed_sum+=d.get('missed',0);uf_sum+=d.get('uf',0);fxdrop_total+=d.get('fxdrop',0)
        if not missing and previous is not None and not any(k not in previous for k in REQUIRED):
            if ((d['scan_total']-previous['scan_total'])&0xffffffff)!=d['scan']:errors.append('hardware_scan_counter_discontinuity');counter_steps_valid=False
            if ((d['swap_total']-previous['swap_total'])&0xffffffff)!=d['swaps']:errors.append('hardware_swap_counter_discontinuity');counter_steps_valid=False
            if d['scan']!=d['swaps'] or d['missed'] or d['uf']:errors.append('missed_swap_or_underflow')
            for k in ('drops','ldrop','lover'):
                if d[k]!=previous[k]:errors.append(k+'_increased_or_reset')
            actual100=d['swaps']*100000000/max(1,d['us'])
            if not hz*100-5<=d['fps100']<=hz*100+5:errors.append('reported_fps_outside_target')
            if not hz*100-5<=actual100<=hz*100+5:errors.append('native_swap_rate_outside_target')
        else:complete_continuity=False
        if now is None or previous_stamp is None:receipt_issues.append('missing_PC_receipt_timestamp')
        elif now<=previous_stamp:receipt_issues.append('non_monotonic_PC_receipt_timestamp')
        elif abs((now-previous_stamp)*1000000-d.get('us',0))>500000:receipt_issues.append('PC_receipt_jitter_vs_native_window')
        if receipt_issues:
            capture_warnings.append({'capture_index':first+index,'utc':row.get('utc'),'monotonic':row.get('monotonic'),
                'issues':receipt_issues,'native_window_us':d.get('us'),'PC_receipt_delta_us':(now-previous_stamp)*1000000 if now is not None and previous_stamp is not None else None})
        if not errors:qualified_us+=d.get('us',0);qualified_swaps+=d.get('swaps',0)
        windows.append({'capture_index':first+index,'utc':row.get('utc'),'monotonic':row.get('monotonic'),'telemetry':d,'errors':errors,'hardware_errors':errors,'capture_warnings':receipt_issues})
        reasons.extend(errors);previous=d;previous_stamp=now
    if steady_stats<3:reasons.append('fewer_than_three_steady_windows')
    if same_us<seconds*1000000:reasons.append('insufficient_measured_duration')
    if same_swaps<seconds*hz:reasons.append('insufficient_valid_swaps')
    reasons=sorted(set(reasons));performance_pass=not reasons
    cosmetics_clean=fxdrop_total==0
    warnings=[] if cosmetics_clean else ['bounded_cosmetic_effects_dropped; FPS acceptance is separate from full visual coverage']
    accepted=performance_pass and (cosmetics_clean or not require_zero_fxdrop)
    return {
        'schema':'ti60-r6-stability-v2','policy':policy,'policy_sha256':policy_digest(policy),'status':'PASS' if accepted else 'FAIL',
        'hardware_status':'PASS' if performance_pass else 'FAIL','capture_quality':'WARNING' if capture_warnings else 'PASS',
        'visual_status':'PASS' if cosmetics_clean else 'WARNING','historical_R5_results_reclassified':False,
        'passed_target_fps':performance_pass,'passed_60fps':performance_pass and hz==60,
        'full_visual_budget_clean':cosmetics_clean,'require_zero_fxdrop':require_zero_fxdrop,
        'requested':{'mode':mode,'hw':hw,'count':count,'seconds':seconds,'hz':hz,'minimum_us':seconds*1000000,'minimum_swaps':seconds*hz},
        'warmup_first_matching_STAT_excluded_once':True,'warmup_telemetry':baseline,
        'prelude_records':records[:first] if first is not None else records,
        'all_records_from_first_matching_window':observed,
        'steady_windows':steady_stats,'measured_us':same_us,'observed_same_configuration_swaps':same_swaps,
        'qualified_us':qualified_us,'qualified_swaps':qualified_swaps,
        'weighted_fps':same_swaps*1000000/same_us if same_us else None,
        'hardware_counter_continuity_verifiable':complete_continuity,
        'counter_continuity_pass':complete_continuity and counter_steps_valid,
        'scan_sum':scan_sum,'missed_sum':missed_sum,'underflow_sum':uf_sum,
        'cosmetic_fxdrop_total':fxdrop_total,'failure_reasons':reasons,'warnings':warnings,'windows':windows,
        'hardware_failure_reasons':reasons,'capture_quality_warnings':capture_warnings,
        'acceptance_failure_reasons':reasons+(['cosmetic_budget_drops_disallowed'] if require_zero_fxdrop and not cosmetics_clean else []),
        'scope':'STAT-window hardware-counter continuity and swap cadence; frame field is processing time, not a cumulative counter. No invented per-frame render timing proof.',
    }

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--log',type=Path)
    ap.add_argument('--mode',type=int,default=2);ap.add_argument('--mode2',dest='mode',action='store_const',const=2)
    ap.add_argument('--count',type=int,default=20000);ap.add_argument('--seconds',type=int,default=600);ap.add_argument('--hz',type=int,default=60);ap.add_argument('--hw',type=int,default=1)
    ap.add_argument('--output',type=Path);ap.add_argument('--start-utc');ap.add_argument('--require-zero-fxdrop',action='store_true');ap.add_argument('--describe-policy',action='store_true')
    a=ap.parse_args()
    if a.seconds<1 or a.hz<1 or not 1<=a.count<=20000:ap.error('positive seconds/hz and count1..20000 required')
    if a.log is not None and a.output is not None and a.output.resolve()==a.log.resolve():ap.error('output may not overwrite raw input log')
    if a.describe_policy:
        p=policy_description(a.mode,a.count,a.seconds,a.hz,a.hw,a.require_zero_fxdrop)
        document={'policy':p,'policy_sha256':policy_digest(p)}
        if a.output:
            a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(document,indent=2),encoding='utf-8')
        print(json.dumps(document,indent=2));return 0
    if a.log is None or a.output is None:ap.error('--log and --output required for analysis')
    payload=a.log.read_bytes();records=[];parse_errors=[]
    for index,line in enumerate(payload.decode('utf-8',errors='replace').splitlines()):
        if not line.strip():continue
        try:
            r=json.loads(line)
            if not isinstance(r,dict) or not isinstance(r.get('line'),str):raise ValueError('JSONL row requires line string')
            if a.start_utc and datetime.fromisoformat(r.get('utc','').replace('Z','+00:00'))<datetime.fromisoformat(a.start_utc.replace('Z','+00:00')):continue
            records.append(r)
        except (ValueError,TypeError) as e:parse_errors.append({'line':index+1,'error':str(e),'raw':line})
    result=assess(records,a.mode,a.count,a.seconds,a.hz,a.hw,a.require_zero_fxdrop)
    if parse_errors:
        result['failure_reasons'].append('malformed_capture_records');result['status']='FAIL';result['passed_target_fps']=result['passed_60fps']=False
        result['hardware_status']='FAIL';result['capture_quality']='ERROR';result['acceptance_failure_reasons'].append('malformed_capture_records')
    result.update(source_log=str(a.log.resolve()),source_bytes=len(payload),source_sha256=hashlib.sha256(payload).hexdigest(),parse_errors=parse_errors,start_utc=a.start_utc,hardware_accessed=False)
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','hardware_status','capture_quality','visual_status','steady_windows','measured_us','observed_same_configuration_swaps','weighted_fps','counter_continuity_pass','missed_sum','underflow_sum','cosmetic_fxdrop_total','failure_reasons','capture_quality_warnings','warnings')},indent=2))
    return 0 if result['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
