#!/usr/bin/env python3
"""Production elapsed helper with actual fixed100MHz CLINT tick conversion."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=ap.parse_args()
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
B=R/'build/frame_clock';B.mkdir(parents=True,exist_ok=True)
source=(R/'src/game.c').read_text(encoding='utf-8-sig')
assert 'uint32_t delta=frame_elapsed_us(now,last);last=now;' in source
prefix=(R/'tests/phase_gameplay.c').read_text(encoding='utf-8-sig').split('static int failures;',1)[0]
old='uint32_t bb_us(uint64_t t) { return (uint32_t)t; }';assert old in prefix
prefix=prefix.replace(old,'uint32_t bb_us(uint64_t t) { return (uint32_t)(t/100u); }')
for name,args in [('scene_hud_begin','void'),('scene_hud_end','void'),('scene_hud_invalidate','void'),('scene_hud_cache_enable','unsigned enabled')]:
    if ('void '+name+'(') not in prefix:prefix+='\nvoid '+name+'('+args+') {'+('(void)enabled;' if 'enabled' in args else '')+'}\n'
host=B/'frame_clock_host.c';host.write_text(prefix+'\n#include "frame_clock_body.h"\n',encoding='utf-8');exe=B/'frame_clock_host.exe'
cmd=cc+['-std=gnu11','-O2','-UNDEBUG','-Wall','-Wextra','-Wno-unused-function','-Wno-unused-parameter','-Wno-misleading-indentation','-Isrc','-Itests/stub','-Itests',str(host),'src/stage.c','src/battle.c','src/player.c', 'src/enemies.c','src/layer_visuals.c','src/effects.c','src/game_config.c','src/font.c','src/replay.c','src/remote_input.c','-o',str(exe)]
p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=60);log=p.stdout+p.stderr;code=p.returncode
if not code:
    p=subprocess.run([str(exe)],cwd=R,capture_output=True,text=True,timeout=60);log+=p.stdout+p.stderr;code=p.returncode
print(log,end='');status='PASS' if not code and 'ALL_FRAME_CLOCK_PASS' in log else 'FAIL'
(R/'results/frame_clock_test.json').write_text(json.dumps({'status':status,'hardware_accessed':False,'game_source_sha256':hashlib.sha256(source.encode()).hexdigest(),'conversion':'uint32_t(ticks/100), matching fixed100MHz CLINT','command':cmd,'exit_code':code,'output':log,'scope':'Production helper arithmetic and real runtime step counts under controlled host time. Not physical scanout or a new600s board result.'},indent=2),encoding='utf-8')
raise SystemExit(0 if status=='PASS' else 1)
