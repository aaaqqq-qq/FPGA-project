from pathlib import Path
import ctypes as C,re,subprocess,json
r=Path(__file__).resolve().parents[1]
subprocess.run([r'D:\MinGW\mingw-w64\mingw64\bin\gcc.exe','-shared','-O2','-Isrc','src/stage.c','src/battle.c','-o','build/near_test.dll'],check=True,cwd=r)
lib=C.CDLL(str(r/'build/near_test.dll'))
cap=int(re.search(r'SHOT_CAPACITY (\d+)',(r/'src/stage.h').read_text())[1])
class Shot(C.Structure):_fields_=[('x',C.c_int32),('y',C.c_int32),('vx',C.c_int16),('vy',C.c_int16),('age',C.c_uint16),('tile',C.c_uint8),('grazed',C.c_uint8)]
class Stage(C.Structure):_fields_=[('shots',Shot*cap),('count',C.c_uint)]
st=Stage.in_dll(lib,'stage');count=C.c_uint.in_dll(lib,'stage_near_count');ids=(C.c_uint*512).in_dll(lib,'stage_near_indices')
lib.stage_stress(cap)
checks=0
for f in range(200):
 px=16+(f*71)%992;py=24+(f*43)%640
 lib.stage_stress_step_near(px,py)
 assert lib.stage_near_ready(px,py)
 candidates=set(ids[:count.value]);assert len(candidates)==count.value
 for dx,dy in ((-16,-16),(16,-16),(-16,16),(16,16),(0,0)):
  assert lib.stage_near_ready(px+dx,py+dy)
  for i,b in enumerate(st.shots):
   if abs(b.x//4096-px-dx)<14 and abs(b.y//4096-py-dy)<14:assert i in candidates
  checks+=1
 assert not lib.stage_near_ready(px+17,py)
# Degenerate clustered scene must fall back instead of dropping collisions.
for n in (511,512,513):
 lib.stage_stress(n)
 for i in range(n):st.shots[i].x=512*4096;st.shots[i].y=620*4096;st.shots[i].vx=st.shots[i].vy=0
 lib.stage_stress_step_near(512,620)
 assert bool(lib.stage_near_ready(512,620))==(n<=512)
 assert count.value==min(n,512)
result={'passed':True,'capacity':cap,'full_scan_comparisons':checks,'max_next_move':16,'graze_radius':14,'candidate_radius':32,'overflow_fallback':True}
(r/'results/near_candidates.json').write_text(json.dumps(result,indent=2));print(result)
