"""Load ELF, compare every file-backed LOAD byte, then resume VexRiscv.

The supplied VexRiscv OpenOCD target does not implement checksum_memory,
so verify_image cannot be used. A failed readback leaves the CPU halted.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess

p=argparse.ArgumentParser()
p.add_argument('--elf',required=True)
p.add_argument('--config-dir',required=True)
p.add_argument('--openocd',required=True)
p.add_argument('--output',required=True)
a=p.parse_args()
elf=Path(a.elf).resolve()
cfgdir=Path(a.config_dir).resolve()
out=Path(a.output).resolve()
out.mkdir(parents=True,exist_ok=True)
data=elf.read_bytes()
if data[:6]!=b'\x7fELF\x01\x01':raise SystemExit('Expected little-endian ELF32')
hdr=struct.unpack_from('<16sHHIIIIIHHHHHH',data)
if hdr[2]!=243:raise SystemExit('Expected RISC-V ELF')
entry,phoff,phentsize,phnum=hdr[4],hdr[5],hdr[9],hdr[10]
segments=[]
for i in range(phnum):
    typ,offset,vaddr,paddr,filesz,memsz,flags,align=struct.unpack_from('<IIIIIIII',data,phoff+i*phentsize)
    if typ==1 and filesz:
        if offset+filesz>len(data):raise SystemExit('Truncated ELF segment')
        segments.append((i,paddr,data[offset:offset+filesz]))
if not segments:raise SystemExit('ELF has no file-backed LOAD segments')
prefix='source [find ftdi_ti.cfg]\nsource [find debug_ti.cfg]\ntargets fpga_spinal.cpu0\nhalt\n'
loadcfg=out/'load_readback.cfg'
loadcfg.write_text(prefix+f'load_image {{{elf.as_posix()}}}\n'+''.join(
    f'dump_image {{{(out/f"segment_{i}.readback.bin").as_posix()}}} 0x{addr:x} {len(expected)}\n'
    for i,addr,expected in segments)+'shutdown\n',encoding='ascii')
def run(config,logname):
    result=subprocess.run([a.openocd,'-s',str(cfgdir),'-f',str(config)],cwd=cfgdir,
        stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,errors='replace',timeout=90)
    (out/logname).write_text(result.stdout,encoding='utf-8')
    print(result.stdout,flush=True)
    if result.returncode:raise SystemExit(result.returncode)
run(loadcfg,'load_readback.log')
checks=[]
for i,addr,expected in segments:
    actual=(out/f'segment_{i}.readback.bin').read_bytes()
    if actual!=expected:raise SystemExit(f'READBACK MISMATCH at segment {i}; CPU left halted')
    checks.append({'address':hex(addr),'bytes':len(expected),'sha256':hashlib.sha256(actual).hexdigest()})
    print(f'PASS full readback: {len(expected)} bytes at 0x{addr:x}',flush=True)
(out/'readback_report.json').write_text(json.dumps({'elf':str(elf),'elf_sha256':hashlib.sha256(data).hexdigest(),
    'entry':hex(entry),'verified':True,'segments':checks},indent=2),encoding='utf-8')
resume=out/'resume.cfg'
resume.write_text(prefix+f'resume 0x{entry:x}\nshutdown\n',encoding='ascii')
run(resume,'resume.log')
