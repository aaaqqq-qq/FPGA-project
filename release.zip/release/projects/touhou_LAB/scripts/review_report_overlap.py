"""Write a local offline candidate receipt; never a READY/release seal."""
from pathlib import Path
import json,hashlib,struct,difflib,datetime

P=Path(__file__).resolve().parents[1];B=P.parent/'game60_pipe5_fontclip_fw_20261103'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=P/'results/verification_reportoverlap_final.json';tests=P/'results/report_overlap/20261103_164837/summary.json'
j=json.loads(v.read_text());t=json.loads(tests.read_text())
assert all(j[x]['status']=='PASS' for x in ['implementation','host_tests','rv32_build'])
assert len(j['host_tests']['tests'])==48 and not j['host_tests']['failed'] and not j['host_tests']['not_run']
assert t['status']=='PASS'
for name,digest in t['source_sha256'].items():assert H(P/name)==digest,name
for name,digest in t['golden_source_sha256'].items():assert H(B/name)==digest,name
changed=[p.name for p in (P/'src').iterdir() if p.is_file() and H(p)!=H(B/'src'/p.name)]
assert set(changed)=={'game.c','game_load.inc','pipe5_runtime.inc'}
for golden in tests.parent.glob('golden_*frames*.stdout.log'):
 candidate=golden.with_name(golden.name.replace('golden_','candidate_',1))
 assert golden.read_bytes()==candidate.read_bytes(),golden.name
assert (tests.parent/'unit_golden_10.stdout.log').read_bytes()==(tests.parent/'unit_candidate_10.stdout.log').read_bytes()
raw_inputs=set(p for p in tests.parent.iterdir() if p.is_file())
raw_inputs.update(P/x['log'] for x in j['host_tests']['tests'].values())
raw_inputs.update([P/'results/verify_reportoverlap_final.stdout.log',P/'results/verification_attempt1_preserved/FAILURE_RECEIPT.json'])
raw_evidence={str(p.relative_to(P)):{'sha256':H(p),'bytes':p.stat().st_size} for p in sorted(raw_inputs)}
diff=''
for name in sorted(changed):
 diff+=''.join(difflib.unified_diff((B/'src'/name).read_text().splitlines(True),(P/'src'/name).read_text().splitlines(True),fromfile='F286/src/'+name,tofile='candidate/src/'+name))
(P/'evidence/REPORTOVERLAP_PRODUCT.diff').write_text(diff)
elf=P/'build/rumia.elf';b=elf.read_bytes();h=struct.unpack_from('<16sHHIIIIIHHHHHH',b)
loads=[struct.unpack_from('<IIIIIIII',b,h[5]+i*h[9]) for i in range(h[10])];loads=[x for x in loads if x[0]==1]
assert len(loads)==1 and loads[0][5]<=1044480
receipt={'status':'OFFLINE_CANDIDATE_PASS_NOT_SEALED_NOT_FLASHED','created_at':datetime.datetime.now().isoformat(),'parent_root':str(B),'candidate_root':str(P),
 'changed_product_files':changed,'source_sha256':t['source_sha256'],'parent_source_sha256':t['golden_source_sha256'],
 'verification':{'path':str(v.relative_to(P)),'sha256':H(v),'host_groups':48},'special_tests':{'path':str(tests.relative_to(P)),'sha256':H(tests),'cases':t['tests']},
 'independent_observations':{'path':'results/report_overlap/20261103_164837/INDEPENDENT_OBSERVATIONS.json','sha256':H(P/'results/report_overlap/20261103_164837/INDEPENDENT_OBSERVATIONS.json')},
 'test_script_sha256':H(P/'scripts/test_report_overlap.py'),'ELF':{'path':'build/rumia.elf','sha256':H(elf),'load_file_bytes':loads[0][4],'RAM_used_including_4096_stack':loads[0][5],'RAM_capacity':1044480,'remaining':1044480-loads[0][5]},
 'snapshot_bytes':392,'physical_FPS':'NOT_RUN','physical_Flash':'NOT_RUN','cold_boot':'NOT_RUN','hardware_accessed':False,
 'raw_evidence':raw_evidence,
 'preserved_failure':'results/verification_attempt1_preserved/FAILURE_RECEIPT.json',
 'limits':['Actual C286 periodic-miss correlation is not causal proof.','Native model uses full raster but synthetic time, so does not establish physical FPS.','Compiler stack records are per-function only; no physical stack watermark.','Inherited F286 evidence in this work copy is historical and not a new release authority.']}
(P/'evidence/REPORTOVERLAP_OFFLINE_REVIEW.json').write_text(json.dumps(receipt,indent=2))
readme='''# GAME_LOAD report overlap 离线候选

该独立候选从冻结F286复制，未修改F286、RTL、100MHz、数量/画质、计数窗口、预热或验收门槛。尚未封存、安装、烧录或测量实板性能。

post-swap每60帧只复制392B报告快照，并在原16槽回复队列预留4个FIFO位置。下一pipe_frame在R/M提交后格式化STAT、DETAIL、PIPE、VIEW并填入原位置，全部完成后允许输出。格式器只读取独立快照，不交换gl；final/cancel先填完旧sample再追加最终日志。直接fatal先排空旧sample，再输出FAIL。重复pending和捕获时队列容量不足立即failclosed。

原始C286长测370459283的累计60→600帧missed=0..9，rendermax≤16461us、late=0、UF=0；9次中间sample与9次额外scan强相关，缺少逐帧R-start记录，尚不能证明因果。若它们确由报告串行开销触发，本优化最多回收该600帧窗口的9次额外scan，约150ms；实板收益待实测。

验证：原48主机组及RV32构建通过。专项与冻结F286比较8px20k及32px5k各600帧，6Boss12mob、native fast=0完整光栅；9组中间sample与final、每帧完整8MiB双bank和完整游戏状态SHA一致，完成状态/图像逐字节一致。另有diag61帧、pending未格式化取消、提交后取消、快照污染、FIFO跨尾及满/重复pending测试；全部原始stdout（含诊断）逐字节相同，异常用例按预期拒绝。真实计时仍需实板确认。

`evidence/REPORTOVERLAP_OFFLINE_REVIEW.json`绑定源码、ELF及日志。首轮全套测试在最后写JSON时因调用方多传results/前缀失败，其日志已保留在results/verification_attempt1_preserved；最终只认verification_reportoverlap_final.json。

复现（独立进程，cwd为本目录）：

```
C:/work/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe -X utf8 -B scripts/test_pipe5.py --host-cc E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe
C:/work/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe -X utf8 -B scripts/test_report_overlap.py
C:/work/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe -X utf8 -B scripts/verify_all.py --host-cc E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe --toolchain-bin D:/ELSFPGARSIC-V/toolchain/bin --json verification_reportoverlap_final.json
```

首次fixture依赖同级冻结F286的现有build/pipe5输入；生成源及命令也已完整保存在专项结果目录。第二次全套复现请使用新的JSON名称并保留已有结果。
'''
(P/'REPORTOVERLAP_README.md').write_text(readme,encoding='utf8')
print('OFFLINE_REVIEW',H(P/'evidence/REPORTOVERLAP_OFFLINE_REVIEW.json'),'ELF',H(elf))
