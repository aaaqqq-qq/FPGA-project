from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[1];t=json.loads((r/'results/timing.json').read_text())
bit=r/'hw/game/par/ddr_demo_ti60/outflow/ddr_demo_ti60.bit'
errors=[]
if not t.get('pass'):errors.append('routing/timing report is not passing')
if hashlib.sha256(bit.read_bytes()).hexdigest()!=t['bit_sha256']:errors.append('bitstream differs from verified build')
for name,h in t['source_hashes'].items():
 p=r/name
 if not p.is_file()or hashlib.sha256(p.read_bytes()).hexdigest()!=h:errors.append(name)
if errors:raise SystemExit('Hardware source/build mismatch; run build_hardware.ps1: '+', '.join(errors))
print('PASS hardware source hashes and verified bitstream match')
