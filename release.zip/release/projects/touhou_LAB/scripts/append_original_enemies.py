#!/usr/bin/env python3
"""Append original ANM fairies after tile82; never retrain the existing palette."""
from pathlib import Path
import ast,hashlib,json,re,struct
from PIL import Image

def sha(data):return hashlib.sha256(data).hexdigest()
def array(text,name):
 m=re.search(r'static const \w+ '+name+r'\[\d+\] = \{\n(.*?)\n\};',text,re.S)
 if not m:raise ValueError('missing '+name)
 return m,[int(v) for v in re.findall(r'\d+',m.group(1))]
def original_loader(root):
 source=(root/'scripts/prepare_stage.py').read_text()
 node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='load_tile')
 env={'DATA':root/'assets/source','Image':Image,'struct':struct,'hashlib':hashlib,'tiles':[],'manifest':{'assets':[]}}
 exec(compile(ast.Module(body=[node],type_ignores=[]),'prepare_stage.py::load_tile','exec'),env)
 return env['load_tile']
def append_original_enemies(root,loader=None):
 root=Path(root);path=root/'src/art_data.h';text=path.read_text();pm,palette=array(text,'art_palette');xm,pixels=array(text,'art_pixels')
 tm=re.search(r'static const Tile tiles\[\] = \{\n(.*?)\};',text,re.S)
 desc=[tuple(map(int,v)) for v in re.findall(r'\{(\d+),(\d+),(\d+)\}',tm.group(1))]
 if len(desc) not in (83,91):raise ValueError('expected old83 or already-appended91')
 old_desc=desc[:83];old_count=old_desc[-1][0]//4+old_desc[-1][1]*old_desc[-1][2];old_pixels=pixels[:old_count]
 before={'palette_sha256':sha(struct.pack('<%dI'%len(palette),*palette)),'tiles83_sha256':sha(b''.join(struct.pack('<IHH',*v) for v in old_desc)),'pixels83_sha256':sha(bytes(old_pixels)),'pixels83_count':old_count}
 pixels=old_pixels[:];desc=old_desc[:];off=len(pixels)*4
 loader=loader or original_loader(root);data=root/'assets/source';name='th06e_ST.DAT__stg2enm'
 colors=[((v>>16)&255,(v>>8)&255,v&255) for v in palette];nearest={};manifest=[]
 out=root/'assets/generated/original_enemies';out.mkdir(parents=True,exist_ok=True);sheet=Image.new('RGBA',(240,30))
 for tile_id,sid,label in [(83+i,i,'FAIRY_BLUE'+str(i)) for i in range(4)]+[(87+i,8+i,'FAIRY_PINK'+str(i)) for i in range(4)]:
  loader(name,sid,label);env=loader.__globals__;_,im,mask=env['tiles'][-1];meta=env['manifest']['assets'][-1]
  if im.size!=(30,30) or mask.size!=im.size:raise ValueError('original fairy rectangle must be30x30')
  packed=[];rgba=[]
  for rgb,a in zip(im.getdata(),mask.getdata()):
   if a<48:ix=0
   else:
    if rgb not in nearest:
     nearest[rgb]=min(range(1,256),key=lambda j:sum((rgb[k]-colors[j][k])**2 for k in range(3)))
    ix=nearest[rgb]
   packed.append(ix);rgba.append((*colors[ix],255 if ix else 0))
  desc.append((off,30,30));pixels.extend(packed);off+=3600
  preview=Image.new('RGBA',(30,30));preview.putdata(rgba);preview.save(out/(label.lower()+'.png'));sheet.paste(preview,((tile_id-83)*30,0))
  manifest.append({'tile':tile_id,'label':label,'source_sprite_id':sid,'rect':meta['rect'],'w':30,'h':30,'alpha_threshold':48,'indexed_sha256':sha(bytes(packed))})
 assert len(desc)==91 and pixels[:old_count]==old_pixels and desc[:83]==old_desc
 # Keep palette text byte-for-byte. Only array length/tail and new descriptor rows change.
 newx='static const uint8_t art_pixels[%d] = {\n%s\n};'%(len(pixels),'\n'.join(','.join(str(x)for x in pixels[i:i+16])+','for i in range(0,len(pixels),16)))
 text=text[:xm.start()]+newx+text[xm.end():]
 text=re.sub(r'static const Tile tiles\[\] = \{\n.*?\};','static const Tile tiles[] = {\n'+''.join('{%d,%d,%d},\n'%d for d in desc)+'};',text,flags=re.S)
 text=re.sub(r'#define ART_BYTES \d+u','#define ART_BYTES %du'%off,text);path.write_text(text)
 ids=root/'src/art_ids.h';st=ids.read_text();st=re.sub(r'    ART_FAIRY_(?:BLUE|PINK)\d = \d+,\n','',st)
 additions=''.join('    ART_%s = %d,\n'%(m['label'],m['tile']) for m in manifest)
 st=re.sub(r'    ART_TILE_COUNT = \d+',additions+'    ART_TILE_COUNT = 91',st);ids.write_text(st)
 _,after_palette=array(text,'art_palette');_,after_pixels=array(text,'art_pixels')
 assert after_palette==palette and after_pixels[:old_count]==old_pixels
 report={'status':'PASS','source_name':name,'source_sha256':{ext:sha((data/(name+ext)).read_bytes())for ext in ['.anm','.png','_a.png']},'old83_prefix':before,'palette_unchanged':True,'tiles83_unchanged':True,'pixels83_unchanged':True,'alpha_threshold':48,'quantization':'nearest squared RGB distance among existing opaque palette1..255; no retraining/dithering','tile_count':91,'art_bytes':off,'assets':manifest}
 sheet.save(out/'fairy_contact_sheet.png');(out/'manifest.json').write_text(json.dumps(report,indent=2));(root/'results/original_enemies_prefix.json').write_text(json.dumps(report,indent=2))
 ex=root/'results/extraction.json'
 if ex.exists():
  old=json.loads(ex.read_text());old['original_enemies']=manifest;old['tile_count']=91;old['rom_pixel_bytes']=len(pixels);old['ddr_tile_bytes']=off
  ex.write_text(json.dumps(old,indent=2,ensure_ascii=False))
 print('ORIGINAL_ENEMIES PASS old83 palette/descriptor/pixel prefix unchanged; tiles91, bytes',off)
 return report
if __name__=='__main__':append_original_enemies(Path(__file__).resolve().parents[1])
