"""Real battle dispatch, real128-byte driver codec and native DMA backing.
The mock actually reads/writes each submitted mapped region; CPU reference
operates on independent buffers. This is protocol/state evidence, not RTL/FPS.
"""
from pathlib import Path
import argparse,ast,ctypes,hashlib,json,os,re,shlex,shutil,subprocess,time,sys
P=Path(__file__).resolve().parents[1]
BASE=Path('E:/Ti60_builds/game60_release3_20261102/TI60_GAME60_SW3HUD_20261102/projects/touhou_LAB')
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default='E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe');ap.add_argument('--baseline-root',type=Path,default=BASE);a=ap.parse_args();BASE=a.baseline_root
O=P/'build/motion_hw';O.mkdir(parents=True,exist_ok=True);(P/'results/motion_hw').mkdir(exist_ok=True)
CC=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen={str(p):H(p) for root in [BASE,P] for p in (root/'src').glob('*') if p.is_file()}
assert H(BASE/'src/battle.c')=='33785bd2b30b93c7cfc734ba5c0f82eb662659ab6a688829e3461396390364d1'
assert H(P/'src/motion_abi.h')=='a799ec1effedc74a42087c55d0ad5ce22ca571f47b15d544dd8554021a362fbd'
def literals(path,names):
 t=ast.parse(path.read_text('utf-8-sig'));return {n.targets[0].id:ast.literal_eval(n.value) for n in t.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in names}
parts=literals(P/'scripts/test_tick_profile.py',['core','private']);core,private=parts['core'],parts['private']
fixture=literals(P/'scripts/test_sw3_state.py',['FIXTURE_CODE'])['FIXTURE_CODE']
core+=r'''
__declspec(dllexport) void backend_cpu_render(unsigned yes){hardware=!yes;}
static char backend_reply[512];
static const char *backend_find_reply(const char *prefix){
 backend_reply[0]=0;
 for(unsigned i=0;i<command_reply_count;++i){const char *p=command_replies[(command_reply_head+i)%COMMAND_REPLY_CAP];if(!strncmp(p,prefix,strlen(prefix)))snprintf(backend_reply,sizeof backend_reply,"%s",p);}
 drain_queue();return backend_reply;
}
__declspec(dllexport) const char *backend_caps(void){drain_queue();cli(":hello\n");return backend_find_reply("CAPS ");}
__declspec(dllexport) const char *backend_finish(void){drain_queue();game_load_finish("CANCEL","fixture_end");return backend_find_reply("MOTION_DIAG ");}
'''
backend=(P/'tests/motion_hw/backend.inc').read_text()
reference=P/'tests/motion_hw/reference_kernel.c'
shutil.copy2(reference,O/'reference_kernel.c')
libs=[];commands=[]
for name,root,hardware in [('baseline',BASE,False),('candidate',P,True)]:
 game=(root/'src/game.c').read_text('utf-8-sig')
 fatal=r'void fatal\(const char \*where,int error\)\{.*?for\(;;\)\{\}\}'
 assert len(re.findall(fatal,game))==1
 game=re.sub(fatal,'void fatal(const char *where,int error){host_test_fatal(where,error);}',game)
 gamefile=O/(name+'_game.c');gamefile.write_text(game,encoding='utf8')
 prefix=(root/'tests/phase_gameplay.c').read_text('utf-8-sig').split('static int failures;',1)[0]
 prefix=prefix.replace('#include "game.c"','void host_test_fatal(const char *,int);\n#include "'+gamefile.as_posix()+'"')
 prefix=prefix.replace('static uint64_t host_ticks;','uint64_t host_ticks;unsigned host_bb_reads;')
 for fn in ['bb_read','bb_write','bb_ticks','bb_us','bb_publish','bb_acquire']:
  prefix,n=re.subn(r'^.*\b'+fn+r'\([^\n]*\{[^\n]*\}\s*$', '',prefix,flags=re.M);assert n==1,(fn,n)
 prefix=prefix.replace('unsigned uart_writeAvailability(unsigned u) { (void)u; return 0; }','unsigned uart_writeAvailability(unsigned u) { (void)u; return 128; }')
 for fn,arg in [('scene_hud_begin','void'),('scene_hud_end','void'),('scene_hud_invalidate','void'),('scene_hud_cache_enable','unsigned enabled')]:
  if 'void '+fn+'(' not in prefix:prefix+='\nvoid '+fn+'('+arg+'){}\n'
 host=O/(name+'_host.c');host.write_text(prefix+core,encoding='utf8')
 source=(root/'src/battle.c').read_text('utf-8-sig')
 source=source.replace('static void simulate_bullets_relevant(int px, int py) {','static void cpu_relevant_body(int px, int py) {')
 needle='static void simulate_bullets(int px,int py){';assert source.count(needle)==1
 source=source.replace(needle,'static void simulate_bullets_relevant(int px,int py){++mock_cpu_calls;cpu_relevant_body(px,py);}\n'+needle+'\n    ++mock_dispatch_calls;')
 battle=O/(name+'_battle.c');battle.write_text('static unsigned mock_cpu_calls,mock_dispatch_calls;\n'+source,encoding='utf8')
 extra=O/(name+'_private.c');extra.write_text(private.replace('BATTLE',battle.as_posix()).replace('EFFECTS',(root/'src/effects.c').as_posix()).replace('ENEMIES',(root/'src/enemies.c').as_posix())+fixture+'\n'+backend,encoding='utf8')
 cmd=CC+['-std=gnu11','-O2','-shared','-UNDEBUG','-Wno-misleading-indentation','-I'+str(root/'src'),'-I'+str(P/'src'),'-I'+str(root/'tests'),'-I'+str(root/'tests/stub'),str(host),str(extra),str(O/'reference_kernel.c')]
 if hardware:cmd+=['-DMOTION_HW_HOST_TEST',str(P/'src/motion_hw.c')]
 cmd += [str(root/'src'/n) for n in ['stage.c','player.c','layer_visuals.c','game_config.c','font.c','replay.c','remote_input.c']]
 dll=O/(name+'.dll');cmd+=['-o',str(dll)];q=subprocess.run(cmd,cwd=P,capture_output=True,text=True)
 (O/(name+'_compile.log')).write_text(q.stdout+q.stderr,encoding='utf8');assert not q.returncode,(name,q.stderr)
 commands.append(cmd);l=ctypes.CDLL(str(dll));l.public_snapshot.restype=l.private_snapshot.restype=ctypes.c_void_p;l.real_hash.restype=ctypes.c_uint32;l.backend_failure.restype=l.backend_caps.restype=l.backend_finish.restype=ctypes.c_char_p;libs.append(l)
B,C=libs;sz=B.public_bytes();pz=B.private_bytes();assert C.public_bytes()==sz and C.private_bytes()==pz
print('MOTION_HW compiled true baseline and driver, snapshot bytes',sz+pz,flush=True)
checks=0;paths=[];faults=[];start=time.perf_counter()
def compare(tag):
 global checks
 before=ctypes.string_at(B.public_snapshot(),sz)+ctypes.string_at(B.private_snapshot(),pz)
 after=ctypes.string_at(C.public_snapshot(),sz)+ctypes.string_at(C.private_snapshot(),pz)
 assert before==after,(tag,next(i for i,(a,b) in enumerate(zip(before,after)) if a!=b))
 assert B.real_hash()==C.real_hash(),tag;checks+=1
def metric(l):return [l.backend_metric(i) for i in range(11)]

for side,n in [(8,20000),(32,5000)]:
 for cap,cpu in [(0,0),(30,0),(30,1)]:
  print('runtime',side,n,cap,cpu,flush=True)
  for l in libs:l.init_case(n,side,123456789,1,0);l.backend_cpu_render(cpu);l.backend_set(cap,0,1)
  caps=C.backend_caps().decode();assert f'motion={1 if cap&16 else 0} pref={1 if cap&8 else 0}' in caps,caps
  compare(('runtime_init',side,cap,cpu))
  for tick in range(80):
   assert B.backend_checked_runtime(tick,1)==C.backend_checked_runtime(tick,1)==0
   compare(('runtime',side,cap,cpu,tick))
   m=metric(C);expected=(tick+1) if cap and not cpu else 0
   assert m[0]==expected and m[5]==tick+1 and m[4]==(0 if expected else tick+1),(side,cap,cpu,tick,m)
   if expected:assert m[6]==m[7]==n and m[8:10]==[1,1] and m[1]==m[2]==m[3]==expected
  paths.append({'kind':'runtime_GLOAD','size':side,'N':n,'cap':cap,'CPU_render':bool(cpu),'ticks':80,'candidate_metrics':metric(C)})
  B.backend_finish();diagnostic=C.backend_finish().decode();assert f'submitted={expected} completed={expected}' in diagnostic,diagnostic
  paths[-1].update(CAPS=caps,MOTION_DIAG=diagnostic)
 for which in range(9):
  print('fixture',side,which,flush=True)
  for l in libs:l.fixture_init(n,side,which,1,0);l.backend_set(30,0,1)
  compare(('fixture_init',side,which))
  for tick in range(3):
   assert B.backend_checked_tick(512,620)==C.backend_checked_tick(512,620)==0
   compare(('fixture',side,which,tick));m=metric(C);assert m[0]==tick+1 and m[4]==0 and m[5]==tick+1 and m[6]==m[7]
   assert m[8:10]==[1,1]
  paths.append({'kind':'edge_fixture','size':side,'N':n,'fixture':which,'ticks':3,'candidate_metrics':metric(C)})

# Unsupported mode/size falls back only before any CMD. Legacy/near0/gather0
# retain the actual original dispatcher body and exact scratch behavior.
for near,legacy,gather,side in [(0,0,1,8),(1,1,1,8),(1,0,0,8),(1,0,1,64)]:
 for l in libs:l.fixture_init(257,side,0,near,legacy);l.backend_set(30,0,1)
 for l in libs:
  if gather:l.fixture_tick(512,620,1)
  else:l.fixture_tick(512,620,0)
 compare(('fallback',near,legacy,gather,side));assert C.backend_metric(0)==0
 paths.append({'kind':'unsupported_preCMD_fallback','near':near,'legacy':legacy,'gather':gather,'size':side})

for fault in range(1,24):
 print('fault',fault,flush=True)
 child=f'import ctypes;f=ctypes.CDLL({str(O/"candidate.dll")!r});f.fixture_init(64,8,0,1,0);f.backend_set(30,{fault},1);f.backend_checked_tick(512,620)'
 q=subprocess.run([sys.executable,'-c',child],capture_output=True,text=True)
 (P/f'results/motion_hw/fault_{fault:02d}.log').write_text(q.stdout+q.stderr,encoding='utf8')
 assert q.returncode==90,(fault,q.returncode,q.stdout,q.stderr)
 m=re.search(r'where=(.*?) cmd=(\d+) cpu=(\d+) dispatch=(\d+) invalidates=(\d+) acquires=(\d+) partial_changed=(\d+)',q.stderr);assert m,(fault,q.stderr)
 where=m[1];values=list(map(int,m.groups()[1:]));cmd,cpu,dispatch,invalidates,acquires,changed=values
 assert cpu==0 and dispatch==1 and invalidates==1 and cmd==(0 if fault in [22,23] else 1),(fault,values)
 if fault==20:assert changed==1
 faults.append({'injection':fault,'fatal':where,'actual_cmd':cmd,'actual_dispatch':dispatch,'scene_cache_invalidated':invalidates,'actual_acquire':acquires,'array_changed_before_partial_error':changed,'CPU_replay_calls':cpu,'child_exit':q.returncode})
for f,h in frozen.items():assert H(Path(f))==h,f
report={'status':'PASS','scope':'Actual battle dispatch + true128-byte driver/MMIO/DMA codec with independent mapped-buffer oracle; not hardware cycles or FPS','state_points':checks,'bytes_per_point':sz+pz,'state_hash_equal':True,'runtime_ticks':480,'target_arrays_actual_DMA_read_write':True,'cap0_fallback':True,'pure_CPU_forbids_motionHW':True,'faults_failclosed_no_CPU_replay':faults,'paths':paths,'compile_argv':commands,'reference_kernel_sha256':H(O/'reference_kernel.c'),'source_unchanged':frozen,'elapsed_host_seconds':time.perf_counter()-start,'hardware_accessed':False}
(P/'results/motion_hw/summary.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print('MOTION_HW PASS',checks,'full-state points x',sz+pz,'bytes; actual mapped DMA target20k/5k; cap0/CPU/mode fallback;23 failclosed injections; no device')
