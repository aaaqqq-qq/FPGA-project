from pathlib import Path
import time,re,json,hashlib,subprocess
R=Path(__file__).resolve().parents[1];log=R/'results/validation/touhou_uart.log';cmd=R/'results/serial_commands.txt'
def send(s):
 with cmd.open('ab')as f:f.write(s.encode())
def read(start):
 with log.open('rb')as f:f.seek(start);return f.read().decode(errors='replace')
identity={'elf_sha256':hashlib.sha256((R/'build/rumia.elf').read_bytes()).hexdigest(),'flash_written':False}
start=log.stat().st_size;send('y');time.sleep(20)
rows=[{k:int(v)for k,v in re.findall(r'(\w+)=(\d+)',line)}for line in read(start).splitlines()if line.startswith('BATCH_COMPARE')]
assert len(rows)==3 and all(x['errors']==0 and x['battle']==1 for x in rows),rows
(R/'results/original_battle_pixels.json').write_text(json.dumps({**identity,'passed':True,'frames':rows},indent=2));print('Battle CPU/FPGA pixels PASS',flush=True)
result={**identity,'invincible':True,'autoplay':False,'runs':[]}
for rank,duration in enumerate([205,65,65]):
 start=log.stat().st_size;send('n4096\nr'if rank==0 else'd');time.sleep(duration)
 rows=[{k:int(v)for k,v in re.findall(r'(\w+)=(\d+)',line)}for line in read(start).splitlines()if line.startswith('STAT')]
 rows=[x for x in rows if x.get('mode')==1];steady=rows[1:]
 passed=len(steady)>20 and all(5995<=x['fps100']<=6005 and x['uf']==0 and x['missed']==0 and x['rejected']==0 and x['demo']==1 for x in steady)
 result['runs'].append({'difficulty':rank,'seconds':duration,'passed_60fps':passed,'min_bullets':min((x['N']for x in steady),default=0),'max_bullets':max((x['N']for x in steady),default=0),'windows':rows})
 (R/'results/original_battle_board.json').write_text(json.dumps(result,indent=2));print('BATTLE',rank,passed,'max bullets',result['runs'][-1]['max_bullets'],flush=True)
 if not passed:raise SystemExit('Battle performance failed')
send('i');subprocess.run([r'D:\Python312\python.exe','-X','utf8',str(R/'scripts/benchmark_board.py'),'--counts','4096','--seconds','120','--output','original_battle_stress4096.json'],cwd=R,check=True)
send('rmi');print('Finished: original three-boss menu, invincible ON',flush=True)
