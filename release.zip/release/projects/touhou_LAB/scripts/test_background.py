#!/usr/bin/env python3
"""Check the cached integer 2.5D background; no device access."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess,time
r=Path(__file__).resolve().parents[1];out=r/'results/background';out.mkdir(parents=True,exist_ok=True)
p=argparse.ArgumentParser();p.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=p.parse_args()
cc=[v.strip('"')for v in shlex.split(a.host_cc,posix=False)];exe=r/'build'/('background_test.exe' if os.name=='nt' else 'background_test')
cmd=cc+['-O2','-Wall','-Wextra','-Wno-misleading-indentation','-Isrc','tests/background/background_test.c','src/background.c','-o',str(exe)]
report={'status':'IN_PROGRESS','device_access':False};(out/'background_test.json').write_text(json.dumps(report))
try:
 p=subprocess.run(cmd,cwd=r,capture_output=True,text=True);(out/'compile.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
 started=time.perf_counter();p=subprocess.run([str(exe)],cwd=r,capture_output=True,text=True);elapsed=time.perf_counter()-started;(out/'background_test.log').write_text(p.stdout+p.stderr);print(p.stdout,end='');assert p.returncode==0,p.stdout+p.stderr
 report={'status':'PASS','scope':'host determinism, classic-off equivalence, full screen/field boundary and low-contrast/guard tests; no FPGA startup/FPS claim','device_access':False,'command':cmd,'stdout':p.stdout,'host_elapsed_s':elapsed,'cache_bytes':11220,'source_sha256':{f:hashlib.sha256((r/f).read_bytes()).hexdigest()for f in ['src/background.c','src/background.h','src/scene.c','tests/background/background_test.c']}}
except Exception as e:
 report={'status':'FAIL','reason':repr(e),'device_access':False};raise
finally:(out/'background_test.json').write_text(json.dumps(report,indent=2))
print('BACKGROUND_TEST=PASS')
