from pathlib import Path
import subprocess,json,time,re,hashlib
R=Path(__file__).resolve().parents[1]
P=r'D:\Python312\python.exe'
C=R/'results/serial_commands.txt';L=R/'results/validation/touhou_uart.log'
def send(s):
 with C.open('ab') as f:f.write(s.encode('ascii'))
def run(script,*args):subprocess.run([P,'-X','utf8',str(R/'scripts'/script),*args],cwd=R,check=True)
def check(name):
 d=json.loads((R/'results'/name).read_text());assert all(x['passed_60fps'] for x in d['runs']),name
send('v');run('validate_game_board.py');check('game_v2.json')
run('benchmark_board.py','--counts','4096','--cpu','--seconds','24','--output','final720_cpu4096.json')
start=L.stat().st_size;send('x');deadline=time.monotonic()+25
while time.monotonic()<deadline:
 time.sleep(.5)
 with L.open('rb')as f:f.seek(start);t=f.read().decode(errors='replace')
 rows=re.findall(r'BATCH_COMPARE frame=(\d+) N=4096 pixels=(\d+) errors=(\d+) first=(\d+) hash=(\d+)',t)
 if len(rows)>=3:break
assert len(rows)==3 and all(x[2]=='0'for x in rows),t
(R/'results/final720_board_pixels.json').write_text(json.dumps({'passed':True,'elf_sha256':hashlib.sha256((R/'build/rumia.elf').read_bytes()).hexdigest(),'frames':[dict(zip(['frame','pixels','errors','first_error','hash'],map(int,x)))for x in rows]},indent=2))
send('v');run('benchmark_board.py','--counts','4096','--dodge','--seconds','65','--output','final720_dodge4096.json');send('v');check('final720_dodge4096.json')
run('benchmark_board.py','--counts','4096','--seconds','300','--output','final720_4096_endurance.json');check('final720_4096_endurance.json')
send('n4096\ngm')
print('PASS final suite; manual DODGE menu, N4096, Flash unchanged',flush=True)
