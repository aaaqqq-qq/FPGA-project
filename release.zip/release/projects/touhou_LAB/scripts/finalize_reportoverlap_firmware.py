"""Validate and freeze C287 offline authority; never accesses a device.

Creation refuses overwrite. --check verifies the existing immutable receipt and
all inputs again without changing artifacts. Parent visual proofs remain
explicitly historical; current runtime authority is the new full-raster suite.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, difflib, hashlib, json, shutil

F = Path(__file__).resolve().parents[1]
W = F.parent
P = W / 'game60_pipe5_fontclip_fw_20261103'
N = W / 'gui287_native_policy1_20261103/native_policy1_fixture'
H = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
J = lambda p: json.loads(Path(p).read_text('utf-8-sig'))
ELF = '5f9aad31dfd66e75c44be85e32f78f1c51abaf0ad40db2fd5d92f5f1ed8d13f7'
VFY = 'd24a59c57fbbd824b38811cbdae45c268df0feee2cf2cf42d6601667af776e9e'
REVIEW = '33e6c8a207b033fedf1fe7afe7cde5c4adc381fd71884d5f0c1ce4719817fce4'
SPECIAL = '61afd97e06bb5f3656ae863b8449f0726ae1667260f280e7fc8d7101bcd01115'
NATIVE = '5039a86818f701134f3e7e232f60297d34df6574028bdacbda76b2ab3f6aa9f5'
POLICY = 'a8c481c9a52fbf433f64cf4df02586cf5da4f5cf9800ea9b78429ecb4aa8605a'
PRODUCT = {'src/game.c', 'src/game_load.inc', 'src/pipe5_runtime.inc'}


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), f'Refuse overwrite: {path}'
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', 'utf8')


def bind(mapping, root=F, plain_src=False):
    for rel, digest in mapping.items():
        path = root / rel
        if plain_src and not path.exists():
            path = root / 'src' / rel
        assert path.is_file() and H(path) == digest, str(path)


def row(rel, **extra):
    return dict(path=rel, sha256=H(F / rel), **extra)


def validate():
    assert H(F / 'evidence/REPORTOVERLAP_OFFLINE_REVIEW.json') == REVIEW
    r = J(F / 'evidence/REPORTOVERLAP_OFFLINE_REVIEW.json')
    bind(r['source_sha256'])
    bind(r['parent_source_sha256'], P)
    assert len(r['raw_evidence']) == 117
    for rel, item in r['raw_evidence'].items():
        path = F / rel
        assert path.stat().st_size == item['bytes'] and H(path) == item['sha256'], rel
    assert H(F / 'results/verification_reportoverlap_final.json') == VFY
    v = J(F / 'results/verification_reportoverlap_final.json')
    assert all(v[name]['status'] == 'PASS' for name in ('implementation', 'host_tests', 'rv32_build'))
    assert len(v['host_tests']['tests']) == 48 and not v['host_tests']['failed'] and not v['host_tests']['not_run']
    assert all(item['status'] == 'PASS' and item['exit_code'] == 0 for item in v['host_tests']['tests'].values())
    bind(v['source_sha256'])
    i = J(F / 'build/identity.json')
    assert i['status'] == 'PASS' and H(F / 'build/rumia.elf') == i['elf_sha256'] == ELF
    bind(i['sources']); bind(i['scripts'])
    assert i['memory']['ram_remaining_above_reserved_stack'] == 11536
    special_rel = 'results/report_overlap/20261103_164837/summary.json'
    assert H(F / special_rel) == SPECIAL
    s = J(F / special_rel)
    assert s['status'] == 'PASS' and len(s['tests']) == 8
    bind(s['source_sha256']); bind(s['golden_source_sha256'], P)
    for side, count in ((8, 20000), (32, 5000)):
        t = next(t for t in s['tests'] if t.get('side') == side and t.get('mode') == 0 and t.get('diag') == 0)
        assert t['N'] == count and t['frames'] == 600 and t['samples'] == 9
        assert t['protocol_exact'] and t['every_frame_state_and_8MiB_SHA_exact'] and t['completion_bytes_exact'] and not t['fast_raster_skipped']
    obs = J(F / r['independent_observations']['path'])
    assert H(F / r['independent_observations']['path']) == r['independent_observations']['sha256']
    assert all(item['all_stdout_bytes_equal'] for item in obs['all_raw_stdout_comparisons'])
    result_dir = F / Path(special_rel).parent
    # Independent byte checks supplement the specialist's per-frame SHA check.
    for golden in result_dir.glob('golden_*.banks.bin'):
        candidate = golden.with_name(golden.name.replace('golden_', 'candidate_', 1))
        assert golden.read_bytes() == candidate.read_bytes()
    for golden in result_dir.glob('golden_*.state.bin'):
        candidate = golden.with_name(golden.name.replace('golden_', 'candidate_', 1))
        assert golden.read_bytes() == candidate.read_bytes()
    for item in obs['all_raw_stdout_comparisons']:
        assert (result_dir / item['golden']).read_bytes() == (result_dir / item['candidate']).read_bytes()
    # Existing fresh regression summaries bind all current product source.
    fresh = ['results/hud_dma_lifecycle.json', 'results/segment_diag/unit.json',
             'results/segment_diag/native.json', 'results/pipe5/native_main_wire.json']
    for rel in fresh:
        q = J(F / rel)
        assert q['status'] == 'PASS', rel
        if q.get('source_sha256'):
            bind(q['source_sha256'], plain_src=True)
    q = J(F / 'results/pipe5/summary.json')
    assert q['status'] == 'PASS' and q['full_state_points'] == 424
    if q.get('source_sha256'):
        bind(q['source_sha256'], plain_src=True)
    # The lifecycle writer hashes captured CRLF text but its log wrapper stores
    # one additional CRLF. Preserve the original report and account
    # for this exact known representation discrepancy, never rewrite it.
    life = J(F / 'results/hud_dma_lifecycle.json')
    logged = (F / life['log']).read_bytes()
    assert life['log_sha256'] == 'e2dc6084bc4e638bc6fc12984f534523044a01a4187791dff6ad80b1aa6f110a'
    assert H(F / life['log']) == 'c2271fb72fbda5acabbfc430e07b4e9e2dfdcf48c7a49e838a8f1234373b17d0'
    captured = life['output'].replace('\n', '\r\n').encode()
    assert hashlib.sha256(captured).hexdigest() == life['log_sha256']
    assert logged == captured + b'\r\n'
    assert len(logged) == 195 and len(captured) == 193
    assert H(F / 'results/validation/hud_policy1_native_provenance.json') == NATIVE
    assert H(F / 'results/validation/hud_policy1_complete.log') == POLICY
    n = J(F / 'results/validation/hud_policy1_native_provenance.json')
    assert n['status'] == 'INDEPENDENT_POLICY1_PROTOCOL_FIXTURE_NATIVE_PASS'
    assert Path(n['root']).resolve() == F and n['source_inputs_unchanged'] and n['compile_exit'] == n['run_exit'] == 0
    assert n['product_modified'] is False and n['hardware_accessed'] is False
    bind(n['source_inputs'])
    assert H(N / 'REVIEW.json') == NATIVE
    for name, digest in n['raw_logs'].items():
        assert H(N / name) == digest
    assert H(N / 'host.c') == n['fixture_source_sha256']
    assert H(N / 'policy1_fixture.exe') == n['fixture_executable_sha256']
    parent_mf = J(P / 'evidence/FONTCLIP_SOURCE_MANIFEST.json')
    assert H(P / 'evidence/FONTCLIP_SOURCE_MANIFEST.json') == 'e7c6e3f505c22b3061a69fcc829108ae5a054c59e2566115be9f31b6a2813dcd'
    bind(parent_mf, P)
    files = set(parent_mf)
    for sub in ('src', 'scripts', 'tests'):
        files.update(p.relative_to(F).as_posix() for p in (F / sub).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    mf = {rel: H(F / rel) for rel in sorted(files)}
    changed = {rel for rel, sha in mf.items() if rel.startswith('src/') and parent_mf.get(rel) != sha}
    assert changed == PRODUCT, changed
    assert H(F / 'src/font.c') == H(P / 'src/font.c') and H(F / 'src/scene.c') == H(P / 'src/scene.c')
    return r, v, i, s, n, mf


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--check', action='store_true')
    args = ap.parse_args()
    r, v, i, s, n, mf = validate()
    manifest = F / 'evidence/REPORTOVERLAP_SOURCE_MANIFEST.json'
    final = F / 'evidence/REPORTOVERLAP_RELEASE_FINAL_RECEIPT.json'
    review = F / 'evidence/ROOT_REPORTOVERLAP_RELEASE_REVIEW.json'
    if args.check:
        assert J(manifest) == mf
        f = J(final)
        for name in ('ELF', 'identity', 'source_manifest', 'verification', 'native', 'native_log', 'product_diff', 'review_script'):
            assert H(F / f[name]['path']) == f[name]['sha256'], name
        for item in f['extra_evidence']:
            assert H(F / item['path']) == item['sha256']
        q = J(review)
        assert q['final_receipt_sha256'] == H(final) and q['source_manifest_sha256'] == H(manifest)
    else:
        assert not final.exists() and not manifest.exists() and not review.exists()
        parent_rows = []
        # .txt preserves each historical JSON verbatim and prevents generic
        # stage collectors from resolving a parent's build/ path against C287.
        for rel in ('evidence/FONTCLIP_RELEASE_FINAL_RECEIPT.json',
                    'results/font_equivalence/test_result.json',
                    'results/hud_delta/20261103_135659_892687/summary.json'):
            dst = 'evidence/parent_c286/' + rel.replace('/', '__') + '.txt'
            (F / dst).parent.mkdir(parents=True, exist_ok=True)
            assert not (F / dst).exists()
            shutil.copy2(P / rel, F / dst)
            assert H(F / dst) == H(P / rel)
            parent_rows.append(row(dst, scope='HISTORICAL_PARENT_ONLY_NOT_CURRENT_MAIN_AUTHORITY', parent_relative_path=rel))
        save(manifest, mf)
        diff = []
        for rel in sorted(PRODUCT):
            diff.extend(difflib.unified_diff((P / rel).read_text().splitlines(True), (F / rel).read_text().splitlines(True), fromfile='C286/' + rel, tofile='C287/' + rel))
        (F / 'evidence/REPORTOVERLAP_PRODUCT.diff').write_text(''.join(diff), 'utf8')
        raw_rows = [row(Path(rel).as_posix(), bytes=item['bytes']) for rel, item in r['raw_evidence'].items()]
        save(F / 'evidence/REPORTOVERLAP_RAW_FILE_MANIFEST.json', dict(status='ALL117_RAW_HASHES_AND_SIZES_PASS', files=raw_rows))
        life = J(F / 'results/hud_dma_lifecycle.json')
        save(F / 'evidence/REPORTOVERLAP_LIFECYCLE_LOG_RECONCILIATION.json', dict(
            status='EXACT_REPRESENTATION_RECONCILED_ORIGINAL_REPORT_UNMODIFIED',
            report=row('results/hud_dma_lifecycle.json'), actual_log=row(life['log']),
            declared_text_sha256=life['log_sha256'], declared_text_bytes=193, actual_wrapper_bytes=195,
            reason='Report hashes193B captured CRLF text; wrapper adds exactly one2B CRLF. JSON normalizes those lines to LF. Complete captured text is otherwise byte-exact.',
            no_other_exception_allowed=True))
        fresh = ['evidence/REPORTOVERLAP_OFFLINE_REVIEW.json', 'evidence/REPORTOVERLAP_RAW_FILE_MANIFEST.json',
                 'evidence/REPORTOVERLAP_LIFECYCLE_LOG_RECONCILIATION.json',
                 'results/report_overlap/20261103_164837/summary.json',
                 'results/hud_dma_lifecycle.json', 'results/pipe5/summary.json',
                 'results/segment_diag/unit.json', 'results/segment_diag/native.json',
                 'results/pipe5/native_main_wire.json']
        limits = [
            'Exact unchanged 100MHz C286 hardware reused; no RTL or clock modification.',
            'Native full raster uses synthetic time; no physical FPS, Flash or cold-boot claim.',
            'Snapshot392B plus bounded existing16-slot FIFO; input/state/ordered pixel/log equality is offline evidence only.',
            'Parent font1486 and HUD830 reports are historical; font/scene bytes unchanged, current main checked separately for600+600 full-raster frames.',
            'Compiler per-function stack only; no measured board stack watermark or full indirect-call worst-case proof.',
            'First verification JSON-write failure retained; final48-group rerun is the sole complete verification authority.',
            'Lifecycle log writer representation discrepancy is explicitly reconciled by exact path/hash/bytes; original report retained.']
        out = dict(status='FINAL_OFFLINE_PASS_NOT_READY_NOT_FLASHED', created_utc=datetime.now(timezone.utc).isoformat(),
                   implementation='PASS', RV32='PASS', host_groups=48, host_failures=[], host_skips=[],
                   ELF=row('build/rumia.elf'), identity=row('build/identity.json'),
                   source_manifest=row('evidence/REPORTOVERLAP_SOURCE_MANIFEST.json', files=len(mf)),
                   verification=row('results/verification_reportoverlap_final.json'),
                   native=row('results/validation/hud_policy1_native_provenance.json'),
                   native_log=row('results/validation/hud_policy1_complete.log'),
                   extra_evidence=[row(rel, scope='CURRENT_C287_SOURCE_BOUND_OFFLINE') for rel in fresh] + parent_rows,
                   memory=i['memory'], product_diff=row('evidence/REPORTOVERLAP_PRODUCT.diff'),
                   review_script=row('scripts/finalize_reportoverlap_firmware.py'),
                   changed_product_files=sorted(PRODUCT), raw_evidence_files=117,
                   runtime_full_raster_frames=[600, 600], diag_full_raster_frames=61,
                   parent_visual_source_identity={rel: H(F / rel) for rel in ('src/font.c', 'src/scene.c')},
                   board_FPS='NOT_RUN', physical_Flash='NOT_RUN', cold_boot='NOT_RUN', limits=limits)
        save(final, out)
        save(review, dict(status='ROOT_SOURCE_LOG_AND_ELF_REVIEW_PASS', approved_for_offline_image=True,
                         approved_for_physical_FPS=False, ELF_sha256=ELF, source_manifest_sha256=H(manifest),
                         source_files=len(mf), verification_sha256=VFY, final_receipt_sha256=H(final),
                         clock_mhz=100, gameplay_N_Alpha_Key_unchanged=True,
                         reviewer='Root-delegated /root/c287_release_authority: independent source, all117 raw, new native, build identity and exact full-bank/log/state review; root physical adoption is separate.',
                         limits=limits))
    print(json.dumps(dict(status='PASS', ELF=ELF, source_manifest_sha256=H(manifest), source_files=len(mf), verification_sha256=VFY,
                          final_receipt_sha256=H(final), review_sha256=H(review), native_provenance_sha256=NATIVE, native_log_sha256=POLICY,
                          script_sha256=H(Path(__file__))), indent=2))


if __name__ == '__main__':
    main()
