#!/usr/bin/env python3
"""Call real game.c render; model command submission/retained field per bank."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess,sys
from datetime import datetime,timezone
root=Path(__file__).resolve().parents[1];a=argparse.ArgumentParser();a.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));args=a.parse_args();cc=[x.strip('"') for x in shlex.split(args.host_cc,posix=False)]
b=root/'build/terminal_render';b.mkdir(parents=True,exist_ok=True);exe=b/('terminal_render.exe' if os.name=='nt' else 'terminal_render')
cmd=cc+['-std=gnu11','-O2','-UNDEBUG','-Wall','-Wextra','-Wno-unused-function','-Wno-unused-parameter','-Wno-misleading-indentation','-Isrc','-Itests/stub','tests/terminal_render.c','src/stage.c','src/battle.c','src/player.c','src/enemies.c','src/layer_visuals.c','src/effects.c','src/game_config.c','src/font.c','src/replay.c','src/remote_input.c','-o',str(exe)]
p=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=60);log=p.stdout+p.stderr;code=p.returncode
if not code:p=subprocess.run([str(exe)],cwd=root,capture_output=True,text=True,timeout=45);log+=p.stdout+p.stderr;code=p.returncode
ok=not code and 'TERMINAL_RENDER PASS checks=' in log;val=root/'results/validation';val.mkdir(exist_ok=True);(val/'terminal_render.log').write_text(log,encoding='utf-8');print(log,end='')
(root/'results/terminal_render.json').write_text(json.dumps({'status':'PASS' if ok else 'FAIL','generated_utc':datetime.now(timezone.utc).isoformat(),'exit_code':code,'command':cmd,'output':log,'scope':'Actual production render entry with command/retained-field model; tests cache decisions and submissions/HUD. Doesnotreplacefullpixel/RTL/boardverification.','source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['src/game.c','src/scene.c','src/player.c','src/enemies.c','src/layer_visuals.c','tests/terminal_render.c']}},indent=2),encoding='utf-8');sys.exit(0 if ok else 1)
