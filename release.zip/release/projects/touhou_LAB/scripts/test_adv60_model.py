"""Portable frozen-Q8 vs production Q12 equivalence; no device or timing claim."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess,time
r=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser();p.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=p.parse_args();b=r/'build/adv60_model';b.mkdir(parents=True,exist_ok=True)
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)];flags=['-D__USE_MINGW_ANSI_STDIO=1','-std=c11','-O2','-Wall','-Wextra','-Werror','-Wno-misleading-indentation']
renames=['-Dadv_particles_init=old_init','-Dadv_particles_step=old_step']+['-Dadv_'+n+'=old_'+n for n in ['random','color','shape','golden']]
commands=[cc+flags+renames+['-c','tests/adv60_reference/adv_model.c','-o',str(b/'old.o')],cc+flags+['-Isrc','src/adv_model.c','tests/adv60_model_equivalence.c',str(b/'old.o'),'-o',str(b/'model.exe')],[str(b/'model.exe')]]
start=time.monotonic();runs=[]
for cmd in commands:
 q=subprocess.run(cmd,cwd=r,capture_output=True,text=True,timeout=180);out=q.stdout+q.stderr;print(out,end='');runs.append(dict(command=cmd,exit=q.returncode,output=out))
 if q.returncode:break
passed=not runs[-1]['exit'] and 'ADV60_MODEL_PASS' in runs[-1]['output'];names=['src/adv_model.c','src/adv_model.h','tests/adv60_reference/adv_model.c','tests/adv60_reference/adv_model.h','tests/adv60_model_equivalence.c']
report=dict(status='PASS' if passed else 'FAIL',hardware_accessed=False,scope='frozen production Q8 compared everytick to new canonical Q12 state plus stats; dedicated pure-draw unroll tails all57 sizes',elapsed_seconds=round(time.monotonic()-start,3),runs=runs,sha256={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in names})
(r/'results/adv60_model_equivalence.json').write_text(json.dumps(report,indent=2),encoding='utf8');raise SystemExit(0 if passed else 1)
