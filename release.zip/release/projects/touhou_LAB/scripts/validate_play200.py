from pathlib import Path
import subprocess,time,re,json,hashlib
R=Path(__file__).resolve().parents[1];P=r'D:\Python312\python.exe';C=R/'results/serial_commands.txt';L=R/'results/validation/touhou_uart.log'
def send(s):
 with C.open('ab')as f:f.write(s.encode())
def capture(offset):
 with L.open('rb')as f:f.seek(offset);return f.read().decode(errors='replace')
def run(*args):subprocess.run([P,'-X','utf8',str(R/'scripts/benchmark_board.py'),*args],cwd=R,check=True)
def check(name):assert json.loads((R/'results'/name).read_text())['runs'][0]['passed_60fps'],name
report={'elf_sha256':hashlib.sha256((R/'build/rumia.elf').read_bytes()).hexdigest(),'invincible':True,'autoplay':False,'runs':[]}
for name,cmd in [('Normal','i4r'),('Hard','d'),('Lunatic','d')]:
 start=L.stat().st_size;send(cmd);print('INVINCIBLE',name,flush=True);time.sleep(32);t=capture(start)
 rows=[{k:int(v)for k,v in re.findall(r'(\w+)=(\d+)',line)}for line in t.splitlines()if line.startswith('STAT')]
 play=[x for x in rows if x.get('mode')==1];steady=play[1:]
 passed=len(steady)>=3 and all(x['demo']==1 and x['fps100']>=5995 and x['fps100']<=6005 and x['missed']==0 and x['uf']==0 for x in steady) and not any(x.get('mode')==4 for x in rows)and 'FAIL'not in t
 report['runs'].append({'difficulty':name,'passed_60fps':passed,'windows':rows,'no_death_in_demo':not any(x.get('mode')==4 for x in rows)})
 (R/'results/play200_stages.json').write_text(json.dumps(report,indent=2));assert passed,(name,t);print('PASS',name,flush=True)
send('i')
run('--counts','4096','--cpu','--seconds','24','--output','play200_cpu4096.json')
start=L.stat().st_size;send('x');deadline=time.monotonic()+25
while time.monotonic()<deadline:
 time.sleep(.5);t=capture(start);rows=re.findall(r'BATCH_COMPARE frame=(\d+) N=4096 pixels=(\d+) errors=(\d+) first=(\d+) hash=(\d+)',t)
 if len(rows)>=3:break
assert len(rows)==3 and all(x[2]=='0'for x in rows),t
(R/'results/play200_board_pixels.json').write_text(json.dumps({'passed':True,'elf_sha256':report['elf_sha256'],'frames':[dict(zip(['frame','pixels','errors','first_error','hash'],map(int,x)))for x in rows]},indent=2))
send('i');run('--counts','4096','--dodge','--seconds','205','--output','play200_dodge4096.json');check('play200_dodge4096.json')
send('i');run('--counts','4096','--seconds','120','--output','play200_4096_endurance.json');check('play200_4096_endurance.json')
send('4rmi');print('PASS final input/demo suite; Normal menu, invincible ON, no Flash writes',flush=True)
