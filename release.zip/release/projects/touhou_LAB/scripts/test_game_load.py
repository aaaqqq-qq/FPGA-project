"""Production GAME_LOAD parser/runtime/metrics with independent MMIO counter fixtures."""
from pathlib import Path
import argparse,subprocess,json,os,shlex,sys
r=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser();p.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=p.parse_args();cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
b=r/'build/game_load';b.mkdir(parents=True,exist_ok=True)
s=(r/'tests/phase_gameplay.c').read_text(encoding='utf-8-sig').split('static int failures;',1)[0]
s=s.replace('void scene_init(void) {}','static unsigned host_scene_background,host_background_prepares;\nvoid scene_init(void){host_scene_background=game_cfg.background_depth_enabled;++host_background_prepares;scene_bullets_reset();}')
s=s.replace('uint32_t bb_read(unsigned reg) { (void)reg; return 0; }','static unsigned host_scan,host_swap,host_uf;\nuint32_t bb_read(unsigned reg){return reg==BB_FRAMES?host_scan:reg==BB_SWAPS?host_swap:reg==BB_UNDERFLOWS?host_uf:0;}')
for name,args in [('scene_hud_begin','void'),('scene_hud_end','void'),('scene_hud_invalidate','void'),('scene_hud_cache_enable','unsigned enabled')]:
 if ('void '+name+'(') not in s:s+='\nvoid '+name+'('+args+'){}\n'
h=b/'host.c';h.write_text(s+'\n#include "game_load_body.h"\n',encoding='utf-8');exe=b/'test.exe'
cmd=cc+['-std=gnu11','-O2','-UNDEBUG','-Wno-misleading-indentation','-Isrc','-Itests/stub','-Itests',str(h),'src/stage.c','src/battle.c','src/player.c','src/enemies.c','src/layer_visuals.c','src/effects.c','src/game_config.c','src/font.c','src/replay.c','src/remote_input.c','-o',str(exe)]
x=subprocess.run(cmd,cwd=r,capture_output=True,text=True);log=x.stdout+x.stderr;code=x.returncode
if not code:x=subprocess.run([str(exe)],cwd=r,capture_output=True,text=True,timeout=120);log+=x.stdout+x.stderr;code=x.returncode
(r/'results/validation/game_load.log').write_text(log,encoding='utf-8');(r/'results/game_load.json').write_text(json.dumps({'status':'PASS' if not code else 'FAIL','command':cmd,'exit_code':code,'scope':'production game logic and protocol; display/timer stubs; not board FPS','hardware_accessed':False,'output':log},indent=2),encoding='utf-8');print(log);sys.exit(code)
