#!/usr/bin/env python3
"""Line-oriented R2 tuning console. It never compiles, resets or programs a board."""
from pathlib import Path
from datetime import datetime
import argparse
import threading
import serial

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--port',default='COM16')
    a=ap.parse_args()
    folder=Path(__file__).resolve().parents[1]/'results'/'control_sessions'/datetime.now().strftime('%Y%m%d_%H%M%S')
    folder.mkdir(parents=True,exist_ok=True)
    stop=threading.Event()
    uart=serial.Serial(port=None,baudrate=115200,timeout=.1)
    uart.dtr=False;uart.rts=False;uart.port=a.port
    try: uart.open()
    except serial.SerialException as error:
        print('串口未打开，请核对COM号，并关闭其它串口窗口：',error)
        return 1
    print('已连接',a.port,'；日志保存在',folder)
    def receiver():
        pending=b''
        with (folder/'uart.log').open('wb') as log:
            while not stop.is_set():
                try:data=uart.read(max(1,min(uart.in_waiting,4096)))
                except serial.SerialException:
                    stop.set();break
                if not data:continue
                log.write(data);log.flush();pending+=data
                while b'\n' in pending:
                    line,pending=pending.split(b'\n',1)
                    line=line.decode('ascii',errors='replace').rstrip('\r')
                    if not line.startswith(('STAT ','REPLAY_WORD ')):print('\n板卡：',line)
    thread=threading.Thread(target=receiver,daemon=True);thread.start()
    def send(command):
        payload=command.encode('ascii')
        uart.write(payload)
        with (folder/'commands.log').open('a',encoding='utf-8') as log:log.write(repr(command)+'\n')
    try:
        while not stop.is_set():
            print('\n1 正常战  2 FPGA压力  3 CPU对照  4 切换演示无敌  5 调参')
            print('6 录制新局  7 停止录制  8 回放  9 回放状态  10 导出回放')
            print('11 四Boss+六妖精  12 六Boss+十二妖精  13 三Boss基线  0 关闭串口')
            print('14 图层管线开关  15 人物Y排序开关  16 阴影和近景装饰开关')
            print('17 装饰强度（1克制 / 2演示）')
            action=input('选择：').strip()
            if action=='0':break
            if action=='1':send('r\n')
            elif action in ('2','3'):
                count=input('精灵数量（1～20000）：').strip()
                if not count.isdigit() or not 1<=int(count)<=20000:print('数量不合法');continue
                send('mn'+count+'\n'+('s\n' if action=='2' else 'c'))
            elif action=='4':
                send('i');print('查看屏幕确认DEMO状态；真实受击测试前须关闭。')
            elif action=='5':
                field=input('字段（如 hud_dirty_enabled）：').strip()
                value=input('整数值：').strip()
                if not value.isdigit() or not field or any(c not in 'abcdefghijklmnopqrstuvwxyz_0123456789[]' for c in field):
                    print('字段或整数格式不合法');continue
                send(':set '+field+' '+value+'\n')
            elif action=='6':
                seed=input('随机种子（直接回车用1852404840）：').strip() or '1852404840'
                if not seed.isdigit() or int(seed)>0xffffffff:print('种子不合法');continue
                send(':record '+seed+'\n')
            elif action=='7':send(':stop\n')
            elif action=='8':send(':replay\n')
            elif action=='9':send(':replay status\n')
            elif action=='10':send(':replay dump\n');print('等待REPLAY_END；导出内容会保存在uart.log。')
            elif action in ('11','12','13'):
                bosses,mobs={'11':(4,6),'12':(6,12),'13':(3,0)}[action]
                send('m:set boss_count '+str(bosses)+'\n:set enemy_count '+str(mobs)+'\nr\n')
            elif action in ('14','15','16'):
                field={'14':'layer_pipeline_enabled','15':'layer_y_sort','16':'layer_visuals_enabled'}[action]
                value=input('输入1开启，0关闭：').strip()
                if value not in ('0','1'):print('请输入0或1');continue
                send(':set '+field+' '+value+'\n')
            elif action=='17':
                value=input('输入1克制，2演示：').strip()
                if value not in ('1','2'):print('请输入1或2');continue
                send(':set layer_visuals_strength '+value+'\n')
            else:print('请选择列出的编号。')
    except (KeyboardInterrupt,EOFError):pass
    finally:
        stop.set();thread.join(timeout=2);uart.close()
    print('串口已关闭，板卡继续运行。')
    return 0

if __name__=='__main__':raise SystemExit(main())
