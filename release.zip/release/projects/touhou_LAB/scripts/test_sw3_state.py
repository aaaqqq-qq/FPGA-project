"""Targeted F3/SW2/SW3 state regression with exact index-scratch write rules.

Only the 65536-byte contact_index history is eligible for normalization, and
only after every candidate byte has passed its actual path's write rule. The
currently consumed original-path prefixes always equal the frozen reference.
Actual dispatcher entry is observed; stale counts never identify the path.
No production source is edited, and native timer/render stubs are not FPS.
"""
from pathlib import Path
import argparse, ast, ctypes, hashlib, json, os, shlex, subprocess, time

P = Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser()
ap.add_argument('--current-root', type=Path, default=Path('E:/Ti60_builds/game60_sw2_20261102'))
ap.add_argument('--F3-root', type=Path, default=Path('F:/FPGA/BoardStudio272/TI60_GAME_SIZE3_20261101/projects/touhou_LAB'))
ap.add_argument('--host-cc', default=os.environ.get('HOST_CC', 'gcc'))
a = ap.parse_args()
S, F = a.current_root.resolve(), a.F3_root.resolve()
CC = [x.strip('"') for x in shlex.split(a.host_cc, posix=False)]
O = P / 'build/sw3_state'
O.mkdir(parents=True, exist_ok=True)
V = P / 'results/validation'
V.mkdir(parents=True, exist_ok=True)
H = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = {str(p): H(p) for root in [F, S, P] for p in (root / 'src').glob('*') if p.is_file()}

template = ast.parse((P / 'scripts/test_tick_profile.py').read_text('utf-8-sig'))
parts = {n.targets[0].id: ast.literal_eval(n.value) for n in template.body
         if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
         and n.targets[0].id in ['core', 'private']}
core, private = parts['core'], parts['private']
core += r'''
__declspec(dllexport) void sw3_paused_runtime(void){unsigned saved_paused=paused;paused=1;runtime_step();paused=saved_paused;}
'''
FIXTURE_CODE = '\nstatic uint32_t fixture_rng(uint32_t *s){uint32_t v=*s;v^=v<<13;v^=v>>17;v^=v<<5;return *s=v;}\n__declspec(dllexport) void fixture_init(unsigned n,unsigned side,unsigned which,unsigned near,unsigned legacy){\n game_config_defaults();game_cfg.enemy_bullet_size=side;game_cfg.boss_count=6;game_cfg.enemy_count=12;game_cfg.near_enabled=near;\n battle_set_legacy(legacy);battle_reset(1,SHOT_CAPACITY);player_reset(512,620);enemies_reset(12);effects_reset();\n memset(stage.shots,0xa5,sizeof stage.shots);memset(stage.owner,0x5a,sizeof stage.owner);memset(effects,0x96,sizeof effects);\n memset(contact_count,0,sizeof contact_count);memset(contact_index,0x6d,sizeof contact_index);\n stage.count=n;stage.seed=123456789;battle_near_fallbacks=17;battle_load_active=0;uint32_t rng=123456789;\n unsigned radius=game_bullet_radius(),graze=radius+9;\n for(unsigned i=0;i<n;++i){\n  int x=(int)(radius+fixture_rng(&rng)%(ARENA_W-2*radius)),y=(int)(radius+fixture_rng(&rng)%(ARENA_H-2*radius));\n  int16_t vx=(int16_t)fixture_rng(&rng),vy=(int16_t)fixture_rng(&rng);\n  unsigned age=fixture_rng(&rng)%40,delay=i%8,turn=i%4?0:12;\n  unsigned tile=(i*17u)&255u,grazed=i%7?0:((i%5+1)*43u)&255u;\n  if(which==1){x=i&1?ARENA_W-(int)radius:(int)radius;y=i&2?ARENA_H-(int)radius:(int)radius;vx=i&1?4096:-4096;vy=i&2?4096:-4096;turn=delay=0;age=5;}\n  if(which==2||which==3||which==9){x=512;y=which==2?620:which==3?100:(i<4097?620:100);vx=vy=0;turn=delay=0;age=10;grazed=i%3==0?0:i%3==1?2:255;}\n  if(which==4){static const int ys[]={72,73,85,86,98,99,171,172};x=512;y=ys[i%8];vx=vy=0;turn=delay=0;age=10;grazed=0;}\n  if(which==5){int ds[]={-(int)graze-1,-(int)graze,-(int)radius,-1,0,1,(int)radius,(int)graze,(int)graze+1};x=512+ds[i%9];y=620+ds[(i/9)%9];vx=vy=0;turn=delay=0;age=10;grazed=0;}\n  if(which==6){static const unsigned ages[]={0,5,6,17,18,19,65534,65535};age=ages[i%8];delay=6;turn=12;}\n  if(which==7){x=i%3==0?-20:100+(int)(i%700);y=100+(int)(i%400);vx=vy=0;turn=delay=0;age=65535;game_cfg.bullet_age_max=65536;}\n  if(which==8){x=512;y=620;vx=vy=0;turn=0;delay=65535;age=65535;game_cfg.bullet_age_max=65536;grazed=0;}\n  stage.shots[i]=(Shot){x*Q+(int)(i%3),y*Q+(int)(i%5),vx,vy,(uint16_t)age,(uint8_t)tile,(uint8_t)grazed};\n  effects[i]=(Effect){(int16_t)(i*231),(int16_t)(i%8192),(int16_t)(i*719),(int16_t)(i%2?-32768:32767),(uint16_t)turn,(uint16_t)delay};\n  stage.owner[i]=(uint8_t)(i%4?i%6:128+i%12);\n }\n}\n__declspec(dllexport) void fixture_tick(int px,int py,unsigned gather){\n game_cfg.battle_gather_enabled=gather;battle_hit=battle_grazes=0;simulate_bullets(px,py);++stage.frame;\n}\n__declspec(dllexport) void fixture_edge(unsigned age,unsigned age_max,unsigned delay,unsigned turn,int target,int speed,unsigned grazed){\n game_cfg.bullet_age_max=age_max;\n for(unsigned i=0;i<stage.count;++i){stage.shots[i].x=512*Q;stage.shots[i].y=620*Q;stage.shots[i].age=(uint16_t)age;stage.shots[i].tile=(uint8_t)(0x80+i);stage.shots[i].grazed=(uint8_t)grazed;stage.shots[i].vx=-32768;stage.shots[i].vy=32767;effects[i].delay=(uint16_t)delay;effects[i].turn=(uint16_t)turn;effects[i].target=(int16_t)target;effects[i].target_speed=(int16_t)speed;}\n}\n__declspec(dllexport) unsigned diagnostic(unsigned field){switch(field){case 0:return battle_near_fallbacks;case 1:return battle_near_candidates;case 2:return battle_grazes;case 3:return battle_hit;default:return stage.count;}}\n'
private += FIXTURE_CODE
private += r'''
__declspec(dllexport) void sw3_set_mode(unsigned near,unsigned legacy){game_cfg.near_enabled=near;battle_set_legacy(legacy);}
__declspec(dllexport) unsigned sw3_meta(unsigned field){
 switch(field){
 case 0:return sw3_trace_calls;case 1:return sw3_trace_path;case 2:return sw3_trace_lo;case 3:return sw3_trace_hi;case 4:return sw3_trace_consumed;
 case 5:return __builtin_offsetof(PrivateSnapshot,contact_index);case 6:return sizeof(contact_index);case 7:return __builtin_offsetof(PrivateSnapshot,contact_count);
 case 8:return CONTACT_BUCKET_CAP;case 9:return CONTACT_BUCKETS;default:return stage.count;
 }
}
__declspec(dllexport) void sw3_trace_reset(void){sw3_trace_calls=sw3_trace_path=sw3_trace_lo=sw3_trace_hi=sw3_trace_consumed=0;}
'''

wrapper = r'''
static unsigned sw3_trace_calls,sw3_trace_path,sw3_trace_lo,sw3_trace_hi,sw3_trace_consumed;
static void simulate_bullets(int px,int py){
 ++sw3_trace_calls;
 sw3_trace_path=(!legacy_mode&&game_cfg.near_enabled)?(game_cfg.battle_gather_enabled?1u:2u):3u;
 sw3_trace_lo=contact_bucket(py-(int)game_bullet_graze_radius());
 sw3_trace_hi=contact_bucket(py+(int)game_bullet_graze_radius());
 sw3_actual_simulate_bullets(px,py);
 unsigned overflow=0;
 if(sw3_trace_path!=3)for(unsigned b=sw3_trace_lo;b<=sw3_trace_hi;++b)if(contact_count[b]>CONTACT_BUCKET_CAP)overflow=1;
 sw3_trace_consumed=!overflow&&(sw3_trace_path==2||(sw3_trace_path==1&&SW3_RELEVANT_CONSUMES));
}
'''

libs, commands, metadata = [], [], []
for name, root in [('F3', F), ('SW2', S), ('SW3', P)]:
    source = (root / 'src/battle.c').read_text('utf-8-sig')
    relevant = source.split('static void simulate_bullets_relevant(', 1)[1].split('static void simulate_bullets(', 1)[0]
    if name == 'SW3':
        assert 'contact_index' not in relevant, 'SW3 relevant may not read/write index scratch'
        original = source.split('static void simulate_bullets_original(', 1)[1].split('static void simulate_bullets_relevant(', 1)[0]
        ref_original = (S / 'src/battle.c').read_text('utf-8-sig').split('static void simulate_bullets_original(', 1)[1].split('static void simulate_bullets_relevant(', 1)[0]
        assert original == ref_original, 'Original/legacy/near0/gather0 body must stay identical to SW2'
    consumes = 'contact_check(contact_index' in relevant
    needle = 'static void simulate_bullets(int px,int py){'
    assert source.count(needle) == 1
    source = source.replace(needle, 'static void sw3_actual_simulate_bullets(int px,int py){')
    marker = '\nstatic void step_legacy('
    assert source.count(marker) == 1
    source = source.replace(marker, '\n' + wrapper.replace('SW3_RELEVANT_CONSUMES', str(int(consumes))) + marker)
    observed = O / (name + '_battle_observed.c')
    observed.write_text(source, encoding='utf8')
    prefix = (P / 'tests/phase_gameplay.c').read_text('utf-8-sig').split('static int failures;', 1)[0]
    prefix = prefix.replace('#include "game.c"', '#include "' + (root / 'src/game.c').as_posix() + '"')
    prefix = prefix.replace('static uint64_t host_ticks;', 'static uint64_t host_ticks;static unsigned host_bb_reads;').replace('return ++host_ticks;', '++host_bb_reads;return ++host_ticks;')
    for fn, arg in [('scene_hud_begin', 'void'), ('scene_hud_end', 'void'), ('scene_hud_invalidate', 'void'), ('scene_hud_cache_enable', 'unsigned enabled')]:
        if 'void ' + fn + '(' not in prefix:
            prefix += '\nvoid ' + fn + '(' + arg + '){}\n'
    prefix = prefix.replace('unsigned uart_writeAvailability(unsigned u) { (void)u; return 0; }', 'unsigned uart_writeAvailability(unsigned u) { (void)u; return 128; }')
    host = O / (name + '_host.c')
    host.write_text(prefix + core, encoding='utf8')
    extra = O / (name + '_private.c')
    extra.write_text(private.replace('BATTLE', observed.as_posix()).replace('EFFECTS', (root / 'src/effects.c').as_posix()).replace('ENEMIES', (root / 'src/enemies.c').as_posix()), encoding='utf8')
    cmd = CC + ['-std=gnu11', '-O2', '-shared', '-UNDEBUG', '-Wno-misleading-indentation', '-I' + str(root / 'src'), '-I' + str(P / 'tests'), '-I' + str(P / 'tests/stub'), str(host), str(extra)]
    cmd += [str(root / 'src' / n) for n in ['stage.c', 'player.c', 'layer_visuals.c', 'game_config.c', 'font.c', 'replay.c', 'remote_input.c']]
    dll = O / (name + ('.dll' if os.name == 'nt' else '.so'))
    cmd += ['-o', str(dll)]
    q = subprocess.run(cmd, cwd=P, capture_output=True, text=True)
    (O / (name + '_compile.log')).write_text(q.stdout + q.stderr, encoding='utf8')
    assert not q.returncode, (name, q.stderr)
    commands.append(cmd)
    lib = ctypes.CDLL(str(dll))
    lib.public_snapshot.restype = lib.private_snapshot.restype = ctypes.c_void_p
    libs.append(lib)
    metadata.append({'name': name, 'root': str(root), 'relevant_index_consumed': consumes,
                     'instrumentation': 'Generated copy renames dispatcher only and inserts a call/path observer; actual motion bodies unchanged'})

pub_n, priv_n = libs[0].public_bytes(), libs[0].private_bytes()
assert all(l.public_bytes() == pub_n and l.private_bytes() == priv_n for l in libs)
ix_off, ix_n, ct_off, cap, buckets = [libs[2].sw3_meta(f) for f in [5, 6, 7, 8, 9]]
assert ix_n == 65536 and cap == 4096 and buckets == 8
assert all([l.sw3_meta(f) for f in [5, 6, 7, 8, 9]] == [ix_off, ix_n, ct_off, cap, buckets] for l in libs)
for m in metadata:
    m.update(private_index_offset=ix_off, private_index_bytes=ix_n, private_count_offset=ct_off)

checks, cases, path_counts = 0, [], {'no_motion': 0, 'relevant_no_index_write': 0, 'original_collect_exact_prefix': 0, 'near0_or_legacy_no_write': 0}
consumed_prefix_bytes = 0
coverage = {'overflow': False, 'graze': False, 'hit': False, 'removed': False, 'mode_switches': 0}
start = time.perf_counter()

def snapshots():
    return [ctypes.string_at(l.public_snapshot(), pub_n) + ctypes.string_at(l.private_snapshot(), priv_n) for l in libs]

def index(data):
    return data[pub_n + ix_off:pub_n + ix_off + ix_n]

def check(tag, before=None, exact_setup=False):
    global checks, consumed_prefix_bytes
    data = snapshots()
    assert data[0] == data[1], ('F3/SW2 full-state mismatch', tag, next(i for i, (x, y) in enumerate(zip(data[0], data[1])) if x != y))
    if exact_setup:
        assert data[0] == data[2], ('Fixture setup mismatch', tag)
    else:
        assert before is not None
        traces = [[l.sw3_meta(f) for f in range(4)] for l in libs]
        assert traces[0] == traces[1] == traces[2], ('Actual dispatcher path mismatch', tag, traces)
        calls, path, lo, hi = traces[2]
        assert calls in [0, 1], ('Need per-call proof for multi-motion step', tag, calls)
        old, after, ref = index(before[2]), index(data[2]), index(data[0])
        if not calls:
            assert after == old, ('No-motion index changed', tag)
            path_counts['no_motion'] += 1
        elif path == 1:
            assert after == old, ('Relevant path changed index byte', tag)
            assert libs[2].sw3_meta(4) == 0
            path_counts['relevant_no_index_write'] += 1
        elif path == 2:
            counts = list((ctypes.c_uint32 * buckets).from_buffer_copy(data[2][pub_n + ct_off:pub_n + ct_off + buckets * 4]))
            expected = bytearray(old)
            for b, count in enumerate(counts):
                begin, size = b * cap * 2, min(count, cap) * 2
                expected[begin:begin + size] = ref[begin:begin + size]
                assert after[begin:begin + size] == ref[begin:begin + size], ('Original written prefix differs', tag, b)
            assert after == expected, ('Original wrote outside count-indicated prefixes', tag)
            if libs[2].sw3_meta(4):
                for b in range(lo, hi + 1):
                    size = counts[b] * 2
                    assert counts[b] <= cap
                    begin = b * cap * 2
                    assert after[begin:begin + size] == ref[begin:begin + size], ('Actually consumed index differs', tag, b)
                    consumed_prefix_bytes += size
            path_counts['original_collect_exact_prefix'] += 1
        else:
            assert path == 3 and not libs[2].sw3_meta(4)
            assert after == old, ('near0/legacy index changed', tag)
            path_counts['near0_or_legacy_no_write'] += 1
        # This is the ONLY normalization, after the exact write/consumption rules.
        normalized = data[2][:pub_n + ix_off] + index(data[0]) + data[2][pub_n + ix_off + ix_n:]
        assert normalized == data[0], ('Non-whitelisted state differs', tag, next(i for i, (x, y) in enumerate(zip(data[0], normalized)) if x != y))
    assert libs[0].real_hash() == libs[1].real_hash() == libs[2].real_hash(), ('Authoritative hash mismatch', tag)
    coverage['overflow'] |= libs[2].diagnostic(0) > 17
    coverage['graze'] |= libs[2].diagnostic(2) > 0
    coverage['hit'] |= libs[2].diagnostic(3) > 0
    checks += 1

def action(tag, fn):
    before = snapshots()
    for l in libs:
        l.sw3_trace_reset()
        fn(l)
    check(tag, before=before)

def fixture(side, n, scenario):
    for l in libs:
        l.init_case(0, 8, 9, 0, 0)
        l.fixture_init(n, side, scenario, 1, 0)
        l.sw3_trace_reset()
    check(('fixture_setup', side, n, scenario), exact_setup=True)

for side, n in [(8, 20000), (32, 5000)]:
    for synthetic in [0, 1]:
        action(('runtime_init', side, synthetic), lambda l: l.init_case(n, side, 123456789, synthetic, 0))
        for t in range(200):
            action(('runtime_tick', side, synthetic, t), lambda l, t=t: l.advance_case(t, synthetic))
        cases.append({'kind': 'actual_runtime_step', 'size': side, 'initial_N': n, 'synthetic_GAME_LOAD': synthetic, 'ticks': 200})
action('explicit_paused_runtime_has_no_motion', lambda l: l.sw3_paused_runtime())
runtime_points = checks

for side, n in [(8, 20000), (32, 5000)]:
    for scenario in [0, 1, 2, 4, 6, 7, 8, 9]:
        fixture(side, n, scenario)
        before_count = libs[2].diagnostic(4)
        for t in range(4):
            py = [620, 85, 86, 688][t]
            action(('target_fixture', side, scenario, t), lambda l, py=py: l.fixture_tick(512, py, 1))
        coverage['removed'] |= libs[2].diagnostic(4) < before_count
        cases.append({'kind': 'targeted_motion', 'size': side, 'initial_N': n, 'scenario': scenario, 'ticks': 4})
    for n in [4096, 4097]:
        for scenario in [2, 9]:
            fixture(side, n, scenario)
            action(('overflow_threshold', side, n, scenario), lambda l: l.fixture_tick(512, 620, 1))

# Same state switches from fused to actual consuming original, near0 and legacy,
# then returns; the candidate's historical unwritten bytes are never hidden from
# any original-path prefix consumer.
for side, n in [(8, 20000), (32, 5000), (8, 4096), (32, 4096)]:
    fixture(side, n, 9)
    modes = [(1, 0, 1), (1, 0, 0), (1, 0, 1), (0, 0, 1), (1, 1, 1), (1, 0, 0), (1, 0, 1)]
    for t, (near, legacy, gather) in enumerate(modes):
        for l in libs:
            l.sw3_set_mode(near, legacy)
        action(('same_state_mode_switch', side, t, near, legacy, gather), lambda l, gather=gather: l.fixture_tick(512, 620, gather))
        coverage['mode_switches'] += 1
    cases.append({'kind': 'same_state_mode_switch', 'size': side, 'initial_N': n, 'sequence': modes})

for age, age_max, delay, turn in [(5, 60000, 6, 0), (17, 60000, 6, 12), (18, 60000, 6, 12), (65535, 65536, 65535, 0)]:
    for grazed in [0, 2, 255]:
        fixture(8, 3, 0)
        for l in libs:
            l.fixture_edge(age, age_max, delay, turn, -32768, -32768, grazed)
        check(('edge_setup', age, delay, turn, grazed), exact_setup=True)
        action(('packed_edge', age, age_max, delay, turn, grazed), lambda l: l.fixture_tick(512, 620, 1))
for side in [8, 32]:
    for n in [0, 1, 2, 3]:
        fixture(side, n, 1)
        action(('swap_delete_small', side, n), lambda l: l.fixture_tick(512, 620, 1))

assert all(path_counts[k] > 0 for k in path_counts), path_counts
assert consumed_prefix_bytes > 0, 'Need an actual nonoverflow original consumer, not only overflow fallback'
assert coverage['overflow'] and coverage['graze'] and coverage['hit'] and coverage['removed'], coverage
for file, sha in frozen.items():
    assert H(Path(file)) == sha, file
report = {'status': 'PASS', 'scope': 'Targeted F3/SW2/SW3 real runtime + real motion; exact index-write whitelist, not board FPS',
          'full_state_points': checks, 'actual_runtime_points': runtime_points, 'actual_runtime_calls': 801,
          'target_runtime_calls': 800, 'explicit_paused_runtime_calls': 1,
          'comparison_bytes_per_point': pub_n + priv_n, 'authoritative_hashes_equal': True,
          'whitelist': {'only_field': 'PrivateSnapshot.contact_index', 'bytes': ix_n, 'private_offset': ix_off,
                        'rule': 'Normalize history only AFTER exact per-step no-write/prefix-write/actual-consumer checks; every other byte strict'},
          'observed_path_counts': path_counts, 'actually_consumed_prefix_bytes_compared': consumed_prefix_bytes,
          'coverage': coverage, 'cases': cases, 'metadata': metadata, 'compile_commands': commands,
          'elapsed_host_seconds': time.perf_counter() - start, 'source_sha256': frozen, 'hardware_accessed': False}
(P / 'results/sw3_state.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
summary = f'SW3_STATE PASS points={checks} runtime_calls=801 bytes={pub_n + priv_n} exact scratch write rules+consumed prefixes+all other state/tails/hash; host-only'
(V / 'sw3_state.log').write_text(summary + '\n', encoding='utf8')
print(summary)
