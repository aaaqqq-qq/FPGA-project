"""Pixel-exact HUD0 delta regression against the frozen C284 scene renderer.

Every invocation preserves its own compiler output, result, and failures.
No target, GUI, serial port, or original test/result file is touched.
"""
from pathlib import Path
import argparse
import ctypes
import datetime
import hashlib
import json
import os
import random
import subprocess
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
REFERENCE_SHA = '1777f74bcf50b9f6d0988739055856cdeeba737008dd2086a3721837afb78fb6'
FRAME_BYTES = 1280 * 720 * 4
FB = (0x01000000, 0x01400000)


def text(x, y, value, color=0xe9e5f2, scale=1):
    return (1, x, y, 0, 0, color, scale, value.encode('latin1'))


def rect(x, y, w, h, color=0x80cfff):
    return (0, x, y, w, h, color, 0, b'')


def cases():
    result = []

    def add(label, commands, bank=None, hw=1, layered=1, cache=1,
            size=8, count=37, deferred=None):
        frame = len(result)
        result.append(dict(label=label, commands=commands,
                           args=(frame, frame % 2 if bank is None else bank,
                                 hw, layered, cache, size, count,
                                 frame % 2 if deferred is None else deferred)))

    # Warm both banks, then only the final digit changes; same and alternating banks.
    for i in range(24):
        add('text_delta', [text(1078,588,'FPS 60.00 R~1234'+str(i % 10))], bank=(i // 3) % 2)
    # Foreground and overlapping later command remain in painter order.
    for i in range(24):
        add('bar_delta', [rect(1078,334,186,8,0x383143),
                          rect(1078,334,175+i % 10,8),
                          rect(1171,334,1,8,0xffffff)], bank=i % 2)

    values = ['', '0', '1', '9', '10', '99', '100', '999', '1000',
              '999999', '1000000', '4294967295', '', 'A B', 'A  B',
              'a  b', '\x80\xff', 'AB\nCD', 'ABCD', '']
    # All public fast font scales, cross-band positions, screen and HUD clipping.
    for scale in (1,2,3,4,5,0):
        for i,value in enumerate(values):
            x=(1071,1072,1078,1278,1280,1400)[i % 6]
            y=(117,118,119,125,697,703)[i % 6]
            add('text_edges', [text(x,y,value,0xa0b0c0,scale),
                               text(1081,589,'OLD '+value,0xffffff,scale)])

    # Same origin/colour while widths shrink/grow, empty bars and clip endpoints.
    widths=(186,185,1,0,1,185,186,200,0,-1,8,0,2147483647)
    for i,width in enumerate(widths * 2):
        add('bar_edges', [rect(1078,334,width,8),rect(1171,334,1,8,0xffffff),
                          rect(1071,119,width,1),rect(1279,703,width,8)], bank=(i//2)%2)

    rng=random.Random(0x284D31A)
    base=[text(1078,124,'SCORE',0x8786a3),text(1078,138,'999',scale=2),
          rect(1078,178,186,10,0x383143),rect(1078,178,170,10),
          text(1078,192,'HP 100/100')]
    for k in range(6):
        y=320+34*k
        base += [text(1078,y,'BOSS '+str(k)),text(1198,y,'ENRAGED',0xf5cf77),
                 rect(1078,y+14,186,8,0x383143),rect(1078,y+14,180,8),
                 rect(1171,y+14,1,8,0xffffff),text(1078,y+26,'3000/3000')]
    base += [text(1078,588,'FPS 60.00 R~12345'),text(1078,684,'LAY 1 Q99 C0 S2')]
    for i in range(160):
        commands=list(base)
        for j in rng.sample(range(len(commands)),rng.randrange(1,8)):
            c=list(commands[j])
            if c[0]:
                value=c[7].decode('latin1')
                if value and rng.randrange(4):
                    p=rng.randrange(len(value));value=value[:p]+str(rng.randrange(10))+value[p+1:]
                else:value=rng.choice(values)
                c[7]=value.encode('latin1')
            else:c[3]=rng.randrange(0,187)
            if i%17==0:c[5]^=0x01000000 # Full 32-bit colour semantics.
            if i%19==0:c[1]+=rng.randrange(-8,9)
            if i%23==0:c[2]+=rng.randrange(-8,9)
            commands[j]=tuple(c)
        # Insertions/deletions, overlapping reorder, non-fast rows, bank reuse.
        if i%11==0:commands.insert(8,rect(1088,188,103,19,0xa01840))
        if i%13==0:commands.pop(10)
        if i%7==0:commands += [rect(1090,586,40,11,0x381440),text(1095,587,'OVERLAP')]
        if i%14==0:commands[-2:]=reversed(commands[-2:])
        if i%29==0:commands += [text(-3,700,'NEGATIVE',scale=2),rect(1078,657,0,7)]
        add('random',commands,bank=rng.randrange(2),cache=0 if i%31==0 else 1)

    # Non-overlap CPU/legacy hardware paths must also retain job traces exactly.
    for hw,layered in ((0,0),(0,1),(1,0),(1,1)):
        for i in range(18):
            commands=[text(1078,588,'COUNT '+str(9+i)),rect(1078,334,i%7,8),
                      text(1078,603,'A\nB' if i%7==0 else 'A B'),
                      rect(1082,589,19,8,0x481090)]
            if i%5==0:commands.reverse()
            add('fallback',commands,hw=hw,layered=layered,cache=i%4!=0)
    for size,count in ((8,20000),(8,20000),(32,5000),(32,5000)):
        add('full_load',base,size=size,count=count)
    return result


def mapped_scene(source):
    source=source.replace('#include "stage.h"', '#include "stage.h"\n#define stage (*(Stage *)(uintptr_t)0x02100000u)')
    source='static unsigned long long delta_restore_pixels,delta_fill_pixels;\nstatic unsigned delta_job_hash,delta_job_count;\n'+source
    for name,code in (
        ('static void hud_cpu_restore(', 'delta_restore_pixels+=(unsigned long long)(bottom-top)*(unsigned)(right-left);'),
        ('static void hud_cpu_fill(', 'delta_fill_pixels+=(unsigned long long)(unsigned)w*(unsigned)h;')):
        position=source.index('{',source.index(name))+1
        source=source[:position]+code+source[position:]
    source=source.replace('    ++scene_jobs;', '    {const uint32_t *v=(const uint32_t *)j;for(unsigned k=0;k<sizeof(*j)/4;++k)delta_job_hash=(delta_job_hash^v[k])*16777619u;++delta_job_count;}\n    ++scene_jobs;',1)
    source+='''
__declspec(dllexport) void delta_reset_stats(void){delta_restore_pixels=delta_fill_pixels=0;delta_job_hash=2166136261u;delta_job_count=0;}
__declspec(dllexport) unsigned long long delta_restored(void){return delta_restore_pixels;}
__declspec(dllexport) unsigned long long delta_filled(void){return delta_fill_pixels;}
__declspec(dllexport) unsigned delta_jobs_hash(void){return delta_job_hash;}
__declspec(dllexport) unsigned delta_jobs_count(void){return delta_job_count;}
'''
    return source


def run(args,out,result):
    assert os.name=='nt','The guarded address-space harness requires Windows'
    reference=ROOT/'tests/hud_delta/reference_scene.c'
    assert hashlib.sha256(reference.read_bytes()).hexdigest()==REFERENCE_SHA,'Frozen C284 reference changed'
    result['source_sha256']={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in [reference,ROOT/'src/scene.c',ROOT/'src/font.c',ROOT/'tests/hud_delta/host.c',Path(__file__)]}
    libs=[]
    for name,source in (('c284',reference),('candidate',ROOT/'src/scene.c')):
        mapped=out/(name+'_scene.c');mapped.write_text(mapped_scene(source.read_text(encoding='utf-8')),encoding='utf-8')
        dll=out/(name+'.dll')
        command=[args.host_cc,'-O2','-Wall','-Wextra','-Wno-misleading-indentation','-Wno-unused-function',
                 '-shared','-DBB_HOST_TEST','-Isrc','tests/hud_delta/host.c',str(mapped),
                 'src/font.c','src/pixels.c','src/render_queue.c','src/background.c','src/game_config.c','-o',str(dll)]
        q=subprocess.run(command,cwd=ROOT,capture_output=True,text=True)
        (out/(name+'_compile.log')).write_text(q.stdout+q.stderr,encoding='utf-8')
        assert q.returncode==0,(name,'compile',q.stderr)
        lib=ctypes.CDLL(str(dll))
        lib.delta_begin.argtypes=[ctypes.c_uint]*8
        lib.delta_command.argtypes=[ctypes.c_uint,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_uint,ctypes.c_uint,ctypes.c_char_p]
        lib.delta_restored.restype=lib.delta_filled.restype=ctypes.c_ulonglong
        libs.append(lib)
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.VirtualAlloc.restype=ctypes.c_void_p
    kernel.VirtualAlloc.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint32,ctypes.c_uint32]
    regions=((0x1000000,0x1200000),(0x7000000,0x400000),(0x5ff0000,0x90000))
    for address,size in regions:
        assert kernel.VirtualAlloc(address,size,0x3000,4)==address,ctypes.get_last_error()
    sequence=cases();expected=[];statistics=[]
    (out/'cases.json').write_text(json.dumps([{**c,'commands':[list(v[:-1])+[v[-1].hex()] for v in c['commands']]} for c in sequence],indent=2),encoding='utf-8')
    for variant,lib in enumerate(libs):
        for address,size in regions:ctypes.memset(address,0xa5,size)
        lib.init_overlap();stats=[]
        for index,case in enumerate(sequence):
            lib.delta_begin(*case['args']);lib.delta_reset_stats()
            for command in case['commands']:lib.delta_command(*command)
            lib.delta_end()
            digest=[hashlib.sha256(ctypes.string_at(address,FRAME_BYTES)).hexdigest() for address in FB]
            traces=(lib.trace()&0xffffffff,lib.trace_jobs(),lib.delta_jobs_hash()&0xffffffff,lib.delta_jobs_count())
            row=dict(frame=index,label=case['label'],restored=lib.delta_restored(),filled=lib.delta_filled())
            stats.append(row)
            if not variant:expected.append((digest,traces))
            else:
                assert digest==expected[index][0],('fullpixel',index,case,digest,expected[index][0])
                assert traces==expected[index][1],('ordered_jobs',index,case,traces,expected[index][1])
                if case['label']=='fallback' and not (case['args'][2] and case['args'][3]):
                    assert (row['restored'],row['filled'])==(statistics[0][index]['restored'],statistics[0][index]['filled']),('nonoverlap_metrics',index)
        statistics.append(stats)
        (out/('c284_metrics.json' if not variant else 'candidate_metrics.json')).write_text(json.dumps(stats,indent=2),encoding='utf-8')
        print(('C284' if not variant else 'CANDIDATE'),len(sequence),'frames completed',flush=True)
    improvements={}
    for label in ('text_delta','bar_delta'):
        # Exclude the first encounter with each bank (cold initialization).
        selected=[i for i,c in enumerate(sequence) if c['label']==label][6:]
        old=sum(statistics[0][i]['restored'] for i in selected)
        new=sum(statistics[1][i]['restored'] for i in selected)
        assert old>0 and new<old/2,(label,'restoration reduction missing',old,new)
        improvements[label]={'c284_restored_pixels':old,'candidate_restored_pixels':new,'reduction_percent':100*(old-new)/old}
    result.update(status='PASS',frames_exact=len(sequence),banks_compared=2,
                  pixels_compared=len(sequence)*2*1280*720,ordered_job_traces_exact=len(sequence),
                  strict_hud_bounds='PASS',nonoverlap_unchanged='PASS',improvements=improvements,
                  totals=[{'restored_pixels':sum(r['restored'] for r in rows),'filled_pixels':sum(r['filled'] for r in rows)} for rows in statistics],
                  pixel_sha256=[x[0] for x in expected],
                  scope='Frozen C284 source vs candidate; both full framebuffers after every frame; unchanged independent pixel model; CPU overlap HUD writes confined to active-bank right HUD; no hardware cache/DDR/FPS claim')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--host-cc',default='E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe')
    args=parser.parse_args()
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    out=ROOT/'results/hud_delta'/stamp;out.mkdir(parents=True,exist_ok=False)
    result={'status':'IN_PROGRESS','created_at':datetime.datetime.now().isoformat(),'output':str(out)}
    try:
        run(args,out,result)
    except BaseException as error:
        result.update(status='FAIL',error=repr(error))
        (out/'failure.log').write_text(traceback.format_exc(),encoding='utf-8')
        raise
    finally:
        (out/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        print('HUD_DELTA',result['status'],out,flush=True)


if __name__=='__main__':
    main()
