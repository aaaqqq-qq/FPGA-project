#!/usr/bin/env python3
"""Bounded local decoration tests and an offline composition preview. No device IO."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess,sys
from datetime import datetime,timezone
r=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=ap.parse_args()
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
o=r/'results/layer_visuals';o.mkdir(parents=True,exist_ok=True)
b=r/'build/layer_visuals';b.mkdir(parents=True,exist_ok=True)
exe=b/('test.exe' if os.name=='nt' else 'test');ppm=o/'preview_strength1.ppm';ppm2=o/'preview_strength2.ppm'
cmd=cc+['-std=gnu11','-O2','-UNDEBUG','-Wall','-Wextra','-Isrc','tests/layer_visuals/test_layer_visuals.c','src/layer_visuals.c','src/background.c','src/pixels.c','-o',str(exe)]
p=subprocess.run(cmd,cwd=r,capture_output=True,text=True,timeout=60);log=p.stdout+p.stderr;code=p.returncode
if not code:
 p=subprocess.run([str(exe),str(ppm),str(ppm2)],cwd=r,capture_output=True,text=True,timeout=90);log+=p.stdout+p.stderr;code=p.returncode
print(log,end='');(o/'test.log').write_text(log,encoding='utf-8')
preview='NOT_RENDERED'
if not code:
 try:
  from PIL import Image
  with Image.open(ppm) as im:im.save(o/'preview_strength1.png')
  with Image.open(ppm2) as im:im.save(o/'preview_strength2.png');im.save(o/'preview.png')
  preview='OFFLINE_PREVIEW_PNG'
 except ImportError:preview='PPM_ONLY_PIL_UNAVAILABLE'
ok=not code and 'LAYER_VISUALS PASS' in log
report={'status':'PASS' if ok else 'FAIL','generated_utc':datetime.now(timezone.utc).isoformat(),'exit_code':code,'command':cmd,
 'scope':'New pure local decoration module with clipped geometry, fixed budgets, original atlas aura and bothstrength60000tick deterministic simulation. Composition preview is host-only, not FPGA/FPS evidence.',
 'jobs_cap':12,'area_cap':8192,'maximal_actual_area':{'strength1':1828,'strength2':5664},'device_accessed':False,'preview':preview,
 'source_sha256':{n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in ('src/layer_visuals.c','src/layer_visuals.h','tests/layer_visuals/test_layer_visuals.c','src/art_data.h','src/background.c')},'stdout':log}
(o/'test.json').write_text(json.dumps(report,indent=2),encoding='utf-8');raise SystemExit(0 if ok else 1)
