"""Ordinary-enemy host regression using real enemies/battle/stage/player modules."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=ap.parse_args()
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)];exe=R/'build/enemies_host.exe'
cmd=cc+['-std=gnu11','-O2','-UNDEBUG','-Wall','-Wextra','-Wno-misleading-indentation','-Wno-unused-parameter','-Isrc','tests/enemies_host.c','src/enemies.c','src/layer_visuals.c','src/stage.c','src/battle.c','src/player.c','src/effects.c','src/game_config.c','-o',str(exe)]
p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=60);log=p.stdout+p.stderr;code=p.returncode
if not code:
 p=subprocess.run([str(exe)],cwd=R,capture_output=True,text=True,timeout=90);log+=p.stdout+p.stderr;code=p.returncode
print(log,end='');status='PASS' if not code and 'ALL_ENEMIES_PASS' in log else 'FAIL'
(R/'results/enemies_tests.json').write_text(json.dumps({'status':status,'hardware_accessed':False,'command':cmd,'exit_code':code,'output':log,'sources':{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'src/enemies.c',R/'src/layer_visuals.c',R/'src/enemies.h',R/'src/battle.c',R/'src/stage.c',R/'src/player.c']},'scope':'Real production enemy/bullet movement/state/ownership semantics; host scene hooks validate budgets/bounds, not physical rendering/FPS.'},indent=2),encoding='utf-8')
raise SystemExit(0 if status=='PASS' else 1)
