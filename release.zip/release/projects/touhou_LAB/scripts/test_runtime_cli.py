#!/usr/bin/env python3
"""Exercise the actual firmware parser/runtime with production game.c."""
from pathlib import Path
import argparse,json,os,shlex,subprocess,sys
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=ap.parse_args()
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
build=R/'build/runtime_cli';build.mkdir(parents=True,exist_ok=True)
prefix=(R/'tests/phase_gameplay.c').read_text(encoding='utf-8-sig').split('static int failures;',1)[0]
for name,args in [('scene_hud_begin','void'),('scene_hud_end','void'),('scene_hud_invalidate','void'),('scene_hud_cache_enable','unsigned enabled')]:
 if ('void '+name+'(') not in prefix:prefix+='\nvoid '+name+'('+args+') {'+('(void)enabled;' if 'enabled' in args else '')+'}\n'
host=build/'runtime_cli.c';host.write_text(prefix+'\n#include "runtime_cli_body.h"\n',encoding='utf-8')
exe=build/'runtime_cli.exe'
cmd=cc+['-std=gnu11','-O2','-UNDEBUG','-Wall','-Wextra','-Wno-unused-function','-Wno-unused-parameter','-Wno-misleading-indentation','-Isrc','-Itests/stub','-Itests',str(host),'src/stage.c','src/battle.c','src/player.c', 'src/enemies.c','src/layer_visuals.c','src/effects.c','src/game_config.c','src/font.c','src/replay.c','src/remote_input.c','-o',str(exe)]
p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=60);log=p.stdout+p.stderr;code=p.returncode
if not code:
 p=subprocess.run([str(exe)],cwd=R,capture_output=True,text=True,timeout=60);log+=p.stdout+p.stderr;code=p.returncode
print(log,end='')
status='PASS' if not code and 'ALL_RUNTIME_CLI_PASS' in log else 'FAIL'
(R/'results/runtime_cli.json').write_text(json.dumps({'status':status,'exit_code':code,'stdout_stderr':log,'hardware_accessed':False,'command':cmd},indent=2),encoding='utf-8')
print('RUNTIME_CLI='+status);raise SystemExit(0 if status=='PASS' else 1)
