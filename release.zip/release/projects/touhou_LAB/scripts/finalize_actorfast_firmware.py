"""C288 source-only offline authority. No device, GUI, seal or staging.

No overwrite on creation; --check revalidates artifacts without mutation.
Only new-source proofs govern scene changes. Historical glyph proof is a blob.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,difflib,hashlib,json,shutil
F=Path(__file__).resolve().parents[1];W=F.parent;P=W/'game60_pipe5_reportoverlap_fw_20261103'
N=W/'gui288_native_policy1_20261103/native_policy1_fixture'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
J=lambda p:json.loads(Path(p).read_text('utf-8-sig'))
ELF='c7d231afd22e3cc7f78f052f64fb1408e45d42a3aa2d0295f1bdde2dc2c449c8'
SCENE='6e9cc88cb469a5c9285ebee4554d68509b323858fb4ddb247eb1158927f01449'
NATIVE='d2357a3760b341afe889c4200b461cf5458079aafc27b13a1c5c0144196426b0'
POLICY='a8c481c9a52fbf433f64cf4df02586cf5da4f5cf9800ea9b78429ecb4aa8605a'
EMIT='results/actorfast_emit/20261103_180029_434304/summary.json'
MAIN='results/actorfast_main/20261103_180219/summary.json'
RV='results/actorfast_rv/20261103_180102_422325/summary.json'
INDEPENDENT=W/'c288_independent_review_20261103/REVIEW.json'

def save(p,obj):
 assert not p.exists(),p
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n','utf8')
def row(rel,**more):return dict(path=rel,sha256=H(F/rel),**more)
def bind(m,root=F):
 for rel,sha in m.items():
  p=root/rel
  if not p.is_file():p=root/'src'/rel
  assert p.is_file()and H(p)==sha,p
def validate():
 assert H(F/'src/scene.c')==SCENE
 parent=J(P/'evidence/REPORTOVERLAP_SOURCE_MANIFEST.json')
 assert H(P/'evidence/REPORTOVERLAP_SOURCE_MANIFEST.json')=='2bda8823a2ea77603f7728977493b5f2aeee7c40df1be8f4fede2a7c6fe0fc45'
 bind(parent,P)
 v=J(F/'results/verification_actorfast_final.json')
 assert all(v[k]['status']=='PASS'for k in('implementation','host_tests','rv32_build'))
 assert len(v['host_tests']['tests'])==48 and not v['host_tests']['failed']and not v['host_tests']['not_run']
 assert all(q['status']=='PASS'and q['exit_code']==0 for q in v['host_tests']['tests'].values())
 bind(v['source_sha256']);i=J(F/'build/identity.json')
 assert H(F/'build/rumia.elf')==i['elf_sha256']==ELF and i['status']=='PASS'
 bind(i['sources']);bind(i['scripts']);assert i['memory']['ram_remaining_above_reserved_stack']==10320
 emit,main,rv=J(F/EMIT),J(F/MAIN),J(F/RV)
 assert emit['status']=='PASS_EXACT_ORDERED_MMIO_AND_CLIP'and emit['engine_cases']==4102
 bind(emit['source_sha256']);assert 'checks=2094208 'in emit['clip_output']
 ed=(F/EMIT).parent;assert (ed/'golden.trace.bin').read_bytes()==(ed/'candidate.trace.bin').read_bytes()
 assert H(ed/'candidate.trace.bin')==emit['complete_trace_sha256']
 assert main['status']=='PASS'and len(main['tests'])==8;bind(main['source_sha256']);bind(main['golden_source_sha256'],P)
 md=(F/MAIN).parent
 for side,n in((8,20000),(32,5000)):
  q=next(q for q in main['tests']if q.get('side')==side and q.get('mode')==0 and q.get('diag')==0)
  assert q['N']==n and q['frames']==600 and q['samples']==9 and q['protocol_exact']and q['every_frame_state_and_8MiB_SHA_exact']and q['completion_bytes_exact']and not q['fast_raster_skipped']
 for golden in md.glob('golden_*.stdout.log'):
  assert golden.read_bytes()==golden.with_name(golden.name.replace('golden_','candidate_',1)).read_bytes()
 for suffix in('.stderr.log','.banks.bin','.state.bin'):
  for golden in md.glob('golden_*frames*'+suffix):assert golden.read_bytes()==golden.with_name(golden.name.replace('golden_','candidate_',1)).read_bytes()
 assert rv['status']=='ACTUAL_RV32_ELF_INSTRUCTION_PATHS_COUNTED';bind(rv['source_sha256'])
 assert rv['ELFs'][1]['sha256']==ELF and H(Path(rv['ELFs'][0]['path']))==rv['ELFs'][0]['sha256']=='5f9aad31dfd66e75c44be85e32f78f1c51abaf0ad40db2fd5d92f5f1ed8d13f7'
 assert rv['engine'][0]['no_change']==[150,81]and rv['engine'][1]['no_change']==[128,81]
 assert rv['capture'][0]['baseline_instructions']==118 and rv['capture'][0]['candidate_instructions']==89
 pix=J(F/'results/scene_pixels_batch720.json');assert pix['passed']is True and pix['frames_compared']==64 and len(pix['pixel_sha256'])==64
 assert pix['source_sha256']==hashlib.sha256((F/'src/scene.c').read_text().encode()).hexdigest()
 fresh=('results/pipe5/summary.json','results/hud_dma_lifecycle.json','results/segment_diag/unit.json','results/segment_diag/native.json','results/pipe5/native_main_wire.json')
 for rel in fresh:
  q=J(F/rel);assert q['status']=='PASS',rel
  if q.get('source_sha256'):bind(q['source_sha256'])
 assert J(F/fresh[0])['full_state_points']==424
 life=J(F/'results/hud_dma_lifecycle.json');original=life['output'].replace('\n','\r\n').encode();logged=(F/life['log']).read_bytes()
 assert len(original)==193 and len(logged)==195 and hashlib.sha256(original).hexdigest()==life['log_sha256']=='e2dc6084bc4e638bc6fc12984f534523044a01a4187791dff6ad80b1aa6f110a'
 assert logged==original+b'\r\n'and H(F/life['log'])=='c2271fb72fbda5acabbfc430e07b4e9e2dfdcf48c7a49e838a8f1234373b17d0'
 native=J(F/'results/validation/hud_policy1_native_provenance.json')
 assert H(F/'results/validation/hud_policy1_native_provenance.json')==H(N/'REVIEW.json')==NATIVE
 assert H(F/'results/validation/hud_policy1_complete.log')==POLICY
 assert len(native['source_inputs'])==77 and native['source_inputs_unchanged']and native['compile_exit']==native['run_exit']==0
 assert Path(native['root']).resolve()==F and not native['hardware_accessed']and not native['product_modified'];bind(native['source_inputs'])
 for name,sha in native['raw_logs'].items():assert H(N/name)==sha
 assert H(N/'host.c')==native['fixture_source_sha256']and H(N/'policy1_fixture.exe')==native['fixture_executable_sha256']
 assert H(INDEPENDENT)=='f4d1d58df323fe488a3610d507f17db68c6f8d29aea86f25aabf44f34d787f84'
 q=J(INDEPENDENT);bind(q['source_sha256']);assert q['native_trace_records_independently_parsed']==4102 and q['op2_concurrent_trace_records']==1024 and all(x['equal']for x in q['full_stdout_pairs'])
 for x in q['reviewed_files']:assert H(x['path'])==x['sha256']and Path(x['path']).stat().st_size==x['bytes']
 old_attempt=J(F/'evidence/attempt1_outlined_clip/PRESERVED.json')
 for x in old_attempt['files']:assert H(F/'evidence/attempt1_outlined_clip'/x['snapshot'])==x['sha256']
 files=set(parent)
 for sub in('src','scripts','tests'):files.update(p.relative_to(F).as_posix()for p in(F/sub).rglob('*')if p.is_file()and '__pycache__'not in p.parts)
 mf={rel:H(F/rel)for rel in sorted(files)}
 assert {rel for rel,sha in mf.items()if rel.startswith('src/')and parent.get(rel)!=sha}=={'src/scene.c'}
 return v,i,mf,fresh

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--check',action='store_true');a=ap.parse_args();v,i,mf,fresh=validate()
 final=F/'evidence/ACTORFAST_RELEASE_FINAL_RECEIPT.json';manifest=F/'evidence/ACTORFAST_SOURCE_MANIFEST.json';review=F/'evidence/ROOT_ACTORFAST_RELEASE_REVIEW.json'
 if a.check:
  assert J(manifest)==mf
  q=J(final)
  for key in('ELF','identity','verification','source_manifest','native','native_log','product_diff','review_script'):
   assert H(F/q[key]['path'])==q[key]['sha256']
  for x in q['extra_evidence']:assert H(F/x['path'])==x['sha256']
  raw=J(F/'evidence/ACTORFAST_RAW_FILE_MANIFEST.json')
  for x in raw['files']:assert H(F/x['path'])==x['sha256']and(F/x['path']).stat().st_size==x['bytes']
  assert J(review)['final_receipt_sha256']==H(final)
 else:
  assert not final.exists()and not manifest.exists()and not review.exists()
  # Preserve independent review verbatim without exposing its external parent
  # path/SHA rows to a relocated release collector as current source links.
  blobs=[(INDEPENDENT,'evidence/ACTORFAST_INDEPENDENT_REVIEW.original.json.txt','CURRENT_SCOPED_REVIEW_ORIGINAL_BLOB'),
         (W/'game60_pipe5_fontclip_fw_20261103/results/font_equivalence/test_result.json','evidence/parent_glyph_only.original.json.txt','HISTORICAL_FONT_ONLY_NOT_SCENE_AUTHORITY'),
         (F/'evidence/attempt1_outlined_clip/PRESERVED.json','evidence/attempt1_outlined_clip/PRESERVED.original.json.txt','HISTORICAL_REJECTED_ATTEMPT'),
         (F/'results/actorfast_rv/20261103_175934_878126/summary.json','evidence/attempt1_outlined_clip/RV_REGRESSION.original.json.txt','HISTORICAL_REJECTED_ATTEMPT'),
         (F/RV,'evidence/ACTORFAST_RV_ORIGINAL.json.txt','CURRENT_RV_ORIGINAL_PATHS_PRESERVED')]
  extras=[]
  for source,rel,scope in blobs:
   dest=F/rel;assert not dest.exists();shutil.copy2(source,dest);assert H(dest)==H(source);extras.append(row(rel,scope=scope))
  save(manifest,mf)
  # Preserve original RV report verbatim; a separate path-normalized view
  # carries exactly the same values and a locally retained parent ELF. The
  # release collector must never follow its historical F287 build path as a
  # current-source link or silently replace the original report.
  parent_elf=F/'evidence/parent_c287_rumia.elf';assert not parent_elf.exists();shutil.copy2(P/'build/rumia.elf',parent_elf)
  rv_local=J(F/RV);rv_local['ELFs'][0]['path']='evidence/parent_c287_rumia.elf';rv_local['ELFs'][1]['path']='build/rumia.elf'
  rv_local['relocatable_path_view']=True;rv_local['original_report']=row('evidence/ACTORFAST_RV_ORIGINAL.json.txt')
  save(F/'evidence/ACTORFAST_RV_REVIEW.json',rv_local)
  diff=''.join(difflib.unified_diff((P/'src/scene.c').read_text().splitlines(True),(F/'src/scene.c').read_text().splitlines(True),fromfile='C287/src/scene.c',tofile='C288/src/scene.c'))
  (F/'evidence/ACTORFAST_PRODUCT.diff').write_text(diff,'utf8')
  rawfiles=set()
  for rel in(EMIT,MAIN,RV):rawfiles.update(p for p in(F/rel).parent.rglob('*')if p.is_file()and p!=F/RV)
  rawfiles.update(F/'evidence/attempt1_outlined_clip'/name for name in('scene.c','rumia.elf','rumia.map','identity.json'))
  rawfiles.update(p for p in(F/'results/validation').rglob('*')if p.is_file())
  for rel in('results/verify_actorfast_final.stdout.raw.log','results/verify_actorfast_final.stderr.raw.log','build/compile.log'):rawfiles.add(F/rel)
  save(F/'evidence/ACTORFAST_RAW_FILE_MANIFEST.json',dict(status='CURRENT_C288_RAW_HASHES_AND_SIZES_PASS',files=[row(p.relative_to(F).as_posix(),bytes=p.stat().st_size)for p in sorted(rawfiles)]))
  save(F/'evidence/ACTORFAST_REPRESENTATION_RECONCILIATION.json',dict(status='EXACT_NAMED_TEST_WRITER_REPRESENTATIONS_VERIFIED_ORIGINALS_UNMODIFIED',
       scene_raw=row('src/scene.c'),scene_normalized_text_sha256=J(F/'results/scene_pixels_batch720.json')['source_sha256'],
       scene_test=row('results/scene_pixels_batch720.json'),scene_test_hash_method='test_scene hashes read_text().encode(); universal newlines apply',
       lifecycle_report=row('results/hud_dma_lifecycle.json'),lifecycle_log=row('results/validation/hud_dma_lifecycle.log'),
       lifecycle_declared_capture_bytes=193,lifecycle_actual_wrapper_bytes=195,lifecycle_exact_suffix_hex='0d0a',no_other_exception_allowed=True))
  extra_rels=[EMIT,MAIN,'evidence/ACTORFAST_RV_REVIEW.json','results/scene_pixels_batch720.json',*fresh,'evidence/ACTORFAST_RAW_FILE_MANIFEST.json','evidence/ACTORFAST_REPRESENTATION_RECONCILIATION.json','ACTORFAST_README.md']
  limits=['100MHz existing hardware reused; no RTL/clock/N/quality/painter change.',
          'Current scene authority is64 full frames,424 state/pixel,dual600 real-main full8MiB/state/all-log and4102 ordered MMIO plus2094208 clip cases; parent scene proofs are not reused.',
          'Measured ELF instruction counts have no DDR/APB/cache/branch latency model, hence no cycle/ms/FPS claim; sample partially clipped paths cost2 extra instructions.',
          'BSS unchanged; data44B smaller, text1276B larger, linker totalRAM1216B larger; no extra job pool. Reserved4KiB stack has no physical watermark.',
          'Initial outlined-clip functionalPASS but instruction regression preserved, not adopted.',
          'Only exact named newline/log-writer representation differences reconciled; originals unchanged.',
          'Historical font-only report does not establish current scene/main correctness.']
  save(final,dict(status='FINAL_OFFLINE_PASS_NOT_READY_NOT_FLASHED',created_utc=datetime.now(timezone.utc).isoformat(),implementation='PASS',RV32='PASS',host_groups=48,host_failures=[],host_skips=[],
       ELF=row('build/rumia.elf'),identity=row('build/identity.json'),source_manifest=row('evidence/ACTORFAST_SOURCE_MANIFEST.json',files=len(mf)),verification=row('results/verification_actorfast_final.json'),
       native=row('results/validation/hud_policy1_native_provenance.json'),native_log=row('results/validation/hud_policy1_complete.log'),
       extra_evidence=[row(rel,scope='CURRENT_C288_SOURCE_BOUND_OFFLINE'if'outlined_clip'not in rel else'HISTORICAL_REJECTED_ATTEMPT')for rel in extra_rels]+extras,
       memory=i['memory'],product_diff=row('evidence/ACTORFAST_PRODUCT.diff'),review_script=row('scripts/finalize_actorfast_firmware.py'),changed_product_files=['src/scene.c'],
       runtime_full_raster_frames=[600,600],diag_full_raster_frames=61,scene_full_frames=64,ordered_MMIO_cases=4102,clip_cases=2094208,
       parent_font_source_identity={'src/font.c':H(F/'src/font.c')},raw_evidence_files=len(rawfiles),board_FPS='NOT_RUN',physical_Flash='NOT_RUN',cold_boot='NOT_RUN',limits=limits))
  save(review,dict(status='ROOT_SOURCE_LOG_AND_ELF_REVIEW_PASS',approved_for_offline_image=True,approved_for_physical_FPS=False,ELF_sha256=ELF,source_manifest_sha256=H(manifest),source_files=len(mf),verification_sha256=H(F/'results/verification_actorfast_final.json'),final_receipt_sha256=H(final),clock_mhz=100,gameplay_N_Alpha_Key_unchanged=True,
       reviewer='Root-delegated c287_release_authority plus independent c288_independent_review: current scene-only source, ordered trace, complete pixels/main/log, ELF and native review; no physical performance claim.',limits=limits))
 print(json.dumps(dict(status='PASS',ELF=ELF,source_manifest_sha256=H(manifest),source_files=len(mf),verification_sha256=H(F/'results/verification_actorfast_final.json'),final_receipt_sha256=H(final),review_sha256=H(review),native_provenance_sha256=NATIVE,script_sha256=H(Path(__file__))),indent=2))

if __name__=='__main__':main()
