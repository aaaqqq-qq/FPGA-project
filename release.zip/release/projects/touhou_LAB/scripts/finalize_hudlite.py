"""Finalize/check the HUDLite offline candidate; does not access any device."""
from pathlib import Path
import argparse,hashlib,json,difflib
F=Path(__file__).resolve().parents[1]
P=Path(r'C:/FPGA/migrations/C289_GENERAL_CA91_20261104/TI60_GAME60_PIPELINE5_LINEPUBLISH_CA91_20261104/projects/touhou_LAB')
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');a=p.parse_args()
e=F/'evidence';target=e/'HUDLITE_RELEASE_FINAL_RECEIPT.json';mf=e/'HUDLITE_SOURCE_MANIFEST.json'
if a.check:
 r=json.loads(target.read_text());m=json.loads(mf.read_text())
 assert H(mf)==r['source_manifest_sha256']
 for rel,h in m.items():assert H(F/rel)==h,rel
 for rel,row in r['current_evidence'].items():assert H(F/rel)==row['sha256'] and (F/rel).stat().st_size==row['bytes'],rel
 for rel,h in r['parent_source_manifest'].items():assert H(P/rel)==h,rel
 print('HUDLITE_FINAL_CHECK_PASS',len(m),H(target));raise SystemExit(0)
parent=json.loads((e/'HUDLITE_PARENT_SOURCE_MANIFEST.json').read_text());changes=[x for x,h in parent.items()if H(F/x)!=h]
assert changes==['src/game.c','src/game_load.inc','src/hud_frozen.inc','src/scene.c'],changes
assert all(H(P/x)==h for x,h in parent.items())
keys=sorted([*parent,'tests/hudlite/run.py','scripts/finalize_hudlite.py']);m={x:H(F/x)for x in keys};mf.write_text(json.dumps(m,indent=2),encoding='utf8')
identity=json.loads((F/'build/identity.json').read_text());assert identity['status']=='PASS' and identity['elf_sha256']==H(F/'build/rumia.elf')
assert identity['sources']=={str(p.relative_to(F)):H(p)for p in sorted((F/'src').glob('*'))if p.is_file()}
trace=json.loads((F/'results/hudlite/REVIEW.json').read_text());assert trace['status']=='PASS' and trace['checks']==2114
assert trace['source_sha256']==identity['sources'];assert trace['test_source_sha256']==H(F/'tests/hudlite/run.py')
pixel=json.loads((F/'results/r2_render/summary.json').read_text());assert pixel['status']=='PASS' and pixel['hud_frames_exact']==12
assert len(pixel['vignette'])==4 and all(x['cleanup']=='PASS' for x in pixel['vignette'])
(e/'HUDLITE_FINAL_PRODUCT.diff').write_text(''.join(''.join(difflib.unified_diff((P/x).read_text().splitlines(True),(F/x).read_text().splitlines(True),fromfile='parent/'+x,tofile='candidate/'+x))for x in changes),encoding='utf8')
proofs=['build/rumia.elf','build/identity.json','build/compile.log','results/hudlite/REVIEW.json','results/hudlite/parent_host.c','results/hudlite/candidate_host.c','results/hudlite/parent_compile.log','results/hudlite/candidate_compile.log','results/r2_render/summary.json','results/r2_render/cached_compile.log','results/r2_render/reference_compile.log','evidence/HUDLITE_FINAL_PRODUCT.diff']
r={'schema':'ti60_hudlite_offline_candidate_v1','status':'OFFLINE_TARGETED_VERIFICATION_PASS_BOARD_NOT_RUN','candidate':str(F),'parent':str(P),'source_count':len(m),'product_source_count':60,'source_manifest_sha256':H(mf),'changed_product_files':changes,'product_sha256':{x:H(F/x)for x in changes},'elf_sha256':identity['elf_sha256'],'ram':identity['memory'],'current_evidence':{x:{'bytes':(F/x).stat().st_size,'sha256':H(F/x)}for x in proofs},'parent_source_manifest':{'evidence/LINEPUBLISH_SOURCE_MANIFEST.json':H(P/'evidence/LINEPUBLISH_SOURCE_MANIFEST.json')},'tests':{'hud_menu_and_actual_fps_cache':{'status':'PASS','checks':2114,'hud_cases':600,'menu_cases':300},'renderer_two_bank_cleanup':{'status':'PASS','hud_frames':12,'cleanup_paths':4},'rv32':{'status':'PASS'},'full_verify_all':{'status':'NOT_RUN','reason':'Root directed targeted verification only for HUD/menu presentation delta.'}},'scope':['Only HUD bottom commands, MENU text/height and three static title lines changed.','HP/score/Boss and CPU/HW STRESS commands below y572 remain exact.','GLOAD FPS derives from the current cumulative swaps/us at existing 60-frame samples; initial display is FPS --; ordinary gameplay uses the prior fps100.','Original GLOAD format strings, gameplay, protocol counters, timing boundaries, Alpha/CK and 100MHz/RTL preserved.'],'known_limitations':{'board_function':'NOT_RUN','board_fps':'NOT_RUN','physical_COPY_defect':'UNRESOLVED_PARENT_DEFECT_NOT_MODIFIED','pixel_scope':'Native software renderer/model; no physical DDR/cache or scanout proof','previous_48_tests':'NOT_RERUN_FOR_THIS_CANDIDATE'},'historical_builds':['results/rv_attempt1_pre_menu','results/rv_attempt2_pre_compact_menu']}
target.write_text(json.dumps(r,indent=2),encoding='utf8');print(json.dumps({'status':r['status'],'source_count':len(m),'source_manifest_sha256':H(mf),'receipt_sha256':H(target),'elf_sha256':r['elf_sha256'],'trace_sha256':H(F/'results/hudlite/REVIEW.json'),'pixels_sha256':H(F/'results/r2_render/summary.json')},indent=2))
