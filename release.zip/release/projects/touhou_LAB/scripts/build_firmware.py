#!/usr/bin/env python3
"""Build the bare-metal RV32 firmware.

The original script hard-coded the author's Efinity/GCC path. This version is
parameterised so a fresh checkout can build on Windows or Linux:

    python scripts/build_firmware.py --toolchain-bin <dir> [--prefix riscv-none-elf-]
    python scripts/build_firmware.py --check-only

If no toolchain is available the script prints RV32_BUILD=NOT_RUN and exits 2
(0 with --allow-missing), so a hardware-free verification run can record the
missing prerequisite instead of pretending the build passed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import struct
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCES = [
    "game.c", "pipe5_control.c", "motion_hw.c", "tick_profile.c", "remote_input.c", "lab.c", "labx.c", "adv.c", "adv_model.c", "scene.c", "render_queue.c", "layer_visuals.c", "stage.c", "battle.c", "player.c", "effects.c",
    "game_config.c", "replay.c", "enemies.c", "background.c", "bitblt.c", "pixels.c", "font.c", "start.S",
]
EXTRA_ASM = ["sw/software/standalone/common/trap.S"]
C_FLAGS = [
    "-march=rv32im_zicsr_zifencei", "-mabi=ilp32", "-O2", "-g", "-DUSE_GP",
    "-std=gnu11", "-Wall", "-Wextra", "-Wno-unused-function",
    "-Wno-misleading-indentation", "-ffunction-sections", "-fdata-sections",
    "-fstack-usage", "-Isrc",
    "-Isw/bsp/efinix/EfxSapphireSoc/include",
    "-Isw/software/standalone/driver",
]


def exe(name: str) -> str:
    return name + (".exe" if os.name == "nt" else "")


def find_tool(toolchain_bin: str | None, prefix: str, tool: str) -> Path | None:
    names = [prefix + tool, tool]
    candidates: list[Path] = []
    if toolchain_bin:
        candidates += [Path(toolchain_bin) / exe(n) for n in names]
    env = os.environ.get("RISCV_GCC_BIN")
    if env:
        candidates += [Path(env) / exe(n) for n in names]
    for n in names:
        found = shutil.which(exe(n)) or shutil.which(n)
        if found:
            candidates.append(Path(found))
    # Historical local installs are only fallbacks; no source file depends on them.
    for base in (Path(r"D:\Efinity\efinity-riscv-ide-2026.1\toolchain\bin"),
                 Path(r"C:\Efinity\efinity-riscv-ide-2026.1\toolchain\bin")):
        candidates += [base / exe(n) for n in names]
    for c in candidates:
        if c.is_file():
            return c
    return None


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def memory_identity(elf: Path, out: Path) -> dict:
    """Read the actual ELF32 load segments, not its debug-file length."""
    data = elf.read_bytes()
    header = struct.unpack_from("<16sHHIIIIIHHHHHH", data)
    if header[0][:6] != b"\x7fELF\x01\x01":
        raise ValueError("Expected little-endian ELF32")
    segments = []
    for i in range(header[10]):
        p = struct.unpack_from("<IIIIIIII", data, header[5] + i * header[9])
        if p[0] == 1:
            segments.append({"address": p[3], "file_bytes": p[4], "memory_bytes": p[5]})
    stack_lines = []
    for su in sorted(out.glob("*.su")):
        for line in su.read_text().splitlines():
            fields = line.split("\t")
            if len(fields) >= 3:
                stack_lines.append({"function": fields[0], "bytes": int(fields[1]), "kind": fields[2]})
    end = max((p["address"] + p["memory_bytes"] for p in segments), default=0x1000)
    return {
        "entry": header[4], "load_segments": segments,
        "load_file_bytes": sum(p["file_bytes"] for p in segments),
        "ram_origin": 0x1000, "ram_capacity_bytes": 1020 * 1024,
        "ram_used_including_reserved_stack": end - 0x1000,
        "ram_remaining_above_reserved_stack": 0x100000 - end,
        "reserved_stack_bytes": 4096,
        "largest_static_function_frames": sorted(stack_lines, key=lambda x: x["bytes"], reverse=True)[:10],
        "stack_scope": "Compiler per-function frames; no measured board stack watermark or complete indirect-call worst-case proof.",
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--toolchain-bin", help="directory containing riscv-none-elf-gcc")
    ap.add_argument("--prefix", default="riscv-none-elf-",
                    help="tool prefix, e.g. riscv-none-elf- or riscv32-unknown-elf-")
    ap.add_argument("--out", default="build", help="output directory (default build)")
    ap.add_argument("--allow-missing", action="store_true",
                    help="exit 0 with NOT_RUN when the toolchain is absent")
    ap.add_argument("--check-only", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args()

    cc = find_tool(a.toolchain_bin, a.prefix, "gcc")
    size = find_tool(a.toolchain_bin, a.prefix, "size")
    if not cc or not size:
        msg = ("RV32_BUILD=NOT_RUN reason=riscv-gcc-not-found "
               f"prefix={a.prefix} toolchain_bin={a.toolchain_bin or os.environ.get('RISCV_GCC_BIN', '')}")
        print(msg)
        return 0 if a.allow_missing else 2
    try:
        version = subprocess.run([str(cc), "--version"], capture_output=True, text=True,
                                 check=False).stdout.splitlines()[0]
    except Exception as e:  # pragma: no cover - toolchain diagnostics
        version = f"unknown ({e})"
    print(f"RV32_CC={cc}")
    print(f"RV32_CC_VERSION={version}")
    if a.check_only:
        print("RV32_BUILD=CHECK_OK")
        return 0

    out = Path(a.out)
    if not out.is_absolute():
        out = ROOT / out
    out.mkdir(parents=True, exist_ok=True)
    log: list[str] = []
    objects: list[str] = []
    ordered = [(f, "src/" + f) for f in SOURCES] + [(p, p) for p in EXTRA_ASM]
    for name, source in ordered:
        obj = out / (Path(name).stem + ".o")
        objects.append(str(obj))
        cmd = [str(cc), *C_FLAGS, *(["-Os"] if name in {"adv.c", "adv_model.c"} else []), "-c", source, "-o", str(obj)]
        p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
        log.append(" ".join(cmd) + "\n" + p.stdout + p.stderr)
        print(p.stdout, end="")
        print(p.stderr, end="", file=sys.stderr)
        if p.returncode:
            (out / "compile.log").write_text("\n".join(log))
            print(f"RV32_BUILD=FAIL phase=compile source={source}")
            return p.returncode

    elf = out / "rumia.elf"
    link = [str(cc), *C_FLAGS, *objects, "-o", str(elf), "-nostartfiles",
            "-specs=nosys.specs",
            "-Wl,--gc-sections,-T,scripts/link.ld,-Map," + str(out / "rumia.map") +
            ",--print-memory-usage", "-lc", "-lgcc", "-lm"]
    p = subprocess.run(link, cwd=ROOT, capture_output=True, text=True)
    log.append(" ".join(link) + "\n" + p.stdout + p.stderr)
    print(p.stdout, end="")
    print(p.stderr, end="", file=sys.stderr)
    (out / "compile.log").write_text("\n".join(log))
    if p.returncode:
        print("RV32_BUILD=FAIL phase=link")
        return p.returncode

    s = subprocess.run([str(size), str(elf)], capture_output=True, text=True)
    print(s.stdout, end="")
    print(s.stderr, end="", file=sys.stderr)
    identity = {
        "status": "PASS",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "toolchain": str(cc),
        "toolchain_version": version,
        "prefix": a.prefix,
        "flags": C_FLAGS,
        "per_source_extra_flags": {"src/adv.c": ["-Os"], "src/adv_model.c": ["-Os"]},
        "elf": str(elf.relative_to(ROOT)),
        "elf_sha256": sha256(elf),
        "map": str((out / "rumia.map").relative_to(ROOT)),
        "sources": {str(p.relative_to(ROOT)): sha256(p) for p in sorted((ROOT / "src").glob("*")) if p.is_file()},
        "scripts": {str(p.relative_to(ROOT)): sha256(p) for p in (ROOT / "scripts/link.ld", ROOT / "scripts/build_firmware.py", ROOT / "scripts/verify_all.py")},
        "memory": memory_identity(elf, out),
    }
    (out / "identity.json").write_text(json.dumps(identity, indent=2), encoding="utf8")
    print(f"RV32_BUILD=PASS elf={elf} sha256={identity['elf_sha256']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
