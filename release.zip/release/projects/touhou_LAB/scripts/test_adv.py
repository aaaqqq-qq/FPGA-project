"""Actual advanced firmware + production CPU/submit/swap path; bounded DMA model."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess,time
p=argparse.ArgumentParser();p.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=p.parse_args()
r=Path(__file__).resolve().parents[1];b=r/'build/adv_host';b.mkdir(parents=True,exist_ok=True)
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
flags=['-std=c99','-O2','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-Wno-unused-function','-DBB_HOST_TEST','-Isrc']
commands=[cc+flags+['-Dbb_cpu_execute=host_cpu_execute','-c','src/adv.c','-o',str(b/'adv.o')],cc+flags+['src/bitblt.c','src/pixels.c','src/font.c','src/adv_model.c','tests/adv_host.c',str(b/'adv.o'),'-o',str(b/'adv_host.exe'),'-Wl,--image-base,0x180000000']]
start=time.monotonic();runs=[];passed=True
for cmd in commands+[[str(b/'adv_host.exe')]]:
 proc=subprocess.run(cmd,cwd=r,capture_output=True,text=True,timeout=300)
 output=proc.stdout+proc.stderr;print(output,end='');runs.append({'command':cmd,'exit':proc.returncode,'output':output})
 if proc.returncode:passed=False;break
passed=passed and 'ALL_ADV_PASS' in runs[-1]['output']
report={'status':'PASS' if passed else 'FAIL','hardware':'NOT_RUN','scope':'actual adv.c+adv_model.c, production driver, independent scalar DMA and display model; no real throughput claim','elapsed_seconds':round(time.monotonic()-start,3),'runs':runs,'source_sha256':{n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in ['src/adv.c','src/adv_model.c','src/game.c','src/bitblt.c','tests/adv_host.c']}}
(r/'results/adv_host.json').write_text(json.dumps(report,indent=2),encoding='utf8')
raise SystemExit(0 if passed else 1)
