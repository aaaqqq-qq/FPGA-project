#!/usr/bin/env python3
"""Render the requested game states with the production renderer on the PC.

This is a host model (synchronous bitblt emulation), not a board capture.
Outputs results/preview/*.png plus manifest.json.
"""
from __future__ import annotations

import argparse
import json
import os
import shlex
import subprocess
from pathlib import Path

R = Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser()
ap.add_argument("--host-cc", default=os.environ.get("HOST_CC", "gcc"))
ap.add_argument("--out", default="build")
a = ap.parse_args()
cc = [x.strip('"') for x in shlex.split(a.host_cc, posix=False)]
out = R / a.out
out.mkdir(exist_ok=True)
preview = R / "results/preview"
preview.mkdir(parents=True, exist_ok=True)
for old in list(preview.glob("*.ppm")) + list(preview.glob("*.png")):
    old.unlink()
exe = out / ("game_preview.exe" if os.name == "nt" else "game_preview")
cmd = cc + ["-std=gnu11", "-O2", "-UNDEBUG", "-DBB_HOST_TEST", "-Isrc", "-Itests/stub",
            "sim/game_preview.c", "src/scene.c", "src/render_queue.c", "src/background.c", "src/font.c", "src/pixels.c",
            "src/stage.c", "src/battle.c", "src/player.c", "src/enemies.c","src/layer_visuals.c", "src/effects.c",
            "src/game_config.c", "src/replay.c", "-o", str(exe)]
subprocess.run(cmd, cwd=R, check=True)
p = subprocess.run([str(exe)], cwd=R, capture_output=True, text=True)
print(p.stdout, end="")
if p.returncode:
    raise SystemExit(p.returncode)
try:
    from PIL import Image
except Exception as e:
    print("PIL unavailable, PPM kept:", e)
    raise SystemExit(0)
preview = R / "results/preview"
for f in sorted(preview.glob("*.ppm")):
    Image.open(f).save(f.with_suffix(".png"))
    f.unlink()
manifest = {
    "model": "PC host renderer: production scene.c/font.c with synchronous bitblt emulation",
    "not_a_board_capture": True,
    "frames": sorted(x.name for x in preview.glob("*.png")),
    "tool": "scripts/render_preview.py",
}
(preview / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf8")
print("PREVIEWS", len(manifest["frames"]), preview)
