from pathlib import Path
import argparse,subprocess,json,hashlib,re,time
from datetime import datetime,timezone

def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--root',default='E:/Ti60_builds/game60_batch32_20261102')
 ap.add_argument('--iverilog',default='D:/FPGA/tools/iverilog/bin/iverilog.exe')
 ap.add_argument('--cases',nargs='*')
 ap.add_argument('--output')
 a=ap.parse_args();r=Path(a.root);rtl=r/'hw/game/rtl';sim=r/'sim';iv=Path(a.iverilog);vvp=iv.with_name('vvp.exe')
 out=Path(a.output) if a.output else r/'evidence'/('rtl_replay_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
 out.mkdir(parents=True,exist_ok=False)
 common=['sprite_batch_engine.sv','render_engine.sv','bitblt_engine.sv','write_beat_fifo.sv']
 cases=[
  ('legacy8','tb_sprite_batch',['sprite_batch_engine.sv'],[],[], 'PASS all sprite batch pixel/protocol tests'),
  ('matrix32','tb_batch32',common,['WITH_WRITE_FIFO'],['SNAPSHOT'],'PASS all 8/32 ordered batch pixel/protocol tests'),
  ('edges32','tb_batch32_edges',common,['WITH_WRITE_FIFO'],[],'PASS invalid32 descriptors, RLAST failures and recovery'),
  ('full5000x32','tb_batch32',common,['WITH_WRITE_FIFO'],['FULL32','SNAPSHOT'],'PASS full field 5000 32px batch'),
  ('full20000x8','tb_batch32_full8',common,['WITH_WRITE_FIFO'],['FULL8','SNAPSHOT'],'PASS full field 20000 8px batch'),
  ('legacy_flag32','tb_render_legacy_flag32',common,['WITH_WRITE_FIFO'],[],'PASS BitBlt tests=170'),
  ('apb32','tb_batch32_apb',['game_apb.sv'],[],[],'PASS APB capability6'),
 ]
 selected=[c for c in cases if not a.cases or c[0] in a.cases]
 if a.cases:assert set(a.cases)=={c[0]for c in selected},'Unknown case name'
 inputs={p for c in selected for p in [sim/(c[1]+'.sv'),*[rtl/n for n in c[2]]]}
 hashes={str(p.relative_to(r)):H(p)for p in sorted(inputs)}
 report={'started_utc':datetime.now(timezone.utc).isoformat(),'root':str(r),'tool_sha256':{'iverilog':H(iv),'vvp':H(vvp)},'input_hashes':hashes,'hardware_accessed':False,'cases':[]}
 for name,top,files,defines,args,marker in selected:
  target=out/(name+'.vvp');compile_args=[str(iv),'-g2012',*['-D'+d for d in defines],'-s',top,'-o',str(target),*[str(rtl/n)for n in files],str(sim/(top+'.sv'))]
  x={'name':name,'compile_argv':compile_args,'sim_argv':[str(vvp),'-i',str(target),*['+'+s for s in args]],'status':'NOT_RUN'}
  start=time.monotonic()
  with(out/(name+'.compile.log')).open('w')as f:cc=subprocess.run(compile_args,stdout=f,stderr=subprocess.STDOUT)
  x['compile_exit']=cc.returncode
  if cc.returncode==0:
   with(out/(name+'.log')).open('w')as f:run=subprocess.run(x['sim_argv'],stdout=f,stderr=subprocess.STDOUT,timeout=900)
   txt=(out/(name+'.log')).read_text()
   x.update({'sim_exit':run.returncode,'pass_marker':marker in txt,'no_fatal':'FATAL:' not in txt,'status':'PASS'if run.returncode==0 and marker in txt and 'FATAL:' not in txt else 'FAIL','log_sha256':H(out/(name+'.log'))})
  else:x['status']='FAIL_COMPILE'
  x['elapsed_host_seconds']=time.monotonic()-start
  report['cases'].append(x)
  print(name,x['status'],flush=True)
  (out/'verification.json').write_text(json.dumps(report,indent=2))
  if x['status']!='PASS':break
 report.update({'finished_utc':datetime.now(timezone.utc).isoformat(),'inputs_unchanged':all(H(r/p)==h for p,h in hashes.items())})
 report['status']='PASS'if len(report['cases'])==len(selected)and all(x['status']=='PASS'for x in report['cases'])and report['inputs_unchanged']else'FAIL'
 (out/'verification.json').write_text(json.dumps(report,indent=2));print('OUTPUT',out)
 raise SystemExit(0 if report['status']=='PASS'else 1)
if __name__=='__main__':main()
