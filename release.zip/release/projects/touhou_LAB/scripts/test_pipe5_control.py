from pathlib import Path
import argparse,ctypes,subprocess,json,os
P=Path(__file__).resolve().parents[1];O=P/'build/pipe5_control';O.mkdir(parents=True,exist_ok=True)
a=argparse.ArgumentParser();a.add_argument('--host-cc',default='E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe');a=a.parse_args()
cmd=[a.host_cc,'-O2','-std=c11','-shared','-I'+str(P/'src'),str(P/'src/pipe5_control.c'),'-o',str(O/'control.dll')]
q=subprocess.run(cmd,capture_output=True,text=True);(O/'compile.log').write_text(q.stdout+q.stderr);assert not q.returncode,q.stderr
class Sample(ctypes.Structure):_fields_=[('deadline',ctypes.c_uint64),('epoch',ctypes.c_uint32),('keys',ctypes.c_uint32),('bombs',ctypes.c_uint32),('controls',ctypes.c_uint32)]
L=ctypes.CDLL(str(O/'control.dll'));L.pipe5_input_reset.argtypes=[ctypes.c_uint64,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_uint32];L.pipe5_input_record.argtypes=[ctypes.c_uint64,ctypes.c_uint32,ctypes.c_uint32];L.pipe5_input_take.argtypes=[ctypes.c_uint64,ctypes.POINTER(Sample)];L.pipe5_input_due.argtypes=L.pipe5_input_backlog.argtypes=[ctypes.c_uint64]
checks=0
def check(v):
 global checks;assert v;checks+=1
for hz in [1000000,100000000]:
 origin=0x100000000+333;L.pipe5_input_reset(origin,hz,0,1);s=Sample()
 check(L.pipe5_input_record(origin+5,17,17)==1)
 check(L.pipe5_input_take(origin,ctypes.byref(s))==1 and (s.keys,s.bombs,s.epoch)==(0,0,1))
 check(L.pipe5_input_take(origin+5,ctypes.byref(s))==0)
 for i in range(1,121):
  due=origin+i*hz//60
  check(L.pipe5_input_due(due-1)==0)
  check(L.pipe5_input_take(due,ctypes.byref(s))==1 and s.deadline==due and s.epoch==i+1)
  if i==1:check((s.keys,s.bombs)==(1,1))
  elif i<30:check(s.keys==1 and s.bombs==0)
  elif i>=31:check(s.keys==0 and s.bombs==0)
  check(L.pipe5_input_backlog(due)==0)
 # An already late packet cannot be backdated into an overdue tick.
 L.pipe5_input_reset(origin,hz,2,1);check(L.pipe5_input_record(origin+hz//60+10,4,0)==1)
 check(L.pipe5_input_take(origin+hz,ctypes.byref(s))==1 and s.keys==2 and s.deadline==origin)
 check(L.pipe5_input_take(origin+hz,ctypes.byref(s))==1 and s.keys==2)
 check(L.pipe5_input_take(origin+hz,ctypes.byref(s))==1 and s.keys==4)
 # Bounded input queue fails explicitly; no overwritten/future event used.
 L.pipe5_input_reset(origin,hz,0,1)
 for i in range(128):check(L.pipe5_input_record(origin+i,1,0)==1)
 check(L.pipe5_input_record(origin+128,2,0)==0 and L.pipe5_input_overflows()==1)
L.pipe5_cli_push.argtypes=[ctypes.c_char_p];L.pipe5_cli_pop.argtypes=[ctypes.c_char_p,ctypes.c_uint32];L.pipe5_cli_clear()
commands=[b'menu',b'pause 1',b'set boss_count 6',b'restart',b'gload cancel 17',b'x'*639,b'set enemy_count 12',b'pause 0']
for v in commands:check(L.pipe5_cli_push(v)==1)
check(L.pipe5_cli_push(b'overflow')==0)
b=ctypes.create_string_buffer(640)
for v in commands:check(L.pipe5_cli_pop(b,640)==1 and b.value==v)
check(L.pipe5_cli_pop(b,640)==0)
(P/'results/pipe5_control.json').write_text(json.dumps({'status':'PASS','checks':checks,'clock_hz_cases':[1000000,100000000],'raw_clock_above_uint32':True,'no_future_input_or_late_packet_backdating':True,'explicit_overflow':True,'ASCII_FIFO_preserved_639bytes':True,'scope':'Real input queue/rational clock module, native only; no display/physical-FPS claim'},indent=2))
print('PIPE5_CONTROL PASS checks',checks,'real deadlines; no future/backdated input; FIFO/overflow exact')
