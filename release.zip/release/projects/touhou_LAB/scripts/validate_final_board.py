from pathlib import Path
import argparse,time,re,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--hz',type=int,required=True);p.add_argument('--seconds',type=int,default=65);p.add_argument('--prefix',default='final');a=p.parse_args()
r=Path(__file__).resolve().parents[1];log=r/'results/validation/touhou_uart.log';cmd=r/'results/serial_commands.txt'
def send(s):
 with cmd.open('ab')as f:f.write(s.encode())
def read(offset):
 with log.open('rb')as f:f.seek(offset);return f.read().decode(errors='replace')
def stats(text):return [{k:int(v)for k,v in re.findall(r'(\w+)=(\d+)',line)}for line in text.splitlines()if line.startswith('STAT')]
identity={'elf_sha256':hashlib.sha256((r/'build/rumia.elf').read_bytes()).hexdigest(),'bit_sha256':hashlib.sha256((r/'hw/game/par/ddr_demo_ti60/outflow/ddr_demo_ti60.bit').read_bytes()).hexdigest()}
comparisons=[]
for key in ('x','y'):
 offset=log.stat().st_size;send(key);deadline=time.monotonic()+50
 while time.monotonic()<deadline:
  time.sleep(.5);text=read(offset)
  rows=[{k:int(v)for k,v in re.findall(r'(\w+)=(\d+)',line)}for line in text.splitlines()if line.startswith('BATCH_COMPARE')]
  if len(rows)>=3:break
 assert len(rows)==3 and all(x['errors']==0 for x in rows),text
 comparisons.extend(rows);print('CPU/GPU pixel compare',key,'PASS',flush=True);time.sleep(2)
(r/'results'/f'{a.prefix}_pixels.json').write_text(json.dumps({**identity,'passed':True,'frames':comparisons},indent=2))
# Read immunity state rather than blindly toggling it.
offset=log.stat().st_size;send('n4096\nrdd');time.sleep(3)
rows=stats(read(offset));assert rows,read(offset)
if not rows[-1]['demo']:send('i')
offset=log.stat().st_size;time.sleep(a.seconds)
rows=stats(read(offset));steady=[d for d in rows if d.get('mode')==1][1:]
passed=len(steady)>=a.seconds//3 and all(a.hz*100-5<=d['fps100']<=a.hz*100+5 and d['uf']==0 and d['missed']==0 and d['rejected']==0 for d in steady)
(r/'results'/f'{a.prefix}_threeboss.json').write_text(json.dumps({**identity,'passed':passed,'target_hz':a.hz,'difficulty':'Lunatic','windows':rows},indent=2));print('Three boss Lunatic',passed,flush=True)
offset=log.stat().st_size;send('cn4096\n');time.sleep(15);rows=stats(read(offset));offset=log.stat().st_size;t=time.monotonic();send('m')
while time.monotonic()-t<3 and 'UI MENU'not in read(offset):time.sleep(.01)
latency=time.monotonic()-t
result={**identity,'cpu_windows':rows,'uart_menu_ack_seconds':latency,'responsive':latency<.5,'note':'Serial command path measured; physical key debounce/hold tested separately on host.'}
(r/'results'/f'{a.prefix}_cpu_input.json').write_text(json.dumps(result,indent=2));print('CPU 4096 benchmark and menu latency',latency,flush=True)
assert result['responsive'],result
