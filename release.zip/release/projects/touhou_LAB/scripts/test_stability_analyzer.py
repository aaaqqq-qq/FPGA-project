"""Offline acceptance adversarial regressions; no device access or waiting."""
import copy,json,subprocess,sys
from pathlib import Path
from analyze_stability import assess,policy_description,policy_digest,POLICY_ID
R=Path(__file__).resolve().parents[1]
fields=dict(mode=2,hw=1,N=20000,limit=20000,fps100=6000,swaps=120,scan=120,us=2000000,
            frame=12000,logic=3000,render=9000,scan_total=0,swap_total=0,missed=0,uf=0,drops=0,ldrop=0,lover=0,fxdrop=0)
def fixture():
    rows=[]
    for i in range(301):
        d=fields.copy();d.update(scan_total=(i+1)*120,swap_total=(i+1)*120,frame=12000+i)
        rows.append({'monotonic':1000+i*2,'line':'STAT '+' '.join('%s=%u'%x for x in d.items())})
    return rows
def change(rows,i,key,value):
    d=dict((x.split('=')[0],int(x.split('=')[1])) for x in rows[i]['line'].split()[1:]);d[key]=value
    rows[i]['line']='STAT '+' '.join('%s=%u'%x for x in d.items())
results={}
def check(name,rows,expected,**kwargs):
    r=assess(rows,**kwargs);assert r['passed_target_fps']==expected,(name,r['failure_reasons'])
    results[name]={'test_status':'PASS','accepted':r['status'],'performance_pass':r['passed_target_fps'],'hardware_status':r['hardware_status'],'capture_quality':r['capture_quality'],'reasons':r['failure_reasons'],'measured_us':r['measured_us']}
    return r
base=fixture();check('600s_36000_swaps_variable_frame_processing_time',base,True)
check('six_seconds_cannot_pass_600',base[:4],False)
for key in ('missed','uf','drops','ldrop','lover'):
    rows=fixture();change(rows,20,key,1);check('nonzero_or_increased_'+key,rows,False)
for key,value in [('mode',0),('hw',0),('N',4096),('limit',4096)]:
    rows=fixture();change(rows,20,key,value);check('transition_'+key+'_not_filtered',rows,False)
rows=fixture();del rows[20];check('missing_whole_window',rows,False)
rows=fixture();change(rows,20,'scan_total',2521);check('scan_counter_jump',rows,False)
rows=fixture();change(rows,20,'swap_total',2521);check('swap_counter_jump',rows,False)
rows=fixture();change(rows,20,'swaps',1);check('fake_reported_FPS',rows,False)
rows=fixture();change(rows,20,'us',100000000);check('fake_large_native_duration',rows,False)
rows=fixture();rows[20]['line']=' '.join(x for x in rows[20]['line'].split() if not x.startswith('scan_total='));check('processing_frame_cannot_replace_missing_scan_total',rows,False)
rows=fixture();del rows[20]['monotonic'];r=check('missing_receipt_timestamp_warns_not_hardware_failure',rows,True);assert r['capture_quality']=='WARNING'
rows=fixture();rows[20]['monotonic']-=4;r=check('backwards_receipt_timestamp_warns_not_hardware_failure',rows,True);assert r['capture_quality']=='WARNING'
rows=fixture();rows.insert(20,{'line':'FAIL TRAP 5','monotonic':1039});check('fault_in_retained_capture',rows,False)
rows=fixture();rows.insert(0,{'line':'FAIL before first target','monotonic':999});check('fault_not_hidden_as_prelude',rows,False)
rows=fixture();rows.insert(20,{'line':'RUMIA HDMI RESTART','monotonic':1039});check('reboot_during_run',rows,False)
rows=fixture();rows.append({'line':'STAT mode=0 hw=1 N=0','monotonic':1602});check('transition_after_long_duration_cannot_be_hidden',rows,False)
rows=fixture()
for i in range(len(rows)):change(rows,i,'ldrop',7)
check('warmup_counter_baseline_explicit_no_new_drops',rows,True)
rows=fixture();change(rows,20,'fxdrop',3)
r=check('cosmetic_drop_reported_separately',rows,True);assert r['cosmetic_fxdrop_total']==3 and not r['full_visual_budget_clean']
r=check('optional_no_cosmetic_drop_gate',rows,True,require_zero_fxdrop=True);assert r['status']=='FAIL'
rows=fixture()
for i in range(len(rows)):change(rows,i,'scan_total',(0xfffffff0+i*120)&0xffffffff);change(rows,i,'swap_total',(0xfffffff0+i*120)&0xffffffff)
check('unsigned_hardware_counter_wrap',rows,True)
rows=fixture();rows[78]['monotonic']+=0.655318
r=check('PC_delayed_then_catchup_native_cadence_intact',rows,True)
assert r['hardware_status']=='PASS' and r['capture_quality']=='WARNING' and len(r['capture_quality_warnings'])==2
assert r['status']=='PASS' and r['qualified_us']==600000000
rows=fixture();rows[78]['monotonic']+=0.655318;del rows[77]
r=check('receipt_jitter_never_excuses_missing_native_window',rows,False);assert r['capture_quality']=='WARNING'
rows=fixture();rows[78]['monotonic']+=0.655318;change(rows,78,'missed',1)
check('receipt_jitter_never_excuses_real_missed_frame',rows,False)
rows=fixture();rows[78]['monotonic']+=0.655318;change(rows,78,'uf',1)
check('receipt_jitter_never_excuses_real_underflow',rows,False)
rows=fixture();rows[20],rows[21]=rows[21],rows[20]
check('row_reordering_is_native_counter_failure_not_just_receipt_warning',rows,False)
rows=fixture();rows[20]['line']=' '.join(x for x in rows[20]['line'].split() if not x.startswith('swap_total='))
check('swap_total_is_required_native_evidence',rows,False)
rows=fixture();rows[20]['line']+=' swaps=120'
check('duplicate_native_fields_rejected',rows,False)
rows=fixture();change(rows,20,'scan_total',((20+1)*120)+(1<<32))
check('uint32_counter_range_cannot_hide_bad_counter_as_wrap',rows,False)
rows=fixture();rows[78]['monotonic']+=0.655318;change(rows,78,'us',100000000)
check('receipt_jitter_never_excuses_fake_native_duration',rows,False)
rows=fixture()[:4];rows[2]['monotonic']+=0.655318
check('short_six_seconds_plus_receipt_jitter_still_fails600',rows,False)
cli=R/'build/stability_cli';cli.mkdir(parents=True,exist_ok=True)
policyfile=cli/'policy_before_run.json'
p=subprocess.run([sys.executable,'scripts/analyze_stability.py','--describe-policy','--mode2','--count','8192','--seconds','600','--hz','60','--require-zero-fxdrop','--output',str(policyfile)],cwd=R,capture_output=True,text=True)
assert p.returncode==0;policy=json.loads(policyfile.read_text(encoding='utf-8'))
assert policy['policy']['policy_id']==POLICY_ID and policy['policy_sha256']==policy_digest(policy_description(2,8192,600,60,1,True))
assert policy['policy_sha256']!=policy_digest(policy_description(2,4096,600,60,1,True))
results['preregister_policy_export_and_configuration_bound_hash']={'test_status':'PASS','policy_sha256':policy['policy_sha256']}
invalid=cli/'invalid.jsonl';invalid.write_text('{invalid JSONL}\n',encoding='utf-8');raw=invalid.read_bytes()
badout=cli/'malformed_report.json'
p=subprocess.run([sys.executable,'scripts/analyze_stability.py','--log',str(invalid),'--output',str(badout)],cwd=R,capture_output=True,text=True)
bad=json.loads(badout.read_text(encoding='utf-8'));assert p.returncode==1 and bad['hardware_status']=='FAIL' and bad['capture_quality']=='ERROR' and invalid.read_bytes()==raw
results['malformed_JSONL_fails_evidence_not_soft_receipt_warning']={'test_status':'PASS'}
p=subprocess.run([sys.executable,'scripts/analyze_stability.py','--log',str(invalid),'--output',str(invalid)],cwd=R,capture_output=True,text=True)
assert p.returncode==2 and invalid.read_bytes()==raw
results['report_cannot_overwrite_raw_log']={'test_status':'PASS'}
out={'status':'PASS','hardware_accessed':False,'case_count':len(results),'cases':results}
(R/'results/stability_analyzer_tests.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print('STABILITY_ANALYZER PASS',len(results),'cases')
