#!/usr/bin/env python3
"""DODGE 200-second rule, lives/bomb collision, PC input events and ignored board keys."""
from __future__ import annotations

import argparse
import json
import os
import shlex
import subprocess
from pathlib import Path

R = Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser()
ap.add_argument("--host-cc", default=os.environ.get("HOST_CC", "gcc"))
ap.add_argument("--out", default="build")
a = ap.parse_args()
cc = [x.strip('"') for x in shlex.split(a.host_cc, posix=False)]
out = R / a.out
out.mkdir(exist_ok=True)
exe = out / ("dodge_controls.exe" if os.name == "nt" else "dodge_controls")
cmd = cc + ["-std=gnu11", "-O2", "-UNDEBUG", "-Isrc", "-Itests/stub",
            "tests/dodge_controls.c", "src/stage.c", "src/battle.c", "src/player.c", "src/enemies.c","src/layer_visuals.c",
            "src/effects.c", "src/game_config.c", "src/replay.c", "src/remote_input.c", "src/font.c", "-o", str(exe)]
subprocess.run(cmd, cwd=R, check=True)
p = subprocess.run([str(exe)], cwd=R, capture_output=True, text=True)
print(p.stdout, end="")
print(p.stderr, end="", file=__import__("sys").stderr)
ok = p.returncode == 0
(R / "results/dodge_controls.json").write_text(json.dumps({
    "passed": ok, "command": " ".join(cmd), "stdout": p.stdout,
}, indent=2))
print("DODGE_CONTROLS=" + ("PASS" if ok else "FAIL"))
raise SystemExit(0 if ok else 1)
