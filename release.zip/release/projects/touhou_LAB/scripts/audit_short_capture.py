#!/usr/bin/env python3
"""Read-only short-board-session audit and production-host replay check.

Uses annotated command UTC/wait intervals, excludes the first STAT once per
segment, and preserves failed windows. Never opens a COM port or programs FPGA.
"""
from pathlib import Path
from datetime import datetime,timedelta
import argparse,hashlib,json,re,shlex,statistics,subprocess
from replay_tool import parse_log
R=Path(__file__).resolve().parents[1]

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def metrics(rows):
    us=sum(x.get('us',0) for x in rows);sw=sum(x.get('swaps',0) for x in rows)
    return {'steady_windows':len(rows),'measured_us':us,'swaps':sw,'weighted_fps':sw*1e6/us if us else None,
        'N_min':min((x.get('N',0) for x in rows),default=None),'N_max':max((x.get('N',0) for x in rows),default=None),
        'render_sample_median_us':statistics.median([x['render'] for x in rows]) if rows else None,
        'logic_sample_median_us':statistics.median([x['logic'] for x in rows]) if rows else None,
        'overlap_sample_median_us':statistics.median([x.get('overlap',0) for x in rows]) if rows else None,
        'missed_sum':sum(x.get('missed',0) for x in rows),'UF_sum':sum(x.get('uf',0) for x in rows),
        'fxdrop_sum':sum(x.get('fxdrop',0) for x in rows)}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--session',type=Path,required=True);ap.add_argument('--plan',type=Path)
    ap.add_argument('--output-dir',type=Path,required=True);ap.add_argument('--host-cc',default='gcc');ap.add_argument('--boss-count',type=int,default=3);ap.add_argument('--enemy-count',type=int,default=0);a=ap.parse_args()
    S=a.session.resolve();O=a.output_dir.resolve();O.mkdir(parents=True,exist_ok=True)
    planpath=a.plan or next(S.glob('*_test_plan.jsonl'))
    session=json.loads((S/'session.json').read_text(encoding='utf-8'))
    rows=[];invalid=[]
    for i,line in enumerate((S/'uart_lines.jsonl').read_text(encoding='utf-8').splitlines()):
        try:rows.append(json.loads(line))
        except ValueError:invalid.append({'index':i,'line':line})
    plan=[json.loads(x) for x in planpath.read_text(encoding='utf-8').splitlines() if x.strip()]
    stats=[]
    for x in rows:
        if x.get('line','').startswith('STAT '):
            d={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',x['line'])};d['utc']=x['utc'];stats.append(d)
    segments=[]
    for i,entry in enumerate(plan):
        command=entry['command'];match=re.search(r'n(\d+)',command)
        pressure=bool(match and ('s' in command or 'pressure' in entry['label'] or 'stress' in entry['label']))
        combat=any(x in entry['label'] for x in ('battle','tuned')) and entry['wait']>=4
        if not pressure and not combat:continue
        start=datetime.fromisoformat(entry['utc']);end=start+timedelta(seconds=entry['wait'])
        if i+1<len(plan):end=min(end,datetime.fromisoformat(plan[i+1]['utc']))
        observed=[x for x in stats if start<=datetime.fromisoformat(x['utc'])<end]
        expected_count=int(match[1]) if pressure else None
        group=[x for x in observed if x.get('mode')==2 and x.get('N')==expected_count] if pressure else [x for x in observed if x.get('mode') in (1,3,4)]
        steady=group[1:]
        continuity=bool(group) and all('scan_total' in x and 'swap_total' in x for x in group)
        if continuity:
            continuity=all(((group[i]['scan_total']-group[i-1]['scan_total'])&0xffffffff)==group[i]['scan'] and ((group[i]['swap_total']-group[i-1]['swap_total'])&0xffffffff)==group[i]['swaps'] for i in range(1,len(group)))
        s={'label':entry['label'],'command':command,'start_utc':start.isoformat(),'end_utc':end.isoformat(),
           'expected_count':expected_count,'first_STAT_excluded_once':True,'observed_windows':len(group),**metrics(steady),
           'hardware_cumulative_counter_continuity':continuity,'by_mode':{str(m):metrics([x for x in steady if x.get('mode')==m]) for m in sorted({x.get('mode') for x in steady})},
           'cumulative_counter_baseline':{k:group[0].get(k) if group else None for k in ('ldrop','lover','drops')},
           'cumulative_counter_delta':{k:steady[-1].get(k,0)-group[0].get(k,0) if steady else None for k in ('ldrop','lover','drops')},
           'all_interval_windows':observed,'retained_windows':steady}
        s['short_cadence_clean']=bool(pressure and steady and continuity and len(group)==len(observed) and
            all(x['missed']==0 and x['uf']==0 and x['scan']==x['swaps'] and 5995<=x['fps100']<=6005 and 5995<=x['swaps']*100000000/x['us']<=6005 for x in steady) and
            all(s['cumulative_counter_delta'][k]==0 for k in ('ldrop','lover','drops')))
        if combat:s['scope']='Explicit DEMO/autoplay and tuning per command; active PLAY and terminal modes reported separately, not default gameplay acceptance.'
        segments.append(s)
    largest=max((x['expected_count'] for x in segments if x['short_cadence_clean']),default=None)
    perf={'status':'SHORT_RUN_ONLY','source_session':str(S),'elf_sha256':session['elf_sha256'],
        'method':'Annotated command UTC through min(nextUTC,start+wait); firstSTAT excluded once; native-us weighting; absolute scan_total/swap_total continuity, never frame_us.',
        'stability_600_seconds':'NOT_RUN','largest_short_cadence_clean_count':largest,'segments':segments,'capture_parse_errors':invalid}
    (O/'short_segments.json').write_text(json.dumps(perf,indent=2),encoding='utf-8')
    # Last complete dump only, preserving all complete-dump count metadata.
    dumps=[];current=[]
    for row in rows:
        text=row.get('line','')
        if text=='REPLAY_BEGIN':current=[text]
        elif current and text.startswith(('REPLAY_WORD','REPLAY_END')):
            current.append(text)
            if text.startswith('REPLAY_END'):dumps.append(current);current=[]
    cross={'status':'NOT_RUN','reason':'no complete replay dump'}
    if dumps:
        text='\n'.join(dumps[-1])+'\n';(O/'board_export_uart.txt').write_text(text,encoding='utf-8');obj=parse_log(text)
        (O/'board_export.json').write_text(json.dumps(obj,indent=2),encoding='utf-8');wordfile=O/'board_words.txt';wordfile.write_text('\n'.join(str(x) for x in obj['words'])+'\n',encoding='ascii')
        prefix=(R/'tests/phase_gameplay.c').read_text(encoding='utf-8-sig').split('static int failures;',1)[0]
        for name,args in [('scene_hud_begin','void'),('scene_hud_end','void'),('scene_hud_invalidate','void'),('scene_hud_cache_enable','unsigned enabled')]:
            if ('void '+name+'(') not in prefix:prefix+='\nvoid '+name+'('+args+') {'+('(void)enabled;' if 'enabled' in args else '')+'}\n'
        host=O/'board_replay_host.c';host.write_text(prefix+'\n#include "replay_game_body.h"\n',encoding='utf-8');exe=O/'board_replay_host.exe'
        cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
        command=cc+['-std=gnu11','-O2','-UNDEBUG','-Wno-unused-function','-Wno-unused-parameter','-Wno-misleading-indentation','-Isrc','-Itests/stub','-Itests',str(host),'src/stage.c','src/battle.c','src/player.c', 'src/enemies.c','src/layer_visuals.c','src/effects.c','src/game_config.c','src/font.c','src/replay.c','-o',str(exe)]
        p=subprocess.run(command,cwd=R,capture_output=True,text=True,timeout=60);(O/'host_compile.log').write_text(p.stdout+p.stderr,encoding='utf-8')
        q=subprocess.run([str(exe),str(wordfile),str(a.boss_count),str(a.enemy_count)],cwd=R,capture_output=True,text=True,timeout=60) if not p.returncode else None
        if q:(O/'host_replay.log').write_text(q.stdout+q.stderr,encoding='utf-8')
        identity=json.loads((R/'build/identity.json').read_text(encoding='utf-8'))
        cross={'status':'PASS' if q and q.returncode==0 and 'REPLAY_MODEL PASS' in q.stdout else 'FAIL','source_session':str(S),'board_header':obj['header'],'complete_dump_count':len(dumps),'selected_dump':'last complete dump',
               'board_replay_pass_observed':any('REPLAY PASS state hash' in x.get('line','') for x in rows),'CRC':'PASS','compile_command':command,'host_compile_exit':p.returncode,'host_replay_exit':q.returncode if q else None,
               'host_replay_output':q.stdout+q.stderr if q else None,'board_elf_sha256':sha(S/'firmware.elf'),'current_build_elf_sha256':identity['elf_sha256'],'no_hardware_access_by_analysis':True,
               'scope':'Actual bounded board input recording -> fresh host process running production game/runtime/battle/player modules. One held-zero-input RLE event is not movement/full-game coverage.',
               'final_capture_files':{n:{'bytes':len((S/n).read_bytes()),'sha256':sha(S/n)} for n in ('uart.bin','uart_lines.jsonl',planpath.name,'session.json')}}
        cross['current_build_matches_board_elf']=cross['board_elf_sha256']==identity['elf_sha256']
    (O/'board_to_pc_result.json').write_text(json.dumps(cross,indent=2),encoding='utf-8')
    print(json.dumps({'largest_short_cadence_clean_count':largest,'segments':[{k:s[k] for k in ('label','steady_windows','weighted_fps','missed_sum','UF_sum','hardware_cumulative_counter_continuity','short_cadence_clean')} for s in segments],
        'cross_PC':{k:v for k,v in cross.items() if k in ('status','board_header','host_replay_output','current_build_matches_board_elf')}},indent=2))
    return 0 if cross['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
