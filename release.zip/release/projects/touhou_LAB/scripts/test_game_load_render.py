"""Actual GAME_LOAD render diagnostics regression, with host clock/display stubs.

Includes this checkout's real game.c/game_load.inc and links real tick_profile.c.
This validates sampling, protocol and lifecycle, not hardware timing or FPS.
LIST is earlier CPU publication/preparation. The asynchronous BATCH interval can
cross COLLECT and FLUSH; these diagnostic categories must never be added as
exclusive CPU/GPU costs.
"""
from pathlib import Path
import argparse, hashlib, json, os, re, shlex, subprocess

P = Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser()
ap.add_argument('--host-cc', default=os.environ.get('HOST_CC', 'gcc'))
a = ap.parse_args()
CC = [x.strip('"') for x in shlex.split(a.host_cc, posix=False)]
O = P / 'build/game_load_render'
O.mkdir(parents=True, exist_ok=True)
V = P / 'results/validation'
V.mkdir(parents=True, exist_ok=True)
H = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = {str(p.relative_to(P)): H(p) for p in (P / 'src').glob('*') if p.is_file()}

prefix = (P / 'tests/phase_gameplay.c').read_text('utf-8-sig').split('static int failures;', 1)[0]
prefix = prefix.replace('#include "game.c"', '#include "' + (P / 'src/game.c').as_posix() + '"')
prefix = prefix.replace(
    'uint32_t bb_read(unsigned reg) { (void)reg; return 0; }',
    'static unsigned host_scan,host_swap;\nuint32_t bb_read(unsigned reg) { return reg==BB_FRAMES?host_scan:reg==BB_SWAPS?host_swap:0; }')
prefix = prefix.replace('unsigned uart_writeAvailability(unsigned u) { (void)u; return 0; }',
                        'unsigned uart_writeAvailability(unsigned u) { (void)u; return 4096; }')
prefix = prefix.replace('void uart_write(unsigned u, unsigned c) { (void)u; (void)c; }', r'''
static char host_wire[32768];static unsigned host_wire_at,host_diag_active;
void uart_write(unsigned u,unsigned c){
 (void)u;assert(host_wire_at+1<sizeof host_wire);host_wire[host_wire_at++]=(char)c;host_wire[host_wire_at]=0;
 if(c=='\n'){
  const char *s=host_wire+host_wire_at-1;while(s>host_wire&&s[-1]!='\n')--s;
  if(!strncmp(s,"GL_RENDER_",10)&&tick_profile_info().active)host_diag_active=1;
 }
}
''')
for fn, arg in [('scene_hud_begin', 'void'), ('scene_hud_end', 'void'),
                ('scene_hud_invalidate', 'void'), ('scene_hud_cache_enable', 'unsigned enabled')]:
    if 'void ' + fn + '(' not in prefix:
        prefix += '\nvoid ' + fn + '(' + arg + '){}\n'

core = r'''
static unsigned assertions;
#define CHECK(c) do{++assertions;if(!(c)){fprintf(stderr,"CHECK FAIL line=%u expr=%s\n",__LINE__,#c);exit(1);}}while(0)
static void drain(void){unsigned cap=10000;while(command_reply_count||txpos<txlen){CHECK(cap--);pump();}}
static void cli(const char *s){while(*s)uart_character(*s++);}
static unsigned occurrences(const char *prefix){
 unsigned n=0;const char *p=host_wire;while(*p){if(!strncmp(p,prefix,strlen(prefix)))++n;p=strchr(p,'\n');if(!p)break;++p;}return n;
}
static void line_copy(const char *prefix,char out[512]){
 const char *p=host_wire;unsigned matches=0;
 while(*p){if(!strncmp(p,prefix,strlen(prefix))){const char *e=strchr(p,'\n');CHECK(e);size_t n=(size_t)(e-p)+1;CHECK(n<=511);memcpy(out,p,n);out[n]=0;++matches;}p=strchr(p,'\n');if(!p)break;++p;}
 CHECK(matches==1);
}
static unsigned diag_number(const char *line,const char *key){
 char tag[64];snprintf(tag,sizeof tag,"%s=",key);const char *p=strstr(line,tag);CHECK(p);return (unsigned)strtoul(p+strlen(tag),0,10);
}
static uint64_t total(const char *line,const char *name){
 char lo[64],hi[64];snprintf(lo,sizeof lo,"%s_lo",name);snprintf(hi,sizeof hi,"%s_hi",name);
 return (uint64_t)diag_number(line,lo)|((uint64_t)diag_number(line,hi)<<32);
}
static void set_values(const unsigned v[6]){
 profile_collect_us=v[0];profile_flush_us=v[1];profile_hud_us=v[2];render_us=v[3];scene_list_us=v[4];scene_batch_cycles=v[5];
}
static void fixture(unsigned id,unsigned enabled){
 game_load_running=game_load_cancel=validate_requested=validation_active=0;battle_load_end();
 game_config_defaults();replay_reset();mode=MENU;choice=0;custom_limit=512;autoplay=demo_invincible=0;
 host_bullet_prepare_fail=host_bullet_guard_fail=0;host_ticks=host_scan=host_swap=0;
 command_reply_head=command_reply_count=command_reply_overruns=txpos=txlen=0;command_len=command_overflow=deferred_ascii=0;
 host_wire_at=host_diag_active=0;host_wire[0]=0;remote_input_init(&remote);frame_us=logic_us=render_us=0;
 tick_profile_enable(enabled);char cmd[128];snprintf(cmd,sizeof cmd,":gload run %u 6 12 1 8 60 123456789\n",id);cli(cmd);drain();
 CHECK(game_load_running&&!gl.ready&&!gl.render_diag&&!gl.render_samples);
 CHECK(occurrences("GLOAD_ACK ")==1);char line[512];line_copy("GLOAD_ACK ",line);
 CHECK(diag_number(line,"id")==id&&strstr(line,"op=run status=OK kind=GAME_LOAD")&&diag_number(line,"b")==6&&diag_number(line,"m")==12);
 CHECK(diag_number(line,"n")==1&&diag_number(line,"size")==8&&diag_number(line,"frames")==60&&diag_number(line,"seed")==123456789);
 CHECK(diag_number(line,"cfg")==gl.cfg&&diag_number(line,"deadline_us")==20000000);
}
static void ready(unsigned expected){
 const unsigned warm[6]={999,998,997,996,995,994};set_values(warm);
 game_load_after_swap(1,6,12);CHECK(!gl.frames&&!gl.render_samples);drain();
 render_warmup_advance();game_load_after_swap(1,6,12);CHECK(!gl.frames&&!gl.render_samples);
 render_warmup_advance();game_load_after_swap(1,6,12);CHECK(!gl.frames&&!gl.render_samples);
 /* Poison accumulators to prove READY resets the exact measured window. */
 gl.render_samples=77;for(unsigned i=0;i<GLR_PARTS;++i){gl.render_sum[i]=UINT64_MAX;gl.render_max[i]=UINT32_MAX;}
 game_load_ready(bb_ticks());drain();CHECK(gl.ready&&gl.render_diag==expected&&!gl.render_samples);
 for(unsigned i=0;i<GLR_PARTS;++i)CHECK(!gl.render_sum[i]&&!gl.render_max[i]);
 CHECK(occurrences("GLOAD_READY ")==1&&!occurrences("GL_RENDER_"));
}
static void sample(const unsigned v[6]){
 unsigned before=gl.frames;runtime_step();set_values(v);frame_us=16667;
 host_scan=host_swap=before+1;host_ticks=gl.start+(uint64_t)(before+1)*16667u-1u;
 game_load_after_swap(1,6,12);drain();CHECK(gl.frames==before+1);
 if(game_load_running)CHECK(!occurrences("GL_RENDER_"));
}
static void finish(void){game_load_finish("CANCEL","fixture_end");drain();CHECK(!game_load_running&&!tick_profile_info().active&&!host_diag_active&&!command_reply_overruns);}
static void verify_report(unsigned n,const uint64_t sums[6],const unsigned max[6]){
 char cpu[512],gpu[512];CHECK(occurrences("GL_RENDER_CPU ")==1&&occurrences("GL_RENDER_GPU ")==1);
 line_copy("GL_RENDER_CPU ",cpu);line_copy("GL_RENDER_GPU ",gpu);
 CHECK(diag_number(cpu,"id")==gl.id&&diag_number(gpu,"id")==gl.id&&diag_number(cpu,"samples")==n&&diag_number(gpu,"samples")==n);
 CHECK(strstr(cpu,"units=us\r\n")&&strstr(gpu,"units=cycles core_hz=100000000 overlap=1\r\n"));
 static const char *names[6]={"collect","flush","hud","render","list","batchcy"};
 for(unsigned i=0;i<6;++i){const char *s=i==5?gpu:cpu;char key[64];snprintf(key,sizeof key,"%s_max",names[i]);CHECK(total(s,names[i])==sums[i]&&diag_number(s,key)==max[i]);}
 CHECK(!strstr(cpu,"batchcy")&&!strstr(gpu,"flush_")&&!strstr(gpu,"list_"));
}
static void output_case(const char *name){
 const char *p=host_wire;while(*p){const char *e=strchr(p,'\n');CHECK(e);CHECK((unsigned)(e-p+1)<=511);p=e+1;}
 printf("WIRE_BEGIN %s\n",name);for(const char *q=host_wire;*q;++q)if(*q!='\r')putchar(*q);printf("WIRE_END %s\nCASE %s PASS\n",name,name);
}
int main(void){
 CHECK(TICK_PROFILE_REAL==1);CHECK(GLR_PARTS==6);
 const unsigned a[6]={1,2,3,4,5,6},b[6]={11,12,13,14,15,16},c[6]={101,102,103,104,105,106};
 fixture(7001,0);ready(0);sample(a);sample(b);CHECK(!gl.render_samples);finish();CHECK(!occurrences("GL_RENDER_")&&!occurrences("TICK_PROFILE "));output_case("default_off");
 fixture(7002,1);ready(1);tick_profile_enable(0);CHECK(gl.render_diag==1);sample(a);sample(b);sample(c);
 {uint64_t sums[6]={113,116,119,122,125,128};finish();verify_report(3,sums,c);CHECK(!occurrences("TICK_PROFILE "));}output_case("latched_on_known_samples");
 fixture(7003,0);ready(0);tick_profile_enable(1);CHECK(!gl.render_diag);sample(a);sample(b);CHECK(!gl.render_samples);finish();CHECK(!occurrences("GL_RENDER_")&&occurrences("TICK_PROFILE ")==1);output_case("latched_off");
 fixture(7004,1);ready(1);
 {const unsigned huge[6]={UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX};uint64_t sums[6];for(unsigned i=0;i<6;++i)sums[i]=8589934590ULL;
  sample(huge);sample(huge);for(unsigned i=0;i<6;++i)CHECK(gl.render_sum[i]==sums[i]);host_bullet_prepare_fail=1;finish();verify_report(2,sums,huge);CHECK(occurrences("ERR restored bullet preparation")==1&&occurrences("UI MENU")==1);}output_case("sum64_and_two_tail_slots");
 fixture(7005,1);ready(1);for(unsigned i=0;i<60;++i)sample(a);
 CHECK(!game_load_running&&!tick_profile_info().active&&!host_diag_active&&!command_reply_overruns);
 {uint64_t sums[6]={60,120,180,240,300,360};verify_report(60,sums,a);char done[512];line_copy("GLOAD_DONE ",done);CHECK(strstr(done,"status=PASS reason=complete"));}
 CHECK(occurrences("GLOAD_DETAIL ")==1&&occurrences("GLOAD_DONE ")==1);
 {unsigned count=occurrences("GL_RENDER_");game_load_finish("CANCEL","duplicate");drain();CHECK(occurrences("GL_RENDER_")==count);}output_case("automatic_finish_once");
 fixture(7006,1);ready(1);tick_profile_stop();
 gl.id=UINT32_MAX;gl.render_samples=UINT32_MAX;for(unsigned i=0;i<6;++i){gl.render_sum[i]=UINT64_MAX;gl.render_max[i]=UINT32_MAX;}
 game_load_render_report();drain();
 {const unsigned max[6]={UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX,UINT32_MAX};const uint64_t sums[6]={UINT64_MAX,UINT64_MAX,UINT64_MAX,UINT64_MAX,UINT64_MAX,UINT64_MAX};verify_report(UINT32_MAX,sums,max);}
 CHECK(!host_diag_active&&!command_reply_overruns);output_case("maximum_field_width");
 printf("GAME_LOAD_RENDER PASS cases=6 assertions=%u real_game_load=1 real_tick_profile=1 host_only=1\n",assertions);return 0;
}
'''

host = O / 'host.c'
host.write_text(prefix + core, encoding='utf8')
cmd = CC + ['-std=gnu11', '-O2', '-UNDEBUG', '-DTICK_PROFILE_HOST_ENABLE=1',
            '-Wno-misleading-indentation', '-I' + str(P / 'src'),
            '-I' + str(P / 'tests'), '-I' + str(P / 'tests/stub'), str(host)]
cmd += [str(P / 'src' / n) for n in ['stage.c', 'battle.c', 'player.c', 'enemies.c',
                                    'layer_visuals.c', 'effects.c', 'game_config.c',
                                    'font.c', 'replay.c', 'remote_input.c', 'tick_profile.c']]
exe = O / ('host.exe' if os.name == 'nt' else 'host')
cmd += ['-o', str(exe)]
compiled = subprocess.run(cmd, cwd=P, capture_output=True, text=True)
(O / 'compile.log').write_text(compiled.stdout + compiled.stderr, encoding='utf8')
assert compiled.returncode == 0, compiled.stdout + compiled.stderr
run = subprocess.run([str(exe)], cwd=P, capture_output=True, text=True, timeout=120)
log = run.stdout + run.stderr
(V / 'game_load_render.log').write_text(log, encoding='utf8')
assert run.returncode == 0, log[-6000:]

cases = []
ack_keys = set('id op status kind b m n size frames seed cfg deadline_us pipe hud_dma'.split())
stat_keys = set('id frames us swaps scans gap missed uf ldrop lover nmin nmax bmin bmax mmin mmax logicmax rendermax late'.split())
detail_keys = set('id frames fill recycle keep hits damage bhits mhits size seed cfg guards logerr qmin qmax lodsum fxdrop ddrop fault ticks runtime mode hw active paused invincible autoplay collision pipe hud_dma'.split())
cpu_keys = {'id', 'samples', 'units'} | {p + '_' + k for p in ['collect', 'flush', 'hud', 'render', 'list'] for k in ['lo', 'hi', 'max']}
gpu_keys = set('id samples batchcy_lo batchcy_hi batchcy_max units core_hz overlap'.split())
for m in re.finditer(r'WIRE_BEGIN (\S+)\n(.*?)WIRE_END \1\nCASE \1 PASS', run.stdout, re.S):
    name, wire = m.group(1), m.group(2)
    rows = []
    for line in wire.splitlines():
        if not line:
            continue
        assert len(line.encode('ascii')) + 2 <= 511, (name, line)
        fields = dict(token.split('=', 1) for token in line.split()[1:] if '=' in token)
        kind = line.split()[0]
        expected = {'GLOAD_ACK': ack_keys, 'GLOAD_STAT': stat_keys,
                    'GLOAD_DETAIL': detail_keys, 'GLOAD_DONE': {'id', 'status', 'reason'},
                    'GL_RENDER_CPU': cpu_keys, 'GL_RENDER_GPU': gpu_keys}.get(kind)
        if expected is not None:
            assert set(fields) == expected, (name, kind, set(fields) ^ expected)
        if kind in ('GLOAD_ACK', 'GLOAD_DETAIL'):
            assert fields['hud_dma'] == '0', (name, kind, fields['hud_dma'])
        if kind == 'GLOAD_DETAIL':
            assert fields['mode'] == '1' and fields['hw'] == '1' and fields['active'] == '1'
            assert fields['paused'] == fields['invincible'] == '0'
            assert fields['autoplay'] == '1' and fields['collision'] == 'scaled'
        rows.append({'kind': kind, 'fields': fields, 'line_bytes_with_CRLF': len(line) + 2})
    cases.append({'name': name, 'records': rows})
assert len(cases) == 6, log[-500:]
for f, sha in frozen.items():
    assert H(P / f) == sha, f
report = {'status': 'PASS', 'scope': 'Actual game.c/game_load.inc plus actual tick_profile.c; stub clocks/render; no physical timing/FPS',
          'cases': cases, 'case_count': 6, 'real_runtime_step_calls': 69,
          'assertions': int(re.search(r'assertions=(\d+)', run.stdout).group(1)),
          'line_limit_bytes_including_CRLF': 511, 'source_sha256': frozen,
          'compile_command': cmd, 'hardware_accessed': False,
          'interpretation': {'CPU_units': 'us', 'GPU_units': 'raw core cycles, core_hz=100000000',
                             'LIST': 'Earlier CPU descriptor publication/preparation before collect_begin',
                             'BATCH': 'Asynchronous interval can cross COLLECT and FLUSH; overlap=1',
                             'additive_exclusive_budget': False}}
(P / 'results/game_load_render.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
print(re.search(r'GAME_LOAD_RENDER PASS[^\n]+', run.stdout).group(0))
