"""Production single-tick profiler on/off semantic and reporting regression.
No port/device access; stub time is not a board performance measurement.
"""
from pathlib import Path
import argparse,ctypes,hashlib,json,os,shlex,subprocess,time
P=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'))
# Instrumentation equivalence uses this exact SW3 source with profiler off/on.
# Historical F3/SW2 semantics and physical scratch rules are tested separately.
ap.add_argument('--baseline-root',type=Path,default=P)
a=ap.parse_args();CC=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)];BASE=a.baseline_root.resolve();O=P/'build/tick_profile';O.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
frozen={str(p):sha(p) for p in sorted((BASE/'src').glob('*')) if p.is_file()}
core=r'''
static unsigned capture_size;
static unsigned char pub_blob[sizeof(Stage)+sizeof(GameConfig)+sizeof(PlayerState)+sizeof(player_shots)+sizeof(bosses)+64*sizeof(unsigned)];
static unsigned char *push_blob(unsigned char *p,const void *src,unsigned bytes){memcpy(p,src,bytes);return p+bytes;}
__declspec(dllexport) const void *public_snapshot(void){
 memset(pub_blob,0,sizeof(pub_blob));unsigned char *p=pub_blob;
 p=push_blob(p,&stage,sizeof stage);p=push_blob(p,&game_cfg,sizeof game_cfg);p=push_blob(p,&player,sizeof player);p=push_blob(p,player_shots,sizeof player_shots);p=push_blob(p,bosses,sizeof bosses);
 unsigned state[]={mode,choice,capacity_level,difficulty,hardware,autoplay,paused,demo_invincible,keys,edges,ticks,bomb_requests,runtime_tick,slowmo_remaining,slowmo_phase,dead_seen,custom_limit,
 battle_hit,battle_grazes,battle_materials,summon_done,battle_cleared,battle_density_slow,battle_density_skips,battle_near_candidates,battle_near_fallbacks,
 battle_load_active,battle_load_fills,battle_load_recycles,battle_load_keeps,battle_load_player_hits,battle_load_player_damage,battle_load_boss_hits,battle_load_mob_hits,player_homing_retargets};
 push_blob(p,state,sizeof state);return pub_blob;
}
__declspec(dllexport) unsigned public_bytes(void){return sizeof pub_blob;}
__declspec(dllexport) unsigned read_count(void){return host_bb_reads;}
__declspec(dllexport) unsigned real_hash(void){return runtime_state_hash();}
__declspec(dllexport) unsigned profile_calls(unsigned phase){
#ifdef TICK_PROFILE_REAL
 return tick_profile_phase(phase).calls;
#else
 (void)phase;return 0;
#endif
}
__declspec(dllexport) unsigned profile_enabled(void){
#ifdef TICK_PROFILE_REAL
 return tick_profile_info().enabled;
#else
 return 0;
#endif
}
static void drain_queue(void){while(command_reply_count){txlen=txpos=0;service_command_output();txpos=txlen;}txpos=txlen=0;}
static void cli(const char *s){while(*s)uart_character(*s++);}
void natural_seed(unsigned n,unsigned seed,unsigned side);
__declspec(dllexport) void init_case(unsigned n,unsigned side,unsigned seed,unsigned synthetic,unsigned armed){
 game_load_running=game_load_cancel=validate_requested=validation_active=0;battle_load_end();game_config_defaults();replay_reset();mode=MENU;choice=0;custom_limit=512;autoplay=demo_invincible=0;
 host_bullet_prepare_fail=host_bullet_guard_fail=0;host_ticks=host_bb_reads=0;command_reply_head=command_reply_count=command_reply_overruns=0;txpos=txlen=0;command_len=command_overflow=0;deferred_ascii=0;remote_input_init(&remote);
 frame_us=logic_us=render_us=0;
#ifdef TICK_PROFILE_REAL
 tick_profile_enable(armed);
#else
 (void)armed;
#endif
 char s[128];sprintf(s,":gload run 121 6 12 %u %u 36000 %u\n",n?n:1,side,seed);cli(s);drain_queue();render_warmup_advance();render_warmup_advance();game_load_ready(bb_ticks());drain_queue();
 if(!synthetic){game_load_running=0;battle_load_end();natural_seed(n,seed,side);}
#ifdef TICK_PROFILE_REAL
 tick_profile_restart();
#endif
}
__declspec(dllexport) void advance_case(unsigned t,unsigned synthetic){
 static const unsigned directions[]={0,1,2,4,8,3,12,0};keys=directions[(t/17)%8];edges=0;bomb_requests=(!synthetic&&t==200)?1:0;
 if(!synthetic&&(t==40||t==300||t==360)){
  for(unsigned k=0;k<6;++k){bosses[k].vulnerable=1;battle_apply_damage(k,t==40?1500:10000,1);}
 }
 runtime_step();
}
__declspec(dllexport) int check_cli_and_report(void){
#if defined(TICK_PROFILE_REAL) && TICK_PROFILE_REAL
 if(game_load_running)game_load_finish("CANCEL","fixture_end");
 show_menu();drain_queue();cli(":set tick_profile 1\n");if(!tick_profile_info().enabled)return 0;drain_queue();
 unsigned epoch=tick_profile_info().epoch;GameConfig saved=game_cfg;unsigned hash=runtime_config_hash();
 cli(":set tick_profile 2\n");if(!tick_profile_info().enabled||memcmp(&saved,&game_cfg,sizeof saved)||runtime_config_hash()!=hash||tick_profile_info().epoch!=epoch)return 0;drain_queue();
 choice=0;start();unsigned enabled=tick_profile_info().enabled;cli(":timing 0\n");if(tick_profile_info().enabled!=enabled)return 0;drain_queue();
 game_load_running=1;cli(":timing report\n");for(unsigned i=0;i<command_reply_count;++i)if(strncmp(command_replies[(command_reply_head+i)%COMMAND_REPLY_CAP],"TICK_PROFILE",12)==0)return 0;game_load_running=0;drain_queue();
 show_menu();drain_queue();cli(":timing report\n");unsigned header=0,phases=0;
 for(unsigned i=0;i<command_reply_count;++i){const char *p=command_replies[(command_reply_head+i)%COMMAND_REPLY_CAP];header+=!strncmp(p,"TICK_PROFILE",12);phases+=!strncmp(p,"TICK_PHASE",10);}
 if(header!=1||phases!=TP_PHASES||tick_profile_info().active)return 0;drain_queue();
 cli(":set tick_profile 0\n");if(tick_profile_info().enabled||tick_profile_info().active)return 0;return 1;
#else
 return 1;
#endif
}
'''
private=r'''
#include <stdint.h>
#include <string.h>
#include "BATTLE"
#include "EFFECTS"
#include "ENEMIES"
typedef struct {
 Effect effects[SHOT_CAPACITY];BattleVm vm[MAX_BOSSES];Fx fx[FX_CAP];OrdinaryEnemy enemies[ENEMY_CAPACITY];
 unsigned contact_count[CONTACT_BUCKETS];uint16_t contact_index[CONTACT_BUCKETS][CONTACT_BUCKET_CAP];unsigned flags[40];
} PrivateSnapshot;
static PrivateSnapshot saved;
__declspec(dllexport) unsigned private_bytes(void){return sizeof saved;}
__declspec(dllexport) const void *private_snapshot(void){
 memset(&saved,0,sizeof saved);memcpy(saved.effects,effects,sizeof effects);memcpy(saved.vm,vmb,sizeof vmb);memcpy(saved.fx,fx,sizeof fx);memcpy(saved.enemies,ordinary_enemies,sizeof ordinary_enemies);memcpy(saved.contact_count,contact_count,sizeof contact_count);memcpy(saved.contact_index,contact_index,sizeof contact_index);
 unsigned flags[]={legacy_mode,load_cursor,fx_overflow,graze_wait,quality_recovery,effects_jobs,effects_area,effects_over_budget,effects_active,effects_drop_total,effects_quality,effects_lod_jobs,
 configured,last_tick,seed,seed_ready,stopped,enemies_kills,enemies_spawns,enemies_despawns,enemies_requested,enemies_spawned,enemies_rejected,enemies_volleys_deferred,enemies_bullets_cleared,enemies_config_rejections};
 memcpy(saved.flags,flags,sizeof flags);return &saved;
}
void natural_seed(unsigned n,unsigned seed_value,unsigned side){
 game_cfg.enemy_bullet_size=side;battle_reset(2,SHOT_CAPACITY);stage.seed=seed_value;
 unsigned r=side/2;
 for(unsigned i=0;i<n;++i){unsigned v=stage_random();int x=(int)(r+v%(1024-2*r)),y=(int)(r+stage_random()%(688-2*r));battle_spawn_enemy_bullet(i%6,x,y,(int)(stage_random()&65535u),Q+(int)(v&4095u),54+(v&15u));}
 enemies_reset(12);enemies_load_begin();
}
'''
commands=[];libs=[]
for name,root in [('baseline',BASE),('disabled',P),('enabled',P)]:
 prefix=(root/'tests/phase_gameplay.c').read_text('utf-8-sig').split('static int failures;',1)[0]
 prefix=prefix.replace('#include "game.c"','#include "'+(root/'src/game.c').as_posix()+'"')
 prefix=prefix.replace('static uint64_t host_ticks;','static uint64_t host_ticks;static unsigned host_bb_reads;')
 prefix=prefix.replace('return ++host_ticks;','++host_bb_reads;return ++host_ticks;')
 for fn,arg in [('scene_hud_begin','void'),('scene_hud_end','void'),('scene_hud_invalidate','void'),('scene_hud_cache_enable','unsigned enabled')]:
  if 'void '+fn+'(' not in prefix:prefix+='\nvoid '+fn+'('+arg+'){}\n'
 prefix=prefix.replace('unsigned uart_writeAvailability(unsigned u) { (void)u; return 0; }','unsigned uart_writeAvailability(unsigned u) { (void)u; return 128; }')
 h=O/(name+'_host.c');h.write_text(prefix+core,encoding='utf8');extra=O/(name+'_private.c')
 extra.write_text(private.replace('BATTLE',(root/'src/battle.c').as_posix()).replace('EFFECTS',(root/'src/effects.c').as_posix()).replace('ENEMIES',(root/'src/enemies.c').as_posix()),encoding='utf8')
 cmd=CC+['-std=gnu11','-O2','-shared','-UNDEBUG','-Wno-misleading-indentation','-I'+str(root/'src'),'-I'+str(root/'tests'),'-I'+str(root/'tests/stub')]
 if name!='baseline':cmd+=['-DTICK_PROFILE_HOST_ENABLE=1']
 cmd +=[str(h),str(extra)]+[str(root/'src'/x) for x in ['stage.c','player.c','layer_visuals.c','game_config.c','font.c','replay.c','remote_input.c']]
 if name!='baseline':cmd+=[str(root/'src/tick_profile.c')]
 dll=O/(name+'.dll');cmd+=['-o',str(dll)];q=subprocess.run(cmd,cwd=root,capture_output=True,text=True);(O/(name+'_compile.log')).write_text(q.stdout+q.stderr,encoding='utf8');assert not q.returncode,(name,q.stderr)
 commands.append(cmd);lib=ctypes.CDLL(str(dll));lib.public_snapshot.restype=lib.private_snapshot.restype=ctypes.c_void_p;libs.append(lib)
sz=libs[0].public_bytes();pz=libs[0].private_bytes();assert all(l.public_bytes()==sz and l.private_bytes()==pz for l in libs)
checks=0;cases=[];max_samples=0;clear_seen=False;start=time.perf_counter()
def compare(tag):
 global checks
 data=[ctypes.string_at(l.public_snapshot(),sz)+ctypes.string_at(l.private_snapshot(),pz) for l in libs]
 for i in (1,2):assert data[0]==data[i],(tag,i,next(n for n,(x,y) in enumerate(zip(data[0],data[i])) if x!=y))
 assert libs[0].real_hash()==libs[1].real_hash()==libs[2].real_hash(),tag
 assert libs[0].read_count()==libs[1].read_count(),('disabled read overhead',tag,libs[0].read_count(),libs[1].read_count())
 checks+=1
for side,target in ((8,20000),(32,5000)):
 for synthetic in (0,1):
  for n,seed,duration in ((target,123456789,600),(1,0xffffffff,100),(0,9,100)):
   for i,l in enumerate(libs):l.init_case(n,side,seed,synthetic,i==2)
   compare(('init',side,n,synthetic))
   for t in range(duration):
    for l in libs:l.advance_case(t,synthetic)
    compare(('tick',side,n,seed,synthetic,t))
   assert libs[0].profile_enabled()==libs[1].profile_enabled()==0 and libs[2].profile_enabled()==1
   assert all(libs[1].profile_calls(i)==0 for i in range(11))
   total=libs[2].profile_calls(10);assert total>0
   if synthetic:assert total==duration
   clear_seen|=libs[2].profile_calls(7)>0;max_samples=max(max_samples,total)
   cases.append({'size':side,'initial_N':n,'synthetic':synthetic,'seed':seed,'requested_runtime_calls':duration,'timed_real_logic_calls':total,'per_phase_calls':[libs[2].profile_calls(i) for i in range(11)]})
assert clear_seen and max_samples==600
assert libs[1].check_cli_and_report()==1 and libs[2].check_cli_and_report()==1
for f,h in frozen.items():assert sha(f)==h,f
report={'status':'PASS','scope':'SW3 profiler off/on vs same-source inline-off per logical tick, including physical scratch; display/timer stubs, not physical time/FPS','full_state_points':checks,'comparison_bytes_per_point':sz+pz,'comparisons_per_point':2,'existing_state_hash_equal':True,'disabled_additional_timer_reads':0,'enabled_clear_owner_seen':clear_seen,'cases':cases,'elapsed_host_seconds':time.perf_counter()-start,'commands':commands,'untouched_baseline_sha256':frozen,'hardware_accessed':False}
(P/'results/tick_profile.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
summary=f'TICK_PROFILE PASS state_points={checks} bytes={sz+pz} SW3 off/on hashes equal; disabled_extra_timer_reads=0; per_tick_samples and CLI/outside-window reporting PASS; host-only'
(P/'results/validation/tick_profile.log').write_text(summary+'\n',encoding='utf8');print(summary)
