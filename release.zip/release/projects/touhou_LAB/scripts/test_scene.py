"""Compare optimized frame pixels to a full-frame redraw reference.

Host model delays each DMA until status polling and rejects unsafe CPU writes.
This checks scheduling/dirty-region correctness, not physical cache/AXI timing.
"""
from pathlib import Path
import argparse, ctypes, hashlib, json, os, re, shlex, subprocess
p = argparse.ArgumentParser()
p.add_argument("--host-cc", default=os.environ.get("HOST_CC", "gcc"))
a = p.parse_args()
cc = [x.strip('"') for x in shlex.split(a.host_cc, posix=False)]
r = Path(__file__).resolve().parents[1]
out = r / 'build/scene_test'
out.mkdir(exist_ok=True)
current = (r / 'src/scene.c').read_text()
baseline = current.replace('if(!(initialized_frames&bit)){', 'if(1){').replace('framebuffer=fb;hardware=hw;', 'hw=0;framebuffer=fb;hardware=hw;')
font = (r / 'src/font.c').read_text().replace('void draw_text(', 'void font_draw_text(')
(out / 'font.c').write_text(font)
libs = []
for name, source in [('baseline', baseline), ('optimized', current)]:
    source = source.replace('void scene_init(void){', 'void scene_init(void){\n    game_config_defaults();')
    source = source.replace('#include "stage.h"', '#include "stage.h"\n#define stage (*(Stage *)(uintptr_t)0x02100000u)')
    source = re.sub(r'SCENE_FENCE\(\);', '', source)
    source = re.sub(r'static inline uint32_t scene_read\([^\n]+', 'static inline uint32_t scene_read(unsigned reg){return bb_read(reg);}', source)
    source = re.sub(r'static inline void scene_write\([^\n]+', 'static inline void scene_write(unsigned reg,uint32_t v){bb_write(reg,v);}', source)
    (out / (name + '.c')).write_text(source)
    dll = out / (name + '.dll')
    cmd = cc + ['-O2', '-shared', '-DBB_HOST_TEST', '-Isrc', str(out / (name + '.c')), str(out / 'font.c'), 'src/pixels.c','src/render_queue.c', 'src/background.c', 'src/game_config.c', 'sim/scene_host.c', '-o', str(dll)]
    subprocess.run(cmd, cwd=r, check=True)
    libs.append(ctypes.CDLL(str(dll)))
k = ctypes.WinDLL('kernel32', use_last_error=True)
k.VirtualAlloc.restype = ctypes.c_void_p
k.VirtualAlloc.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_uint32, ctypes.c_uint32]
base = 0x01000000
size = 0x1200000
assert k.VirtualAlloc(base, size, 0x3000, 4) == base, ctypes.get_last_error()
assert k.VirtualAlloc(0x07000000,0x00400000,0x3000,4)==0x07000000, ctypes.get_last_error()
expected = []
checks = 0
for index, lib in enumerate(libs):
    ctypes.memset(base, 0xa5, size)
    lib.init_test()
    for f in range(64):
        if f in (4, 13, 27, 44):
            lib.cancelled_frame_test()
        lib.frame_test(f, int(f % 12 < 8))
        address = base + (0x400000 if f & 1 else 0)
        digest = hashlib.sha256(ctypes.string_at(address, 1280 * 720 * 4)).hexdigest()
        if index == 0:
            expected.append(digest)
        else:
            assert digest == expected[f], f'pixel mismatch frame {f}'
            checks += 1
result = {
    'passed': True,
    'frames_compared': checks,
    'reference': 'full background redraw',
    'source_sha256': hashlib.sha256(current.encode()).hexdigest(),
    'model': 'deferred DMA; CPU/GPU switches, clipping, overlap, alpha/key, new HUD/effect tiles, HUD row shortening, menu restoration',
    'pixel_sha256': expected,
}
(r / 'results/scene_pixels_batch720.json').write_text(json.dumps(result, indent=2))
print('PASS:', checks, 'complete 1280x720 frames match full redraw byte for byte')
