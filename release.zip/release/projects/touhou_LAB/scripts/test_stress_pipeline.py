#!/usr/bin/env python3
"""Instrument actual production main only for finite deterministic clock steps.

Every submitted descriptor set is compared with a serial non-gather reference.
Scene/MMIO hooks prove ordering semantics, not real physical DMA overlap/FPS.
"""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess,sys
R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));a=ap.parse_args()
cc=[x.strip('"') for x in shlex.split(a.host_cc,posix=False)]
B=R/'build/stress_pipeline';B.mkdir(parents=True,exist_ok=True)
source=(R/'src/game.c').read_text(encoding='utf-8-sig')
head,sep,main=source.partition('int main(void){');assert sep
needle='uint64_t last=bb_ticks();uint32_t acc_us=0;';assert needle in main
main=main.replace(needle,'pipeline_bootstrap();'+needle,1)
assert 'for(;;){' in main
main=main.replace('for(;;){','for(unsigned test_i=0;test_i<PIPELINE_ITERATIONS;++test_i){pipeline_iteration(test_i);',1)
tail=main.rfind('\n}');assert tail>=0;main=main[:tail]+'\n    pipeline_finished();return 0;'+main[tail:]
instrumented=B/'game_instrumented.c';instrumented.write_text(head+sep+main,encoding='utf-8')
prefix=(R/'tests/phase_gameplay.c').read_text(encoding='utf-8-sig').split('static int failures;',1)[0]
prefix=prefix.replace('#include "game.c"','#include "game_instrumented.c"')
for name,args in [('scene_hud_begin','void'),('scene_hud_end','void'),('scene_hud_invalidate','void'),('scene_hud_cache_enable','unsigned enabled')]:
 if ('void '+name+'(') not in prefix:prefix+='\nvoid '+name+'('+args+') {'+('(void)enabled;' if 'enabled' in args else '')+'}\n'
replacements={
 'void scene_batch_shots(void) {}':'void scene_batch_shots(void) {pipeline_submit();}',
 'void scene_batch_snapshot_ready(void) {}':'void scene_batch_snapshot_ready(void) {pipeline_snapshot();}',
 'void scene_end(void) {}':'void scene_end(void) {pipeline_end();}',
 'unsigned scene_cancelled(void) { return 0; }':'unsigned scene_cancelled(void) { return host_cancelled; }',
 'uint64_t bb_ticks(void) { return ++host_ticks; }':'uint64_t bb_ticks(void) { return host_ticks; }',
 'uint32_t bb_read(unsigned reg) { (void)reg; return 0; }':'uint32_t bb_read(unsigned reg) { return reg==BB_FRONT?BB_FB0:0; }',
}
for old,new in replacements.items():assert old in prefix,old;prefix=prefix.replace(old,new,1)
hooks='#define PIPELINE_ITERATIONS 14\nstatic unsigned host_cancelled;\nstatic void pipeline_bootstrap(void),pipeline_iteration(unsigned),pipeline_submit(void),pipeline_snapshot(void),pipeline_end(void),pipeline_finished(void);\n'
host=B/'stress_pipeline_host.c';host.write_text(hooks+prefix+'\n#include "stress_pipeline_body.h"\n',encoding='utf-8')
flags=['-std=gnu11','-O2','-UNDEBUG','-Wall','-Wextra','-Wno-unused-function','-Wno-unused-parameter','-Wno-misleading-indentation','-Isrc','-Itests/stub','-Itests']
results={}
def run(name,cmd):
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=60);print(p.stdout,end='');print(p.stderr,end='',file=sys.stderr)
 results[name]={'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'command':cmd}
 if p.returncode:raise RuntimeError(name+' failed')
try:
 exe=B/'stress_pipeline.exe'
 run('pipeline_build',cc+flags+[str(host),'src/stage.c','src/battle.c','src/player.c', 'src/enemies.c','src/layer_visuals.c','src/effects.c','src/game_config.c','src/font.c','src/replay.c','src/remote_input.c','-o',str(exe)])
 for label,kind,n in [('gpu64',0,64),('gpu4096',0,4096),('gpu20000',0,20000),('cpu',1,64),('disabled',2,64),('validation',3,64),('PLAY',4,64),('DODGE',5,64),('cancelled_render',6,64),('mode_change',7,64),('toggle_overlap',8,64)]:run(label,[str(exe),str(kind),str(n)])
 snap=B/'stress_snapshot.exe'
 run('snapshot_build',cc+flags+['-ffunction-sections','-fdata-sections','tests/stress_snapshot.c','src/render_queue.c','src/background.c','src/game_config.c','-Wl,--gc-sections','-o',str(snap)])
 run('snapshot_count_and_order',[str(snap)])
 status='PASS'
except Exception as e:status='FAIL';results['error']=str(e)
report={'status':status,'hardware_accessed':False,'game_source_sha256':hashlib.sha256(source.encode()).hexdigest(),'instrumentation':'Production main unchanged except finite loop/clock/bootstrap hooks; actual runtime/logic/render functions retained. Serial oracle disables gather.','scope':'Host ordering/count/state semantics only; MMIO model cannot certify physical DMA snapshot timing or overlap performance.','results':results}
(R/'results/stress_pipeline.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('STRESS_PIPELINE='+status);raise SystemExit(0 if status=='PASS' else 1)
