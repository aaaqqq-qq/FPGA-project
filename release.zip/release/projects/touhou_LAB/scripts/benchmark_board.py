#!/usr/bin/env python3
"""Collect every STAT window from the running serial monitor.

For --battle this deliberately does NOT filter on a requested bullet count:
a natural phase battle has a time-varying N (the pool is not forced to the
menu limit). All PLAY windows are retained and annotated with N, boss phases
and player level. Stress/dodge require the requested active count and limit
throughout every retained window; transitions or missing windows fail.
`--hz` is the target swap rate, not the core clock.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import time

R = Path(__file__).resolve().parents[1]
CMD = R / 'results/serial_commands.txt'
LOG = R / 'results/validation/touhou_uart.log'

ap = argparse.ArgumentParser()
ap.add_argument('--hz', type=int, default=60, help='target swap rate (not core MHz)')
ap.add_argument('--counts', default='512,640,704,768', help='stress/dodge count labels')
ap.add_argument('--seconds', type=int, default=20)
ap.add_argument('--battle', action='store_true')
ap.add_argument('--cpu', action='store_true')
ap.add_argument('--dodge', action='store_true')
ap.add_argument('--output', default='sweep.json')
a = ap.parse_args()
if a.seconds < 1 or a.hz < 1 or (a.battle and a.dodge):
    ap.error('positive seconds/hz and a single mode are required')


def digest(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


result = {
    'elf_sha256': digest(R / 'build/rumia.elf'),
    'bit_sha256': digest(R / 'hw/game/par/ddr_demo_ti60/outflow/ddr_demo_ti60.bit'),
    'resolution': [1280, 720], 'playfield': [1024, 688],
    'sprite_size': [8, 8], 'alpha': 224, 'color_key': 'ff00ff',
    'seed': '6e697468', 'interactive_dodge': a.dodge,
    'requested_hz': a.hz, 'runs': [],
}


def read_new(start: int) -> list[dict]:
    if not LOG.is_file():
        return []
    with LOG.open('rb') as f:
        f.seek(start)
        text = f.read().decode(errors='replace')
    rows = []
    for line in text.splitlines():
        if not line.startswith('STAT'):
            continue
        d = {k: int(v) for k, v in re.findall(r'(\w+)=(\d+)', line)}
        rows.append(d)
    return rows


def command_for(n: int) -> str:
    if a.battle:
        return 'mr'  # phase battle always uses the full 20000-budget pool
    if a.dodge:
        return f'mn{n}\ng'
    return f'mn{n}\n' + ('c' if a.cpu else 's')


def assess_windows(rows, n, options):
    """Require complete duration, continuous counters/configuration and no faults.

    This certifies STAT-window cadence only. No per-frame render maximum is
    exported by the current firmware, so no such timing claim can be made.
    """
    mode = 1 if options.battle else 5 if options.dodge else 2
    def matches(d):
        return (d.get('mode') == mode and d.get('hw') == int(not options.cpu)
                and (options.battle or d.get('N') == n and d.get('limit') == n))
    first = next((i for i,d in enumerate(rows) if matches(d)), len(rows))
    observed = rows[first:]
    keep = [d for d in observed if matches(d)]
    steady = keep[1:]
    reasons = []
    if any(not matches(d) for d in observed):
        reasons.append('mode_or_configuration_interrupted')
    required = ('mode','hw','N','limit','fps100','swaps','scan','us','scan_total',
                'missed','uf','ldrop','lover','drops','fxo','req','rejected')
    complete = all(all(k in d for k in required) for d in keep)
    if not complete: reasons.append('missing_required_telemetry')
    if len(steady) < 3: reasons.append('fewer_than_three_full_windows')
    if sum(d.get('us',0) for d in steady) < options.seconds*1000000:
        reasons.append('insufficient_measured_duration')
    if sum(d.get('swaps',0) for d in steady) < options.seconds*options.hz:
        reasons.append('insufficient_valid_swaps')
    if complete:
        previous = keep[0] if keep else None
        for d in steady:
            if not 1900000 <= d['us'] <= 2500000:
                reasons.append('irregular_or_missing_stat_window')
            if not options.hz*100-5 <= d['fps100'] <= options.hz*100+5:
                reasons.append('reported_fps_outside_target')
            rate100 = d['swaps']*100000000/max(1,d['us'])
            if not options.hz*100-5 <= rate100 <= options.hz*100+5:
                reasons.append('measured_fps_outside_target')
            if d['scan'] != d['swaps'] or any(d[k] != 0 for k in
                    ('missed','uf','ldrop','lover','drops','fxo')):
                reasons.append('frame_logic_log_or_effect_failure')
            if previous is not None and ((d['scan_total']-previous['scan_total']) & 0xffffffff) != d['scan']:
                reasons.append('frame_counter_discontinuity')
            if d['rejected'] > d['req'] or (not options.battle and d['rejected'] != 0):
                reasons.append('unexpected_emission_rejection')
            previous = d
    return keep, steady, sorted(set(reasons))


def run_once(n: int):
    start = LOG.stat().st_size if LOG.is_file() else 0
    with CMD.open('ab') as f:
        f.write(command_for(n).encode('ascii'))
    print('TEST', n, 'CPU' if a.cpu else 'FPGA', flush=True)
    # Padding accommodates one discarded transition window and UART tail.
    # Acceptance still requires the requested duration in measured STAT data.
    deadline = time.monotonic() + a.seconds + 6
    while time.monotonic() < deadline:
        time.sleep(0.5)
    rows = read_new(start)
    keep, steady, failure_reasons = assess_windows(rows,n,a)
    passed = not failure_reasons
    return {
        'count_label': n, 'seconds_requested': a.seconds, 'target_hz': a.hz,
        'passed_target_fps': passed, 'passed_60fps': passed and a.hz == 60,
        'failure_reasons': failure_reasons,
        'acceptance_scope': 'continuous full-duration STAT-window cadence, not per-frame timing',
        'all_observed_windows': rows,
        'windows': keep, 'full_windows': len(steady),
        'n_min': min((d.get('N', 0) for d in keep), default=None),
        'n_max': max((d.get('N', 0) for d in keep), default=None),
        'n_last': keep[-1].get('N') if keep else None,
        'boss_states_last': [keep[-1].get(f'b{i}') for i in range(3)] if keep else None,
        'enrage_mask_last': keep[-1].get('enr') if keep else None,
        'player_level_last': keep[-1].get('lv') if keep else None,
        'player_hp_last': keep[-1].get('php') if keep else None,
        'summon_last': keep[-1].get('summon') if keep else None,
        'measured_us': sum(d.get('us',0) for d in steady),
        'valid_swaps': sum(d.get('swaps',0) for d in steady),
        'last_frame_render_sample_max_us': max((d.get('render',0) for d in steady), default=None),
        'cumulative_logic_render_peak_us': max((d.get('max',0) for d in keep), default=None),
        'steady_peak_us': None, 'max_render_us': None,
    }


if a.battle:
    result['runs'].append(run_once(0))
else:
    for n in map(int, a.counts.split(',')):
        result['runs'].append(run_once(n))
out = R / 'results' / a.output
out.write_text(json.dumps(result, indent=2))
print('WROTE', out)
for run in result['runs']:
    print('RESULT', run['count_label'], 'N', run['n_min'], '..', run['n_max'],
          'PASS' if run['passed_target_fps'] else 'NOT_TARGET',
          'windows', len(run['windows']))
