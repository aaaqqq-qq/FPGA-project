from pathlib import Path
import struct,json,hashlib
R=Path(__file__).resolve().parents[1]
# Operand types from TH06 ECL layouts, verified against the local executable data.
F={2:'ii',3:'iii',4:'ii',5:'if',8:'if',13:'iii',16:'iii',17:'iii',20:'iff',21:'iff',27:'ii',28:'ff',29:'ii',30:'ii',31:'ii',32:'ii',33:'ii',34:'ii',35:'iif',36:'',47:'f',50:'ff',57:'ifff',61:'i',67:'hhiiffffi',68:'hhiiffffi',69:'hhiiffffi',70:'hhiiffffi',81:'fff',82:'iiiiffff',105:'i',131:'ffiiii'}
# Presentation-only events retained in the manifest rather than silently dropped.
OMIT={93:'spell title displayed by scene',96:'no other stage enemies',97:'scene animation',99:'scene animation attachment',106:'sound unavailable',112:'HP callback handled by scene',115:'user-requested 200 second/unlimited demo timer',116:'timeout callback handled by scene',118:'visual particles',120:'presentation flag'}
text='#pragma once\ntypedef struct {int time,op; int a[9];} OriginalOp;\n';manifest={'spells':[],'omitted':OMIT,'sources':[]}
for boss,(st,sub,label) in enumerate([(1,22,'Rumia: Night Bird'),(2,30,'Cirno: Hailstorm'),(3,29,'Meiling: Colorful Rainbow Wind Chime')]):
 path=R/f'assets/source/th06e_ST.DAT__ecldata{st}.ecl';d=path.read_bytes();n=struct.unpack_from('<H',d)[0];offs=list(struct.unpack_from('<%dI'%n,d,16))+[len(d)]
 subs=[sub]+([10]if boss==2 else[])
 for rank in [2,4,8]:
  allrows=[];starts={}
  for sn in subs:
   starts[sn]=len(allrows);p=offs[sn]
   while p<offs[sn+1]:
    t,op,size,m,_=struct.unpack_from('<i4H',d,p)
    if t==-1:break
    if m>>8&rank:
     assert op in F or op in OMIT,(boss,sn,op)
     if op in F:
      fmt=F[op];args=list(struct.unpack('<'+fmt,d[p+12:p+size]));args=[round(x*65536)if k=='f'else x for k,x in zip(fmt,args)];allrows.append([p,t,op,args,sn])
    p+=size
  for off,t,op,args,sn in allrows:
   if op in [2,3,29,30,31,32,33,34]:
    target=off+args[1];args[1]=next(i for i,row in enumerate(allrows)if row[4]==sn and row[0]>=target)
   if op==35:args[0]=starts[args[0]]
  name=f'original_{boss}_{rank}';text+=f'static const OriginalOp {name}[]={{\n'+''.join('{%d,%d,{%s}}, /* source offset %d */\n'%(t,op,','.join(map(str,args)),off)for off,t,op,args,sn in allrows)+'};\n'
 manifest['spells'].append({'boss':boss,'label':label,'stage':st,'sub':sub,'sha256':hashlib.sha256(d).hexdigest()})
text+='static const OriginalOp *const original_code[3][3]={{original_0_2,original_0_4,original_0_8},{original_1_4,original_1_4,original_1_8},{original_2_2,original_2_4,original_2_8}};\n'
(R/'src/original_battle_data.h').write_text(text)
(R/'results/original_battle_extraction.json').write_text(json.dumps(manifest,indent=2))
print('Extracted original 3-boss scripts, all three difficulties')
