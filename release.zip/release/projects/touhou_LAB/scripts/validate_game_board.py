"""Run each actual spell difficulty; requires serial monitor and autoplay ON."""
from pathlib import Path
import hashlib, json, re, time

root = Path(__file__).resolve().parents[1]
log = root / 'results/validation/touhou_uart.log'
commands = root / 'results/serial_commands.txt'
result = {'elf_sha256': hashlib.sha256((root/'build/rumia.elf').read_bytes()).hexdigest(),
          'autoplay': True, 'limit': 512, 'runs': []}
for difficulty, command in [('Normal', b'4r'), ('Hard', b'd'), ('Lunatic', b'd')]:
    offset = log.stat().st_size
    with commands.open('ab') as f:
        f.write(command)
    print('TEST', difficulty, flush=True)
    time.sleep(28)
    with log.open('rb') as f:
        f.seek(offset)
        text = f.read().decode(errors='replace')
    rows = []
    for line in text.splitlines():
        if line.startswith('STAT'):
            d = {k: int(v) for k,v in re.findall(r'(\w+)=(\d+)', line)}
            if d.get('mode') == 1 and d.get('hw') == 1:
                rows.append(d)
    steady = rows[1:]
    passed = len(steady) >= 3 and 'FAIL' not in text and all(
        5995 <= d['fps100'] <= 6005 and d['missed'] == 0 and d['uf'] == 0
        and d['rejected'] == 0 and d['scan'] == d['swaps'] for d in steady)
    result['runs'].append({'difficulty': difficulty, 'passed_60fps': passed,
                           'play_windows': rows, 'steady_play_windows': len(steady),
                           'raw_capture': text})
    (root/'results/game_v2.json').write_text(json.dumps(result, indent=2))
    print('RESULT', difficulty, passed, 'play windows', len(steady), flush=True)
with commands.open('ab') as f:
    f.write(b'v4rm')
print('RESTORED Normal menu, limit 512, autoplay OFF', flush=True)
