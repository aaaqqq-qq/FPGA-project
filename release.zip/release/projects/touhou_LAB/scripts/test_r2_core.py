#!/usr/bin/env python3
"""R2 production core regression: exact broadphase and bounded policy controls."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess,sys
from datetime import datetime,timezone
root=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));args=a.parse_args()
cc=[x.strip('"') for x in shlex.split(args.host_cc,posix=False)]
exe=root/'build/r2_core.exe'
cmd=cc+['-std=gnu11','-O2','-UNDEBUG','-Wall','-Wextra','-Wno-unused-parameter','-Isrc','-Itests/stub','tests/r2_core.c','src/stage.c','src/player.c', 'src/enemies.c','src/layer_visuals.c','src/effects.c','src/game_config.c','tests/host_scene_stubs.c','-o',str(exe)]
first=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=45)
log=first.stdout+first.stderr
status='FAIL';code=first.returncode
if not code:
    p=subprocess.run([str(exe)],cwd=root,capture_output=True,text=True,timeout=30)
    log+=p.stdout+p.stderr;code=p.returncode
    if not code and 'R2_CORE PASS checks=' in p.stdout:status='PASS'
(root/'results/validation').mkdir(parents=True,exist_ok=True)
(root/'results/validation/r2_core.log').write_text(log,encoding='utf-8')
print(log,end='')
(root/'results/r2_core.json').write_text(json.dumps({'status':status,'generated_utc':datetime.now(timezone.utc).isoformat(),'command':cmd,'exit_code':code,'checks':'production core assertions inclprivate replay hash, seven full/bucket movement/contact equivalence cases up to20000; enabled/disabled/legacy policies','source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['src/battle.c','src/player.c', 'src/enemies.c','src/layer_visuals.c','src/player.h','src/game_config.c','src/game_config.h','tests/r2_core.c']},'scope':'host semantic regression, not board FPS'},indent=2),encoding='utf-8')
sys.exit(0 if status=='PASS' else 1)
