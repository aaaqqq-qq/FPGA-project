"""Actual bounded segment aggregator tests. Synthetic ticks are not board timing."""
from pathlib import Path
import argparse, subprocess, json, hashlib
P=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--host-cc',default='E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe');a=a.parse_args()
O=P/'build/segment_diag';O.mkdir(parents=True,exist_ok=True)
R=P/'results/segment_diag';R.mkdir(parents=True,exist_ok=True)
code=r'''
#include <assert.h>
#include <stdio.h>
#include "segment_diag.h"
static uint64_t now;static unsigned reads;
uint64_t bb_ticks(void){++reads;return ++now;}
uint32_t bb_us(uint64_t x){return (uint32_t)(x/100);}
static void done_frame(uint64_t start,uint64_t step,uint64_t render,uint64_t swap){
 segment_diag_frame_begin(start);
 for(unsigned i=1;i<SD_SWAP_WAIT;++i)segment_diag_cut_at(i,start+i*step);
 segment_diag_frame_done(render,swap);
}
int main(void){
 segment_diag_enable(0);unsigned before=reads;
 segment_diag_frame_begin(1);segment_diag_cut(1);segment_diag_event(SDE_R_SUBMIT);
 segment_diag_nested_end(SD_PUBLISH,segment_diag_nested_begin());segment_diag_frame_done(2,3);
 assert(reads==before&&!segment_diag_info().samples);
 segment_diag_enable(1);SegmentInfo s=segment_diag_info();assert(reads-before==32&&s.read_min==1&&s.read_max==1&&s.timer_hz==100000000);
 segment_diag_restart(100);now=106;segment_diag_frame_begin(105);
 segment_diag_event(SDE_R_SUBMIT);unsigned saved_reads=reads;segment_diag_event(SDE_R_SUBMIT);assert(reads==saved_reads);
 uint64_t b=segment_diag_nested_begin();now+=5;segment_diag_nested_end(SD_PUBLISH,b);
 segment_diag_value(SD_M_CYCLES,1234);segment_diag_value(SD_R_READ,16384);
 for(unsigned i=1;i<SD_SWAP_WAIT;++i)segment_diag_cut_at(i,105+i*10);
 segment_diag_frame_done(220,250);s=segment_diag_info();assert(s.samples==1&&!s.order_errors&&!s.overflow);
 uint64_t sum=0;for(unsigned i=0;i<SD_WALL_COUNT;++i){assert(segment_diag_phase(i).calls==1);sum+=segment_diag_phase(i).sum;}
 assert(sum==150&&s.peak_render==115&&s.peak_period==150&&s.peak_frame==1&&s.peak_event_mask==1);
 assert(segment_diag_event_info(SDE_R_SUBMIT).calls==1&&segment_diag_peak_event(SDE_R_SUBMIT)==2);
 assert(segment_diag_phase(SD_PUBLISH).calls==1&&segment_diag_phase(SD_PUBLISH).sum==6);
 assert(segment_diag_phase(SD_M_CYCLES).sum==1234&&segment_diag_phase(SD_R_READ).sum==16384);
 done_frame(260,20,500,550);s=segment_diag_info();assert(s.samples==2&&!s.order_errors&&s.peak_frame==2&&s.peak_render==240&&s.peak_period==300);
 sum=0;for(unsigned i=0;i<SD_WALL_COUNT;++i){assert(segment_diag_phase(i).calls==2);sum+=segment_diag_phase(i).sum;}
 assert(sum==450);sum=0;for(unsigned i=0;i<SD_WALL_COUNT;++i)sum+=segment_diag_peak(i);assert(sum==s.peak_period);
 segment_diag_stop();before=reads;segment_diag_cut(0);segment_diag_event(0);segment_diag_nested_end(SD_ACQUIRE,0);assert(reads==before);
 segment_diag_restart(0);segment_diag_frame_begin(1);segment_diag_cut_at(SD_SNAPSHOT,2);assert(segment_diag_info().order_errors==1);
 segment_diag_stop();segment_diag_restart(0);segment_diag_frame_begin(UINT64_C(0x100000000));s=segment_diag_info();assert(s.overflow&&segment_diag_phase(SD_INTERFRAME).sum==UINT64_C(0x100000000)&&segment_diag_phase(SD_INTERFRAME).maximum==UINT32_MAX);
 segment_diag_stop();segment_diag_enable(0);assert(!segment_diag_info().enabled);puts("SEGMENT UNIT PASS disabled=zero_timer_reads calibration=32 ordered_partition=2frames nested_separate=1 peak_same_frame=1 invalid_order=reported overflow=saturated");return 0;
}
'''
c=O/'unit.c';c.write_text(code);exe=O/'unit.exe'
cmd=[a.host_cc,'-std=gnu11','-O2','-UNDEBUG','-DSEGMENT_DIAG_HOST_ENABLE','-DBSP_CLINT_HZ=100000000','-I'+str(P/'src'),str(c),str(P/'src/tick_profile.c'),'-o',str(exe)]
q=subprocess.run(cmd,capture_output=True,text=True);log=q.stdout+q.stderr
if q.returncode==0:
 q=subprocess.run([str(exe)],capture_output=True,text=True);log+=q.stdout+q.stderr
(R/'unit.log').write_text(log)
report={'status':'PASS' if q.returncode==0 else 'FAIL','exit_code':q.returncode,'command':cmd,'log':'results/segment_diag/unit.log','scope':'Production aggregate implementation, synthetic clock; not physical FPS','sources':{str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [P/'src/segment_diag.h',P/'src/segment_diag_impl.inc',P/'src/tick_profile.c']}}
(R/'unit.json').write_text(json.dumps(report,indent=2));print(log);raise SystemExit(q.returncode)
