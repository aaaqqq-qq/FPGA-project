from pathlib import Path
import subprocess,time,re,json,hashlib
r=Path(__file__).resolve().parents[1];log=r/'results/validation/touhou_uart.log';cmd=r/'results/serial_commands.txt'
def send(s):
 with cmd.open('ab')as f:f.write(s.encode())
def read(offset):
 with log.open('rb')as f:f.seek(offset);return f.read().decode(errors='replace')
def bench(*args):subprocess.run([r'D:\Python312\python.exe','-X','utf8','scripts/benchmark_board.py',*args],cwd=r,check=True)
send('i')
bench('--counts','19456,20480','--dodge','--seconds','24','--output','final60_dodge_boundary.json')
bench('--counts','21504','--seconds','180','--output','final60_stress_long.json')
identity={'elf_sha256':hashlib.sha256((r/'build/rumia.elf').read_bytes()).hexdigest(),'bit_sha256':hashlib.sha256((r/'hw/game/par/ddr_demo_ti60/outflow/ddr_demo_ti60.bit').read_bytes()).hexdigest()}
comparisons=[]
for key in ('x','y'):
 offset=log.stat().st_size;send(key);deadline=time.monotonic()+40
 while time.monotonic()<deadline:
  time.sleep(.5);text=read(offset)
  rows=[{k:int(v)for k,v in re.findall(r'(\w+)=(\d+)',line)}for line in text.splitlines()if line.startswith('BATCH_COMPARE')]
  if len(rows)>=3:break
 assert len(rows)==3 and all(x['errors']==0 for x in rows),text
 comparisons.extend(rows);print('CPU/GPU pixel compare',key,'PASS',flush=True);time.sleep(2)
(r/'results/final60_pixels.json').write_text(json.dumps({**identity,'passed':True,'frames':comparisons},indent=2))
offset=log.stat().st_size;send('n4096\nrdd');time.sleep(65)
rows=[{k:int(v)for k,v in re.findall(r'(\w+)=(\d+)',line)}for line in read(offset).splitlines()if line.startswith('STAT')]
steady=[d for d in rows if d.get('mode')==1][1:]
passed=len(steady)>20 and all(5995<=d['fps100']<=6005 and d['uf']==0 and d['missed']==0 and d['rejected']==0 for d in steady)
(r/'results/final60_threeboss.json').write_text(json.dumps({**identity,'passed':passed,'difficulty':'Lunatic','windows':rows},indent=2));print('Three boss Lunatic',passed,flush=True)
send('m')
