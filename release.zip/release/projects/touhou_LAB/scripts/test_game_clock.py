"""Real main/input timing and ordered-input regressions; mocked timer/display.

Place in scripts/, with tests/game_clock/reference_game_SIZE2.c and
reference_game_load_SIZE2.inc. Candidate directly includes this project's
src/game.c. No device access or physical performance claim.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,shlex,subprocess,sys,time

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--host-cc',default=os.environ.get('HOST_CC','gcc'));args=parser.parse_args()
CC=[x.strip('"') for x in shlex.split(args.host_cc,posix=False)]
B=ROOT/'build/game_clock';B.mkdir(parents=True,exist_ok=True)
OUT=ROOT/'results/validation/game_clock.log';OUT.parent.mkdir(parents=True,exist_ok=True)
source=ROOT/'src/game.c';reference=ROOT/'tests/game_clock/reference_game_SIZE2.c'
source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
logs=[];commands=[];clock_rows=[];input_rows=[]

def run(cmd,label,timeout=120):
 q=subprocess.run(list(map(str,cmd)),cwd=ROOT,capture_output=True,text=True,timeout=timeout)
 (B/(label+'.log')).write_text(q.stdout+q.stderr,encoding='utf8')
 commands.append({'label':label,'command':list(map(str,cmd)),'exit_code':q.returncode})
 if q.returncode:raise AssertionError((label,q.stdout[-1500:],q.stderr[-2000:]))
 return q.stdout

def fixture_prefix(game):
 s=(ROOT/'tests/phase_gameplay.c').read_text('utf-8-sig').split('static int failures;',1)[0]
 s=s.replace('#include "game.c"','#include "'+game.as_posix()+'"')
 # The actual source's textfmt invokes va_start. This hook changes only the
 # mocked wall clock, not production main, scheduler, counters or runtime_step.
 s=s.replace('#define main firmware_main','''#undef va_start
#define va_start(ap,last) (host_format_cost(last),__builtin_va_start(ap,last))
#define main firmware_main''')
 for name,a in [('scene_hud_begin','void'),('scene_hud_end','void'),('scene_hud_invalidate','void'),('scene_hud_cache_enable','unsigned enabled')]:
  if 'void '+name+'(' not in s:s+='\nvoid '+name+'('+a+'){}\n'
 return s

PRE='''#include <stdint.h>
#include <setjmp.h>
static uint64_t host_clock;
static unsigned host_scan,host_swap,host_front=0x01000000,host_render_us,host_ready_us,host_seen_ready;
static unsigned host_runtime_calls,host_freeze_runtime,host_ready_calls;
static char host_command[128];static jmp_buf host_exit;
void host_format_cost(const char *fmt);
'''
CLOCK_TAIL='''
void bsp_init(void){const char *s=host_command;host_uart_at=host_uart_end=0;while(*s)host_uart[host_uart_end++]=(unsigned char)*s++;}
void host_format_cost(const char *fmt){if(strncmp(fmt,"GLOAD_READY",11)==0||strncmp(fmt,"PLAY_READY",10)==0){host_clock+=(uint64_t)host_ready_us*100;++host_ready_calls;}}
void __attribute__((no_instrument_function)) __cyg_profile_func_enter(void *f,void *caller){
 (void)caller;if(f==(void*)runtime_step){++host_runtime_calls;if(host_freeze_runtime)replay_play_begin(123);}
}
void __attribute__((no_instrument_function)) __cyg_profile_func_exit(void *f,void *caller){(void)f;(void)caller;}
int main(int argc,char **argv){
 if(argc!=4&&argc!=5)return 2;
 host_ready_us=(unsigned)strtoul(argv[1],0,10);host_render_us=(unsigned)strtoul(argv[2],0,10);
 unsigned frames=(unsigned)strtoul(argv[3],0,10);host_freeze_runtime=argc==5;
 sprintf(host_command,":gload run 777 1 0 1 8 %u 123456789\\n",frames);
 if(!setjmp(host_exit))firmware_main();
 const char *done="MISSING";
 for(unsigned i=0;i<COMMAND_REPLY_CAP;++i)if(strncmp(command_replies[i],"GLOAD_DONE id=777",16)==0)done=command_replies[i];
 printf("CLOCK_RESULT ready=%u render=%u frames=%u measured=%u us=%u swaps=%u scans=%u gap=%u missed=%u uf=%u ticks=%u runtime=%u calls=%u readycalls=%u ldrop=%u lover=%u logicmax=%u rendermax=%u DONE %s\\n",host_ready_us,host_render_us,frames,gl.frames,gl.us,gl.swaps,gl.scans,gl.gap,gl.missed,gl.uf,gl.logic_ticks,runtime_tick,host_runtime_calls,host_ready_calls,logic_drops,logic_overruns,gl.logicmax,gl.rendermax,done);
 return 0;
}
'''
clock_sources=['src/stage.c','src/battle.c','src/player.c','src/enemies.c','src/layer_visuals.c','src/effects.c','src/game_config.c','src/font.c','src/replay.c','src/remote_input.c']
def compile_host(h,exe,instrument=False):
 run(CC+['-std=gnu11','-O2','-UNDEBUG','-Wno-misleading-indentation','-Isrc','-Itests/stub','-Itests']+(['-finstrument-functions'] if instrument else [])+[str(h),*clock_sources,'-o',str(exe)],exe.stem+'_compile')

def clock_program(game,label):
 s=fixture_prefix(game).replace('static uint64_t host_ticks;','')
 s=s.replace('uint32_t bb_read(unsigned reg) { (void)reg; return 0; }','uint32_t bb_read(unsigned reg){return reg==BB_FRAMES?host_scan:reg==BB_SWAPS?host_swap:reg==BB_FRONT?host_front:0;}')
 s=s.replace('uint64_t bb_ticks(void) { return ++host_ticks; }','uint64_t bb_ticks(void){host_clock+=100;return host_clock;}')
 s=s.replace('uint32_t bb_us(uint64_t t) { return (uint32_t)t; }','uint32_t bb_us(uint64_t t){return (uint32_t)(t/100);}')
 s=s.replace('void scene_begin(uint32_t fb, unsigned hw) { (void)fb; (void)hw; }','void scene_begin(uint32_t fb,unsigned hw){(void)fb;(void)hw;if(game_load_running)host_clock+=(uint64_t)host_render_us*100;}')
 s=s.replace('bb_result bb_swap_wait(uint32_t fb, uint32_t t) { (void)fb; (void)t; return BB_OK; }','''bb_result bb_swap_wait(uint32_t fb,uint32_t t){
 (void)t;unsigned next=(unsigned)(host_clock*60/100000000)+1;
 host_clock=((uint64_t)next*100000000+59)/60;host_scan=next;++host_swap;host_front=fb;
 if(game_load_running&&gl.ready)host_seen_ready=1;return BB_OK;
}''')
 s=s.replace('void bsp_init(void) {}','void bsp_init(void);')
 s=s.replace('unsigned uart_writeAvailability(unsigned u) { (void)u; return 0; }','unsigned uart_writeAvailability(unsigned u){(void)u;return 128;}')
 s=s.replace('unsigned uart_readOccupancy(unsigned u) { (void)u; return host_uart_end-host_uart_at; }','''unsigned uart_readOccupancy(unsigned u){(void)u;if(host_seen_ready&&!game_load_running)longjmp(host_exit,1);return host_uart_end-host_uart_at;}''')
 h=B/(label+'_clock.c');h.write_text(PRE+s+CLOCK_TAIL,encoding='utf8');exe=B/(label+'_clock.exe');compile_host(h,exe,True);return exe

INPUT_TAIL='''
void host_format_cost(const char *fmt){(void)fmt;}
static unsigned input_checks;
#define CK(x) do{++input_checks;if(!(x)){printf("INPUT_FAIL %u %s\\n",__LINE__,#x);return 1;}}while(0)
static void setup(void){
 game_load_running=game_load_cancel=validate_requested=validation_active=0;battle_load_end();game_config_defaults();replay_reset();mode=MENU;choice=0;custom_limit=512;autoplay=demo_invincible=0;
 host_bullet_prepare_fail=host_bullet_guard_fail=0;host_ticks=0;command_reply_head=command_reply_count=command_reply_overruns=0;txpos=txlen=0;command_len=command_overflow=0;host_uart_at=host_uart_end=0;
 deferred_ascii=0;remote_input_init(&remote);
}
static void append_byte(unsigned c){host_uart[host_uart_end++]=(unsigned char)c;}
static void ascii(const char *s){while(*s)append_byte((unsigned char)*s++);}
static void packet(unsigned seq,unsigned mask){append_byte(0xa5);append_byte(0x5a);append_byte(seq);append_byte(mask);append_byte(0);append_byte(seq^mask^0xa7);}
static void feed_all(void){input();game_load_poll_cancel();}
int main(void){
 setup();packet(0,0);packet(1,REMOTE_MENU);packet(2,0);ascii(":gload run 91 1 0 1 8 60 1\\n");feed_all();
 unsigned stale_survives=game_load_running&&!game_load_cancel;
 printf("INPUT_OBSERVE stale_menu_before_run=%u\\n",stale_survives);
#ifdef EXPECT_FIXED_INPUT
 CK(stale_survives&&remote.held==0&&remote.sequence==2);
 // Genuine later edge, including in the same input batch, remains a cancel.
 packet(3,REMOTE_MENU);feed_all();CK(!game_load_running&&game_load_cancel==0&&mode==MENU);
 setup();packet(0,0);packet(1,REMOTE_MENU);packet(2,0);ascii(":gload run 92 1 0 1 8 60 1\\n");packet(3,REMOTE_MENU);feed_all();CK(!game_load_running&&mode==MENU);
 // Held old MENU is consumed at command boundary but preserved as held state.
 setup();packet(0,REMOTE_MENU);ascii(":gload run 93 1 0 1 8 60 1\\n");feed_all();CK(game_load_running&&remote.held==REMOTE_MENU&&remote.sequence==0&&!remote.pressed);
 packet(1,0);feed_all();CK(game_load_running);packet(2,REMOTE_MENU);feed_all();CK(!game_load_running);
 // Packet sequence protection survives the boundary; stale/repeated packets
 // cannot be reinterpreted as fresh MENU presses after a parser reset.
 setup();packet(10,0);packet(11,REMOTE_MENU);packet(12,0);ascii(":gload run 94 1 0 1 8 60 1\\n");feed_all();CK(game_load_running);
 packet(11,REMOTE_MENU);packet(12,0);feed_all();CK(game_load_running&&remote.rejected==1&&remote.duplicates==1&&remote.sequence==12);
 // Every possible fragmentation boundary of the coalesced transaction.
 for(unsigned split=0;split<=56;++split){
  setup();packet(0,0);packet(1,REMOTE_MENU);packet(2,0);ascii(":gload run 95 1 0 1 8 60 1\\n");unsigned total=host_uart_end;
  unsigned first=split<total?split:total;host_uart_end=first;feed_all();host_uart_end=total;feed_all();CK(game_load_running&&!game_load_cancel&&remote.sequence==2);
 }
 // Byte-at-a-time transport preserves the same result.
 setup();packet(0,0);packet(1,REMOTE_MENU);packet(2,0);ascii(":gload run 96 1 0 1 8 60 1\\n");unsigned total=host_uart_end;
 for(unsigned n=1;n<=total;++n){host_uart_end=n;feed_all();}CK(game_load_running&&!game_load_cancel);
 // ASCII menu used by GUI-owned transactions has no virtual-key edge.
 setup();ascii(":menu\\n:gload run 97 1 0 1 8 60 1\\n");feed_all();CK(game_load_running&&!game_load_cancel);
 // Explicit command cancellation and a post-start ESC fragment remain active.
 ascii(":gload cancel 97\\n");feed_all();CK(!game_load_running&&mode==MENU);
 setup();ascii(":gload run 98 1 0 1 8 60 1\\n");feed_all();CK(game_load_running);
 packet(0,REMOTE_MENU);total=host_uart_end;host_uart_end=total-1;feed_all();CK(game_load_running);host_uart_end=total;feed_all();CK(!game_load_running);
 // Rejected run commands do not silently consume unrelated input edges.
 setup();packet(0,REMOTE_START);ascii(":gload run 99 0 0 1 8 60 1\\n");feed_all();CK(!game_load_running&&mode==PLAY);
#else
 CK(!stale_survives&&mode==MENU);
#endif
 printf("INPUT_PASS checks=%u\\n",input_checks);return 0;
}
'''

def main():
 started=time.monotonic();exes={label:clock_program(game,label) for label,game in [('baseline',reference),('candidate',source)]}
 for ready in (0,1,50,2500,15000,22000):
  for render in (100,1000,8000,17000,40000,80000):
   for label,exe in exes.items():
    out=run([exe,ready,render,60],f'{label}_{ready}_{render}_60');line=[x for x in out.splitlines() if x.startswith('CLOCK_RESULT')][-1]
    row={'label':label,'line':line,**{k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)}};row['pass']='status=PASS' in line;clock_rows.append(row)
    assert row['readycalls']==2 and row['runtime']<=row['calls']
    if label=='candidate' and ready<=2500 and render<=8000:assert row['pass'] and row['ticks']==row['calls']==60 and row['missed']==0,line
    if label=='baseline' and ready<=2500 and render<=8000:assert not row['pass'] and row['ticks']==58,line
    if render>=17000:assert not row['pass'] and row['missed']>0,line
    if label=='candidate' and ready>=15000:assert not row['pass'] and row['missed']>0,line
    if render==80000:assert row['ldrop']>0 and row['lover']>0,line
 for frames in (600,36000):
  for label,exe in exes.items():
   out=run([exe,50,1000,frames],f'{label}_50_1000_{frames}');line=[x for x in out.splitlines() if x.startswith('CLOCK_RESULT')][-1]
   row={'label':label,'line':line,**{k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)}};row['pass']='status=PASS' in line;clock_rows.append(row)
   assert row['pass']==(label=='candidate') and row['ticks']==frames-(0 if label=='candidate' else 2),line
   if label=='candidate':assert row['calls']==frames and row['missed']==row['ldrop']==row['lover']==0,line
 # Force real runtime_step to encounter a replay fault after run acceptance.
 out=run([exes['candidate'],0,1000,60,'freeze_runtime'],'candidate_actual_runtime_fault')
 assert 'status=FAIL reason=timing' in out and ' ticks=0 runtime=0 ' in out and ' calls=60 ' in out,out
 logs.append('CLOCK_PASS 72 short + 4 duration cases; actual main/runtime_step, READY cost and rational100MHz/vblank; slow/drop/frozen runtime remain FAIL')
 for label,game in [('baseline',reference),('candidate',source)]:
  s=fixture_prefix(game);h=B/(label+'_input.c');h.write_text('void host_format_cost(const char *);\n'+s+INPUT_TAIL,encoding='utf8');exe=B/(label+'_input.exe')
  flags=['-DEXPECT_FIXED_INPUT'] if label=='candidate' else []
  run(CC+['-std=gnu11','-O2','-UNDEBUG','-Wno-misleading-indentation','-Isrc','-Itests/stub','-Itests',*flags,str(h),*clock_sources,'-o',str(exe)],label+'_input_compile')
  out=run([exe],label+'_input');input_rows.append({'label':label,'output':out});logs.append(out.strip())
 assert hashlib.sha256(source.read_bytes()).hexdigest()==source_hash
 report={'status':'PASS','scope':'production main/input/runtime, independent timer/vblank/format/render fixtures; not physical FPS','hardware_accessed':False,'clock_cases':76,'runtime_fault_cases':1,'clock_results':clock_rows,'input_results':input_rows,'seconds':time.monotonic()-started,'production_game_sha256':source_hash,'commands':commands}
 (ROOT/'results/game_clock.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');logs.append('GAME_CLOCK PASS direct production include; no candidate source copying or runtime counter rewrites')
 OUT.write_text('\n'.join(logs)+'\n',encoding='utf8');print('\n'.join(logs));return 0

if __name__=='__main__':
 try:sys.exit(main())
 except Exception as e:
  logs.append('GAME_CLOCK FAIL '+repr(e));OUT.write_text('\n'.join(logs)+'\n',encoding='utf8');print('\n'.join(logs));raise
