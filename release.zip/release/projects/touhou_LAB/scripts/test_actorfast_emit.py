"""Actual extracted engine ordered-MMIO and 32-bit clipping equivalence.

No board, no FPS claim. Generated extracted source, compile commands, traces
and failure logs are retained in a fresh per-run result directory.
"""
from pathlib import Path
from datetime import datetime
import hashlib, json, subprocess
P=Path(__file__).resolve().parents[1]
B=P.parent/'game60_pipe5_reportoverlap_fw_20261103'
O=P/'results/actorfast_emit'/datetime.now().strftime('%Y%m%d_%H%M%S_%f')
O.mkdir(parents=True)
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def function(source,name):
    start=source.index(name+'(')
    start=source.rfind('\n',0,start)+1
    begin=source.index('{',start);depth=1;end=begin+1
    while depth:
        if source[end]=='{':depth+=1
        if source[end]=='}':depth-=1
        end+=1
    return source[start:end]

prefix=r'''
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <setjmp.h>
#include "bitblt.h"
#include "pipe5_abi.h"
#include "segment_diag.h"
typedef struct {unsigned epoch,count,alpha,flags,key,bank;} SceneSubmission;
static SceneSubmission frame_submission;
static bb_job previous;
static unsigned cache_valid,pending_job,pending_pipe_job,pending_epoch,next_render_epoch,frame_pipe_epoch,batch_count,scene_batch_cycles;
static uint32_t regs[256];static unsigned injection,trace_count,capabilities;
static uint32_t trace[32768][3];static uint64_t fake_ticks;static jmp_buf failed;
static void mark(unsigned kind,unsigned reg,unsigned value){assert(trace_count<32768);trace[trace_count][0]=kind;trace[trace_count][1]=reg;trace[trace_count++][2]=value;}
static uint32_t scene_read(unsigned reg){
 uint32_t value=reg==0x4c?capabilities:reg==BB_STATUS?BB_DONE:reg==PIPE5_R_STATUS?BB_DONE:regs[reg/4];
 if(injection==1&&reg==BB_STATUS)value=BB_ERROR;
 if(injection==2&&reg==PIPE5_FAULT)value=1;
 if(injection==3&&reg==PIPE5_M_STATUS)value=PIPE5_BUSY;
 if(injection==4&&reg==BB_ALPHA)value^=1;
 if(injection==5&&reg==BB_STATUS)value=BB_BUSY;
 if(injection==6&&reg==PIPE5_R_DONE_EPOCH)value^=1;
 mark(1,reg,value);return value;
}
static void scene_write(unsigned reg,uint32_t value){mark(2,reg,value);regs[reg/4]=value;}
#define SCENE_FENCE() mark(3,0,0)
uint64_t bb_ticks(void){fake_ticks+=100001;return fake_ticks;}
uint32_t bb_us(uint64_t t){return (uint32_t)t;}
void fatal(const char *where,int value){unsigned hash=2166136261u;for(;*where;++where)hash=(hash^(unsigned char)*where)*16777619u;mark(4,hash,(unsigned)value);longjmp(failed,1);}
'''
suffix=r'''
int main(int argc,char **argv){
 assert(argc==2);FILE *out=fopen(argv[1],"wb");assert(out);
 unsigned cases=0;
 for(unsigned invalid=0;invalid<2;++invalid)for(unsigned mask=0;mask<2048;++mask){
  memset(regs,0,sizeof regs);memset(&frame_submission,0,sizeof frame_submission);trace_count=0;fake_ticks=0;injection=0;
  uint32_t *old=(uint32_t*)&previous;bb_job job;uint32_t *next=(uint32_t*)&job;
  for(unsigned k=0;k<11;++k){old[k]=k?0x1000+k*0x12345u:1;next[k]=old[k]+((mask>>k)&1u);regs[(BB_OP+k*4)/4]=old[k];}
  capabilities=(mask&2)?PIPE5_CAP_CONCURRENT_EPOCH:0;
  cache_valid=!invalid;pending_job=(mask>>2)&1;pending_pipe_job=pending_job&&((mask>>3)&1);
  pending_epoch=13;next_render_epoch=(mask&16)?0xffffffffu:16;frame_pipe_epoch=0;batch_count=17;
  regs[PIPE5_R_DONE_EPOCH/4]=pending_epoch;regs[0x44/4]=batch_count;regs[0x50/4]=2;
  scene_batch_cycles=0;
  int error=setjmp(failed);if(!error)engine(&job);
  unsigned state[]={invalid,mask,(unsigned)error,cache_valid,pending_job,pending_pipe_job,pending_epoch,next_render_epoch,frame_pipe_epoch,scene_batch_cycles,trace_count};
  assert(fwrite(state,sizeof state,1,out)==1);assert(fwrite(trace,sizeof trace[0],trace_count,out)==trace_count);
  assert(fwrite(&previous,sizeof previous,1,out)==1);assert(fwrite(&frame_submission,sizeof frame_submission,1,out)==1);++cases;
 }
 for(injection=1;injection<=6;++injection){
  memset(regs,0,sizeof regs);memset(&previous,0,sizeof previous);memset(&frame_submission,0,sizeof frame_submission);trace_count=0;fake_ticks=0;
  cache_valid=0;pending_epoch=13;next_render_epoch=16;frame_pipe_epoch=scene_batch_cycles=0;capabilities=PIPE5_CAP_CONCURRENT_EPOCH;batch_count=17;
  pending_job=(injection==1||injection==5||injection==6);pending_pipe_job=injection==6;
  regs[PIPE5_R_DONE_EPOCH/4]=pending_epoch;regs[0x44/4]=batch_count;
  bb_job job={2,0x1800000,0x1400000,32,5120,8,8,0,224,0xff00ff,3};
  int error=setjmp(failed);if(!error)engine(&job);assert(error);
  unsigned state[]={injection,(unsigned)error,cache_valid,pending_job,pending_pipe_job,pending_epoch,next_render_epoch,frame_pipe_epoch,scene_batch_cycles,trace_count};
  assert(fwrite(state,sizeof state,1,out)==1);assert(fwrite(trace,sizeof trace[0],trace_count,out)==trace_count);++cases;
 }
 fclose(out);printf("ENGINE_ORDER_EXACT_CASES %u\n",cases);return 0;
}
'''

def run(cmd,name):
    (O/(name+'.argv.json')).write_text(json.dumps(cmd,indent=2))
    q=subprocess.run(cmd,cwd=P,capture_output=True)
    (O/(name+'.stdout.raw.log')).write_bytes(q.stdout)
    (O/(name+'.stderr.raw.log')).write_bytes(q.stderr)
    assert q.returncode==0,(name,q.returncode,q.stderr.decode(errors='replace'))
    return q

try:
    for label,root in [('golden',B),('candidate',P)]:
        scene=(root/'src/scene.c').read_text()
        text=prefix+'\n'+function(scene,'scene_pipe_check_fault')+'\n'+function(scene,'finish_job')+'\n'+function(scene,'engine')+'\n'+suffix
        path=O/(label+'.c');path.write_text(text)
        exe=O/(label+'.exe')
        run(['E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe','-std=gnu11','-O2','-UNDEBUG','-I'+str(root/'src'),str(path),'-o',str(exe)],label+'_compile')
        run([str(exe),str(O/(label+'.trace.bin'))],label+'_run')
    assert (O/'golden.trace.bin').read_bytes()==(O/'candidate.trace.bin').read_bytes()
    old=function((B/'src/scene.c').read_text(),'clipped_bounds').replace('clipped_bounds','old_clip',1)
    new=function((P/'src/scene.c').read_text(),'clipped_bounds').replace('clipped_bounds','new_clip',1)
    clip=r'''
#include <stdint.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "bitblt.h"
'''+old+'\n'+new+r'''
static uint32_t seed=123456789u;static uint32_t rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static unsigned checks;
static void check(int a[8]){int x[4]={INT_MIN,INT_MAX,123,-456},y[4];memcpy(y,x,sizeof x);int p=old_clip(a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],x,x+1,x+2,x+3);int q=new_clip(a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],y,y+1,y+2,y+3);assert(p==q&&memcmp(x,y,sizeof x)==0);++checks;}
int main(void){
 int edge[]={INT_MIN,INT_MIN+1,-100000,-1281,-1,0,1,15,16,31,32,63,64,703,704,719,720,1055,1056,1279,1280,INT_MAX-1,INT_MAX};
 for(unsigned f=0;f<8;++f)for(unsigned e=0;e<sizeof edge/sizeof edge[0];++e)for(unsigned j=0;j<512;++j){int a[8];for(unsigned k=0;k<8;++k)a[k]=(int)rnd();a[f]=edge[e];check(a);}
 for(unsigned j=0;j<1000000;++j){int a[8];for(unsigned k=0;k<8;++k)a[k]=(int)rnd();check(a);}
 for(unsigned j=0;j<1000000;++j){int a[8];a[0]=32+rnd()%960;a[1]=16+rnd()%620;a[2]=1+rnd()%64;a[3]=1+rnd()%64;a[4]=32;a[5]=16;a[6]=1056;a[7]=704;check(a);}
 printf("CLIP_EXACT_PASS checks=%u invalid_overflow_partial_and_contained=1\n",checks);return 0;
}
'''
    c=O/'clip.c';c.write_text(clip);exe=O/'clip.exe'
    run(['E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe','-std=gnu11','-O2','-UNDEBUG','-I'+str(P/'src'),str(c),'-o',str(exe)],'clip_compile')
    q=run([str(exe)],'clip_run')
    report=dict(status='PASS_EXACT_ORDERED_MMIO_AND_CLIP',source_sha256={'src/scene.c':H(P/'src/scene.c')},
                parent_scene_sha256=H(B/'src/scene.c'),engine_cases=4102,complete_trace_sha256=H(O/'candidate.trace.bin'),
                clip_output=q.stdout.decode(),hardware_accessed=False,physical_FPS='NOT_RUN',
                scope='Actual extracted unchanged finish/fault/epoch engine with all2048 field-delta masks x cache_valid0/1 and6 failure cases; every read/write/fence/fatal/state byte equal. Integer clipping2,094,208 cases exact including INT_MIN/MAX. Host stubs, no physical timing.')
    (O/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
except BaseException as error:
    (O/'FAILURE.json').write_text(json.dumps(dict(status='FAIL_PRESERVED',error=repr(error),hardware_accessed=False),indent=2)+'\n')
    raise
