# LAB23: memory and driver experiments

The platform bitstream, RTL, 100 MHz baseline, existing game rules and binary
PC keyboard packets are unchanged. The boot identity is
`PHASE BATTLE v3 LAB23 PC CONTROL`; `:hello` includes `labx=1`.
`labx_protocol.json` is the machine-readable protocol contract.

## Execute from the PC

Send one newline-terminated request, wait for its own terminal `LABX_DONE`,
then advance. IDs are positive 31-bit decimal numbers. Example:

```text
:labx 1 enter
:labx 2 mem copy medium boundary 3
:labx 3 compare blocks medium 120 2 3
:labx 4 compare image medium 120 2 3
:labx 5 double reset
:labx 6 double next
:labx 7 double next
:labx 8 double next
:labx 9 double next
:labx 10 exit
```

`double auto` performs the five steps automatically. `status` reads actual
framebuffer roles without drawing. `cancel` acknowledges its own request ID
and asks the running experiment to stop at a cooperative safe boundary. The
original request returns `CANCELLED`; cancellation keeps laboratory ownership
until `exit` restores the game menu and both framebuffer histories.

LAB1 remains available through `:lab`. LAB1, LAB23 and game rendering are
mutually exclusive. `LEGACY_ACTIVE` identifies an old LAB1 session that must
be exited before LAB23. There is no board-button input path.

## Workloads and honest measurements

Sizes are 128x96, 512x256, and 960x480. MEM uses the exact same final image,
split into 32x16 tiles or submitted as a merged rectangle. Both methods use
opaque Fill or Copy. The aligned/offset/boundary cases change both source
and destination layout; Fill therefore genuinely tests destination layout.
The boundary destination is x255,y219, whose byte address ends in 4092 mod4096.
The platform's existing AXI burst splitter handles the boundary.

COMPARE uses one shared deterministic task generator for CPU and FPGA.
Blocks clear the selected region then draw twelve moving colored squares;
image clears that region then copies one of two reproducible large images.
Both backends start with the same panel/background, frame numbers, warmup,
dimensions, positions, order and contents. The whole CPU group executes
before its matching FPGA group. The board retains separate completed result
columns and never computes a speedup from a previous request's result.

`render_us` includes API calls, task construction/submission/completion and
necessary memory synchronization. Exact CLINT ticks spent in the cooperative
UART service hook are excluded. `wait_us` reports real vblank exchange wait.
`elapsed_us` in METRIC is the real timed window, with actual swap-counter
delta; it excludes warmup, correctness checking and final result presentation.
Displayed FPS is actual timed swaps divided by this wall time, not scanout Hz.

After freezing timing/counter results, the actual last displayed FRONT frame
is checked first, read-only, before any replay can overwrite evidence. Earlier
registered first/middle frame indices are reconstructed on BACK and checked.
All registered checks cover the full 1280x720 framebuffer, both sources and
tail guards; duplicate frame indices are removed. CHECK reports `actual` and
`replayed` separately. Single-frame MEM checks the actual timed product.
Earlier-frame-only transient faults can escape reconstruction; no claim is
made that replay captured the original timed first/middle framebuffer.
`check_us` is separate and excluded from performance measurement.

`cycles`, `read`, `write` come from each real hardware task's registers and
are accumulated as 64-bit values. CPU values of zero mean not available.
READ counts accepted 128-bit read beats times16; WRITE counts valid WSTRB
bytes. These are engine counters, not all DDR physical traffic or utilization.
`uf` counts display-underflow row events, not lost frames. DONE `elapsed_us`
is the complete request wall time, including setup and checks, for continuous
display-on validation coverage. No experiment disables the display.

## Memory and safety

Source slots: 0x02400000 and 0x02600000, each2MiB. Reference/snapshot:
0x02800000 and 0x02c00000, each4MiB. The largest source including4092-byte
offset and64-byte guard is below its2MiB boundary. Each full-frame reference
and its guard fit its4MiB slot. They do not overlap game art/background/damage,
the persistent loader at0x00f00000, or framebuffers0x01000000/0x01400000.
Host input never supplies a DDR address.

Drawing always targets the current real BACK buffer. Pending exchange is
settled before a new drawing operation or exit. The five-step demonstration
checks A against a full snapshot while drawing B, then requests a real swap;
step5 requires changed FRONT, increased swap count and cleared pending.
STATE re-reads FRONT/swaps for a consistent snapshot and calculates BACK as
the other actual framebuffer, including immediately completed swaps.

## Reproduce offline verification

```text
python scripts/verify_all.py --host-cc E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe --toolchain-bin D:/ELSFPGARSIC-V/toolchain/bin
python scripts/test_labx.py --host-cc E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe
```

`test_labx.py` links actual experiment C, the actual CPU renderer and hardware
driver to an independent bounded DMA/display model. It tests all dimensions,
alignments and Fill/Copy methods, deterministic CPU/FPGA tasks, pixel/source/
guard faults, cancellation, ownership, real state transitions and restoration
failure. Host performance values are modeled and never board FPS evidence.
Board HDMI/cache/timing and persistent Flash acceptance are separate raw-log
tests performed by the main task, not by this offline verification script.
