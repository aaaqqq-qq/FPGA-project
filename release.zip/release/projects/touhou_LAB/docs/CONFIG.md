# CONFIG — 全部可调参数与默认值

参数集中在 `src/game_config.c` 的 `game_config_defaults()`，运行时可修改全局
`GameConfig game_cfg`。默认值即本交付版本。改完后重新构建并跑
`scripts/verify_all.py`。

## 1. Boss

| 字段 | 默认 | 说明 |
|---|---:|---|
| `boss_count` | 3 | 固定三名Boss；不要加到4（任务书明确搁置） |
| `boss_max_hp` | 3000 | 每名Boss基础HP |
| `boss_half_hp` | 1500 | 半血阈值，整数比较；默认=3000/2 |
| `enrage_intro_ticks` | 36 | 首次半血预警/演出，0.6s@60Hz |
| `enter_ticks` | 72 | 援军同时入场，1.2s@60Hz；期间不发弹/不可伤 |
| `first_burst` | 512 | 露米娅预警结束的一次爆发弹数 |
| `other_burst` | 256 | 后两名各自首次半血预警结束的爆发弹数 |
| `refill_first` | 1 | 首Boss狂暴结束回满 |
| `refill_others` | 0 | 后两名默认不回血；改1即统一回血 |
| `enrage_fire_num/den` | 7/5 | 平均射频1.4×；额外发射事件延迟3tick |
| `enrage_move_num/den` | 5/4 | Boss移速1.25×；实现为移动时长×4/5 |
| `enrage_bullets_num/den` | 3/2 | 单次弹数1.5×（向上取整） |
| `burst_rings` | 4 | 爆发弹环数 |
| `burst_speed_first` | 8192 | Q12像素/tick；2px/tick |
| `burst_speed_step` | 2048 | 每环增加0.5px/tick |

行为说明：

- 每名Boss每局只狂暴一次；`enrage_done`先锁，`enraged`在预警结束才置1。
- 首Boss二次半血不再回血/召唤/预警；后两名各自独立。
- 后两名只在首Boss首次狂暴结束时同时召唤，不是逐个击破换Boss。
- `battle_can_damage`：WAIT/ENTER/ENRAGE_INTRO/DEAD不可伤；NORMAL需ECL
  `vulnerable=1`；ENRAGED忽略ECL的周期性`vulnerable=0`，避免符卡循环出现
  无伤窗口。

## 2. 玩家

| 字段 | 默认 | 说明 |
|---|---:|---|
| `player_max_hp` | 100 | HP条上限 |
| `player_hit_damage` | 15 | 单次命中扣血 |
| `hit_invuln_ticks` | 48 | 受击保护，不与更长保护覆盖 |
| `spawn_invuln_ticks` | 120 | 出生保护 |
| `bomb_invuln_ticks` | 120 | 炸弹保护 |
| `bomb_damage` | 120 | 对每个可受伤Boss的炸弹伤害；走统一入口 |
| `regen_wait_ticks` | 300 | 最后一次**实际**受伤后等待5s |
| `regen_period_ticks` | 60 | 之后每1s回一次 |
| `regen_amount` | 5 | 每次回复5HP |
| `upgrade_ticks` | 48 | 升级动画时长 |
| `upgrade_invuln_ticks` | 48 | 升级真实免疫；与受击/炸弹/出生保护分开 |
| `hp_delay_ticks` | 18 | HP条延迟损失段保持时间 |
| `hp_drop_rate` | 4 | 延迟段每tick下落像素/HP |
| `player_shot_cap` | 128 | 玩家弹槽，≤`PLAYER_SHOT_CAPACITY=128` |
| `player_shot_life` | 180 | 玩家弹生命周期（tick） |
| `player_shot_damage` | 5 | 每发主射/追踪伤害 |
| `player_shot_speed` | 18 | 主射速度参数 |
| `homing_shot_speed` | 15 | 追踪符札速度参数 |

保护规则：

- `spawn_invuln`、`hit_invuln`、`bomb_invuln`、`upgrade_invuln`分别倒计时；
  `player_can_be_hit()`只要任一>0或DEMO就不可伤。
- 新的受击/升级保护用`max`合并不覆盖更长保护；不把多个保护合并成一个
  `invuln`赋值。
- 只有实际扣血才重置`regen_wait`；保护期间碰弹不延长等待。
- 回血为整数累加；死亡/菜单/结果状态不运行回血或升级。
- 炸弹仍为SW0+SW1；`bombs`初始3。

## 3. 成长

| 字段 | Lv1 | Lv2 | Lv3 | Lv4 | Lv5 |
|---|---:|---:|---:|---:|---:|
| `level_threshold` | 0 | 1000 | 3500 | 7000 | 12000 |
| `level_main`（主射路数） | 1 | 3 | 3 | 5 | 7 |
| `level_homing`（追踪路数） | 0 | 0 | 2 | 2 | 4 |

- 分数累计不消费；同tick跨多个门槛直接到目标等级，只播放一次最高等级动画。
- 主射角度间隔：≤5路14°，7路20°，以-90°为中心；追踪路角度间隔18°。
- `main_fire_period=5`、`homing_fire_period=15`；Lv5也受128槽和180tick寿命限制。
- 升级在“本tick实际伤害结算后、玩家仍存活”才执行；动画期间允许移动，判定点
  照常绘制。

## 4. 计分

| 字段 | 默认 | 说明 |
|---|---:|---|
| `damage_score` | 1 | 每实际伤害1分 |
| `boss_kill_score` | 2000 | 击破一名Boss一次 |
| `graze_score` | 10 | 每颗敌弹首次擦弹 |

旧“命中+25”、炸弹+500、PLAY通关+200000已移除，避免重复计分；回血/阶段过场
不加分。DODGE模式保留其独立的+50000通关奖励。

## 5. 容量/时序/效果

| 字段 | 默认 | 说明 |
|---|---:|---|
| `effect_job_budget` | 12 | 每帧新增效果通用作业上限 |
| `effect_area_budget` | 16384 | 每帧效果覆盖像素上限 |
| `bullet_age_max` | 60000 | `Shot.age`到顶后保持，不uint16回绕 |
| `logic_hz` | 60 | 目标逻辑频率 |
| `logic_max_catchup` | 2 | 最多连续执行`logic_max_catchup+1=3`个逻辑步；超出记drop/overrun |

其他硬约束不在`GameConfig`里：`SHOT_CAPACITY=20000`、`PLAYER_SHOT_CAPACITY=128`、
`Shot` 16字节布局、Q=4096、Q12坐标、54..69连续8×8材质、Alpha224/Key `0x00FF00FF`、
双帧缓冲地址/步长。改这些必须同步硬件/驱动，不能只改宏。

## 6. 菜单/模式

- `choice 0/1/2`：三Boss阶段战 NORMAL/HARD/LUNATIC。
- `choice 3/4`：固定精灵压力 FPGA/CPU；`SW0/SW1`选择容量档，作用于压力/DODGE。
- `choice 5`：200秒 DODGE，保留原规则和三命。
- PLAY阶段战固定使用20000敌弹池，不受菜单容量档影响（菜单标签已注明
  “BULLET LIMIT (STRESS)”）。
- 普通游戏默认`demo_invincible=0`；菜单`SW0+SW1`可切换，HUD显示DEMO。
- 验收伤害/回血时应关闭DEMO/autoplay；测试中的`validate_renderers`显式置
  DEMO并在telemetry标`guard=1`，不作为玩法验收。
