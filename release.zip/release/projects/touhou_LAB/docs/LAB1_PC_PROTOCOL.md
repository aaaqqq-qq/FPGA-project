# LAB1：电脑控制与基础一实验固件接口

本版本在独立目录 `touhou_LAB` 中构建；不改原 R8、RTL 或 100 MHz 时钟。
固件启动标识为 `PHASE BATTLE v3 LAB1 PC CONTROL`。

## 连接确认

发送 `:hello\n`，必须收到：

```
CAPS fw=LAB1 proto=2 controls=PC lab=1 width=1280 height=720 hz=60
```

该握手释放旧按键并重置按键包序号接收状态，保留游戏进度和暂停状态。
`STAT` 末尾带 `fw=LAB1 paused=0|1 control=PC`；旧 R8 的数字性能数据不能作为 LAB1 实板证据。

## 键盘状态包

每 75 ms 发送完整的六字节状态包，按下/松开立即发送：

```
A5 5A seq mask_lo mask_hi checksum
checksum = seq XOR mask_lo XOR mask_hi XOR A7
```

`seq` 为 8 位递增序号。位掩码：左 1、右 2、上 4、下 8、炸弹 16、暂停 32、开始/重开 64、菜单 128。`mask_hi` 必须为 0。支持斜向移动；同时左右没有炸弹含义。

同序号同状态仅刷新心跳；同序号不同状态、旧序号、校验错误均丢弃。255→0 正常接受。未收满的包 50 ms 后丢弃。500 ms 未收到有效包全部释放，允许下一会话重新从任意序号开始。PC 窗口失焦、断开、切到实验页时应主动发送零状态。

动作只认新按下边沿。按住炸弹或空格以及重复心跳不重复消耗炸弹/切换暂停。暂停期间逻辑与运行 tick 停止，画面、串口和 PAUSED 提示继续运行。

板上 GPIO 按键没有参与输入，原 SW0/SW1/SW2/SW3 组合控制已移除。此版本只接受二进制状态包和冒号开头、换行结尾的文本命令。无前缀旧 `m/r/s/n...` 字节静默忽略，避免坏包触发菜单或重开。

## 文本命令

每条以冒号开头、换行结束。值必须为不带符号的十进制整数。

| 命令 | 行为 | 成功回执 |
| --- | --- | --- |
| `:mode N` | 立即开始：0普通、1困难、2极难、3 FPGA 压测、4 CPU 压测、5 200秒躲避 | `OK mode N` |
| `:limit N` | 精确设置 1..20000 压测弹幕；已在压测/躲避时重开该模式 | `OK limit N` |
| `:pause 0` / `:pause 1` | 幂等恢复/暂停 | `OK paused N` |
| `:menu` | 中止回放，返回菜单 | `UI MENU` |
| `:autoplay 0|1` | 自动移动开关 | `OK autoplay N` |
| `:invincible 0|1` | 演示无敌开关 | `OK invincible N` |
| `:backend 0|1` | 0 CPU、1 FPGA | `OK backend CPU/FPGA` |
| `:validate 1|2` | 原 CPU/FPGA 逐像素比较：1 压测、2 战斗 | `OK validate N` 后比较日志 |
| `:set field value` | 保留现有白名单参数与范围校验 | `OK set` |
| `:record [seed]` | 从普通模式开始录制 | `OK record started (normal/live)` |
| `:stop` | 结束录制 | `OK record saved` |
| `:replay` | 重放并核对权威状态哈希 | `OK replay started`，结束 `REPLAY PASS state hash` |
| `:replay status` | 回放状态 | `REPLAY_STATUS ...` |
| `:replay dump` | 有界记录导出 | `REPLAY_BEGIN / REPLAY_WORD / REPLAY_END` |

录制/回放期间禁止变更会影响确定性的配置、模式、后端；暂停可用。菜单动作可以中止回放。拓扑参数 boss_count、enemy_count、background_depth_enabled 仍必须先返回菜单修改。

## 实验画面所有权

`lab.h` 定义基础一 Fill/Copy 实验协议，具体命令与用例见 `tests/lab_protocol.json`。实验命令先排队；`lab_active()` 或 `lab_pending()` 时游戏不运行逻辑、不渲染，不能覆盖实验画面。实验退出先重建空闲 framebuffer，垂直同步切换，再重建原 front；两 bank、脏区和 HUD 缓存恢复完成后才交回游戏。

接收缓冲为 160 字节；回复 FIFO 可容纳 16 行，能完整保存一次 verify 的 ACK、9 条 CASE、DONE。上位机仍应按 request id 串行发送实验任务，等待 DONE 后继续。

## 已完成的离线检查

`scripts/test_remote_input.py` 执行生产输入模块以及实际 game.c 逻辑集成，覆盖断包、错包、重复序号、时间/序号回绕、失联释放、炸弹边沿、暂停、无 GPIO 读取、实验所有权、双缓冲退出顺序和回复 FIFO。

`scripts/test_lab.py` 执行实际 lab.c，与独立像素参考、源数据/guard 和明确的 9 个基础用例比对。以上属于宿主验证，不替代 LAB1 的实板显示、按键延迟与帧率验收。
