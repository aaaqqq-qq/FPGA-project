<!-- ADV1_CURRENT_RELEASE -->
# 当前版本 ADV1 / LAB23（2026-11-01）

新增高阶 Alpha、Color Key、联合比较和多尺寸/颜色/形状/可选物理压力实验；保留原东方 Project、基础一/二/三、电脑控制和 100MHz/RTL 基线。实现与验收说明见 [ADV_IMPLEMENTATION.md](ADV_IMPLEMENTATION.md)，线协议见 [adv_protocol.json](adv_protocol.json)，相对 LAB23 补丁见 [adv1_source.diff](adv1_source.diff)。

当前离线证据是 `results/verification_adv1.json`：30组宿主回归、静态检查与真实RV32构建均PASS；完成2026-11-01T03:29:17.387742+00:00。新增实验独立宿主测试是 `results/adv_host.json`；独立审查见 `independent_review/`。首次适配失败及修复日志保留在 `results/verification_adv_stdout.log`，不要误作最终结论。

当前 ELF SHA256 `00c0596bcf091580cbc543e2d2943098568a227d0a58d409278301ffc3e6d88a`，加载233266字节，含4096字节预留栈RAM用量1008256/1044480字节。新板输出、全Flash固化读回、断电自启动、吞吐与帧率必须由本版本单独实测；离线结果不代表板测。此段以下R6/R4及更早内容均为历史记录。

---

<!-- R6_CURRENT_RELEASE -->
# 当前版本R6（2026-10-29）

当前功能、控制、验证身份和验收边界统一见[R6_RELEASE.md](R6_RELEASE.md)。默认3Boss/0妖精，菜单可选4+6或6+12；新增缓存月夜2.5D背景和原ANM普通妖精，保留原游戏名及100MHz/RTL/BSP/Flash基线。
本次生产源码绑定的离线CI18组及RV32构建PASS（完成2026-10-28T18:57:28.304199+00:00）。新R6上板/600秒尚待根任务实测，不能宣称20k或六Boss完整游戏已稳定60FPS。
R5原严格回执保持FAIL；独立hardware_status=PASS只是8192 STRESS累计节奏诊断且capture_quality=WARNING，不改写原验收。
R6当前ELF SHA256 `acd65a167459a215049d29ff7fbe2bd8d430e906df24d18be230f20a27493a73`，加载164226字节。独立补丁为`phase_battle_R6.diff`，旧`phase_battle.diff`保持原样。

---
## 以下为旧版本历史记录

以下R4及更早身份、三Boss固定范围、旧内存/测试数字和PENDING都描述当时版本；当前R6以顶部链接为准，历史不能充作新板测。

<!-- R4_RELEASE_CURRENT -->
# 当前版本：R4（2026-10-29）

完整当前说明与十一项功能、操作、参数白名单、安全性能路径及证据见[R4_RELEASE](R4_RELEASE.md)。
R4只改软件，保留三Boss/游戏名/720p/100MHz，不改RTL/PLL/BSP/Flash。
当前采用32位字体span、HUD双缓冲脏行、4弹统一加载、固定60Hz有理累加、两初始化帧预热及仅FPGA STRESS的安全描述符快照重叠。
R4快照门槛为CMD后fence、新BUSY锚点至少1us、完整冻结数量字节门槛；R3必须观察短暂<4096的候选已拒绝。
14组主机检查与RV32构建实际PASS；R4板端结果在本文冻结时PENDING，600秒与完整三Boss两万弹60FPS未证明。
特效保持硬上限12任务/16384像素，拒绝有跨帧总计；无新增声音/音频输出。

---
## 以下为DeepSeek初版、R1和R3历史变更记录

以下参数、内存数字、测试条件和实现说明属于各自历史阶段；例如旧版“每帧整面板恢复”、旧低计数门槛和旧工具缺失理由均不是当前R4状态。当前以顶部链接为准。

# CHANGES — 三Boss阶段战改造

本文件对应任务书《给DeepSeek：东方弹幕工程修改执行任务书》，基线为
`hdmi_rumia_ultimate.zip`（SHA256
`2d8cb25f98acfafeea81950f96e9fa75559f261b36d3ce48f9a66e146d5b93d8`）。
改造保留原工程名、东方角色、素材和原有硬件路径，不引入第四名Boss，不改成
“幻夜神社”等新游戏。

## 1. 交付概要

- 新增强制状态机：`WAIT → ENTER → NORMAL → ENRAGE_INTRO → ENRAGED → DEAD`。
- 开局仅露米娅活动；首次半血预警36tick、回满、发射512颗爆发弹，同时召唤
  琪露诺/红美铃从上方两侧进入（72tick，无敌、不发弹），随后三Boss同场。
- 每名Boss每局只狂暴一次；后两名半血预警36tick、爆发256颗，默认不回血。
- 玩家改为100HP、受击-15、48tick保护、300tick后每60tick回复5HP；分数驱动
  Lv1..Lv5，升级48tick动画期间真实免疫。
- 新HUD、受击白剪影/碎片、延迟损血段、回血提示、狂暴环、升级符环/星点、
  援军姓名条；双缓冲HUD整面板恢复，批量快照count冻结。
- 构建/测试入口全部参数化；T01–T12主机测试、像素测试、旧ECL回归、DODGE/
  输入回归均通过；RV32固件在本会话实际构建通过（720,886B / 69.02%）。
- 实板、Efinity综合/布局布线/bit、Flash更新未执行（环境不具备），见
  `VERIFICATION.md` 和 `verification.json`。

## 2. 逐文件修改

### 新增源码

| 文件 | 内容 |
|---|---|
| `src/game_config.h/.c` | 全部机制参数集中配置：Boss HP/阈值/预警/入场/爆发、回血开关、狂暴倍率、玩家HP/保护/回血、等级门槛/射路、计分、效果预算、逻辑频率。 |
| `src/player.h/.c` | 玩家独立状态；HP/受击/回血/保护/升级；Lv1..Lv5射路与追踪符札；128槽玩家弹池、生命周期、拒绝计数；追踪目标只选可受伤Boss。 |
| `src/battle.h` | Boss状态枚举、`BattleBoss`（含状态/半血/召唤/伤害/发射统计）、统一伤害入口、legacy接口。 |
| `src/effects.h/.c` | 32项局部效果池；预警/爆发/受击/升级/回血/入场/死亡效果；每帧作业数≤12、覆盖面积≤16384像素的硬预算。 |
| `src/art_ids.h` | 由`scripts/prepare_stage.py`生成的追加图集ID（70..82），保证54..69的8×8敌弹材质块不被占用。 |
| `tests/phase_gameplay.c` | T01–T10/T12生产代码宿主测试。 |
| `tests/dodge_controls.c` | DODGE 200秒、三命、炸弹、输入去抖、长按菜单回归。 |
| `tests/host_scene_stubs.c` | 无渲染测试所需的scene桩。 |
| `tests/stub/*.h` | BSP/CSR/GPIO宿主桩，测试直接包含生产`game.c`。 |
| `sim/game_preview.c` | PC宿主预览：真实`scene.c`/`font.c`+同步bitblt模型，调用生产`render()`。 |
| `scripts/test_phase_gameplay.py` | 参数化编译/运行T01–T10/T12并写JSON。 |
| `scripts/verify_all.py` | 无硬件总验证入口；缺工具/板卡明确NOT_RUN。 |
| `scripts/render_preview.py` | 一键生成关键状态PNG。 |
| `scripts/build_firmware.py` | 参数化RV32构建（本任务书要求）。 |
| `scripts/test_stage.py`、`test_original_battle.py`、`test_scene.py`、`test_dodge.py` | 改为`--host-cc`参数化；更新到新结构；旧ECL回归走legacy模式。 |
| `scripts/benchmark_board.py` | `--battle`不再按“N==容量档”过滤，保留所有自然阶段战窗口并记录N/Boss状态/等级。 |
| `scripts/prepare_stage.py` | 保留原70图集顺序/调色板/像素；追加4张白剪影、3种颜色/尺寸环、星、绿十字；写`art_ids.h`和效果PNG/alpha/manifest。 |
| `sim/scene_host.c` | 像素模型更新新HUD、效果图集、双缓冲短文本/血条/菜单清除。 |
| `docs/` | 本文件、`README_RUN.md`、`CONFIG.md`、`VERIFICATION.md`、`TEST_PLAN.md`、`FREQUENCY_STUDY.md`、`phase_battle.diff`（相对基线的统一diff补丁）。 |

### 修改源码

| 文件 | 修改 |
|---|---|
| `src/game.c` | 重新接入生产状态；`hp`（Boss HP之和）改名为`boss_hp_sum`，`level`（弹容量档）改名为`capacity_level`；新增`player.power_level`。删除旧`lives/score/graze/invuln/hp`玩家混用。60Hz逻辑累加器+有限追帧；PLAY无200秒超时；DODGE保留200秒；三Boss全灭通关；同tick玩家死亡优先。新HUD/结果面板/援助入场标签/升级文字；bomb走统一伤害入口。 |
| `src/battle.c` | 保持原ECL VM/512步看门狗/事件顺序；新增状态机、召唤、半血截断、统一伤害、计分、Boss归属/请求/拒绝统计、轮转公平发射、爆发弹、legacy三Boss模式。移动插值与发射节拍分离：狂暴时移动时长×4/5（速度1.25×），发射事件按7/5额外排队（间隔3tick），单次弹数×3/2；不再整体加速VM。 |
| `src/stage.h/.c` | `Shot`布局保持16字节；新增并行`owner[20000]`，删除时同步迁移；新增`requested`统计；年龄到顶策略由battle统一钳制。 |
| `src/scene.c` | 右侧HUD每帧整面板恢复（208×586），修复数字变短/动画结束残影；批量提交时冻结`batch_count`，快照阈值用提交时count；新增`BB_HOST_TEST`的MMIO/ fence条件编译，便于真实生产渲染的主机测试；月亮/背景降亮。 |
| `src/arena.h` | 菜单面板334×181→460×238，适配新规则/按键说明。 |
| `src/art_data.h` | 由生成器重新生成；前70个tile的偏移/尺寸/像素与基线逐字节一致；调色板不变；新增tile 70..82。 |

### 保留不动

- `Shot` DMA 16字节布局、`tile`偏移14、Q12坐标。
- 54..69连续8×8敌弹材质块、Alpha224/ColorKey `0x00FF00FF`。
- `bitblt.c`公共Fill/Copy/Alpha/Key、CPU同负载、FPGA压力、DODGE、菜单/串口校验入口。
- `start.S`、`scripts/link.ld`、BSP缓存/装载流程（只增加新源文件和参数化脚本）。
- 原RTL、bit、约束和原素材文件均未改；`hw/`中旧bit只作为100MHz基线证据。

## 3. 关键设计选择

### 3.1 一次性狂暴与回血

- `BattleBoss.enrage_done`在伤害入口里**先锁**，再改状态/放效果；`finish_enrage`
  再检查状态，重复调用不会二次召唤或二次回血。
- 首Boss（k=0）`refill_first=1`，在36tick预警结束时`hp=max_hp`并召唤；
  后两名`refill_others=0`，半血保持1500，只进入ENRAGED。该行为集中在
  `game_config.c`，以后统一回血只需把`refill_others`改1。
- 首Boss二次半血：`enraged=1`后不再进入半血分支，不会回血/召唤/再次预警。

### 3.2 伤害截断

`battle_apply_damage()`是唯一入口（玩家弹、炸弹、测试均走这里）：

- NORMAL且未狂暴：若`hp-amount <= 1500`，实际伤害只到1500，余量丢弃，
  状态进入ENRAGE_INTRO；同一tick后续调用返回0。
- ENRAGE_INTRO/ENTER/WAIT/DEAD不可受伤；NORMAL需ECL `vulnerable=1`；
  ENRAGED忽略ECL的周期性`vulnerable=0`（否则每次符卡循环会有2秒无伤窗口），
  规则写在`battle_can_damage()`并有测试。
- 回血不产生分数；击杀+2000只触发一次；旧`+25/命中`、炸弹`+500`、通关
  `+200000`不再叠加（DODGE保留自己的50000通关奖励）。

### 3.3 同tick结局

`logic()`顺序：伤害/擦弹→受击→回血→升级→`resolve_outcome()`。
`resolve_outcome()`先判断玩家死亡，再判断Boss全灭；因此玩家与最后Boss同tick
归零时结果为LOST。升级只在玩家存活且本tick伤害结算完成后进行，不会用新获得
的无敌撤销已发生的致命伤。

### 3.4 60Hz与统计边界

- 主循环按CLINT实际时间累计，以16667us为一逻辑tick；最多追3步，超出记
  `logic_drops/logic_overruns`，不静默丢弃。
- `logic_us`只包逻辑；`render_us`只包render；`frame_us=logic+render`；
  swap等待单独由FPS/UNDERFLOW统计。`scene_list_us/BB_CYCLES`仍为列表发布和
  硬件batch周期。
- 回血、保护、射击、入场、预警全部按逻辑tick，渲染变慢或核心提频不会改变
  这些时长。

### 3.5 速度/射速分离

未采用“VM整体×1.4再把移速×1.25”的错误做法：

- 移动插值每逻辑tick一次；ENRAGED时把移动时长乘4/5（速度1.25×），不改变
  脚本事件时间点。
- 每次ECL发射事件立即发一发；另用每Boss的`fire_acc`累计2/5，每5次事件
  额外排1发，延迟3tick，得到1.4×平均射频；单发弹数×3/2。
- 每Boss用`script_ticks`做1500/2100/1800周期重置，不用全局`stage.frame`同步
  重置所有Boss；VM状态标志在VM外，循环重置不会清掉狂暴/召唤/死亡。
- 新狂暴是明确改编，不声称与未修改原ECL的发射时间戳/数量一致；legacy模式
  保留原ECL发射计数回归（36,000帧）。

### 3.6 容量与公平

- 20000敌弹池共享；所有普通/爆发请求先`++stage.requested`，再检查`limit`，
  拒绝计入`stage.rejected`和每Boss统计。
- 发射顺序按`stage.frame % 3`轮转起手；HUD显示真实`stage.count/limit`，
  不每帧补满。
- 玩家弹128槽、生命周期180tick（配置），满了记`shot_rejections`，不越界。

### 3.7 HUD/效果/双缓冲

- 右侧HUD整面板每帧从BACKGROUND恢复后再绘制，彻底解决数字变短、动画结束、
  状态切换残影；场地由batch整幅BACKGROUND重建。
- 每次batch提交冻结`batch_count`；`scene_batch_snapshot_ready()`用冻结值，
  不再读会被下一步逻辑改变的`stage.count`。
- 场内通用绘制仍等batch完成；右侧CPU HUD文本有严格并发边界。
- 效果池≤32项；渲染时作业数≤12、覆盖≤16384像素；环是透明轮廓，不参与碰撞，
  不会被误判为敌弹。
- 新图集由`prepare_stage.py`可重复生成；白剪影来自原player alpha，环/星为
  程序生成PNG；前70 tile和调色板与基线逐字节一致。

## 4. 默认参数（摘要，完整见CONFIG.md）

- Boss：3×3000HP，半血1500；预警36tick；首Boss爆发512、后两名256；入场72tick；
  首Boss回满、后两名不回；狂暴射频7/5、移速5/4、单次弹数3/2。
- 玩家：100HP，命中-15；受击保护48tick；出生保护120tick；炸弹3个/120tick保护/
  120伤害；最后受伤后300tick开始，每60tick回5，封顶100。
- 升级：Lv1 0、Lv2 1000、Lv3 3500、Lv4 7000、Lv5 12000；射路1/3/3/5/7，
  追踪0/0/2/2/4；主射周期5tick、追踪15tick；升级动画/免疫48tick。
- 计分：实际伤害1分/点、击破2000、首次擦弹10；分数不消费。
- 效果预算：12作业/16384像素；子弹age上限60000；逻辑60Hz、最多追3步。

## 5. 验证状态

- 主机T01–T10/T12、T11像素、旧ECL 36,000帧、stage 3×12,000帧、DODGE/输入：
  PASS（详见`VERIFICATION.md`）。
- RV32构建：PASS，`build/rumia.elf`，720,886B/69.02%，SHA256见
  `build/identity.json`。
- Efinity综合/布局布线/bit、实板功能、60FPS长测、Flash更新：NOT_RUN，
  原因和无硬件步骤见`VERIFICATION.md`。
- 原包中的旧`flash/game.bin`、`flash/game_boot_124k.bin`对应旧ELF
  `d715548a...`，**不是**本次新ELF，不得作为新release烧录；本次release未附带旧镜像，也未更新Flash。
- 原包`reference/`历史检查点归档未随本release附带，完整保留在原始ZIP中。

## 7. 复验与补丁（第二会话）

- 在新解压副本中独立重跑`verify_all.py`与`render_preview.py`：implementation、
  host_tests、rv32_build全部PASS，复验记录见`VERIFICATION.md`第4.1节。
- 新增`docs/phase_battle.diff`：基线→本版的统一diff（src/scripts/sim/tests/sw/
  docs/交付文档），供逐文件审查。

## 6. 已知限制

- 首次可玩版本只做了100MHz软件；未做105/110/120/125MHz提频，未生成新bit。
  提频条件和约束分析见`FREQUENCY_STUDY.md`。
- 实板峰值/600秒稳定负载未测；不能把主机测试当作板级60FPS结论。
- 新狂暴弹幕数量/节奏是改编值，不与原ECL的未修改发射数逐帧一致；legacy回归
  单独保留。
- 效果/环为8×8/16×16/32×32/64×64索引图集，没有逐弹旋转/逐效果缩放；符合
  现有硬件材质契约。


## 2026-10-29 Reviewer R1修订

- 一次性输入排队并仅消费一次，补零/一/二/三步追帧回归，恢复同N CPU/HW配对结果与后端标签。
- 场内文字限制在可恢复场地内，避免援军入场与靠边升级污染双缓冲边框；特效预算拒绝统一计数。
- benchmark_board按请求时长与有效换帧总数、模式/容量/后端连续性、帧计数连续性和异常计数验收；短窗或中断不能冒充600秒通过。末帧render采样、累计logic+render峰值分别标注，未提供逐帧渲染最大值。
- verify_all不再把未执行硬件步骤描述成已探测无工具/无板；新增16项离线验收器回归。
- 不改游戏名、三Boss数量、100MHz硬件/BSP/原位流；Flash不更新。
- 本节的板端短测为PENDING，600秒完整新版本稳定性为NOT_RUN；软件通过不等于实板60FPS通过。


## Reviewer R3 (2026-10-29)
见 docs/R3_OPTIMIZATION.md；独立R2/R3证据分别保留，硬件时钟/RTL/Flash未改。R3新实板/长测状态以最终结果记录为准。
