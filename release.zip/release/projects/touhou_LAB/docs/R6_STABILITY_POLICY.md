# R6稳定性验收规则与工具用法

规则ID：`R6-native-hardware-and-PC-receipt-v1`。本规则用于在测量前登记的新R6测试。
R5原始严格结果仍为FAIL；R5另存的硬件计数审计PASS、电脑接收质量WARNING也保留。
本次没有将旧结果改判为新规则下的正式通过。

## 测量前登记

在工程目录执行，生成规则JSON；此命令不访问串口或板卡：

```text
python scripts/analyze_stability.py --describe-policy --mode2 --count 8192 --seconds 600 --hz 60 --require-zero-fxdrop --output results/policy_before_run.json
```

开始新采集之前，将这个文件及其SHA256、分析器源码SHA256、ELF/bit身份、预热时长和测量模式写入本次run登记。
8192颗、600秒、60Hz、要求零特效丢弃这一组规则的`policy_sha256`为：
`4743e8580601948fb9e19df952a64e36290e6be381914280a85d453fcbe9c333`。
计数、时长、目标频率或特效门槛不同，应重新生成并登记，不能照抄这组哈希。
采集程序须在测量开始时保存预先约定的`measurement_start_utc`，不得看到结果后再选择起点。

## 硬件通过条件

只排除一次首个匹配STAT作为基线；之后所有窗口、模式切换和异常都保留。

- 模式、渲染后端、实际N和容量均与登记值相同。
- 同时要求`scan_total`、`swap_total`。按无符号32位差值计算，每相邻窗口的累计扫描/换帧增量必须分别等于该窗`scan`、`swaps`。
- 每窗`scan == swaps`、`missed == 0`、`uf == 0`；累计`drops/ldrop/lover`不得增加或复位。
- 每窗原生时长在1.9～2.5秒内；报告FPS和由`swaps/us`重算的FPS均须在目标频率±0.05Hz内。
- 不允许缺字段、重复字段、超过32位范围、缺窗、乱序、模式变化、重启或TRAP/FAIL/FATAL。
- 至少三个稳定窗口；原生时长之和达到600000000µs，完成换帧数至少36000。

`frame`是处理耗时，不是累计帧计数。`hardware_status=PASS`只表示这组原生计数条件通过。
特效丢弃单独记录；指定`--require-zero-fxdrop`时，任何特效丢弃都会使总验收失败。

## 电脑接收质量

JSONL中的UTC/monotonic是Python收到数据的时间，不是FPGA发出该帧的时间。
接收时间缺失、倒退、重复或与原生窗口时长相差超过500ms，记为`capture_quality=WARNING`，逐窗列出。
如果全部原生累计计数连续、原生窗口满足要求，这类接收警告不单独否定硬件节拍。
缺窗、原生计数跳变、原生漏帧/欠流等仍然FAIL，不能用“电脑抖动”解释掉。
JSONL无法解析属于证据缺失，硬件判定FAIL、接收质量ERROR。

## 测量后分析

```text
python scripts/analyze_stability.py --log RUN/uart_lines.jsonl --start-utc MEASUREMENT_START_UTC --mode2 --count 8192 --seconds 600 --hz 60 --require-zero-fxdrop --output RUN/stability_R6.json
```

报告同时给出`hardware_status`、`capture_quality`、`visual_status`和`status`。
总状态PASS要求硬件条件及配置的特效门槛通过；接收WARNING会保留，不能隐藏。
原始日志和已有R5判定文件不覆盖，输出路径不能等于原始日志路径。

这是固定8192颗8×8精灵压力场景的验收，不能写成两万颗或完整Boss游戏通过600秒。
窗口计数也不等于逐帧渲染耗时测量、画面逐像素验证或官方赛事验收。

## 工具回归

```text
python scripts/test_stability_analyzer.py
```

回归覆盖短六秒、缺窗、硬件计数跳变、真实漏帧/欠流、模式切换、重复/越界字段、乱序、重启、接收延迟后赶上，以及“接收抖动同时存在硬件缺窗”等对抗场景。
