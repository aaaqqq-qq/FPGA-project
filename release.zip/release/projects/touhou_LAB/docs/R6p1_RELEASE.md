# R6p1：修复HUD扫描开销与终局重复绘制

日期：2026-10-29。本版R6p1已完成固定20000精灵压力实板长测：600.700021秒、36042次完成换帧，约59.9999979FPS；硬件指标、电脑收包质量和装饰效果预算门槛均PASS，独立原始日志重算PASS。完整结果见[最终实板验收](../RELEASE_ACCEPTANCE.md)与[机器验收记录](../results/release_acceptance.json)。这不代表完整活动战斗全程60FPS：4Boss+6普通敌人及6Boss+12普通敌人活动短测分别为56.0384、48.5745FPS；用户本轮已确认“背景和小妖精都正常”，对应本次短测显示画面；该反馈不外推为600秒长测全程肉眼观察。Ti60F225I3-V4、100MHz、720p、原游戏名/人物素材、默认3Boss+0小怪和可选4+6/6+12均保持，没有修改RTL、PLL、BSP或Flash。本文件以下构建候选、加载及长测待执行字样保留当时历史状态，当前结论以上述最终实测为准。

十一项玩法/交互优化、2.5D缓存背景、原ANM妖精素材及操作细节见[R6_RELEASE.md](R6_RELEASE.md)。该文件现为**历史R6功能说明**，不是本次p1板端结论。原R6及R4补丁保持旧证据，本次只提供独立R6p1补丁。

## 1. 原R6的短功能结果与性能失败

R6原始SESSION为`20261029_025918_c226fe48`。串口短测包含菜单、4Boss+6妖精、6Boss+12妖精、击破/终局、固定压力及扩展录制回放。部分组合使用伤害50、DEMO和自动驾驶以快速观察阶段，不能记为默认live难度完整验收，也不能代替显示器目视确认。

该R6版本没有达到稳定60FPS：活动局6Boss组合有约19.9～30.3FPS窗口，render约18.2～24.4ms；4Boss终局N0仍约30FPS/render约19.1ms，6Boss终局N0约30FPS/render约20.6～21.3ms。菜单约12.3ms，仍有约60FPS短窗。以上属于不同模式，不能只拿菜单或初始短窗代表完整游戏。

静态背景仅在scene_init生成，硬件在活动帧读取缓存背景，未发现每帧重新执行背景算法。主要可修复路径包括：六Boss增加HUD命令后逐行反复扫描旧/新命令，以及终局逻辑早已冻结但每帧继续重画残留玩家弹、视觉特效和CPU菜单文字。原R6性能FAIL与原始UART保留，不覆盖为p1成绩。

## 2. p1的两项软件修改

### 2.1 同数量HUD命令的精确脏位图

旧HUD只要一个数值改变，就对74个8像素行带分别遍历命令列表进行精确比对；六Boss和更多字段会扩大重复读取。p1在命令数量相同时，按索引对每条旧/新命令只做一次memcmp，发生变化则把**旧位置和新位置**覆盖的行带加入74位脏图。脏图之后只按行扫描，主路由重复行×命令扫描变为命令扫描＋行扫描。

没有用哈希替代精确相等。重绘仍遍历当前命令并保持原painter顺序，且裁剪到变化区域；同数量的重排也标记旧/新覆盖范围。数量变化（插入/删除）保留原精确逐行回退。两个帧缓冲各自记录历史；关闭缓存、初始化/失效和空列表仍正确处理。变化完全在HUD可恢复区域外时同步保存元数据，不产生不必要的绘制。

生产scene.c SHA256：`c3ee5b3b8d2c43458502c3a804e1542d65eb20c986eb6c5f52d215607702034c`。算法复杂度变化不直接等于板端FPS提升，后续需同配置实测。

### 2.2 仅硬件终局保留静态场地

仅在`hardware && !validation_active && (LOST || CLEARED)`启用。每个缓冲先完整渲染终局一次，成功且未取消后才标记可复用；后续保留该缓冲已有的场地、残留弹丸/特效和结算面板，只更新HUD数值，不再每帧重新batch背景、重画静止人物和CPU结算文字。

模式、DEMO、choice、后端改变、回菜单、重开和取消会使相应缓存失效。CPU后端和像素验证仍完整绘制；PLAY/DODGE始终画活动场景，未用缓存冻结正在玩的游戏。MENU仍按原路径绘制，未把菜单或终局省时当作活动游戏加速成绩。

界面将原SPRITES标签明确为DRAWN：这是当前帧实际提交的tile/批次绘制数；终局复用时可以为0，但画面中保留的实体没有消失。ACTORS仍独立表示活动逻辑实体。串口`sprites`字段沿用兼容名，不应把0解释为没有画面或把缓存帧称为重新渲染全部精灵。

如果后续终局达到60FPS，只能说明静态终局路径改善；不能推导6Boss活动局、12只小怪或20,000活动弹也达到60FPS。

## 3. 真实复验范围

本次完整离线CI于2026-10-28T19:14:16.944931+00:00结束；已逐文件核验机器记录绑定当前生产src。implementation、host_tests和rv32_build均PASS，共21组。

| 项 | 实际状态 | 原始日志 |
|---|---|---|
| `benchmark_acceptance` | PASS | [`benchmark_acceptance.log`](../results/validation/benchmark_acceptance.log) |
| `enemies` | PASS | [`enemies.log`](../results/validation/enemies.log) |
| `expanded_battle` | PASS | [`expanded_battle.log`](../results/validation/expanded_battle.log) |
| `r6_integration` | PASS | [`r6_integration.log`](../results/validation/r6_integration.log) |
| `background` | PASS | [`background.log`](../results/validation/background.log) |
| `hud_dirty_fast` | PASS | [`hud_dirty_fast.log`](../results/validation/hud_dirty_fast.log) |
| `terminal_render` | PASS | [`terminal_render.log`](../results/validation/terminal_render.log) |
| `stability_analyzer` | PASS | [`stability_analyzer.log`](../results/validation/stability_analyzer.log) |
| `stress_pipeline` | PASS | [`stress_pipeline.log`](../results/validation/stress_pipeline.log) |
| `telemetry_counters` | PASS | [`telemetry_counters.log`](../results/validation/telemetry_counters.log) |
| `frame_clock` | PASS | [`frame_clock.log`](../results/validation/frame_clock.log) |
| `replay` | PASS | [`replay.log`](../results/validation/replay.log) |
| `runtime_cli` | PASS | [`runtime_cli.log`](../results/validation/runtime_cli.log) |
| `r2_core` | PASS | [`r2_core.log`](../results/validation/r2_core.log) |
| `font_equivalence` | PASS | [`font_equivalence.log`](../results/validation/font_equivalence.log) |
| `r2_render` | PASS | [`r2_render.log`](../results/validation/r2_render.log) |
| `phase_gameplay` | PASS | [`phase_gameplay.log`](../results/validation/phase_gameplay.log) |
| `legacy_battle` | PASS | [`legacy_battle.log`](../results/validation/legacy_battle.log) |
| `stage` | PASS | [`stage.log`](../results/validation/stage.log) |
| `dodge_controls` | PASS | [`dodge_controls.log`](../results/validation/dodge_controls.log) |
| `scene_pixels` | PASS | [`scene_pixels.log`](../results/validation/scene_pixels.log) |

新增检查分开解释：

- `hud_dirty_fast`：28帧完整1280×720像素逐字节等于禁用缓存的完整重画参考。覆盖插入/删除/重排/重叠、跨多行移动、文字缩短、双缓冲和同bank重复、空HUD、关闭/重开及边缘裁剪；这是host deferred MMIO模型。
- `terminal_render`：161项检查直接调用实际生产game.c的render，验证两个bank首次独立绘制/复用、HUD值变化、DRAWN0、各种失效、CPU和validation禁用、取消不缓存、重开以及活动PLAY每帧重绘。它是**命令提交和保留场地模型**，不是161帧完整像素比较，也不是RTL/实板时序。
- 原12帧HUD/四工况效果恢复、64帧整屏参考、字体826+20+8、背景guard/确定性、原83图集前缀、扩展Boss84975项、回放、CLI、帧时钟、计数和原ECL等仍按各日志保留。

复现示例（在工程根）：

```text
python scripts/verify_all.py --host-cc <宿主GCC> --toolchain-bin <RISC-V工具链bin>
python tests/hud_dirty_fast/test.py --host-cc <宿主GCC>
python scripts/test_terminal_render.py --host-cc <宿主GCC>
```

本次21组PASS来自Windows环境。固定地址像素模型依赖Win32；其它平台不能据此声称通过，新增hud_dirty_fast入口也应在支持Win32时运行，不把平台不支持或缺工具冒称成功。以上没有新访问设备。

## 4. p1身份和临时上板边界

ELF SHA256：`5960b4b762d06d2e54ff1e7e37e1398b799163abc67a410396890a24d9d7b4b4`。入口0x1000，有效加载165186字节，PT_LOAD内存跨度911616字节。原位流仍为SHA256 `8c294a053584c52f4bf44a6a627dbac7008fbe3df83cccf18b0b924e4bfd7269`。新启动文字必须包含`PHASE BATTLE v3 R6p1`；以完整加载读回、新SESSION身份和实际BOOT共同确认，不能只依据本机源码校验推定板上已经是p1。

本文件冻结时根任务正在准备p1临时加载。新上板、目视/按键、同配置短性能及600秒均PENDING/待执行，不改Flash。分别复测3+0、4+6、6+12活动局与终局，保留实际N、等级、DEMO/自动驾驶/伤害配置；固定N压力与完整游戏分开。不能承诺20k或完整扩展游戏稳定60FPS。

## 5. 新长测的预注册与验收口径

`scripts/run_stability.py`不会编译、JTAG下载或写Flash。必须先确认已经加载本版，再运行；不带`--execute`仅离线检查，不打开串口。示例：

```text
python scripts/run_stability.py --count 8192 --seconds 600 --warmup 10 --port <实际COM> --execute
```

每次使用新的`review_board_tools/long_runs/日期时间_数量`目录。在接收器启动、发压力命令和正式测量之前，写`policy_before_run.json`，记录策略、策略摘要、注册UTC以及分析器源码SHA；长测元数据也保存这些身份。结束分析前再次比较分析器源码SHA；若改变则阻止继续产出PASS，应保留异常和原记录，不能混用旧结果。

本版分析器身份：`f8d8807b42bb3f96ff69e27200e8d70a1fced76b39818ff14bf49ad6be4cb20b`。策略ID为`R6-native-hardware-and-PC-receipt-v1`，明确仅适用于预注册的新运行：

- 预定预热后只剔除第一条匹配STAT基线，不删后续失败窗。
- 模式/后端/N/limit一致，原生窗口1.9～2.5秒，原始累计scan/swap增量与窗口计数一致。
- 至少完整600000000us和36000次完成换帧；原生缺窗、乱序/重复、重启、错误及missed/UF/丢日志/逻辑丢步等不能忽略。
- 同时保留配置的零fxdrop视觉门槛；硬件节奏与可选视觉丢弃分别解释。
- PC UTC/单调时间是**接收时刻**。若原生硬件证据完整，而接收间隔与原生时长差异超过500000us等，只能保留capture_quality WARNING；这不宽免原生缺口/故障，也不能静默去掉警告。
- 当前策略的overall PASS需要hardware PASS与配置的视觉门槛通过；它是窗口级累计节奏证明，不是每一帧render都低于16.67ms，更不是全游戏性能证明。

该接收质量口径在测量前记录，不得用来追溯改写R5。R5原严格报告仍FAIL，独立硬件节奏PASS只是另一个诊断；R6原性能FAIL也不受p1主机PASS替代。新运行未完成前不预填长测通过。

## 6. 独立补丁与历史材料

`docs/phase_battle_R6p1.diff`从pristine DeepSeek最终完整工程生成（原ZIP SHA256 `d6f56d165cd3289dd328108aa0b18ace72bfe2f7316df1052837b85e42403a6e`），覆盖当前源码、可复现脚本/测试、说明和工具文本，排除build/results/采集、二进制图片及各旧/新补丁自身。

旧`phase_battle.diff`、`phase_battle_R6.diff`保持原样，历史R4/R6文档均不是本版结论。实际板端结果另写独立文件；若依赖工具、源码或补丁所含文档后来再改，必须重新生成p1补丁。最终补丁指纹及只读应用检查由根任务交付清单记录。
