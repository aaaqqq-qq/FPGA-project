> 历史R6说明：本文件随R6冻结，保留当时功能及PENDING边界。R6随后已做短功能测试，但性能未达稳定60FPS。当前R6p1修改、最新身份、验证范围和新上板状态请读[R6p1_RELEASE.md](R6p1_RELEASE.md)；不得将此历史文件当成本次p1结论。

# R6：月夜2.5D背景、可选多Boss与原素材妖精

日期：2026-10-29。本版针对Ti60F225I3-V4，保留TOUHOU / SCARLET NIGHT及1280×720显示，100MHz原硬件基线不变；没有新增RTL、PLL或Flash修改。默认仍是三Boss阶段战、普通敌人0；四Boss/六Boss及6/12只妖精为显式可选压力/玩法配置。本文件冻结时R6离线CI已完成，新R6上板和600秒验收尚待根任务实测，不能由旧版数据推定本版帧率。

## 1. 三种配置与具体操作

| 配置 | boss_count | enemy_count | 说明 |
|---|---:|---:|---|
| 默认/三Boss基线 | 3 | 0 | 原先单露米娅→半血召唤两援军的流程 |
| 四Boss＋六妖精 | 4 | 6 | 原三种Boss素材/脚本的独立实例扩展，加6个普通敌人槽 |
| 六Boss＋十二妖精 | 6 | 12 | 原三模板各两实例，加12个普通敌人槽；不能把它直接称性能已达标 |

`MAX_BOSSES=6`，`ENEMY_CAPACITY=12`。第4～6名为RUMIA II、CIRNO II、MEILING II，对应原三种素材/脚本的独立实例，具有独立VM、HP、狂暴、待发与击破状态，没有声称创作或移植新的独立Boss人物。半血事件把当前配置其余Boss全部带入场；默认3只路径保留，legacy原ECL回归仍按原三模板验证。

关闭其它串口控制器后，在工程根运行：

```text
python scripts/control_r2.py --port <实际COM号>
```

控制台保留兼容文件名`CONTROL_R2.cmd`，本机默认COM16、D:/ELSFPGA。菜单11“四Boss+六妖精”、12“六Boss+十二妖精”、13“三Boss基线”；这些选项先回菜单，修改数量，再开Normal。只是控制当前已加载固件，不会自动编译、下载或写Flash。手工发送等价完整行：

```text
m
:set boss_count 4
:set enemy_count 6
r
```

六Boss改为6/12；回基线改为3/0。`boss_count`仅接受3～6，`enemy_count`0～12，`background_depth_enabled`0/1；这三个字段只允许菜单修改，活动局里返回`ERR topology requires menu`。其它热参数继续使用整数白名单；禁止改时钟、DDR地址或编译容量，录制/回放时禁止调参。数组调参索引现为Boss[0..5]，倍率和交叉校验仍适用；详情以`game_config.c`白名单为准。

板上SW0/1左右，SW2上/SW3下；菜单SW2切模式、SW3开始；菜单SW0+SW1切DEMO，活动局组合键使用炸弹；长按SW2+SW3回菜单。正常受击/回血验证前关闭DEMO。调参控制台日志在`results/control_sessions`，关闭它只释放串口，板卡继续运行。

## 2. 普通妖精的行为与素材来源

`enemies.c/h`提供最多12个槽：错峰进场→摆动驻留→退出→延时重生。HP为20/30/40；每逻辑tick最多两组三发齐射，轮转分配并服从密度限流；发出的弹仍进入同一个20,000容量池，拥有独立owner128+槽号。完整计数包括请求/生成/容量拒绝/延后、击杀/重生/清除；没有额外无限弹池。

玩家直射或现有弹道可击中小怪，命中消耗该玩家弹，实际伤害及击杀200分纳入分数成长；炸弹和接触伤害接入现有流程。**当前追踪武器优先锁定Boss，不会主动搜索小怪**；不能把小怪出图等同新增了小怪追踪AI。普通敌人死亡或退出清除其所属敌弹；所有Boss击破或玩家死亡会清空小怪并停止重生，通关无需把无限重生的小怪全部杀光。

使用原包`assets/source/th06e_ST.DAT__stg2enm`的ANM矩形和独立alpha平面，不重画人物：蓝精灵源sprite0～3→tile83～86，粉精灵sprite8～11→tile87～90，各30×30，原四帧动画保留。透明阈值alpha≥48；不透明RGB只在旧调色板索引1～255选择最近色，索引0仍是透明key。

`scripts/append_original_enemies.py`复用`prepare_stage.py`的`load_tile`原函数；它在原83张生成完成后追加8张。`ART_TILE_COUNT=91`，`ART_BYTES=295632`。独立对照冻结R4，旧83张描述符、256色调色板和66708个原索引像素均逐字节相同，新增加7200个索引字节；54～69连续8×8批次材质不变。证据：`results/original_enemies_prefix.json`；实际量化接触图在`assets/generated/original_enemies/fairy_contact_sheet.png`。完整`prepare_stage.py`与追加脚本均已真实运行，不修改`assets/source`原文件。

HUD区分ACTORS、SPRITES、BOSS和MOB：ACTORS为活动逻辑实体（包括入场中的槽，未必每个已经完全进入屏幕）；SPRITES为真实提交的tile/批次精灵数量，含敌弹、人物及视觉特效，HUD字体/矩形不计作精灵。4个角色不等于只画4个精灵；容量上限、当前活动N与绘制提交数也不等价。

## 3. 缓存月夜2.5D背景

`background.c/h`提供`background_prepare(enable)`和`background_pixel(x,y)`：暗靛蓝渐变天空、月晕与少量星点、远/中山体、雾和错落树线、低对比透视地面与侧边近景。它用分层、远近色差及透视线制造2.5D纵深，**不是完整3D引擎**，没有3D模型、相机或深度缓冲。

仅在`scene_init`准备11220字节整数查找缓存，再一次写入现有BACKGROUND。活动帧仍由原batch/copy恢复，没有新增逐帧整屏alpha层、动态内存或浮点三角计算。活动场地限制在x32..1055/y16..703，边框和右侧UI保持原规则，亮区只占很小部分，优先保证白/青/红弹幕对比。

默认`background_depth_enabled=1`。菜单中`:set background_depth_enabled 0`可恢复旧夜景，设1恢复深度背景；该命令明确重跑初始化并重建统计基线，不把这次初始化停顿计入稳定工况，活动局不允许切换。

实际背景函数生成PPM后转PNG，预览为`results/background/background_depth.png`，属于真实函数输出而非AI示意图。`scripts/test_background.py`已验证确定性、全部屏幕/场地边界、前后guard、低亮度约束、关闭模式与旧算法逐像素一致；64帧deferred CPU/HW参考比较和12帧HUD/四工况边缘恢复分别有宿主证据。宿主运行秒数不能当作FPGA启动或渲染耗时。

## 4. 继承的十一项优化

| 序号 | 功能 | 当前实际实现与边界 |
|---|---|---|
| 1 | 密度自适应 | `battle.c`占用严格大于80%时，普通发射调用按1/2通过；降至不高于70%恢复；使用迟滞，脚本时间、移动和半血爆发仍执行；不是减小固定STRESS的N。 |
| 2 | 擦弹视觉（音效未实现） | 真实首次擦弹调用`fx_graze`，默认8tick冷却，短寿命星点为低优先级，共享效果硬预算；没有新增音频输出。 |
| 3 | 差异化狂暴模板 | `game_config.c`分表：露米娅6环且爆发量3/2，琪露诺普通狂暴弹数2倍，美铃狂暴移速3/2；可关闭profiles回到统一倍率，默认三名；扩展实例按原三模板分别持有状态。 |
| 4 | 低HP警示 | 默认严格HP<30时，HP条脉冲、中心判定点和描边变色；HP=30不触发。阈值与周期可热调；视觉效果不改变碰撞判定。 |
| 5 | PLAY接触候选 | `battle.c`8个Y桶，每桶4096索引；只扫描相关桶，相关桶溢出立即完整扫描。20,000弹的移动、寿命和物理效果仍逐颗处理，不能称所有循环都已消除。 |
| 6 | HUD脏行 | `scene_hud_begin/end`捕获真实绘制命令，两个缓冲各自精确memcmp；仅恢复变化的8像素行带，删除/缩短文字与血条也清理；初始化、模式切换、取消和参数变化会失效。 |
| 7 | 追踪弹降频选敌 | 追踪弹前40tick内默认每4tick重选目标/调整转向，目标失效立即重选；之后沿当前速度继续。每tick仍移动、处理寿命和碰撞，发弹周期仍独立。 |
| 8 | 击破慢动作与消弹星 | 死亡后12个60Hz基础tick（约200ms）内，每3个基础tick执行一次核心逻辑；只清除死Boss所属敌弹，最多8个低优先级星点，保留原击破环。 |
| 9 | 轻量预警边缘 | `effects_vignette`为四条稀疏边缘点缀，每次最多4任务/1664像素；在主特效后绘制，共享预算；不增加整屏后处理，退出时由场地恢复清除。 |
| 10 | 种子与输入回放 | `replay.c/h`最多4096条8字节RLE事件，事件区32KiB，加32字节头；保存种子、配置身份、CRC、结束tick和最终权威状态哈希。错误/溢出停止，不覆盖为假成功。 |
| 11 | 整数白名单热调 | 完整一行`:set 字段 整数`，原子验证后更新；越界、未知字段、负数、溢出及不满足关系的组合均拒绝，配置保持原值；录制/回放期间禁止调参；Boss数/小怪数/背景只允许在菜单修改。 |

声音输出仍未实现。纯视觉效果共享32槽、12任务/16384像素硬上限，普通妖精和扩展Boss不会增加这个预算。`effects_over_budget`为该帧拒绝数，`effects_drop_total`跨帧累计；窗口fxdrop与容量发弹拒绝、逻辑丢步、显示漏换帧应分别报告。

追踪弹只在前40个tick转向，默认4tick重选；目标失效立即重选，之后继续现有速度。Seed回放继续最多4096条8字节事件（32KiB），保存配置身份、CRC、结束tick和最终权威哈希；现已包含普通敌人的逻辑状态。录制会重开Normal/live并清DEMO/自动驾驶，但保留菜单选择的Boss/小怪配置。调参后配置不同会拒绝旧回放，不能只凭同种子宣称同局。

```text
:record 1852404840
:stop
:replay
:replay status
:replay dump
```

等REPLAY_END后，可用`scripts/replay_tool.py`校验导出并用`scripts/test_replay.py --replay-json ...`复验真实生产逻辑。当前没有声称支持任意PC文件通过UART通用导入；板内录制在RAM，重启不保留。权威哈希不包含墙钟、渲染、UART或纯视觉粒子，输入回放不是屏幕录像。

## 5. 100MHz性能路径与验收分组

保留四弹统一加载、HUD双缓冲精确脏行、32位字体span和仅FPGA STRESS的安全描述符重叠。快照helper先CMD后I/O fence，以首次新BUSY锚定至少1us，再读`4096+冻结batch_count×16`；ERROR/DONE/超时和退出fence保留。硬件在同一100MHz时钟的接受CMD后一周期无条件复位计数、锁存输入；1us只建立当前命令身份，不能代替完整描述符快照门槛。PLAY/DODGE不直接使用这个未来tick重叠。

固定60Hz使用整数有理累加，两初始化帧预热不冒充稳态；追帧最多3步，丢步有ldrop/lover。原始`scan_total`/`swap_total`通过一致读形成共同状态；`frame`是处理耗时，不是扫描累计次数。`render`包含重叠墙钟，不能再把overlap加进去重复计算；屏显R慢更新不改变原始计数证据。

后续上板必须分开：默认3+0、4+6、6+12完整玩法；固定N4096/8192/12000/16384/20000压力；CPU同N对照；600秒显示/DDR稳定性。每组记录模式、难度、DEMO、level、真正活动弹数、实体/精灵数、bit/ELF身份、时间和异常。**两万是编译容量，不代表本版全游戏在20,000活动弹时稳定60FPS**，也不能用固定STRESS代替完整6Boss+12妖精玩法。

## 6. R5历史结果：保留原FAIL，独审不能改写总验收

R5固定8192个8×8活动精灵、100MHz/720p、FPGA STRESS有一段原始长日志。原`stability_600s.json`严格回执保持FAIL，`passed_60fps=false`，原因`capture_gap_or_native_duration_inconsistency`；PC接收时间有两处抖动，严格合格子集仅596866603us/35812次换帧，未达到原600秒条件。不能删掉这两窗后把旧报告改成PASS。

同一原始数据的独立`hardware_cadence_audit.json`仅诊断硬件累计计数：600899952us、36054次换帧，扫描绝对跨度和换帧跨度均36054，约60.0000048FPS，欠流、漏换帧和效果丢弃计数0；其`hardware_status=PASS`，但`capture_quality=WARNING`、`original_overall_status=FAIL`。这是**限定硬件节奏诊断**，不是替换原严格判据的总体通过。

来源：R5 `review_board_tools/long_runs/20261029_023528_8192`；原回执SHA256为`f39c7f7fd5e8fcafffe2a8814cd1ef0c46b13d2aebc61493377c340b7e4ed551`，源JSONL SHA256为`2e4c8993cb46f4b2e9445bb805f6b0225a7851d867ca70d0db040e898041721a`。原结果、失败窗和原日志均保留。上述仅属于R5/8192 STRESS，不属于R6、不属于20k或六Boss完整游戏。

## 7. R6当前真实验证与身份

离线CI结束：2026-10-28T18:57:28.304199+00:00；已逐文件核对该记录绑定当前`src`。implementation、host_tests、rv32_build均PASS，宿主检查18组：

| 项 | 实际结果 | 原始日志 |
|---|---|---|
| `benchmark_acceptance` | PASS | [`benchmark_acceptance.log`](../results/validation/benchmark_acceptance.log) |
| `enemies` | PASS | [`enemies.log`](../results/validation/enemies.log) |
| `expanded_battle` | PASS | [`expanded_battle.log`](../results/validation/expanded_battle.log) |
| `r6_integration` | PASS | [`r6_integration.log`](../results/validation/r6_integration.log) |
| `stability_analyzer` | FAIL | [`stability_analyzer.log`](../results/validation/stability_analyzer.log) |
| `stress_pipeline` | PASS | [`stress_pipeline.log`](../results/validation/stress_pipeline.log) |
| `telemetry_counters` | PASS | [`telemetry_counters.log`](../results/validation/telemetry_counters.log) |
| `frame_clock` | PASS | [`frame_clock.log`](../results/validation/frame_clock.log) |
| `replay` | PASS | [`replay.log`](../results/validation/replay.log) |
| `runtime_cli` | PASS | [`runtime_cli.log`](../results/validation/runtime_cli.log) |
| `r2_core` | PASS | [`r2_core.log`](../results/validation/r2_core.log) |
| `font_equivalence` | PASS | [`font_equivalence.log`](../results/validation/font_equivalence.log) |
| `r2_render` | PASS | [`r2_render.log`](../results/validation/r2_render.log) |
| `phase_gameplay` | PASS | [`phase_gameplay.log`](../results/validation/phase_gameplay.log) |
| `legacy_battle` | PASS | [`legacy_battle.log`](../results/validation/legacy_battle.log) |
| `stage` | PASS | [`stage.log`](../results/validation/stage.log) |
| `dodge_controls` | PASS | [`dodge_controls.log`](../results/validation/dodge_controls.log) |
| `scene_pixels` | PASS | [`scene_pixels.log`](../results/validation/scene_pixels.log) |

新增敌人、扩展Boss、R6集成和帧时钟检查真实执行；扩展Boss检查84975项，另有原ECL36000帧、64帧整屏、字体826+20+8、回放/CLI/快照/计数及原有玩法回归。独立背景与图集前缀证明在前文所列文件。这些是源码/宿主模型/RV32构建结果，不能替代物理DDR、HDMI和帧率验收。

本轮ELF SHA256：`acd65a167459a215049d29ff7fbe2bd8d430e906df24d18be230f20a27493a73`。入口0x1000，有效加载164226字节，PT_LOAD内存跨度910640字节。完整指纹和工具版本以`build/identity.json`为准；加载时必须重新核对该身份与完整读回。

原720p100MHz位流SHA256：`8c294a053584c52f4bf44a6a627dbac7008fbe3df83cccf18b0b924e4bfd7269`。没有新综合/P&R/时序结果；不要使用马里奥/合金1080p底座或旧Flash镜像冒充本版。Flash仍不更新。

| R6阶段 | 本文件冻结时状态 |
|---|---|
| 生产源码/宿主检查/RV32构建 | PASS，范围如上 |
| 新R6临时上板、目视、按键与逐配置短测 | PENDING，等待根任务实际日志/用户确认 |
| R6的600秒严格接收与硬件连续性 | NOT_RUN/待新采集，不继承R5独审 |
| 20k完整玩法稳定60FPS或6Boss+12妖精性能达标 | 尚无证明，不作承诺 |
| Efinity新硬件构建、提频、Flash/断电自启 | NOT_RUN，本轮未修改相关硬件 |

后续板端结果独立追加，保留原始失败/成功日志并给出配置和版本，不能回填成本文早已通过。

## 8. 独立R6补丁

`docs/phase_battle_R6.diff`针对原始DeepSeek最终完整工程（ZIP SHA256 `d6f56d165cd3289dd328108aa0b18ace72bfe2f7316df1052837b85e42403a6e`）重新生成，涵盖源码、脚本、测试、说明及工具文本；排除build/results/运行捕获、二进制图片与补丁自身。未改动旧`docs/phase_battle.diff`，它继续保留旧版本证据，不能用来重建当前R6。

R6独立补丁必须在所标基线上检查；最终应用检查和补丁指纹由根任务交付清单记录。若源码、依赖工具或本节所含文档之后再变更，应重新生成R6补丁，避免再次产生陈旧文档hunk。原始基线保持不变。
