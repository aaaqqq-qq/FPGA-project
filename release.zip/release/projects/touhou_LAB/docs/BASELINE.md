# 基线版本

- 输入ZIP：`hdmi_rumia_ultimate.zip`
- 大小：105,585,252字节
- SHA256：`2d8cb25f98acfafeea81950f96e9fa75559f261b36d3ce48f9a66e146d5b93d8`
- ZIP顶层：`hdmi_rumia_ultimate/`

本次改造在ASCII工作副本上完成；完整原始ZIP保持未修改。原始工程的文件
指纹见`results/baseline_source_hashes.json`（原包自带）；本次新增/修改后的
`src/`指纹见`build/identity.json`和`results/verification.json`。

回退方法：直接解压原始ZIP。注意原始`START_720P_JTAG_ONLY.cmd`和
`scripts/download.ps1`含原作者Windows绝对路径；没有对应板卡/Efinity环境不要
直接运行。

本工程`flash/`中的旧镜像不是本次新ELF，详见`flash/LEGACY_README.md`。
