# TEST PLAN — T01..T12 与实际入口

所有主机测试都编译生产 `src/*.c`（`game.c`、`player.c`、`battle.c`、`stage.c`、
`effects.c`、`game_config.c`），只对 BSP/MMIO/渲染入口打桩；不是另写一个
永远正确的Python假游戏。

| 编号 | 覆盖 | 生产驱动 | 入口/证据 |
|---|---|---|---|
| T01 | 初始只有露米娅活动；另两位WAIT、不发弹、不可伤、不被追踪 | `game.c` + `battle.c` 状态机 | `tests/phase_gameplay.c::test_t01`，`results/phase_gameplay.json` |
| T02 | 1501/1500/1499边界；多弹/炸弹同tick跨线；直接致死穿过半血只触发一次 | `battle_apply_damage` | `test_t02` |
| T03 | 首Boss回满后二次半血、ECL循环重置、连续调用：不重复狂暴/召唤/回血 | `battle.c` + `battle_step` | `test_t03` |
| T04 | 两援军同时入场/结束保护；各自半血独立狂暴；不同死亡顺序 | `battle.c` | `test_t04` |
| T05 | 玩家HP、多弹同tick只扣一次、保护重叠、玩家与最后Boss同tick死亡优先级 | `player.c` + `logic` | `test_t05` |
| T06 | 5秒回血边界、实际受击重置、保护接触不重置、整数回血封顶、死亡不回血 | `player.c` | `test_t06` |
| T07 | 各等级射路/追踪变化、128槽拒绝、跨门槛只一次动画、死亡不升级 | `player.c` | `test_t07` |
| T08 | 无效目标不产分、实际伤害计分、击破/擦弹不重复、回血不刷分 | `battle_apply_damage` + `battle_step` | `test_t08` |
| T09 | 满池拒绝、requested/rejected、age上限、近邻候选溢出回退、无越界 | `battle.c`/`stage.c` | `test_t09` |
| T10 | 菜单/开局/半血/入场/受击/回血/强化/胜负/重开连续流程与复位 | `game.c` | `test_t10` |
| T11 | 两帧缓冲交替、文字变短、HP下降/回升、效果结束、角色死亡/回菜单：无残影；CPU/硬件模型像素一致 | `scene.c`/`font.c`/`pixels.c` | `scripts/test_scene.py`，`results/scene_pixels_batch720.json` |
| T12 | 原基础Copy/Fill/Alpha/Key、压力、DODGE、输入回归；最高火力+三Boss狂暴峰值 | `stage.c`/`battle.c`/`game.c` | `scripts/test_stage.py`、`test_original_battle.py`、`test_dodge.py`、`test_scene.py`、`phase_gameplay::test_t12` |

## 真实运行命令

```bat
python scripts\test_phase_gameplay.py --host-cc <host-cc>
python scripts\test_original_battle.py --host-cc <host-cc>
python scripts\test_stage.py --host-cc <host-cc>
python scripts\test_dodge.py --host-cc <host-cc>
python scripts\test_scene.py --host-cc <host-cc>
python scripts\verify_all.py --host-cc <host-cc> --toolchain-bin <riscv-bin>
```

`verify_all.py`逐项记录PASS/FAIL/NOT_RUN；缺主机CC时host_tests为NOT_RUN，
缺RISC-V工具链时rv32_build为NOT_RUN，不会打印“全部PASS”。

## 测试与真板的边界

- T11使用同步bitblt的PC模型，验证调度/脏区/双缓冲像素一致；**不是**实板
  截图，也不证明真实DDR/AXI时序。
- 主机计时不代表100MHz RISC-V周期；实板60FPS/600s/UNDERFLOW/漏帧需上板。
- 旧`test_original_battle.py`只验证原ECL解析/发射计数；新狂暴弹幕不要求与
  未修改ECL逐帧一致。
- `benchmark_board.py --battle`保留自然阶段战所有STAT窗口，不按容量档过滤；
  `--hz`是目标换帧率，不是核心MHz。
