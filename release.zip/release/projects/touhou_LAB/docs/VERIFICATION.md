<!-- ADV1_CURRENT_RELEASE -->
# 当前版本 ADV1 / LAB23（2026-11-01）

新增高阶 Alpha、Color Key、联合比较和多尺寸/颜色/形状/可选物理压力实验；保留原东方 Project、基础一/二/三、电脑控制和 100MHz/RTL 基线。实现与验收说明见 [ADV_IMPLEMENTATION.md](ADV_IMPLEMENTATION.md)，线协议见 [adv_protocol.json](adv_protocol.json)，相对 LAB23 补丁见 [adv1_source.diff](adv1_source.diff)。

当前离线证据是 `results/verification_adv1.json`：30组宿主回归、静态检查与真实RV32构建均PASS；完成2026-11-01T03:29:17.387742+00:00。新增实验独立宿主测试是 `results/adv_host.json`；独立审查见 `independent_review/`。首次适配失败及修复日志保留在 `results/verification_adv_stdout.log`，不要误作最终结论。

当前 ELF SHA256 `00c0596bcf091580cbc543e2d2943098568a227d0a58d409278301ffc3e6d88a`，加载233266字节，含4096字节预留栈RAM用量1008256/1044480字节。新板输出、全Flash固化读回、断电自启动、吞吐与帧率必须由本版本单独实测；离线结果不代表板测。此段以下R6/R4及更早内容均为历史记录。

---

<!-- R6_CURRENT_RELEASE -->
# 当前版本R6（2026-10-29）

当前功能、控制、验证身份和验收边界统一见[R6_RELEASE.md](R6_RELEASE.md)。默认3Boss/0妖精，菜单可选4+6或6+12；新增缓存月夜2.5D背景和原ANM普通妖精，保留原游戏名及100MHz/RTL/BSP/Flash基线。
本次生产源码绑定的离线CI18组及RV32构建PASS（完成2026-10-28T18:57:28.304199+00:00）。新R6上板/600秒尚待根任务实测，不能宣称20k或六Boss完整游戏已稳定60FPS。
R5原严格回执保持FAIL；独立hardware_status=PASS只是8192 STRESS累计节奏诊断且capture_quality=WARNING，不改写原验收。
R6当前ELF SHA256 `acd65a167459a215049d29ff7fbe2bd8d430e906df24d18be230f20a27493a73`，加载164226字节。独立补丁为`phase_battle_R6.diff`，旧`phase_battle.diff`保持原样。

---
## 以下为旧版本历史记录

以下R4及更早身份、三Boss固定范围、旧内存/测试数字和PENDING都描述当时版本；当前R6以顶部链接为准，历史不能充作新板测。

<!-- R4_RELEASE_CURRENT -->
# 当前验证：R4（2026-10-29）

完整本版功能/验证表见[R4_RELEASE](R4_RELEASE.md)，机器结果为工程根`results/verification.json`，完成时间2026-10-28T17:56:21.857333+00:00。
实际总命令退出0：implementation PASS、host_tests PASS（14组）、rv32_build PASS。
新增font_equivalence对当前src/font.c进行826+20+8个完整帧/guard用例，snapshot流水、telemetry计数一致读、27项稳定性分析器等均实际PASS。
原始日志在results/validation。宿主GCC9.2/RISC-V GCC13.4可用；hardware_build/board_function/board_fps在离线脚本里NOT_RUN，原因是此脚本不执行设备步骤，不是环境探测缺工具/缺板。
R4新ELF SHA256：`6dc378c577119570b6b6e546129049ac309761625b7b18cbf52750b6d2fab81f`，有效加载147970字节；硬件底座继续使用原100MHz位流8c294a05…。
本文冻结时R4临时上板正在进行，板端功能和性能PENDING；后续独立SESSION记录另存。600秒、完整三Boss+Lv5高负载60FPS、DDR/HDMI长测、Flash更新均未由上述主机PASS证明。

---
## 以下为初版及R1/R3历史验证记录

历史中的720886B、旧ELF、旧脚本工具缺失理由、R1/R3 PENDING只描述当时版本；不得当作R4身份或当前板端结果。

# VERIFICATION — 实际执行记录

本文件只记录本次会话实际执行过的命令与结果；未执行项明确标NOT_RUN。
机器可读记录：`results/verification.json`、`build/identity.json`。

## 1. 环境

| 项 | 值 |
|---|---|
| 主机 | Windows（`os.name=nt`） |
| Python | 3.14.7 |
| Pillow | 12.3.0 |
| 宿主CC | Zig 0.16.0 `zig cc`（clang 21.1.0，x86_64-windows-gnu），通过`hostcc.cmd`包装 |
| RISC-V工具链 | xPack GNU RISC-V Embedded GCC 13.4.0，`riscv-none-elf-`前缀 |
| RISC-V路径 | `D:\FPGA\tools\xpack-riscv-none-elf-gcc-13.4.0-1\bin` |
| 基线ZIP | `hdmi_rumia_ultimate.zip`，SHA256 `2d8cb25f98acfafeea81950f96e9fa75559f261b36d3ce48f9a66e146d5b93d8` |

## 2. 总验证命令

```bat
python scripts\verify_all.py ^
  --host-cc D:\rumia_work\tools\hostcc.cmd ^
  --toolchain-bin D:\FPGA\tools\xpack-riscv-none-elf-gcc-13.4.0-1\bin
```

汇总：

| 类别 | 状态 | 证据 |
|---|---|---|
| implementation | PASS | 16项静态契约检查（见`results/verification.json`） |
| host_tests | PASS | phase/legacy/stage/dodge/scene，日志`results/validation/*.log` |
| rv32_build | PASS | `build/rumia.elf`，SHA256以`build/identity.json`为准（首次会话`624126d0...`，复验重建`10f94247...`，差异来自构建路径嵌入的调试信息，源码逐字节一致） |
| hardware_build | NOT_RUN | 本会话无Efinity完整flow/授权IP |
| board_function | NOT_RUN | 无Ti60F225I3-V4板卡连接 |
| board_fps | NOT_RUN | 无板卡，不能测100MHz 60FPS/600s |

## 3. 主机测试明细

### T01–T10/T12

命令：`python scripts\test_phase_gameplay.py --host-cc <host-cc>`

输出：`T01 PASS ... T10 PASS T12 PASS stress_count=1018 peak=1153`，
`ALL_PHASE_TESTS_PASS`。测试直接包含生产`game.c`并链接
`stage.c/battle.c/player.c/effects.c/game_config.c`。

### 旧ECL回归（legacy）

命令：`python scripts\test_original_battle.py --host-cc <host-cc>`

输出：`PASS: 36,000 frames, all 3 bosses match raw original ECL emission
counts/timestamps`。三种难度各12,000帧，Cirno沿用原Hard分支（与
`original_code[1][0]`一致）。

### stage/容量

命令：`python scripts\test_stage.py --host-cc <host-cc>`

三种难度各12,000帧原始浮点ECL vs C定点逐帧发射计数/速度；20000满池10,000帧；
limit=16拒绝测试。结果`passed:true`，`stress_count:20000`，
`limit_test_rejected:12204`。

### DODGE/输入

命令：`python scripts\test_dodge.py --host-cc <host-cc>`

输出：`PASS dodge/input/timeout/hold-menu`。覆盖三命、炸弹、200秒、
输入去抖、低帧率菜单退出、长按SW2+SW3。

### T11像素

命令：`python scripts\test_scene.py --host-cc <host-cc>`

输出：`PASS: 64 complete 1280x720 frames match full redraw byte for byte`。
两帧缓冲交替、64帧CPU/硬件模型逐像素一致；覆盖新HUD、效果图集、文本变短、
HP变化、菜单清除、取消/恢复。该模型是同步bitblt宿主模型，不是实板时序。

## 4. RV32构建

命令：

```bat
python scripts\build_firmware.py ^
  --toolchain-bin D:\FPGA\tools\xpack-riscv-none-elf-gcc-13.4.0-1\bin
```

结果：

```
RV32_BUILD=PASS
Memory region Used Size 720886 B / 1020 KB (69.02%)
text 39044  data 87526  bss 594316  dec 720886
ELF build/rumia.elf
SHA256 以 build/identity.json 为准
```

首次会话（`D:\rumia_work`路径）ELF SHA256
`624126d05279ab35385a50e0b5f36c75f71b18c0867cd04d8c852b83e09223c1`；
复验会话（`D:\deepseek交付工作区\work`路径）重建为
`10f94247eaf8e184d15cd1f873a0c9e0a44528f19e2a91b3ca3f03b114bdb370`。
两者仅差构建路径嵌入的调试信息，源码与flags一致；内存占用数字完全相同。

源码/链接脚本指纹、工具链版本、flags见`build/identity.json`。
仅有的编译警告来自原BSP的`print.h`（`digi`未用、注释内`/*`）和链接器RWX
LOAD段；新源码无新增warning（`-Wall -Wextra`）。

## 4.1 复验记录（第二会话，2026-10-28）

在新解压副本中独立重跑：

```bat
python scripts\verify_all.py ^
  --host-cc D:\rumia_work\tools\hostcc.cmd ^
  --toolchain-bin D:\FPGA\tools\xpack-riscv-none-elf-gcc-13.4.0-1\bin
python scripts\render_preview.py --host-cc D:\rumia_work\tools\hostcc.cmd
```

结果：implementation PASS、host_tests PASS（T01–T10/T12、legacy 36,000帧、
stage、DODGE/输入、T11像素）、rv32_build PASS；hardware_build/board_function/
board_fps 仍 NOT_RUN（同样无Efinity/板卡）。9张PC预览PNG全部重新生成。
机器可读记录已刷新到`results/verification.json`。

## 5. 未执行项与原因

| 项 | 状态 | 原因/需要什么 |
|---|---|---|
| Efinity综合/布局布线/时序 | NOT_RUN | 本会话无Efinity安装/授权IP；未生成新bit |
| 100MHz实板功能/帧率 | NOT_RUN | 无板卡连接 |
| 600秒/36000次有效换帧稳定负载 | NOT_RUN | 需上板，按4k→8k→12k→16k→20k分档 |
| Flash更新/读回 | NOT_RUN | 未重新生成boot image；旧`flash/*.bin`是旧ELF |
| 新bit/ELF身份匹配 | NOT_RUN | 无新bit；软件版RTL未变，但本会话未上板验证 |
| 实板DDR/画面长测 | NOT_RUN | 同一硬件限制 |

**不能**把主机测试或PC预览当作实板60FPS证明；`docs/FREQUENCY_STUDY.md`
说明了100MHz/提频条件。

## 6. 关键产物

- `build/rumia.elf`、`build/rumia.map`、`build/identity.json`、`build/compile.log`
- `results/phase_gameplay.json`
- `results/original_battle_reference.json`
- `results/stage_tests.json`
- `results/dodge_controls.json`
- `results/scene_pixels_batch720.json`
- `results/verification.json`
- `results/preview/00..08*.png`和`manifest.json`（PC宿主模型）
- `assets/generated/effects/*.png`、`effects_manifest.json`
- `results/validation/*.log`
- `docs/phase_battle.diff`（相对基线的统一diff补丁，范围见文件头注释）

旧Flash镜像的说明见`flash/LEGACY_README.md`；它们不是本版本ELF。


## 2026-10-29 Reviewer R1验证补充

- 新增T13输入追帧/排队与T14同N配对HUD条件回归：生产C宿主stdout已实际确认PASS，结果JSON同步列出。
- scripts/test_benchmark_acceptance.py：16项离线回归实际PASS，包括600秒/36000有效换帧样本通过，以及短6秒、缺窗、模式/后端/容量切换、欠流/漏帧/逻辑/日志/特效异常拒绝。
- 以上为宿主/隔离遥测测试，不访问板卡，不能替代DDR/HDMI时序或新固件实测。
- 本次短板测PENDING（以随后新SESSION原始日志为准）；600秒新版本长测NOT_RUN。
- 原100MHz位流继续复用；Efinity重新综合/布局布线/时序未执行。Flash保持NOT_RUN，不使用旧ELF镜像。
- benchmark采集增加6秒过渡/尾部余量，但通过仍要求有效STAT数据达到请求时长、换帧数及全部连续性/异常条件；当前只有窗口级证据，不能宣称逐帧时限全部满足。


## Reviewer R3 (2026-10-29)
见 docs/R3_OPTIMIZATION.md；独立R2/R3证据分别保留，硬件时钟/RTL/Flash未改。R3新实板/长测状态以最终结果记录为准。
