> 历史R3候选记录：其中要求捕捉READ_BYTES<4096的重叠门槛已因板端性能退化被拒绝；当前R4门槛和验证边界见[R4_RELEASE.md](R4_RELEASE.md)。R3数据不得当作R4结果。

# R3：十一项体验优化与100MHz性能路线

日期2026-10-29。保留Ti60F225I3-V4、三Boss、TOUHOU/SCARLET NIGHT名称、720p和100MHz；未改RTL、PLL或Flash。原R1/R2及原始输入保留。硬件构建NOT_RUN不等于工具缺失；本版复用逐文件身份相同的8c294a05原位流。

## 已实现内容

1. 池占用超过80%减普通发射节拍，低于70%恢复；迟滞避免抖动，半血爆发保留，脚本时间和移动不跳步。
2. 擦弹反馈采用冷却限流星点，共享特效预算；本轮没有新增音频输出。
3. 露米娅爆发6环/1.5倍爆发量、琪露诺普通狂暴弹数2倍、美铃狂暴移速1.5倍，仍仅3人。参数分表、可关闭。
4. HP严格小于30时HP条脉冲、判定点描边变色；30不触发。
5. 8个Y桶用于实际PLAY的敌弹接触候选，每桶4096项；相关桶溢出完整扫描。20,000弹的移动和寿命仍逐颗计算，不能称全循环消除。
6. HUD按两缓冲分别保留精确绘制命令和变动行。相同HUD不提交恢复任务；缩短/删除文字和血条正确清理。R~为每200ms更新的屏显耗时采样，串口原始render/window_peak未降采样。
7. 追踪目标和转向每4tick更新，目标失效立即重新获取；每tick仍移动和碰撞。
8. Boss死亡后12个60Hz基础tick约200ms慢动作，期间核心每3tick更新；只消去死Boss所属敌弹，最多8个低优先级星点。
9. 狂暴预警采用轻量四边暗角点缀，1664像素/4任务；结束后正确恢复。
10. 4096条/32KiB输入RLE回放：种子、配置身份、CRC、结束tick与最终状态哈希。包含私有VM/待发/弹丸效果，错误或容量溢出明确停止。
11. 串口整数热调参：原子白名单更新，非法值不改变配置；录制/回放期间拒绝调参。不能修改Boss数量、时钟、地址或容量。特效硬上限12任务/16384像素，直接改结构体也不能绕过。

## R3性能改动

- 文字常见路径采用32位横向连续span，边界/大缩放保留参考fallback；以完整帧和前后guard验证一致。
- STRESS每4弹先统一读取12个对齐字，再写位置，减少CPU AXI写后读排空；不改变Shot的16字节DMA布局。
- 仅FPGA STRESS：锁存本帧描述符后，CPU与GPU重叠准备下一tick。必须先观察本命令低读计数，再满足4096+冻结数量×16，未观察到则等待DONE。PLAY/DODGE/验证不重叠。
- 未来准备状态在零逻辑步时不提交；0/1/2/3步和开关模式均与串行参考一致。
- 60Hz逻辑使用整数有理累加，模式初始化的两缓冲预热不计入稳定工况。初始化帧保留原日志，不当作持续600秒数据。
- overlap_us单列；render为包含重叠的墙钟时间，不能再加overlap重复计时。

## 操作

现有SW0/1左右、SW2上、SW3下，菜单SW3开始，长按SW2+SW3回菜单保持。
双击CONTROL_R2.cmd是调参控制台（名字保留兼容，控制的是当前同目录固件），默认COM16，须先关闭其它串口窗口。它不编译/下载/改Flash。
推荐由控制台发送完整行，人工慢速输入使用冒号前缀，避免与旧单键r/s冲突：
    :set hud_dirty_enabled 1
    :set adaptive_density 1
    :set homing_retarget_ticks 4
    :set boss_bullets_num[1] 3
    :set death_slowmo_enabled 1
    :record 1852404840
    :stop
    :replay
    :replay status
    :replay dump
REPLAY_END后用scripts/replay_tool.py核CRC/导出；scripts/test_replay.py可在PC实际生产逻辑重放。录制会重开Normal/live新局，禁用DEMO/自动驾驶；自用不同配置须保留配置身份，不能套原配置回放。

性能开关：hud_dirty_enabled、stress_gather_enabled、stress_overlap_enabled、near_enabled均可设0/1。压力测试用mn20000换行再s换行，固定N不等同自然战始终有20,000弹。

## 验证边界

源码/主机模型/RV32构建/实板启动/短窗性能/600秒稳定性分别记录。R2已证明4096 HUD开60/关30/再开60，20k仍20FPS，不能当作R3成绩。R3实际结果以同目录results及资料库最终报告为准。600秒未取得完整日志前保持NOT_RUN。20,000固定压力与三Boss+Lv5完整玩法分别验收。

## 查阅的公开一手资料

- LVGL官方绘制/双缓冲： https://lvgl.io/docs/open/9.0/overview/draw
- Infineon官方图形例程，full/direct与双缓冲： https://github.com/Infineon/mtb-example-psoc-edge-gfx-lvgl-demo/blob/master/docs/design_and_implementation.md
- AMD UG1399连续访问、突发、行缓存原则： https://docs.amd.com/r/en-US/ug1399-vitis-hls/Summary
- Project F作者帧缓冲/硬件精灵实现： https://projectf.io/posts/framebuffers/ 和 https://projectf.io/posts/hardware-sprites/
- Efinix官方Sapphire能力/配置： https://www.efinixinc.com/support/ip/riscv-sapphire.php
这些资料支持设计原则；不同FPGA、HLS示例或厂商fMAX数字不构成本工程提频或FPS证明。本轮没有改RTL。
