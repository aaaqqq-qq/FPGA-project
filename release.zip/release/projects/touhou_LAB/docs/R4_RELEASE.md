# R4交付说明：三Boss阶段战、十一项体验功能与100MHz优化

日期：2026-10-29。板卡Ti60F225I3-V4；保持TOUHOU / SCARLET NIGHT、三名Boss、1280×720和100MHz。没有修改RTL、PLL、BSP或Flash。本文件在R4离线CI结束后冻结；R4实板正在执行，以下不预填FPS或功能通过。随后板端结果另存独立记录，不能用本文的PENDING替代后续原始日志，也不能由旧版本结果推定本版成绩。

## 1. 十一项功能与代码落点

| 序号 | 功能 | 当前实际实现与边界 |
|---|---|---|
| 1 | 密度自适应 | `battle.c`占用严格大于80%时，普通发射调用按1/2通过；降至不高于70%恢复；使用迟滞，脚本时间、移动和半血爆发仍执行；不是减小固定STRESS的N。 |
| 2 | 擦弹视觉（音效未实现） | 真实首次擦弹调用`fx_graze`，默认8tick冷却，短寿命星点为低优先级，共享效果硬预算；没有新增音频输出。 |
| 3 | 三Boss差异化狂暴 | `game_config.c`分表：露米娅6环且爆发量3/2，琪露诺普通狂暴弹数2倍，美铃狂暴移速3/2；可关闭profiles回到统一倍率，仍仅三名Boss。 |
| 4 | 低HP警示 | 默认严格HP<30时，HP条脉冲、中心判定点和描边变色；HP=30不触发。阈值与周期可热调；视觉效果不改变碰撞判定。 |
| 5 | PLAY接触候选 | `battle.c`8个Y桶，每桶4096索引；只扫描相关桶，相关桶溢出立即完整扫描。20,000弹的移动、寿命和物理效果仍逐颗处理，不能称所有循环都已消除。 |
| 6 | HUD脏行 | `scene_hud_begin/end`捕获真实绘制命令，两个缓冲各自精确memcmp；仅恢复变化的8像素行带，删除/缩短文字与血条也清理；初始化、模式切换、取消和参数变化会失效。 |
| 7 | 追踪弹降频选敌 | 追踪弹前40tick内默认每4tick重选目标/调整转向，目标失效立即重选；之后沿当前速度继续。每tick仍移动、处理寿命和碰撞，发弹周期仍独立。 |
| 8 | 击破慢动作与消弹星 | 死亡后12个60Hz基础tick（约200ms）内，每3个基础tick执行一次核心逻辑；只清除死Boss所属敌弹，最多8个低优先级星点，保留原击破环。 |
| 9 | 轻量预警边缘 | `effects_vignette`为四条稀疏边缘点缀，每次最多4任务/1664像素；在主特效后绘制，共享预算；不增加整屏后处理，退出时由场地恢复清除。 |
| 10 | 种子与输入回放 | `replay.c/h`最多4096条8字节RLE事件，事件区32KiB，加32字节头；保存种子、配置身份、CRC、结束tick和最终权威状态哈希。错误/溢出停止，不覆盖为假成功。 |
| 11 | 整数白名单热调 | 完整一行`:set 字段 整数`，原子验证后更新；越界、未知字段、负数、溢出及不满足关系的组合均拒绝，配置保持原值；录制/回放期间禁止调参。 |

原阶段战仍为：露米娅单独出场→第一次半血1500截断→36tick预警→回满3000并爆发、两援军72tick入场→各自第一次半血狂暴。援军默认不回满；没有第四名Boss。玩家100HP、实际命中-15、300tick未受击后每60tick回5；五级分数门槛与实际火力保留。炸弹边沿排队、统一伤害入口、场内文字裁剪及同N CPU/FPGA成对结果保留。

主警告/受击/升级先于擦弹和消弹星；槽满时主效果可替换低优先级粒子。`fx_budget_accept`即使配置结构体被直接改大，仍强制最多12任务/16384像素。`effects_over_budget`是该绘制帧计数；`effects_drop_total`跨帧累计预算拒绝和效果槽溢出，只在`effects_reset`清零。STAT的`fxdrop`使用窗口增量，不用末帧`fxo=0`冒充整个窗口无丢弃。可选视觉降级与漏换帧、发弹池拒绝是不同指标。

## 2. R4的性能实现与安全门槛

### 2.1 文字路径

`src/font.c`常见正屏幕坐标、scale1～4使用32位行优先连续span；字母/数字只分类一次。负数/极大坐标、scale>4保留原参考fallback，换行x重置8、x饱和、裁剪和unsigned入口语义不变。

[`test_font_equivalence.py`](../scripts/test_font_equivalence.py)编译当前`src/font.c`，与工程内冻结参考比较：826个裁剪用例、20个unsigned入口和8个空指针/对齐用例PASS。每例完整比较4MiB，包含507904字节尾guard，另查64KiB前guard。参考、可传`--host-cc`的测试都在`tests/font_equivalence`；没有依赖R2目录。

历史RV32成本/反汇编在[`results/font_equivalence/reference`](../results/font_equivalence/reference/rv32_cost.json)：连续存储内循环为sw/addi/bltu三条指令；font text2960B，对照1604B（增加1356B），rodata386B不变。它是指令形态和代码尺寸证据，不能直接推算板端FPS。

### 2.2 四弹统一加载与安全重叠

`stage.c`的STRESS每4弹先执行12次对齐32位加载，再写回位置，减少CPU AXI写后读排空；尾部逐条处理。Shot仍是16字节，DMA材质和数量布局不变。DODGE候选收集保留原路径。该优化改变访问顺序，不改变弹丸状态结果。

仅FPGA STRESS允许重叠：先提交当前帧、冻结`batch_count`，确认完整描述符快照后，CPU准备下一tick；下一逻辑tick消费`stress_prepared`，不得重复更新或在零逻辑步时提交未来状态。PLAY/DODGE/像素验证不直接套用这个流水。

R3要求观察`READ_BYTES<4096`，可能错过很短的纹理加载窗口，退化为等DONE再计算，已作为性能失败路径拒绝。R4改为：

1. helper入口执行CMD后的`fence iorw,iorw`。
2. 首次看到新BUSY才记录`accepted_at`。
3. 从该锚点至少等待1微秒，再判断`READ_BYTES >= 4096 + 冻结数量×16`。
4. ERROR、DONE和总超时仍先处理；退出前fence保留；后续普通引擎任务和换帧仍等待完成。

RTL证明：`game_apb.sv`在接受CMD的T0置start；同一100MHz时钟的T0+1，`render_engine.sv`锁定batch输出，`sprite_batch_engine.sv`在IDLE无条件清读计数并锁存输入，该路径不等待DDR。引擎先读取4096字节纹理、再读全部N×16字节描述符并存入片上RAM，之后才读取背景；各条带只使用片上描述符。因此新BUSY后1微秒（100个基线CLINT/core tick）足以建立当前命令计数身份，但**不能替代完整快照字节门槛**。它是软件与RTL顺序证明，不是本轮板端时序/收益证明。

### 2.3 逻辑时钟、预热与遥测

60Hz逻辑改用整数有理累加`acc_us += delta_us*60`，每达到1000000单位执行一步，避免16667微秒近似累积漂移。最多追3步的上限保留；未执行的逻辑会累计ldrop/lover。两缓冲初始化/切换预热帧保留日志，预热后重新建立统计窗口，不计入稳定负载证明。

`overlap_us`单列。`render_us`是包含重叠的墙钟时间；`frame`字段是logic+render处理耗时，不是硬件累计扫描次数，不能把overlap再次相加。屏幕R采样每200ms更新，串口原始render与窗口峰值没有因此降采样。

R4增加`scan_total`和`swap_total`，使用FRAMES→SWAPS→FRAMES，前后FRAMES相等才采用这对计数。扫描事件和安全空白期换帧在RTL并非同一拍，瞬时差1不自动等于漏帧；使用连续窗口增量、UF和原始时长判定。STAT最坏54个uint32值约888字节，1024字节发送缓冲足够。

## 3. 操作、热调与回放

SW0左、SW1右、SW2上、SW3下；菜单SW2切模式、SW3开始；SW0+SW1在菜单切DEMO，在活动游戏用炸弹；长按SW2+SW3约0.6秒回菜单。真实受击/回血验收前关闭DEMO，自动驾驶与保护状态均按日志明示。

`CONTROL_R2.cmd`保留兼容文件名，控制同目录的当前固件，不编译、不下载、不写Flash。此本机入口默认COM16和D:/ELSFPGA；换电脑须按实际安装路径和串口配置，通用调用为：

```text
python scripts/control_r2.py --port <实际COM号>
```

115200串口一次只由一个程序占用；运行后按菜单编号选择正常战、同数量FPGA/CPU压力、调参及录制回放。输入/输出原始记录在`results/control_sessions/日期时间/`；关闭控制台只释放串口，板上游戏继续。

直接发送完整行时示例：

```text
:set hud_dirty_enabled 1
:set adaptive_density 1
:set homing_retarget_ticks 4
:set boss_bullets_num[1] 3
:set death_slowmo_enabled 1
:set stress_gather_enabled 1
:set stress_overlap_enabled 1
:record 1852404840
:stop
:replay
:replay status
:replay dump
```

冒号用于避免慢速人工输入与旧单键r/s冲突。成功应收到OK；错误返回ERR并保留旧配置。接收行长和回复队列有上限，不应把未收到确认当作调参成功。旧单键m回菜单，n后十进制数量及换行设容量，s换行FPGA压力，c为CPU压力，r换行正常战，g为DODGE，i切DEMO，v切自动驾驶，x/y为独立像素比较。固定压力N不等于自然战当前活动弹数。

录制会重开Normal/live，清DEMO/自动驾驶，设置指定种子。记录的是基础tick的键状态和炸弹离散事件；慢动作仍按基础tick回放。配置身份不匹配、CRC损坏、错误tick/键、事件溢出、提前结束和最终状态不匹配会明确失败。权威哈希包含玩家、Boss、弹丸及内部VM/待发/物理效果状态，不包含墙钟、渲染、UART或纯视觉粒子，不能宣称逐帧画面录像。

板内仅保存当前RAM录制，重启不保留；dump完成须等REPLAY_END。离线校验及生成JSON示例：

```text
python scripts/replay_tool.py 新采集uart.log --output replay.json --words-output replay_words.txt
python scripts/test_replay.py --host-cc <宿主GCC> --replay-json replay.json
```

这是板内回放与离线真实逻辑复验，当前没有声明提供通用UART导入任意PC录像文件的功能。种子、配置身份、输入日志与最终哈希应一起保留。

### 热参数完整白名单

以下范围按当前`game_config.c`自动整理。Boss数量、时钟、DDR地址、编译容量、资源布局均不允许热改。

| 字段 | 单值范围 |
|---|---|
| `adaptive_density` | 0～1 |
| `density_high_pct` | 1～99 |
| `density_low_pct` | 0～98 |
| `density_slow_num` | 1～16 |
| `density_slow_den` | 1～16 |
| `boss_profiles_enabled` | 0～1 |
| `homing_retarget_ticks` | 1～16 |
| `near_enabled` | 0～1 |
| `graze_feedback_enabled` | 0～1 |
| `graze_feedback_cooldown` | 1～600 |
| `low_hp_threshold` | 1～100 |
| `low_hp_pulse_ticks` | 8～600 |
| `death_slowmo_enabled` | 0～1 |
| `death_slowmo_ticks` | 1～180 |
| `death_slowmo_divisor` | 1～8 |
| `death_star_budget` | 0～8 |
| `vignette_enabled` | 0～1 |
| `hud_dirty_enabled` | 0～1 |
| `stress_gather_enabled` | 0～1 |
| `stress_overlap_enabled` | 0～1 |
| `main_fire_period` | 1～120 |
| `homing_fire_period` | 1～240 |
| `player_shot_damage` | 1～100 |
| `player_shot_life` | 1～600 |
| `player_shot_speed` | 1～24 |
| `homing_shot_speed` | 1～24 |
| `player_hit_damage` | 1～100 |
| `hit_invuln_ticks` | 0～600 |
| `regen_wait_ticks` | 0～3600 |
| `regen_period_ticks` | 1～600 |
| `regen_amount` | 1～100 |
| `effect_job_budget` | 0～12 |
| `effect_area_budget` | 0～16384 |
| `first_burst` | 0～4096 |
| `other_burst` | 0～4096 |
| `burst_rings` | 1～8 |

数组字段：`boss_fire_num/den[0..2]`、`boss_move_num/den[0..2]`、`boss_bullets_num/den[0..2]`、`boss_burst_scale_num/den[0..2]`单值1～16；实际比值须在1～4。`boss_burst_rings[0..2]`为1～8。`level_threshold[2..5]`为1～1000000且严格递增，索引0/1不接受热改。密度低阈值必须小于高阈值，慢发射分子不得超过分母。一次修改先复制校验，失败不部分写入；需要调整相关分子/分母时选择合法的操作顺序。

## 4. 本版实际离线验证

运行完成于2026-10-28T17:56:21.857333+00:00（UTC；本机日期2026-10-29），总脚本退出0。宿主GCC9.2、RISC-V GCC13.4；implementation、host_tests、rv32_build均PASS。

| 子检查 | 实际结果 | 原始日志 |
|---|---|---|
| `benchmark_acceptance` | PASS | [`benchmark_acceptance.log`](../results/validation/benchmark_acceptance.log) |
| `stability_analyzer` | PASS | [`stability_analyzer.log`](../results/validation/stability_analyzer.log) |
| `stress_pipeline` | PASS | [`stress_pipeline.log`](../results/validation/stress_pipeline.log) |
| `telemetry_counters` | PASS | [`telemetry_counters.log`](../results/validation/telemetry_counters.log) |
| `replay` | PASS | [`replay.log`](../results/validation/replay.log) |
| `runtime_cli` | PASS | [`runtime_cli.log`](../results/validation/runtime_cli.log) |
| `r2_core` | PASS | [`r2_core.log`](../results/validation/r2_core.log) |
| `font_equivalence` | PASS | [`font_equivalence.log`](../results/validation/font_equivalence.log) |
| `r2_render` | PASS | [`r2_render.log`](../results/validation/r2_render.log) |
| `phase_gameplay` | PASS | [`phase_gameplay.log`](../results/validation/phase_gameplay.log) |
| `legacy_battle` | PASS | [`legacy_battle.log`](../results/validation/legacy_battle.log) |
| `stage` | PASS | [`stage.log`](../results/validation/stage.log) |
| `dodge_controls` | PASS | [`dodge_controls.log`](../results/validation/dodge_controls.log) |
| `scene_pixels` | PASS | [`scene_pixels.log`](../results/validation/scene_pixels.log) |

机器记录为[`results/verification.json`](../results/verification.json)，各子日志保存完整输出。14组主机检查包括16项验收器、27项稳定性分析器、431项R2核心、完整回放/CLI/流水与快照门槛、遥测撕裂读重试、826+20+8字体等价、12帧HUD及四工况边缘恢复、64帧整屏参考比较、旧ECL36000帧及stage/DODGE回归。以上为真实执行结果，但宿主MMIO模型不是DDR/HDMI实物时序。

ELF SHA256：`6dc378c577119570b6b6e546129049ac309761625b7b18cbf52750b6d2fab81f`。入口`0x1000`；PT_LOAD有效加载字节147970，内存段跨度880192。完整构建依赖/指纹见`build/identity.json`。采用原720p100MHz位流SHA256：`8c294a053584c52f4bf44a6a627dbac7008fbe3df83cccf18b0b924e4bfd7269`，不要混用马里奥/合金1080p底座。

## 5. 版本结果隔离与待完成验收

| 版本/项目 | 已有证据 | 本文状态 |
|---|---|---|
| R2低N和4096固定压力 | 既有短板测约60FPS；HUD开/关有独立对照 | 历史检查点，不属于R4 |
| R2两万固定压力 | 既有短板测约20FPS | 未达到60FPS |
| R3重叠候选 | 开启重叠仍约20FPS；保守低计数门槛错过纹理窗，退化为串行 | 性能候选已拒绝，不冒称优化通过 |
| R4主机/RV32 | 本节14组主机检查与构建PASS | 已完成离线验证 |
| R4临时上板/画面/按键/短时性能 | 本文冻结时正在下载和检查 | PENDING，等待独立SESSION/目视记录 |
| R4完整三Boss+Lv5高负载60FPS | 尚无本版完整证明 | NOT_RUN/待实测，不能用固定压力替代 |
| R4持续600秒负载/DDR/HDMI稳定性 | 尚无连续有效日志 | NOT_RUN，不能由2秒均值或旧版结果推定 |
| 新Efinity综合/P&R/时序 | 软件版复用原100MHz底座 | NOT_RUN；不是声称本机缺工具 |
| Flash更新/断电自启 | 不更新Flash、不使用旧镜像 | NOT_RUN |

上板先核对新ELF与既有bit的身份、完整读回、缓存处理和新R4启动字样，再按功能/固定压力/完整玩法分别采集。USB/JTAG临时下载不自动改变Flash。实板结论由后续独立原始记录补充，保持本文件和最终补丁冻结，避免文档补丁再次过期。

## 6. 补丁与复现范围

`docs/phase_battle.diff`从原始`hdmi_rumia_ultimate.zip`的完整解压基线重新生成，覆盖新增/变更的源码、脚本、仿真/测试、根说明、docs及review_board_tools；排除build/results/运行采集、图片及二进制、未改硬件/BSP，并排除补丁自身。最终diff检查另记`results/phase_battle_diff_check.json`，原始基线保持不变。检查的是本次冻结文本及上下文，不把压缩包内旧Flash当作本版启动镜像。
