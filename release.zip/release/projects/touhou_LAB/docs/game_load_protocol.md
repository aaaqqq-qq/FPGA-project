# GAME_SIZE_1 实际游戏与受控测量协议

固件保持100MHz与原RTL；本入口不使用ADV模型或STRESS移动循环。普通战斗：菜单中设置 `:set boss_count 1..6`、`:set enemy_count 0..12`、`:set enemy_bullet_size 8/16/24/32/40/48/56`、`:limit 1..20000`，然后 `:mode 0/1/2` 按难度开局。弹幕尺寸同时改变命中半径 size/2、擦弹半径 size/2+9、候选碰撞范围与完整图案离场边界；8px保持旧行为。尺寸/数量拓扑只能在菜单更改。

## GAME_LOAD 是游戏合成负载

命令：`:gload run ID B M N SIZE FRAMES SEED`。B=1..6，M=0..12，N=1..20000，SIZE七档，FRAMES=60..36000，SEED为非零uint32。先进入菜单；LAB/ADV、录放回放、回放错误、待执行或正在执行的渲染验证均阻止启动。

实验使用默认游戏设置、最高难度、全部Boss直接进入狂暴、普通敌人直接ACTIVE、固定正弦自动移动、真实自动射击/寻敌、实际碰撞/擦弹、受击免疫倒计时、伤害、回血/升级、效果、HUD及绘制。饱和发射不能因密度自动降频，故adaptive_density=0；默认render_budget政策继续生效，完整质量变化另记录。

人工持续规则必须与结论一起披露：濒死前补满HP再执行真实伤害（keep）；普通敌人到离场时间重置活动年龄（keep）；缺弹按同一生成器补入（fill），包含无转向、24tick转向和8tick延迟；真实AI满池发射通过轮转替换旧弹（recycle）。初始填满数量在READY的initial_fill给出。它不是自然关卡持续产生该数量的证据；正常游戏的死亡、召唤、离场、清弹规则未修改。

输入、准备、生成贴图/背景、填池和两次双缓冲预热在测量窗外。READY后每次成功swap锁存实际N/B/M、逻辑tick、硬件扫描/换帧、最大扫描间隔、UF和处理时间。每60帧输出累计STAT/DETAIL；最后同frames的STAT/DETAIL先于DONE。`late`只表示logic+render超过16667us，不单独判丢帧。所有FPS必须从raw swaps/us计算。

## 回包

* `GLOAD_ACK id=... op=run status=OK kind=GAME_LOAD b=... m=... n=... size=... frames=... seed=... cfg=... deadline_us=...`
* `GLOAD_READY id=... warmup=2 prepare_us=... initial_fill=... kind=GAME_LOAD`
* `GLOAD_STAT id=... frames=... us=... swaps=... scans=... gap=... missed=... uf=... ldrop=... lover=... nmin=... nmax=... bmin=... bmax=... mmin=... mmax=... logicmax=... rendermax=... late=...`
* `GLOAD_DETAIL id=... frames=... fill=... recycle=... keep=... hits=... damage=... bhits=... mhits=... size=... seed=... cfg=... guards=... logerr=... qmin=... qmax=... lodsum=... fxdrop=... ddrop=... fault=... ticks=... runtime=... mode=... hw=... active=... paused=... invincible=0 autoplay=1 collision=scaled`
* `GLOAD_DONE id=... status=PASS/FAIL/CANCEL reason=complete/timing/load/guards/fault/state/timeout/cancel`

qmin/qmax是全窗效果质量范围(0完整，1繁忙缩小)；lodsum是缩小效果累计，fxdrop为起点差分累计，ddrop为逐帧装饰裁减累计。不是仅末帧画质。guards=0表示检查无错误；仅最终结果做窗外守卫检查，必须匹配最终DETAIL.frames。ticks是实际logic推进，runtime是调度调用次数。

PASS要求全部目标帧完成，每帧实际N/B/M都等于请求，mode=PLAY/hw=1/active=1/paused=0，扫描/换帧/帧数相等，gap=1、missed/UF/逻辑丢弃/日志错误/故障为0；真实ticks>0，与frames和round(us*60/1e6)各相差不超过1；整数fps100在5990..6010。上位机可使用更严格的FPS阈值。完整负载失败点与超时的部分样本必须分开记录。

超时clamp(frames*200000us,20s,1800s)，60帧20秒、600帧120秒、36000帧1800秒；当前帧DMA/换帧安全完成后再检查。`:gload cancel ID`使用原run ID，必须等待DONE才释放所有权；`:gload status QUERY_ID`只读返回 `running=0/1 current=run ID/0`，可在其他实验占用时查询。

结束或取消恢复测试前的完整GameConfig、尺寸贴图和背景、弹数上限、难度选择、自动移动/无敌设置，返回菜单。最多60帧只能称短测；持续5000颗合成负载通过不能写成正常游戏自然5000颗长测通过。所有主机测试均明确不是板端FPS。
