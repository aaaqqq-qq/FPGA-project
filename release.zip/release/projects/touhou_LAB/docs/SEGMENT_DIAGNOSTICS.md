# C283 bounded frame diagnostics

This candidate changes diagnostics only. It does not claim a performance gain.
Parent is the frozen C282 lifecycle firmware; hardware, clock, gameplay,
6 Boss + 12 enemies, 20000 x 8 or 5000 x 32 bullets, Alpha and color key remain
unchanged. HUD DMA remains disabled by default. All existing GLOAD pass/fail
criteria and real frame/scan/swap counters remain authoritative.

Use the existing menu command `:set tick_profile 1` to enable both the original
TICK/GL_RENDER diagnostics and the new SEG reports. `0` disables both. The
setting is outside GameConfig and does not change its hash. No new UI control
or independent segment_profile setting is required. Segments are collected
only for a ready pipeline GAME_LOAD, excluding preparation and warmup.

The normal test order is unchanged: actual ACK, prime, READY, measured frames,
STAT/DETAIL, diagnostic tail, motion/final evidence, DONE. SEG output is queued
only after the window stops; there is no per-frame diagnostic UART output.
Serial delivery after the test may take time and is outside the timing window.
No binary protocol replaces the existing ASCII protocol.

## Non-overlapping wall segments

Every measured frame has these fifteen ordered raw-CLINT-tick intervals.
Their sum equals previous swap timestamp to this swap timestamp, exactly.

| Phase | Endpoint / interpretation |
|---|---|
| interframe | Previous swap to current frame_begin; includes previous bookkeeping and input pacing |
| capture | Frame stamp, render_capture, submission and frozen actor/HUD command capture |
| snapshot | Explicit snapshot-ready wait after capture (snapshot may already be ready) |
| before_logic | Submission stamp, fallback/control preparation to existing logic_begin timestamp |
| runtime_begin | Runtime prepare/control/Boss work through asynchronous motion submission |
| cpu_hud | Frozen CPU HUD work for hud_dma=0; otherwise only branch/probe overhead |
| motion_commit | Motion poll, DMA ownership commit, remaining gameplay tail |
| dma_hud | Frozen legacy GPU HUD tail for hud_dma=1; otherwise branch/probe overhead |
| logic_end | Final live-epoch and logic timing bookkeeping |
| actor_tail | scene_layers_flush, including first R wait and subsequent actor jobs |
| frame_drain | Remaining scene_end drain and fault checks before final publication |
| frame_publish | Final scene_end publish operation |
| before_swap | Remaining render metrics, frame accounting and swap admission checks |
| swap_publish | Publication immediately before requesting swap |
| swap_wait | Swap command/acknowledgement through existing swap_epoch timestamp |

`render_us` still ends before swap. `logic_us` is nested within it and must not
be added to it. `interframe` and swap phases are outside render_us. GLOAD `us`
also includes the final after-swap accounting before its ending timestamp;
therefore the sum of SEG periods is not asserted equal to GLOAD us.

For a NO_DRAW fallback, early fallback rendering is charged to before_logic;
the later actor/frame-drain/frame-publish phases are empty boundaries. The
existing fallback counter remains visible. It must not be interpreted as the
ordinary concurrent path. Optional control/cancel branches still traverse all
fifteen boundaries, without changing their gameplay behavior.

## Nested timing and hardware counters

Four nested intervals (`r_wait`, `legacy_wait`, `publish`, `acquire`) report
calls, sum, max and last. They are already inside wall segments and MUST NOT
be added to wall durations. The wait probe surrounds a whole pending operation
wait, with no timer reads inside each polling iteration.

Seven counter phases report `legacy_cycles`, `r_cycles`, `r_read`, `r_write`,
`m_cycles`, `m_read`, `m_write`. Cycles use the unchanged 100MHz core clock;
read/write values are bytes. R cycles reuse the existing read; R read/write add
two completed-job register reads. Legacy cycles add one register read per
completed legacy job. M counters reuse the validated completion record, adding
no DMA or MMIO reads. Counters cover the complete measured window, not only its
last frame. They do not independently establish DDR bandwidth saturation.

## Event offsets and peak frame

Six one-shot events per ordinary frame record offsets relative to frame_begin:
`r_submit`, `snapshot`, `m_submit`, `m_done`, `m_commit`, `r_done`.
Submit offsets are sampled after writing the respective command. Snapshot is
sampled when the firmware's explicit snapshot-ready call returns. DONE offsets
are sampled after the CPU observes and validates completion. They are upper
bounds on hardware completion time, not additional hardware timestamps. A
late CPU observation can overstate a hardware lifetime; use hardware cycles
and observed waits to interpret it. Duplicate completion observations do not
produce additional event timer reads.

The one frame with the maximum existing frame_begin-to-render_end interval
retains its entire fifteen-part wall vector, six event offsets, validity mask,
render duration and period. This is a same-frame vector, not independently
maximal phases assembled into an impossible frame. Ties keep the earlier frame.

## Wire schema

All fields are unsigned decimal except named phases/kinds/units. All records
carry the actual GLOAD request `id` and diagnostic `epoch`.

- `SEG_PROFILE`: enabled,samples,timer_hz,read_min,read_max,overflow,order_errors,
  wall_count=15,nested_count=4,counter_count=7,event_count=6,hud_dma,core_hz=100000000.
- `SEG_PHASE`: kind=wall/nested/counter,phase,calls,sum_lo,sum_hi,max,last,units.
  Units are ticks for walls/nested, core_cycles or bytes for hardware counters.
- `SEG_EVENT`: event,calls,sum_lo,sum_hi,max,last,origin=frame_begin,units=ticks.
- `SEG_PEAK`: frame,render_lo,render_hi,period_lo,period_hi,event_mask,units=ticks.
- `SEG_PEAK_PART`: frame,phase,value_lo,value_hi,units=ticks (15 records).
- `SEG_PEAK_EVENT`: frame,event,value_lo,value_hi,valid,origin=frame_begin,units=ticks (6 records).

64-bit values are `lo + (hi << 32)`. Max/last/calls saturate at uint32 maximum
and set overflow. Sum saturates at uint64 maximum. An out-of-order boundary
sets order_errors and never masquerades as a valid partition. Ordinary complete
pipeline windows require samples=GLOAD frames, every wall calls=samples, all six
event calls=samples and peak event_mask=63. Cancel/empty windows remain partial
observations and cannot establish target FPS. Diagnostic records are not PASS
records and never override GLOAD FAIL.

## Overhead and validation scope

Disabled diagnostics make no additional timer or MMIO reads; small branch/call
overhead remains. Enabled diagnostics add boundary/event timer reads, two reads
per nested operation, fixed-size aggregate bookkeeping and the completed-job
counter reads described above. This overhead is included in measured timings.
Menu-only calibration is a lower bound for a pair of timer reads; it is not
total overhead and is never subtracted. Original tick_profile probes remain.
Memory use is fixed; no per-frame log grows, no allocation is performed.

Native tests exercise production aggregation, real firmware UART/main/scene/
motion paths, both HUD policies, 1MHz/100MHz synthetic clocks and mid-motion
cancel. Off/on world arrays and cropped playfield pixels are compared exactly
at the same pre-cleanup completion boundary. Numeric HUD timing fields naturally
change. Native fake time is not board performance evidence. Target qualification
must be repeated with diagnostics disabled after finding and optimizing the
actual bottleneck.
