# PIPE5 固件候选：一帧流水与真实状态统计

本目录是独立候选，基于冻结 FW4。BOOT 为 `GAME60_PIPELINE_5`，100MHz 基线不变；尚未对本版进行 Flash、冷启动或实板帧率验收。

## 本轮改动

- R 首先提交旧状态 S(j−1) 的敌弹批绘；原有 RQ 和 HUD 缓冲随后捕获旧状态的全部人物、效果、文字、DRAWN、参数。没有复制第二套两万颗 Shot/Effect。
- 只有真实 R_SNAP_EPOCH 与本次非零 R token 相同且 READY 后，才执行本次真实输入 u(j) 对应的控制/Boss ECL 和独立 M 提交。
- 在 R/M 运行期间，CPU 只绘制已经捕获的旧 HUD。HUD 的 RX 回调只接收和排队，不能修改世界。
- M DONE/token、publish/acquire、guard、Completion 全部校验通过后，才执行原次序的普通敌人、玩家发弹/命中、owner 清除、回血/升级/FX、GLOAD 补弹及结局。
- 必须 M 已验证完成，才能发旧 BB_CMD 人物尾部；必须 R 与 M 都完成且无 sticky FAULT，才能实际 swap。
- 显示为 S(j−1)，实时逻辑为 S(j)：增加一个显示状态的延迟，不预测未来输入。输入按原始 64 位定时器的精确有理 60Hz 截止时间消费；晚收到的数据不会倒填给旧截止时间。迟到会记录 backlog/真实 scan gap，并不能通过 60FPS 门禁。

## 接口与回退

`src/pipe5_abi.h` 是硬件组冻结的 v2 ABI，SHA256 为 `ab19cc7bffabab1eb0189c7fd62ab944ec0c9d5351d109bf30b7cdfd5a67d4f5`。完整接口在 `evidence/PIPE5_CONTRACT_V2.txt`。

R/M 使用独立 CMD/STATUS/EPOCH/完成指标，M 不修改旧渲染寄存器，因此不使 scene 的差分寄存器缓存失效。旧 cap30 OP3 仍走原来的 drain+显式缓存失效路径。纯 CPU 渲染禁用 motionHW。只有实际 cap126 且尺寸为8或32、near/gather/layer 可用时，GLOAD 才 ACK pipe=1；其他尺寸或旧平台回原串行路径。

新 R 的 NO_DRAW 不代表成功快照。硬件 hold 保留源所有权；固件以旧 COPY 还原背景并完整画完逐弹、人物、HUD，scene_end 等待所有事务、publish 后，用同一 R token 的 FALLBACK_DONE 归还 hold。READY/snapshot_epoch 仍为0。本帧不能拿此事件提前改 Shot 或发 M。8和32均有此路径，单独 scene 调用者也在 scene_end 归还。目标验收要求 fallback=0，不能靠慢回退冒充达到指标。

任何 R 晚期总线错误、M 部分 DMA/错误包/错 token/超时均 fatal；不发 swap、不 CPU 重算，也不 reset 掉未完成 AXI。

## 控制与取消

二进制输入使用128项带原始接收时间的事件队列；ASCII 使用8项、每项640字节的自有队列。世界被本帧持有时，只接收与排队。pause/menu/start/set/replay/cancel 只在 R/M 和旧 RQ 全部 drain 的安全边界应用一次。

在某帧 M 期间收到 GLOAD cancel/menu，先完成这次已开始的真实 tick 和旧帧 swap；统计该真实帧后输出 CANCEL，不能先输出 PASS。最后结果前的协议为 STAT/DETAIL → MOTION_DIAG → PIPE final → VIEW final → DONE。各队列追加前真实 pump 流控，末尾保留清理槽。

## 测量定义

原有两次准备 swap 不推进游戏。PIPE 模式额外且仅一次披露的 prime：推进真实 L1，同时呈现 S0；prime 完成 swap 为 T0。随后完整测量 F 次真实状态推进与 F 次实际呈现，不增加更多预热或重设时间边界。

- prime：live 0→1，presented 0→0，input 0→1。
- 结束：live=F+1，presented=F，呈现的 input_epoch=F。
- DETAIL.ticks 来自已呈现 FrameStamp 的 game_tick 相对 T0 差值；runtime 是实际 live runtime_tick。
- PIPE 分开报告 presented_delta、logic_committed_delta、live/presented/input epoch、真实 R/snapshot token、backlog、fallback。
- VIEW 的 N/B/M、HP、分数、等级、hit/graze、cfg、质量、背景和视觉强度都来自已呈现 stamp。alpha/key/alpha_enable/draw_n/key_rgb 来自实际 R CMD 参数的读回锁存，默认目标为224/1/1/N/16711935。opaque 是敌弹实际 alpha 旁路，不是人物 opaque_sprites。
- 帧区间使用实际 inclusive wall time。R busy 与 CPU HUD/逻辑区间有重叠，不能把各段相加当总帧时间。独立 packet/GL_RENDER 指标保留各自定义。
- 保留原真实 ±1 tick 门禁、实际 scan/swap、欠流、日志错误、满 N/B/M 和60Hz门禁。目标还要求 M submitted/completed=F，live/presented三角成立、backlog0、fallback0。

## 离线复现

PowerShell 将 TEMP/TMP 指到本工程 tmp 后执行：

```
python scripts/verify_all.py --host-cc E:/Dev-Cpp/TDM-GCC-64/bin/gcc.exe --toolchain-bin D:/ELSFPGARSIC-V/toolchain/bin --json verification_pipe5_final.json
```

新增三个组：pipe5_control、pipe5_runtime_pixels、pipe5_native_main_wire；共45组。`test_pipe5.py` 默认冻结参考根为 `E:/Ti60_builds/game60_motion_fw4_20261102`，可以用 `--baseline-root <恢复的FW4工程>` 指定；会硬核 FW4 game/battle/scene 身份。它也读取本工程 `scripts/test_tick_profile.py` 的公开/私有状态采集模板和本地 `tests/motion_hw/reference_kernel.c`。不要缺少参考源时声称可独立复现。wire 组依赖紧邻前一组生成的实际 C harness，并核全 src seal 一致，随后重编译和运行真实 firmware_main。

新增对照范围：

- 424帧、390,758,400像素完整相等，逐帧公开/私有状态及 replay hash 对 FW4 相等。8×20k和32×5k各32帧；两尺寸128颗各90帧；两尺寸自然第一Boss阶段/死亡/owner/slowmo各90帧。
- 另外4帧满目标 NO_DRAW，完整旧序回退的像素和状态相等；ACK 时断言 RQ 空、Shot仍旧字节、旧事务全闲且已经 publish。
- 8类真实 driver 错包/超时/迟发R错等注入必须退出90，CPU重算计数0；M期间收到菜单的命令保持到安全 barrier。
- 主程序原生 wire 的10例：1MHz/100MHz两种原始定时器；两个满目标；旧cap30；非目标size16 ACKpipe0；M期间取消。真实两warmup、prime、逻辑和呈现、终止包顺序均运行。

以上 C 模型证明状态、像素、接口和统计的一致性，不证明物理帧率或 RTL 周期。native 模型有效数据拷贝字节与 AXI 字节分开：计数按每个 mock DMA 请求 ceil16 的近似 beat 规则，明确不是实际 RTL 访问轨迹。旧 v2 日志的32档未整16字节计数已被上位机诚实拒绝，原日志保存在 `results/pipe5/pre_beat_model_v2/`；修正日志另名 `wire_v3_*`，不得把旧记录当最终通过证据。

硬件 P&R/STA、组合平台审签、完整固化、整片读回、冷启动与物理 FPS 由根流程另行完成。本候选只交付源、宿主证据和真实 RV32 ELF。
