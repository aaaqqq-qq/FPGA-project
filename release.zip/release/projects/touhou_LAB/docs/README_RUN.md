# README_RUN — 构建、测试、预览与操作

本工程是 Ti60F225I3-V4（Ti60F225/I3）+ 100MHz RV32 裸机 HDMI 弹幕工程。
本版本只做“固定三名Boss阶段战 + 玩家成长”，没有第四名Boss，没有改游戏名。

> 先读：`docs/CHANGES.md`（逐文件改动与设计选择）、`docs/CONFIG.md`（全部参数）、
> `docs/VERIFICATION.md`（实际跑过什么、未跑什么）、`docs/FREQUENCY_STUDY.md`
> （100MHz基线与提频条件）。

## 1. 目录

```
src/               固件源码（新增 game_config/player/battle/effects）
assets/source/     原东方素材（未改）
assets/generated/  新增效果图/alpha/manifest（可重复生成）
scripts/           构建、测试、预览、板级采集脚本
sim/               RTL仿真 + PC宿主渲染模型
tests/             生产代码宿主测试
hw/                原RTL/约束/bit（100MHz基线；本次未改）
sw/                BSP/驱动
results/           历史证据、测试JSON、PC预览
docs/              交付文档
build/             本次实际构建产物（rumia.elf/map/identity）
```

## 2. 依赖

- Python 3.10+；`scripts/prepare_stage.py`/预览需要 Pillow。
- 宿主C编译器：MinGW-w64 gcc、Linux gcc、或 `zig cc` 均可。测试用
  `--host-cc` 指定（可包含空格，如 `--host-cc "zig cc"`）。
- RISC-V工具链：本会话实际使用
  `D:\FPGA\tools\xpack-riscv-none-elf-gcc-13.4.0-1\bin`
  （xPack GNU RISC-V Embedded GCC 13.4.0，`riscv-none-elf-` 前缀）。
  其它安装用 `--toolchain-bin`/`--prefix` 指定。
- 实板/Efinity：本会话没有，相关项NOT_RUN。

## 3. 构建RV32固件

```bat
python scripts\build_firmware.py ^
  --toolchain-bin D:\FPGA\tools\xpack-riscv-none-elf-gcc-13.4.0-1\bin
```

成功输出：

```
RV32_BUILD=PASS elf=...\build\rumia.elf sha256=...
```

产物：`build/rumia.elf`、`build/rumia.map`、`build/identity.json`、
`build/compile.log`。当前实测：RAM 720,886B / 1020KiB（69.02%），
text 39,044B，data 87,526B，bss 594,316B。

无工具链时会明确输出：

```
RV32_BUILD=NOT_RUN reason=riscv-gcc-not-found ...
```

加 `--allow-missing` 返回0（供总验证记录NOT_RUN）；直接构建返回2。

## 4. 主机测试（不需要硬件）

```bat
python scripts\test_phase_gameplay.py --host-cc gcc
python scripts\test_original_battle.py --host-cc gcc
python scripts\test_stage.py --host-cc gcc
python scripts\test_dodge.py --host-cc gcc
python scripts\test_scene.py --host-cc gcc
```

总入口（推荐）：

```bat
python scripts\verify_all.py ^
  --host-cc gcc ^
  --toolchain-bin D:\FPGA\tools\xpack-riscv-none-elf-gcc-13.4.0-1\bin
```

`verify_all.py`写`results/verification.json`和`results/validation/*.log`。
缺主机CC/工具链/Windows像素模型时分别NOT_RUN，不会用“全部PASS”掩盖。

T01–T12与脚本对应见`docs/TEST_PLAN.md`。测试直接编译生产
`game.c/player.c/battle.c/stage.c/effects.c/game_config.c`，只桩BSP/MMIO/
渲染入口。

## 5. PC关键帧预览

```bat
python scripts\render_preview.py --host-cc gcc
```

输出`results/preview/00_menu.png` ... `08_result_clear.png`和`manifest.json`。
这是**PC宿主模型**（真实`scene.c`/`font.c`+同步bitblt），不是实板截图。
覆盖：菜单、单Boss、狂暴预警、援军入场、三Boss、受击、回血、Lv5强化、通关。

## 6. 操作

- 菜单：SW0/SW1选择压力/DODGE容量档；SW2切换模式；SW3开始；
  菜单中SW0+SW1切换DEMO无敌。
- 游戏中：SW0左、SW1右、SW2上、SW3下；SW0+SW1炸弹；
  长按SW2+SW3约0.6秒回菜单。
- 自动射击，无需额外开火键；成长按分数自动触发。
- PLAY阶段战：三名Boss全灭通关，无200秒超时；失败/通关后SW3重开，
  长按回菜单。
- DODGE：保留200秒规则和三命；压力模式保留固定容量档。
- 串口`r/s/c/g/m/i/v/h/+/-/数字/x/y/n`等调试命令保留；
  `x`/`y`为CPU/FPGA像素校验。

## 7. 素材/图集重生成

```bat
python scripts\prepare_stage.py
```

从`assets/source`重新生成`src/stage_data.h`、`src/art_data.h`、
`src/art_ids.h`、`assets/generated/effects/*.png`、`results/extraction.json`。
已验证前70个tile的偏移/尺寸/像素和调色板与基线逐字节一致；新增tile 70..82
不得塞进54..69的8×8 DMA材质块。

## 8. 回到原版本

原始ZIP：`hdmi_rumia_ultimate.zip`，
SHA256 `2d8cb25f98acfafeea81950f96e9fa75559f261b36d3ce48f9a66e146d5b93d8`。
解压即原工程；不要用本工程的`flash/game.bin`回退（它是旧ELF的Flash镜像）。
原`START_720P_JTAG_ONLY.cmd`会调用原`scripts/download.ps1`，其中有原作者
Windows绝对路径；没有板卡/Efinity环境不要执行。

## 9. 重要边界

- 本次**没有**生成新bit、没有综合/布局布线、没有上板、没有更新Flash。
- `flash/game.bin`和`flash/game_boot_124k.bin`是旧ELF
  `d715548a...`的镜像，不能作为本版本release烧录；新ELF只在`build/`。
  本release**未附带**这些旧镜像（避免误烧）；如需查看，它们在原始ZIP
  `hdmi_rumia_ultimate.zip`的`flash/`中，说明见`flash/LEGACY_README.md`。
- 原始ZIP中`reference/`下的历史检查点归档（旧版本快照zip，约78MB）同样
  未随本release附带；它们与本次改动无关，完整保留在原始ZIP中。
- 相对基线的统一diff补丁见`docs/phase_battle.diff`（范围与统计见文件头）；
  补丁仅供审查，不能代替本完整工程。
- 100MHz软件版本已构建；60FPS/600s/UNDERFLOW/峰值必须上板复测，主机测试
  不能替代。
- 新狂暴弹幕是改编值，不与原ECL逐帧一致；legacy回归单独保留。
