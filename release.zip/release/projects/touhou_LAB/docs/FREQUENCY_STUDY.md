# 100MHz基线、时序条件与提频研究

## 结论（先说）

本交付保持 **100MHz** 工作版本，没有改RTL、PLL、DDR参数或约束，也没有生成
新bit。提频（105/110/120/125MHz）在本会话不具备“综合/布局布线/完整setup-hold/
CDC/新bit/实板”闭环条件，因此**没有执行，也不声称已超频成功**。100MHz软件
版本、RV32构建、主机测试和PC预览是实际交付物；实板/bit/Flash项在
`VERIFICATION.md`中标NOT_RUN。

## 1. 当前时钟事实（来自工程文件）

- `hw/game/rtl/ddr3_example_top.v:52`：`core_clk`注释为100MHz；`:271`
  `user_clk = core_clk`；CPU/APB/渲染/DDR控制器同域。
- `hw/game/rtl/ddr3_controller/ddr3_parameter.vh`：
  - `tCK=2500ps`（400MHz DDR物理时钟周期）；
  - `CK_RATIO=4`；
  - `ASYN_AXI_CLK=0`（当前同步AXI，100:400=1:4）。
- `hw/game/par/ddr_demo_ti60/ddr_demo_ti60.peri.xml`：
  - `clk_25m` 25MHz参考；
  - `pll_inst1`为`PLL_TL0`，核心PLL；
  - `DDR3_PLL`为`PLL_TR0`；
  - `clk_100m`输出分频/倍频配置见peri文件；当前100MHz已接近该输出参考
    4倍关系，不能只把100改成125。
- HDMI独立74.25/371.25MHz，保持1280×720@60Hz；核心提频不会把屏幕变成
  120FPS，只增加CPU/渲染吞吐余量。

## 2. 现有实现证据（原工程，不是本次新测）

`results/timing.json`记录原100MHz布局后的关系级slack：

- `core_clk → core_clk` setup **0.701ns**；
- `core_clk → core_clk` hold **0.026ns**；
- `sdram_clk → sdram_clk` setup **0.370ns**；
- `tx_cal_clk_90edge → tx_cal_clk_90edge` setup **0.324ns**；
- 最小hold包括`rx_cal_clk` 0.034ns、`sdram_clk` 0.036ns等。

同域粗算约107.5MHz，但这是局部/关系级估计，**不能**认证整机Fmax；片上
Memory Blocks 256/256满配，布局/布线余量小。任何提频必须重新跑完整
setup/hold、CDC、DDR校准和板级长测。

关键路径之一在`sprite_batch_engine.sv`地址末端计算/范围检查；如要做，需要
分拍但保留非法命令拒绝、BUSY/DONE和DMA时序。本版本未改该RTL。

## 3. 为什么没有直接改125MHz

1. **PLL条件**：25MHz参考、当前CLKOUT0已到4×限制；更高频率要重新选择
   输出/反馈分频并用厂商PLL计算器验证，不能只改宏或peri分频。
2. **AXI/CDC**：CPU/渲染独立时钟需要完整异步桥、复位/CDC、APB和BSP配套；
   只翻`ASYN_AXI_CLK`不够。
3. **DDR整体提频**：要核颗粒/IO/控制器/校准允许范围，不能盲改tCK/CK_RATIO。
4. **工具与板卡**：本会话无Efinity完整flow/授权IP/板卡；没有新bit和实测就
   不能宣称60FPS或提频成功。
5. **软件目标优先**：任务书要求先完成100MHz可用软件版本及测试；本交付已完成
   该优先级。

## 4. 若条件具备的推荐顺序

1. 先测100MHz新阶段战：单Boss/援军/三Boss狂暴/Lv5/多效果叠加，记录
   logic/collision/list/batch/render/HUD/swap各段和实际N、Boss阶段、等级、
   MISSED/UF；不要用固定20000空场代替自然战。
2. 软件热点优化：目标查询复用/限频（追踪目标每N tick）、整数化、批量提交、
   HUD整面板/脏区、局部效果、减少重复读写；不静默删伤害提示或改玩法换FPS。
3. 必要时做`sprite_batch_engine.sv`关键路径分拍；保持非法命令拒绝/BUSY/DONE/
   DMA时序，重新跑仿真回归。
4. 时钟架构/PLL条件满足后研究105、110MHz候选；每个候选都要新综合/布局布线/
   完整setup-hold/CDC/工具输出，并同步CLINT计时、UART/超时换算、SoC生成配置、
   BSP/固件。
5. 有余量再研究120/125MHz；DDR整体提频另立路线，核颗粒/IO/校准范围。
6. 实板验证：匹配bit/ELF身份、完整装载读回、缓存/启动、玩家可见反馈、DDR/
   画面/性能长测；4096→8192→12000→16384→20000容量档逐步压测并记录实际N。

## 5. 统计单位提醒

`game.c`中`fps100=(swaps*100000000)/elapsed_us`的`100000000`是
“100×1e6 us”的百分比换算系数，**不是**核心频率，不应随100MHz改125而替换。
CLINT计时源在`SYSTEM_CLINT_HZ`/BSP中；若改核心时钟，必须同步该值和UART/超时
换算。
