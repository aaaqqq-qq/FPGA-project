"""Single fixed complete-Flash entry. No application RAM-load fallback."""
from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
import flash_device

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--game',choices=['touhou_LAB'],default='touhou_LAB');p.add_argument('--check',action='store_true');p.add_argument('--config',type=Path,default=ROOT/'tools/local_paths.json');a=p.parse_args()
    marker=json.loads((ROOT/'persistent_entry.json').read_text(encoding='utf-8'))
    if marker.get('kind')!='full_flash' or marker.get('ram_fallback_allowed') is not False or marker.get('firmware')!='LAB23':raise RuntimeError('Not the fixed LAB23 complete-Flash entry')
    if marker.get('state')!='READY':raise RuntimeError('NOT_READY: final GAME60_PIPELINE_5 image is not sealed; no device or RAM fallback is allowed')
    cfg=json.loads(a.config.read_text(encoding='utf-8-sig'))
    flash_device.EF=Path(cfg['efinity_home']).resolve();flash_device.LIBUSB=Path(cfg['libusb']).resolve();flash_device.LOCATION=cfg['usb_location'];flash_device.BRIDGE=flash_device.EF/'pgm/fli/titanium/uANONYMOUS.bit'
    for target in [flash_device.EF/'python311/bin/python.exe',flash_device.EF/'pgm/bin/efx_pgm/ftdi_program.py',flash_device.BRIDGE,flash_device.LIBUSB,ROOT/'tools/capture_uart.py',ROOT/'tools/probe_jedec.py']:
        if not target.is_file():raise RuntimeError('Required fixed-Flash tool missing: '+str(target))
    flash_device.progress('files',1);path,profile=flash_device.profile_check(ROOT/marker.get('manifest','out/manifest.json'))
    if a.check:
        flash_device.progress('files',1,'done');print('CHECK ONLY PASS: complete 8 MiB Flash image '+profile.image_sha256+'; no USB/JTAG/UART/Flash access.',flush=True);return 0
    flash_device.program(path,port=cfg['uart_port'])
    return 0
if __name__=='__main__':raise SystemExit(main())
