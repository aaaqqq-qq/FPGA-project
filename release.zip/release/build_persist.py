#!/usr/bin/env python3
"""Offline-only packer: newly verified FPGA platform + relocated software loader.

This program neither imports USB/serial/programmer libraries nor invokes a
programmer. All writes are confined to --out beneath this independent folder.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, os, re, struct, subprocess, time, zlib
from hardware_gate import validate_review, RELEASE_ID, BOOT_MARKER, CAPS, pinned, json_file

ROOT=Path(__file__).resolve().parent
ROM_FLASH=0x380000
ROM_BYTES=124*1024
APP_FLASH=0x400000
FLASH_BYTES=8*1024*1024
STAGE2=0xf00000
STACK=0xfff000

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def hexbytes(path):
    lines=Path(path).read_text(encoding='ascii').splitlines()
    if not lines or any(not re.fullmatch('[0-9a-fA-F]{2}',line) for line in lines):
        raise ValueError('Not Efinity byte-per-line HEX: '+str(path))
    return bytes(int(x,16) for x in lines)
def one_load(path):
    data=Path(path).read_bytes();h=struct.unpack_from('<16sHHIIIIIHHHHHH',data)
    if h[0][:6]!=b'\x7fELF\x01\x01' or h[2]!=243:raise ValueError('Expected RV32 ELF')
    loads=[]
    for i in range(h[10]):
        p=struct.unpack_from('<IIIIIIII',data,h[5]+i*h[9])
        if p[0]==1:
            if p[1]+p[4]>len(data):raise ValueError('Truncated ELF load segment')
            loads.append(p)
    if len(loads)!=1:raise ValueError('This pinned loader requires exactly one PT_LOAD')
    p=loads[0]
    if p[3]!=0x1000 or h[4]!=0x1000 or not 0<p[4]<=p[5]<=0x100000-0x1000:
        raise ValueError('Application entry/range incompatible with this pinned platform')
    return h[4],p[3],p[4],p[5],data[p[1]:p[1]+p[4]]
def run(cmd,log):
    p=subprocess.run([str(x) for x in cmd],cwd=ROOT,capture_output=True,text=True)
    log.append({'command':[str(x) for x in cmd],'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    if p.returncode:raise RuntimeError(p.stdout+p.stderr)
    return p.stdout

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--project-root',type=Path,required=True)
    ap.add_argument('--expect-elf-sha256',required=True)
    ap.add_argument('--expect-bit-sha256',required=True)
    ap.add_argument('--toolchain-bin',type=Path,required=True)
    ap.add_argument('--hardware-review',type=Path,required=True)
    ap.add_argument('--expect-hardware-review-sha256',required=True)
    ap.add_argument('--release-config',type=Path,required=True)
    ap.add_argument('--expect-release-config-sha256',required=True)
    ap.add_argument('--fresh-backup',type=Path,required=True,help='Verified baseline image for offline packing; live programmer must make fresh backups again')
    ap.add_argument('--expect-backup-sha256',required=True)
    ap.add_argument('--out',type=Path,default=ROOT/'out')
    a=ap.parse_args();began=time.perf_counter();out=a.out.resolve()
    if ROOT not in out.parents:raise ValueError('Output must be inside independent persistence workspace')
    request=json_file(pinned(a.release_config,a.expect_release_config_sha256))
    if (request.get('state')!='READY_TO_BUILD' or request.get('release_id')!=RELEASE_ID
        or request.get('boot_marker')!=BOOT_MARKER or request.get('required_capabilities')!=CAPS
        or request.get('final_elf_sha256')!=a.expect_elf_sha256
        or request.get('hardware_review_sha256')!=a.expect_hardware_review_sha256
        or request.get('pc_elf_ram_upload') is not False):
        raise ValueError('NOT_READY: final firmware/hardware/root-reviewed release request is incomplete')
    project=a.project_root.resolve()
    if project!=ROOT/'projects/touhou_LAB':raise ValueError('Only the frozen project inside this release bundle is accepted')
    hardware=validate_review(a.hardware_review,a.expect_hardware_review_sha256,ROOT)
    elf=project/'build/rumia.elf'
    platform=project/'hw/game/par/ddr_demo_ti60/outflow'
    bit=platform/'ddr_demo_ti60.bit';hx=platform/'ddr_demo_ti60.hex'
    if (sha(elf)!=a.expect_elf_sha256 or sha(bit)!=a.expect_bit_sha256
        or hardware['bit_sha256']!=sha(bit) or hardware['hex_sha256']!=sha(hx)):
        raise ValueError('Pinned final ELF/new hardware identity mismatch')
    identity=json.loads((project/'build/identity.json').read_text())
    if identity['elf_sha256']!=a.expect_elf_sha256:raise ValueError('ELF differs from build identity')
    for name,expected in identity['sources'].items():
        if sha(project/name.replace('\\','/'))!=expected:raise ValueError('Source identity mismatch: '+name)
    entry,address,count,memory,payload=one_load(elf);raw_platform=hexbytes(hx)
    if BOOT_MARKER.encode('ascii') not in payload:raise ValueError('Wrong final GAME60_PIPELINE_5 boot identity')
    if len(raw_platform)>ROM_FLASH:raise ValueError('Platform intersects ROM application slot')
    if APP_FLASH+count>FLASH_BYTES:raise ValueError('Payload exceeds Flash')
    out.mkdir(parents=True,exist_ok=True)
    relative=lambda p:Path(os.path.relpath(p,out)).as_posix()
    crc=zlib.crc32(payload)&0xffffffff
    cfg=(f'#pragma once\n#define APP_LOAD_ADDRESS {address}u\n#define APP_ENTRY {entry}u\n'
         f'#define APP_FILE_BYTES {count}u\n#define APP_MEMORY_BYTES {memory}u\n'
         f'#define APP_FLASH_ADDRESS {APP_FLASH}u\n#define APP_CRC32 0x{crc:08x}u\n'
         f'#define APP_ELF_SHA256 "{a.expect_elf_sha256}"\n')
    (out/'payload_config.h').write_text(cfg)
    (out/'app_payload.bin').write_bytes(payload)
    cc=a.toolchain_bin/'riscv-none-elf-gcc.exe';objcopy=a.toolchain_bin/'riscv-none-elf-objcopy.exe'
    nm=a.toolchain_bin/'riscv-none-elf-nm.exe';objdump=a.toolchain_bin/'riscv-none-elf-objdump.exe'
    flags=['-march=rv32im_zicsr_zifencei','-mabi=ilp32','-O2','-g','-std=gnu11','-ffreestanding',
           '-fno-builtin','-fno-stack-protector','-msmall-data-limit=0','-mno-relax','-fno-pic',
           '-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-fstack-usage',
           '-ffunction-sections','-fdata-sections','-nostdlib','-I'+str(out)]
    log=[];objects=[]
    for source in ['loader.c','platform_rv32.c','stage2_start.S']:
        obj=out/(Path(source).stem+'.o');objects.append(obj)
        run([cc,*flags,'-c',ROOT/source,'-o',obj],log)
    run([cc,*flags,*objects,'-Wl,--gc-sections,-T,'+str(ROOT/'stage2.ld')+',-Map,'+str(out/'stage2.map'),'-o',out/'stage2.elf'],log)
    run([objcopy,'-O','binary',out/'stage2.elf',out/'stage2.bin'],log)
    stage2=(out/'stage2.bin').read_bytes()
    if not stage2 or len(stage2)>0x10000:raise ValueError('stage2 code size out of bounds')
    # This entry is the only executable left in the ROM's historical 124KiB
    # copy destination. It relocates stage2 before app overwrites low DDR.
    asm=''' .section .text
 .globl _start
_start:
 csrci mstatus,8
 csrw mie,zero
 li sp,0x00fff000
 la t0,stage2_blob
 li t1,0x00f00000
 li t2,STAGE2_LEN
 add t2,t1,t2
1: lbu t3,0(t0)
 sb t3,0(t1)
 addi t0,t0,1
 addi t1,t1,1
 bltu t1,t2,1b
 fence iorw,iorw
 .word 0x500f
 li t3,0x00ffffc0
 lw t4,0(t3)
 fence iorw,iorw
 .word 0x500f
 fence iorw,iorw
 fence.i
 li t0,0x00f00000
 jr t0
 .balign 16
 .globl stage2_blob
stage2_blob:
 .incbin "STAGE2_FILE"
'''.replace('STAGE2_LEN',str(len(stage2))).replace('STAGE2_FILE',(out/'stage2.bin').as_posix())
    (out/'stage1.S').write_text(asm)
    run([cc,*flags,'-Wl,--gc-sections,-T,'+str(ROOT/'stage1.ld')+',-Map,'+str(out/'stage1.map'),out/'stage1.S','-o',out/'stage1.elf'],log)
    run([objcopy,'-O','binary',out/'stage1.elf',out/'stage1.bin'],log)
    stage1=(out/'stage1.bin').read_bytes()
    if len(stage1)>ROM_BYTES:raise ValueError('stage1 exceeds old ROM copy length')
    symbols=run([nm,'-n',out/'stage1.elf'],log)
    blob=int(re.search(r'^([0-9a-fA-F]+)\s+\w\s+stage2_blob$',symbols,re.M)[1],16)-0x1000
    if stage1[blob:blob+len(stage2)]!=stage2:raise ValueError('Relocation source mismatch')
    (out/'stage1_124k.bin').write_bytes(stage1+b'\xff'*(ROM_BYTES-len(stage1)))
    for name in ['stage1','stage2']:
        (out/(name+'.disasm.txt')).write_text(run([objdump,'-d',out/(name+'.elf')],log))
    backup=None
    if a.fresh_backup:
        if not a.expect_backup_sha256 or sha(a.fresh_backup)!=a.expect_backup_sha256:
            raise ValueError('Fresh backup identity mismatch')
        backup=a.fresh_backup.read_bytes()
        if len(backup)!=FLASH_BYTES:raise ValueError('Preservation snapshot must contain full8MiB')
        (out/'preservation_base.bin').write_bytes(backup)
    image=bytearray(backup if backup is not None else b'\xff'*FLASH_BYTES)
    image[:len(raw_platform)]=raw_platform
    image[ROM_FLASH:ROM_FLASH+ROM_BYTES]=(out/'stage1_124k.bin').read_bytes()
    image[APP_FLASH:APP_FLASH+count]=payload
    fresh_proof={'status':'NOT_RUN'}
    if backup is not None:
        outside=[(len(raw_platform),ROM_FLASH),(ROM_FLASH+ROM_BYTES,APP_FLASH),(APP_FLASH+count,FLASH_BYTES)]
        same=all(image[lo:hi]==backup[lo:hi] for lo,hi in outside)
        if not same:raise ValueError('Image unexpectedly changes bytes outside authorized regions')
        fresh_proof={'status':'PASS','scope':'Offline comparison to a known prior full readback, not a fresh observation of the connected board. Live GUI programming requires two new full backups.',
          'fresh_current_board_backup':False,'path':str(a.fresh_backup.resolve()),'sha256':a.expect_backup_sha256,
          'outside_authorized_ranges_identical':same,'outside_compared_bytes':sum(hi-lo for lo,hi in outside),
          'outside_ranges':outside,'outside_non_ff_bytes':sum(sum(x!=255 for x in backup[lo:hi]) for lo,hi in outside)}
    (out/'full_flash_8m.bin').write_bytes(image)
    # Efinity HEX is one decoded byte per line, not Intel HEX records.
    with (out/'full_flash_8m.hex').open('w',encoding='ascii',newline='\n') as f:
        f.writelines(f'{x:02X}\n' for x in image)
    provenance={'schema':'ti60_verified_hw_build_v1','status':'PASS',
        'review_path':relative(a.hardware_review.resolve()),
        'review_sha256':a.expect_hardware_review_sha256,
        'release_id':RELEASE_ID,'bit_sha256':hardware['bit_sha256'],
        'hex_sha256':hardware['hex_sha256'],'lbf_sha256':hardware['lbf_sha256'],
        'scope':'New same-source vendor-generated platform, full PAR/STA plus independent reproduction; not an old legacy-platform equality claim.'}
    manifest={'schema':'ti60_persistent_image_v1','created_utc':datetime.now(timezone.utc).isoformat(),
      'release':'LAB23','firmware':'LAB23','release_id':RELEASE_ID,'required_capabilities':CAPS,'boot_marker':BOOT_MARKER,
      'status':'OFFLINE_BUILT_NOT_BOARD_TESTED','board':'Ti60F225I3-V4','clock_mhz':100,'flash_size':FLASH_BYTES,
      'elf':{'path':relative(elf),'sha256':sha(elf),'entry':entry,'load_address':address,'file_bytes':count,'memory_bytes':memory,'crc32':f'{crc:08x}'},
      'platform':{'bit_path':relative(bit),'bit_sha256':sha(bit),'hex_path':relative(hx),'hex_sha256':sha(hx),'flash_offset':0,'decoded_bytes':len(raw_platform),'decoded_sha256':hashlib.sha256(raw_platform).hexdigest(),
                  'source':'New same-invocation PAR/vendor active HEX, bound to frozen inputs, exact LBF, complete timing and independently reproduced configurations. Not converted from passive bit.'},
      'stage1':{'path':'stage1_124k.bin','sha256':sha(out/'stage1_124k.bin'),'flash_offset':ROM_FLASH,'copy_bytes':ROM_BYTES,'unpadded_bytes':len(stage1),'entry':0x1000,'stage2_embedded_offset':blob},
      'stage2':{'bin_path':'stage2.bin','bin_bytes':len(stage2),'bin_sha256':sha(out/'stage2.bin'),'elf_path':'stage2.elf','elf_sha256':sha(out/'stage2.elf'),'run_address':STAGE2,'stack_pointer':STACK},
      'payload':{'path':'app_payload.bin','sha256':sha(out/'app_payload.bin'),'flash_offset':APP_FLASH,'bytes':count},
      'image':{'bin_path':'full_flash_8m.bin','bin_sha256':sha(out/'full_flash_8m.bin'),'hex_path':'full_flash_8m.hex','hex_sha256':sha(out/'full_flash_8m.hex'),'bytes':FLASH_BYTES},
      'platform_build_provenance':provenance,
      'preservation_source':{'path':'preservation_base.bin','sha256':sha(out/'preservation_base.bin'),'bytes':FLASH_BYTES,'fresh_current_board_backup':False},
      'release_request_sha256':a.expect_release_config_sha256,'pc_elf_ram_upload':False,'ram_fallback_allowed':False,'sources':{p.name:sha(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.suffix in ['.py','.c','.h','.S','.ld']},
      'fresh_backup_preservation':fresh_proof,
      'build_seconds':round(time.perf_counter()-began,3),'hardware_accessed':False,'flash_written':False,
      'verification':{'host_tests':'NOT_RUN','board_cold_boot':'NOT_RUN','physical_reset':'NOT_RUN'}}
    (out/'compile.json').write_text(json.dumps(log,indent=2))
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print('PERSIST_BUILD=PASS');print(json.dumps({k:manifest[k] for k in ['image','stage1','stage2','elf','build_seconds']},indent=2))

if __name__=='__main__':main()
