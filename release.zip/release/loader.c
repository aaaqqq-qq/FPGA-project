/* Independent second-stage software loader. No GPIO, clock, RTL, Flash erase
 * or Flash program operation. This code runs above application memory. */
#include "loader_platform.h"
#include "payload_config.h"

static uint32_t crc_byte(uint32_t crc,uint8_t byte){
    crc^=byte;
    for(unsigned j=0;j<8;++j)crc=(crc>>1)^(0xedb88320u&(0u-(crc&1u)));
    return crc;
}

int persist_run(void){
    uint8_t block[128];
    if(APP_LOAD_ADDRESS<0x1000u||APP_LOAD_ADDRESS>=0x100000u||!APP_FILE_BYTES||
       APP_FILE_BYTES>APP_MEMORY_BYTES||APP_MEMORY_BYTES>0x100000u-APP_LOAD_ADDRESS||
       APP_ENTRY<APP_LOAD_ADDRESS||APP_ENTRY-APP_LOAD_ADDRESS>=APP_FILE_BYTES||
       APP_FLASH_ADDRESS<0x400000u||APP_FLASH_ADDRESS>=0x800000u||APP_FILE_BYTES>0x800000u-APP_FLASH_ADDRESS){
        persist_log("FAIL PERSIST bounds\r\n");return 1;
    }
    if(persist_platform_init()) {persist_log("FAIL PERSIST init\r\n");return 2;}
    persist_log("LAB23 PERSIST STAGE2 ELF " APP_ELF_SHA256 "\r\n");
    uint32_t crc=0xffffffffu;
    for(uint32_t pos=0;pos<APP_FILE_BYTES;){
        uint32_t count=APP_FILE_BYTES-pos;if(count>sizeof(block))count=sizeof(block);
        if(persist_flash_read(APP_FLASH_ADDRESS+pos,block,count)){
            persist_log("FAIL PERSIST Flash read\r\n");return 3;
        }
        for(uint32_t j=0;j<count;++j){
            crc=crc_byte(crc,block[j]);persist_store(APP_LOAD_ADDRESS+pos+j,block[j]);
        }
        pos+=count;
    }
    if((crc^0xffffffffu)!=APP_CRC32){persist_log("FAIL PERSIST payload CRC\r\n");return 4;}
    persist_sync(APP_LOAD_ADDRESS+APP_FILE_BYTES-1);
    crc=0xffffffffu;
    for(uint32_t pos=0;pos<APP_FILE_BYTES;++pos)crc=crc_byte(crc,persist_fetch(APP_LOAD_ADDRESS+pos));
    if((crc^0xffffffffu)!=APP_CRC32){persist_log("FAIL PERSIST DDR CRC\r\n");return 5;}
    persist_log("LAB23 PERSIST Flash+DDR CRC PASS; jump 0x1000\r\n");
    persist_sync(APP_LOAD_ADDRESS+APP_FILE_BYTES-1);
    persist_jump(APP_ENTRY);return 0; /* Host test jump returns; target jump does not. */
}

