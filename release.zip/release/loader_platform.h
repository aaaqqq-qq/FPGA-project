#pragma once
#include <stdint.h>
#include <stddef.h>
int persist_platform_init(void);
int persist_flash_read(uint32_t address,uint8_t *out,uint32_t count);
void persist_store(uint32_t address,uint8_t value);
uint8_t persist_fetch(uint32_t address);
void persist_sync(uint32_t last_address);
void persist_log(const char *message);
void persist_jump(uint32_t entry);
int persist_run(void);

