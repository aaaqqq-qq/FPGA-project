"""Explicit Windows application build. Running without --build checks tools only."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
DEFAULT_RUNTIME = ROOT / "runtime"


def runtime_path() -> Path | None:
    explicit = os.environ.get("FPGA_CONTROL_RUNTIME", "").strip()
    candidates = [Path(explicit)] if explicit else []
    candidates += [ROOT / "runtime", DEFAULT_RUNTIME]
    return next((p for p in candidates if (p / "PySide6").is_dir()), None)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true", help="explicitly run PyInstaller")
    parser.add_argument("--check", action="store_true", help="dependency check only (default)")
    args = parser.parse_args()
    runtime = runtime_path()
    if runtime:
        sys.path.insert(0, str(runtime))
    modules = {name: importlib.util.find_spec(name) is not None for name in ("PySide6", "serial", "PyInstaller")}
    inputs = {name: (ROOT / name).is_file() for name in ("bootstrap.py", "main.py", "control_core.py")}
    report = {"utc": datetime.now(timezone.utc).isoformat(), "python": sys.executable,
              "runtime": str(runtime) if runtime else None, "modules": modules,
              "inputs": inputs, "hardware_accessed": False}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not args.build:
        return 0 if all(modules.values()) else 2
    if args.check:
        parser.error("--check and --build are mutually exclusive")
    if os.name != "nt":
        print("A Windows build requires Windows.", file=sys.stderr)
        return 2
    if not all(modules.values()) or not all(inputs.values()):
        print("Missing build dependency or application source; see the report above.", file=sys.stderr)
        return 2
    env = os.environ.copy()
    env.pop("PYTHONHOME", None)
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONPATH"] = os.pathsep.join(str(p) for p in (runtime, ROOT) if p)
    command = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--onefile", "--windowed",
               "--name", "Topic2Workbench", "--distpath", str(ROOT / "dist_v26"),
               "--workpath", str(ROOT / "build" / "pyinstaller"), "--specpath", str(ROOT / "build"),
               "--paths", str(ROOT), "--hidden-import", "serial.tools.list_ports",
               "--hidden-import", "serial.tools.list_ports_windows", "--exclude-module", "tkinter"]
    if runtime:
        command += ["--paths", str(runtime)]
    icon = ROOT / "assets" / "app.ico"
    if icon.is_file():
        command += ["--icon", str(icon)]
    command.append(str(ROOT / "bootstrap.py"))
    logs = ROOT / "build"
    logs.mkdir(exist_ok=True)
    report["command"] = command
    with (logs / "windows_build.log").open("w", encoding="utf-8") as log:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        code = process.wait()
    report["exit_code"] = code
    report["executable"] = str(ROOT / "dist_v26" / "Topic2Workbench.exe")
    report["executable_exists"] = Path(report["executable"]).is_file()
    (logs / "windows_build.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Build log:", logs / "windows_build.log")
    print("Application:", report["executable"])
    return code


if __name__ == "__main__":
    raise SystemExit(main())
