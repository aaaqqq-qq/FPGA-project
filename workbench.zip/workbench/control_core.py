"""Qt-independent services for Ti60 Control Center.

Importing this module never starts a process, enumerates USB or opens a port.
Programming uses only a marked full-Flash entry and an offline-verified image.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
import csv
import hashlib
import json
import os
import re
import shutil
import sys
import threading
import time
from typing import Any
from persistent_profile import load_profile as load_persistent_profile, CURRENT_ELF_SHA256, CURRENT_PLATFORM_SHA256, BOOT_MARKER
from image_protocol import IMAGE_OPS, IMAGE_ERRORS, IMAGE_NUMBERS, image_arguments, image_reply_valid


@dataclass(frozen=True)
class Profile:
    id: str
    title: str
    version: str
    subtitle: str
    project_rel: str
    kind: str
    status: str
    history_fps: str
    controls: dict[str, str]


PROFILES: dict[str, Profile] = {
    "touhou_LAB": Profile(
        "touhou_LAB", "东方 Project", "GAME60_PIPELINE_5 · 固化版", "电脑控制 · 自选图片搬运 · 透明混合与物理压力场",
        "projects/touhou_LAB", "touhou", "单一固定版本 · 场景切换不换固件", "100 MHz · 1280×720 / 60 Hz 输出",
        {"left": "向左", "right": "向右", "up": "向上", "down": "向下", "bomb": "炸弹",
         "pause": "暂停 / 继续", "start": "开始 / 重开", "restart": "重开", "menu": "返回菜单",
         "autoplay": "切换自动移动", "invincible": "切换演示无敌"}),
    "touhou_R8": Profile(
        "touhou_R8", "东方 Project", "R8 · 最新候选", "阶段战 · 玩家成长 · 轻量图层",
        "projects/touhou_R8", "touhou", "完整战斗性能待验收", "约 59.93 FPS · 三 Boss 短片段",
        {"start": "开始 / 重开", "menu": "返回菜单", "autoplay": "切换自动移动", "invincible": "切换演示无敌"}),
    "mario_HD32_R1": Profile(
        "mario_HD32_R1", "超级马里奥", "HD32-R1 · 32 关", "横版平台 · 滚屏与角色动画",
        "projects/mario_HD32_R1", "mario", "画面与基本按键已确认", "约 12.00 FPS · 历史混合状态窗口",
        {"start": "开始 / 继续", "pause": "暂停 / 继续", "left": "向左", "right": "向右", "jump": "跳跃"}),
    "metal_FRONTLINE_v31": Profile(
        "metal_FRONTLINE_v31", "合金弹头", "FRONTLINE · v3.1", "横版射击 · 多层场景与自动开火",
        "projects/metal_FRONTLINE_v31", "metal", "已启动 · 画面按键待确认", "8.5–9.1 FPS · 历史活动采样",
        {"start": "开始 / 继续", "pause": "暂停 / 继续", "left": "向左", "right": "向右", "jump": "跳跃", "bomb": "手雷"}),
    "touhou_R7p1": Profile(
        "touhou_R7p1", "东方 Project", "R7p1 · 验证基线", "固定两万精灵 · 十分钟压力记录",
        "projects/touhou_R7p1", "touhou", "固定压力 60 FPS 已验证", "固定 20k ≈ 60 FPS · 非完整战斗",
        {"start": "开始 / 重开", "menu": "返回菜单", "autoplay": "切换自动移动", "invincible": "切换演示无敌"}),
}

APPLICATION_VERSION = "2.8.9.2"
DEFAULT_BUNDLE = Path(__file__).resolve().parents[1] / "release"
LEGACY_BUNDLE = DEFAULT_BUNDLE


def app_data_dir(create: bool = False) -> Path:
    path = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData/Local")) / "Ti60ControlCenter2892HUDLite"
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def default_python() -> str:
    explicit = os.environ.get("TI60_CONTROL_PYTHON")
    choices = [explicit]
    if not getattr(sys, "frozen", False):
        choices.insert(1, sys.executable)
    choices.extend([shutil.which("python"), shutil.which("python3")])
    for value in choices:
        if value and Path(value).is_file():
            return str(Path(value).resolve())
    return ""


def discover_bundle(preferred: str | Path | None = None) -> Path | None:
    frozen = bool(getattr(sys, "frozen", False))
    here = Path(sys.executable).resolve().parent if frozen else Path(__file__).resolve().parent
    paired = [here / "TI60_GAME60_PIPELINE5_HUDLITE_20261104", here.parent / "TI60_GAME60_PIPELINE5_HUDLITE_20261104"]
    if frozen:
        paired.append(here.parent.parent / "TI60_GAME60_PIPELINE5_HUDLITE_20261104")
    candidates = [os.environ.get("TI60_BUNDLE_ROOT"), preferred, *paired, here, here.parent, DEFAULT_BUNDLE]
    # Explicit choices and a portable adjacent release win over this machine's
    # development path. A saved older LAB23 release is never a candidate.
    seen = set()
    for value in candidates:
        if not value:
            continue
        try:
            root = Path(value).expanduser().resolve()
        except (OSError, ValueError, RuntimeError):
            continue
        key = str(root).casefold()
        if key in seen:
            continue
        seen.add(key)
        if current_bundle_available(root):
            return root
    return None


def current_bundle_available(bundle: str | Path) -> bool:
    """Lightweight routing identity check, never a substitute for burn validation.

    Only the small marker and manifest are read here. Full artifact hashes,
    layout and provenance remain mandatory in load_profile before any burn.
    """
    try:
        entry = persistent_entry(bundle)
        caps = entry.get("required_capabilities")
        if (entry.get("release_id") != "GAME60_PIPELINE_5" or not isinstance(caps, dict)
                or type(caps.get("adv")) is not int or caps["adv"] != 1
                or type(caps.get("img")) is not int or caps["img"] != 1
                or type(caps.get("perf")) is not int or caps["perf"] != 1
                or type(caps.get("game_load")) is not int or caps["game_load"] != 1
                or type(caps.get("gsizes")) is not int or caps["gsizes"] != 7
                or type(caps.get("batch32")) is not int or caps["batch32"] != 1
                or type(caps.get("motion")) is not int or caps["motion"] != 1
                or type(caps.get("pref")) is not int or caps["pref"] != 1
                or type(caps.get("pipe")) is not int or caps["pipe"] != 1
                or type(caps.get("pref8")) is not int or caps["pref8"] != 1):
            return False
        manifest = entry["manifest_path"]
        if manifest.stat().st_size > 262144:
            return False
        raw = manifest.read_text(encoding="utf-8-sig")
        data = json.loads(raw)
        declared = data.get("required_capabilities") if isinstance(data, dict) else None
        return bool(isinstance(data, dict) and data.get("release_id") == "GAME60_PIPELINE_5"
                    and data.get("firmware") == "LAB23" and data.get("clock_mhz") == 100
                    and data.get("boot_marker") == BOOT_MARKER
                    and isinstance(declared, dict) and type(declared.get("adv")) is int
                    and declared["adv"] == 1 and type(declared.get("img")) is int and declared["img"] == 1
                    and type(declared.get("perf")) is int and declared["perf"] == 1
                    and type(declared.get("game_load")) is int and declared["game_load"] == 1
                    and type(declared.get("gsizes")) is int and declared["gsizes"] == 7
                    and type(declared.get("batch32")) is int and declared["batch32"] == 1
                    and type(declared.get("motion")) is int and declared["motion"] == 1
                    and type(declared.get("pref")) is int and declared["pref"] == 1
                    and type(declared.get("pipe")) is int and declared["pipe"] == 1
                    and type(declared.get("pref8")) is int and declared["pref8"] == 1 and isinstance(data.get("elf"), dict)
                    and data["elf"].get("sha256") == CURRENT_ELF_SHA256
                    and isinstance(data.get("platform"), dict)
                    and data["platform"].get("bit_sha256") == CURRENT_PLATFORM_SHA256)
    except (OSError, ValueError, TypeError, RuntimeError):
        return False



def bundle_startup_message(bundle: str | Path | None) -> str:
    """Small manifest identity for logs; never verifies artifacts or accesses a device."""
    root = Path(bundle).expanduser().resolve() if bundle else None
    declared_bit = declared_elf = "未知"
    if root is not None:
        try:
            manifest = persistent_entry(root)["manifest_path"]
            if manifest.stat().st_size <= 262144:
                data = json.loads(manifest.read_text(encoding="utf-8-sig"))
                if isinstance(data, dict):
                    for key, field in (("platform", "bit_sha256"), ("elf", "sha256")):
                        value = data.get(key, {})
                        text = value.get(field) if isinstance(value, dict) else None
                        if isinstance(text, str) and re.fullmatch(r"[0-9a-f]{64}", text):
                            if key == "platform": declared_bit = text[:12]
                            else: declared_elf = text[:12]
        except (OSError, ValueError, TypeError, RuntimeError):
            pass
    return (f"赛题二工作台 {APPLICATION_VERSION} · 工程 {root or '未找到当前匹配工程'} · "
            f"清单硬件 {declared_bit} / 当前硬件 {CURRENT_PLATFORM_SHA256[:12]} · ELF {declared_elf}")


def persistent_entry(bundle: str | Path) -> dict[str, Any]:
    """Read the explicit full-Flash marker; never infer it from a directory name."""
    root = Path(bundle).expanduser().resolve()
    try:
        values = json.loads((root / "persistent_entry.json").read_text(encoding="utf-8-sig"))
    except (ValueError, TypeError, OSError) as exc:
        raise ValueError("缺少有效的完整 Flash 烧录标志，已拒绝旧 RAM 入口") from exc
    if not isinstance(values, dict) or values.get("kind") != "full_flash":
        raise ValueError("入口不是完整 Flash 烧录，禁止回退到 RAM 加载")
    if values.get("firmware") != "LAB23":
        raise ValueError("本版只接受 LAB23 完整固化包；旧版仅可连接操作")
    if values.get("state") not in {"PREPARING", "CHECK_ONLY", "READY"} or values.get("ram_fallback_allowed") is not False:
        raise ValueError("持久入口状态无效或仍允许 RAM 回退")
    if "clock_mhz" in values and (type(values["clock_mhz"]) is not int or values["clock_mhz"] != 100):
        raise ValueError("持久入口必须保持 100 MHz")
    for key in ("profile", "profile_id", "game"):
        if key in values and values[key] != "touhou_LAB":
            raise ValueError("固化入口必须固定为 touhou_LAB")
    relative = values.get("manifest", "out/manifest.json")
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute() or ":" in relative or ".." in relative.replace("\\", "/").split("/"):
        raise ValueError("持久镜像清单必须位于当前资料包内")
    manifest = (root / relative).resolve()
    if not manifest.is_relative_to(root):
        raise ValueError("持久镜像清单超出资料包")
    if not (root / "START_MENU.py").is_file() or not (root / "tools/local_paths.json").is_file() or not (root / "projects/touhou_LAB").is_dir():
        raise FileNotFoundError("固化资料不完整，需 START_MENU.py、tools 和 projects/touhou_LAB")
    result = dict(values)
    result["manifest_path"] = manifest
    return result


def persistent_bundle_available(bundle: str | Path | None) -> bool:
    if not bundle:
        return False
    try:
        persistent_entry(bundle)
        return True
    except (ValueError, TypeError, OSError):
        return False


def persistent_program_available(bundle: str | Path | None) -> bool:
    if not bundle:
        return False
    try:
        return persistent_entry(bundle)["state"] == "READY"
    except (ValueError, TypeError, OSError):
        return False


@dataclass
class Settings:
    bundle_root: str = ""
    port: str = "COM16"
    baudrate: int = 115200
    python_executable: str = field(default_factory=default_python)
    notifications: bool = True
    efinity_home: str = "D:/ELSFPGA"
    openocd: str = "D:/ELSFPGARSIC-V/openocd/bin/openocd.exe"
    libusb: str = "D:/ELSFPGARSIC-V/openocd/bin/libusb-1.0.dll"
    usb_location: str = "1-3"
    last_profile: str = "touhou_LAB"
    load_warning: str = field(default="", repr=False)

    @classmethod
    def load(cls, path: str | Path | None = None) -> "Settings":
        destination = Path(path) if path else app_data_dir() / "settings.json"
        try:
            data = json.loads(destination.read_text(encoding="utf-8-sig"))
            if not isinstance(data, dict):
                raise ValueError("settings must be an object")
            valid = {f.name for f in fields(cls)} - {"load_warning"}
            obj = cls(**{k: v for k, v in data.items() if k in valid})
            obj.validate()
            return obj
        except FileNotFoundError:
            return cls()
        except (ValueError, TypeError, OSError) as exc:
            return cls(load_warning="设置读取失败，已使用默认值：" + str(exc))

    def validate(self) -> None:
        if not isinstance(self.port, str) or not re.fullmatch(r"COM[1-9][0-9]*", self.port, re.I):
            raise ValueError("请输入正确的 COM 端口，例如 COM16")
        if isinstance(self.baudrate, bool) or self.baudrate not in (9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600):
            raise ValueError("不支持的波特率")
        if not isinstance(self.usb_location, str) or not re.fullmatch(r"[1-9][0-9]*-[1-9][0-9]*(?:\.[1-9][0-9]*)*", self.usb_location):
            raise ValueError("USB 位置需为明确的物理路径，例如 1-3")
        for name in ("bundle_root", "python_executable", "efinity_home", "openocd", "libusb"):
            if not isinstance(getattr(self, name), str):
                raise ValueError("设置字段必须是文本：" + name)
        if not isinstance(self.notifications, bool) or self.last_profile not in PROFILES:
            raise ValueError("无效的应用设置")

    def save(self, path: str | Path | None = None) -> Path:
        self.validate()
        destination = Path(path) if path else app_data_dir(True) / "settings.json"
        destination.parent.mkdir(parents=True, exist_ok=True)
        data = asdict(self); data.pop("load_warning", None)
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(destination)
        return destination

    def write_tool_config(self, bundle: str | Path | None = None, path: str | Path | None = None) -> Path:
        """Create a private job configuration; never overwrite archived local_paths."""
        self.validate()
        root = Path(bundle or self.bundle_root)
        original = root / "tools/local_paths.json"
        data = json.loads(original.read_text(encoding="utf-8-sig"))
        data.update(efinity_home=self.efinity_home, openocd=self.openocd, libusb=self.libusb,
                    uart_port=self.port, usb_location=self.usb_location, capture_seconds=15)
        destination = Path(path) if path else app_data_dir(True) / "job_paths.json"
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return destination


def process_environment() -> dict[str, str]:
    env = os.environ.copy()
    env.pop("PYTHONHOME", None); env.pop("PYTHONPATH", None)
    env.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1")
    return env


def build_command(bundle: str | Path, profile_id: str, check: bool = True,
                  python_executable: str | Path | None = None,
                  config_path: str | Path | None = None) -> list[str]:
    if profile_id != "touhou_LAB":
        raise ValueError("本版只允许 LAB23 完整 Flash 烧录，旧版本加载入口已禁用")
    root = Path(bundle).expanduser().resolve()
    marker = persistent_entry(root)
    if not check and marker["state"] != "READY":
        raise ValueError("持久烧录入口仍在准备，仅允许离线检查，禁止写入或 RAM 回退")
    entry = root / "START_MENU.py"
    if not entry.is_file() or not (root / PROFILES[profile_id].project_rel).is_dir():
        raise FileNotFoundError("工程资料不完整，请选择 TI60_LAB23_20261101 完整烧录包")
    # This is file-only validation, including --check. It never imports a
    # programmer or touches USB, UART or JTAG; the helper must recheck before use.
    load_persistent_profile(marker["manifest_path"], reviewed=True)
    for key, target in (("entry_sha256", entry), ("manifest_sha256", marker["manifest_path"])):
        if key in marker:
            expected = marker[key]
            if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected) or hashlib.sha256(target.read_bytes()).hexdigest() != expected:
                raise ValueError("持久烧录入口或镜像清单身份不匹配：" + key)
    interpreter = str(python_executable or default_python())
    if not interpreter or not Path(interpreter).is_file():
        raise FileNotFoundError("找不到 Python，请在设置中选择 Python 解释器")
    if getattr(sys, "frozen", False) and Path(interpreter).resolve() == Path(sys.executable).resolve():
        raise ValueError("下载工具需要 Python，不能使用上位机 EXE 作为解释器")
    # A persistent package may additionally pin its reviewed launcher/helpers.
    manifest = root / "PACK_MANIFEST.json"
    if manifest.is_file():
        info = json.loads(manifest.read_text(encoding="utf-8"))
        for rel in ("START_MENU.py",):
            expected = info.get("files", {}).get(rel, {}).get("sha256")
            if expected and hashlib.sha256((root / rel).read_bytes()).hexdigest() != expected:
                raise ValueError("下载入口已被修改，请先恢复校验通过的接手包：" + rel)
    command = [interpreter, "-B", "-X", "utf8", str(entry), "--game", profile_id]
    if config_path:
        config = Path(config_path).resolve()
        if not config.is_file():
            raise FileNotFoundError("找不到本次下载配置")
        command.extend(["--config", str(config)])
    if check:
        command.append("--check")
    return command


def _base_metrics(game_id: str, mode: str, raw: str) -> dict[str, Any]:
    return dict(game_id=game_id, mode=mode, fps=None, underflows=None, missed=None,
                frame_us=None, logic_us=None, render_us=None, sprites=None, raw=raw)


def _key_values(text: str) -> dict[str, str] | None:
    """Reject duplicate/partial fields rather than accepting a plausible prefix."""
    result: dict[str, str] = {}
    for token in text.split():
        if "=" not in token:
            return None
        key, value = token.split("=", 1)
        if not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", key) or not value or key in result:
            return None
        result[key] = value
    return result


@dataclass(frozen=True)
class Capability:
    firmware: str = "LAB1"
    protocol: int = 2
    controls: str = "PC"
    lab: bool = True
    width: int = 1280
    height: int = 720
    refresh: int = 60


def parse_capabilities(line: str) -> dict[str, Any] | None:
    raw = line.strip()
    if not raw.startswith("CAPS "):
        return None
    values = _key_values(raw[5:])
    expected = {"proto": "2", "controls": "PC", "lab": "1", "width": "1280", "height": "720", "hz": "60"}
    if values is None or any(values.get(k) != v for k, v in expected.items()):
        return None
    if values.get("fw") not in {"LAB1", "LAB23"}:
        return None
    if values["fw"] == "LAB23" and values.get("labx") != "1":
        return None
    if any(values.get(k,'0') not in {'0','1'} for k in ('adv','img','perf','game_load','batch32','tprof','motion','pref','pipe','pref8','hud_dma','hud_dma_proof')):return None
    if values.get('hud_dma_proof')=='1' and 'hud_dma' not in values:return None
    if values.get('gsizes','0') not in {'0','7'}:return None
    result=dict(fw=values["fw"], proto=2, controls="PC", lab=1,
                labx=int(values.get("labx") == "1" and values["fw"] == "LAB23"),
                adv=int(values.get('adv')=='1' and values['fw']=='LAB23'),
                img=int(values.get('img')=='1' and values['fw']=='LAB23'),
                perf=int(values.get('perf')=='1' and values['fw']=='LAB23'),
                game_load=int(values.get('game_load')=='1' and values.get('gsizes')=='7' and values['fw']=='LAB23'),
                gsizes=int(values.get('gsizes','0')),
                batch32=int(values.get('batch32','0')),
                tprof=int(values.get('tprof','0')),
                motion=int(values.get('motion','0')),pref=int(values.get('pref','0')),
                pipe=int(values.get('pipe','0')),pref8=int(values.get('pref8','0')),
                width=1280, height=720, hz=60, raw=raw)
    for name in ('hud_dma','hud_dma_proof'):
        if name in values:result[name]=int(values[name])
    return result


def hello_command() -> bytes:
    return b":hello\n"


def _integer(value: Any, minimum: int, maximum: int, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
        raise ValueError(label)
    return value


def mode_command(choice: int) -> bytes:
    return (":mode %d\n" % _integer(choice, 0, 5, "模式应为 0 至 5")).encode("ascii")


def pause_command(paused: bool | int) -> bytes:
    if paused not in (0, 1) or not isinstance(paused, (int, bool)):
        raise ValueError("暂停状态应为 0 或 1")
    return (":pause %d\n" % int(paused)).encode("ascii")


def limit_command(count: int) -> bytes:
    return (":limit %d\n" % _integer(count, 1, 20000, "弹幕上限应为 1 至 20000")).encode("ascii")


def toggle_command(name: str, enabled: bool | int) -> bytes:
    if name not in {"autoplay", "invincible", "backend"}:
        raise ValueError("未知状态命令")
    if enabled not in (0, 1) or not isinstance(enabled, (int, bool)):
        raise ValueError("状态应为 0 或 1")
    return (":%s %d\n" % (name, int(enabled))).encode("ascii")


def config_command(name: str, value: int) -> bytes:
    if not re.fullmatch(r"[a-z][a-z0-9_]{0,47}", name):
        raise ValueError("参数名无效")
    _integer(value, 0, 2147483647, "参数应为非负整数")
    return (":set %s %d\n" % (name, value)).encode("ascii")


def replay_command(operation: str, seed: int | None = None) -> bytes:
    if operation not in {"record", "stop", "replay", "dump", "status"}:
        raise ValueError("未知回放命令")
    if seed is not None:
        if operation != "record":
            raise ValueError("只有录制可以指定随机种子")
        return (":record %d\n" % _integer(seed, 0, 0xFFFFFFFF, "随机种子无效")).encode("ascii")
    text = "replay " + operation if operation in {"dump", "status"} else operation
    return (":" + text + "\n").encode("ascii")


_LAB_OPS = {"enter", "exit", "clear", "fill", "copy", "pattern", "verify"} | IMAGE_OPS


def lab_command(request_id: int, operation: str, *args: Any) -> bytes:
    request_id = _integer(request_id, 1, 2147483647, "请求 ID 无效")
    if operation not in _LAB_OPS:
        raise ValueError("未知实验操作")
    if operation in IMAGE_OPS:
        numbers = image_arguments(operation, args)
    elif operation in {"enter", "exit", "clear", "verify"}:
        if args:
            raise ValueError("此操作不接受参数")
        numbers = []
    elif operation == "pattern":
        if len(args) != 1:
            raise ValueError("pattern 需要图案编号")
        numbers = [_integer(args[0], 0, 2, "图案编号应为 0 至 2")]
    elif operation == "fill":
        if len(args) != 5:
            raise ValueError("fill 需要 x y w h color")
        x, y, w, h, color = args
        numbers = [_integer(x, 0, 1279, "x 超出画布"), _integer(y, 0, 719, "y 超出画布"),
                   _integer(w, 1, 1280, "宽度无效"), _integer(h, 1, 720, "高度无效")]
        if x + w > 1280 or y + h > 720:
            raise ValueError("矩形超出画布")
        if isinstance(color, str) and re.fullmatch(r"0x[0-9a-fA-F]{6}", color):
            color = int(color, 16)
        numbers.append(_integer(color, 0, 0xFFFFFF, "颜色应为 RGB 24 位值"))
    else:
        if len(args) != 7:
            raise ValueError("copy 需要 tile sx sy w h dx dy")
        tile, sx, sy, w, h, dx, dy = args
        numbers = [_integer(tile, 0, 1, "素材编号应为 0 或 1"),
                   _integer(sx, 0, 63, "素材 x 超界"), _integer(sy, 0, 63, "素材 y 超界"),
                   _integer(w, 1, 64, "复制宽度无效"), _integer(h, 1, 64, "复制高度无效"),
                   _integer(dx, 0, 1279, "目标 x 超界"), _integer(dy, 0, 719, "目标 y 超界")]
        if sx + w > 64 or sy + h > 64 or dx + w > 1280 or dy + h > 720:
            raise ValueError("复制范围超出素材或画布")
    suffix = " " + " ".join(map(str, numbers)) if numbers else ""
    return (":lab %d %s%s\n" % (request_id, operation, suffix)).encode("ascii")


@dataclass(frozen=True)
class LabReply:
    kind: str
    request_id: int
    operation: str | None
    status: str
    values: dict[str, Any]


def parse_lab_reply(line: str) -> dict[str, Any] | None:
    raw = line.strip()
    head, _, tail = raw.partition(" ")
    if head not in {"LAB_ACK", "LAB_DONE", "LAB_CASE"}:
        return None
    values = _key_values(tail)
    if values is None or not re.fullmatch(r"[1-9][0-9]*", values.get("id", "")):
        return None
    request_id = int(values["id"])
    if request_id > 2147483647:
        return None
    if head != "LAB_CASE" and values.get("op") not in _LAB_OPS:
        return None
    if head == "LAB_ACK":
        if values.get("status") != "QUEUED":
            return None
    else:
        allowed = {"PASS", "FAIL"} if head == "LAB_CASE" else {"PASS", "ERROR"}
        if values.get("status") not in allowed:
            return None
        if not re.fullmatch(r"[0-9]+", values.get("errors", "")):
            return None
        if values["status"] == "PASS" and values["errors"] != "0":
            return None
        if head == "LAB_DONE":
            if not re.fullmatch(r"[0-9]+", values.get("us", "")):
                return None
            if values["status"] == "ERROR" and values.get("code") not in ({"RANGE", "BUSY", "MODE", "PARSE", "ENGINE", "VERIFY", "RESTORE"} | IMAGE_ERRORS):
                return None
            if values["status"] == "PASS" and any(values.get(k) != v for k, v in {"width": "1280", "height": "720", "refresh": "60"}.items()):
                return None
            if values["status"] == "PASS" and values.get("active") not in {"0", "1"}:
                return None
            if values.get("op") in IMAGE_OPS and not image_reply_valid(values):
                return None
        elif not re.fullmatch(r"[a-zA-Z_][a-zA-Z0-9_]*", values.get("case", "")):
            return None
        elif values["status"] == "FAIL" and values.get("code") not in {"ENGINE", "VERIFY"}:
            return None
    numeric = {"id", "errors", "us", "hw_cycles", "width", "height", "refresh", "active", "passed", "failed"} | IMAGE_NUMBERS
    result: dict[str, Any] = dict(kind=head, raw=raw)
    for key, value in values.items():
        if key in numeric:
            if not re.fullmatch(r"[0-9]+", value):
                return None
            result[key] = int(value)
        else:
            result[key] = value
    result["request_id"] = request_id
    return result


class LabRequestTracker:
    """One outstanding command; ACK is progress, never a completed test."""
    def __init__(self):
        self.pending_id: int | None = None
        self.operation: str | None = None
        self.deadline: float | None = None
        self.acknowledged = False
        self.cases: list[dict[str, Any]] = []
        self.last_result: dict[str, Any] | None = None
        self._issued_ids: set[int] = set()

    def begin(self, request_id: int, operation: str, now: float | None = None) -> None:
        _integer(request_id, 1, 2147483647, "请求 ID 无效")
        if operation not in _LAB_OPS:
            raise ValueError("未知实验操作")
        if self.pending_id is not None:
            raise RuntimeError("上一条实验请求尚未完成")
        if request_id in self._issued_ids:
            raise ValueError("请求 ID 已使用，请为新操作分配新 ID")
        self._issued_ids.add(request_id)
        self.pending_id, self.operation = request_id, operation
        self.deadline = (time.monotonic() if now is None else now) + (180 if operation in {"verify", "imgcommit", "imgcopy"} else 30)
        self.acknowledged = False
        self.cases.clear()
        self.last_result = None

    def receive(self, reply: dict[str, Any], now: float | None = None) -> bool:
        if self.expire(now) is not None or self.pending_id is None or reply.get("id") != self.pending_id:
            return False
        kind = reply.get("kind")
        if kind == "LAB_CASE":
            if self.operation != "verify":
                return False
            self.cases.append(reply.copy())
            return True
        if reply.get("op") != self.operation:
            return False
        if kind == "LAB_ACK" and reply.get("status") == "QUEUED":
            self.acknowledged = True
            return True
        if kind == "LAB_DONE" and reply.get("status") in {"PASS", "ERROR"}:
            self.last_result = reply.copy()
            self.pending_id = self.operation = self.deadline = None
            return True
        return False

    def expire(self, now: float | None = None) -> dict[str, Any] | None:
        if self.pending_id is None or (time.monotonic() if now is None else now) < self.deadline:
            return None
        result = dict(kind="LAB_TIMEOUT", id=self.pending_id, request_id=self.pending_id, op=self.operation, status="TIMEOUT")
        self.last_result = result
        self.pending_id = self.operation = self.deadline = None
        return result

    def cancel(self) -> None:
        self.pending_id = self.operation = self.deadline = None
        self.acknowledged = False
        self.cases.clear()


def parse_telemetry(line: str, profile_id: str | None = None) -> dict[str, Any] | None:
    """Parse actual firmware messages. Unavailable values remain None, never zero."""
    raw = line.strip()
    if raw.startswith("STAT "):
        if profile_id and profile_id not in ("touhou_LAB", "touhou_R8", "touhou_R7p1"):
            return None
        values = {k: int(v) for k, v in re.findall(r"\b(\w+)=(-?\d+)(?=\s|$)", raw)}
        mandatory = {"mode", "hw", "N", "fps100", "swaps", "scan", "us", "frame", "logic", "render", "missed", "uf", "vstr"}
        if not mandatory <= values.keys() or any(values[k] < 0 for k in mandatory) or values["mode"] not in range(6) or values["hw"] not in (0, 1):
            return None
        tags = _key_values(raw[5:])
        if tags is None:
            return None
        if "fw" in tags:
            if tags.get("fw") not in {"LAB1", "LAB23"} or tags.get("control") != "PC" or values.get("paused") not in (0, 1):
                return None
            actual_id = "touhou_LAB"
        else:
            actual_id = "touhou_R8" if "h_pk" in values else "touhou_R7p1"
        if profile_id and profile_id != actual_id:
            return None
        mode = {0: "菜单", 1: "战斗", 2: "固定压力", 3: "通关", 4: "结束", 5: "躲避"}.get(values["mode"], "未知状态")
        out = _base_metrics(actual_id, mode, raw)
        out.update(fps=values["fps100"] / 100, mode_id=values["mode"], backend="FPGA" if values.get("hw") else "CPU",
                   underflows=values.get("uf"), missed=values.get("missed"), frame_us=values.get("frame"),
                   logic_us=values.get("logic"), render_us=values.get("render"), sprites=values.get("N"),
                   underflow_semantics="window_delta", missed_semantics="window_delta", values=values,
                   paused=values.get("paused"), firmware=tags.get("fw"), control=tags.get("control"))
        return out
    if raw.startswith("PERF,"):
        if profile_id and profile_id != "mario_HD32_R1":
            return None
        row = next(csv.reader([raw]))
        if len(row) != 19 or row[2] != "MARIO" or row[3] not in ("GAME", "CPU", "FPGA"):
            return None
        try:
            nums = {i: int(row[i]) for i in range(1, 19) if i not in (2, 3)}
        except ValueError:
            return None
        if nums[6] <= 0 or any(v < 0 for v in nums.values()):
            return None
        mode = {"GAME": "游戏 / 菜单 / 暂停", "CPU": "CPU 基准", "FPGA": "FPGA 基准"}[row[3]]
        out = _base_metrics("mario_HD32_R1", mode, raw)
        out.update(fps=nums[7] * 1_000_000 / nums[6], mode_id=row[3], backend=row[3],
                   underflows=nums[11], missed=nums[10], sprites=nums[4] if row[3] != "GAME" else None,
                   window_us=nums[6], swaps=nums[7], peak_us=nums[9], run=nums[1],
                   underflow_semantics="window_delta", missed_semantics="window_delta",
                   values=dict(zip(("run", "game", "backend", "count", "profile", "window_us", "swaps", "display_frames", "peak_us", "missed", "underflows", "updates", "batches", "active_sum", "drawn_sum", "read_bytes", "write_bytes", "tx_dropped"), row[1:])))
        return out
    if raw.startswith("PERF schema="):
        if profile_id and profile_id != "metal_FRONTLINE_v31":
            return None
        values = {k: int(v) for k, v in re.findall(r"\b(\w+)=(-?\d+)(?=\s|$)", raw)}
        mandatory = {"schema", "backend", "build", "state", "lab", "fps_x10", "frame_us", "update_us", "render_us", "swap_us", "underflows", "late", "total", "combat_alive", "combat_shots"}
        if not mandatory <= values.keys() or any(values[k] < 0 for k in mandatory):
            return None
        if values["schema"] != 2 or values["build"] != 31 or values["backend"] != 1 or values["lab"] not in (0, 1) or values["state"] not in range(7):
            return None
        mode = "压力实验室" if values["lab"] else {0: "标题", 1: "战斗", 2: "暂停", 3: "死亡", 4: "关卡完成", 5: "结束", 6: "通关"}.get(values["state"], "未知状态")
        out = _base_metrics("metal_FRONTLINE_v31", mode, raw)
        sprites = values.get("enemies", 0) + values.get("bullets", 0) if values["lab"] else None
        out.update(fps=values["fps_x10"] / 10, mode_id=values["state"], backend="FPGA",
                   underflows=values.get("underflows"), missed=values.get("late"), frame_us=values.get("frame_us"),
                   logic_us=values.get("update_us"), render_us=values.get("render_us"), sprites=sprites,
                   underflow_semantics="cumulative", missed_semantics="measurement_epoch_cumulative", values=values)
        return out
    return None


def metal_packet(mask: int) -> bytes:
    if isinstance(mask, bool) or not isinstance(mask, int) or mask < 0 or mask & ~0x0C3F:
        raise ValueError("无效的合金按键状态")
    low, high = mask & 255, (mask >> 8) & 255
    return bytes((0xA5, 0x5A, low, high, low ^ high ^ 0xA7))


_METAL_MASKS = {"left": 1, "right": 2, "jump": 4, "bomb": 16}
_TOUHOU_MASKS = {"left": 1, "right": 2, "up": 4, "down": 8, "bomb": 16,
                  "pause": 32, "start": 64, "restart": 64, "menu": 128}


def touhou_packet(sequence: int, mask: int) -> bytes:
    _integer(sequence, 0, 255, "控制包序号无效")
    _integer(mask, 0, 255, "东方按键状态无效")
    low, high = mask & 255, (mask >> 8) & 255
    return bytes((0xA5, 0x5A, sequence, low, high, sequence ^ low ^ high ^ 0xA7))


def command_for_action(profile_id: str, action: str, pressed: bool = True) -> bytes | None:
    if profile_id not in PROFILES:
        return None
    kind = PROFILES[profile_id].kind
    if profile_id == "touhou_LAB":
        # Stateful controls require SerialLink's sequence and aggregate mask.
        # Explicit toggles are exposed via toggle_command, never guessed.
        return None
    if kind == "touhou":
        if not pressed:
            return None
        return {"start": b"r\n", "restart": b"r\n", "menu": b"m", "autoplay": b"v", "invincible": b"i"}.get(action)
    if kind == "mario":
        if not pressed:
            return None  # Firmware releases its virtual GPIO after 160ms.
        return {"start": b"s", "pause": b"s", "left": b"a", "right": b"d", "jump": b"w"}.get(action)
    if action in _METAL_MASKS:
        return metal_packet(_METAL_MASKS[action] if pressed else 0)
    if pressed:
        return {"start": b"p", "pause": b"p"}.get(action)
    return None


def stress_command(profile_id: str, count: int, hardware: bool = True) -> bytes | None:
    if isinstance(count, bool) or not isinstance(count, int) or not 1 <= count <= 20000:
        raise ValueError("精灵数量应为 1 至 20000")
    if profile_id == "touhou_LAB":
        return limit_command(count) + mode_command(3 if hardware else 4)
    if profile_id in ("touhou_R8", "touhou_R7p1"):
        return ("mn%u\n%s\n" % (count, "s" if hardware else "c")).encode("ascii")
    return None


class SerialLink:
    """Explicit, nonblocking serial ownership. UI drives read/heartbeat timers.

    LAB1 held states are composed and sequenced, refreshed every 75ms, and
    zeroed on close/focus loss. LAB1 requires a current capability handshake.
    Metal held states are refreshed every <=100ms and zeroed on close. Mario's
    firmware only supports 160ms pulses; releasing stops refresh, not the chip's
    remaining pulse. No invented release packets are sent to Mario or Touhou.
    """
    def __init__(self, baudrate: int = 115200):
        self.baudrate = baudrate
        self._serial = None
        self._lock = threading.RLock()
        self._buffer = bytearray()
        self._held: set[str] = set()
        self._profile: str | None = None
        self._last_refresh = 0.0
        self._sequence = 0
        self.capabilities: dict[str, Any] | None = None

    def accept_capabilities(self, values: dict[str, Any] | None) -> bool:
        """Call only on a fresh parsed CAPS line from this open connection."""
        with self._lock:
            expected = {"proto": 2, "controls": "PC", "lab": 1, "width": 1280, "height": 720, "hz": 60}
            if (not self.is_open or not isinstance(values, dict) or values.get("fw") not in {"LAB1", "LAB23"}
                    or any(values.get(k) != v for k, v in expected.items())
                    or values.get("fw") == "LAB23" and values.get("labx") != 1):
                self.capabilities = None
                return False
            self._held.clear()
            self._profile = "touhou_LAB"
            self._sequence = 0
            self.capabilities = values.copy()
            return True

    @property
    def is_open(self) -> bool:
        return self._serial is not None and bool(getattr(self._serial, "is_open", True))

    @property
    def port(self) -> str | None:
        return getattr(self._serial, "port", None)

    def open(self, port: str) -> None:
        if not re.fullmatch(r"COM[1-9][0-9]*", port, re.I):
            raise ValueError("请选择有效的 COM 端口")
        with self._lock:
            if self.is_open:
                raise RuntimeError("串口已连接，请先断开")
            import serial
            device = serial.Serial(port=None, baudrate=self.baudrate, timeout=0, write_timeout=.2)
            try:
                # Match the reviewed capture tool: set control-line levels
                # before opening rather than pulsing DTR/RTS on construction.
                device.dtr = False; device.rts = False; device.port = port
                device.open()
            except Exception:
                device.close()
                raise
            self._serial = device
            self._buffer.clear(); self._held.clear(); self._profile = None
            self.capabilities = None; self._sequence = 0

    def send(self, payload: bytes) -> None:
        if not isinstance(payload, bytes):
            raise TypeError("串口命令必须是 bytes")
        if not payload:
            return
        with self._lock:
            if not self.is_open:
                raise RuntimeError("尚未连接串口")
            if self._serial.write(payload) != len(payload):
                raise OSError("串口命令未完整发送")

    def read_lines(self) -> list[str]:
        with self._lock:
            if not self.is_open:
                return []
            waiting = min(int(self._serial.in_waiting), 65536)
            if waiting:
                self._buffer.extend(self._serial.read(waiting))
            lines = []
            while b"\n" in self._buffer:
                line, _, rest = self._buffer.partition(b"\n")
                self._buffer[:] = rest
                lines.append(line.rstrip(b"\r").decode("utf-8", errors="replace"))
            if len(self._buffer) > 65536:
                self._buffer.clear()
                lines.append("[上位机] 超长未换行串口数据已丢弃")
            return lines

    def set_action(self, profile_id: str, action: str, pressed: bool) -> bool:
        if profile_id not in PROFILES:
            return False
        with self._lock:
            if not self.is_open:
                raise RuntimeError("尚未连接串口")
            if self._profile and self._profile != profile_id:
                self.release_all()
            if profile_id == "touhou_LAB":
                if self.capabilities is None:
                    raise RuntimeError("尚未收到 LAB1 电脑控制能力确认，请重新连接或检查固件")
                if action not in _TOUHOU_MASKS:
                    return False
                self._profile = profile_id
                # Aliased start/restart use a single logical held state.
                action = "start" if action == "restart" else action
                before = action in self._held
                if pressed:
                    self._held.add(action)
                else:
                    self._held.discard(action)
                if before != bool(pressed):
                    self._refresh_held(force=True)
                return True
            self._profile = profile_id
            if action in ("left", "right", "jump", "bomb"):
                if action not in PROFILES[profile_id].controls:
                    return False
                if pressed:
                    self._held.add(action)
                else:
                    self._held.discard(action)
                self._refresh_held(force=True)
                return True
            command = command_for_action(profile_id, action, pressed)
            if command is None:
                return False
            self.send(command)
            return True

    def _refresh_held(self, force: bool = False) -> None:
        now = time.monotonic()
        if not force and now - self._last_refresh < .075:
            return
        self._last_refresh = now
        if not self._profile or not self.is_open:
            return
        kind = PROFILES[self._profile].kind
        if self._profile == "touhou_LAB":
            if self.capabilities is None:
                return
            mask = 0
            for action in self._held:
                mask |= _TOUHOU_MASKS[action]
            self.send(touhou_packet(self._sequence, mask))
            self._sequence = (self._sequence + 1) & 255
        elif kind == "metal":
            mask = 0
            for action in self._held:
                mask |= _METAL_MASKS[action]
            self.send(metal_packet(mask))
        elif kind == "mario" and self._held:
            # The firmware cannot hold multiple virtual keys. Keep the latest
            # supported pulse deterministic; jump has priority over movement.
            for action in ("jump", "left", "right"):
                if action in self._held:
                    self.send(command_for_action(self._profile, action) or b"")
                    break

    def heartbeat(self) -> None:
        with self._lock:
            if self._held:
                self._refresh_held()

    def release_all(self) -> None:
        with self._lock:
            self._held.clear()
            if self.is_open and self._profile:
                if self._profile == "touhou_LAB" and self.capabilities is not None:
                    self._refresh_held(force=True)
                elif PROFILES[self._profile].kind == "metal":
                    self.send(metal_packet(0))

    def close(self) -> None:
        with self._lock:
            error = None
            if self._serial is None:
                return
            try:
                self.release_all()
            except Exception as exc:
                error = exc
            finally:
                device = self._serial
                self._serial = None
                self._buffer.clear(); self._held.clear(); self._profile = None
                self.capabilities = None
                try:
                    device.close()
                except Exception as exc:
                    if error is None:
                        error = exc
            if error:
                raise error


def list_serial_ports() -> list[tuple[str, str]]:
    """Read device inventory only when requested; never opens a serial port."""
    try:
        from serial.tools import list_ports
    except ImportError:
        return []
    return [(p.device, p.description) for p in list_ports.comports()]

