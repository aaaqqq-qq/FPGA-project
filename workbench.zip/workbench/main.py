"""Native white desktop controller. Startup and UI navigation are hardware-free."""
from __future__ import annotations
import codecs
from datetime import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from PySide6.QtCore import Qt, QTimer, QProcess, QProcessEnvironment, QUrl, QEvent, QLockFile
from PySide6.QtGui import QColor, QFont, QFontDatabase, QPainter, QPen, QDesktopServices
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QFrame, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QStackedWidget, QScrollArea, QComboBox, QPlainTextEdit, QLineEdit,
    QFileDialog, QFormLayout, QCheckBox, QProgressBar, QMessageBox, QSizePolicy, QSpinBox)

from control_core import (PROFILES, Settings, SerialLink, discover_bundle, build_command,
    parse_telemetry, stress_command, app_data_dir, process_environment, parse_capabilities, bundle_startup_message,
    parse_lab_reply, hello_command, lab_command, mode_command, pause_command, limit_command,
    toggle_command, config_command, replay_command, persistent_bundle_available, persistent_program_available)
from ui_projects import PROJECT_VIEWS, project_for
from lab_panel import LabPanel
from download_progress import DownloadProgress
from download_panel import DownloadPanel
from game_actions import ActionSequence, CONFIG_FIELDS, CONFIG_BY_NAME
from labx_panel import LabXPanel
from labx_protocol import labx_command, parse_labx_reply
from adv_panel import AdvPanel
from adv_protocol import adv_command, parse_adv_reply
from game_load_panel import GameLoadPanel
from game_load_protocol import game_load_command, parse_game_load_reply, SIZES

STYLE = """QMainWindow, QWidget { background:#ffffff; color:#202123; font-family:'Microsoft YaHei UI','Segoe UI'; font-size:13px; }
QWidget#sidebar { background:#f7f7f8; border-right:1px solid #eaeaea; }
QWidget#sidebar QLabel { background:transparent; }
QLabel#brand { font-size:17px; font-weight:600; }
QLabel#section { color:#89898e; font-size:11px; }
QLabel#title { font-size:29px; font-weight:600; }
QLabel#subtitle { color:#77787d; font-size:13px; }
QLabel#muted { color:#8a8b90; }
QLabel#small { color:#818287; font-size:11px; }
QLabel#badge { background:#f4f4f5; border-radius:6px; padding:5px 9px; font-size:11px; color:#66686e; }
QLabel#notice { background:#f7f7f8; border-radius:8px; padding:13px 16px; color:#66686c; }
QPushButton { border:1px solid #e4e4e7; border-radius:8px; padding:9px 15px; background:#ffffff; }
QPushButton:hover { background:#f4f4f5; }
QPushButton:pressed { background:#e9e9eb; }
QPushButton:disabled { color:#b3b3b7; background:#fafafa; border-color:#eeeeef; }
QPushButton#primary { background:#202123; color:white; border-color:#202123; font-weight:600; }
QPushButton#primary:hover { background:#3b3c3f; }
QPushButton#primary:disabled { background:#d9d9dc; border-color:#d9d9dc; color:#f8f8f9; }
QPushButton#nav { border:0; background:transparent; text-align:left; padding:11px 13px; color:#65666a; }
QPushButton#nav:hover { background:#eeeef0; }
QPushButton#nav:checked { background:#eaeaec; color:#242529; font-weight:600; }
QPushButton#link { border:0; color:#6a6b71; padding:7px 2px; text-align:left; }
QPushButton#link:hover { color:#202123; background:transparent; }
QFrame#line { border:0; background:#ededee; max-height:1px; min-height:1px; }
QComboBox, QLineEdit, QSpinBox { border:1px solid #e1e1e5; border-radius:7px; background:#ffffff; padding:8px 10px; min-height:19px; selection-background-color:#dedee3; }
QComboBox:focus, QLineEdit:focus { border-color:#9a9ba1; }
QComboBox::drop-down { border:0; width:24px; }
QPlainTextEdit { border:1px solid #e9e9ec; border-radius:9px; background:#fafafa; padding:12px; font-family:'Cascadia Mono','Consolas'; font-size:12px; color:#55575d; }
QScrollArea { border:0; background:#ffffff; }
QScrollBar:vertical { background:transparent; width:7px; }
QScrollBar::handle:vertical { background:#dddddf; border-radius:3px; min-height:35px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }
QProgressBar { border:0; background:#efeff1; border-radius:4px; min-height:8px; max-height:8px; }
QProgressBar::chunk { background:#686a72; border-radius:4px; }
QCheckBox { spacing:9px; }
QCheckBox::indicator { width:16px; height:16px; border:1px solid #d8d8dc; border-radius:4px; background:white; }
QCheckBox::indicator:checked { background:#343539; border-color:#343539; }
QToolTip { background:#26272b; color:white; border:0; padding:7px; }
QTableWidget { border:1px solid #e9e9ed; border-radius:7px; gridline-color:#f0f0f3; selection-background-color:#eceef3; selection-color:#25262a; }
QHeaderView::section { background:#fafafb; border:0; border-bottom:1px solid #e9e9ed; padding:8px 10px; color:#72747b; }
QTabWidget::pane { border:1px solid #e8e8ed; border-radius:8px; top:-1px; }
QTabBar::tab { border:0; background:#f7f7f9; color:#75777e; padding:11px 18px; }
QTabBar::tab:selected { background:#fff; color:#25262b; border-bottom:2px solid #45464d; }
"""

def label(text, role=None, wrap=False):
    w=QLabel(text)
    if role:w.setObjectName(role)
    w.setWordWrap(wrap)
    return w

def button(text, callback=None, role=None):
    w=QPushButton(text)
    if role:w.setObjectName(role)
    if callback:w.clicked.connect(callback)
    w.setCursor(Qt.PointingHandCursor)
    return w

def line():
    w=QFrame();w.setObjectName('line');return w

class Mark(QWidget):
    def __init__(self):super().__init__();self.setFixedSize(27,27)
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);p.setPen(Qt.NoPen)
        for x,y,c in [(2,2,'#292a2d'),(15,2,'#9a9ba0'),(2,15,'#9a9ba0'),(15,15,'#292a2d')]:
            p.setBrush(QColor(c));p.drawRoundedRect(x,y,10,10,3,3)

class Metric(QWidget):
    def __init__(self,title,unit):
        super().__init__();v=QVBoxLayout(self);v.setContentsMargins(0,12,12,16);v.setSpacing(7)
        v.addWidget(label(title,'subtitle'));row=QHBoxLayout();self.value=label('—');self.value.setStyleSheet('font-size:29px; font-weight:500;');row.addWidget(self.value)
        row.addWidget(label(unit,'small'),0,Qt.AlignBottom);row.addStretch();v.addLayout(row)
    def set(self,value):self.value.setText(value)

class MainWindow(QMainWindow):
    def __init__(self,smoke=False):
        super().__init__();self.smoke=smoke;self.settings=Settings.load()
        self.bundle=discover_bundle(self.settings.bundle_root)
        if self.bundle:self.settings.bundle_root=str(self.bundle)
        self.profile_id=self.settings.last_profile if project_for(self.settings.last_profile) else PROJECT_VIEWS[0].profiles[0];self.link=None;self.job=None;self.job_check=False
        self.decoder=None;self.pending='';self.last_live=0.;self.live_family=None;self.controls=[]
        self.protocol_ready=False;self.input_sources={};self.board_paused=False;self.job_persistent_ready=False
        self._hud_policy_expected=None;self._hud_policy_deadline=0.
        self.download_progress=DownloadProgress()
        self.game_sequence=ActionSequence(self.sequence_send,self.sequence_menu,self.sequence_done)
        self.gload=GameLoadPanel()
        self.preset_buttons=[];self.demo_controls=[]
        self.session_lines=[];self.status_message='准备就绪';self.settings_fields={}
        self.log_path=app_data_dir(True)/'sessions'/('session_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.log');self.log_path.parent.mkdir(exist_ok=True)
        self.setWindowTitle('赛题二工作台 2.8.9.2 · 东方工作台');self.setMinimumSize(980,650)
        screen=QApplication.primaryScreen().availableGeometry();self.resize(min(1210,screen.width()-40),min(820,screen.height()-48))
        root=QWidget();self.setCentralWidget(root);layout=QHBoxLayout(root);layout.setContentsMargins(0,0,0,0);layout.setSpacing(0)
        self.sidebar=self.build_sidebar();layout.addWidget(self.sidebar)
        main=QWidget();mv=QVBoxLayout(main);mv.setContentsMargins(36,25,36,16);mv.setSpacing(20)
        head=QHBoxLayout();self.breadcrumb=label('项目 / 东方 Project','subtitle');head.addWidget(self.breadcrumb);head.addStretch()
        self.connection=label('●  未连接','small');head.addWidget(self.connection)
        self.connect_button=button('连接串口',self.toggle_connection);self.connect_button.setObjectName('connectButton');head.addWidget(self.connect_button);mv.addLayout(head)
        self.download_panel=DownloadPanel();self.download_panel.hide();mv.addWidget(self.download_panel)
        self.job_progress=self.download_panel.bar;self.job_label=self.download_panel.detail
        self.stack=QStackedWidget();self.stack.addWidget(self.build_home());self.stack.addWidget(self.build_logs());self.stack.addWidget(self.build_settings());self.stack.addWidget(self.build_help())
        self.lab=LabPanel();self.lab.setMinimumHeight(710);self.lab.command_requested.connect(self.lab_send);self.lab.export_requested.connect(self.export_log);self.lab.state_changed.connect(self.lab_state_changed)
        lab_scroll=QScrollArea();lab_scroll.setWidgetResizable(True);lab_scroll.setWidget(self.lab);self.stack.addWidget(lab_scroll);mv.addWidget(self.stack,1)
        self.stack.addWidget(self.build_demo())
        self.labx=LabXPanel();self.labx.command_requested.connect(self.labx_send);self.labx.export_requested.connect(self.export_labx);self.labx.state_changed.connect(self.lab_state_changed);self.labx.legacy_detected.connect(self.legacy_lab_detected)
        labx_scroll=QScrollArea();labx_scroll.setWidgetResizable(True);labx_scroll.setWidget(self.labx);self.stack.addWidget(labx_scroll)
        self.adv=AdvPanel();self.adv.set_bundle(self.bundle);self.adv.command_requested.connect(self.adv_send);self.adv.export_requested.connect(self.export_adv);self.adv.state_changed.connect(self.lab_state_changed)
        adv_scroll=QScrollArea();adv_scroll.setWidgetResizable(True);adv_scroll.setWidget(self.adv);self.stack.addWidget(adv_scroll)
        self.gload.command_requested.connect(self.gload_send);self.gload.menu_requested.connect(self.gload_menu);self.gload.state_changed.connect(self.lab_state_changed);self.gload.export_requested.connect(self.export_gload)
        footer=QHBoxLayout();self.footer=label('Ti60F225I3-V4  ·  等待你的操作','small');footer.addWidget(self.footer);footer.addStretch();footer.addWidget(label('赛题二工作台  2.8.9.2 · HUD 精简版 · 工程容差','small'));mv.addLayout(footer);layout.addWidget(main,1)
        self.timer=QTimer(self);self.timer.timeout.connect(self.poll_serial);self.timer.start(20)
        QApplication.instance().applicationStateChanged.connect(self.app_state_changed)
        QApplication.instance().installEventFilter(self)
        self.select_profile(self.profile_id,initial=True)
        self.add_log('应用','工作台已就绪。固定 LAB23 完整烧录与串口连接均由你手动开始。')
        self.add_log('工程身份',bundle_startup_message(self.bundle))
        if self.settings.load_warning:self.add_log('设置',self.settings.load_warning)

    def build_sidebar(self):
        side=QWidget();side.setObjectName('sidebar');side.setFixedWidth(216);v=QVBoxLayout(side);v.setContentsMargins(16,24,16,18);v.setSpacing(5)
        brand=QHBoxLayout();brand.addWidget(Mark());brand.addSpacing(5);brand.addWidget(label('赛题二工作台','brand'));brand.addStretch();v.addLayout(brand);v.addSpacing(31);v.addWidget(label('  游戏项目','section'));v.addSpacing(6)
        self.game_nav={}
        for view in PROJECT_VIEWS:
            key,title=view.profiles[0],view.title
            b=button(title,lambda checked=False,k=key:self.select_profile(k),'nav');b.setCheckable(True);b.setObjectName('nav');self.game_nav[key]=b;v.addWidget(b)
        v.addSpacing(27);v.addWidget(label('  工作空间','section'));v.addSpacing(6);self.page_nav={}
        for i,text in [(5,'演示与调参'),(4,'基础一 · 图形实验'),(6,'基础二 · 数据搬运'),(7,'基础三 · 绘制与双缓冲'),(8,'高阶一 · 透明度混合'),(9,'高阶二 · 颜色键去背'),(1,'运行日志'),(2,'连接设置'),(3,'使用说明')]:
            b=button(text,lambda checked=False,n=i:self.navigate(n),'nav');b.setCheckable(True);self.page_nav[i]=b;v.addWidget(b)
        v.addStretch();v.addWidget(label('  EFINIX · Ti60','small'));v.addSpacing(4);v.addWidget(label('  本地设备工作台','small'))
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setFixedWidth(216);scroll.setWidget(side);return scroll

    def build_home(self):
        scroll=QScrollArea();scroll.setWidgetResizable(True);body=QWidget();v=QVBoxLayout(body);v.setContentsMargins(0,4,0,16);v.setSpacing(18)
        v.addWidget(label('让演示更从容','small'));self.title=label('东方 Project','title');v.addWidget(self.title)
        self.subtitle=label('阶段战 · 玩家成长 · 轻量图层','subtitle',True);v.addWidget(self.subtitle)
        version_row=QHBoxLayout();self.version=QComboBox();self.version.setMinimumWidth(208);self.version.currentIndexChanged.connect(self.version_changed);version_row.addWidget(self.version);self.version_badge=label('','badge');version_row.addWidget(self.version_badge);version_row.addStretch();v.addLayout(version_row)
        actions=QHBoxLayout();self.download_button=button('完整烧录到 Flash',lambda:self.run_job(False),'primary');self.download_button.setObjectName('primary');self.download_button.setMinimumHeight(40)
        self.check_button=button('离线检查',lambda:self.run_job(True));self.check_button.setMinimumHeight(40);actions.addWidget(self.download_button);actions.addWidget(self.check_button);actions.addStretch();actions.addWidget(button('打开工程 ↗',self.open_project,'link'));v.addLayout(actions)
        v.addWidget(label('覆盖开机版本 · 保留本次 Flash 备份 · 场景切换不换固件','small',True))
        self.flash_status=label('Flash 固化状态未核验 · 断电启动待确认','notice',True);v.addWidget(self.flash_status);v.addSpacing(7);v.addWidget(line())
        heading=QHBoxLayout();heading.addWidget(label('运行状态'));heading.addStretch();self.mode_label=label('连接后显示实时数据','small');heading.addWidget(self.mode_label);v.addLayout(heading)
        metrics=QHBoxLayout();self.fps=Metric('实际帧率','FPS');self.draw=Metric('绘图耗时','ms');self.underflow=Metric('显示欠流','次');metrics.addWidget(self.fps);metrics.addWidget(self.draw);metrics.addWidget(self.underflow);v.addLayout(metrics);v.addWidget(line())
        ch=QHBoxLayout();ch.addWidget(label('运行控制'));ch.addStretch();self.control_hint=label('','small');ch.addWidget(self.control_hint);v.addLayout(ch)
        self.control_host=QWidget();self.control_layout=QHBoxLayout(self.control_host);self.control_layout.setContentsMargins(0,0,0,0);self.control_layout.setSpacing(9);v.addWidget(self.control_host)
        v.addWidget(label('WASD / 方向键移动 · J 炸弹 · 空格暂停 · Enter 开始 / 重开 · Esc 菜单','small',True))
        modes=QHBoxLayout();self.mode_choice=QComboBox()
        for i,text in enumerate(['普通阶段战','困难阶段战','极难阶段战','FPGA 固定压力','CPU 固定压力','200 秒躲避挑战']):self.mode_choice.addItem(text,i)
        modes.addWidget(self.mode_choice);self.mode_button=button('开始所选模式',self.start_mode);modes.addWidget(self.mode_button);modes.addStretch();v.addLayout(modes)
        presets=QHBoxLayout()
        for text,bosses,mobs in [('四 Boss ＋ 六妖精',4,6),('六 Boss ＋ 十二妖精',6,12),('三 Boss 基线',3,0)]:
            b=button(text,lambda checked=False,n=bosses,m=mobs:self.start_preset(n,m));self.preset_buttons.append(b);presets.addWidget(b)
        presets.addStretch();v.addLayout(presets)
        pressure=QHBoxLayout();pressure.addWidget(label('绘制压力','small'));self.pressure_count=QComboBox()
        for n in [64,256,1024,4096,8192,20000]:self.pressure_count.addItem(str(n)+' 精灵',n)
        self.pressure_count.setCurrentIndex(5);pressure.addWidget(self.pressure_count)
        self.pressure_backend=QComboBox();self.pressure_backend.addItem('FPGA 加速',True);self.pressure_backend.addItem('CPU 对照',False);pressure.addWidget(self.pressure_backend)
        self.pressure_button=button('运行测试',self.start_pressure);pressure.addWidget(self.pressure_button);pressure.addStretch();v.addLayout(pressure)
        self.board_hint=label('','notice',True);v.addWidget(self.board_hint)
        self.extra_button=button('全部演示选项：无敌、调参、录制与回放 →',lambda:self.navigate(5),'link');v.addWidget(self.extra_button)
        tail=QHBoxLayout();self.evidence_label=label('','small',True);tail.addWidget(self.evidence_label,1);tail.addWidget(button('查看测试记录 ↗',self.open_evidence,'link'));v.addLayout(tail);v.addStretch(1)
        scroll.setWidget(body);return scroll

    def build_logs(self):
        w=QWidget();v=QVBoxLayout(w);v.setContentsMargins(0,4,0,0);v.setSpacing(16);v.addWidget(label('运行日志','title'))
        v.addWidget(label('完整烧录进度、连接信息和板端输出，按时间保存在本机。','subtitle',True))
        row=QHBoxLayout();row.addWidget(button('导出日志',self.export_log));row.addWidget(button('打开日志文件夹 ↗',lambda:self.open_path(self.log_path.parent),'link'));row.addStretch();self.autoscroll=QCheckBox('跟随最新');self.autoscroll.setChecked(True);row.addWidget(self.autoscroll);v.addLayout(row)
        self.log_view=QPlainTextEdit();self.log_view.setReadOnly(True);self.log_view.setMaximumBlockCount(4000);v.addWidget(self.log_view,1);return w

    def build_demo(self):
        scroll=QScrollArea();scroll.setWidgetResizable(True);body=QWidget();v=QVBoxLayout(body);v.setContentsMargins(0,4,0,18);v.setSpacing(17)
        v.addWidget(label('演示与调参','title'));v.addWidget(label('把原串口菜单中的操作集中在这里。连接 LAB1 / LAB23 后，按钮即可使用。','subtitle',True))
        row=QHBoxLayout();row.addWidget(label('1  正常战'));self.demo_difficulty=QComboBox()
        for i,text in enumerate(['普通阶段战','困难阶段战','极难阶段战']):self.demo_difficulty.addItem(text,i)
        row.addWidget(self.demo_difficulty);b=button('按当前参数重新开局',lambda:self.control_send(mode_command(self.demo_difficulty.currentData())),'primary');row.addWidget(b);self.demo_controls.extend([b,self.demo_difficulty]);row.addStretch();v.addLayout(row)
        v.addWidget(label('保留已应用的妖精数量和其他参数。角色仍按原有战斗阶段进场。','small',True))
        row=QHBoxLayout();self.game_size=QComboBox()
        for n in SIZES:self.game_size.addItem(f'{n} × {n}',n)
        self.game_count=QSpinBox();self.game_count.setRange(1,20000);self.game_count.setValue(5000)
        self.game_bosses=QSpinBox();self.game_bosses.setRange(1,6);self.game_bosses.setValue(3)
        self.game_enemies=QSpinBox();self.game_enemies.setRange(0,12);self.game_enemies.setValue(6)
        for name,w in [('敌弹尺寸',self.game_size),('敌弹上限',self.game_count),('Boss',self.game_bosses),('普通敌人',self.game_enemies)]:row.addWidget(label(name,'small'));row.addWidget(w)
        v.addLayout(row);row=QHBoxLayout();self.game_apply=button('应用并开始战斗',self.start_custom_battle,'primary');row.addWidget(self.game_apply);self.game_confirmed=label('参数待板端确认 · 需要新版本固件','small',True);row.addWidget(self.game_confirmed,1);v.addLayout(row)
        v.addWidget(label('自然战斗按原有阶段进场；上限5000不代表始终存在5000颗敌弹。只调整敌弹尺寸，角色与玩家子弹保持原样。','small',True))
        presets=QHBoxLayout()
        for text,bosses,mobs in [('11  四 Boss ＋ 六妖精',4,6),('12  六 Boss ＋ 十二妖精',6,12),('13  三 Boss 基线',3,0)]:
            b=button(text,lambda checked=False,n=bosses,m=mobs:self.start_preset(n,m,self.demo_difficulty.currentData()));self.preset_buttons.append(b);presets.addWidget(b)
        v.addLayout(presets);v.addWidget(label('预设会先回菜单，只修改 Boss / 妖精数量，再开局；“三 Boss 基线”设为 3 Boss、0 妖精。','small',True));v.addWidget(line())
        row=QHBoxLayout();row.addWidget(label('2 / 3  同数量绘制对比'));self.demo_count=QSpinBox();self.demo_count.setRange(1,20000);self.demo_count.setValue(64);self.demo_count.setSuffix(' 精灵');row.addWidget(self.demo_count)
        for text,hw in [('FPGA 压力',True),('CPU 对照',False)]:
            b=button(text,lambda checked=False,h=hw:self.run_pressure(self.demo_count.value(),h));self.demo_controls.append(b);row.addWidget(b)
        self.demo_controls.append(self.demo_count);row.addStretch();v.addLayout(row);v.addWidget(label('CPU 与 FPGA 选择相同数量再比较。CPU 先用 64 个，数量过大会等待较久。','small',True));v.addWidget(line())
        for title,name,attribute in [('4  演示无敌','invincible','god_check'),('自动移动','autoplay','auto_check'),('当前绘制器','backend','cpu_check')]:
            row=QHBoxLayout();row.addWidget(label(title));status=label('状态待板端确认','small');setattr(self,attribute,status);row.addWidget(status);row.addStretch()
            choices=[('FPGA',1),('CPU',0)] if name=='backend' else [('开启',1),('关闭',0)]
            for text,value in choices:
                b=button(text,lambda checked=False,n=name,value=value:self.control_send(toggle_command(n,value)));self.demo_controls.append(b);row.addWidget(b)
            v.addLayout(row)
        v.addWidget(label('无敌适合展示画面；演示受击扣血和回血时请关闭。状态以板端回执为准。','small',True));v.addWidget(line())
        v.addWidget(label('5  调整游戏参数'));cfg=QHBoxLayout();self.cfg_field=QComboBox();self.cfg_field.setEditable(True);self.cfg_field.setMinimumWidth(320)
        for spec in CONFIG_FIELDS:
            if spec.writable:self.cfg_field.addItem(spec.label+' · '+spec.name,spec.name)
        self.cfg_value=QSpinBox();self.cfg_value.setRange(0,1000000);self.cfg_value.setValue(5);self.cfg_button=button('应用参数',self.apply_config);cfg.addWidget(self.cfg_field,1);cfg.addWidget(self.cfg_value);cfg.addWidget(self.cfg_button);v.addLayout(cfg)
        self.cfg_hint=label('','small',True);v.addWidget(self.cfg_hint)
        self.cfg_field.currentTextChanged.connect(self.config_field_changed);self.cfg_field.setCurrentIndex(self.cfg_field.findData('enemy_count'));self.config_field_changed()
        v.addWidget(label('可按英文参数名调参。角色数量、游戏敌弹尺寸与背景参数会先返回菜单，应用后重新开局。场景切换不换固件；重启恢复默认值，运行中的调参不写入 Flash。','small',True));v.addWidget(line())
        v.addWidget(self.gload);v.addWidget(line())
        v.addWidget(label('6–9  录制与回放'));row=QHBoxLayout();row.addWidget(label('随机种子','small'));self.replay_seed=QLineEdit();self.replay_seed.setPlaceholderText('可留空，使用默认种子');self.replay_seed.setMaximumWidth(240);row.addWidget(self.replay_seed);row.addStretch();v.addLayout(row)
        row=QHBoxLayout();self.replay_buttons=[]
        for text,op in [('6  录制新局','record'),('7  停止录制','stop'),('8  回放','replay'),('9  回放状态','status'),('导出到日志','dump')]:
            b=button(text,lambda checked=False,o=op:self.replay_action(o));self.replay_buttons.append(b);row.addWidget(b)
        row.addStretch();v.addLayout(row);v.addWidget(label('录制会重开一局并记录按键，自动关闭无敌和自动移动；它不是录像。停止录制不会暂停游戏。','small',True))
        row=QHBoxLayout();b=button('0  断开串口',self.toggle_connection);self.demo_controls.append(b);row.addWidget(b);row.addWidget(label('只断开电脑连接，板内游戏继续运行。','small'),1);v.addLayout(row);v.addStretch();scroll.setWidget(body);return scroll

    def build_settings(self):
        scroll=QScrollArea();scroll.setWidgetResizable(True);w=QWidget();v=QVBoxLayout(w);v.setContentsMargins(0,4,0,20);v.setSpacing(18)
        v.addWidget(label('连接设置','title'));v.addWidget(label('设置一次，之后直接选择游戏开始。','subtitle'));v.addSpacing(8)
        form=QFormLayout();form.setSpacing(16);form.setLabelAlignment(Qt.AlignLeft)
        self.bundle_field=QLineEdit(str(self.bundle or ''));self.bundle_field.setPlaceholderText('选择已解压的 TI60_LAB23 完整固化资料包')
        row=QWidget();rh=QHBoxLayout(row);rh.setContentsMargins(0,0,0,0);rh.addWidget(self.bundle_field,1);rh.addWidget(button('选择文件夹',self.pick_bundle));form.addRow('工程资料',row)
        self.port_field=QComboBox();self.port_field.setEditable(True);self.port_field.addItem(self.settings.port)
        ports=QWidget();ph=QHBoxLayout(ports);ph.setContentsMargins(0,0,0,0);ph.addWidget(self.port_field,1);ph.addWidget(button('刷新端口',self.refresh_ports));form.addRow('串口',ports)
        self.notification=QCheckBox('任务完成时，用语音提醒我');self.notification.setChecked(self.settings.notifications);form.addRow('',self.notification);v.addLayout(form)
        self.advanced_button=button('更多设置  ▾',self.toggle_advanced,'link');v.addWidget(self.advanced_button)
        self.advanced=QWidget();adv=QFormLayout(self.advanced);adv.setContentsMargins(0,0,0,0);adv.setSpacing(13)
        for key,title in [('python_executable','Python'),('efinity_home','Efinity'),('openocd','OpenOCD'),('libusb','libusb'),('usb_location','USB 位置')]:
            field=QLineEdit(str(getattr(self.settings,key)));self.settings_fields[key]=field;adv.addRow(title,field)
        self.advanced.hide();v.addWidget(self.advanced);row=QHBoxLayout();row.addWidget(button('保存设置',self.save_settings,'primary'));row.addStretch();v.addLayout(row);v.addStretch();scroll.setWidget(w);return scroll

    def build_help(self):
        scroll=QScrollArea();scroll.setWidgetResizable(True);w=QWidget();v=QVBoxLayout(w);v.setContentsMargins(0,4,0,12);v.setSpacing(18)
        v.addWidget(label('从这里开始','title'));v.addWidget(label('准备、完整烧录、运行，固定一个 LAB23 版本。','subtitle'))
        for title,text in [('01  准备开发板','接好 USB 和 HDMI TX，打开板上电源。关闭其他串口窗口，每次只运行一个烧录任务。'),('02  固化 LAB23 开机版本','先做离线检查，再点击“完整烧录到 Flash”。它覆盖开机镜像并保留本次 Flash 备份，校验完整镜像及 Flash 读回；烧录期间保持供电。文件检查本身不访问硬件。'),('03  在电脑上控制','连接串口并完成 LAB1 / LAB23 能力握手后，鼠标或键盘均可操作。WASD / 方向键移动，J 炸弹，空格暂停，Enter 开始 / 重开，Esc 菜单。板上 GPIO 按键不参与游戏控制。'),('04  演示基础一','进入“赛题实验”，点击“进入实验”，调整填色、图片块复制或输出图案，再执行。实验与游戏模式只改变运行状态，不重新烧录固件。退出实验后恢复游戏菜单。'),('05  分开核对写入与断电启动','“已写入并读回核对”表示本次烧录工具确认成功；正常启动日志不能替代断电启动验证，未取得独立验证记录时仍显示“断电启动待确认”。')]:
            v.addWidget(label(title));v.addWidget(label(text,'subtitle',True));v.addSpacing(8)
        for title,text in [('06  基础二与基础三','左侧为两个独立入口。基础二比较分散小块和合并区域；基础三进行同画面CPU/FPGA比较，并展示前后台分步换帧。'),('07  高阶一与高阶二','高阶版仍是LAB23家族，必须核对adv=1。高阶一展示透明混合、可调弹幕压力和物理，支持8档尺寸扫测；高阶二展示精确颜色去背和四状态联合。每项操作先进入实验，完成后退出；电脑源图是取色示意，实际图像在独立显示器。'),('08  停止和保存','停止后等待原任务真正结束与退出确认，不能把取消送达当作任务停止。实验页导出真实回包、失败、取消、未执行档位和对应身份，JSON与文字同时保存。')]:
            v.addWidget(label(title));v.addWidget(label(text,'subtitle',True));v.addSpacing(8)
        v.addWidget(line());v.addWidget(label('关于帧率'));v.addWidget(label('屏幕的 60 Hz 是刷新规格，实际 FPS 来自板端新画面计数。高阶压力分别报告物理、绘制与换帧等待时间；它的最终帧64点抽样不代表完整游戏逐帧通过。历史测试与当前数据分开显示；没有有效数据时显示“—”。','subtitle',True));v.addWidget(label('工作台固定使用 LAB23 / GAME60_PIPELINE_5 持久入口，不提供旧 RAM 加载回退。普通重开、压力对比与实验不更换程序版本。','small',True));v.addStretch();scroll.setWidget(w);return scroll

    def navigate(self,index):
        if self.job is not None and index==2:return
        self.release_controls()
        if index in (6,7):self.labx.set_section('basic2' if index==6 else 'basic3')
        if index in (8,9):self.adv.set_section('alpha' if index==8 else 'key')
        self.stack.setCurrentIndex(6 if index==7 else 7 if index in (8,9) else index)
        for b in self.game_nav.values():b.setChecked(False)
        for i,b in self.page_nav.items():b.setChecked(i==index)
        self.breadcrumb.setText(['项目','工作空间 / 运行日志','工作空间 / 连接设置','工作空间 / 使用说明','赛题实验 / 基础一','游戏 / 演示与调参','赛题实验 / 基础二','赛题实验 / 基础三','赛题实验 / 高阶一','赛题实验 / 高阶二'][index])

    def select_profile(self,key,initial=False):
        if self.job is not None or project_for(key) is None:return
        if not initial:self.release_controls()
        self.profile_id=key;profile=PROFILES[key];self.settings.last_profile=key
        self.stack.setCurrentIndex(0);self.breadcrumb.setText('项目 / '+profile.title);self.title.setText(profile.title);self.subtitle.setText(profile.subtitle)
        view=project_for(key)
        for k,b in self.game_nav.items():b.setChecked(project_for(k)==view)
        for b in self.page_nav.values():b.setChecked(False)
        self.version.blockSignals(True);self.version.clear()
        versions=list(view.profiles)
        for p in versions:self.version.addItem(PROFILES[p].version,p)
        self.version.setCurrentIndex(versions.index(key));self.version.blockSignals(False);self.version_badge.setText(profile.status)
        while self.control_layout.count():
            item=self.control_layout.takeAt(0)
            if item.widget():item.widget().deleteLater()
        self.controls=[]
        for action,text in profile.controls.items():
            if action in ('autoplay','invincible','restart'):continue
            b=button(text)
            b.setFocusPolicy(Qt.NoFocus)
            b.pressed.connect(lambda a=action:self.input_action(a,'mouse',True));b.released.connect(lambda a=action:self.input_action(a,'mouse',False))
            self.controls.append(b);self.control_layout.addWidget(b)
        self.control_layout.addStretch()
        self.board_hint.setText(view.board_hint);self.evidence_label.setText('历史记录：'+profile.history_fps)
        self.clear_metrics();self.update_controls()

    def version_changed(self,index):
        key=self.version.itemData(index)
        if key in PROFILES and key!=self.profile_id:self.select_profile(key)

    def clear_metrics(self):
        self.fps.set('—');self.draw.set('—');self.underflow.set('—');self.last_live=0;self.live_family=None;self.mode_label.setText('连接后显示实时数据' if self.link is None else '等待板端数据')

    def add_log(self,source,text):
        rendered='[%s] %s  %s'%(datetime.now().strftime('%H:%M:%S'),source,text)
        self.session_lines.append(rendered)
        with self.log_path.open('a',encoding='utf-8') as f:f.write(rendered+'\n')
        self.log_view.appendPlainText(rendered)
        if self.autoscroll.isChecked():self.log_view.verticalScrollBar().setValue(self.log_view.verticalScrollBar().maximum())

    def update_controls(self):
        ready=self.link is not None and self.job is None and self.protocol_ready
        labx_block=self.labx.blocks_game if hasattr(self,'labx') else False
        adv_block=self.adv.blocks_game if hasattr(self,'adv') else False
        game_load_block=self.gload.blocks_game
        active=ready and self.live_family==self.profile_id and time.monotonic()-self.last_live<7 and not self.lab.active and not self.lab.pending and not labx_block and not adv_block and not self.game_sequence.busy and not game_load_block
        for b in self.controls:b.setEnabled(active)
        for w in [self.pressure_button,self.pressure_count,self.pressure_backend,self.mode_button,self.mode_choice,self.cfg_button,self.cfg_field,self.cfg_value,self.replay_seed,*self.replay_buttons,*self.preset_buttons,*self.demo_controls]:w.setEnabled(active)
        for w in (self.game_size,self.game_count,self.game_bosses,self.game_enemies,self.game_apply):w.setEnabled(active and self.gload.capable)
        self.lab.set_available(ready and not self.game_sequence.busy and not labx_block and not adv_block and not game_load_block)
        sync_ready=ready and not self.game_sequence.busy and not self.lab.active and not self.lab.pending and not game_load_block
        # The board accepts ADV status first, but rejects even LABX status while
        # ADV owns the display. Keep the deferred LABX state unknown, rather than
        # inventing a successful check or allowing it to block its known owner.
        if hasattr(self,'labx'):self.labx.set_available(sync_ready and not adv_block, sync_ready and self.adv_status_allows_labx_query())
        if hasattr(self,'adv'):self.adv.set_available(sync_ready and not self.labx_blocks_adv_commands(), sync_ready and not self.actual_owner(self.labx))
        self.gload.set_available(ready and not self.game_sequence.busy and not self.lab.active and not self.lab.pending and not labx_block and not adv_block,
                                 ready and not self.game_sequence.busy)
        persistent_ready=persistent_bundle_available(self.bundle)
        lab_busy=self.lab.active or self.lab.pending or self.labx.blocks_game or (hasattr(self,'adv') and self.adv.blocks_game) or game_load_block
        self.download_button.setEnabled(self.job is None and not self.game_sequence.busy and not lab_busy and persistent_program_available(self.bundle));self.check_button.setEnabled(self.job is None and not self.game_sequence.busy and not lab_busy and persistent_ready)
        self.control_hint.setText('电脑控制已就绪' if active else '等待板端逐项确认' if self.game_sequence.busy else '实验占用显示' if self.lab.active else '实验占用或待核对固件后启用')

    def toggle_connection(self):
        if self.link is not None:self.disconnect();return
        try:
            if not self.save_settings(silent=True):return
            self.link=SerialLink(self.settings.baudrate);self.link.open(self.settings.port)
            self.protocol_ready=False;self.link.send(hello_command())
            self.connection.setText('●  '+self.settings.port+' 已连接');self.connect_button.setText('断开连接');self.clear_metrics();self.add_log('连接','已连接 '+self.settings.port+'，等待固件数据。')
        except Exception as exc:
            if self.link:
                try:self.link.close()
                except Exception:pass
            self.link=None;self.add_log('连接失败',str(exc));QMessageBox.warning(self,'连接未完成','无法连接串口。请检查端口、电源，并关闭其他串口窗口。\n\n'+str(exc))

    def disconnect(self):
        self._hud_policy_expected=None;self._hud_policy_deadline=0.
        self.game_sequence.cancel('串口连接已断开')
        self.release_controls();self.protocol_ready=False;self.lab.disconnected();self.labx.disconnected();self.adv.disconnected();self.gload.disconnected()
        if self.link:
            try:self.link.close()
            except Exception as exc:self.add_log('连接',str(exc))
        self.link=None;self.connection.setText('●  未连接');self.connect_button.setText('连接串口');self.clear_metrics();self.update_controls()
        for w in [self.auto_check,self.god_check,self.cpu_check]:w.setText('状态待板端确认')

    def poll_serial(self):
        self.lab.tick()
        self.labx.tick()
        self.adv.tick()
        self.gload.tick()
        self.game_sequence.tick()
        if self.link is None:return
        if self._hud_policy_expected is not None and time.monotonic()>=self._hud_policy_deadline:
            self.add_log('HUD策略','等待新的板端策略确认超时，已停止后续操作')
            self.disconnect();self.footer.setText('HUD策略确认超时，请重新连接核对');return
        try:
            self.link.heartbeat()
            for raw in self.link.read_lines():
                self.add_log('板端',raw)
                caps=parse_capabilities(raw)
                if caps:
                    expected_hud=self._hud_policy_expected
                    if expected_hud is not None and caps.get('hud_dma')!=expected_hud:
                        self.add_log('HUD策略','设置后实际策略不一致：请求%s，板端%s；连接已停用'%(expected_hud,caps.get('hud_dma','缺失')))
                        self.disconnect();self.footer.setText('HUD策略未保持，请重新连接后核对设置');return
                    self._hud_policy_expected=None;self._hud_policy_deadline=0.
                    self.game_sequence.cancel('重新核对固件能力')
                    # set_capabilities emits synchronous state_changed signals.
                    # Initialize every controller before allowing any query.
                    self.protocol_ready=False
                    self.lab.disconnected();self.labx.disconnected();self.adv.disconnected();self.gload.disconnected();self.last_live=0.;self.live_family=None;self.clear_metrics()
                    self.release_controls();accepted=self.link.accept_capabilities(caps);self.connection.setText('●  '+self.settings.port+' · '+caps['fw']+' 已核对'+(' · 旧版基础一' if caps['fw']=='LAB1' else ''))
                    self.lab.set_capabilities(caps)
                    self.labx.set_capabilities(caps)
                    self.adv.set_capabilities(caps)
                    self.gload.set_capabilities(caps)
                    self.protocol_ready=accepted
                    if expected_hud is not None:
                        self.add_log('HUD策略','新能力回包已确认 hud_dma=%s'%expected_hud)
                        self.footer.setText('HUD策略已核对：'+('硬件搬运' if expected_hud else '原CPU绘制'))
                elif raw.startswith('CAPS ') or raw.startswith('RUMIA ') or 'PHASE BATTLE v3 LAB1 PC CONTROL' in raw or 'PHASE BATTLE v3 LAB23 PC CONTROL' in raw:
                    self.game_sequence.cancel('固件已更换或重启')
                    self.release_controls();self.protocol_ready=False;self.link.accept_capabilities(None)
                    self.lab.disconnected();self.labx.disconnected();self.adv.disconnected();self.gload.disconnected();self.clear_metrics()
                    if 'PHASE BATTLE v3 LAB' in raw:self.link.send(hello_command())
                reply=parse_lab_reply(raw)
                if reply:self.lab.ingest(reply)
                labx_reply=parse_labx_reply(raw)
                if labx_reply:self.labx.ingest(labx_reply)
                adv_reply=parse_adv_reply(raw)
                if adv_reply:self.adv.ingest(adv_reply)
                game_load_reply=parse_game_load_reply(raw)
                if game_load_reply:self.gload.ingest(game_load_reply)
                elif raw.lstrip().startswith(('GLOAD_','MOTION_DIAG ')):self.gload.reject_wire(raw)
                self.control_reply(raw)
                self.game_sequence.feed(raw)
                data=parse_telemetry(raw)
                if data:
                    family=data['game_id'];self.live_family=family;self.last_live=time.monotonic()
                    if family!=self.profile_id:
                        self.game_sequence.cancel('固件版本不一致')
                        self.release_controls();self.protocol_ready=False;self.link.accept_capabilities(None);self.lab.disconnected();self.labx.disconnected();self.adv.disconnected();self.gload.disconnected()
                        self.fps.set('—');self.draw.set('—');self.underflow.set('—');self.mode_label.setText('当前固件与所选版本不一致');continue
                    self.board_paused=bool(data.get('paused'));self.mode_label.setText((data.get('mode') or '已接收数据')+(' · 已暂停' if self.board_paused else ''))
                    self.cpu_check.setText('当前：'+data.get('backend','待确认'))
                    f=data.get('fps');us=data.get('render_us');uf=data.get('underflows')
                    self.fps.set('%.1f'%f if f is not None else '—');self.draw.set('%.2f'%(us/1000) if us is not None else '—');self.underflow.set(str(uf) if uf is not None else '—')
            if self.last_live and time.monotonic()-self.last_live>=7:self.release_controls();self.clear_metrics();self.mode_label.setText('实验执行中' if self.lab.active or self.labx.blocks_game or self.adv.blocks_game else '数据已过期 · 等待下一条')
            self.update_controls()
        except Exception as exc:self.add_log('连接中断',str(exc));self.disconnect()

    def action(self,name,pressed):
        if not self.game_ready():return
        try:self.link.set_action(self.profile_id,name,pressed)
        except Exception as exc:self.add_log('控制',str(exc));self.disconnect()

    def release_controls(self):
        self.input_sources.clear()
        if self.link:
            try:self.link.release_all()
            except Exception as exc:self.add_log('释放按键',str(exc))

    def start_pressure(self):
        if not self.game_ready():return
        count=self.pressure_count.currentData();hardware=self.pressure_backend.currentData()
        self.run_pressure(count,hardware)

    def run_pressure(self,count,hardware):
        if not self.game_ready():return
        if not hardware and count>256:
            QMessageBox.information(self,'先选择较小数量','CPU 对照建议先使用 64 或 256 个精灵，避免界面长时间等待。');return
        if self.gload.capable:
            self.release_controls();self.game_sequence.start_pressure(count,bool(hardware));self.update_controls();return
        payload=stress_command(self.profile_id,count,hardware)
        if payload:
            try:self.link.send(payload);self.add_log('控制','开始绘制压力：'+str(count)+'，'+('FPGA' if hardware else 'CPU'))
            except Exception as exc:self.add_log('控制',str(exc));self.disconnect()

    def game_ready(self):
        return (self.link is not None and self.job is None and self.protocol_ready
                and self.live_family==self.profile_id and time.monotonic()-self.last_live<7
                and not self.lab.active and not self.lab.pending and not self.labx.blocks_game and not self.adv.blocks_game and not self.game_sequence.busy and not self.gload.blocks_game)

    def input_action(self,name,source,pressed):
        sources=self.input_sources.setdefault(name,set());before=bool(sources)
        if pressed:
            if not self.game_ready():return
            sources.add(source)
        else:sources.discard(source)
        if before!=bool(sources):self.action(name,bool(sources))

    def eventFilter(self,obj,event):
        if event.type() in (QEvent.KeyPress,QEvent.KeyRelease):
            keys={Qt.Key_W:'up',Qt.Key_Up:'up',Qt.Key_S:'down',Qt.Key_Down:'down',
                  Qt.Key_A:'left',Qt.Key_Left:'left',Qt.Key_D:'right',Qt.Key_Right:'right',
                  Qt.Key_J:'bomb',Qt.Key_Space:'pause',Qt.Key_Return:'start',Qt.Key_Enter:'start',Qt.Key_Escape:'menu'}
            key=event.key()
            if key in keys:
                source=('key',key)
                if event.isAutoRepeat():
                    return source in self.input_sources.get(keys[key],set())
                if event.type()==QEvent.KeyRelease:
                    held=source in self.input_sources.get(keys[key],set())
                    self.input_action(keys[key],source,False)
                    if held:return True
                    return super().eventFilter(obj,event)
                focus=QApplication.focusWidget()
                typing=isinstance(focus,(QLineEdit,QSpinBox,QComboBox,QPlainTextEdit))
                if self.stack.currentIndex()==0 and self.isActiveWindow() and not typing and self.game_ready():
                    self.input_action(keys[key],source,True)
                    return True
        if event.type()==QEvent.WindowDeactivate and obj is self:self.release_controls()
        return super().eventFilter(obj,event)

    def control_send(self,payload):
        if not self.game_ready():return
        self.release_controls()
        try:
            self.link.send(payload);self.add_log('控制已发送',payload.decode('ascii').strip())
            self.footer.setText('指令已发送 · 等待板端 OK / ERR')
        except Exception as exc:self.add_log('控制',str(exc));self.disconnect()

    def control_reply(self,raw):
        if raw.startswith(('OK ','ERR ','REPLAY_','REPLAY ')):
            self.footer.setText('板端：'+raw[:150])
        for prefix,w in [('OK autoplay ',self.auto_check),('OK invincible ',self.god_check)]:
            if raw in (prefix+'0',prefix+'1'):w.setText('已确认：'+('开启' if raw.endswith('1') else '关闭'))
        if raw in ('OK backend CPU','OK backend FPGA'):self.cpu_check.setText('当前：'+raw.split()[-1])

    def start_mode(self):
        self.control_send(mode_command(self.mode_choice.currentData()))

    def apply_config(self):
        if not self.game_ready():return
        field=self.selected_config_field();spec=CONFIG_BY_NAME.get(field)
        if not spec or not spec.writable:
            QMessageBox.information(self,'请选择可调参数','请输入或选择固件支持的参数名。');return
        if field=='enemy_bullet_size' and not self.gload.capable:
            self.footer.setText('当前固件未开放游戏弹幕尺寸，请完整固化新版本');return
        self.release_controls()
        try:self.game_sequence.start_config(field,self.cfg_value.value(),requires_menu=spec.menu_only)
        except ValueError as exc:QMessageBox.information(self,'参数范围',str(exc))
        self.update_controls()

    def selected_config_field(self):
        text=self.cfg_field.currentText().strip();index=self.cfg_field.currentIndex()
        return self.cfg_field.itemData(index) if index>=0 and text==self.cfg_field.itemText(index) else text

    def config_field_changed(self,*_):
        spec=CONFIG_BY_NAME.get(self.selected_config_field())
        if spec and spec.writable:
            self.cfg_value.setRange(spec.minimum,spec.maximum)
            if spec.name=='hud_dma_tail_enabled':self.cfg_value.setValue(0)
            self.cfg_hint.setText('%s · %s · 范围 %s–%s %s%s%s'%(spec.label,spec.name,spec.minimum,spec.maximum,spec.unit,' · 应用前自动回菜单' if spec.menu_only else '',(' · '+spec.note) if spec.name=='hud_dma_tail_enabled' else ''))
        else:self.cfg_hint.setText('请输入完整英文参数名，或在列表中选择。')

    def start_preset(self,bosses,mobs,mode=None):
        if not self.game_ready():return
        if mode is None:
            mode=self.mode_choice.currentData();mode=mode if mode in (0,1,2) else 0
        self.release_controls();self.game_sequence.start_preset(bosses,mobs,mode);self.update_controls()

    def start_custom_battle(self):
        if not self.game_ready() or not self.gload.capable:return
        self.release_controls();self.game_confirmed.setText('请求已发出 · 等待逐项确认')
        self.game_sequence.start_battle(self.game_size.currentData(),self.game_count.value(),self.game_bosses.value(),self.game_enemies.value(),self.demo_difficulty.currentData());self.update_controls()

    def sequence_send(self,payload):
        if self.link is None or not self.protocol_ready or self.job is not None or self.lab.active or self.lab.pending or self.labx.blocks_game or self.adv.blocks_game or self.gload.blocks_game:raise RuntimeError('当前连接不可用于游戏参数事务')
        self.link.send(payload);self.add_log('场景设置',payload.decode('ascii').strip())

    def sequence_menu(self):
        if self.link is None or not self.protocol_ready:raise RuntimeError('串口未就绪')
        if self.game_sequence.requested.get('kind')=='gload_menu':
            if not self.gload.capable or not self.gload._menu_pending:raise RuntimeError('游戏测量菜单事务未获授权')
            # One textual menu command creates no later binary MENU edge.
            self.link.send(b':menu\n')
        else:
            self.release_controls();self.link.set_action(self.profile_id,'menu',True);self.link.set_action(self.profile_id,'menu',False)
        self.add_log('场景设置','请求返回菜单，等待板端确认')

    def sequence_done(self,result):
        self.add_log('场景结果',json.dumps(result,ensure_ascii=False))
        if result['requested'].get('kind')=='gload_menu':
            self.gload.menu_ready(result['success'],result.get('reason',''))
        if result['requested'].get('kind')=='battle':
            names={'enemy_bullet_size':'敌弹尺寸','bullet_limit':'敌弹上限','boss_count':'Boss','enemy_count':'普通敌人'}
            self.game_confirmed.setText('已确认：'+' · '.join(f'{names[k]} {v}' for k,v in result['applied'].items())+(' · 已开局' if result['success'] else ' · 设置未完成'))
        if result.get('status') in ('TIMEOUT','SEND_ERROR'):
            self.disconnect()
            self.footer.setText('确认未完成，已断开串口；请重新连接并核对已应用参数')
            return
        if result['success'] and result['requested'].get('kind')=='config' and result['requested'].get('field')=='hud_dma_tail_enabled':
            self.release_controls();self.protocol_ready=False
            self._hud_policy_expected=result['applied']['hud_dma_tail_enabled'];self._hud_policy_deadline=time.monotonic()+10
            self.link.accept_capabilities(None)
            self.lab.disconnected();self.labx.disconnected();self.adv.disconnected();self.gload.disconnected();self.clear_metrics()
            self.link.send(hello_command())
            self.add_log('HUD策略','设置已应答，重新读取板端实际策略；确认前暂停操作')
            self.footer.setText('等待板端重新确认HUD策略');self.update_controls();return
        self.footer.setText('设置已由板端确认' if result['success'] else '设置未完成：'+str(result.get('reason','请看日志')))
        self.update_controls()

    def replay_action(self,op):
        if not self.game_ready():return
        try:
            seed=self.replay_seed.text().strip() if op=='record' else ''
            seed=int(seed,0) if seed else None
            self.control_send(replay_command(op,seed if op=='record' else None))
        except ValueError:QMessageBox.information(self,'随机种子无效','种子可留空，或输入 0 至 4294967295 的整数。')

    def lab_send(self,request_id,op,args):
        owned=self.lab.tracker.pending_id==request_id and self.lab.tracker.operation==op
        if not owned:return
        if not (owned and self.link is not None and self.protocol_ready and self.job is None and not self.game_sequence.busy and not self.labx.blocks_game and not self.adv.blocks_game and not self.gload.blocks_game):
            self.lab.disconnected();return
        self.release_controls()
        try:
            payload=lab_command(request_id,op,*args)
            if op.startswith('img') and getattr(self.link,'capabilities',{}).get('img')!=1:
                raise ValueError('板上尚未运行LABIMG1图片导入固件，请先完整固化当前版本。')
            self.link.send(payload)
            self.add_log('实验已发送', payload.decode('ascii').strip() if op!='imgdata' else f':lab {request_id} imgdata session={args[0]} offset={args[1]} encoded_chars={len(args[2])}')
        except Exception as exc:
            self.add_log('实验失败',str(exc));self.disconnect()

    def lab_state_changed(self):
        if self.lab.active or self.lab.pending or (hasattr(self,'labx') and self.labx.blocks_game) or (hasattr(self,'adv') and self.adv.blocks_game) or self.gload.blocks_game:
            self.release_controls();self.last_live=0.;self.live_family=None;self.clear_metrics()
        self.update_controls()

    def legacy_lab_detected(self):
        self.lab.active=True;self.lab.status.setText('板端仍在基础一实验 · 请先点击退出实验恢复菜单');self.update_controls()

    @staticmethod
    def actual_owner(panel):
        return panel.active or bool(getattr(panel,'_foreign_running',False)) or panel._cancel_id is not None or (panel.pending and (panel._request is None or panel._request.operation!='status'))

    def adv_status_allows_labx_query(self):
        panel=self.adv
        return not panel.capable or (not panel._need_resync and not panel.blocks_game)

    def labx_blocks_adv_commands(self):
        if self.actual_owner(self.labx):return True
        # Only an already active ADV owner can bypass deferred LABX uncertainty.
        # A pending ADV enter is not ownership; it must still wait for LABX.
        return self.labx.blocks_game and not (self.adv.active or self.adv._foreign_running)

    def labx_send(self,request_id,op,args):
        caps=getattr(self.link,'capabilities',None) if self.link is not None else None
        request=self.labx._request
        owned=(request is not None and request.request_id==request_id and request.operation==op and list(request.args)==args) or (op=='cancel' and request_id==self.labx._cancel_id and not args)
        if not owned:return
        other_busy=not self.adv_status_allows_labx_query() if op=='status' else self.adv.blocks_game
        if not (owned and self.link is not None and self.protocol_ready and self.job is None and not self.game_sequence.busy and not self.lab.active and not self.lab.pending and not other_busy and not self.gload.blocks_game and caps and caps.get('fw')=='LAB23' and caps.get('labx')==1):
            self.labx.disconnected();return
        self.release_controls()
        try:
            payload=labx_command(request_id,op,*args);self.link.send(payload);self.add_log('新实验已发送',payload.decode('ascii').strip())
        except Exception as exc:self.add_log('新实验发送失败',str(exc));self.disconnect()

    def export_labx(self):
        dest,_=QFileDialog.getSaveFileName(self,'导出基础二 / 三实验','LAB23_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.json','结构化实验记录 (*.json)')
        if dest:
            document=self.labx.export_document();document['bundle']=str(self.bundle) if self.bundle else None
            if self.bundle:
                manifest=self.bundle/'out/manifest.json'
                if manifest.is_file():
                    try:document['local_manifest']=json.loads(manifest.read_text(encoding='utf-8-sig'))
                    except (ValueError,OSError):pass
            Path(dest).write_text(json.dumps(document,ensure_ascii=False,indent=2),encoding='utf-8')
            Path(dest).with_suffix('.txt').write_text('LAB23 基础二 / 三实验\n仅 accepted_pass=true 表示本机完整核对通过；ACK不表示通过。\n'+self.labx.status.text()+'\n'+self.labx.summary.text()+'\n'+self.labx.continuous_status.text()+'\n\n'+self.labx.log.toPlainText(),encoding='utf-8');self.footer.setText('实验记录已导出 · JSON 与文字报告')

    def adv_send(self,request_id,op,args):
        caps=getattr(self.link,'capabilities',None) if self.link is not None else None
        request=self.adv._request
        owned=(request is not None and request.request_id==request_id and request.operation==op and list(request.args)==args) or (op=='cancel' and request_id==self.adv._cancel_id and not args)
        if not owned:return
        other_busy=self.actual_owner(self.labx) if op=='status' else self.labx_blocks_adv_commands()
        if not (self.link is not None and self.protocol_ready and self.job is None and not self.game_sequence.busy and not self.lab.active and not self.lab.pending and not other_busy and not self.gload.blocks_game and caps and caps.get('fw')=='LAB23' and caps.get('adv')==1):
            self.adv.disconnected();return
        self.release_controls()
        try:
            payload=adv_command(request_id,op,*args);self.link.send(payload);self.add_log('高阶实验已发送',payload.decode('ascii').strip())
        except Exception as exc:self.add_log('高阶实验发送失败',str(exc));self.disconnect()

    def export_adv(self):
        dest,_=QFileDialog.getSaveFileName(self,'导出高阶一 / 二实验','LABADV1_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.json','结构化实验记录 (*.json)')
        if dest:
            document=self.adv.export_document();document['bundle']=str(self.bundle) if self.bundle else None
            if self.bundle and (self.bundle/'out/manifest.json').is_file():
                try:document['local_manifest']=json.loads((self.bundle/'out/manifest.json').read_text(encoding='utf-8-sig'))
                except (ValueError,OSError):pass
            Path(dest).write_text(json.dumps(document,ensure_ascii=False,indent=2),encoding='utf-8')
            Path(dest).with_suffix('.txt').write_text('LABADV1 高阶实验\n正确性与性能分开；压力为最终帧64点抽样。\n'+self.adv.status.text()+'\n'+self.adv.summary.text()+'\n'+self.adv.detail.text()+'\n\n'+self.adv.log.toPlainText(),encoding='utf-8');self.footer.setText('高阶实验已导出 · JSON 与文字报告')

    def gload_menu(self):
        if not self.gload._menu_pending:return
        if not self.gload.capable or self.link is None or not self.protocol_ready or self.job is not None or self.game_sequence.busy or self.lab.active or self.lab.pending or self.labx.blocks_game or self.adv.blocks_game:
            self.gload.menu_ready(False,'当前连接或实验状态不允许开始');return
        self.release_controls();self.game_sequence.start_menu();self.update_controls()

    def gload_send(self,request_id,op,args):
        if not self.gload.owns(request_id,op,args):return
        caps=getattr(self.link,'capabilities',{}) if self.link else {}
        safe=self.link is not None and self.protocol_ready and self.job is None and not self.game_sequence.busy and caps and caps.get('game_load')==1
        if op=='run':safe=safe and not self.lab.active and not self.lab.pending and not self.labx.blocks_game and not self.adv.blocks_game
        if not safe:self.gload.disconnected();self.update_controls();return
        self.release_controls()
        try:
            payload=game_load_command(request_id,op,*args);self.link.send(payload);self.add_log('游戏测量已发送',payload.decode('ascii').strip())
        except Exception as exc:self.add_log('游戏测量发送失败',str(exc));self.disconnect()

    def export_gload(self):
        dest,_=QFileDialog.getSaveFileName(self,'导出游戏战斗负载测量','GAME_LOAD_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.json','结构化战斗测量 (*.json)')
        if not dest:return
        document=self.gload.export_document();document['bundle']=str(self.bundle) if self.bundle else None
        if self.bundle and (self.bundle/'out/manifest.json').is_file():
            try:document['local_manifest']=json.loads((self.bundle/'out/manifest.json').read_text(encoding='utf-8-sig'))
            except (ValueError,OSError):pass
        Path(dest).write_text(json.dumps(document,ensure_ascii=False,indent=2),encoding='utf-8')
        Path(dest).with_suffix('.txt').write_text('东方游戏受控负载测量\n人工补弹与角色保活；不代表自然阶段战，不是ADV压力。\n'+self.gload.status.text()+'\n'+self.gload.bounds.text()+'\n\n'+'\n'.join(self.gload.raw_lines),encoding='utf-8')
        self.footer.setText('游戏战斗测量已导出 · JSON 与文字报告')

    def app_state_changed(self,state):
        if state!=Qt.ApplicationActive:self.release_controls()

    def run_job(self,check):
        if self.job is not None or self.game_sequence.busy or self.lab.active or self.lab.pending or self.labx.blocks_game or self.adv.blocks_game or self.gload.blocks_game:return
        try:
            if not self.save_settings(silent=True):return
            if self.bundle is None:raise ValueError('请在连接设置中选择已解压的工程资料文件夹。')
            config=self.settings.write_tool_config(self.bundle)
            command=build_command(self.bundle,self.profile_id,check,self.settings.python_executable,config)
        except Exception as exc:QMessageBox.warning(self,'准备未完成',str(exc));return
        self.release_controls()
        if not check:self.disconnect()
        self.job_persistent_ready=persistent_program_available(self.bundle)
        self.job_check=check;self.download_progress.reset(check=check);self.decoder=codecs.getincrementaldecoder('utf-8')('replace');self.pending='';self.job=QProcess(self)
        environment=QProcessEnvironment()
        for k,val in process_environment().items():environment.insert(k,val)
        self.job.setProcessEnvironment(environment);self.job.setWorkingDirectory(str(self.bundle));self.job.setProcessChannelMode(QProcess.MergedChannels)
        self.job.readyReadStandardOutput.connect(self.read_job);self.job.finished.connect(self.job_finished);self.job.errorOccurred.connect(self.job_error)
        self.set_busy(True);self.download_panel.reset(check=check);self.download_panel.show()
        if not check:self.flash_status.setText('完整 Flash 写入与读回进行中 · 断电启动尚未验证')
        self.add_log('任务',('持久镜像离线检查' if check else '完整 Flash 烧录')+' · '+PROFILES[self.profile_id].title+' / '+PROFILES[self.profile_id].version)
        self.job.start(command[0],command[1:])

    def set_busy(self,busy):
        for w in [self.download_button,self.check_button,self.version,self.connect_button,*self.game_nav.values()]:w.setEnabled(not busy)
        self.page_nav[2].setEnabled(not busy);self.footer.setText('任务进行中 · 请保持开发板供电' if busy and not self.job_check else 'Ti60F225I3-V4  ·  '+('正在检查' if busy else '准备就绪'));self.update_controls()

    def read_job(self):
        if self.job is None:return
        self.pending+=self.decoder.decode(bytes(self.job.readAllStandardOutput()))
        while '\n' in self.pending:
            raw,self.pending=self.pending.split('\n',1);raw=raw.rstrip('\r')
            if raw:self.add_log('下载工具',raw);self.download_panel.log_activity()
            self.show_download_progress(raw)

    def show_download_progress(self,raw):
        value=self.download_progress.feed(raw)
        if value is None:return
        self.download_panel.update_progress(value)

    def job_error(self,error):
        if error==QProcess.FailedToStart:self.job_finished(-1,QProcess.CrashExit)

    def job_finished(self,code,status):
        if self.job is None:return
        self.read_job()
        if self.pending.strip():self.add_log('下载工具',self.pending.strip())
        check=self.job_check;old=self.job;self.job=None;old.deleteLater();self.set_busy(False)
        success=code==0 and status==QProcess.NormalExit
        self.download_progress.finish(success)
        if success:
            msg=('离线核对通过 · 未执行 Flash 写入'+(' · 固化入口仍在准备' if not self.job_persistent_ready else '')) if check else '已写入并读回核对 · 断电启动待确认'
            if not check:self.flash_status.setText(msg)
            self.download_panel.finish(True,msg);self.add_log('完成',msg);self.notify('离线检查已完成。' if check else '完整烧录和读回核对已完成，断电启动仍待确认。')
        else:
            if not check:self.flash_status.setText('本次完整烧录未完成 · 不宣称写入或断电启动通过')
            self.download_panel.finish(False,'任务未完成 · 请到运行日志查看原因');self.add_log('任务未完成','退出码 '+str(code));self.notify('任务未完成，请查看运行日志。');self.navigate(1)

    def notify(self,text):
        if self.smoke or not self.settings.notifications:return
        script="Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.SelectVoice('Microsoft Huihui Desktop'); $s.SetOutputToDefaultAudioDevice(); $s.Speak('"+text.replace("'","''")+"'); $s.Dispose()"
        try:subprocess.Popen(['powershell.exe','-NoProfile','-Command',script],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except OSError:pass

    def save_settings(self,silent=False):
        try:
            self.settings.bundle_root=self.bundle_field.text().strip();self.settings.port=self.port_field.currentText().strip().upper();self.settings.notifications=self.notification.isChecked()
            for key,w in self.settings_fields.items():setattr(self.settings,key,w.text().strip())
            self.settings.validate();self.bundle=discover_bundle(self.settings.bundle_root)
            if not self.bundle:raise ValueError('未找到完整持久烧录资料，请选择含 persistent_entry.json(kind=full_flash) 的 TI60_LAB23 文件夹；旧 RAM 入口已禁用。')
            self.settings.bundle_root=str(self.bundle);self.settings.save()
            self.bundle_field.setText(str(self.bundle))
            self.adv.set_bundle(self.bundle)
            if not silent:self.add_log('设置','连接设置已保存。');self.footer.setText('设置已保存')
            return True
        except Exception as exc:
            QMessageBox.warning(self,'设置未保存',str(exc));return False

    def pick_bundle(self):
        selected=QFileDialog.getExistingDirectory(self,'选择工程资料',self.bundle_field.text())
        if selected:self.bundle_field.setText(selected)

    def toggle_advanced(self):
        self.advanced.setVisible(not self.advanced.isVisible());self.advanced_button.setText('收起更多设置  ▴' if self.advanced.isVisible() else '更多设置  ▾')

    def refresh_ports(self):
        try:
            from serial.tools import list_ports
            current=self.port_field.currentText();ports=list(list_ports.comports());self.port_field.clear()
            self.port_field.addItems([p.device for p in ports]);self.port_field.setCurrentText(current)
            self.add_log('端口','检测到 '+str(len(ports))+' 个串口。')
        except Exception as exc:self.add_log('端口',str(exc))

    def open_path(self,path):QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
    def open_project(self):
        if self.bundle:self.open_path(self.bundle/PROFILES[self.profile_id].project_rel)
    def open_evidence(self):
        if self.bundle:self.open_path(self.bundle/'CURRENT_STATUS.txt')
    def export_log(self):
        dest,_=QFileDialog.getSaveFileName(self,'导出日志','赛题二工作台_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.log','日志文件 (*.log)')
        if dest:
            report='\n'.join(self.session_lines)+'\n\nLOCAL_LAB_ACCEPTANCE (accepted_pass is the application verdict)\n'
            report+='\n'.join(json.dumps(r,ensure_ascii=False) for r in self.lab.results)+'\n'
            Path(dest).write_text(report,encoding='utf-8');self.footer.setText('日志已导出（含本地校验结论）')

    def closeEvent(self,event):
        if self.job is not None:
            QMessageBox.information(self,'任务正在进行','请等待当前检查或完整烧录结束后再关闭，避免中断 Flash 写入和读回。');event.ignore();return
        self.disconnect();event.accept()

def main():
    app=QApplication.instance() or QApplication(sys.argv);app.setApplicationName('赛题二工作台');app.setStyle('Fusion')
    font_path=Path('C:/Windows/Fonts/msyh.ttc')
    if font_path.is_file():QFontDatabase.addApplicationFont(str(font_path))
    app.setFont(QFont('Microsoft YaHei UI',10));app.setStyleSheet(STYLE)
    smoke='--smoke' in sys.argv
    lock=QLockFile(str(app_data_dir(True)/'instance.lock'))
    if not smoke and not lock.tryLock(0):QMessageBox.information(None,'赛题二工作台','工作台已经打开，请使用已有窗口。');return 0
    window=MainWindow(smoke=smoke);window.show()
    if smoke:
        def capture():
            directory=Path(__file__).resolve().parent/'evidence';directory.mkdir(exist_ok=True)
            window.grab().save(str(directory/'home.png'));window.navigate(2);window.grab().save(str(directory/'settings.png'));window.navigate(1);window.grab().save(str(directory/'logs.png'));app.quit()
        QTimer.singleShot(350,capture)
    return app.exec()

if __name__=='__main__':raise SystemExit(main())

