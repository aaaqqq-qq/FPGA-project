"""Native ADV1 controls. Only signals leave this widget; it never opens a port."""
from __future__ import annotations
import json, re, secrets, time
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QImage, QPixmap
from PySide6.QtWidgets import (QWidget,QLabel,QPushButton,QVBoxLayout,QHBoxLayout,
 QFormLayout,QComboBox,QSpinBox,QSlider,QCheckBox,QColorDialog,QTabWidget,
 QPlainTextEdit,QTableWidget,QTableWidgetItem,QHeaderView,QLineEdit,QProgressBar)
from adv_protocol import AdvRequest,adv_command,timeout_for,validate_args
from performance_cases import DURATIONS,PRESETS,preset_args,performance_args

SHAPES=[('圆形',0),('方形',1),('菱形',2),('圆环',3),('星芒',4),('三角形',5)]
PATH_NAMES={'none':'尚未准备','cpu':'CPU软件对照','direct8':'8像素直接批绘','tile8_ordered':'8像素分块 · 原精灵顺序','tile8_commute':'8像素分块 · 同色Key安全交换','rowrun':'连续像素行段','rowrun_mixed':'行段任务 · 含容量回退','rect':'逐精灵矩形回退'}
PATH_REASON_NAMES={'not_prepared':'尚未完成准备','none':'正常直接路径','cpu_reference':'CPU软件对照','batch_unavailable':'批绘资源不可用','fusion_dynamic':'融合尺寸动态变化','size64_deferred':'64像素本轮另测','size_not_multiple8':'尺寸不是8的整数倍','descriptor_capacity':'描述符容量不足','materials_over16':'微材质超过16种','materials_fit':'微材质在16种内，保留原顺序','single_color_key':'同一实际前景色且Key开启，安全分多遍','rowrun_fusion':'融合动态尺寸使用精确行段','rowrun_odd':'非8倍数尺寸使用精确行段','rowrun_capacity_fallback':'行段扩展超20000，该帧完整矩形回退（也可能全部回退）'}
PHYSICS=[('纯绘制 · 无粒子相互作用',0),('弹性碰撞反弹',1),('碰撞融合',2),('相互吸引',3),('相互排斥',4),('旋涡场',5)]
def label(value,muted=False):
 w=QLabel(value);w.setWordWrap(True)
 if muted:w.setStyleSheet('color:#818287;font-size:12px;')
 return w
def combo(items):
 w=QComboBox()
 for name,value in items:w.addItem(name,value)
 return w
def spin(lo,hi,value):
 w=QSpinBox();w.setRange(lo,hi);w.setValue(value);return w

class ColorButton(QPushButton):
 changed=Signal(int)
 def __init__(self,rgb):
  super().__init__();self.rgb=rgb;self.set_rgb(rgb);self.clicked.connect(self.choose)
 def set_rgb(self,value):
  self.rgb=int(value)&0xffffff;self.setText('#%06X'%self.rgb)
  self.setStyleSheet('QPushButton{border-left:16px solid #%06x;}'%self.rgb);self.changed.emit(self.rgb)
 def choose(self):
  value=QColorDialog.getColor(QColor(self.rgb),self,'选择颜色')
  if value.isValid():self.set_rgb(value.rgb()&0xffffff)

@lru_cache(maxsize=4)
def read_art(path):
 raw=Path(path).read_text(encoding='utf-8')
 def values(name):
  body=re.search(r'\b'+name+r'\s*\[[^]]*\]\s*=\s*\{([^}]+)\}',raw,re.S)
  if not body:raise ValueError('素材数据缺失')
  return [int(x) for x in re.findall(r'\d+',body.group(1))]
 palette=values('art_palette');pixels=values('art_pixels')
 body=raw.split('static const Tile tiles[] = {',1)[1].split('};',1)[0]
 tiles=[tuple(map(int,x)) for x in re.findall(r'\{(\d+),(\d+),(\d+)\}',body)]
 return palette,pixels,tiles

def shape_contains(shape,x,y,size):
 dx=2*x+1-size;dy=2*y+1-size;r2=size*size
 if shape==0:return dx*dx+dy*dy<=r2
 if shape==1:return True
 if shape==2:return abs(dx)+abs(dy)<=size
 if shape==3:return r2*9//25<=dx*dx+dy*dy<=r2
 if shape==4:return abs(dx)+abs(dy)<=size//2 or abs(dx)*3+abs(dy)<=size*5//4 or abs(dx)+abs(dy)*3<=size*5//4
 return y*2+1>=size//4 and abs(dx)<=y

class SourcePreview(QLabel):
 picked=Signal(int)
 def __init__(self):
  super().__init__();self.image=None;self.setFixedSize(144,144);self.setAlignment(Qt.AlignCenter)
  self.setStyleSheet('border:1px solid #e5e5e8;border-radius:8px;background:#fafafa;')
 def set_pixels(self,pixels,size):
  image=QImage(size,size,QImage.Format_RGB32)
  for y in range(size):
   for x in range(size):image.setPixel(x,y,0xff000000|pixels[y*size+x])
  self.image=image;self.setPixmap(QPixmap.fromImage(image).scaled(140,140,Qt.KeepAspectRatio,Qt.FastTransformation))
 def mousePressEvent(self,event):
  if self.image is not None:
   edge=140;left=(self.width()-edge)//2;top=(self.height()-edge)//2
   x=int(event.position().x())-left;y=int(event.position().y())-top
   if 0<=x<edge and 0<=y<edge:self.picked.emit(self.image.pixel(x*self.image.width()//edge,y*self.image.height()//edge)&0xffffff)
  super().mousePressEvent(event)

class AdvPanel(QWidget):
 command_requested=Signal(int,str,list)
 state_changed=Signal()
 export_requested=Signal()
 def __init__(self,parent=None,clock=time.monotonic):
  super().__init__(parent);self.clock=clock;self.section='alpha';self.bundle=None
  self.available=self.status_available=self.capable=self.active=self.pending=self.uncertain=False;self.perf_capable=False
  self._need_resync=False;self._next_id=secrets.randbelow(1000000000)+1000000
  self._request=None;self._cancel_id=None;self._cancel_deadline=0;self._exit_after=False;self._stop_resync=False
  self._demo=[];self._coalesced_show=None;self._due=False;self._foreign_running=False;self._foreign_check_at=0
  self.results=[];self.raw_lines=[];self.identity={};self.sweeps=[];self._sweep=None;self._sweep_due=False;self._shortcuts=[];self.performance_cases=[];self._performance_contexts={};self._last_performance_case=None;self._request_started=0;self._last_wait_second=-1;self._live_progress=None;self._build();self._enable()
 @property
 def blocks_game(self):return self.active or self.pending or self.uncertain or self._cancel_id is not None or self._foreign_running
 def button(self,title,callback):
  b=QPushButton(title);b.clicked.connect(callback);return b
 def _build(self):
  v=QVBoxLayout(self);v.setContentsMargins(0,4,0,12);v.setSpacing(14)
  self.title=label('高阶一 · 透明度混合');self.title.setStyleSheet('font-size:27px;font-weight:600;');v.addWidget(self.title)
  v.addWidget(label('真实绘制在开发板完成。电脑源图仅供取色与原理观察，不是板卡回传视频。',True))
  r=QHBoxLayout();self.enter_button=self.button('进入实验',lambda:self.request('enter'));self.exit_button=self.button('返回游戏',self.stop_and_return);self.sync_button=self.button('核对板端状态',lambda:self.request('status'));self.stop_button=self.button('停止并返回',self.stop_and_return);self.export_button=self.button('导出实验记录',self.export_requested.emit)
  for b in (self.enter_button,self.exit_button,self.sync_button,self.stop_button):r.addWidget(b)
  r.addStretch();r.addWidget(self.export_button);v.addLayout(r)
  self.status=label('连接支持 ADV1 的 LAB23 固件后启用。',True);v.addWidget(self.status)
  self.tabs=QTabWidget();v.addWidget(self.tabs);show=QWidget();s=QVBoxLayout(show);s.setSpacing(12);s.setAlignment(Qt.AlignTop)
  f=QFormLayout();self.material=combo([('自定义几何弹幕',0),('东方玩家原图',1),('东方 Boss 原图',2),('东方圆弹原图',3)]);self.shape=combo(SHAPES);self.size=spin(8,64,32)
  f.addRow('源素材',self.material);f.addRow('几何形状',self.shape);f.addRow('尺寸 / 像素',self.size)
  self.fg=ColorButton(0xff3030);self.bg=ColorButton(0x2452c0);self.key=ColorButton(0xff00ff)
  colors=QHBoxLayout();colors.addWidget(label('前景'));colors.addWidget(self.fg);colors.addWidget(label('背景'));colors.addWidget(self.bg);colors.addWidget(label('透明色'));colors.addWidget(self.key);s.addLayout(f);s.addLayout(colors)
  self.alpha=QSlider(Qt.Horizontal);self.alpha.setRange(0,255);self.alpha.setValue(128);self.alpha_value=label('128 / 255 · 不透明度 50.2%')
  r=QHBoxLayout();r.addWidget(label('不透明度'));r.addWidget(self.alpha,1);r.addWidget(self.alpha_value);s.addLayout(r)
  r=QHBoxLayout()
  for value in (0,64,128,192,255):
   b=self.button(str(value)+' / 255',lambda checked=False,a=value:self.set_alpha(a));self._shortcuts.append(b);r.addWidget(b)
  r.addStretch();s.addLayout(r)
  self.pattern=combo([('纯色背景',0),('棋盘格',1),('东方背景',2)]);self.order=combo([('前景 A 在上',0),('前景 B 在上',1)])
  self.alpha_on=QCheckBox('启用透明混合');self.alpha_on.setChecked(True);self.key_on=QCheckBox('启用颜色去背')
  r=QHBoxLayout();r.addWidget(self.pattern);r.addWidget(self.order);r.addWidget(self.alpha_on);r.addWidget(self.key_on);r.addStretch();s.addLayout(r)
  r=QHBoxLayout();self.preview=SourcePreview();r.addWidget(self.preview);caption=label('源图原始 RGB 示意\n点击图中像素选为透明色。角色沿用原图颜色，自定义颜色作用于几何弹幕。',True);r.addWidget(caption,1);s.addLayout(r)
  r=QHBoxLayout();self.show_button=self.button('在板卡执行',self.queue_show);self.demo_button=self.button('一键演示',self.start_demo);self.verify_button=self.button('一键校验',lambda:self.request('verify',self.section));self.joint_button=self.button('四状态联合演示',lambda:self.queue_show('joint'));self.joint_verify=self.button('联合数值校验',lambda:self.request('verify','joint'))
  for b in (self.show_button,self.demo_button,self.verify_button,self.joint_button,self.joint_verify):r.addWidget(b)
  s.addLayout(r);s.addWidget(label('每次显示从干净背景开始；先匹配透明色，再混合剩余像素。Alpha 为每个任务统一值，Key 为 RGB 精确匹配。',True));self.tabs.addTab(show,'透明度混合')
  stress=QWidget();sv=QVBoxLayout(stress);sv.setSpacing(12);sv.setAlignment(Qt.AlignTop);form=QFormLayout()
  self.backend=combo([('FPGA 硬件绘制','fpga'),('板内 CPU 软件绘制','cpu')]);self.count=spin(1,20000,64);self.stress_size=spin(8,64,16);self.stress_shape=combo(SHAPES)
  self.color_mode=combo([('单色',0),('三色交替',1),('所选颜色渐变',2)]);self.physics=combo(PHYSICS);self.frames=spin(1,36000,120);self.seed=QLineEdit('123456789');self.seed.setMaxLength(10)
  for name,w in [('绘制器',self.backend),('初始弹幕数量',self.count),('尺寸 8～64 像素',self.stress_size),('形状',self.stress_shape),('配色方式',self.color_mode),('物理效果',self.physics),('测量帧数',self.frames),('随机种子',self.seed)]:form.addRow(name,w)
  sv.addLayout(form);r=QHBoxLayout();r.addWidget(label('快捷尺寸'))
  for size in (8,16,24,32,48,64):
   b=self.button(str(size)+' × '+str(size),lambda checked=False,n=size:self.stress_size.setValue(n));self._shortcuts.append(b);r.addWidget(b)
  r.addStretch();sv.addLayout(r)
  self.palette=[ColorButton(x) for x in (0x4c8dff,0xf18bbb,0xf5be52)];r=QHBoxLayout();r.addWidget(label('自选颜色'))
  for b in self.palette:r.addWidget(b)
  self.stress_alpha=spin(0,255,128);self.stress_key=QCheckBox('去背');self.stress_key.setChecked(True);r.addWidget(label('Alpha'));r.addWidget(self.stress_alpha);r.addWidget(self.stress_key);r.addStretch();sv.addLayout(r)
  self.physics_hint=label('',True);sv.addWidget(self.physics_hint);self.stress_button=self.button('开始压力测试',self.start_stress);self.sweep_button=self.button('一键尺寸扫测 · 8 / 16 / 24 / 32 / 40 / 48 / 56 / 64',self.start_sweep);r=QHBoxLayout();r.addWidget(self.stress_button);r.addWidget(self.sweep_button);sv.addLayout(r)
  self.performance_preset=combo([(title,i) for i,(title,_) in enumerate(PRESETS)]);self.performance_load=self.button('载入明确配置',self.load_performance_preset)
  r=QHBoxLayout();r.addWidget(label('60FPS复测配置'));r.addWidget(self.performance_preset,1);r.addWidget(self.performance_load);sv.addLayout(r)
  self.performance_duration=combo([('自选帧数 · 以上输入为准',None),*DURATIONS]);self.performance_start=self.button('执行当前配置复测',self.start_performance);self.performance_repeat=self.button('按上次原参数复测',self.repeat_performance)
  r=QHBoxLayout();r.addWidget(self.performance_duration);r.addWidget(self.performance_start);r.addWidget(self.performance_repeat);sv.addLayout(r)
  self.performance_hint=label('需perf=1固件。短测只作观察；36000帧目标约10分钟。CPU及64×64不纳入本轮60FPS验收，数量不会自动降低。',True);sv.addWidget(self.performance_hint)
  self.performance_progress=QProgressBar();self.performance_progress.setRange(0,36000);self.performance_progress.setValue(0);self.performance_progress.setTextVisible(False);sv.addWidget(self.performance_progress)
  self.performance_live=label('等待板端真实帧数、换帧、耗时、超时与欠流数据。',True);sv.addWidget(self.performance_live)
  self.performance_wait=label('主机等待时间与板端实际经过时间分开记录。',True);sv.addWidget(self.performance_wait)
  self.sweep_status=label('尺寸扫测固定其余参数，逐档完成才继续；取消后未执行档位保持未执行。',True);sv.addWidget(self.sweep_status)
  self.sweep_table=QTableWidget(0,11);self.sweep_table.setHorizontalHeaderLabels(['尺寸','请求','状态','初始 / 实际','最少 / 最多','逻辑总 ms','绘制墙钟 ms','实际 FPS','>16.667ms','欠流事件','像素核对']);self.sweep_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents);self.sweep_table.setEditTriggers(QTableWidget.NoEditTriggers);self.sweep_table.setMaximumHeight(220);sv.addWidget(self.sweep_table)
  sv.addWidget(label('初始数量不会被自动降低。融合会改变实际数量；所有形状采用圆形碰撞包络。16.667ms计数含实际换帧等待与采样，不等于错过换帧；欠流另列。压力检查为最终帧64个屏幕点抽样，不是完整逐像素检验。',True));self.tabs.addTab(stress,'弹幕压力与物理')
  self.plan_label=label('任务预登记：—',True);v.addWidget(self.plan_label);self.summary=label('等待真实板端结果');v.addWidget(self.summary)
  self.table=QTableWidget(0,11);self.table.setHorizontalHeaderLabels(['请求','操作','初始 / 实际','最少 / 最多','逻辑总 ms','绘制墙钟 ms','换帧等待 ms','实际 FPS','>16.667ms','欠流事件','像素核对']);self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents);self.table.horizontalHeader().setStretchLastSection(True);self.table.setMaximumHeight(160);self.table.setEditTriggers(QTableWidget.NoEditTriggers);v.addWidget(self.table)
  self.detail=label('计时、抽样范围与碰撞/融合次数将在完成后显示。',True);v.addWidget(self.detail)
  self.timing_detail=label('真实扫描、16点前台签名及粒子状态证据将在perf=1固件完成后显示。',True);v.addWidget(self.timing_detail)
  self.path_detail=label('绘制路径诊断尚未提供；不按算法名称判断60FPS。',True);v.addWidget(self.path_detail)
  self.log=QPlainTextEdit();self.log.setReadOnly(True);self.log.setMaximumHeight(100);v.addWidget(self.log)
  self.inputs=[self.material,self.shape,self.size,self.fg,self.bg,self.key,self.alpha,self.pattern,self.order,self.alpha_on,self.key_on,self.preview,self.show_button,self.demo_button,self.verify_button,self.joint_button,self.joint_verify,self.backend,self.count,self.stress_size,self.stress_shape,self.color_mode,self.physics,self.frames,self.seed,*self.palette,self.stress_alpha,self.stress_key,self.stress_button,self.sweep_button,self.performance_preset,self.performance_load,self.performance_duration,self.performance_start,self.performance_repeat,*self._shortcuts]
  self.alpha.valueChanged.connect(lambda a:self.alpha_value.setText('%d / 255 · 不透明度 %.1f%%'%(a,a*100/255)))
  self.performance_duration.currentIndexChanged.connect(self._performance_duration_changed);self.frames.valueChanged.connect(self._performance_frames_changed)
  self.alpha.sliderReleased.connect(self.queue_show);self.material.currentIndexChanged.connect(self.update_preview);self.shape.currentIndexChanged.connect(self.update_preview);self.size.valueChanged.connect(self.update_preview);self.fg.changed.connect(self.update_preview);self.preview.picked.connect(self.key.set_rgb);self.physics.currentIndexChanged.connect(self.update_physics_hint);self.update_physics_hint();self.update_preview()
 def set_bundle(self,bundle):self.bundle=Path(bundle) if bundle else None;self.update_preview()
 def update_preview(self,*_):
  size=self.size.value();material=self.material.currentData()
  try:
   if not material:pixels=[self.fg.rgb if shape_contains(self.shape.currentData(),x,y,size) else 0xff00ff for y in range(size) for x in range(size)]
   else:
    if not self.bundle:raise ValueError('未选择素材包')
    palette,data,tiles=read_art(str(self.bundle/'projects/touhou_LAB/src/art_data.h'));off,w,h=tiles[{1:0,2:4,3:8}[material]];off//=4
    pixels=[palette[data[off+(y*h//size)*w+x*w//size]] for y in range(size) for x in range(size)]
   self.preview.set_pixels(pixels,size)
  except (OSError,ValueError,IndexError,KeyError):self.preview.image=None;self.preview.clear();self.preview.setText('源图待加载')
  if hasattr(self,'inputs'):self._enable()
 def set_section(self,section):
  if section not in ('alpha','key'):raise ValueError('未知高阶页面')
  self.section=section;self.title.setText('高阶一 · 透明度混合' if section=='alpha' else '高阶二 · 颜色键去背')
  self.tabs.setTabText(0,'透明度混合' if section=='alpha' else '去背与联合');self.tabs.setTabVisible(1,True);self.tabs.setCurrentIndex(0);self.tabs.tabBar().setVisible(True)
  self.alpha_on.setChecked(section=='alpha');self.key_on.setChecked(section=='key')
  self.joint_button.setVisible(section=='key');self.joint_verify.setVisible(section=='key');self._refresh_results()
 def update_physics_hint(self,*_):
  mode=self.physics.currentData();self.physics_hint.setText('纯绘制允许 1～20000 颗；尺寸、颜色与形状均按你的选择执行。' if not mode else '当前物理模式上限 512 颗；超出会拒绝，不自动降低数量。融合后同时报告初始、实际和最少/最多数量。')
 def set_alpha(self,value):self.alpha.setValue(value);self.queue_show()
 def show_args(self,page=None):return (page or self.section,self.material.currentData(),self.size.value(),self.shape.currentData(),self.fg.rgb,self.bg.rgb,self.alpha.value(),self.key.rgb,int(self.alpha_on.isChecked())+2*int(self.key_on.isChecked()),self.pattern.currentData(),self.order.currentData())
 def queue_show(self,page=None):
  args=self.show_args(page if isinstance(page,str) else None)
  if self.pending and self._request and self._request.operation=='show':self._coalesced_show=args;self.status.setText('参数已保留 · 等待当前显示安全完成');return True
  return self.request('show',*args)
 def start_demo(self):
  if self.pending or not self.active or not self.available or self.uncertain or self._sweep or self._demo:return False
  base=list(self.show_args());self._demo=[]
  if self.section=='alpha':
   for alpha in (0,64,128,192,255):args=list(base);args[6]=alpha;self._demo.append(tuple(args))
  else:self._demo=[tuple(base),tuple(['joint',*base[1:]])]
  args=self._demo.pop(0);ok=self.request('show',*args,_sequence=True)
  if not ok:self._demo=[]
  return ok
 def stress_args(self):
  if not self.seed.text().isdigit():raise ValueError('种子请输入1～4294967295的整数')
  args=(self.backend.currentData(),self.count.value(),self.stress_size.value(),self.stress_shape.currentData(),*[b.rgb for b in self.palette],self.color_mode.currentData(),self.stress_alpha.value(),int(self.stress_key.isChecked()),self.physics.currentData(),self.frames.value(),int(self.seed.text()))
  return validate_args('stress',args)
 def start_stress(self):
  try:args=self.stress_args()
  except ValueError as exc:self.status.setText(str(exc));return False
  return self.request('stress',*args)
 def apply_performance_args(self,args):
  self.backend.setCurrentIndex(self.backend.findData(args[0]));self.count.setValue(args[1]);self.stress_size.setValue(args[2]);self.stress_shape.setCurrentIndex(self.stress_shape.findData(args[3]))
  for button,rgb in zip(self.palette,args[4:7]):button.set_rgb(rgb)
  self.color_mode.setCurrentIndex(self.color_mode.findData(args[7]));self.stress_alpha.setValue(args[8]);self.stress_key.setChecked(bool(args[9]));self.physics.setCurrentIndex(self.physics.findData(args[10]));self.frames.setValue(args[11]);self.seed.setText(str(args[12]))
 def _performance_duration_changed(self,*_):
  value=self.performance_duration.currentData()
  if value is not None:self.frames.setValue(value)
 def _performance_frames_changed(self,value):
  index=self.performance_duration.findData(value);self.performance_duration.setCurrentIndex(max(0,index))
 def load_performance_preset(self):
  if self.pending or self._sweep or self._demo:return False
  index=self.performance_preset.currentData()
  if not index:self.performance_hint.setText('保留当前所有参数；载入预设不会自动开始测试。');return True
  args=preset_args(index,self.frames.value());self.apply_performance_args(args)
  self.performance_hint.setText('已明确载入：%s；种子1、圆形、三色、无相互作用。尚未开始，所有参数可见。'%PRESETS[index][0]);return True
 def start_performance(self):
  if not self._performance_ready():return False
  if not self.perf_capable:self.status.setText('当前固件无perf=1，不能进行新版60FPS复测。');return False
  try:
   args=performance_args(self.stress_args(),self.section)
  except ValueError as exc:self.status.setText(str(exc));return False
  self.frames.setValue(args[11]);return self._issue_performance(args,self.section)
 def _issue_performance(self,args,section):
  if not self._performance_ready():return False
  try:args=performance_args(args,section)
  except ValueError as exc:self.status.setText(str(exc));return False
  context=dict(section=section,args=list(args),target_frames=args[11],target_nominal_seconds=args[11]/60,scope='Exact requested configuration, no load degradation; sampled content/timing coverage explicit')
  return self.request('stress',*args,_performance=context)
 def repeat_performance(self):
  if not self._last_performance_case or not self._performance_ready():return False
  saved=self._last_performance_case;self.apply_performance_args(saved['args']);return self._issue_performance(tuple(saved['args']),saved['section'])
 def _performance_ready(self):
  if not self.perf_capable:self.status.setText('当前固件无perf=1，不能进行新版60FPS复测。');return False
  return bool(self.available and self.active and not self.pending and not self.uncertain and self._cancel_id is None and not self._sweep and not self._demo and not self._foreign_running)
 def start_sweep(self):
  if not self.available or not self.capable or not self.active or self.uncertain or self.pending or self._demo or self._sweep:return False
  try:base=self.stress_args()
  except ValueError as exc:self.status.setText(str(exc));return False
  rows=[]
  for size in (8,16,24,32,40,48,56,64):
   args=list(base);args[2]=size;rows.append(dict(size=size,args=args,id=None,status='NOT_RUN',result=None))
  self._sweep=dict(utc=datetime.now(timezone.utc).isoformat(),status='RUNNING',reason='',rows=rows,scope='固定其他参数，顺序尺寸实测；未执行不计通过')
  self.sweeps.append(self._sweep);self._refresh_sweep();self._sweep_due=True;self.tick();return True
 def _next_sweep(self):
  row=next((x for x in self._sweep['rows'] if x['status']=='NOT_RUN'),None)
  if row is None:self._finish_sweep('COMPLETE','八档均有完整板端结果');return
  row['status']='PENDING';row['id']=self._next_id
  if not self.request('stress',*row['args'],_sequence=True):row['status']='NOT_RUN';row['id']=None;self._finish_sweep('INCOMPLETE','请求未能派发')
  self._refresh_sweep()
 def _sweep_result(self,result):
  if not self.sweeps:return
  sweep=self.sweeps[-1]
  row=next((x for x in sweep['rows'] if x['id']==result['id']),None)
  if row is None:return
  row['result']=result;row['status']='PASS' if result['accepted_pass'] else result.get('done',{}).get('status','INCOMPLETE')
  if self._sweep:
   if result['accepted_pass']:self._sweep_due=True
   else:self._finish_sweep('INCOMPLETE','当前档未通过或未完成，停止后续档位')
  self._refresh_sweep()
 def _finish_sweep(self,status,reason):
  if self._sweep:self._sweep['status']=status;self._sweep['reason']=reason
  self._sweep=None;self._sweep_due=False;self._refresh_sweep();self._enable();self.state_changed.emit()
 def _refresh_sweep(self):
  if not self.sweeps:return
  sweep=self.sweeps[-1];self.sweep_table.setRowCount(0)
  names={'NOT_RUN':'未执行','PENDING':'执行中','PASS':'已核对','ERROR':'失败','CANCELLED':'已取消','INCOMPLETE':'未完成'}
  for row in sweep['rows']:
   r=row['result'] or {};result=r.get('result') or {};metric=r.get('metric') or {};fps=r.get('actual_fps')
   values=[str(row['size'])+'×'+str(row['size']),row['id'] or '—',names.get(row['status'],row['status']),('%s / %s'%(result['initial'],result['final'])) if result else '—',('%s / %s'%(result['minimum'],result['maximum'])) if result else '—',('%.3f'%(metric['logic_us']/1000)) if metric else '—',('%.3f'%(metric['render_us']/1000)) if metric else '—',('%.2f'%fps) if fps is not None else '—',metric.get('late','—'),metric.get('uf','—'),'通过' if r.get('accepted_pass') else '—' if not r else '未通过']
   i=self.sweep_table.rowCount();self.sweep_table.insertRow(i)
   for col,value in enumerate(values):self.sweep_table.setItem(i,col,QTableWidgetItem(str(value)))
  completed=sum(x['status']=='PASS' for x in sweep['rows']);self.sweep_status.setText('尺寸扫测 %s / 8 档 · %s · %s'%(completed,sweep['status'],sweep['reason']))
 def set_capabilities(self,caps):
  self.capable=bool(caps and caps.get('fw')=='LAB23' and caps.get('adv')==1)
  self.perf_capable=bool(self.capable and caps.get('perf')==1)
  if self.capable:self.identity=dict(firmware='LAB23',adv=1,capabilities=dict(caps));self.uncertain=True;self._need_resync=True
  else:self.uncertain=False;self._need_resync=False;self.status.setText('当前固件未启用 ADV1 · 需先完整固化高阶版；基础实验和游戏仍可使用。')
  self._enable();self.state_changed.emit()
 def set_available(self,value,status_available=None):
  status_available=value if status_available is None else status_available
  changed=self.available!=bool(value) or self.status_available!=bool(status_available);self.available=bool(value);self.status_available=bool(status_available)
  if changed:self._enable()
  if self.status_available and self.capable and self._need_resync and not self.pending:self._need_resync=False;self.request('status')
 def _enable(self):
  ready=self.available and self.capable and not self.pending and self._cancel_id is None and not self._sweep and not self._demo
  self.enter_button.setEnabled(ready and not self.active and not self.uncertain);self.exit_button.setEnabled(ready and self.active);self.sync_button.setEnabled(self.status_available and self.capable and not self.pending and self._cancel_id is None and not self._sweep and not self._demo);self.stop_button.setEnabled(self.available and self.capable and self.blocks_game and self._cancel_id is None)
  for w in self.inputs:w.setEnabled(ready and self.active and not self.uncertain)
  self.alpha.setEnabled(self.available and self.capable and self.active and not self.uncertain and not self._sweep and not self._demo and (not self.pending or (self._request and self._request.operation=='show')))
  self.export_button.setEnabled(bool(self.results or self.raw_lines));self.shape.setEnabled(self.shape.isEnabled() and self.material.currentData()==0);self.fg.setEnabled(self.fg.isEnabled() and self.material.currentData()==0)
  self.performance_start.setEnabled(self.performance_start.isEnabled() and self.perf_capable);self.performance_repeat.setEnabled(self.performance_repeat.isEnabled() and self.perf_capable and self._last_performance_case is not None)
 def _id(self):
  if self._next_id>2147483647:raise RuntimeError('请求编号耗尽，请重新打开工作台')
  value=self._next_id;self._next_id+=1;return value
 def request(self,operation,*args,_sequence=False,_performance=None):
  if not (self.status_available if operation=='status' else self.available) or not self.capable or self.pending or self._cancel_id is not None:return False
  if (self._demo or self._sweep) and not _sequence and operation not in ('status','exit'):return False
  if operation not in ('enter','status') and not self.active:return False
  if self.uncertain and operation not in ('status','exit'):return False
  if operation=='enter' and self.active:return False
  try:
   args=validate_args(operation,args);i=self._id();adv_command(i,operation,*args)
   if operation=='stress' and args[11]>3600 and not self.perf_capable:raise ValueError('超过3600帧需支持perf=1的新固件，不会静默缩短。')
  except ValueError as exc:self.status.setText(str(exc));return False
  request_identity=dict(self.identity,ui_section=(_performance or {}).get('section',self.section))
  self._request=AdvRequest(i,operation,args,self.clock()+timeout_for(operation,args),require_timing=self.perf_capable and operation in ('show','verify','stress'),request_identity=request_identity);self.pending=True
  self._request_started=self.clock();self._last_wait_second=-1;self._live_progress=None
  if operation=='stress':self.performance_progress.setRange(0,args[11]);self.performance_progress.setValue(0);self.performance_live.setText('已请求 %d 帧 · 等待板端真实进度；主机时间不是板端FPS。'%args[11])
  if _performance:
   context=dict(_performance,id=i,status='PENDING',identity=dict(self.identity));self._performance_contexts[i]=context;self.performance_cases.append(context);self._last_performance_case=context
   self.performance_hint.setText('已登记 #%d · 高阶%s · N%d · %d×%d · Alpha%d · Key%s · 种子%d · %d帧；测试中不改负载。'%(i,'一' if context['section']=='alpha' else '二',args[1],args[2],args[2],args[8],'开' if args[9] else '关',args[12],args[11]))
  self.status.setText('请求 #%d · %s · 等待板端'%(i,operation));self.log.appendPlainText('#%d %s %s'%(i,operation,' '.join(str(x) for x in args)));self._enable();self.state_changed.emit();self.command_requested.emit(i,operation,list(args));return True
 def ingest(self,reply):
  if not isinstance(reply,dict):return
  if ((self._request and self.clock()>=self._request.deadline) or (self._cancel_id is not None and self.clock()>=self._cancel_deadline)):self.tick()
  self.raw_lines.append(dict(reply))
  if reply.get('id')==self._cancel_id:
   if reply['kind_line']=='ADV_DONE' and reply.get('op')=='cancel':
    self.log.appendPlainText('取消送达 #%d · %s；继续等待原任务结束'%(self._cancel_id,reply['status']));self._cancel_id=None
    if reply['status']!='PASS':self.uncertain=True;self._exit_after=False
    if self._foreign_running:self._foreign_check_at=self.clock()+.25
    self._maybe_exit();self._enable();self.state_changed.emit()
   return
  r=self._request
  if r is None or not r.feed(reply):return
  if reply['kind_line']=='ADV_PROGRESS':
   self._live_progress=dict(reply);self.performance_progress.setValue(reply['frames']);self._show_live_progress(reply);return
  if reply['kind_line']=='ADV_ACK':self.status.setText('请求 #%d 已接收 · 等待实际完成'%r.request_id)
  elif reply['kind_line']=='ADV_PLAN':self.plan_label.setText('任务 #%d · %s · 参数 %s · 预登记 %s · %s核对 · Key #%06X'%(r.request_id,r.operation,reply['args'],reply['expected'],'最终帧抽样' if reply['scope']=='sampled' else '全测试区域',reply['key']))
  elif reply['kind_line']=='ADV_DONE':
   result=r.finish(reply);self._record_performance_case(result);self.results.append(result);self.pending=False;self._request=None;self.active=bool(reply['active'])
   if r.operation=='stress' and result.get('result'):
    self.performance_progress.setValue(result['result']['frames']);self.performance_wait.setText('主机等待 %.1f秒 · 板端实际计时 %.3f秒；二者口径不同。'%(max(0,self.clock()-self._request_started),(result.get('metric') or {}).get('elapsed_us',0)/1e6))
   if r.operation=='status':
    state=result.get('state');self._foreign_running=bool(state and state['running']);self.uncertain=not result['accepted_pass'] or self._foreign_running
    if self._foreign_running and self._exit_after:self._foreign_check_at=self.clock()+.25
   elif result['accepted_pass']:self.uncertain=False
   if reply['code']=='LEGACY_ACTIVE':self.active=False;self.uncertain=False
   self.status.setText('请求 #%d · %s'%(r.request_id,'已完整核对' if result['accepted_pass'] else '未通过 / 未完成：'+'；'.join(result['reasons'])))
   self.log.appendPlainText(self.status.text());self._sweep_result(result);self._refresh_results()
   if not result['accepted_pass']:self._demo=[];self._coalesced_show=None
   elif self._demo or self._coalesced_show:self._due=True
   if r.operation=='status' and self._stop_resync:
    self._stop_resync=False
    if not result['accepted_pass']:self._exit_after=False
    elif self._foreign_running:self.stop_and_return()
   self._maybe_exit();self._enable();self.state_changed.emit()
 def _record_performance_case(self,result):
  context=self._performance_contexts.get(result['id'])
  if context:
   context.update(status=(result.get('done') or {}).get('status',(result.get('reasons') or ['INCOMPLETE'])[0]),accepted_pass=result.get('accepted_pass',False),long_60fps_pass=result.get('long_60fps_pass',False))
   result['performance_case']=dict(context)
 def _show_live_progress(self,p):
  fps=p['swaps']*1e6/p['elapsed_us'] if p['elapsed_us'] else None
  self.performance_live.setText('板端 %d / %d帧 · 实际换新帧 %d · 实测 %.3f秒 / %.2fFPS · 扫描%d / 错过换帧%d · >16.667ms计数%d · UF%d · 16点签名变化%d（非最终验收）'%(p['frames'],p['total'],p['swaps'],p['elapsed_us']/1e6,fps or 0,p['scan_total'],p['missed_scans'],p['late'],p['uf'],p['pixel_changes']))
 def _refresh_results(self):
  relevant=[r for r in self.results if all(r.get(k) for k in ('plan','result','metric','check')) and (r['op']=='stress' or (r['op'] in ('show','verify') and ((r['args'][0]=='alpha') if self.section=='alpha' else r['args'][0] in ('key','joint'))))]
  self.table.setRowCount(0)
  for entry in relevant[-8:]:
   r=entry['result'];m=entry['metric'];c=entry['check'];fps=entry['actual_fps'];values=[entry['id'],entry['op'],str(r['initial'])+' / '+str(r['final']),str(r['minimum'])+' / '+str(r['maximum']),'%.3f'%(m['logic_us']/1000),'%.3f'%(m['render_us']/1000),'%.3f'%(m['wait_us']/1000),'%.2f'%fps if fps is not None else '—',m['late'],m['uf'],'通过' if entry['accepted_pass'] else '未通过']
   row=self.table.rowCount();self.table.insertRow(row)
   for col,value in enumerate(values):self.table.setItem(row,col,QTableWidgetItem(str(value)))
  if not relevant:self.path_detail.setText('绘制路径诊断尚未提供；不按算法名称判断60FPS。');self.plan_label.setText('本页任务预登记：—');self.summary.setText('本页等待真实板端结果');self.detail.setText('计时、抽样范围与碰撞/融合次数将在完成后显示。');return
  entry=relevant[-1];r=entry['result'];m=entry['metric'];c=entry['check'];timing=entry.get('timing');path=entry.get('path')
  if path:
   self.path_detail.setText('真实路径：%s · 原因：%s。测量窗口已完成OP2作业%d次 / 描述符累计%d条（不是每帧值）。\n预热预计算%d步 / %.3fms；窗口内实际计算%d步，总计%d步。预热计算耗时单列，不能用窗口少一步声称逻辑加速；是否60FPS仍看实际换帧与扫描。'%(PATH_NAMES[path['path']],PATH_REASON_NAMES[path['reason']],path['passes'],path['micro'],path['prime_steps'],path['prime_logic_us']/1000,path['measured_steps'],path['total_steps']))
   if path['path'] in ('rowrun','rowrun_mixed'):self.path_detail.setText(self.path_detail.text()+'\nOP2累计不含底部不足8行的额外填充；容量回退保留完整该帧和全部精灵，OP2为0也可能是全部回退。')
  else:self.path_detail.setText('本次未提供可选绘制路径诊断；不按pipeline或算法名称推定60FPS。')
  perf=('60FPS长测通过（逐扫描换新帧）' if entry.get('long_60fps_pass') else '短测观察，不作为稳定长测通过' if entry['op']=='stress' and entry['args'][11]<36000 else '60FPS长测条件未通过')
  self.summary.setText('最近请求 #%d · %s · %s'%(entry['id'],'正确性已核对' if entry['accepted_pass'] else '未通过 / 未完成',(perf+' · 实际 %.2fFPS'%entry['actual_fps']) if entry['actual_fps'] is not None else '数值实验'))
  self.detail.setText('碰撞候选 %d · 碰撞 %d · 融合 %d · 检查像素 %d · 实际画面 %d · 重放 %d · %s。帧率不等于显示扫描60Hz；此压力结果不代表完整东方战斗。'%(r['pairs'],r['collisions'],r['merges'],c['checked'],c['actual'],c['replayed'],'实际最终帧64个屏幕点抽样' if entry['plan']['scope']=='sampled' else '全1280×720后台读回检查（写入结果标签前）'))
  if timing and entry['op']=='stress':
   self.performance_live.setText('最终板端计时 %.3f秒 · %d帧 / 实际换新帧%d · 实际%.2fFPS · >16.667ms计数%d · UF%d'%(m['elapsed_us']/1e6,r['frames'],m['swaps'],entry['actual_fps'] or 0,m['late'],m['uf']))
   self.timing_detail.setText('显式预热%d帧 · 实际扫描%d · 最大扫描间隔%d · 错过换帧%d。呈现间隔 min/max %.3f/%.3fms，旧16.667ms计数原样列出，不能代替错过换帧。\n逻辑总%.3fms / 绘制墙钟%.3fms（可含逻辑交叠，不能相加）；引擎%.3fms，交叠%.3fms；路径%s。\n实际前台16点FNV %08X → %08X，变化%d次；不是全帧hash，透明/遮挡可重复。粒子状态FNV %08X → %08X，不是屏幕hash。'%(timing['warmup_frames'],timing['scan_total'],timing['max_scan_gap'],timing['missed_scans'],timing['min_frame_us']/1000,timing['max_frame_us']/1000,m['logic_us']/1000,m['render_us']/1000,timing['hw_us']/1000,timing['overlap_us']/1000,'安全快照交叠' if timing['pipeline'] else '串行',timing['pixel_first'],timing['pixel_last'],timing['pixel_changes'],timing['state_first'],timing['state_last']))
  else:self.timing_detail.setText('本次数值实验不计算压力帧率；无perf=1完整时序结果时不认证60FPS长测。')
 def stop_and_return(self):
  if not self.available or not self.capable:return False
  self._demo=[];self._coalesced_show=None;self._due=False;self._exit_after=True
  if self._sweep:self._finish_sweep('CANCELLED','用户停止，后续档位未执行')
  if self.uncertain and not self.pending and not self._foreign_running:
   self._stop_resync=True;return self.request('status')
  if self.pending or self._foreign_running:
   if self._cancel_id is not None:return False
   self._cancel_id=self._id();self._cancel_deadline=self.clock()+8;self.command_requested.emit(self._cancel_id,'cancel',[]);self.status.setText('已请求停止 · 等待原任务安全结束');self._enable();self.state_changed.emit();return True
  self._maybe_exit();return True
 def _maybe_exit(self):
  if self._exit_after and not self.pending and self._cancel_id is None and not self._foreign_running:
   self._exit_after=False
   if self.active:self.request('exit')
 def tick(self):
  now=self.clock()
  if self._cancel_id is not None and now>=self._cancel_deadline:
   self.results.append(dict(id=self._cancel_id,op='cancel',accepted_pass=False,reasons=['取消送达超时'],raw=[]));self._cancel_id=None;self.uncertain=True;self._exit_after=False;self._enable();self.state_changed.emit()
  if self._request and now>=self._request.deadline:
   r=self._request;result=dict(id=r.request_id,op=r.operation,args=list(r.args),accepted_pass=False,reasons=['TIMEOUT'],progress=list(r.progress),raw=list(r.raw));self._record_performance_case(result);self.results.append(result);self._sweep_result(result);self._request=None;self.pending=False;self.uncertain=True;self._demo=[];self._coalesced_show=None;self._exit_after=False;self.status.setText('请求超时 · 未计通过；请重新核对板端状态');self._enable();self.state_changed.emit()
  if self._request and self._request.operation=='stress':
   elapsed=max(0,now-self._request_started)
   if int(elapsed)!=self._last_wait_second:self._last_wait_second=int(elapsed);self.performance_wait.setText('主机已等待 %.0f秒 · 板端实测进度%s；主机时间不代替板端FPS。'%(elapsed,('%.3f秒'% (self._live_progress['elapsed_us']/1e6)) if self._live_progress else '尚未收到'))
  if self._foreign_check_at and now>=self._foreign_check_at and not self.pending and self._cancel_id is None:self._foreign_check_at=0;self.request('status')
  if self._sweep_due and self._sweep and not self.pending and not self.uncertain and self.available:
   self._sweep_due=False;self._next_sweep()
  if self._due and not self.pending and not self.uncertain and self.available:
   self._due=False;args=self._coalesced_show or (self._demo.pop(0) if self._demo else None);self._coalesced_show=None
   if args:self.request('show',*args,_sequence=True)
 def disconnected(self):
  if self._request:
   r=self._request;result=dict(id=r.request_id,op=r.operation,args=list(r.args),accepted_pass=False,reasons=['DISCONNECTED'],progress=list(r.progress),raw=list(r.raw));self._record_performance_case(result);self.results.append(result);self._sweep_result(result)
  if self._sweep:self._finish_sweep('INCOMPLETE','连接断开')
  self._request=None;self._cancel_id=None;self.pending=self.active=self.available=self.status_available=self.capable=self.perf_capable=self.uncertain=False;self._need_resync=False;self._foreign_running=False;self._foreign_check_at=0;self._demo=[];self._coalesced_show=None;self._exit_after=False;self._stop_resync=False;self.status.setText('连接已断开 · 未完成结果保留；重连后重新核对状态');self._enable();self.state_changed.emit()
 def export_document(self):
  return dict(schema='ti60_adv_gui_evidence_v2_lab60',utc=datetime.now(timezone.utc).isoformat(),identity=dict(self.identity),results=list(self.results),size_sweeps=list(self.sweeps),performance_cases=list(self.performance_cases),raw=list(self.raw_lines),notes=['源图示意不是板端视频','full为结果标签写入前全1280×720后台读回检查，包含全部测试区域及目标外未变像素；不代表任意游戏全帧证明','压力场为实际最终帧64个屏幕点抽样','碰撞包络为圆形，融合配色在选定调色板内','纯绘制和物理计算分别计时；实际数量不会冒充初始数量','短测只作观察；36000帧为约10分钟目标，真实经过时间另列','实时前台16点FNV与最终64点像素核对不同，均不是全帧hash','逻辑与绘制墙钟可交叠，不能相加；原16.667ms计数不等于错过换帧','CPU及64×64不纳入本轮60FPS资格，不会自动减少数量','高阶帧率不替代完整东方战斗60FPS验收','本页不自动认证物理冷启动','行段扩展超20000时整帧精确矩形回退，rowrun_mixed可包含全部回退；OP2累计不含底部额外填充','可选ADV_PATH报告真实路径/回退原因，OP2作业和描述符是测量窗口累计，不是每帧','预热预计算步骤及CPU耗时单列；窗口measured_steps加prime_steps等于total_steps，不能把少一步窗口CPU耗时当加速'])
