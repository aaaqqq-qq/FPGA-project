"""Offline checks for a proposed persistent LAB1 release.

This draft schema needs root review against the actual flash/boot layout. It
contains no programmer, device discovery, serial access or RAM loader fallback.
An offline-valid package is not evidence that flash or cold boot passed.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
import struct
import zlib
from typing import Any

SCHEMA = "ti60-persistent-profile-v1-draft"
PERSISTENT_IMAGE_SCHEMA = "ti60_persistent_image_v1"
CURRENT_ELF_SHA256 = "79dd552bc4d473c1b9bc5d3ad8d872d138f342def4bdd8af3e44d91587c10071"
CURRENT_PLATFORM_SHA256 = "08d6dd5db3481d7213556413b7e3858f8d075366d8599e030c8cd31519f4ebb7"
BOOT_MARKER = "PHASE BATTLE v3 LAB23 PC CONTROL GAME60_PIPELINE_5"
_ROLES = frozenset(("firmware_elf", "platform_bitstream", "bootloader_stage", "full_flash_image"))


class ProfileValidationError(ValueError):
    pass


@dataclass(frozen=True)
class Artifact:
    role: str
    path: Path
    size_bytes: int
    sha256: str


@dataclass(frozen=True)
class OfflinePersistentProfile:
    manifest_sha256: str
    artifacts: tuple[Artifact, ...]
    flash_capacity_bytes: int
    needs_root_review: bool
    status: str = "OFFLINE_VALID_ONLY"
    flash_programmed: bool = False
    flash_readback_verified: bool = False
    cold_boot_verified: bool = False
    readback_required: bool = True
    new_boot_required: bool = True
    cold_boot_required: bool = True
    boot_marker: str = BOOT_MARKER
    partitions: tuple = ()

    @property
    def reviewed(self) -> bool:
        """Technical review state, never a request for additional user consent."""
        return not self.needs_root_review

    @property
    def requires_review(self) -> bool:
        return self.needs_root_review

    @property
    def image_path(self) -> Path:
        return next(item.path for item in self.artifacts if item.role == "full_flash_image")

    @property
    def image_sha256(self) -> str:
        return next(item.sha256 for item in self.artifacts if item.role == "full_flash_image")


def _require(condition, message):
    if not condition:
        raise ProfileValidationError(message)


def _uint(value: Any, label: str, minimum=0) -> int:
    _require(type(value) is int and minimum <= value <= 0xFFFFFFFF, f"invalid {label}")
    return value


def _hash_text(value: Any, label: str) -> str:
    _require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value), f"invalid {label}")
    return value


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        _require(key not in result, f"duplicate manifest key: {key}")
        result[key] = value
    return result


def verify_artifact(root: str | Path, role: str, specification: dict) -> Artifact:
    """Reject traversal, missing files, length mismatches and changed bytes."""
    _require(isinstance(specification, dict), f"invalid artifact {role}")
    relative = specification.get("path")
    _require(isinstance(relative, str) and bool(relative) and ":" not in relative
             and not relative.startswith(("/", "\\")), f"artifact path must be relative: {role}")
    _require(".." not in relative.replace("\\", "/").split("/"), f"artifact traversal: {role}")
    base = Path(root).resolve(strict=True)
    path = (base / relative).resolve(strict=True)
    _require(path.is_relative_to(base) and path.is_file(), f"artifact escaped release: {role}")
    size = _uint(specification.get("size_bytes"), f"{role} size", 1)
    expected = _hash_text(specification.get("sha256"), f"{role} hash")
    _require(path.stat().st_size == size, f"artifact length mismatch: {role}")
    actual = sha256_file(path)
    _require(actual == expected, f"artifact hash mismatch: {role}")
    return Artifact(role, path, size, actual)


def _ranges(items: Any, capacity: int, label: str) -> list[dict]:
    _require(isinstance(items, list), f"{label} must be an explicit list")
    result = []
    names = set()
    for item in items:
        _require(isinstance(item, dict), f"invalid {label} entry")
        name = item.get("name")
        _require(isinstance(name, str) and name and name not in names, f"duplicate/empty {label} name")
        names.add(name)
        offset = _uint(item.get("offset"), f"{label} offset")
        length = _uint(item.get("length"), f"{label} length", 1)
        _require(offset + length <= capacity, f"{label} exceeds flash capacity")
        result.append(dict(item, offset=offset, length=length))
    ordered = sorted(result, key=lambda row: row["offset"])
    for left, right in zip(ordered, ordered[1:]):
        _require(left["offset"] + left["length"] <= right["offset"], f"overlapping {label}")
    return ordered


def validate_profile(manifest_path: str | Path, *, expected_flash_capacity: int,
                     approved_manifest_sha256: str | None = None,
                     expected_elf_sha256: str = CURRENT_ELF_SHA256,
                     expected_platform_sha256: str = CURRENT_PLATFORM_SHA256) -> OfflinePersistentProfile:
    """Validate a complete draft without inventing flash offsets or capacity.

    Mandatory schema fields: schema/profile_id/board/release/clock_mhz/storage,
    artifacts (four roles), flash (capacity_bytes, erase_block_bytes,
    program_ranges, protected_ranges), verification, and boot_marker.
    program_ranges are the reviewed complete flash package partitions, each
    with a SHA256 over those exact bytes in the full image. Protected ranges
    are explicit even when empty and may not intersect an erase range.

    The optional manifest pin records root's review of bootloader, component
    encoding/composition and geometry. Without it the result requires review.
    There is deliberately no function here that turns this into a flash PASS.
    """
    path = Path(manifest_path).resolve(strict=True)
    raw = path.read_bytes()
    try:
        data = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=_unique_object)
    except (ValueError, UnicodeError) as exc:
        raise ProfileValidationError("invalid persistent manifest JSON") from exc
    _require(isinstance(data, dict), "persistent manifest must be an object")
    for key, expected in {"schema": SCHEMA, "profile_id": "touhou_LAB", "board": "Ti60F225I3-V4",
                          "release": "LAB23", "clock_mhz": 100, "storage": "spi_flash",
                          "boot_marker": BOOT_MARKER}.items():
        _require(data.get(key) == expected and (key != "clock_mhz" or type(data.get(key)) is int), f"invalid {key}")
    verification = data.get("verification")
    _require(isinstance(verification, dict), "verification policy missing")
    for key in ("full_image_hash_required", "flash_readback_required", "new_boot_required", "cold_boot_required"):
        _require(verification.get(key) is True, f"required persistent verification disabled: {key}")
    specs = data.get("artifacts")
    _require(isinstance(specs, dict) and set(specs) == _ROLES, "four complete persistent artifacts required")
    artifacts = tuple(verify_artifact(path.parent, role, specs[role]) for role in sorted(_ROLES))
    by_role = {item.role: item for item in artifacts}
    _require(by_role["firmware_elf"].sha256 == _hash_text(expected_elf_sha256, "ELF pin"), "not the pinned current LAB1 ELF")
    _require(by_role["platform_bitstream"].sha256 == _hash_text(expected_platform_sha256, "platform pin"), "not the pinned current platform")
    flash = data.get("flash")
    _require(isinstance(flash, dict), "flash geometry missing")
    capacity = _uint(flash.get("capacity_bytes"), "flash capacity", 1)
    _require(capacity == _uint(expected_flash_capacity, "root-pinned flash capacity", 1), "flash capacity differs from reviewed board")
    block = _uint(flash.get("erase_block_bytes"), "erase block", 1)
    _require(block & (block - 1) == 0 and capacity % block == 0, "invalid erase geometry")
    _require(by_role["full_flash_image"].size_bytes == capacity, "full image must cover declared flash capacity")
    programs = _ranges(flash.get("program_ranges"), capacity, "program ranges")
    protected = _ranges(flash.get("protected_ranges"), capacity, "protected ranges")
    _require(bool(programs), "no persistent program ranges")
    # Each required boot component must be explicitly mapped. Encoding of the
    # bit/ELF into these regions needs root review, not an inferred offset.
    _require({row.get("component") for row in programs} >= {"platform", "bootloader", "firmware"},
             "persistent layout must map platform, bootloader and firmware")
    image_path = by_role["full_flash_image"].path
    with image_path.open("rb") as stream:
        for region in (*programs, *protected):
            expected = _hash_text(region.get("sha256"), "region hash")
            stream.seek(region["offset"])
            _require(hashlib.sha256(stream.read(region["length"])).hexdigest() == expected,
                     f"full image region mismatch: {region['name']}")
    for region in programs:
        erase_begin = region["offset"] // block * block
        erase_end = (region["offset"] + region["length"] + block - 1) // block * block
        for reserved in protected:
            _require(erase_end <= reserved["offset"] or erase_begin >= reserved["offset"] + reserved["length"],
                     f"erase touches protected range: {reserved['name']}")
    manifest_hash = hashlib.sha256(raw).hexdigest()
    if approved_manifest_sha256 is not None:
        _require(manifest_hash == _hash_text(approved_manifest_sha256, "reviewed manifest pin"), "manifest differs from root-reviewed release")
    return OfflinePersistentProfile(manifest_hash, artifacts, capacity, approved_manifest_sha256 is None)


def _artifact_path(base: Path, role: str, name: Any, expected: Any, *, relative: bool) -> Artifact:
    """External ELF/PAR sources are allowed; generated outputs stay in out/."""
    _require(isinstance(name, str) and bool(name), f"missing path: {role}")
    if relative:
        _require(not Path(name).is_absolute() and ":" not in name and not name.startswith(("/", "\\"))
                 and ".." not in name.replace("\\", "/").split("/"), f"output escaped release: {role}")
    path = (base / name).resolve(strict=True)
    if relative:
        _require(path.is_relative_to(base), f"output escaped release: {role}")
    _require(path.is_file(), f"not a file: {role}")
    expected = _hash_text(expected, f"{role} SHA256")
    _require(sha256_file(path) == expected, f"artifact hash mismatch: {role}")
    return Artifact(role, path, path.stat().st_size, expected)


def _decode_hex(path: Path) -> bytes:
    """Efinity byte-hex, including its intentional metadata prefix."""
    try:
        return bytes.fromhex(path.read_text(encoding="ascii"))
    except (ValueError, UnicodeError) as exc:
        raise ProfileValidationError(f"invalid byte-hex: {path.name}") from exc


def _elf_loads(path: Path) -> tuple[int, list[tuple[int, bytes, int]]]:
    raw = path.read_bytes()
    _require(len(raw) >= 52 and raw[:6] == b"\x7fELF\x01\x01", "ELF must be 32-bit little-endian")
    header = struct.unpack_from("<16sHHIIIIIHHHHHH", raw)
    _require(header[2] == 243 and header[3] == 1, "ELF must be RISC-V version 1")
    offset, entry_size, count = header[5], header[9], header[10]
    _require(entry_size == 32 and 0 < count <= 128 and offset + count * entry_size <= len(raw), "invalid ELF program headers")
    result = []
    for index in range(count):
        kind, file_offset, virtual, physical, file_bytes, memory_bytes, flags, alignment = struct.unpack_from("<IIIIIIII", raw, offset + index * entry_size)
        if kind != 1:
            continue
        _require(file_bytes <= memory_bytes and file_offset + file_bytes <= len(raw), "invalid ELF PT_LOAD span")
        _require(physical == virtual, "ELF PT_LOAD address alias requires separate review")
        result.append((physical, raw[file_offset:file_offset + file_bytes], memory_bytes))
    _require(bool(result), "ELF has no PT_LOAD")
    return header[4], result


def load_profile(manifest_path: str | Path, *, reviewed: bool = False,
                 approved_manifest_sha256: str | None = None,
                 expected_elf_sha256: str = CURRENT_ELF_SHA256,
                 expected_platform_sha256: str = CURRENT_PLATFORM_SHA256) -> OfflinePersistentProfile:
    """Verify fw agent's complete 8 MiB two-stage image and build a profile.

    ``reviewed=True`` records root's completed technical review under the user's
    existing authorization. It is not a user permission/confirmation workflow.
    Neither value can turn offline checks into readback or cold-boot evidence.
    """
    _require(type(reviewed) is bool, "reviewed must be a technical-review boolean")
    path = Path(manifest_path).resolve(strict=True)
    raw = path.read_bytes()
    try:
        data = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=_unique_object)
    except (ValueError, UnicodeError) as exc:
        raise ProfileValidationError("invalid persistent manifest JSON") from exc
    _require(isinstance(data, dict) and data.get("schema") == PERSISTENT_IMAGE_SCHEMA, "unsupported persistent image schema")
    _require(data.get("release") == "LAB23" and data.get("firmware") == "LAB23"
             and data.get("boot_marker") == BOOT_MARKER and data.get("release_id") == "GAME60_PIPELINE_5"
             and data.get("required_capabilities") == {"adv": 1, "img": 1, "perf": 1, "game_load": 1, "gsizes": 7, "batch32": 1, "motion": 1, "pref": 1, "pipe": 1, "pref8": 1}, "not the current GAME60_PIPELINE_5 image identity")
    _require(data.get("board") == "Ti60F225I3-V4" and type(data.get("clock_mhz")) is int
             and data["clock_mhz"] == 100 and type(data.get("flash_size")) is int
             and data["flash_size"] == 8 * 1024 * 1024, "persistent board/clock/capacity mismatch")
    _require(data.get("hardware_accessed") is False and data.get("flash_written") is False,
             "image manifest must remain offline build evidence; use a separate board receipt")
    _require(data.get("status") in {"OFFLINE_BUILT_NOT_BOARD_TESTED", "OFFLINE_VERIFIED_NOT_BOARD_TESTED"}, "invalid offline image status")
    base = path.parent
    sections = {}
    for name in ("elf", "platform", "stage1", "stage2", "payload", "image"):
        _require(isinstance(data.get(name), dict), f"missing image section: {name}")
        sections[name] = data[name]
    app, platform, stage1, stage2, payload, image = [sections[name] for name in ("elf", "platform", "stage1", "stage2", "payload", "image")]
    definitions = (
        ("firmware_elf", app, "path", "sha256", False),
        ("platform_bitstream", platform, "bit_path", "bit_sha256", False),
        ("platform_hex", platform, "hex_path", "hex_sha256", False),
        ("bootloader_stage", stage1, "path", "sha256", True),
        ("stage2_binary", stage2, "bin_path", "bin_sha256", True),
        ("stage2_elf", stage2, "elf_path", "elf_sha256", True),
        ("firmware_payload", payload, "path", "sha256", True),
        ("full_flash_image", image, "bin_path", "bin_sha256", True),
        ("full_flash_hex", image, "hex_path", "hex_sha256", True),
    )
    artifacts = tuple(_artifact_path(base, role, item.get(filename), item.get(hashname), relative=relative)
                      for role, item, filename, hashname, relative in definitions)
    files = {item.role: item for item in artifacts}
    for role in ("firmware_elf", "platform_bitstream", "platform_hex"):
        _require(files[role].path.is_relative_to(base.parent),
                 f"source artifact escaped persistent bundle: {role}")
    _require(files["firmware_elf"].sha256 == _hash_text(expected_elf_sha256, "ELF pin"), "not the pinned current LAB1 ELF")
    _require(files["platform_bitstream"].sha256 == _hash_text(expected_platform_sha256, "platform pin"), "not the pinned current platform")
    app_entry, app_segments = _elf_loads(files["firmware_elf"].path)
    _require(len(app_segments) == 1, "current application must have exactly one PT_LOAD")
    address, app_bytes, memory_bytes = app_segments[0]
    _require(app_entry == address == 0x1000 and app.get("entry") == app_entry and app.get("load_address") == address,
             "application entry/load address mismatch")
    _require(0 < len(app_bytes) <= memory_bytes <= 0x100000 - address
             and app.get("file_bytes") == len(app_bytes)
             and app.get("memory_bytes") == memory_bytes and BOOT_MARKER.encode("ascii") in app_bytes,
             "application PT_LOAD length/memory span mismatch")
    _require(app.get("crc32") == f"{zlib.crc32(app_bytes) & 0xffffffff:08x}", "application CRC32 mismatch")
    payload_bytes = files["firmware_payload"].path.read_bytes()
    _require(payload.get("flash_offset") == 0x400000 and payload.get("bytes") == len(app_bytes)
             and payload_bytes == app_bytes, "flash payload is not complete current PT_LOAD")
    platform_bytes = _decode_hex(files["platform_hex"].path)
    _require(platform.get("flash_offset") == 0 and platform.get("decoded_bytes") == len(platform_bytes)
             and platform.get("decoded_sha256") == hashlib.sha256(platform_bytes).hexdigest()
             and 0 < len(platform_bytes) <= 0x380000, "platform flash prefix mismatch")
    provenance = data.get('platform_build_provenance')
    _require(isinstance(provenance,dict) and provenance.get('schema')=='ti60_verified_hw_build_v1'
             and provenance.get('status')=='PASS', 'new platform build provenance incomplete')
    _require('legacy_platform_provenance' not in data, 'new hardware cannot claim legacy-platform equality')
    review_relative=provenance.get('review_path')
    _require(isinstance(review_relative,str) and review_relative and ':' not in review_relative,
             'invalid hardware review path')
    review_path=(base/review_relative).resolve()
    _require(review_path.is_relative_to(base.parent), 'hardware review escaped bundle')
    from hardware_gate import validate_review
    try: hardware=validate_review(review_path,provenance.get('review_sha256'),base.parent)
    except (ValueError,KeyError,OSError) as exc:raise ProfileValidationError('new platform evidence rejected: '+str(exc)) from exc
    _require(hardware['bit_sha256']==files['platform_bitstream'].sha256
             and hardware['hex_sha256']==files['platform_hex'].sha256
             and provenance.get('bit_sha256')==hardware['bit_sha256']
             and provenance.get('hex_sha256')==hardware['hex_sha256']
             and provenance.get('lbf_sha256')==hardware['lbf_sha256'],
             'platform artifacts differ from the full same-source hardware review')
    _require(data.get('pc_elf_ram_upload') is False and data.get('ram_fallback_allowed') is False,
             'RAM upload/fallback forbidden')
    stage1_bytes = files["bootloader_stage"].path.read_bytes()
    stage2_bytes = files["stage2_binary"].path.read_bytes()
    _require(stage1.get("flash_offset") == 0x380000 and stage1.get("copy_bytes") == 124 * 1024
             and len(stage1_bytes) == 124 * 1024 and stage1.get("entry") == 0x1000,
             "stage1 legacy ROM window mismatch")
    unpadded = _uint(stage1.get("unpadded_bytes"), "stage1 unpadded bytes", 1)
    embedded = _uint(stage1.get("stage2_embedded_offset"), "stage2 embedded offset")
    _require(unpadded <= len(stage1_bytes) and embedded + len(stage2_bytes) <= unpadded
             and stage1_bytes[embedded:embedded + len(stage2_bytes)] == stage2_bytes
             and stage1_bytes[unpadded:] == b"\xff" * (len(stage1_bytes) - unpadded),
             "stage1 embedded stage2/padding mismatch")
    _require(stage2.get("run_address") == 0xF00000 and stage2.get("stack_pointer") == 0xFFF000,
             "stage2 DDR run/stack address mismatch")
    stage2_entry, stage2_segments = _elf_loads(files["stage2_elf"].path)
    _require(stage2_entry == 0xF00000, "stage2 ELF entry mismatch")
    binary_end = 0
    for start, segment, mem in stage2_segments:
        relative = start - 0xF00000
        _require(relative >= 0 and start + mem <= 0xFFF000
                 and relative + len(segment) <= len(stage2_bytes)
                 and stage2_bytes[relative:relative + len(segment)] == segment,
                 "stage2 ELF/binary memory mapping mismatch")
        binary_end = max(binary_end, relative + len(segment))
    _require(binary_end == len(stage2_bytes), "stage2 binary has undeclared trailing bytes")
    image_bytes = files["full_flash_image"].path.read_bytes()
    _require(image.get("bytes") == 8 * 1024 * 1024 and len(image_bytes) == 8 * 1024 * 1024,
             "persistent image must be the complete 8 MiB device image")
    _require(_decode_hex(files["full_flash_hex"].path) == image_bytes, "full bin/hex image mismatch")
    preserve=data.get('preservation_source')
    _require(isinstance(preserve,dict) and preserve.get('bytes')==8388608
             and preserve.get('fresh_current_board_backup') is False,
             'missing offline full preservation snapshot')
    preserve_file=_artifact_path(base,'preservation snapshot',preserve.get('path'),preserve.get('sha256'),relative=True)
    preservation_bytes=preserve_file.path.read_bytes()
    _require(len(preservation_bytes)==8388608,'preservation snapshot must be full8MiB')
    expected = bytearray(preservation_bytes)
    partitions = []
    for name, start, block in (("platform", 0, platform_bytes), ("stage1", 0x380000, stage1_bytes),
                               ("payload", 0x400000, app_bytes)):
        expected[start:start + len(block)] = block
        partitions.append(dict(name=name, offset=start, length=len(block), sha256=hashlib.sha256(block).hexdigest()))
    _require(image_bytes == expected, "image composition/gaps differ; old slots or undeclared bytes remain")
    sources = data.get("sources")
    _require(isinstance(sources, dict) and bool(sources), "bootloader source identities missing")
    for relative, expected_hash in sources.items():
        _artifact_path(base.parent, "loader source", relative, expected_hash, relative=True)
    manifest_hash = hashlib.sha256(raw).hexdigest()
    if approved_manifest_sha256 is not None:
        _require(manifest_hash == _hash_text(approved_manifest_sha256, "reviewed manifest pin"), "manifest differs from reviewed image")
    return OfflinePersistentProfile(manifest_hash, artifacts, 8 * 1024 * 1024,
                                    not (reviewed or approved_manifest_sha256 is not None),
                                    partitions=tuple(partitions))


# Root can construct the fixed target after technical review; no user prompt.
construct_profile = load_profile
