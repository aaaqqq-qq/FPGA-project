"""Bounded ADV1 wire format and complete, identity-matched result validation.

No ports, processes, Qt, or device access. Matches docs/adv_protocol.json.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import re

OPS={'enter','status','exit','cancel','show','verify','stress'}
FIELDS={
 'ADV_ACK':('id','op','status'),
 'ADV_PLAN':('id','op','task','args','expected','scope','key'),
 'ADV_STATE':('id','op','active','running'),
 'ADV_RESULT':('id','op','task','frames','cases','initial','final','minimum','maximum','pairs','collisions','merges'),
 'ADV_METRIC':('id','op','task','logic_us','render_us','wait_us','elapsed_us','swaps','uf','late'),
 'ADV_CHECK':('id','op','task','errors','guards','source','checked','actual','replayed'),
 'ADV_TIMING':('id','op','task','scan_total','max_scan_gap','missed_scans','pixel_changes','pixel_first','pixel_last','max_logic_us','max_render_us','max_frame_us','min_frame_us','pipeline','state_first','state_last','sample_points','hw_us','overlap_us','warmup_frames'),
 'ADV_PROGRESS':('id','op','task','frames','total','elapsed_us','swaps','uf','late','scan_total','missed_scans','pixel_changes'),
 'ADV_DONE':('id','op','status','code','completed','active','elapsed_us'),
}
OPTIONAL_FIELDS={'ADV_PATH':('id','op','task','path','reason','passes','micro','prime_steps','prime_logic_us','measured_steps','total_steps')}
PATHS={'none','cpu','direct8','tile8_ordered','tile8_commute','rowrun','rowrun_mixed','rect'}
PATH_REASONS={'not_prepared','none','cpu_reference','batch_unavailable','fusion_dynamic','size64_deferred','size_not_multiple8','descriptor_capacity','materials_over16','materials_fit','single_color_key','rowrun_fusion','rowrun_odd','rowrun_capacity_fallback'}
TEXT={'op','status','args','scope','code','path','reason'}

def number(value,lo,hi,label):
 if type(value) is not int or not lo<=value<=hi:raise ValueError(label)
 return value

def normalized(operation,args):
 args=tuple(args)
 if operation not in OPS:raise ValueError('未知高阶实验指令')
 if operation in {'enter','exit','status','cancel'}:
  if args:raise ValueError('该操作不接受参数')
 elif operation=='show':
  if len(args)!=11 or args[0] not in {'alpha','key','joint'}:raise ValueError('显示实验参数无效')
  limits=((0,3),(8,64),(0,5),(0,0xffffff),(0,0xffffff),(0,255),(0,0xffffff),(0,3),(0,2),(0,1))
  for value,(lo,hi) in zip(args[1:],limits):number(value,lo,hi,'显示参数超出范围')
 elif operation=='verify':
  if len(args)!=1 or args[0] not in {'alpha','key','joint'}:raise ValueError('未知校验范围')
 elif operation=='stress':return validate_args(operation,args)
 return args

def validate_args(operation,args):
 args=tuple(args)
 if operation!='stress':return normalized(operation,args)
 if len(args)!=13 or args[0] not in {'fpga','cpu'}:raise ValueError('压力参数无效')
 limits=((1,20000),(8,64),(0,5),(0,0xffffff),(0,0xffffff),(0,0xffffff),(0,2),(0,255),(0,1),(0,5),(1,36000),(1,0xffffffff))
 for value,(lo,hi) in zip(args[1:],limits):number(value,lo,hi,'压力参数超出范围')
 if args[10] and args[1]>512:raise ValueError('物理效果最多512颗；请主动修改数量，或选择纯绘制')
 return args

def canonical(operation,args):
 args=validate_args(operation,args)
 return operation+(' '+' '.join(str(x) for x in args) if args else '')

def task_identity(operation,args):
 value=2166136261
 for byte in canonical(operation,args).encode('ascii'):value=((value^byte)*16777619)&0xffffffff
 return value

def adv_command(request_id,operation,*args):
 number(request_id,1,2147483647,'请求编号无效')
 line=':adv %d %s\n'%(request_id,canonical(operation,args))
 if len(line.encode('ascii'))>255:raise ValueError('实验指令过长')
 return line.encode('ascii')

def timeout_for(operation,args=()):
 if operation=='stress':return 1860.  # board hard budget1800s + UART/cleanup margin
 return 240. if operation=='verify' else 45.

def expected_count(operation,args):
 if operation=='stress':return args[11]
 if operation=='show':return {'alpha':1,'key':2,'joint':4}[args[0]]
 if operation=='verify':return {'alpha':256,'key':8,'joint':4}[args[0]]
 return 0

def expected_key(operation,args):
 if operation=='show':return args[7]
 key=0xff00ff
 if operation!='stress':return key
 a,b,c=args[4:7];mode=args[7]
 colors=[a] if mode==0 else [a,b,c] if mode==1 else []
 if mode==2:
  for t in range(16):
   lo,hi=(a,b) if t<8 else (b,c);k=t if t<8 else t-8;den=8 if t<8 else 7
   colors.append(sum((((lo>>s)&255)*(den-k)+((hi>>s)&255)*k+den//2)//den<<s for s in (0,8,16)))
 while key in colors:key=(key+0x010101)&0xffffff
 return key

def parse_adv_reply(line):
 raw=line.strip()
 if not raw.startswith('ADV_') or len(raw.encode('utf-8'))>509:return None
 parts=raw.split();kind=parts[0]
 fields=FIELDS.get(kind,OPTIONAL_FIELDS.get(kind))
 if fields is None:return None
 pairs={}
 for item in parts[1:]:
  if item.count('=')!=1:return None
  key,value=item.split('=',1)
  if key in pairs or not key or not value:return None
  pairs[key]=value
 if set(pairs)!=set(fields):return None
 values={'kind_line':kind,'raw':raw}
 for key,value in pairs.items():
  if key in TEXT:values[key]=value
  else:
   if not re.fullmatch(r'\d+',value):return None
   n=int(value)
   if n>0xffffffffffffffff:return None
   values[key]=n
 if values.get('op') not in OPS or not 1<=values['id']<=2147483647:return None
 if 'active' in values and values['active'] not in (0,1):return None
 if 'running' in values and values['running'] not in (0,1):return None
 if kind=='ADV_ACK' and values['status'] not in ('QUEUED','ACCEPTED'):return None
 if kind=='ADV_DONE' and (values['status'] not in ('PASS','ERROR','CANCELLED') or not re.fullmatch(r'[A-Z_]+',values['code'])):return None
 if kind=='ADV_PLAN' and values['scope'] not in ('full','sampled'):return None
 if any(values.get(k,0)>limit for k,limit in (('task',0xffffffff),('key',0xffffff))):return None
 if kind=='ADV_TIMING':
  if values['op'] not in ('show','verify','stress') or values['pipeline'] not in (0,1):return None
  if any(values[k]>0xffffffff for k in ('pixel_first','pixel_last','state_first','state_last')):return None
 if kind=='ADV_PATH' and (values['op']!='stress' or values['path'] not in PATHS or values['reason'] not in PATH_REASONS or values['prime_steps'] not in (0,1)):return None
 if kind=='ADV_PROGRESS' and values['op']!='stress':return None
 return values

@dataclass
class AdvRequest:
 request_id:int
 operation:str
 args:tuple
 deadline:float
 raw:list=field(default_factory=list)
 fragments:dict=field(default_factory=dict)
 errors:list=field(default_factory=list)
 require_timing:bool=False
 request_identity:dict=field(default_factory=dict)
 progress:list=field(default_factory=list)
 def feed(self,reply):
  if reply.get('id')!=self.request_id or reply.get('op')!=self.operation:return False
  kind=reply['kind_line'];self.raw.append(dict(reply))
  if kind=='ADV_PROGRESS':
   previous=self.progress[-1] if self.progress else None
   valid=(self.operation=='stress' and reply['task']==task_identity(self.operation,self.args)
    and reply['total']==self.args[11] and 0<reply['frames']<reply['total'] and reply['frames']%600==0
    and reply['swaps']==reply['frames'] and reply['elapsed_us']>0 and reply['late']<=reply['frames']
    and reply['missed_scans']<=reply['scan_total'] and reply['pixel_changes']<=reply['frames']-1)
   if previous:valid=valid and reply['frames']>previous['frames'] and all(reply[k]>=previous[k] for k in ('elapsed_us','swaps','uf','late','scan_total','missed_scans','pixel_changes'))
   if not valid:self.errors.append('进度身份、数量或累计计数不一致');return False
   self.progress.append(dict(reply));return True
  if kind!='ADV_DONE':
   if kind in self.fragments:self.errors.append('重复'+kind)
   else:self.fragments[kind]=dict(reply)
  return True
 def finish(self,done):
  reasons=list(self.errors);ack=self.fragments.get('ADV_ACK');state=self.fragments.get('ADV_STATE')
  if not ack:reasons.append('缺少接收确认')
  elif ack['status']!=('ACCEPTED' if self.operation in ('status','cancel') else 'QUEUED'):reasons.append('接收确认类型不一致')
  if done['status']!='PASS' or done['code']!='OK':reasons.append(done['code'])
  active=done['active']
  if self.operation=='exit' and active!=0:reasons.append('退出未确认')
  if self.operation not in ('status','cancel','exit') and active!=1:reasons.append('显示所有权不一致')
  if self.operation in ('status','enter','exit'):
   if not state or state['active']!=active:reasons.append('缺少一致的板端状态')
   elif self.operation!='status' and state['running']:reasons.append('板端仍有未完成任务')
  plan=self.fragments.get('ADV_PLAN');result=self.fragments.get('ADV_RESULT');metric=self.fragments.get('ADV_METRIC');check=self.fragments.get('ADV_CHECK');timing=self.fragments.get('ADV_TIMING');path=self.fragments.get('ADV_PATH')
  if self.operation in ('show','verify','stress'):
   if self.require_timing and not timing:reasons.append('缺少完整ADV_TIMING')
   if not all((plan,result,metric,check)):reasons.append('结果片段不完整')
   else:
    task=task_identity(self.operation,self.args);expected=expected_count(self.operation,self.args)
    if any(x['task']!=task for x in (plan,result,metric,check)):reasons.append('任务身份不一致')
    if plan['args']!=','.join(str(x) for x in self.args):reasons.append('请求参数未原样确认')
    if plan['expected']!=expected:reasons.append('预登记数量不一致')
    if plan['key']!=expected_key(self.operation,self.args):reasons.append('透明色预登记不一致')
    if plan['scope']!=('sampled' if self.operation=='stress' else 'full'):reasons.append('像素验证范围不一致')
    count=result['frames'] if self.operation=='stress' else result['cases']
    if count!=expected or done['completed']!=count:reasons.append('未完整完成预登记任务')
    if any(check[k] for k in ('errors','guards','source')):reasons.append('像素、保护区或源图错误')
    if check['actual']!=1 or check['replayed']!=0 or not check['checked']:reasons.append('缺少真实画面检查')
    if metric['uf']:reasons.append('显示新增欠流')
    if self.operation in ('show','verify') and check['checked']!=1280*720:reasons.append('显示实验画面核对未完整完成')
    if self.operation=='stress':
     n=self.args[1];fusion=self.args[10]==2
     if result['initial']!=n:reasons.append('初始数量不一致')
     if not 1<=result['minimum']<=result['final']<=result['maximum']<=n:reasons.append('实际数量范围无效')
     if not fusion and any(result[k]!=n for k in ('minimum','final','maximum')):reasons.append('非融合测试改变数量')
     if fusion and (result['merges']!=n-result['final'] or result['minimum']!=result['final'] or result['maximum']!=n):reasons.append('融合数量与合并次数不一致')
     if not fusion and result['merges']:reasons.append('非融合模式出现合并')
     if result['collisions']<result['merges']:reasons.append('融合超过碰撞次数')
     if metric['swaps']!=result['frames'] or not metric['elapsed_us']:reasons.append('换帧或计时不完整')
     if check['checked']!=64:reasons.append('压力抽样数量不一致')
     if metric['late']>result['frames']:reasons.append('超时帧计数越界')
    if timing:
     if timing['task']!=task:reasons.append('时序任务身份不一致')
     if self.operation!='stress':
      if any(timing[k] for k in FIELDS['ADV_TIMING'] if k not in ('id','op','task')):reasons.append('数值实验出现非法压力计数')
     else:
      frames=result['frames']
      if timing['sample_points']!=16:reasons.append('前台签名采样点数不一致')
      if timing['warmup_frames']!=1:reasons.append('缺少显式预热换帧')
      if frames and not 0<timing['min_frame_us']<=timing['max_frame_us']:reasons.append('真实呈现间隔无效')
      if timing['pixel_changes']>max(0,frames-1):reasons.append('采样签名变化计数越界')
      if frames and not timing['pixel_changes'] and timing['pixel_first']!=timing['pixel_last']:reasons.append('签名首末值与变化计数冲突')
      if timing['missed_scans']>timing['scan_total'] or timing['max_scan_gap']>timing['scan_total']:reasons.append('扫描累计计数冲突')
      if timing['overlap_us']>timing['hw_us']:reasons.append('实际交叠时间超过引擎忙时')
      if timing['pipeline']==1 and not (self.args[0]=='fpga' and self.args[2]==8 and self.args[10]==0):reasons.append('流水路径与负载配置不一致')
      if timing['pipeline']==0 and timing['overlap_us']:reasons.append('串行路径报告了交叠时间')
      if self.progress:
       last=self.progress[-1]
       if last['frames']>frames or any(last[k]>metric[k] for k in ('elapsed_us','swaps','uf','late')) or any(last[k]>timing[k] for k in ('scan_total','missed_scans','pixel_changes')):reasons.append('最终累计值小于已收到的真实进度')
  if path:
   if self.operation!='stress' or path['task']!=task_identity(self.operation,self.args):reasons.append('路径诊断任务身份不一致')
   elif path['total_steps']!=path['prime_steps']+path['measured_steps'] or path['total_steps']>self.args[11]:reasons.append('路径诊断逻辑步数不完整')
   elif done['status']=='PASS' and path['total_steps']!=self.args[11]:reasons.append('路径诊断少做逻辑步骤')
   if not path['prime_steps'] and path['prime_logic_us']:reasons.append('未预计算却报告预热逻辑耗时')
   if path['micro']<path['passes'] or bool(path['micro'])!=bool(path['passes']):reasons.append('OP2作业与描述符累计计数不一致')
   if path['path'] in ('none','cpu','rect') and (path['passes'] or path['micro']):reasons.append('非OP2路径报告了OP2作业')
   if path['path']=='cpu' and (self.args[0]!='cpu' or path['reason']!='cpu_reference'):reasons.append('CPU路径与请求不一致')
   if path['path'] in ('direct8','tile8_ordered','tile8_commute','rowrun','rowrun_mixed') and self.args[0]!='fpga':reasons.append('硬件路径与CPU请求不一致')
   if path['path']=='direct8' and (self.args[2]!=8 or path['reason']!='none'):reasons.append('8像素路径与请求不一致')
   if path['path'].startswith('tile8_') and (not 8<self.args[2]<64 or self.args[2]%8):reasons.append('分块路径尺寸不一致')
   if path['path']=='tile8_ordered' and path['reason']!='materials_fit':reasons.append('有序分块原因不一致')
   if path['path']=='tile8_commute' and (not self.args[9] or path['reason']!='single_color_key'):reasons.append('可交换分块需同色Key条件')
   if path['path'] in ('rowrun','rowrun_mixed') and not self.args[9]:reasons.append('行段路径需开启Key')
   if path['path']=='rowrun':
    if path['reason']=='rowrun_fusion':
     if self.args[10]!=2:reasons.append('融合行段原因与物理模式不一致')
    elif path['reason']=='rowrun_odd':
     if self.args[2]%8==0:reasons.append('非8倍数行段原因与尺寸不一致')
    else:reasons.append('行段路径原因不一致')
   if path['path']=='rowrun_mixed' and path['reason']!='rowrun_capacity_fallback':reasons.append('行段容量回退原因不一致')
   if path['path']=='none' and done['status']=='PASS':reasons.append('任务未准备却报告完成')
  if self.operation in ('status','enter','exit','cancel') and done['completed']!=0:reasons.append('控制操作计数异常')
  fps=(metric['swaps']*1e6/metric['elapsed_us']) if self.operation=='stress' and metric and metric['elapsed_us'] else None
  verdict=not reasons
  qualification=[]
  if self.operation!='stress':qualification.append('不是压力长测')
  else:
   if not verdict:qualification.append('正确性或结果完整性未通过')
   if not self.require_timing or not timing:qualification.append('缺少perf=1真实时序证据')
   if self.args[0]!='fpga':qualification.append('CPU不纳入本轮60FPS资格')
   if self.args[2]==64:qualification.append('64×64本轮另测')
   if self.request_identity.get('ui_section')=='key' and not self.args[9]:qualification.append('高阶二未启用Key去背')
   if self.args[11]<36000 or not result or result['frames']<36000:qualification.append('短测观察，不是36000帧长测')
   if not metric or metric['elapsed_us']<599000000:qualification.append('真实计时窗口不足约10分钟')
   if fps is None or fps<59.8:qualification.append('实际帧率低于59.8FPS')
   if timing and result and (timing['scan_total']!=result['frames'] or timing['max_scan_gap']!=1 or timing['missed_scans']):qualification.append('未逐扫描换新帧')
  return dict(id=self.request_id,op=self.operation,args=list(self.args),request_identity=dict(self.request_identity),accepted_pass=verdict,reasons=sorted(set(reasons)),plan=plan,result=result,metric=metric,timing=timing,path=path,check=check,state=state,done=dict(done),actual_fps=fps,performance_60fps=(verdict and metric is not None and metric['uf']==0 and metric['late']==0 and fps is not None and fps>=59.8),long_60fps_pass=not qualification,long_60fps_reasons=qualification,progress=list(self.progress),raw=list(self.raw))
