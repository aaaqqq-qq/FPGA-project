"""Presentation registry. Add a project here after its core protocol is validated."""
from dataclasses import dataclass

@dataclass(frozen=True)
class ProjectView:
    key: str
    title: str
    profiles: tuple[str, ...]
    board_hint: str

PROJECT_VIEWS=(ProjectView(
    'touhou','东方 Project',('touhou_LAB',),
    '电脑操作：WASD / 方向键移动 · J 炸弹 · 空格暂停 · Enter 开始 / 重开 · Esc 返回菜单'),)

def project_for(profile_id):
    return next((view for view in PROJECT_VIEWS if profile_id in view.profiles),None)
