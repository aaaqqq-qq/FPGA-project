"""Stop-and-wait RGB888 upload state. No Qt, port, process or fake progress."""
from __future__ import annotations
import base64,secrets
from image_protocol import CHUNK_RGB_BYTES,FRAME_PIXELS,image_reply_valid

class ImageWorkflow:
 def __init__(self,session_factory=None):
  self.session_factory=session_factory or (lambda:secrets.randbelow(2147483647)+1)
  self.busy=False;self.uncertain=False;self.status_required=False;self.phase='IDLE';self.waiting=None
  self.prepared=None;self.session=None;self.offset=0;self.cache=None
  self.cancel_requested=False;self.last_summary=None;self.request_ids=[];self.position=(0,0)
 def invalidate_cache(self):self.cache=None
 def start(self,prepared,x,y,force=False):
  if self.busy or self.uncertain:return False
  if not 0<=x<=1280-prepared.width or not 0<=y<=720-prepared.height:raise ValueError('图片目标区域超出画布。')
  reusable=bool(not force and self.cache and self.cache['key']==prepared.key)
  self.prepared=prepared;self.position=(x,y);self.cancel_requested=False;self.last_summary=None;self.request_ids=[];self.waiting=None
  self.session=self.cache['session'] if reusable else self.session_factory()
  if type(self.session)is not int or not 1<=self.session<=2147483647:raise ValueError('图片会话编号无效。')
  self.offset=len(prepared.rgb) if reusable else 0;self.phase='COPY' if reusable else 'BEGIN';self.busy=True;return True
 def next_command(self):
  if not self.busy or self.waiting:return None
  if self.cancel_requested:self.phase='ABORT'
  p=self.prepared;session=self.session
  if self.phase=='BEGIN':op,args='imgbegin',[session,p.width,p.height,p.crc32];received=0
  elif self.phase=='DATA':
   raw=p.rgb[self.offset:self.offset+CHUNK_RGB_BYTES];op,args='imgdata',[session,self.offset,base64.b64encode(raw).decode('ascii')];received=self.offset+len(raw)
  elif self.phase=='COMMIT':op,args='imgcommit',[session];received=len(p.rgb)
  elif self.phase=='COPY':op,args='imgcopy',[session,*self.position];received=len(p.rgb)
  elif self.phase=='ABORT':op,args='imgabort',[session];received=None
  else:return None
  self.waiting=dict(op=op,args=args,received=received);return op,args
 def issued(self,request_id):
  if not self.waiting:raise RuntimeError('没有待派发图片步骤')
  self.waiting['id']=request_id;self.request_ids.append(request_id)
 def cancel(self):
  if self.busy:self.cancel_requested=True;self.cache=None;return True
  if self.status_required:return False
  if self.session:
   self.busy=True;self.cancel_requested=True;self.waiting=None;self.phase='ABORT';return True
  return False
 def _finish(self,status,reason):
  self.busy=False;self.waiting=None;self.phase=status
  self.last_summary=dict(status=status,accepted_pass=status=='PASS',reason=reason,session=self.session,
   request_ids=list(self.request_ids),image=self.prepared.metadata() if self.prepared else None,
   dx=self.position[0],dy=self.position[1],received=self.offset,total=len(self.prepared.rgb) if self.prepared else 0)
 def fail(self,reason,status='ERROR'):
  self.cache=None;self.uncertain=True;self.status_required=True;self.cancel_requested=False;self._finish(status,reason)
 def receive(self,reply):
  if reply.get('kind')!='LAB_DONE':return None
  expected=self.waiting
  if not expected or reply.get('id')!=expected.get('id') or reply.get('op')!=expected['op']:return None
  op=expected['op'];valid=reply.get('status')=='PASS' and reply.get('errors')==0 and image_reply_valid(reply)
  reason='板端图片步骤失败'
  if valid and reply.get('session')!=self.session:valid=False;reason='图片会话不一致'
  if valid and reply.get('active')!=1:valid=False;reason='基础一显示所有权未确认'
  if valid and op=='imgabort':
   valid=reply.get('ready')==0 and reply.get('verified')==0;reason='中止状态未确认'
  elif valid:
   p=self.prepared
   valid=(reply.get('imgw')==p.width and reply.get('imgh')==p.height and reply.get('total')==len(p.rgb) and reply.get('received')==expected['received'])
   reason='图片尺寸或真实接收进度不一致'
   if valid and op in ('imgcommit','imgcopy'):
    valid=reply.get('ready')==1 and reply.get('crc')==p.crc32;reason='图片CRC或提交状态不一致'
   elif valid:valid=reply.get('ready')==0;reason='上传中提交状态不一致'
   if valid:
    valid=reply.get('verified')==(FRAME_PIXELS if op=='imgcopy' else 0);reason='实际复制画面校验未完整完成'
  self.waiting=None
  if not valid:self.fail(reason);return dict(accepted_pass=False,reason=reason)
  if op=='imgabort':
   self.cache=None;self.uncertain=False;self.status_required=False;self._finish('CANCELLED','已中止图片会话，整体未计通过');return dict(accepted_pass=True,reason='中止已确认')
  self.offset=reply['received']
  if self.cancel_requested:self.phase='ABORT'
  elif op=='imgbegin':self.phase='DATA'
  elif op=='imgdata':self.phase='COMMIT' if self.offset==len(self.prepared.rgb) else 'DATA'
  elif op=='imgcommit':self.cache=dict(session=self.session,key=self.prepared.key);self.phase='COPY'
  elif op=='imgcopy':self.uncertain=False;self._finish('PASS','实际复制画面921600像素核对通过')
  return dict(accepted_pass=True,reason='板端步骤已核对')
 def sync_status(self,reply,prepared=None):
  valid=reply.get('status')=='PASS' and reply.get('errors')==0 and reply.get('active') in (0,1) and image_reply_valid(reply) and reply.get('verified')==0
  if not valid:return False
  self.uncertain=False;self.status_required=False;self.cache=None
  if (prepared and self.prepared and prepared.key==self.prepared.key
      and self.session==reply['session'] and reply['active']==1 and reply['ready']==1
      and reply['imgw']==prepared.width and reply['imgh']==prepared.height and reply['total']==len(prepared.rgb) and reply['crc']==prepared.crc32):self.cache=dict(session=reply['session'],key=prepared.key)
  return True
 def disconnected(self):
  if self.busy:self.fail('连接已断开，原图片流程未完成','DISCONNECTED')
  self.cache=None;self.uncertain=False;self.status_required=False;self.waiting=None;self.busy=False
