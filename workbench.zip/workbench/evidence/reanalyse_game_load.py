"""Pure offline GAME_LOAD UART reanalysis. Never opens a port or executes a GUI.

Examples (use the bundled Python, no Qt dependencies needed):
  python evidence/reanalyse_game_load.py --log C:/.../session_20261101_222545.log --output-prefix evidence/game_load_actual
  python evidence/reanalyse_game_load.py --log C:/.../game_load_native_protocol.log --native-fixture --output-prefix evidence/game_load_native

Writes JSON, a compact matrix CSV, and an attempts CSV. All input files are
read once into hashed snapshots. 60/600/36000-frame evidence is kept separate.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,re,sys
from datetime import datetime,timezone
from pathlib import Path

APP=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(APP))
from game_load_protocol import (ARG_NAMES,SIZES,GameLoadRequest,parse_game_load_reply,
    game_load_command,validate_args)
from control_core import parse_capabilities

LOG_LINE=re.compile(r'^\[(\d\d:\d\d:\d\d)\]\s+(\S+)\s{2}(.*)$')
ID=re.compile(r'\bid=(\d+)\b')
DURATIONS=(60,600,36000)
def sha(data):return hashlib.sha256(data).hexdigest()

def unpack(line):
    match=LOG_LINE.match(line)
    if match:return match.group(1),match.group(2),match.group(3).strip()
    if line.startswith('TX '):return None,'TX',line[3:].strip()
    if line.startswith('RX '):return None,'RX',line[3:].strip()
    return None,'plain',line.strip()

def read_source(path):
    path=Path(path).expanduser().resolve();before=path.stat();raw=path.read_bytes();after=path.stat()
    partial=b'';complete=raw
    if raw and not raw.endswith(b'\n'):
        complete,_,partial=raw.rpartition(b'\n')
    text=complete.decode('utf-8-sig',errors='strict')
    return text,dict(path=str(path),snapshot_bytes=len(raw),snapshot_sha256=sha(raw),
        hash_scope='First snapshot_bytes of the source file; later appended bytes are outside this snapshot.',
        read_utc=datetime.now(timezone.utc).isoformat(),size_before=before.st_size,size_after=after.st_size,
        changed_during_read=before.st_size!=after.st_size or before.st_mtime_ns!=after.st_mtime_ns,
        unterminated_tail_bytes=len(partial),unterminated_tail_sha256=sha(partial) if partial else None)

def parse_tx(body):
    words=body.split()
    if len(words)<3 or words[0]!=':gload':raise ValueError('invalid GAME_LOAD command')
    op=words[1]
    if not all(re.fullmatch(r'[0-9]+',v) for v in words[2:]):raise ValueError('nondecimal GAME_LOAD argument')
    request_id=int(words[2]);args=tuple(map(int,words[3:]));wire=game_load_command(request_id,op,*args)
    if wire.decode().strip()!=' '.join(words):raise ValueError('noncanonical GAME_LOAD command')
    return request_id,op,args

def analyse_source(path,native_fixture=False):
    text,source=read_source(path)
    if native_fixture and not ('Native production C protocol' in text and 'not physical FPS' in text):
        raise ValueError('--native-fixture requires the explicit native/mock-timer marker')
    active={};records=[];issues=[];controls=[];caps=None;boots=[];occurrences={}

    def create(i,args,number,clock,wire,tx_present):
        occurrences[i]=occurrences.get(i,0)+1
        expected=bool(caps and caps.get('pipe')==1 and caps.get('pref8')==1 and args[3] in (8,32)) if caps else None
        record=dict(request=GameLoadRequest(i,tuple(args),expected_pipeline=expected,capabilities=dict(caps or {})),request_id=i,occurrence=occurrences[i],
            args=list(args),source_path=source['path'],first_line=number,last_line=number,tx_line=number if tx_present else None,
            tx_time=clock,tx=wire if tx_present else None,tx_present=tx_present,native_fixture=native_fixture,
            capabilities=caps.copy() if caps else None,boot_observations=list(boots),
            evidence_lines={'ACK':[],'READY':[],'STAT':[],'DETAIL':[],'DONE':[],'PIPE':[],'VIEW':[],'MOTION_DIAG':[],'cancel_TX':[]},
            wire=[wire] if tx_present else [],integrity_errors=[],done_received=False)
        active[i]=record;return record

    def finish(record,done,number):
        record['last_line']=number;record['done_received']=done.get('kind_line')=='GLOAD_DONE' and not done.get('host_synthetic',False)
        result=record.pop('request').finish(done);result.pop('raw_lines',None)
        wire=record.pop('wire');record['wire_line_count']=len(wire);record['wire_sha256']=sha('\n'.join(wire).encode())
        # Retained only until deduplication, then removed from compact output.
        record['_wire']=wire
        valid_provenance=(record['tx_present'] and record['capabilities'] is not None
            and record['capabilities'].get('game_load')==1 and not record['integrity_errors'] and not native_fixture)
        record['production_result']=result;record['provenance_valid']=valid_provenance
        record['accepted_session_pass']=bool(valid_provenance and result['accepted_pass'])
        record['complete_timing_failure']=bool(valid_provenance and result['search_eligible'])
        record['partial_timeout_observation']=bool(valid_provenance and result['partial_timeout_observation'])
        if not record['tx_present'] and not native_fixture:record['integrity_errors'].append('TX run command not found in this source snapshot')
        if (not record['capabilities'] or record['capabilities'].get('game_load')!=1) and not native_fixture:record['integrity_errors'].append('New GAME_LOAD capabilities not observed before TX')
        record['provenance']=[{'source_path':source['path'],'source_sha256':source['snapshot_sha256'],
            'first_line':record['first_line'],'last_line':record['last_line']}]
        records.append(record);active.pop(record['request_id'],None)

    def incomplete(record,reason,number):
        finish(record,dict(kind_line='GLOAD_DONE',id=record['request_id'],status='INCOMPLETE',reason=reason,
            raw='OFFLINE incomplete: '+reason,host_synthetic=True),number)

    lines=text.splitlines()
    for number,line in enumerate(lines,1):
        clock,origin,body=unpack(line)
        tx_origin=origin in ('游戏测量已发送','TX','plain')
        rx_origin=origin in ('板端','RX','plain')
        if tx_origin and body.startswith(':gload'):
            try:i,op,args=parse_tx(body)
            except ValueError as exc:
                issues.append({'line':number,'kind':'malformed_TX','raw':line,'error':str(exc)})
                for record in active.values():record['integrity_errors'].append(f'malformed TX at line {number}')
                continue
            if op=='run':
                if i in active:
                    active[i]['integrity_errors'].append('Repeated request ID before original terminal');incomplete(active[i],'replaced_by_reused_id',number)
                create(i,args,number,clock,body,True)
            else:
                controls.append({'line':number,'time':clock,'direction':'TX','op':op,'id':i,'raw':body})
                if op=='cancel' and i in active:active[i]['evidence_lines']['cancel_TX'].append(number);active[i]['wire'].append(body)
            continue
        if rx_origin and body.startswith('CAPS '):
            for record in list(active.values()):incomplete(record,'capability_handshake_changed',number)
            caps=parse_capabilities(body);continue
        if rx_origin and body.startswith('PHASE BATTLE '):
            boots.append({'line':number,'raw':body});caps=None
            for record in list(active.values()):incomplete(record,'firmware_boot_marker',number)
            continue
        if origin=='连接中断':
            for record in list(active.values()):incomplete(record,'connection_interrupted',number)
            continue
        if not rx_origin:continue
        if body.startswith('ERR') and active:
            for record in active.values():record['integrity_errors'].append(f'Board ERR at line {number}: {body}')
        if not body.startswith(('GLOAD_','MOTION_DIAG ')):continue
        item=parse_game_load_reply(body)
        if item is None:
            issues.append({'line':number,'kind':'malformed_RX','raw':line})
            match=ID.search(body);targets=[active[int(match.group(1))]] if match and int(match.group(1)) in active else list(active.values())
            for record in targets:record['integrity_errors'].append(f'Malformed GAME_LOAD reply at line {number}')
            continue
        i=item['id'];kind=item['kind_line']
        if kind=='GLOAD_ACK' and item['op']!='run':
            controls.append({'line':number,'time':clock,'direction':'RX','op':item['op'],'id':i,'raw':body})
            if i in active and item['op']=='cancel':active[i]['wire'].append(body)
            continue
        if i not in active and kind=='GLOAD_ACK' and item.get('op')=='run' and item.get('status')=='OK':
            try:args=validate_args(tuple(item[k] for k in ARG_NAMES));create(i,args,number,clock,'',False)
            except (ValueError,KeyError):issues.append({'line':number,'kind':'invalid_ACK_arguments','raw':line});continue
        record=active.get(i)
        if record is None:
            if kind=='MOTION_DIAG':continue # Legacy pipe0 tail was after DONE.
            issues.append({'line':number,'kind':'orphan_RX','raw':line});continue
        record['last_line']=number;record['wire'].append(body);record['evidence_lines'][kind[6:] if kind.startswith('GLOAD_') else kind].append(number)
        if kind=='GLOAD_DONE':finish(record,item,number)
        elif kind=='GLOAD_ACK' and item.get('status')=='ERR':
            record['request'].feed(item)
            finish(record,dict(kind_line='GLOAD_DONE',id=i,status='ERROR',reason=item.get('reason'),raw='OFFLINE run rejected',host_synthetic=True),number)
        else:record['request'].feed(item)
    for record in list(active.values()):incomplete(record,'source_snapshot_eof',len(lines))
    source.update(lines=len(lines),attempts_before_dedup=len(records),native_fixture=native_fixture)
    return source,records,issues,controls

def deduplicate(records):
    """Copies and shorter snapshots do not create additional measured attempts."""
    result=[];duplicates=0;superseded=0
    for record in records:
        key=(record['request_id'],tuple(record['args']),record['tx_time'],record['tx'],record['native_fixture'])
        matched=False
        for index,old in enumerate(result):
            oldkey=(old['request_id'],tuple(old['args']),old['tx_time'],old['tx'],old['native_fixture'])
            if key!=oldkey or old['source_path']==record['source_path']:continue
            # Adverse evidence about the same request survives merging a clean
            # copy or a longer snapshot. A copy cannot erase a corrupt packet.
            taint=list(dict.fromkeys(old['integrity_errors']+record['integrity_errors']))
            if taint:
                for r in (old,record):
                    r['integrity_errors']=list(taint);r['provenance_valid']=False
                    r['accepted_session_pass']=r['complete_timing_failure']=r['partial_timeout_observation']=False
            a,b=old['_wire'],record['_wire'];shared=min(len(a),len(b))
            if a[:shared]!=b[:shared]:continue
            if a==b:
                if record['provenance_valid'] and not old['provenance_valid']:
                    record['provenance'].extend(old['provenance']);result[index]=record
                else:old['provenance'].extend(record['provenance'])
                duplicates+=1;matched=True;break
            if not old['done_received'] and len(b)>len(a):
                record['provenance'].extend(old['provenance']);record['superseded_shorter_snapshot']=True
                result[index]=record;superseded+=1;matched=True;break
            if not record['done_received'] and len(a)>len(b):
                old['provenance'].extend(record['provenance']);old['superseded_shorter_snapshot']=True
                superseded+=1;matched=True;break
        if not matched:result.append(record)
    for record in result:record.pop('_wire',None)
    return result,dict(exact_copied_attempts_merged=duplicates,shorter_snapshots_superseded=superseded)

def observed_bounds(records,frames):
    selected=[r for r in records if r['args'][4]==frames]
    passed=[r['args'][2] for r in selected if r['accepted_session_pass']]
    failed=[r['args'][2] for r in selected if r['complete_timing_failure']]
    timed=[r['args'][2] for r in selected if r['partial_timeout_observation']]
    low=max(passed,default=None);upper=min((n for n in failed if low is None or n>low),default=None)
    conflicts=any(n<=low for n in failed) if low is not None else False
    return dict(requested_frames=frames,attempts=len(selected),passed_counts=sorted(set(passed)),
        complete_failed_counts=sorted(set(failed)),partial_timeout_counts=sorted(set(timed)),
        verified_lower=low,complete_failed_upper=upper,conflicting=conflicts,exact_maximum=None,
        other_or_incomplete=sum(not(r['accepted_session_pass'] or r['complete_timing_failure'] or r['partial_timeout_observation']) for r in selected),
        qualification='long_window' if frames>=36000 else 'short_observation_only')

def aggregate(records,bosses,enemies,sizes):
    expected={(b,m,s) for b in bosses for m in enemies for s in sizes};groups={}
    for r in records:
        b,m,n,s,frames,seed=r['args'];cfg=(r['production_result'].get('ack') or {}).get('cfg')
        groups.setdefault((b,m,s,seed,cfg),[]).append(r)
    measured_cells={(r['args'][0],r['args'][1],r['args'][3]) for r in records if (r['production_result'].get('stat') or {}).get('frames',0)>0 and not r['native_fixture']}
    tx_cells={(r['args'][0],r['args'][1],r['args'][3]) for r in records if r['tx_present'] and not r['native_fixture']}
    complete_cells={(r['args'][0],r['args'][1],r['args'][3]) for r in records if r['accepted_session_pass'] or r['complete_timing_failure']}
    passed_cells={(r['args'][0],r['args'][1],r['args'][3]) for r in records if r['accepted_session_pass']}
    rows=[]
    for key in sorted(groups,key=lambda k:(k[0],k[1],k[2],k[3],str(k[4]))):
        b,m,s,seed,cfg=key;rs=groups[key]
        rows.append(dict(bosses=b,enemies=m,size=s,seed=seed,cfg=cfg,scope='GAME_LOAD controlled workload',
            state='FIXTURE_ONLY' if all(r['native_fixture'] for r in rs) else 'RECORDED',attempts=len(rs),
            request_ids=[r['request_id'] for r in rs],quick60=observed_bounds(rs,60),observe600=observed_bounds(rs,600),
            long36000=observed_bounds(rs,36000),other_frames=sorted({r['args'][4] for r in rs}-set(DURATIONS))))
    occupied={(r['bosses'],r['enemies'],r['size']) for r in rows if r['state']!='FIXTURE_ONLY'}
    for b,m,s in sorted(expected-occupied):
        rows.append(dict(bosses=b,enemies=m,size=s,seed=None,cfg=None,state='NOT_RUN_IN_PROVIDED_LOGS',attempts=0,
            request_ids=[],quick60=observed_bounds([],60),observe600=observed_bounds([],600),long36000=observed_bounds([],36000),other_frames=[]))
    rows.sort(key=lambda r:(r['bosses'],r['enemies'],r['size'],str(r['seed']),str(r['cfg'])))
    coverage=dict(expected_unique_cells=len(expected),unique_cells_with_TX=len(expected&tx_cells),
        unique_cells_with_actual_samples=len(expected&measured_cells),unique_cells_with_complete_window=len(expected&complete_cells),
        unique_cells_with_any_pass=len(expected&passed_cells),unique_unrun_cells=len(expected-(tx_cells|measured_cells)),
        unique_cells_without_TX=len(expected-tx_cells),
        all_expected_cells_complete=expected<=complete_cells,all_expected_cells_passed=expected<=passed_cells,
        observed_extra_cells=sorted(measured_cells-expected),scope='Only supplied immutable log snapshots; repeats do not fill missing B/M/size cells.')
    for frames in DURATIONS:
        cells={(r['args'][0],r['args'][1],r['args'][3]) for r in records if r['args'][4]==frames and r['accepted_session_pass']}
        coverage[f'unique_pass_cells_{frames}_frames']=len(cells&expected)
    return rows,coverage

def run_analysis(paths,*,native_fixture=False,bosses=range(1,7),enemies=(0,6,12),sizes=SIZES):
    sources=[];records=[];issues=[];controls=[];seen=set()
    for path in paths:
        path=Path(path).expanduser().resolve()
        if path in seen:continue
        seen.add(path);source,found,bad,ctl=analyse_source(path,native_fixture)
        sources.append(source);records.extend(found)
        issues.extend(dict(source_path=str(path),**item) for item in bad);controls.extend(dict(source_path=str(path),**item) for item in ctl)
    records,dedup=deduplicate(records);rows,coverage=aggregate(records,bosses,enemies,sizes)
    return dict(schema='ti60_game_load_uart_reanalysis_v1',created_utc=datetime.now(timezone.utc).isoformat(),
        hardware_accessed=False,gui_accessed=False,native_fixture=native_fixture,
        scope='Recorded controlled GAME_LOAD, with artificial fill/keep-alive. Never ADV evidence or natural stage certification. No new board/Flash/FPS test performed.',
        bounds_semantics='Finite observations at fixed B/M/size/seed/cfg and requested frame length. No exact or absolute capacity claim; startup scans and misses are never subtracted. A failed count is only a failed observed window, not proof of a hardware ceiling.',
        production_parser=str(APP/'game_load_protocol.py'),parser_sha256=sha((APP/'game_load_protocol.py').read_bytes()),
        expected_grid=dict(bosses=list(bosses),enemies=list(enemies),sizes=list(sizes)),
        sources=sources,attempts=records,summary=rows,coverage=coverage,deduplication=dedup,
        malformed_or_orphan_events=issues,control_events=controls,
        counts=dict(unique_attempts=len(records),accepted_session_pass=sum(r['accepted_session_pass'] for r in records),
            complete_timing_failures=sum(r['complete_timing_failure'] for r in records),
            partial_timeout_observations=sum(r['partial_timeout_observation'] for r in records),
            production_semantic_pass=sum(r['production_result']['accepted_pass'] for r in records),
            other_or_incomplete=sum(not(r['accepted_session_pass'] or r['complete_timing_failure'] or r['partial_timeout_observation']) for r in records)))

def write_outputs(report,prefix):
    prefix=Path(prefix).expanduser().resolve();prefix.parent.mkdir(parents=True,exist_ok=True)
    json_path=prefix.with_suffix('.json');csv_path=prefix.with_suffix('.csv');attempt_path=prefix.with_name(prefix.name+'_attempts').with_suffix('.csv')
    json_path.write_text(json.dumps(report,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
    fields=['bosses','enemies','size','seed','cfg','state','attempts']
    for name in ('quick60','observe600','long36000'):
        fields.extend(name+'_'+key for key in ('verified_lower','complete_failed_upper','partial_timeout_counts','other_or_incomplete','conflicting'))
    fields+=['other_frames','request_ids']
    with csv_path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for row in report['summary']:
            out={k:row.get(k) for k in ('bosses','enemies','size','seed','cfg','state','attempts','other_frames','request_ids')}
            for name in ('quick60','observe600','long36000'):
                out.update((name+'_'+key,row[name][key]) for key in ('verified_lower','complete_failed_upper','partial_timeout_counts','other_or_incomplete','conflicting'))
            writer.writerow({k:json.dumps(v,separators=(',',':')) if isinstance(v,(list,dict)) else v for k,v in out.items()})
    fields=['request_id','source_path','tx_line','tx_time','bosses','enemies','N','size','requested_frames','seed','cfg','warmup','prepare_us',
        'status','reason','accepted_session_pass','complete_timing_failure','partial_timeout_observation','production_semantic_pass',
        'actual_frames','actual_us','actual_fps','nmin','nmax','bmin','bmax','mmin','mmax','swaps','scans','gap','missed','uf','ldrop','lover','logicmax','rendermax','late','ticks','runtime',
        'mode','hw','active','paused','guards','logerr','fault',
        'fill','keep','recycle','qmin','qmax','lodsum','fxdrop','ddrop','done_received','integrity_errors','verdict_errors']
    with attempt_path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for record in report['attempts']:
            result=record['production_result'];s=result.get('stat') or {};d=result.get('detail') or {};a=result.get('ack') or {};ready=result.get('ready') or {}
            b,m,n,size,frames,seed=record['args']
            row={k:record.get(k) for k in ['request_id','source_path','tx_line','tx_time','accepted_session_pass','complete_timing_failure','partial_timeout_observation','done_received','integrity_errors']}
            row.update(bosses=b,enemies=m,N=n,size=size,requested_frames=frames,seed=seed,cfg=a.get('cfg'),warmup=ready.get('warmup'),prepare_us=ready.get('prepare_us'),status=result['status'],reason=result['reason'],production_semantic_pass=result['accepted_pass'],actual_frames=s.get('frames'),actual_us=s.get('us'),actual_fps=result['actual_fps'],verdict_errors=result['errors'])
            row.update({k:s.get(k) for k in ('nmin','nmax','bmin','bmax','mmin','mmax','swaps','scans','gap','missed','uf','ldrop','lover','logicmax','rendermax','late')});row.update({k:d.get(k) for k in ('ticks','runtime','mode','hw','active','paused','guards','logerr','fault','fill','keep','recycle','qmin','qmax','lodsum','fxdrop','ddrop')})
            writer.writerow({k:json.dumps(v,ensure_ascii=False,separators=(',',':')) if isinstance(v,(list,dict)) else v for k,v in row.items()})
    return [str(json_path),str(csv_path),str(attempt_path)]

def numbers(value):
    try:return tuple(dict.fromkeys(int(n.strip()) for n in value.split(',')))
    except ValueError:raise argparse.ArgumentTypeError('Use comma-separated integers')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--log',action='append',required=True,type=Path,help='Repeat for multiple raw logs or frozen copies')
    parser.add_argument('--output-prefix',type=Path,default=APP/'evidence/GAME_LOAD_reanalysis')
    parser.add_argument('--native-fixture',action='store_true',help='Explicit native/mock fixture; never counted as session performance')
    parser.add_argument('--bosses',type=numbers,default=tuple(range(1,7)));parser.add_argument('--enemies',type=numbers,default=(0,6,12));parser.add_argument('--sizes',type=numbers,default=SIZES)
    args=parser.parse_args()
    if not args.bosses or any(n not in range(1,7) for n in args.bosses) or not args.enemies or any(n not in range(13) for n in args.enemies) or not args.sizes or any(n not in SIZES for n in args.sizes):parser.error('Invalid expected matrix')
    report=run_analysis(args.log,native_fixture=args.native_fixture,bosses=args.bosses,enemies=args.enemies,sizes=args.sizes)
    outputs=write_outputs(report,args.output_prefix)
    print(json.dumps({'outputs':outputs,'counts':report['counts'],'coverage':report['coverage'],'deduplication':report['deduplication']},ensure_ascii=False))
    return 0
if __name__=='__main__':raise SystemExit(main())
