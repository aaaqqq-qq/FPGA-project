"""GAME_LOAD protocol. This is controlled game load, never ADV stress evidence."""
from __future__ import annotations
from dataclasses import dataclass, field
import re
from pipeline_evidence import PipelineEvidence,parse_pipeline_reply

SIZES=(8,16,24,32,40,48,56)
ARG_NAMES=('b','m','n','size','frames','seed')
STAT_FIELDS='frames us swaps scans gap missed uf ldrop lover nmin nmax bmin bmax mmin mmax logicmax rendermax late'.split()
DETAIL_FIELDS='frames fill recycle keep hits damage bhits mhits size seed cfg guards logerr fault ticks runtime mode hw active paused invincible autoplay qmin qmax lodsum fxdrop ddrop'.split()

def integer(value,lo,hi):
    if isinstance(value,bool) or not isinstance(value,int) or not lo<=value<=hi:
        raise ValueError(f'数值必须为{lo}～{hi}整数')
    return value

def validate_args(args):
    if len(args)!=6:raise ValueError('需要Boss、敌人、弹数、尺寸、帧数和种子')
    b,m,n,size,frames,seed=args
    integer(b,1,6);integer(m,0,12);integer(n,1,20000);integer(frames,60,36000);integer(seed,1,0xffffffff)
    integer(size,8,56)
    if size not in SIZES:raise ValueError('尺寸须为8、16、24、32、40、48、56')
    return tuple(args)

def game_load_command(request_id,op,*args):
    integer(request_id,1,0xffffffff)
    if op=='run':args=validate_args(args)
    elif op in ('status','cancel'):
        if args:raise ValueError('状态/取消无附加参数')
    else:raise ValueError('未知游戏负载命令')
    return (':gload '+op+' '+str(request_id)+(' '+' '.join(map(str,args)) if args else '')+'\n').encode('ascii')

def parse_game_load_reply(raw):
    if not isinstance(raw,str):return None
    if raw.strip().startswith(('GLOAD_PIPE ','GLOAD_VIEW ','MOTION_DIAG ')):return parse_pipeline_reply(raw)
    raw=raw.strip();parts=raw.split()
    if not parts or parts[0] not in ('GLOAD_ACK','GLOAD_READY','GLOAD_STAT','GLOAD_DETAIL','GLOAD_DONE') or len(raw)>2048:return None
    data={'kind_line':parts[0],'raw':raw}
    for part in parts[1:]:
        if '=' not in part:return None
        key,value=part.split('=',1)
        if not re.fullmatch('[a-z][a-z0-9_]*',key) or key in data or not value:return None
        data[key]=int(value) if value.isascii() and value.isdigit() else value
    if not isinstance(data.get('id'),int) or not 1<=data['id']<=0xffffffff:return None
    kind=parts[0]
    required=[]
    if kind=='GLOAD_ACK':
        if data.get('op') not in ('run','status','cancel') or data.get('status') not in ('OK','ERR'):return None
        if data['status']=='ERR':
            if not isinstance(data.get('reason'),str):return None
        elif data['op']=='run':
            if data.get('kind')!='GAME_LOAD':return None
            required=[*ARG_NAMES,'cfg','deadline_us']
        elif data['op']=='status':required=['running','current']
    elif kind=='GLOAD_READY':
        if data.get('kind')!='GAME_LOAD':return None
        required=['warmup','prepare_us','initial_fill']
    elif kind=='GLOAD_STAT':required=STAT_FIELDS
    elif kind=='GLOAD_DETAIL':required=DETAIL_FIELDS
    else:
        if data.get('status') not in ('PASS','FAIL','CANCEL') or not isinstance(data.get('reason'),str):return None
    if any(not isinstance(data.get(k),int) or not 0<=data[k]<=0xffffffffffffffff for k in required):return None
    if 'hud_dma' in data and (type(data['hud_dma']) is not int or data['hud_dma'] not in (0,1)):return None
    if kind=='GLOAD_ACK' and data['status']=='OK' and data['op']=='status':
        if data['running'] not in (0,1) or (data['running']==0 and data['current']!=0) or (data['running']==1 and not 1<=data['current']<=0xffffffff):return None
    return data

@dataclass
class GameLoadRequest:
    request_id:int
    args:tuple
    ack:dict|None=None
    ready:dict|None=None
    stat:dict|None=None
    detail:dict|None=None
    errors:list=field(default_factory=list)
    raw_lines:list=field(default_factory=list)
    expected_pipeline:bool|None=None
    capabilities:dict=field(default_factory=dict)
    pipeline:PipelineEvidence=field(default_factory=PipelineEvidence)

    def __post_init__(self):
        integer(self.request_id,1,0xffffffff);self.args=validate_args(self.args)
        self.hud_proof_required=self.capabilities.get('hud_dma_proof')==1
        self.expected_hud_dma=self.capabilities.get('hud_dma')
        self.hud_policy_errors=[]
        if self.hud_proof_required and (type(self.expected_hud_dma)is not int or self.expected_hud_dma not in (0,1)):
            self.hud_policy_errors.append('请求前没有明确核对HUD执行策略')

    def _check_hud_policy(self,item):
        phase=item['kind_line']
        if phase=='GLOAD_ACK' and (item.get('op')!='run' or item.get('status')!='OK'):return
        if phase not in ('GLOAD_ACK','GLOAD_READY','GLOAD_DETAIL'):return
        actual=item.get('hud_dma')
        if self.hud_proof_required:
            if type(actual)is not int or actual not in (0,1):self.hud_policy_errors.append(phase+'缺少真实HUD策略')
            elif actual!=self.expected_hud_dma:self.hud_policy_errors.append('板端实际设置与所选设置不一致（'+phase+'）')
        if actual is not None and self.ack and self.ack.get('hud_dma') is not None and actual!=self.ack['hud_dma']:
            self.hud_policy_errors.append('测量期间HUD执行策略发生变化')

    def feed(self,item):
        if item.get('id')!=self.request_id:return False
        self.raw_lines.append(item['raw']);kind=item['kind_line']
        self._check_hud_policy(item)
        self.pipeline.feed(item,ack_seen=bool(self.ack),ready_seen=bool(self.ready),detail_seen=bool(self.detail))
        if kind=='GLOAD_ACK' and item.get('op')=='run':
            if self.ack or self.ready or self.stat:self.errors.append('请求确认重复或迟到')
            if item.get('status')!='OK' or any(item.get(k)!=v for k,v in zip(ARG_NAMES,self.args)):self.errors.append('请求回执与预登记参数不一致')
            self.ack=item
        elif kind=='GLOAD_READY':
            if not self.ack or self.ready or self.stat:self.errors.append('准备确认重复、迟到或早于请求')
            self.ready=item
        elif kind=='GLOAD_STAT':
            if self.pipeline.final or self.pipeline.view:self.errors.append('测量计数晚于最终流水证据')
            if not self.ack or not self.ready:self.errors.append('测量计数早于请求或准备确认')
            if self.stat and any(item[k]<self.stat[k] for k in ('frames','us','swaps','scans','missed','uf','ldrop','lover','gap','late','logicmax','rendermax')):self.errors.append('累计或最大值计数倒退')
            if self.stat and (any(item[k]>self.stat[k] for k in ('nmin','bmin','mmin')) or any(item[k]<self.stat[k] for k in ('nmax','bmax','mmax'))):self.errors.append('全窗负载范围被重置')
            self.stat=item
        elif kind=='GLOAD_DETAIL':
            if self.pipeline.final or self.pipeline.view:self.errors.append('测量明细晚于最终流水证据')
            if not self.stat or item.get('frames')!=self.stat.get('frames'):self.errors.append('详细回包与当前计数不配对')
            b,m,n,size,frames,seed=self.args
            fixed={'size':size,'seed':seed,'cfg':(self.ack or {}).get('cfg'),'guards':0,'logerr':0,'fault':0,
                'invincible':0,'autoplay':1,'collision':'scaled','mode':1,'hw':1,'active':1,'paused':0}
            if any(item.get(k)!=v for k,v in fixed.items()):self.errors.append('测量窗口曾出现身份、守卫、故障或运行状态错误')
            if item['qmin']>item['qmax']:self.errors.append('效果质量范围无效')
            if self.detail:
                if any(item[k]<self.detail[k] for k in ('frames','fill','recycle','keep','hits','damage','bhits','mhits','ticks','runtime','lodsum','fxdrop','ddrop')):self.errors.append('详细累计计数倒退')
                if item['qmin']>self.detail['qmin'] or item['qmax']<self.detail['qmax']:self.errors.append('全窗效果质量范围被重置')
            self.detail=item
        return True

    def finish(self,item):
        self.feed(item);b,m,n,size,frames,seed=self.args;s=self.stat or {};d=self.detail or {}
        errors=list(self.errors)+list(self.hud_policy_errors)
        if item.get('id')!=self.request_id or item.get('kind_line')!='GLOAD_DONE':errors.append('结束回包不属于当前测量')
        if self.pipeline.terminal_seen:errors.append('同一测量被重复结束')
        pipeline_errors=self.pipeline.validate(self.ack,self.ready,self.stat,self.detail,self.args,self.expected_pipeline)
        errors.extend(pipeline_errors)
        self.pipeline.terminal_seen=True
        if not self.ack or not self.ready or not self.stat or not self.detail:errors.append('缺少ACK、READY、STAT或DETAIL完整回包')
        if item.get('status')!='PASS' or item.get('reason')!='complete':errors.append('板端未报告完整通过')
        if not self.ready or self.ready.get('warmup',0)<2:errors.append('预热未核对')
        if any(s.get(k)!=frames for k in ('frames','swaps','scans')):errors.append('实际帧/换帧/扫描不等于请求帧数')
        if any(s.get(k)!=0 for k in ('missed','uf','ldrop','lover')) or s.get('gap',2)!=1:errors.append('扫描、欠流或逻辑完整性未通过')
        if any(s.get(k)!=v for k,v in [('nmin',n),('nmax',n),('bmin',b),('bmax',b),('mmin',m),('mmax',m)]):errors.append('实际同场负载与请求不符')
        if d.get('size')!=size or d.get('seed')!=seed or d.get('guards')!=0:errors.append('尺寸、种子或守卫错误')
        if d.get('frames')!=s.get('frames') or d.get('frames')!=frames:errors.append('最终详细计数与测量窗口不匹配')
        if d.get('logerr')!=0 or d.get('fault')!=0:errors.append('日志丢失或游戏故障')
        if d.get('invincible')!=0 or d.get('autoplay')!=1 or d.get('collision')!='scaled':errors.append('碰撞、无敌或自动移动配置未核对')
        if not self.ack or d.get('cfg')!=self.ack.get('cfg'):errors.append('配置哈希与请求回执不一致')
        if self.ack and self.ack.get('deadline_us')!=min(1800000000,max(20000000,frames*200000)):errors.append('板端超时策略与请求不一致')
        if any(d.get(k)!=v for k,v in [('mode',1),('hw',1),('active',1),('paused',0)]):errors.append('实际游戏模式、绘制器或运行状态不符')
        expected_ticks=(s.get('us',0)*60+500000)//1000000
        if d.get('ticks',0)<=0 or abs(d.get('ticks',0)-expected_ticks)>1 or abs(d.get('ticks',0)-frames)>1:errors.append('游戏逻辑未按真实时间持续推进')
        fps=s.get('swaps',0)*1e6/s['us'] if s.get('us',0)>0 else None
        if fps is None or not 59.9<=fps<=60.1:errors.append('真实计数帧率未达60FPS范围')
        allowed={'板端未报告完整通过','实际帧/换帧/扫描不等于请求帧数','扫描、欠流或逻辑完整性未通过','真实计数帧率未达60FPS范围','游戏逻辑未按真实时间持续推进'}
        search_eligible=(not pipeline_errors and item.get('status')=='FAIL' and item.get('reason')=='timing' and s.get('frames')==frames and fps is not None and d.get('ticks',0)>0 and not any(e not in allowed for e in errors))
        # A timed-out observation may guide a NEW lower-N request, but never
        # supplies a completed-window upper bound or a PASS certificate.
        timeout_evidence=(self.ack is not None and self.ready is not None and self.stat is not None and self.detail is not None
            and not self.errors and not self.hud_policy_errors and self.ack.get('status')=='OK' and self.ready.get('warmup',0)>=2
            and all(self.ack.get(k)==v for k,v in zip(ARG_NAMES,self.args))
            and 0<s.get('frames',0)<frames and d.get('frames')==s.get('frames') and s.get('swaps')==s.get('frames')
            and s.get('scans',0)>=s.get('swaps',1) and s.get('us',0)>=self.ack.get('deadline_us',0)>0
            and self.ack.get('deadline_us')==min(1800000000,max(20000000,frames*200000))
            and all(s.get(k)==v for k,v in [('nmin',n),('nmax',n),('bmin',b),('bmax',b),('mmin',m),('mmax',m)])
            and d.get('size')==size and d.get('seed')==seed and d.get('cfg')==self.ack.get('cfg')
            and d.get('guards')==0 and d.get('logerr')==0 and d.get('fault')==0
            and d.get('invincible')==0 and d.get('autoplay')==1 and d.get('collision')=='scaled'
            and all(d.get(k)==v for k,v in [('mode',1),('hw',1),('active',1),('paused',0)]) and d.get('ticks',0)>0)
        partial_timeout=(not pipeline_errors and item.get('status')=='FAIL' and item.get('reason')=='timeout' and timeout_evidence)
        result={'request_id':self.request_id,'kind':'GAME_LOAD','args':list(self.args),
            'requested':dict(zip(ARG_NAMES,self.args)),'status':item.get('status','INCOMPLETE'),
            'reason':item.get('reason'),'accepted_pass':not errors,'long_60fps_pass':not errors and frames>=36000,
            'actual_fps':fps,'errors':errors,'ack':self.ack,'ready':self.ready,'stat':self.stat,'detail':self.detail,
            'search_eligible':search_eligible,
            'partial_timeout_observation':partial_timeout,
            'expected_pipeline':self.expected_pipeline,'capabilities':dict(self.capabilities),
            'hud_policy_verified':bool(self.hud_proof_required and not self.hud_policy_errors and all(x and x.get('hud_dma')==self.expected_hud_dma for x in (self.ack,self.ready,self.detail))),
            'hud_policy_evidence':{'required':self.hud_proof_required,'expected':self.expected_hud_dma,'ack':(self.ack or {}).get('hud_dma'),'ready':(self.ready or {}).get('hud_dma'),'detail':d.get('hud_dma'),'errors':list(self.hud_policy_errors)},
            'pipeline_evidence':self.pipeline.export(),
            'pipeline_validation_errors':list(pipeline_errors),
            'visual_policy':{'qmin':d.get('qmin'),'qmax':d.get('qmax'),'lodsum':d.get('lodsum'),'fxdrop':d.get('fxdrop'),'ddrop':d.get('ddrop')},
            'raw_lines':list(self.raw_lines),'scope':'受控游戏负载：人工补弹及角色保活；不代表自然阶段战持续同负载'}
        from engineering_policy import attach_engineering_result
        return attach_engineering_result(result)

def boundary_rows(results):
    """Observed bounds only. Do not assume monotonicity or invent an exact maximum."""
    groups={}
    for result in results:
        b,m,n,size,frames,seed=result['args'];caps=result.get('capabilities') or {}
        path=(result.get('ack') or {}).get('pipe',0);cfg=(result.get('ack') or {}).get('cfg')
        cap_key=tuple((k,caps.get(k)) for k in ('fw','proto','motion','pref','pipe','pref8','batch32','width','height','hz','hud_dma_proof','hud_dma'))
        key=(b,m,size,frames,seed,path,cfg,cap_key)
        row=groups.setdefault(key,{'bosses':b,'enemies':m,'size':size,'frames':frames,'seed':seed,'pipeline':path,'cfg':cfg,'capabilities':dict(caps),'hud_policy_verified':True,'passed':[],'failed':[],'incomplete':[],'partial_timeouts':[]})
        row['hud_policy_verified']=row['hud_policy_verified'] and bool(result.get('hud_policy_verified'))
        category='passed' if result['accepted_pass'] else 'failed' if result.get('search_eligible',False) else 'incomplete'
        row[category].append(n)
        if result.get('partial_timeout_observation'):row['partial_timeouts'].append(n)
    rows=[]
    for row in groups.values():
        low=max(row['passed'],default=None);above=[n for n in row['failed'] if low is None or n>low]
        row.update(verified_lower=low,failed_upper=min(above,default=None),exact_maximum=None,
                   conflicting=any(n<=low for n in row['failed']) if low is not None else False)
        rows.append(row)
    return rows
