"""Visible, device-free download status panel.

Input is a validated DownloadProgress snapshot. This widget does not parse
tool output, launch processes, access devices, or decide whether a job passed.
Its timer changes elapsed/activity labels only, never byte progress.
"""
from __future__ import annotations

import time
from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                               QProgressBar, QSizePolicy)

_STEP = {'files': 1, 'device': 1, 'configure': 2, 'load': 3, 'verify': 4, 'start': 5}
_TITLE = {'files': '检查文件与工具', 'device': '核对开发板', 'configure': '准备/配置烧录通道',
          'load': 'Flash完整写入', 'verify': 'Flash读回核对', 'start': '重新启动并检查LAB1'}
_SHORT = ('检查', '准备通道', 'Flash写入', '读回核对', '启动检查')


class DownloadPanel(QWidget):
    """Fixed-height status, suitable outside the application's scrolling stack.

    ``bar`` and ``detail`` are public aliases for legacy job_progress/job_label.
    Call log_activity() on every nonempty tool message; update_progress() also
    records activity. Only finish() makes a terminal success/failure decision.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('downloadPanel')
        self.setFixedHeight(144)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setStyleSheet('''
            QWidget#downloadPanel {background:#ffffff;border:1px solid #e3e5e8;border-radius:10px;}
            QWidget#downloadPanel QLabel {background:transparent;border:none;color:#34363c;}
            QProgressBar {border:none;border-radius:6px;background:#eaedef;min-height:12px;max-height:12px;}
            QProgressBar::chunk {background:#16846c;border-radius:6px;}
        ''')
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 11, 16, 10)
        layout.setSpacing(7)
        heading = QHBoxLayout()
        self.phase = QLabel('完整烧录到 Flash')
        self.phase.setStyleSheet('font-size:15px;font-weight:600;color:#202123;')
        heading.addWidget(self.phase, 1)
        self.percent = QLabel('待开始')
        self.percent.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.percent.setStyleSheet('font-size:19px;font-weight:700;color:#202123;')
        heading.addWidget(self.percent)
        layout.addLayout(heading)
        stages = QHBoxLayout()
        stages.setSpacing(7)
        self.stage_labels = {}
        for step, title in enumerate(_SHORT, 1):
            label = QLabel(f'{step}  {title}')
            self.stage_labels[step] = label
            stages.addWidget(label, 1)
        layout.addLayout(stages)
        self.bar = QProgressBar()
        self.bar.setTextVisible(False)
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.bar.setFixedHeight(12)
        self.bar.setAccessibleName('当前阶段真实进度')
        layout.addWidget(self.bar)
        bottom = QHBoxLayout()
        self.detail = QLabel('准备好后点击“完整烧录到 Flash”。')
        self.detail.setMinimumWidth(0)
        self.detail.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        self.detail.setStyleSheet('font-size:12px;color:#62666e;')
        bottom.addWidget(self.detail, 1)
        self.elapsed = QLabel('已用 0 秒')
        self.elapsed.setStyleSheet('font-size:12px;color:#62666e;')
        bottom.addWidget(self.elapsed)
        layout.addLayout(bottom)
        self.activity = QLabel('尚未开始 · 烧录期间请保持开发板供电。')
        self.activity.setStyleSheet('font-size:12px;color:#858992;')
        layout.addWidget(self.activity)
        self.timer = QTimer(self)
        self.timer.setInterval(250)
        self.timer.timeout.connect(self._tick)
        self.running = False
        self.check = False
        self.success = None
        self.current_stage = 'files'
        self.current_step = 1
        self.last_snapshot = None
        self._started = self._last_activity = None
        self._elapsed_seconds = 0
        self._dots = 0
        self._refresh_stages(idle=True)

    def reset(self, check: bool = False):
        if type(check) is not bool:
            raise TypeError('check must be bool')
        self.check = check
        self.running = True
        self.success = None
        self.current_stage, self.current_step = 'files', 1
        self.last_snapshot = None
        self._started = self._last_activity = time.monotonic()
        self._elapsed_seconds = self._dots = 0
        self.phase.setText('离线检查 · 检查文件与工具' if check else '阶段 1/5 · 检查文件与工具')
        self.percent.setText('处理中')
        self.percent.setStyleSheet('font-size:19px;font-weight:700;color:#202123;')
        self.bar.setStyleSheet('')
        self.bar.setRange(0, 0)
        self.detail.setText('等待工具返回真实进度 · 不按时间估算百分比')
        self.detail.setToolTip(self.detail.text())
        self._refresh_stages()
        self._tick()
        self.timer.start()

    def log_activity(self):
        if self.running:
            self._last_activity = time.monotonic()
            self._tick()

    def update_progress(self, value: dict):
        if not self.running or not isinstance(value, dict):
            return
        stage = value.get('stage')
        if stage not in _STEP or value.get('step', _STEP[stage]) != _STEP[stage]:
            return
        # Validation belongs to DownloadProgress; these checks merely avoid
        # passing malformed counts to Qt if the widget is used independently.
        done, total = value.get('done'), value.get('total')
        counted = type(done) is int and type(total) is int and 0 <= done <= total and total > 0
        self.current_stage, self.current_step = stage, _STEP[stage]
        self.last_snapshot = dict(value)
        self.phase.setText(('离线检查 · ' if self.check else f'阶段 {self.current_step}/5 · ') + _TITLE[stage])
        if counted:
            # Qt's integer range is signed 32-bit. Scale only enormous counts;
            # the visible percentage/byte text always uses exact real values.
            if total <= 2147483647:
                self.bar.setRange(0, total)
                self.bar.setValue(done)
            else:
                self.bar.setRange(0, 10000)
                self.bar.setValue(done * 10000 // total)
            self.percent.setText(f'{done * 100 / total:.1f}%')
            self.detail.setText(f'本阶段 {done:,} / {total:,} 字节 · 正在核对真实数据')
        else:
            self.bar.setRange(0, 0)
            self.percent.setText('处理中')
            self.detail.setText('工具处理中 · 此阶段未提供可计数进度')
        if value.get('state') == 'done':
            self.detail.setText(self.detail.text().replace('正在核对真实数据', '阶段计数已完成') + ' · 等待任务结束')
        self.detail.setToolTip(self.detail.text())
        self._refresh_stages()
        self.log_activity()

    def finish(self, success: bool, message: str = ''):
        if type(success) is not bool:
            raise TypeError('success must be bool')
        if not self.running:
            return
        self._tick()
        self.running = False
        self.success = success
        self.timer.stop()
        if success:
            if not self.check:
                self.current_stage, self.current_step = 'start', 5
            self.phase.setText('离线检查通过' if self.check else 'Flash写入及读回完成 · 断电启动待确认')
            self.percent.setText('已通过' if self.check else '已写入')
            self.bar.setRange(0, 100)
            self.bar.setValue(100)
            text = message or ('文件和工具已就绪' if self.check else '可以查看当前启动结果，随后验证断电重启')
            if not self.check and '断电启动待确认' not in text:
                text += ' · 断电启动待确认'
            self.detail.setText(text)
            self.activity.setText('● 离线检查已完成 · 未执行Flash写入' if self.check else '● Flash写入及读回已完成 · 断电后启动尚待确认')
        else:
            self.phase.setText(('离线检查未完成 · ' if self.check else f'阶段 {self.current_step}/5 未完成 · ') + _TITLE[self.current_stage])
            self.percent.setText('未完成')
            self.percent.setStyleSheet('font-size:19px;font-weight:700;color:#b24742;')
            self.bar.setStyleSheet('QProgressBar::chunk {background:#b24742;border-radius:6px;}')
            # A full byte count may precede a later failure. Never present it as
            # a completed overall job after a failed process result.
            self.bar.setRange(0, 100)
            self.bar.setValue(0)
            self.detail.setText(message or '请到运行日志查看工具返回的原因。')
            self.activity.setText('● 任务已停止 · 保留发生问题的阶段，等待你的下一步操作')
        self.detail.setToolTip(self.detail.text())
        self._refresh_stages()

    def _refresh_stages(self, idle=False):
        for step, label in self.stage_labels.items():
            if idle or (self.check and step != 1):
                color, weight = '#9599a1', 400
            elif self.success is False and step == self.current_step:
                color, weight = '#b24742', 600
            elif step < self.current_step or (self.success is True and (not self.check or step == 1)):
                color, weight = '#16846c', 600
            elif step == self.current_step:
                color, weight = '#202123', 600
            else:
                color, weight = '#9599a1', 400
            label.setStyleSheet(f'font-size:12px;color:{color};font-weight:{weight};')

    def _tick(self):
        if not self.running:
            return
        now = time.monotonic()
        self._elapsed_seconds = max(0, int(now - self._started))
        silent = max(0., now - self._last_activity)
        self.elapsed.setText(f'已用 {self._elapsed_seconds} 秒')
        self._dots = (self._dots + 1) % 3
        dots = ('● ○ ○', '○ ● ○', '○ ○ ●')[self._dots]
        if silent >= 8:
            status = '一段时间未收到新消息 · 请保持供电，等待工具返回'
        elif silent >= 2:
            status = '工具处理中，等待返回'
        else:
            status = '正在接收工具消息'
        self.activity.setText(f'{dots}  {status} · 最后消息 {int(silent)} 秒前')
