"""Explicit long-window engineering tolerance; strict board verdict is immutable."""
POLICY_ID='LONG36000_RAW5999_MISS6_V1'
ALLOWED_STRICT_ERRORS={
    '逻辑截止时间存在积压','板端未报告完整通过',
    '实际帧/换帧/扫描不等于请求帧数','扫描、欠流或逻辑完整性未通过',
    '游戏逻辑未按真实时间持续推进',
}

def engineering_evaluate(result):
    from game_load_protocol import parse_game_load_reply
    errors=[]
    def check(ok,text):
        if not ok:errors.append(text)
    args=result.get('args') or []
    if len(args)!=6:return {'pass':False,'errors':['缺少完整请求参数'],'policy':POLICY_ID}
    b,m,n,size,target,seed=args
    s=result.get('stat') or {};d=result.get('detail') or {};a=result.get('ack') or {}
    ready=result.get('ready') or {}
    check(bool(a and ready and s and d) and a.get('status')=='OK' and ready.get('warmup')==2,'ACK、预热或最终完整回包缺失')
    p=result.get('pipeline_evidence') or {};final=p.get('final') or {}
    check(target==36000,'工程容差仅适用于完整36000帧长测')
    check((result.get('status'),result.get('reason')) in {('PASS','complete'),('FAIL','timing'),('FAIL','pipeline')},'原结束状态不是完整计时结果')
    check(not any(x not in ALLOWED_STRICT_ERRORS for x in result.get('errors',[])),'存在容差以外的严格验收错误')
    check(not any(x!='逻辑截止时间存在积压' for x in result.get('pipeline_validation_errors',[])),'流水身份或完整性未通过')
    check(result.get('hud_policy_verified') is True,'实际HUD绘图策略未核对')
    check(all(s.get(k)==target for k in ('frames','swaps')) and d.get('frames')==target and d.get('ticks')==target,'呈现、换帧或逻辑步数未完整达到36000')
    missed=s.get('missed');us=s.get('us')
    check(type(missed)is int and 0<=missed<=6,'累计错过换帧超过6或缺失')
    check(type(us)is int and us>0 and s.get('swaps',0)*100000000>=5999*us and s.get('swaps',0)*10000000<=601*us,'原始计数FPS不在59.99至60.1范围')
    rows=[]
    for raw in result.get('raw_lines',[]):
        item=parse_game_load_reply(raw)
        if item and item.get('id')==result.get('request_id'):rows.append(item)
    stats=[x for x in rows if x['kind_line']=='GLOAD_STAT']
    details=[x for x in rows if x['kind_line']=='GLOAD_DETAIL']
    expected=list(range(60,36001,60))
    check([x.get('frames')for x in stats]==expected and [x.get('frames')for x in details]==expected,'完整600组原始样本缺失、重复或倒退')
    by_frame={x['frames']:x for x in stats}
    for x in stats:
        miss=x.get('missed',-1);count=x.get('frames',0)
        check(type(miss)is int and 0<=miss<=6 and x.get('scans')==count+miss and x.get('swaps')==count,'扫描差额与累计错过换帧不一致')
        check(x.get('gap') in (1,2) and (x.get('gap')==1 if miss==0 else True),'单次扫描间隔超出容差')
        check(type(x.get('late'))is int and 0<=x['late']<=miss,'迟到次数超过对应扫描差额')
        check(all(x.get(k)==0 for k in ('uf','ldrop','lover')),'欠流或真实逻辑丢步/超限')
        check(all(x.get(k)==v for k,v in [('nmin',n),('nmax',n),('bmin',b),('bmax',b),('mmin',m),('mmax',m)]),'真实同屏负载发生变化')
    for x in details:
        check(all(x.get(k)==0 for k in ('guards','logerr','fault','fxdrop','ddrop')),'守卫、日志、故障或画质丢弃计数非零')
        check(x.get('qmin')==x.get('qmax')==1,'原效果质量档位不一致')
        check(x.get('ticks')==x.get('frames') and x.get('cfg')==a.get('cfg') and x.get('size')==size and x.get('seed')==seed,'逻辑步数、尺寸、种子或配置不一致')
    windows=[*p.get('samples',[]),final]
    check([x.get('frames')for x in windows]==expected,'完整呈现流水样本缺失')
    for x in windows:
        st=by_frame.get(x.get('frames'),{});budget=st.get('missed',-1);backlog=x.get('backlog',-1)
        check(type(backlog)is int and 0<=backlog<=budget<=6,'累计排期差额超出对应扫描容差')
        check(x.get('presented_delta')==x.get('frames')==x.get('logic_committed_delta') and x.get('latency')==1 and x.get('fallback')==0,'呈现、逻辑提交或延迟语义改变')
    check(s.get('scans')==target+(missed if type(missed)is int else -100),'最终扫描计数不一致')
    if type(us)is int and us>0 and type(missed)is int:
        ticks_expected=(us*60+500000)//1000000
        check(0<=ticks_expected-target<=missed+1,'真实时间与已完成逻辑差额超出扫描容差')
    errors=list(dict.fromkeys(errors))
    return {'pass':not errors,'errors':errors,'policy':POLICY_ID}

def attach_engineering_result(result):
    verdict=engineering_evaluate(result)
    result['engineering_long_pass']=verdict['pass']
    result['engineering_errors']=verdict['errors']
    result['engineering_policy']=verdict['policy']
    result['original_board_verdict']={'status':result.get('status'),'reason':result.get('reason')}
    return result
