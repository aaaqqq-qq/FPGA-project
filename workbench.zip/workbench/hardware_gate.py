"""Strict, file-only provenance gate for the 100MHz motion plus preflight platform.

No USB, UART, JTAG, programmer, subprocess, or hardware-library import exists.
An accepted report describes offline engineering evidence, never board success.
"""
from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET

RELEASE_ID='GAME60_PIPELINE_5'
BOOT_MARKER='PHASE BATTLE v3 LAB23 PC CONTROL GAME60_PIPELINE_5'
CAPS={'adv':1,'img':1,'perf':1,'game_load':1,'gsizes':7,'batch32':1,'motion':1,'pref':1,'pipe':1,'pref8':1}
BASE_PINS_SHA='81b9e2899ad3dd50d4ff2e9bb0767fff255b1e1cd5e5e813a206a546d3e53ba4'
SCOPE_SHA='fc11488ffca208c7238830341c37dd56da8418c5bc8a9ac0156813ad108d2989'
TOOL_PINS_SHA='6b72264b024d90e40edc03e64f35041ae76119b71f972cbb7fe4b0fc9aca5632'
ALLOWED_RTL={f'hw/game/rtl/{n}.sv'for n in ('game_apb','game_fabric','render_engine','sprite_batch_engine','bitblt_engine')}
ACTIVE_INSERT=bytes.fromhex('eacf8968eacf8968eacf8968eacf8968f8435835')
SYNC=bytes.fromhex('168a2236')

class EvidenceError(ValueError):pass
def require(ok,msg):
 if not ok:raise EvidenceError(msg)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def _unique(pairs):
 out={}
 for k,v in pairs:require(k not in out,'Duplicate JSON key: '+k);out[k]=v
 return out
def json_file(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'),object_pairs_hook=_unique)
def safe_path(base,rel):
 require(isinstance(rel,str)and rel and ':'not in rel and not rel.startswith(('/','\\'))and'..'not in rel.replace('\\','/').split('/'),'Unsafe evidence path')
 b=Path(base).resolve();p=(b/rel).resolve()
 require(p.is_relative_to(b)and p.is_file(),'Missing or escaping evidence: '+rel)
 return p
def pinned(p,sha):
 require(isinstance(sha,str)and re.fullmatch('[0-9a-f]{64}',sha),'Missing explicit review SHA256')
 require(digest(p)==sha,'Pinned evidence changed: '+str(p));return Path(p)
def decode_hex(p):
 lines=Path(p).read_text(encoding='ascii').splitlines()
 require(bool(lines)and all(re.fullmatch('[0-9a-fA-F]{2}',x)for x in lines),'Not exact Efinity byte-per-line HEX')
 return bytes.fromhex(''.join(lines))
def validate_bit_hex(bit,hx,reproduced_bit,reproduced_hex):
 b,h=decode_hex(bit),decode_hex(hx)
 require(len(b)>424 and len(h)==len(b)+20,'Unexpected bit/HEX format length')
 require(b[:256].decode('ascii').find('Mode: passive')>=0 and h[:256].decode('ascii').find('Mode: active')>=0,'Wrong bit/HEX programming modes')
 require(b[256:260]==h[256:260]==SYNC,'Missing fixed Ti60 configuration sync')
 rb,rh=decode_hex(reproduced_bit),decode_hex(reproduced_hex)
 require(Path(bit).resolve()!=Path(reproduced_bit).resolve()and Path(hx).resolve()!=Path(reproduced_hex).resolve(),'Reproduction must be a separate output')
 require(b[256:]==rb[256:]and h[256:]==rh[256:]and len(b)==len(rb)and len(h)==len(rh),'Independent vendor reproduction differs')
 # Do not invent an interpretation of private active/passive control words.
 # Same-LBF vendor generation and independent full configuration reproduction
 # prove provenance. Exact differences are recorded, never arbitrarily masked.
 prefix_diffs=[{'decoded_offset':i,'bit_byte':b[i],'hex_byte':h[i]}for i in range(256,404)if b[i]!=h[i]]
 return {'status':'PASS_SAME_VENDOR_SOURCE_AND_REPRODUCED_CONFIGURATIONS','bit_configuration_sha256':hashlib.sha256(b[256:]).hexdigest(),'hex_configuration_sha256':hashlib.sha256(h[256:]).hexdigest(),'active_passive_prefix_differences':prefix_diffs,'active_only_insert_hex':h[404:424].hex(),'configuration_tail_byte_identical':b[404:]==h[424:],'private_control_word_interpretation':'NOT_ASSERTED'}
def timing_rows(text):
 require('Version: 2026.1.132'in text and'Timing Model: I3'in text,'Wrong timing tool/model')
 require('Setup (Max) Clock Relationship'in text and'NOTE: Values'in text,'Incomplete timing report')
 body=text.split('Setup (Max) Clock Relationship',1)[1].split('NOTE: Values',1)[0];kind='setup';out=[]
 for line in body.splitlines():
  if line.startswith('Hold (Min)'):kind='hold'
  m=re.match(r'^\s*(\S+)\s+(\S+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+\(([RF]-[RF])\)',line)
  if m:out.append(dict(kind=kind,launch=m[1],capture=m[2],edge=m[5],constraint_ns=float(m[3]),slack_ns=float(m[4])))
 require(out and all(x['slack_ns']>=0 for x in out),'Negative/incomplete final setup/hold')
 return out
PROJECT_XML='hw/game/par/ddr_demo_ti60/ddr_demo_ti60.xml'
NEW_RTL={f'hw/game/rtl/{n}.sv'for n in ('motion_engine','motion_cache_dma','motion_trig_rom','render_axi_arbiter')}
BASE_PROJECT_SHA='78c481f0201d355228274ba07a20911a80a3f45b83fe32c3efb520f1133a5243'

def validate_project_xml(project,baseline_path):
 current=ET.parse(safe_path(project,PROJECT_XML)).getroot()
 baseline=ET.parse(pinned(baseline_path,BASE_PROJECT_SHA)).getroot()
 expected={'../../rtl/'+Path(x).name for x in NEW_RTL};seen=set()
 designs=current.findall('{http://www.efinixinc.com/enf_proj}design_info')
 require(len(designs)==1,'Exactly one direct design_info required')
 for parent in current.iter():
  for node in list(parent):
   name=node.get('name')
   if node.tag=='{http://www.efinixinc.com/enf_proj}design_file' and name in expected:
    require(parent is designs[0] and not list(node) and not (node.text or '').strip() and not (node.tail or '').strip(),'Motion source must be an empty direct design_info child')
    require(name not in seen and node.attrib=={'name':name,'version':'default','library':'default'},'Changed/duplicated motion source entry')
    seen.add(name);parent.remove(node)
 require(seen==expected,'Four motion/concurrent-AXI source declarations required')
 def normalized(node):return (node.tag,sorted(node.attrib.items()),(node.text or '').strip(),[normalized(x)for x in node])
 require(normalized(current)==normalized(baseline),'Project XML changed beyond the four source declarations')

def validate_sources(project,start,baseline):
 rows=start.get('source_inputs');require(isinstance(rows,list)and len(rows)==83,'Need all83 frozen HW inputs')
 old={x['path']:x for x in baseline['inputs']};actual={};changed=[]
 require(len(old)==79 and not NEW_RTL.intersection(old),'Baseline source count changed')
 for x in rows:
  name=x['path'];require(name not in actual and (name in old or name in NEW_RTL),'New/duplicate HW dependency')
  want=x.get('sha256',x.get('source_sha256'));require(isinstance(want,str),'Missing frozen input digest')
  p=safe_path(project,name);pinned(p,want);require(p.stat().st_size==x['bytes'],'Frozen input length mismatch')
  actual[name]=want
  if name not in old or want!=old[name]['sha256']:changed.append(name)
 require(set(actual)==set(old)|NEW_RTL,'Frozen HW dependency set changed')
 require(set(changed)==ALLOWED_RTL|NEW_RTL|{PROJECT_XML},'Only reviewed renderer/motion RTL and project source declarations may differ')
 return changed

def map_memory_resources(text):
 # Efinity omits zero-use primitive types; each present final histogram row
 # must be unique. DPRAM10 consumes the same finite physical memory pool.
 found=re.findall(r'^EFX_(RAM10|DPRAM10)\s*:\s*(\d+)\s*$',text,re.M)
 counts={}
 for name,count in found:
  require(name not in counts,'Duplicated synthesis memory primitive summary')
  counts[name]=int(count)
 require(set(re.findall(r'^EFX_(RAM10|DPRAM10)\s*:',text,re.M))==set(counts),'Malformed synthesis memory primitive summary')
 require('RAM10'in counts,'Missing synthesis RAM10 primitive summary')
 ram=counts['RAM10'];dual=counts.get('DPRAM10',0);total=ram+dual
 require(total<=256,'Synthesis RAM10+DPRAM10 exceeds256 physical blocks')
 return {'EFX_RAM10':ram,'EFX_DPRAM10':dual,'physical_memory_blocks':total,'capacity':256}

def validate_review(review_path,expected_sha256,bundle_root):
 root=Path(bundle_root).resolve();review_path=Path(review_path).resolve()
 require(review_path.is_relative_to(root),'Hardware review must be inside the release bundle')
 pinned(review_path,expected_sha256);d=json_file(review_path)
 require(d.get('schema')=='ti60_verified_hw_build_v1'and d.get('status')=='HARDWARE_TIMING_REVIEWED','Hardware is NOT_READY or not reviewed')
 require(d.get('release_id')==RELEASE_ID and d.get('board')=='Ti60F225I3-V4'and type(d.get('clock_mhz'))is int and d['clock_mhz']==100,'Hardware release/clock mismatch')
 require(d.get('hardware_accessed')is False and d.get('flash_written')is False,'Offline HW proof must not claim board work')
 project_rel=d.get('project_rel');require(project_rel=='projects/touhou_LAB','Only fixed bundle project accepted')
 project=root/project_rel;require(project.is_dir(),'Frozen project snapshot missing')
 roles={}
 for x in d.get('artifacts',[]):
  role=x.get('role');require(isinstance(role,str)and role not in roles,'Duplicate evidence role')
  p=safe_path(project,x.get('path'));pinned(p,x.get('sha256'));require(p.stat().st_size==x.get('bytes'),'Evidence length mismatch');roles[role]=p
 needed={'build_start','map_execution','map_rpt','map_v','map_out','remaining_execution','timing','coverage','sta_log','collections','route_xml','pgm_log','pgm_trace','lbf','lpf','or_ini','bit','hex','loaded_sdc','reproduction','reproduced_bit','reproduced_hex'}
 require(needed<=set(roles),'Missing full hardware evidence roles')
 base=json_file(pinned(root/'reference/baseline_input_pins.json',BASE_PINS_SHA))
 scope=json_file(pinned(root/'reference/baseline_timing_scope.json',SCOPE_SHA))
 changed=validate_sources(project,json_file(roles['build_start']),base)
 validate_project_xml(project,root/'reference/baseline_project.xml')
 memory=map_memory_resources(roles['map_rpt'].read_text(errors='replace'))
 mapping=json_file(roles['map_execution']);run=json_file(roles['remaining_execution'])
 require(mapping.get('exit_code')==0 and mapping.get('source_inputs_unchanged')is True,'Map failed or sources changed')
 map_outputs={x['name']:x for x in mapping.get('artifacts',[])}
 for role in ('map_rpt','map_v','map_out'):
  require(roles[role].name in map_outputs and map_outputs[roles[role].name]['sha256']==digest(roles[role]),'Frozen map output differs from executed source job')
 require(mapping.get('input_manifest_sha256')==run.get('input_manifest_sha256')==digest(roles['build_start']),'Build-start chain mismatch')
 require(run.get('status')=='COMPLETED_PENDING_INDEPENDENT_TIMING_REVIEW'and run.get('source_inputs_unchanged')is True and run.get('process_architecture')=='AMD64','Incomplete/changed full tool run')
 require(run.get('hardware_accessed')is False and run.get('flash_written')is False,'Unexpected device operation in HW flow')
 tools=json_file(pinned(root/'reference/efinity_tool_pins.json',TOOL_PINS_SHA))
 observed={x['path'].replace('\\','/').lower():x['sha256']for x in run.get('tools',[])}
 require(observed==tools,'Missing or changed Efinity tool/script identity')
 require('base_version=2026.1.132'in run.get('tool_manifest','')or'base_version 2026.1.132'in run.get('tool_manifest','')or'2026.1.132'in run.get('tool_manifest',''),'Tool version evidence missing')
 phases=run.get('phases');require(isinstance(phases,list)and[x.get('flow')for x in phases]==['interface','pnr','pgm','sta_tclsh'],'Need full ordered tool phases')
 for x in phases:
  require(x.get('exit_code')==0 and x.get('source_inputs_unchanged')is True,'Tool stage failed or input changed')
  args=x.get('efinity_argv',[]);require('--flow'in args and args[args.index('--flow')+1]==x['flow']and not any('program'in str(v).lower()or'ftdi'in str(v).lower()for v in args),'Unacceptable tool flow args')
 pgm=phases[2];require(pgm.get('bit_hex_absent_before')is True and pgm.get('source_lbf_sha256_before')==digest(roles['lbf']),'No fresh same-run bit generation source')
 gen={x['name']:x for x in pgm.get('generated_artifacts',[])}
 for role in ('bit','hex'):
  require(roles[role].name in gen and gen[roles[role].name]['sha256']==digest(roles[role]),'Platform output not generated in this exact job')
 log=roles['pgm_log'].read_text(errors='replace')
 require('Missing Interface Designer'not in log and'Using source file'in log and'Generating bit file:'in log,'Bit generator source/output trace missing')
 rep=json_file(roles['reproduction'])
 require(rep.get('status')=='PASS'and rep.get('exit_code')==0 and rep.get('source_inputs_unchanged')is True and rep.get('hardware_accessed')is False and rep.get('flash_written')is False,'Independent vendor reproduction incomplete')
 require(rep.get('source_job_pgm_log_sha256')==digest(roles['pgm_trace']),'Reproduction is not bound to same source job')
 for flag,role in [('--source','lbf'),('--periph','lpf'),('--interface_designer_settings','or_ini')]:require(rep.get('inputs',{}).get(flag,{}).get('sha256')==digest(roles[role]),'Reproduction used a different vendor input')
 for kind in ('bit','hex'):
  output=next((x for x in rep.get('outputs',[])if x.get('kind')==kind),{})
  require(output.get('original_sha256')==digest(roles[kind])and output.get('reproduced_sha256')==digest(roles['reproduced_'+kind])and output.get('configuration_byte_identical')is True,'Vendor reproduction output identity mismatch')
 relation=validate_bit_hex(roles['bit'],roles['hex'],roles['reproduced_bit'],roles['reproduced_hex'])
 rows=timing_rows(roles['timing'].read_text(errors='replace'))
 keys=lambda xs:{tuple(x[k]for k in ('kind','launch','capture','edge'))for x in xs}
 require(keys(rows)==keys(scope['relationships']),'Synchronous clock relationship coverage changed')
 core=next(x for x in rows if x['kind']=='setup'and x['launch']==x['capture']=='core_clk');require(core['constraint_ns']==10.0,'Core is not100MHz')
 cov=roles['coverage'].read_text(errors='replace');counts={k:int(v)for k,v in re.findall(r'^\d+\. checking (\S+) \((\d+)\)',cov,re.M)}
 require(counts==scope['check_timing_counts'],'New/changed legacy timing-coverage findings require review')
 require('clk_100m~CLKOUT~201~322'in cov,'Legacy peripheral feedback finding missing')
 sta=roles['sta_log'].read_text(errors='replace')
 for kind in ('setup','hold'):
  m=re.search('QUERY_BEGIN '+kind+'_negative(.*?)QUERY_END '+kind+'_negative',sta,re.S)
  require(m and'No timing path is found'in m[1],'Missing exhaustive negative-'+kind+' query')
 require('FANOUT_MEMBERS_IN_ALL_REGISTERS=0'in sta and'CLK100M_REGISTER_NAME_MATCHES=0'in sta,'Unresolved peripheral feedback load')
 collection_meta=json_file(roles['collections']);obs=re.findall(r'^SDC_COLLECTION (\d+) \S+ (\d+)',sta,re.M)
 require(len(obs)==len({int(i)for i,_ in obs})==scope['collection_count']==len(collection_meta['active_sdc_collections'])and all(int(n)>0 for _,n in obs),'Empty, missing or duplicated user-SDC collection')
 resources=ET.parse(roles['route_xml']).getroot();data={x.get('name'):x.get('value')for x in resources.iter()if x.tag.split('}')[-1]=='group_data'}
 for label,maxval in [('Memory Blocks',256),('DSP Blocks',160),('XLRs',60800)]:
  require(label in data and int(data[label].split('/')[0].strip())<=maxval,'Exceeded/missing final P&R resource: '+label)
 require(int(data['Memory Blocks'].split('/')[0].strip())==memory['physical_memory_blocks'],'P&R memory count differs from RAM10+DPRAM10 synthesis total')
 require(d.get('legacy_external_interface_signoff')=='NOT_VERIFIED','Do not turn external physical gaps into PASS')
 require(type(d.get('new_bram_blocks'))is int and d['new_bram_blocks']==-3 and memory=={'EFX_RAM10':242,'EFX_DPRAM10':10,'physical_memory_blocks':252,'capacity':256},'Reviewed QUADSKIP layout requires242RAM10+10DPRAM10=252, delta-3 fromCOPY4')
 return {'status':'PASS_OFFLINE_HW_EVIDENCE','review_sha256':expected_sha256,'release_id':RELEASE_ID,'bit_sha256':digest(roles['bit']),'hex_sha256':digest(roles['hex']),'lbf_sha256':digest(roles['lbf']),'changed_rtl':changed,'memory_resources':memory,'core_setup_slack_ns':core['slack_ns'],'worst_setup_slack_ns':min(x['slack_ns']for x in rows if x['kind']=='setup'),'worst_hold_slack_ns':min(x['slack_ns']for x in rows if x['kind']=='hold'),'bit_hex_relation':relation,'legacy_external_interface_signoff':'NOT_VERIFIED','hardware_accessed':False}
