"""Strict, file-only verification of PIPE5 presented-state evidence.

An outstanding future logic state never counts as the displayed state. The
explicit single prime is outside T0..T1; all F steps and F presents are inside.
This module does not infer FPS or physical validity from a capability bit.
"""
from dataclasses import dataclass,field
import re

PRIME_FIELDS='pipe warmup prime_us prime_logic prime_present live_start live_end presented_start presented_end input_start input_end n_start n_end r_epoch snap_epoch m_epoch latency'.split()
WINDOW_FIELDS='pipe frames presented_delta logic_committed_delta live_epoch presented_epoch input_epoch frame_epoch snap_epoch latency backlog fallback'.split()
VIEW_FIELDS='state_epoch input_epoch n b m cfg mode hw active paused hp score lv hit grazes graze_total quality lod visual bg opaque alpha key alpha_enable draw_n key_rgb'.split()
MOTION_FIELDS='submitted completed cycles_last read_last write_last'.split()

def parse_pipeline_reply(raw):
    if not isinstance(raw,str):return None
    raw=raw.strip()
    if not raw.isascii() or len(raw)>512:return None
    parts=raw.split()
    if not parts or parts[0] not in ('GLOAD_PIPE','GLOAD_VIEW','MOTION_DIAG'):return None
    data={'kind_line':parts[0],'raw':raw}
    for token in parts[1:]:
        if '=' not in token:return None
        k,v=token.split('=',1)
        if not re.fullmatch('[a-z][a-z0-9_]*',k) or k in data:return None
        if k=='phase':data[k]=v
        elif re.fullmatch('[0-9]+',v) and int(v)<=0xffffffff:data[k]=int(v)
        else:return None
    if type(data.get('id')) is not int or not 1<=data['id']<=0xffffffff:return None
    kind=parts[0];phase=data.get('phase')
    if kind=='MOTION_DIAG':fields=MOTION_FIELDS;keys={'id',*fields}
    elif kind=='GLOAD_PIPE':
        if phase not in ('prime','sample','final'):return None
        fields=PRIME_FIELDS if phase=='prime' else WINDOW_FIELDS;keys={'id','phase',*fields}
    else:
        if phase not in ('sample','final'):return None
        fields=VIEW_FIELDS;keys={'id','phase',*fields}
    if set(data)-{'kind_line','raw'}!=keys:return None
    if any(type(data.get(k)) is not int for k in fields):return None
    return data

@dataclass
class PipelineEvidence:
    prime:dict|None=None
    final:dict|None=None
    view:dict|None=None
    motion:dict|None=None
    samples:list=field(default_factory=list)
    views:list=field(default_factory=list)
    errors:list=field(default_factory=list)
    terminal_seen:bool=False

    def feed(self,item,*,ack_seen,ready_seen,detail_seen):
        kind=item['kind_line'];phase=item.get('phase')
        if kind not in ('GLOAD_PIPE','GLOAD_VIEW','MOTION_DIAG'):return
        if not ack_seen:self.errors.append('流水证据早于请求确认')
        if self.terminal_seen:self.errors.append('流水证据晚于结束回包')
        if kind=='GLOAD_PIPE' and phase=='prime':
            if ready_seen or self.prime:self.errors.append('预计算重复或晚于T0准备确认')
            self.prime=item
        elif kind=='MOTION_DIAG':
            if not ready_seen or not detail_seen:self.errors.append('运动完成计数早于测量明细')
            if self.motion:self.errors.append('运动完成计数重复')
            if self.final or self.view:self.errors.append('运动完成计数晚于最终状态')
            self.motion=item
        elif phase=='final':
            if not ready_seen or not detail_seen:self.errors.append('最终流水证据缺少测量窗口')
            if kind=='GLOAD_PIPE' and not self.motion:self.errors.append('最终流水状态早于运动完成计数')
            if kind=='GLOAD_VIEW' and not self.final:self.errors.append('最终画面快照早于最终流水状态')
            attr='final' if kind=='GLOAD_PIPE' else 'view'
            if getattr(self,attr):self.errors.append('最终流水证据重复')
            setattr(self,attr,item)
        else:
            if self.motion or self.final or self.view:self.errors.append('流水样本晚于最终测量证据')
            target=self.samples if kind=='GLOAD_PIPE' else self.views
            epoch_key='frames' if kind=='GLOAD_PIPE' else 'state_epoch'
            if not ready_seen:self.errors.append('流水样本早于T0准备确认')
            if target and item[epoch_key]<=target[-1][epoch_key]:self.errors.append('流水样本倒退或重复')
            target.append(item)

    def validate(self,ack,ready,stat,detail,args,expected=None):
        errors=list(self.errors);a=ack or {};r=ready or {};s=stat or {};d=detail or {}
        pipe=a.get('pipe',0)
        if type(pipe) is not int or pipe not in (0,1):errors.append('流水路径声明无效')
        if expected is True and pipe!=1:errors.append('目标请求未使用已确认流水路径')
        if expected is False and pipe==1:errors.append('流水路径未获实际能力确认')
        if pipe!=1:
            if any(x.get('pipe',0)!=0 for x in (r,d)) or self.prime or self.final or self.view or self.samples or self.views:
                errors.append('串行请求混入流水证据')
            return errors
        b,m,n,size,frames,seed=args
        if size not in (8,32):errors.append('流水尺寸不受支持')
        if any(x.get('pipe')!=1 for x in (a,r,d)):errors.append('ACK/READY/DETAIL流水路径不一致')
        if r.get('prime')!=1 or r.get('warmup')!=2:errors.append('必须恰好两次预热和一次显式预计算')
        p=self.prime or {};f=self.final or {};v=self.view or {};motion=self.motion or {}
        if not self.prime or not self.final or not self.view or not self.motion:errors.append('缺少预计算、最终状态、画面快照或运动完成证据')
        expected_prime={'pipe':1,'warmup':2,'prime_logic':1,'prime_present':1,'live_start':0,'live_end':1,
            'presented_start':0,'presented_end':0,'input_start':0,'input_end':1,'n_start':n,'n_end':n,'latency':1}
        if any(p.get(k)!=value for k,value in expected_prime.items()) or not p.get('prime_us',0):errors.append('预计算没有独立、完整地执行一次')
        if not p.get('r_epoch',0) or p.get('snap_epoch')!=p.get('r_epoch') or not p.get('m_epoch',0):errors.append('预计算硬件快照或运动epoch未核对')
        for x in [*self.samples,f]:
            count=x.get('frames',-1)
            if not 0<count<=frames or x.get('pipe')!=1:errors.append('流水测量窗口超范围');continue
            if x.get('presented_delta')!=count or x.get('logic_committed_delta')!=count:errors.append('窗口内逻辑推进与实际呈现次数不相等')
            if x.get('live_epoch')!=p.get('live_end',-2)+count or x.get('presented_epoch')!=p.get('presented_end',-2)+count:errors.append('实时状态与呈现状态的epoch不对应')
            if x.get('input_epoch')!=x.get('presented_epoch') or x.get('latency')!=1 or x.get('live_epoch')!=x.get('presented_epoch',-2)+1:errors.append('输入/呈现延迟不是声明的一帧')
            if not x.get('frame_epoch',0) or x.get('frame_epoch')!=x.get('snap_epoch'):errors.append('呈现帧没有对应完成的硬件快照')
            expected_token=((p.get('r_epoch',0)-1+count)%0xffffffff)+1
            if x.get('frame_epoch')!=expected_token:errors.append('呈现帧重复使用或跳过了硬件快照epoch')
            if x.get('backlog')!=0:errors.append('逻辑截止时间存在积压')
            if x.get('fallback')!=0:errors.append('流水目标发生串行回退')
        if f.get('frames')!=s.get('frames') or f.get('presented_delta')!=d.get('ticks'):errors.append('最终流水帧数与原始测量计数不一致')
        if d.get('runtime')!=f.get('live_epoch'):errors.append('实时逻辑计数与已提交状态epoch不一致')
        measured=s.get('frames',0)
        if measured<=0 or motion.get('submitted')!=measured or motion.get('completed')!=measured:errors.append('真实运动提交/完成数不等于窗口逻辑步数')
        # Necessary hardware invariants only: every successful job reads the
        # 128-byte header + 4096-byte LUT; DMA counts complete 16-byte beats.
        # Processing N is additionally bound by the signed driver/RTL proofs.
        read=motion.get('read_last',0);write=motion.get('write_last',0);cycles=motion.get('cycles_last',0)
        if read<4224 or write<128 or read%16 or write%16 or cycles<max(read//16,write//16):errors.append('运动内核周期或事务字节计数不可能成立')
        pipe_windows={x.get('presented_epoch'):x for x in [*self.samples,f]}
        seen_views={}
        for x in [*self.views,v]:
            epoch=x.get('state_epoch');w=pipe_windows.get(epoch)
            if epoch in seen_views and any(x.get(k)!=seen_views[epoch].get(k) for k in VIEW_FIELDS):errors.append('相同呈现epoch的画面快照互相矛盾')
            seen_views[epoch]=x
            if not w or x.get('input_epoch')!=w.get('input_epoch'):errors.append('画面快照与呈现输入状态不一致')
            for k,value in [('n',n),('b',b),('m',m),('cfg',a.get('cfg')),('mode',1),('hw',1),('active',1),('paused',0),('opaque',0),('alpha',224),('key',1),('alpha_enable',1),('draw_n',n),('key_rgb',16711935)]:
                if x.get(k)!=value:errors.append('画面快照负载、状态或Alpha/去背路径不一致');break
            if not 0<=x.get('hp',-1)<=100 or not 1<=x.get('lv',0)<=5:errors.append('画面生命值或等级超出范围')
            if not d.get('qmin',-1)<=x.get('quality',-2)<=d.get('qmax',-1):errors.append('画面质量与全窗质量记录不一致')
        if v.get('state_epoch')!=f.get('presented_epoch'):errors.append('最终画面不是最终已呈现状态')
        return list(dict.fromkeys(errors))

    def export(self):
        return dict(prime=self.prime,final=self.final,view=self.view,motion=self.motion,
            samples=list(self.samples),views=list(self.views),errors=list(self.errors),latency_frames=1 if self.prime else None)
