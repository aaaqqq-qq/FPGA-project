"""Interactive basic-one page. Signals only: never opens a device or process."""
from __future__ import annotations

import re
import time
from pathlib import Path
from PySide6.QtCore import Qt, Signal, QRectF, QTimer
from PySide6.QtGui import QColor, QImage, QPainter, QPen
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QComboBox, QSpinBox, QLineEdit, QStackedWidget,
    QPlainTextEdit, QSizePolicy, QFrame, QFileDialog, QCheckBox, QProgressBar)

from control_core import LabRequestTracker, lab_command
from image_assets import load_image,prepare_image,initial_size,proportional_size,image_canvas
from image_workflow import ImageWorkflow
from image_protocol import IMAGE_OPS

WIDTH, HEIGHT = 1280, 720
BASE = 0xF4F6FA
TILE_COLORS = (0x4C8DFF, 0x7C6DF0, 0x35B89B, 0xF2B65C)
BAR_COLORS = (0xF2F2F2, 0xF1C75B, 0x42C5C2, 0x51B875,
              0xDC6D9B, 0xE76565, 0x5788D9, 0x24262C)
VERIFY_CASES = frozenset(("fill", "fill_edges", "copy", "copy_edges", "grid",
                          "bars", "border", "boundary_reject", "guards_source"))


def preview_image(operation: str, args: list) -> QImage:
    """Independent exact RGB reference, without reading FPGA memory."""
    image = QImage(WIDTH, HEIGHT, QImage.Format_RGB32)
    image.fill(BASE)
    painter = QPainter(image)
    painter.setPen(Qt.NoPen)
    if operation == "fill":
        x, y, w, h, color = args
        painter.fillRect(x, y, w, h, QColor.fromRgb(int(color)))
    elif operation == "copy":
        tile, sx, sy, w, h, dx, dy = args
        # Draw only the requested crop. The modulo is anchored in source space.
        for y in range(h):
            for x in range(w):
                index = ((sx + x) // 8 + ((sy + y) // 8 if tile == 0 else 0)) % 4
                painter.fillRect(dx + x, dy + y, 1, 1, QColor.fromRgb(TILE_COLORS[index]))
    elif operation == "pattern":
        kind = args[0]
        if kind == 0:
            for x in range(0, WIDTH, 40):
                painter.fillRect(x, 0, 1, HEIGHT, QColor(0xD4, 0xD8, 0xE2))
            for y in range(0, HEIGHT, 40):
                painter.fillRect(0, y, WIDTH, 1, QColor(0xD4, 0xD8, 0xE2))
        elif kind == 1:
            for i, color in enumerate(BAR_COLORS):
                painter.fillRect(i * 160, 0, 160, HEIGHT, QColor.fromRgb(color))
        else:
            painter.fillRect(0, 0, WIDTH, HEIGHT, QColor(255, 255, 255))
            painter.fillRect(640, 0, 1, HEIGHT, QColor.fromRgb(TILE_COLORS[0]))
            painter.fillRect(0, 360, WIDTH, 1, QColor.fromRgb(TILE_COLORS[0]))
            for (x, y), color in zip(((12, 12), (1252, 12), (12, 692), (1252, 692)), TILE_COLORS):
                painter.fillRect(x, y, 16, 16, QColor.fromRgb(color))
        border = 4 if kind == 2 else 2
        edge = QColor(0x40, 0x44, 0x4F)
        painter.fillRect(0, 0, WIDTH, border, edge)
        painter.fillRect(0, HEIGHT - border, WIDTH, border, edge)
        painter.fillRect(0, 0, border, HEIGHT, edge)
        painter.fillRect(WIDTH - border, 0, border, HEIGHT, edge)
    painter.end()
    return image


class LabPreview(QWidget):
    def __init__(self):
        super().__init__()
        self.image = preview_image("clear", [])
        self.setMinimumHeight(230)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def set_operation(self, operation: str, args: list) -> None:
        self.image = preview_image(operation, args)
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#fafafa"))
        area = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        scale = min(area.width() / WIDTH, area.height() / HEIGHT)
        target = QRectF((self.width() - WIDTH * scale) / 2,
                        (self.height() - HEIGHT * scale) / 2, WIDTH * scale, HEIGHT * scale)
        p.drawImage(target, self.image)
        p.setPen(QPen(QColor("#e1e3e7"), 1))
        p.drawRect(target)


class LabPanel(QWidget):
    command_requested = Signal(int, str, list)
    export_requested = Signal()
    state_changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.active = False
        self.pending = False
        self.available = False
        self.tracker = LabRequestTracker()
        self._next_id = 1
        self._request_args: list = []
        self._demo: list[tuple[str, list]] = []
        self._demo_due: float | None = None
        self._demo_running = False
        self.results: list[dict] = []
        self.img_capable=False;self.image_asset=None;self.prepared_image=None;self._image_size_guard=False
        self.image_workflow=ImageWorkflow();self._image_raw=[];self._image_recorded_summary=None;self._image_abort_after_status=False
        self.image_timer=QTimer(self);self.image_timer.setInterval(10);self.image_timer.timeout.connect(self._image_tick)
        self._build_ui()
        self._refresh_preview()
        self._refresh_enabled()

    @property
    def blocks_game(self):return self.active or self.pending or self.image_workflow.busy

    def set_capabilities(self,caps):
        capable=bool(caps and caps.get('fw')=='LAB23' and type(caps.get('img')) is int and caps['img']==1)
        self.img_capable=capable;self.image_workflow.invalidate_cache()
        self.image_validation.setText('图片执行需LABIMG1 / img=1；电脑可先导入和预览。' if not capable else '图片功能已核对 · 上传或状态核对后使用。')
        self._refresh_enabled()

    @staticmethod
    def _label(text, muted=False):
        obj = QLabel(text)
        obj.setWordWrap(True)
        if muted:
            obj.setStyleSheet("color:#83858d;font-size:12px;")
        return obj

    @staticmethod
    def _button(text, callback):
        obj = QPushButton(text)
        obj.setCursor(Qt.PointingHandCursor)
        obj.clicked.connect(callback)
        return obj

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 4, 0, 10)
        layout.setSpacing(14)
        title = self._label("基础一 · 填充、复制与显示")
        title.setStyleSheet("font-size:27px;font-weight:600;color:#202123;")
        layout.addWidget(title)
        layout.addWidget(self._label("调整参数，观察独立显示器，再用板端逐像素校验核对结果。", True))
        toolbar = QHBoxLayout()
        self.enter_button = self._button("进入实验", lambda: self.request("enter"))
        self.exit_button = self._button("退出实验", lambda: self.request("exit"))
        self.clear_button = self._button("清空画布", lambda: self.request("clear"))
        self.demo_button = self._button("自动演示", self.start_demo)
        self.verify_button = self._button("自动校验", lambda: self.request("verify"))
        for b in (self.enter_button, self.exit_button, self.clear_button, self.demo_button, self.verify_button):
            toolbar.addWidget(b)
        toolbar.addStretch()
        self.export_button = self._button("导出记录", lambda: self.export_requested.emit())
        toolbar.addWidget(self.export_button)
        layout.addLayout(toolbar)
        self.status = self._label("等待连接支持基础一的固件。", True)
        layout.addWidget(self.status)

        workspace = QHBoxLayout()
        workspace.setSpacing(22)
        controls = QWidget()
        controls.setMaximumWidth(310)
        side = QVBoxLayout(controls)
        side.setContentsMargins(0, 0, 0, 0)
        side.addWidget(self._label("操作参数"))
        self.operation = QComboBox()
        self.operation.addItem("矩形填充 · Fill", "fill")
        self.operation.addItem("区域复制 · Copy", "copy")
        self.operation.addItem("显示测试图 · Pattern", "pattern")
        side.addWidget(self.operation)
        self.forms = QStackedWidget()
        self.fill_fields = self._coordinate_form(("x", "y", "w", "h"), (160, 140, 480, 280), (1279, 719, 1280, 720), self.forms)
        fill_page = self.forms.widget(0)
        self.fill_color = QLineEdit("#4C8DFF")
        self.fill_color.setMaxLength(7)
        fill_page.layout().addWidget(QLabel("颜色 RGB"), 4, 0)
        fill_page.layout().addWidget(self.fill_color, 4, 1)
        self.fill_color.textChanged.connect(self._refresh_preview)
        self.copy_fields = self._coordinate_form(("sx", "sy", "w", "h", "dx", "dy"), (0, 0, 64, 64, 608, 328), (63, 63, 64, 64, 1279, 719), self.forms)
        copy_page = self.forms.widget(1)
        self.tile = QComboBox()
        self.tile.addItem("彩色棋盘 · 64 × 64", 0)
        self.tile.addItem("彩色条纹 · 64 × 64", 1)
        self.tile.addItem("自选图片 · PNG / JPG / BMP", 2)
        copy_page.layout().addWidget(QLabel("源素材"), 6, 0)
        copy_page.layout().addWidget(self.tile, 6, 1)
        self.tile.currentIndexChanged.connect(self._refresh_preview)
        pattern_page = QWidget()
        pattern_layout = QVBoxLayout(pattern_page)
        pattern_layout.setContentsMargins(0, 4, 0, 0)
        self.pattern = QComboBox()
        for text, kind in (("网格与边框", 0), ("八色色条", 1), ("中心线与四角定位", 2)):
            self.pattern.addItem(text, kind)
        pattern_layout.addWidget(self.pattern)
        pattern_layout.addWidget(self._label("用来检查颜色、画布边界与显示位置。", True))
        pattern_layout.addStretch()
        self.forms.addWidget(pattern_page)
        self.pattern.currentIndexChanged.connect(self._refresh_preview)
        self.operation.currentIndexChanged.connect(self._operation_changed)
        side.addWidget(self.forms)
        self._build_image_controls(side)
        self.parameter_hint = self._label("", True)
        side.addWidget(self.parameter_hint)
        self.execute_button = self._button("执行到开发板", self.execute)
        self.execute_button.setObjectName("primary")
        side.addWidget(self.execute_button)
        side.addWidget(self._label("Fill / Copy 每次都先恢复浅灰底色，再绘制当前内容。", True))
        side.addStretch()
        workspace.addWidget(controls)
        right = QVBoxLayout()
        right.addWidget(self._label("电脑示意 · 非板端回传", True))
        self.preview = LabPreview()
        right.addWidget(self.preview, 1)
        right.addWidget(self._label("1280 × 720 RGB · HDMI 60 Hz 输出；操作耗时以板端回包为准。", True))
        workspace.addLayout(right, 1)
        layout.addLayout(workspace, 1)
        result_header = QHBoxLayout()
        result_header.addWidget(self._label("执行结果"))
        result_header.addStretch()
        self.metrics = self._label("耗时 —  ·  硬件周期 —  ·  像素错误 —", True)
        result_header.addWidget(self.metrics)
        layout.addLayout(result_header)
        self.result_log = QPlainTextEdit()
        self.result_log.setReadOnly(True)
        self.result_log.setMaximumBlockCount(250)
        self.result_log.setMaximumHeight(150)
        self.result_log.setPlaceholderText("尚无板端结果。排队确认不等于检验通过。")
        layout.addWidget(self.result_log)
        self.setStyleSheet("QSpinBox{border:1px solid #e1e1e5;border-radius:7px;background:white;padding:6px 8px;min-height:20px;} QStackedWidget{background:white;}")

    def _coordinate_form(self, names, defaults, maxima, stack):
        page = QWidget()
        form = QGridLayout(page)
        form.setContentsMargins(0, 8, 0, 8)
        form.setVerticalSpacing(9)
        fields = {}
        for row, (name, default, maximum) in enumerate(zip(names, defaults, maxima)):
            spin = QSpinBox()
            spin.setRange(1 if name in {"w", "h"} else 0, maximum)
            spin.setValue(default)
            form.addWidget(QLabel(name.upper()), row, 0)
            form.addWidget(spin, row, 1)
            spin.valueChanged.connect(self._refresh_preview)
            fields[name] = spin
        form.setRowStretch(len(names) + 1, 1)
        stack.addWidget(page)
        return fields

    def _operation_changed(self, index):
        self.forms.setCurrentIndex(index)
        self._refresh_preview()

    def _build_image_controls(self,side):
        self.image_controls=QWidget();v=QVBoxLayout(self.image_controls);v.setContentsMargins(0,0,0,0);v.setSpacing(9)
        self.import_button=self._button('导入图片…',self.import_image);v.addWidget(self.import_button)
        self.image_info=self._label('尚未导入图片。',True);self.image_info.setTextFormat(Qt.PlainText);v.addWidget(self.image_info)
        grid=QGridLayout();self.image_width=QSpinBox();self.image_width.setRange(1,1280);self.image_height=QSpinBox();self.image_height.setRange(1,720)
        self.image_x=QSpinBox();self.image_x.setRange(0,1279);self.image_y=QSpinBox();self.image_y.setRange(0,719)
        for row,(name,w) in enumerate((('宽度 / 像素',self.image_width),('高度 / 像素',self.image_height),('位置 X',self.image_x),('位置 Y',self.image_y))):grid.addWidget(QLabel(name),row,0);grid.addWidget(w,row,1)
        v.addLayout(grid);self.image_aspect=QCheckBox('保持原图比例');self.image_aspect.setChecked(True);v.addWidget(self.image_aspect)
        self.image_center=self._button('居中放置',self.center_image);v.addWidget(self.image_center)
        self.image_validation=self._label('只在电脑预览，尚未上传或执行。',True);self.image_validation.setTextFormat(Qt.PlainText);v.addWidget(self.image_validation)
        self.image_progress=QProgressBar();self.image_progress.setRange(0,100);self.image_progress.setValue(0);self.image_progress.setTextVisible(False);v.addWidget(self.image_progress)
        self.image_progress_text=self._label('接收进度以板端DONE为准，ACK不增加进度。',True);v.addWidget(self.image_progress_text)
        row=QHBoxLayout();self.image_reupload=self._button('重新上传',lambda:self.start_image_upload(force=True));self.image_cancel=self._button('取消上传',self.cancel_image);row.addWidget(self.image_reupload);row.addWidget(self.image_cancel);v.addLayout(row)
        self.image_status=self._button('核对板端图片状态',lambda:self.request('imgstatus'));v.addWidget(self.image_status)
        side.addWidget(self.image_controls);self.image_controls.hide()
        self.image_width.valueChanged.connect(lambda:self._image_size_changed('width'));self.image_height.valueChanged.connect(lambda:self._image_size_changed('height'))
        self.image_aspect.toggled.connect(lambda:self._image_size_changed('width'));self.image_x.valueChanged.connect(self._image_position_changed);self.image_y.valueChanged.connect(self._image_position_changed)

    def _import_selected(self):return self.operation.currentData()=='copy' and self.tile.currentData()==2

    def import_image(self,path=None):
        if self.pending or self._demo_running:return False
        if not isinstance(path,(str,Path)):
            path,_=QFileDialog.getOpenFileName(self,'导入基础一复制图片','','图片 (*.png *.jpg *.jpeg *.bmp)')
        if not path:return False
        try:
            asset=load_image(path);self.image_asset=asset;w,h=initial_size(asset)
            self._image_size_guard=True;self.image_width.setValue(w);self.image_height.setValue(h);self._image_size_guard=False
            self._prepare_import();self.center_image()
            self._image_metadata_label()
            self._refresh_preview();return True
        except (ValueError,OSError) as exc:
            self._image_size_guard=False;self.image_asset=None;self.prepared_image=None;self.image_workflow.invalidate_cache();self.image_info.setText('导入失败：'+str(exc));self.image_validation.setText('没有可执行的图片；未上传。');self.preview.set_operation('clear',[]);self._refresh_enabled();return False

    def _image_size_changed(self,changed):
        if self._image_size_guard or self.image_asset is None:return
        if self.image_aspect.isChecked():
            w,h=proportional_size(self.image_asset,self.image_width.value(),self.image_height.value(),changed)
            self._image_size_guard=True;self.image_width.setValue(w);self.image_height.setValue(h);self._image_size_guard=False
        self._prepare_import();self._refresh_preview()

    def _prepare_import(self):
        if self.image_asset is None:return
        try:self.prepared_image=prepare_image(self.image_asset,self.image_width.value(),self.image_height.value())
        except ValueError as exc:self.prepared_image=None;self.image_validation.setText(str(exc));return
        p=self.prepared_image;self.image_workflow.invalidate_cache();self.image_x.setMaximum(WIDTH-p.width);self.image_y.setMaximum(HEIGHT-p.height)
        self.image_progress.setRange(0,len(p.rgb));self.image_progress.setValue(0)
        self.image_validation.setText('电脑已准备 %d × %d · RGB888 %d字节\nCRC32 %u · 尚未上传/复制。'%(p.width,p.height,len(p.rgb),p.crc32))
        self.image_progress_text.setText('0 / %d 字节 · 尺寸改变需重新上传；位置改变可复用已提交源图。'%len(p.rgb));self._image_metadata_label()

    def _image_metadata_label(self):
        if self.image_asset is None:return
        a=self.image_asset;p=self.prepared_image
        self.image_info.setText('%s\n原图 %d × %d · 文件%d字节%s%s'%(a.filename,a.original_width,a.original_height,a.file_bytes,('\n处理 %d × %d · RGB888 %d字节\nCRC32 %u'%(p.width,p.height,len(p.rgb),p.crc32)) if p else '', '\n透明像素铺浅灰底，基础一普通复制。' if a.had_alpha else ''))

    def center_image(self):
        if self.prepared_image:
            p=self.prepared_image;self.image_x.setValue((WIDTH-p.width)//2);self.image_y.setValue((HEIGHT-p.height)//2);self._refresh_preview()

    def _image_position_changed(self,*_):
        if self.prepared_image and not self.image_workflow.busy:
            self.image_validation.setText('目标位置已改变 · 电脑示意；此位置尚未执行。'+('已提交源图可复用。' if self.image_workflow.cache else '需要上传源图。'))
        self._refresh_preview()

    def _current_spec(self):
        op = self.operation.currentData()
        if op == "fill":
            text = self.fill_color.text().strip()
            if not re.fullmatch(r"#?[0-9a-fA-F]{6}", text):
                raise ValueError("颜色请输入 6 位 RGB，例如 #4C8DFF。")
            args = [self.fill_fields[k].value() for k in ("x", "y", "w", "h")]
            args.append(int(text.lstrip("#"), 16))
        elif op == "copy":
            if self.tile.currentData()==2:
                if self.prepared_image is None:raise ValueError('请先导入一张图片。')
                image_canvas(self.prepared_image,self.image_x.value(),self.image_y.value())
                return 'imgcopy',[self.image_workflow.session or 1,self.image_x.value(),self.image_y.value()]
            args = [self.tile.currentData()] + [self.copy_fields[k].value() for k in ("sx", "sy", "w", "h", "dx", "dy")]
        else:
            args = [self.pattern.currentData()]
        lab_command(1, op, *args)  # One shared strict range contract.
        return op, args

    def _refresh_preview(self, *_):
        if not hasattr(self, "preview"):
            return
        imported=self._import_selected();self.image_controls.setVisible(imported)
        self.forms.setMinimumHeight(58 if imported else 0);self.forms.setMaximumHeight(58 if imported else 16777215)
        self.forms.setSizePolicy(QSizePolicy.Preferred,QSizePolicy.Fixed if imported else QSizePolicy.Preferred)
        self.execute_button.setText('上传并复制到开发板' if imported else '执行到开发板')
        for row in range(6):
            for col in (0,1):
                item=self.forms.widget(1).layout().itemAtPosition(row,col)
                if item and item.widget():item.widget().setVisible(not imported)
        try:
            op, args = self._current_spec()
            if op=='imgcopy':self.preview.image=image_canvas(self.prepared_image,self.image_x.value(),self.image_y.value());self.preview.update()
            else:self.preview.set_operation(op, args)
            self.parameter_hint.setText("参数有效 · 修改仅更新电脑示意。")
        except (ValueError, TypeError) as exc:
            self.parameter_hint.setText(str(exc))
        self._refresh_enabled()

    def _refresh_enabled(self):
        ready = self.available and not self.pending and not self._demo_running
        self.enter_button.setEnabled(ready and not self.active)
        self.exit_button.setEnabled(ready and self.active)
        if self.image_workflow.status_required:self.exit_button.setEnabled(False)
        self.clear_button.setEnabled(ready and self.active)
        self.verify_button.setEnabled(ready and self.active)
        self.demo_button.setEnabled(ready)
        if self.image_workflow.uncertain:
            self.clear_button.setEnabled(False);self.verify_button.setEnabled(False);self.demo_button.setEnabled(False)
        editable=not self.pending and not self._demo_running
        self.operation.setEnabled(editable)
        self.forms.setEnabled(editable)
        valid = False
        try:
            self._current_spec()
            valid = True
        except (ValueError, TypeError):
            pass
        image_ready=not self._import_selected() or (self.img_capable and not self.image_workflow.uncertain)
        self.execute_button.setEnabled(ready and self.active and valid and image_ready)
        self.import_button.setEnabled(editable)
        for w in (self.image_width,self.image_height,self.image_x,self.image_y,self.image_aspect,self.image_center):w.setEnabled(editable and self.image_asset is not None)
        self.image_reupload.setEnabled(ready and self.active and self.img_capable and self.prepared_image is not None and not self.image_workflow.uncertain)
        self.image_cancel.setEnabled(self.available and self.img_capable and (self.image_workflow.busy or self.image_workflow.uncertain) and not self.image_workflow.cancel_requested)
        self.image_status.setEnabled(ready and self.active and self.img_capable)
        self.export_button.setEnabled(bool(self.results))

    def set_available(self, available: bool):
        if self.available == bool(available):
            self._refresh_enabled()
            return
        self.available = bool(available)
        if not self.available and self._demo_running:
            self._stop_demo()
        if not self.pending:
            self.status.setText("实验模式已开启。" if self.active and available else "已连接，请先进入基础一实验。" if available else "等待连接支持基础一的固件。")
        self._refresh_enabled()

    def request(self, operation: str, *args, _demo=False, _image=False) -> bool:
        if not self.available or (self.pending and not (_image and self.image_workflow.busy and self.tracker.pending_id is None)) or (self._demo_running and not _demo):
            return False
        if operation in IMAGE_OPS and not self.img_capable:return False
        if self.image_workflow.status_required and operation!='imgstatus':return False
        if self.image_workflow.uncertain and operation not in ('imgstatus','imgabort','exit'):return False
        if operation != "enter" and not self.active:
            self.status.setText("请先进入实验模式。")
            return False
        if operation == "enter" and self.active:
            return False
        try:
            request_id = self._next_id
            lab_command(request_id, operation, *args)
            self.tracker.begin(request_id, operation)
        except (ValueError, RuntimeError, TypeError) as exc:
            self.status.setText(str(exc))
            return False
        self._next_id += 1
        self._request_args = list(args)
        if _image:self.image_workflow.issued(request_id)
        if operation in IMAGE_OPS:self._image_raw=[]
        self.pending = True
        self.status.setText("请求 #%d · %s · 等待板端完成" % (request_id, operation))
        detail=('session=%s offset=%s RGB块=%s字节'%(args[0],args[1],len(args[2])*3//4)) if operation=='imgdata' else ' '.join(map(str,args))
        self.result_log.appendPlainText("#%d %s %s · 已发送，等待结果" % (request_id, operation, detail))
        self._refresh_enabled()
        self.state_changed.emit()
        self.command_requested.emit(request_id, operation, list(args))
        return True

    def execute(self):
        if self._import_selected():return self.start_image_upload()
        try:
            op, args = self._current_spec()
            self.request(op, *args)
        except (ValueError, TypeError) as exc:
            self.status.setText(str(exc))

    def ingest(self, reply: dict):
        if not isinstance(reply, dict) or not self.pending:
            return
        if not self.tracker.receive(reply):
            if self.tracker.pending_id is None and self.tracker.last_result and self.tracker.last_result.get("status") == "TIMEOUT":
                self._timeout(self.tracker.last_result)
            return
        if reply.get('op') in IMAGE_OPS:self._image_raw.append(dict(reply))
        request_id = reply["id"]
        if reply["kind"] == "LAB_ACK":
            self.status.setText("请求 #%d 已排队，等待真实执行结果。" % request_id)
            return
        if reply["kind"] == "LAB_CASE":
            state = "通过" if reply.get("status") == "PASS" and reply.get("errors") == 0 else "失败"
            self.result_log.appendPlainText("#%d · %s · %s · 像素错误 %s" % (request_id, reply.get("case", "?"), state, reply.get("errors", "—")))
            return
        if reply["kind"] != "LAB_DONE":
            return
        if reply.get('op') in IMAGE_OPS:
            self._receive_image_done(reply);return
        self.pending = False
        # A matched error also reports the board's current isolation state.
        # In particular, reconnect -> enter ERROR MODE active=1 must permit exit.
        if reply.get("active") in (0, 1):
            self.active = bool(reply["active"])
        passed = reply.get("status") == "PASS" and reply.get("errors") == 0
        expected_active = 0 if reply["op"] == "exit" else 1
        if passed and reply.get("active") != expected_active:
            passed = False
        if passed and reply["op"] == "verify":
            cases = self.tracker.cases
            passed = (reply.get("passed") == 9 and reply.get("failed") == 0 and len(cases) == 9
                      and {item.get("case") for item in cases} == VERIFY_CASES
                      and all(item.get("status") == "PASS" and item.get("errors") == 0 for item in cases))
        if passed:
            if reply['op']=='exit':self.image_workflow.invalidate_cache();self.image_workflow.uncertain=False;self.image_validation.setText('已退出基础一；再次使用图片需重新上传。')
            elif reply['op'] in {'fill','copy','pattern','clear','verify'}:self.image_validation.setText('画布已被基础实验更新；图片源图缓存可保留，需再次执行复制。')
            if reply["op"] in {"fill", "copy", "pattern", "clear"}:
                self.preview.set_operation(reply["op"], self._request_args)
            elif reply["op"] == "verify":
                self.preview.set_operation("pattern", [2])
        self.results.append(dict(reply, accepted_pass=passed))
        verdict = "通过" if passed else "失败 · " + str(reply.get("code", "回包状态不一致"))
        self.status.setText("请求 #%d · %s · %s" % (request_id, reply["op"], verdict))
        self.metrics.setText("耗时 %s μs  ·  硬件周期 %s  ·  像素错误 %s" % (reply.get("us", "—"), reply.get("hw_cycles", "—"), reply.get("errors", "—")))
        self.result_log.appendPlainText("#%d %s · %s · %s μs / %s cycles / errors=%s" % (request_id, reply["op"], verdict, reply.get("us", "—"), reply.get("hw_cycles", "—"), reply.get("errors", "—")))
        if self._demo_running:
            if passed and self._demo:
                self._demo_due = time.monotonic() + .8
            else:
                self._stop_demo()
        self._refresh_enabled()
        self.state_changed.emit()

    def start_image_upload(self,force=False):
        if (not self.available or not self.active or not self.img_capable or self.pending
                or self._demo_running or self.prepared_image is None or self.image_workflow.uncertain):return False
        if not self.image_workflow.start(self.prepared_image,self.image_x.value(),self.image_y.value(),force):return False
        self._image_recorded_summary=None;self.pending=True
        self.image_progress.setRange(0,len(self.prepared_image.rgb));self.image_progress.setValue(self.image_workflow.offset)
        self.image_validation.setText('等待板端复制和921600像素检查，尚未通过。')
        self.status.setText('图片流程准备中 · 每段等待板端DONE确认');self.image_timer.start();self._refresh_enabled();self.state_changed.emit();return True

    def _image_tick(self):
        wf=self.image_workflow
        if not wf.busy:self.image_timer.stop();return
        if self.available and self.tracker.pending_id is None:
            command=wf.next_command()
            if command and not self.request(command[0],*command[1],_image=True):
                wf.fail('图片步骤未能派发');self._finish_image_state()

    def cancel_image(self):
        if not self.available or not self.img_capable:return False
        if self.image_workflow.status_required:
            if self.pending:return False
            self._image_abort_after_status=True;self.image_validation.setText('状态未知，先等待imgstatus实际完成，确认服务结束后才能中止。')
            return self.request('imgstatus')
        if self.image_workflow.cancel():
            self.pending=True;self.image_timer.start();self.image_validation.setText('正在中止 · 等待在途步骤和imgabort实际完成');self._refresh_enabled();self.state_changed.emit();return True
        return False

    def _receive_image_done(self,reply):
        wf=self.image_workflow;op=reply['op']
        if op=='imgstatus':
            valid=wf.sync_status(reply,self.prepared_image)
            if valid:self.active=bool(reply['active'])
            outcome=dict(accepted_pass=valid,reason='实际状态已核对' if valid else '图片状态回包无效')
            self.image_validation.setText(('板端实际接收 %s / %s字节 · ready=%s；这是源图状态，不是复制画面通过。'%(reply.get('received'),reply.get('total'),reply.get('ready'))) if valid else '状态未确认；图片不可执行。')
            if self._image_abort_after_status:
                self._image_abort_after_status=False
                # Firmware returns BUSY for status while a previous service is
                # running; only a matched PASS permits a subsequent abort.
                if valid and reply['active']==1 and reply['session']==wf.session and wf.session:
                    wf.cancel();self.image_timer.start()
        else:outcome=wf.receive(reply) or dict(accepted_pass=False,reason='图片步骤与当前流程不一致')
        record_image=self.prepared_image if op=='imgstatus' else wf.prepared
        self.results.append(dict(reply,accepted_pass=outcome['accepted_pass'],image=record_image.metadata() if record_image else None,raw_replies=list(self._image_raw)))
        self.result_log.appendPlainText('#%s %s · %s · 接收%s/%s · ready=%s · verified=%s'%(reply['id'],op,'已核对' if outcome['accepted_pass'] else outcome['reason'],reply.get('received','—'),reply.get('total','—'),reply.get('ready','—'),reply.get('verified','—')))
        self.image_progress.setValue(wf.offset)
        self.image_progress_text.setText('板端已确认 %d / %d 字节 · %s'%(wf.offset,len(wf.prepared.rgb) if wf.prepared else 0,wf.phase))
        self.metrics.setText('耗时 %s μs · 图片校验 %s 像素 · 错误 %s'%(reply.get('us','—'),reply.get('verified','—'),reply.get('errors','—')))
        if wf.busy:self.status.setText('图片流程进行中 · '+wf.phase+' · 等待下一独立DONE')
        else:self.status.setText('请求 #%s · %s · %s'%(reply['id'],op,'已核对' if outcome['accepted_pass'] else outcome['reason']))
        self._finish_image_state()

    def _finish_image_state(self):
        wf=self.image_workflow;self.pending=wf.busy or self.tracker.pending_id is not None
        if not wf.busy:self.image_timer.stop()
        if wf.last_summary and wf.last_summary is not self._image_recorded_summary:
            self._image_recorded_summary=wf.last_summary;self.results.append(dict(kind='LOCAL_IMAGE_FLOW',**wf.last_summary))
            self.status.setText('图片流程 · '+('通过 · 真实画面921600像素核对' if wf.last_summary['accepted_pass'] else wf.last_summary['status']+' · '+wf.last_summary['reason']))
            self.image_validation.setText(self.status.text())
        self._refresh_enabled();self.state_changed.emit()

    def start_demo(self):
        if not self.available or self.pending or self._demo_running:
            return
        self._demo = ([] if self.active else [("enter", [])]) + [
            ("clear", []), ("fill", [160, 140, 480, 280, 0x4C8DFF]),
            ("fill", [440, 240, 360, 240, 0xF2B65C]),
            ("copy", [0, 0, 0, 64, 64, 608, 328]), ("pattern", [1])]
        self._demo_running = True
        self._demo_due = time.monotonic()
        self._refresh_enabled()
        self.tick()

    def _stop_demo(self):
        self._demo.clear()
        self._demo_due = None
        self._demo_running = False

    def _timeout(self, result):
        if result.get('op') in IMAGE_OPS:
            self.image_workflow.fail('图片请求超时，板端状态未知；请核对状态或中止会话。','TIMEOUT')
            self.results.append(dict(result,accepted_pass=False,image=self.prepared_image.metadata() if self.prepared_image else None,raw_replies=list(self._image_raw)))
            self.result_log.appendPlainText('#%s %s · TIMEOUT（未计通过）'%(result['id'],result['op']));self._finish_image_state();return
        self.pending = False
        self._stop_demo()
        self.results.append(result.copy())
        self.status.setText("请求 #%d 超时；板端状态待确认，请重新连接后核对。" % result["id"])
        self.result_log.appendPlainText("#%d %s · TIMEOUT（未计为通过）" % (result["id"], result["op"]))
        self._refresh_enabled()
        self.state_changed.emit()

    def tick(self):
        result = self.tracker.expire()
        if result is not None:
            self._timeout(result)
        self._image_tick()
        if self._demo_running and not self.pending and self.available and self._demo_due is not None and time.monotonic() >= self._demo_due:
            if self._demo:
                op, args = self._demo.pop(0)
                self._demo_due = None
                if not self.request(op, *args, _demo=True):
                    self._stop_demo()
            else:
                self._stop_demo()
            self._refresh_enabled()

    def disconnected(self):
        if self.pending:
            result = dict(kind="LAB_DISCONNECTED", id=self.tracker.pending_id,
                          op=self.tracker.operation, status="DISCONNECTED")
            self.results.append(result)
            self.result_log.appendPlainText("#%s · 连接已断开，结果未确认。" % result["id"])
        self.tracker.cancel()
        self.image_workflow.disconnected();self.image_timer.stop();self.img_capable=False;self._image_abort_after_status=False
        if self.image_workflow.last_summary and self.image_workflow.last_summary is not self._image_recorded_summary:
            self._image_recorded_summary=self.image_workflow.last_summary;self.results.append(dict(kind='LOCAL_IMAGE_FLOW',**self.image_workflow.last_summary))
        self.image_validation.setText('连接已断开；电脑保留示意，板端图片状态未确认。')
        self._stop_demo()
        self.pending = False
        self.active = False
        self.available = False
        self.status.setText("连接已断开。板端状态待重连确认。")
        self._refresh_enabled()
        self.state_changed.emit()
