"""White, device-free LAB23 Basic 2/3 laboratory UI.

Signals are the only output channel. The parent owns the serial port and the
exclusive game/programming interlock. A computer drawing is never a capture.
"""
from __future__ import annotations

import json
import secrets
import time
from datetime import datetime, timezone
from PySide6.QtCore import Qt, Signal, QRectF
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
    QFormLayout, QComboBox, QSpinBox, QTabWidget, QTableWidget, QTableWidgetItem,
    QHeaderView, QPlainTextEdit, QFrame)
from labx_protocol import ExperimentRequest, labx_command, request_timeout

METHOD_NAMES = {"split":"分散小块", "merged":"合并区域", "blocks":"移动方块", "image":"大图切换"}
PHASE_NAMES = {0:"尚未开始", 1:"A 正在显示", 2:"B 已画一半 · A 保持不变", 3:"B 已完成 · 尚未请求换帧", 4:"已请求换帧 · 等待确认", 5:"换帧已确认 · 前后台交换"}


def text(value, muted=False):
    label = QLabel(value); label.setWordWrap(True)
    if muted: label.setStyleSheet("color:#80838b;font-size:12px;")
    return label


def combo(items):
    widget = QComboBox()
    for title, value in items: widget.addItem(title, value)
    return widget


class TimingBars(QWidget):
    """Only measured board render times; no inferred or fabricated datapoints."""
    def __init__(self):
        super().__init__(); self.rows=[]; self.setMinimumHeight(112)
    def set_rows(self, rows): self.rows=list(rows); self.update()
    def paintEvent(self, event):
        p=QPainter(self); p.fillRect(self.rect(), QColor("#fafafb"))
        if not self.rows:
            p.setPen(QColor("#858791")); p.drawText(self.rect(), Qt.AlignCenter, "等待真实板端绘制耗时"); return
        rows=self.rows[-6:]; peak=max(r["render_us"] for r in rows) or 1
        stride=max(24, self.height()/len(rows)); width=max(20,self.width()-195)
        for i,row in enumerate(rows):
            y=i*stride+8; title=row["backend"]+" · "+METHOD_NAMES.get(row["method"],row["method"])
            p.setPen(QColor("#60636b")); p.drawText(QRectF(10,y,117,20),Qt.AlignVCenter,title)
            p.fillRect(QRectF(132,y+3,width*row["render_us"]/peak,13),QColor("#4c8dff" if row["backend"]=="FPGA" else "#a2a5ae"))
            p.drawText(QRectF(140+width,y,60,20),Qt.AlignVCenter,"%.2f ms"%(row["render_us"]/1000))


class LabXPanel(QWidget):
    command_requested = Signal(int, str, list)
    state_changed = Signal()
    export_requested = Signal()
    legacy_detected = Signal()

    def __init__(self, parent=None, clock=time.monotonic):
        super().__init__(parent); self.clock=clock
        self.available=False; self.status_available=False; self.capable=False; self.active=False; self.pending=False; self.uncertain=False
        self._need_resync=False; self._next_id=secrets.randbelow(1000000000)+1000000; self._request=None
        self._cancel_id=None; self._cancel_deadline=None; self._exit_after=False
        self._loop=False; self._loop_goal_us=0; self._loop_measured_us=0; self._loop_start=None
        self._loop_args=None; self._loop_ids=[]; self._loop_uf=0; self._loop_due=False
        self.results=[]; self.continuous_results=[]; self.raw_lines=[]; self.identity={}
        self.section='basic2'; self._basic3_tab=1
        self.buffer_state=None; self._committed_front=None;self._demo_origin=None;self._state_before_request=None
        self._build(); self._enable(); self.set_section('basic2')

    @property
    def blocks_game(self): return self.active or self.pending or self.uncertain or self._loop or self._cancel_id is not None

    def _button(self, title, callback):
        b=QPushButton(title); b.clicked.connect(callback); return b

    def _build(self):
        layout=QVBoxLayout(self); layout.setContentsMargins(0,4,0,12); layout.setSpacing(14)
        self.title_label=text("基础二 · 数据搬运"); self.title_label.setStyleSheet("font-size:27px;font-weight:600;"); layout.addWidget(self.title_label)
        layout.addWidget(text("开发板内的 RISC-V 与 FPGA 执行实验；电脑只负责操作、显示回包和保存记录。",True))
        row=QHBoxLayout(); self.enter_button=self._button("进入实验",lambda:self.request("enter")); self.exit_button=self._button("返回游戏",self.stop_and_return)
        self.sync_button=self._button("核对板端状态",lambda:self.request("status")); self.stop_button=self._button("停止并返回",self.stop_and_return)
        self.export_button=self._button("导出实验记录",lambda:self.export_requested.emit())
        for b in (self.enter_button,self.exit_button,self.sync_button,self.stop_button): row.addWidget(b)
        row.addStretch(); row.addWidget(self.export_button); layout.addLayout(row)
        self.status=text("连接 LAB23 后启用；LAB1 仍可使用游戏和基础一。",True); layout.addWidget(self.status)
        self.tabs=QTabWidget(); layout.addWidget(self.tabs)
        mem=QWidget(); v=QVBoxLayout(mem); v.setSpacing(12)
        v.addWidget(text("基础二 · 数据搬运")); v.addWidget(text("同一张最终图，比较分散小块与合并区域。突发传输/FIFO采用现有硬件；这不是开关 Burst 的对照。",True))
        form=QFormLayout(); self.mem_kind=combo([("图片复制 · Copy","copy"),("纯色填充 · Fill","fill")]); self.mem_size=combo([("小规模","small"),("中规模","medium"),("大规模","large")]); self.mem_size.setCurrentIndex(1)
        self.mem_layout=combo([("连续对齐","aligned"),("合法字对齐偏移","offset"),("跨 4 KiB 边界","boundary")]); self.mem_repeats=QSpinBox();self.mem_repeats.setRange(1,3);self.mem_repeats.setValue(3)
        for name,w in (("操作",self.mem_kind),("规模",self.mem_size),("布局",self.mem_layout),("重复组数",self.mem_repeats)):form.addRow(name,w)
        v.addLayout(form); self.mem_button=self._button("比较两种任务组织",self.start_mem);v.addWidget(self.mem_button)
        row=QHBoxLayout();self.duration=combo([("连续验证 30 秒",30),("连续验证 10 分钟",600)]);self.continuous_button=self._button("一键连续验证",self.start_continuous)
        row.addWidget(self.duration);row.addWidget(self.continuous_button);row.addStretch();v.addLayout(row)
        self.continuous_status=text("连续验证累计每个实际完成请求的板端 elapsed_us；所有成功、失败和取消均保留。",True);v.addWidget(self.continuous_status)
        v.addWidget(text("结构说明：RISC-V → 寄存器 / BitBlt → AXI → DDR；写 FIFO 协调速率。此说明来自源码，未测 FIFO 水位或整块 DDR 利用率。",True));self.tabs.addTab(mem,"基础二 · 数据搬运")
        compare=QWidget();v=QVBoxLayout(compare);v.setSpacing(12);v.addWidget(text("基础三 · 同画面 CPU / FPGA 对照"));v.addWidget(text("先完成 CPU，再从相同初始状态执行 FPGA。显示持续开启；绘制计时不含像素检查与串口输出。",True))
        form=QFormLayout();self.compare_kind=combo([("移动方块","blocks"),("大图切换","image")]);self.compare_size=combo([("小规模","small"),("中规模","medium"),("大规模","large")]);self.compare_frames=QSpinBox();self.compare_frames.setRange(1,120);self.compare_frames.setValue(30)
        self.compare_warmup=QSpinBox();self.compare_warmup.setRange(0,8);self.compare_warmup.setValue(2);self.compare_repeats=QSpinBox();self.compare_repeats.setRange(1,3);self.compare_repeats.setValue(3)
        for name,w in (("样例",self.compare_kind),("规模",self.compare_size),("测量帧数 / 每方",self.compare_frames),("预热帧数 / 每方",self.compare_warmup),("重复组数",self.compare_repeats)):form.addRow(name,w)
        v.addLayout(form);self.compare_button=self._button("一键公平比较",self.start_compare);v.addWidget(self.compare_button)
        v.addWidget(text("CPU 指板内 RISC-V。实际 FPS 按真实换帧 / 测量阶段经过时间计算，不含重放校验；绘制加速比另按相同任务绘制耗时计算。",True));self.tabs.addTab(compare,"基础三 · 同画面对照")
        double=QWidget();v=QVBoxLayout(double);v.setSpacing(12);v.addWidget(text("双缓冲 · 一张显示，另一张绘制"));v.addWidget(text("示意卡只跟随板端真实地址和阶段回包，不是显存截图。完成换帧确认后才交换角色。",True))
        row=QHBoxLayout();self.reset_button=self._button("从第一步开始",lambda:self.request("double","reset"));self.next_button=self._button("下一步",lambda:self.request("double","next"));self.auto_button=self._button("自动演示五步",lambda:self.request("double","auto"))
        for b in (self.reset_button,self.next_button,self.auto_button):row.addWidget(b)
        row.addStretch();v.addLayout(row);cards=QHBoxLayout();self.buffer_cards=[];self.buffer_titles=[]
        for name,address in (("A",0x01000000),("B",0x01400000)):
            card=QFrame();card.setStyleSheet("QFrame{background:#f7f8fa;border:1px solid #e7e8ec;border-radius:10px;} QLabel{border:0;}");c=QVBoxLayout(card);title=text("显存地址 "+name);self.buffer_titles.append(title);c.addWidget(title);c.addWidget(text("0x%08X"%address,True));role=text("状态待板端核对");c.addWidget(role);self.buffer_cards.append(role);cards.addWidget(card)
        v.addLayout(cards);self.buffer_phase=text("尚未开始");v.addWidget(self.buffer_phase);self.buffer_metrics=text("front — · back — · swaps — · pending —",True);v.addWidget(self.buffer_metrics);self.tabs.addTab(double,"双缓冲 · 分步演示")
        self.plan_label=text("任务预登记：—",True);layout.addWidget(self.plan_label);self.current_label=text("当前方：— · 最近完成的一组：—");layout.addWidget(self.current_label)
        self.bars=TimingBars();layout.addWidget(self.bars)
        self.summary=text("绘制加速比 — · 像素检查 — · HDMI 扫描规格 60 Hz",True);layout.addWidget(self.summary)
        self.table=QTableWidget(0,12);self.table.setHorizontalHeaderLabels(["组","执行方 / 方法","帧","总绘制 ms","每帧绘制 ms","实际 FPS","引擎周期","读字节","有效写字节","有效 MB/s","像素检查","欠流事件"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents);self.table.horizontalHeader().setStretchLastSection(True);self.table.setEditTriggers(QTableWidget.NoEditTriggers);self.table.setMaximumHeight(225);layout.addWidget(self.table)
        layout.addWidget(text("有效 MB/s = 有效像素 × 4 / 绘制微秒（十进制）。引擎读/写计数不是 DDR 总物理流量；CPU 对应引擎计数显示 —。",True))
        self.log=QPlainTextEdit();self.log.setReadOnly(True);self.log.setMaximumHeight(120);self.log.setMaximumBlockCount(400);layout.addWidget(self.log)
        self._inputs=[self.mem_kind,self.mem_size,self.mem_layout,self.mem_repeats,self.mem_button,self.duration,self.continuous_button,self.compare_kind,self.compare_size,self.compare_frames,self.compare_warmup,self.compare_repeats,self.compare_button,self.reset_button,self.next_button,self.auto_button]

    def _belongs_to_section(self, operation):
        return operation=='mem' if self.section=='basic2' else operation in ('compare','double')

    def _show_plan(self, request_id, plan, scope=None):
        if not plan:
            self.plan_label.setText('任务预登记待板端完整回包');return
        self.plan_label.setText("任务 #%d · 摘要 %u · %s / %s · %s×%s · 每方 %s 帧 · 预热 %s · %s 组"%(request_id,plan['task'],plan['kind'],plan['layout'],plan['w'],plan['h'],plan['frames'],plan['warmup'],plan['repeats']))
        if scope:self.plan_label.setText(self.plan_label.text()+" · 末帧实测画面 + 首/中帧确定性重放 [%d, %d, %d]"%(scope['first'],scope['middle'],scope['last']))

    def set_section(self, section):
        if section not in ('basic2','basic3'):raise ValueError('Unknown laboratory section')
        if self.section=='basic3' and self.tabs.currentIndex() in (1,2):self._basic3_tab=self.tabs.currentIndex()
        self.section=section
        self.title_label.setText('基础二 · 数据搬运' if section=='basic2' else '基础三 · 绘制与双缓冲')
        for index in range(3):self.tabs.setTabVisible(index,(index==0) if section=='basic2' else (index in (1,2)))
        self.tabs.setCurrentIndex(0 if section=='basic2' else self._basic3_tab)
        self.tabs.tabBar().setVisible(section=='basic3')
        self.plan_label.setText('任务预登记：—');self.current_label.setText('本页尚未完成实验')
        self.bars.set_rows([]);self.table.setRowCount(0)
        self.summary.setText(('任务合并收益' if section=='basic2' else '绘制加速比')+' — · 像素检查 — · HDMI 扫描规格 60 Hz')
        result=next((r for r in reversed(self.results) if r.get('rows') and self._belongs_to_section(r['op'])),None)
        if result:
            if result.get('plan'):self._show_plan(result['id'],result['plan'],result.get('scope'))
            self._show_results(result)
        if self._request and self._belongs_to_section(self._request.operation):
            if self._request.plan:self._show_plan(self._request.request_id,self._request.plan,self._request.scope)
            self.current_label.setText('本页实验正在进行 · 请求 #%d'%self._request.request_id)

    def set_capabilities(self, capabilities):
        capable=bool(capabilities and capabilities.get("fw")=="LAB23" and capabilities.get("labx")==1)
        self.capable=capable
        if capable:
            self.identity.update(firmware="LAB23",capabilities=dict(capabilities));self.uncertain=True;self._need_resync=True
        else:
            self._need_resync=False;self.uncertain=False
            self.status.setText("当前固件不支持基础二/三；LAB1 可继续使用游戏与基础一。")
        self._enable();self.state_changed.emit()

    def set_available(self, available, status_available=None):
        status_available=available if status_available is None else status_available
        changed=self.available!=bool(available) or self.status_available!=bool(status_available);self.available=bool(available);self.status_available=bool(status_available)
        if changed:self._enable()
        if self.status_available and self.capable and self._need_resync and not self.pending:
            self._need_resync=False;self.request("status")

    def _enable(self):
        ready=self.available and self.capable and not self.pending and self._cancel_id is None and not self._loop
        self.enter_button.setEnabled(ready and not self.active and not self.uncertain)
        self.exit_button.setEnabled(ready and self.active)
        self.sync_button.setEnabled(self.status_available and self.capable and not self.pending and self._cancel_id is None)
        self.stop_button.setEnabled(self.available and self.capable and (self.pending or self.active or self._loop) and self._cancel_id is None)
        for widget in self._inputs:widget.setEnabled(ready and self.active and not self.uncertain)
        self.export_button.setEnabled(bool(self.results or self.raw_lines))

    def _id(self):
        if self._next_id>2147483647:raise RuntimeError("实验编号已耗尽，请重新启动工作台")
        value=self._next_id;self._next_id+=1;return value

    def request(self, operation, *args, _loop=False):
        if not (self.status_available if operation=='status' else self.available) or not self.capable or self.pending or self._cancel_id is not None or (self._loop and not _loop):return False
        if operation not in {"enter","status"} and not self.active:return False
        if self.uncertain and operation not in {"status","exit"}:return False
        if operation=="enter" and self.active:return False
        request_id=self._id();labx_command(request_id,operation,*args);now=self.clock()
        self._state_before_request=dict(self.buffer_state) if self.buffer_state else None
        self._request=ExperimentRequest(request_id,operation,tuple(args),now,now+request_timeout(operation));self.pending=True
        self.status.setText("请求 #%d · %s · 等待板端"%(request_id,operation));self.log.appendPlainText("#%d %s %s · 已发送，未完成"%(request_id,operation," ".join(map(str,args))))
        self._enable();self.state_changed.emit();self.command_requested.emit(request_id,operation,list(args));return True

    def mem_args(self):return (self.mem_kind.currentData(),self.mem_size.currentData(),self.mem_layout.currentData(),self.mem_repeats.value())
    def start_mem(self):return self.request("mem",*self.mem_args())
    def start_compare(self):return self.request("compare",self.compare_kind.currentData(),self.compare_size.currentData(),self.compare_frames.value(),self.compare_warmup.value(),self.compare_repeats.value())

    def ingest(self, reply):
        if not isinstance(reply,dict):return
        if ((self._request is not None and self.clock()>=self._request.deadline)
                or (self._cancel_id is not None and self.clock()>=self._cancel_deadline)):
            self.tick()
        self.raw_lines.append(dict(reply))
        if reply.get("id")==self._cancel_id:
            if reply["kind_line"]=="LABX_DONE" and reply.get("op")=="cancel":
                self.log.appendPlainText("取消请求 #%d · %s；仍等待原任务安全结束"%(self._cancel_id,reply["status"]));self._cancel_id=None;self._cancel_deadline=None
                if reply["status"]!="PASS":self.uncertain=True
                self._maybe_exit();self._enable();self.state_changed.emit()
            return
        request=self._request
        if request is None or not request.feed(reply):return
        kind=reply["kind_line"]
        if kind=="LABX_ACK":self.status.setText("请求 #%d 已排队 · 等待测量与校验"%request.request_id)
        elif kind=="LABX_PLAN" and self._belongs_to_section(request.operation):self._show_plan(request.request_id,reply)
        elif kind=="LABX_SCOPE" and self._belongs_to_section(request.operation):self._show_plan(request.request_id,request.plan,reply)
        elif kind=="LABX_RESULT" and self._belongs_to_section(request.operation):self.current_label.setText("正在收集：%s · %s · 组 %s · 请求 #%s"%(reply["backend"],METHOD_NAMES[reply["method"]],reply["group"],request.request_id))
        elif kind=="LABX_STATE":self._show_state(reply)
        elif kind=="LABX_DONE":
            result=request.finish(reply);self.results.append(result);self.pending=False;self._request=None
            if request.operation=="double" and request.args==("next",) and result["accepted_pass"]:
                before=self._state_before_request
                expected=1 if before is None or before["phase"] in (0,5) else before["phase"]+1
                if len(request.states)!=1 or request.states[0]["phase"]!=expected:
                    result["accepted_pass"]=False;result["reasons"].append("分步阶段未按顺序确认")
                elif expected in (2,3) and (request.states[0]["front"]!=before["front"] or request.states[0]["swaps"]!=before["swaps"]):
                    result["accepted_pass"]=False;result["reasons"].append("后台绘制时前台已变化")
                elif expected==5:
                    end=request.states[0];origin=self._demo_origin
                    if origin is None or end["front"]!=origin["back"] or end["back"]!=origin["front"] or end["pending"] or ((end["swaps"]-origin["swaps"])&0xffffffff)!=1:
                        result["accepted_pass"]=False;result["reasons"].append("缺少本轮实际换帧起止证据，请重置演示")
            self.active=bool(reply["active"])
            self.uncertain=request.operation=="status" and not result["accepted_pass"]
            if reply.get("code")=="LEGACY_ACTIVE":
                self.active=False;self.uncertain=False;self._need_resync=False;self.legacy_detected.emit()
            if result["accepted_pass"]:
                self.status.setText("请求 #%d · %s · 已核对通过"%(request.request_id,request.operation))
            else:self.status.setText("请求 #%d · 未通过 / 未完成：%s"%(request.request_id,"；".join(result["reasons"])))
            self.log.appendPlainText(self.status.text())
            if result["rows"]:self._show_results(result)
            if self._loop and request.operation=="mem":self._advance_continuous(result)
            self._maybe_exit();self._enable();self.state_changed.emit()

    def _show_state(self, state):
        self.buffer_state=dict(state);phase=state["phase"]
        if phase==1:self._demo_origin=dict(state)
        elif phase==0:self._demo_origin=None
        if phase in (1,5) or self._committed_front is None:self._committed_front=state["front"]
        self.buffer_phase.setText("第 %s / 5 步 · %s"%(phase,PHASE_NAMES[phase]))
        for title,role,address in zip(self.buffer_titles,self.buffer_cards,(0x01000000,0x01400000)):
            foreground=address==self._committed_front
            if self._demo_origin:title.setText("演示 A · 原前台" if address==self._demo_origin["front"] else "演示 B · 准备画面")
            role.setText("显示前台 · 保持画面" if foreground else "绘制后台 · "+("已准备" if state["ready"] else "准备中"))
        self.buffer_metrics.setText("真实读回 front 0x%08X · back 0x%08X · swaps %s · pending %s · 错误 %s"%(state["front"],state["back"],state["swaps"],state["pending"],state["errors"]))

    def _show_results(self, result):
        if not self._belongs_to_section(result['op']):return
        rows=result["rows"];self.table.setRowCount(0);self.bars.set_rows(rows)
        for row in rows:
            check="通过" if not any(row[k] for k in ("errors","guards","source")) else "失败"
            values=[row["group"],row["backend"]+" / "+METHOD_NAMES[row["method"]],row["frames"],"%.3f"%(row["render_us"]/1000),"%.3f"%(row["render_us"]/row["frames"]/1000) if row["frames"] else "—","%.2f"%row["actual_fps"] if row["actual_fps"] is not None else "—",*(row[k] if row["backend"]=="FPGA" else "—" for k in ("cycles","read","write")),"%.2f"%row["effective_MBps"] if row["effective_MBps"] is not None else "—",check,row["uf"]]
            index=self.table.rowCount();self.table.insertRow(index)
            for col,value in enumerate(values):self.table.setItem(index,col,QTableWidgetItem(str(value)))
        ratios=[]
        for group in sorted({r["group"] for r in rows}):
            group_rows=[r for r in rows if r["group"]==group]
            if len(group_rows)!=2:continue
            a=next((r for r in group_rows if r["backend"]=="CPU" or r["method"]=="split"),None)
            b=next((r for r in group_rows if r["backend"]=="FPGA" and r["method"]!="split"),None)
            if a and b and b["render_us"]:ratios.append(a["render_us"]/b["render_us"])
        ratio=" / ".join("%.2f×"%n for n in ratios) if result["accepted_pass"] and ratios else "—（结果尚未全部核对）"
        self.summary.setText(("绘制加速比 " if result["op"]=="compare" else "任务合并收益 ")+ratio+" · 像素检查 "+("通过" if result["accepted_pass"] else "未通过 / 未完成")+" · HDMI 扫描规格 60 Hz")
        self.current_label.setText("当前方：已结束 · 最近完成的一组：#%d · %s"%(result["id"],"完整通过" if result["accepted_pass"] else "不完整，保留原始数据"))

    def start_continuous(self):
        if not self.available or not self.capable or not self.active or self.uncertain or self.pending or self._loop:return False
        self._loop=True;self._loop_goal_us=self.duration.currentData()*1000000;self._loop_measured_us=0;self._loop_start=self.clock();self._loop_args=self.mem_args();self._loop_ids=[];self._loop_uf=0;self._loop_due=False
        self.continuous_status.setText("连续验证进行中 · 实测 0 / %s 秒"%self.duration.currentData());self._enable();self.state_changed.emit()
        return self.request("mem",*self._loop_args,_loop=True)

    def _advance_continuous(self,result):
        self._loop_ids.append(result["id"]);self._loop_measured_us+=result["done"].get("elapsed_us",0);self._loop_uf+=result["done"].get("uf",0)
        if not result["accepted_pass"] or result["done"].get("elapsed_us",0)<=0:self._finish_continuous(False,"有请求失败、未完成或缺少有效板端时长")
        elif self._loop_measured_us>=self._loop_goal_us:self._finish_continuous(True,"达到预登记板端执行时长")
        else:
            self.continuous_status.setText("连续验证进行中 · 板端实测 %.3f / %.0f 秒 · %s 个请求 · 欠流 %s"%(self._loop_measured_us/1e6,self._loop_goal_us/1e6,len(self._loop_ids),self._loop_uf));self._loop_due=True

    def _finish_continuous(self,passed,reason):
        if not self._loop:return
        report=dict(utc=datetime.now(timezone.utc).isoformat(),requested_us=self._loop_goal_us,measured_board_us=self._loop_measured_us,host_elapsed_s=self.clock()-self._loop_start,request_ids=list(self._loop_ids),uf_sum=self._loop_uf,accepted_pass=bool(passed and not self._loop_uf),reason=reason,scope="累计实际完成LABX请求的板端时间；不含请求之间主机派发间隙")
        self.continuous_results.append(report);self._loop=False;self._loop_due=False
        self.continuous_status.setText("连续验证%s · 板端 %.3f 秒 · %s 个请求 · 欠流 %s · %s"%("通过" if report["accepted_pass"] else "未通过 / 未完成",self._loop_measured_us/1e6,len(self._loop_ids),self._loop_uf,reason));self._enable();self.state_changed.emit()

    def stop_and_return(self):
        if not self.available or not self.capable:return False
        self._exit_after=True
        if self._loop:self._finish_continuous(False,"用户停止")
        if self.pending:
            if self._cancel_id is not None:return False
            self._cancel_id=self._id();self._cancel_deadline=self.clock()+5
            self.command_requested.emit(self._cancel_id,"cancel",[]);self.status.setText("已请求取消 · 等待当前硬件任务安全结束");self._enable();self.state_changed.emit();return True
        self._maybe_exit();return True

    def _maybe_exit(self):
        if self._exit_after and not self.pending and self._cancel_id is None:
            self._exit_after=False
            if self.active:self.request("exit")

    def tick(self):
        if self._cancel_id is not None and self.clock()>=self._cancel_deadline:
            self.results.append(dict(id=self._cancel_id,op="cancel",accepted_pass=False,reasons=["取消送达超时"],raw=[]));self._cancel_id=None;self._cancel_deadline=None;self._exit_after=False;self.uncertain=True
            self.status.setText("取消确认超时 · 板端状态未知，请核对状态或重新连接");self._enable();self.state_changed.emit()
        if self._request is not None and self.clock()>=self._request.deadline:
            request=self._request;self.results.append(dict(id=request.request_id,op=request.operation,args=list(request.args),accepted_pass=False,reasons=["TIMEOUT"],raw=list(request.raw)))
            self._request=None;self.pending=False;self.uncertain=True;self._exit_after=False
            if self._loop:self._finish_continuous(False,"请求超时")
            self.status.setText("请求 #%d 超时 · 未计通过；请核对板端状态"%request.request_id);self._enable();self.state_changed.emit()
        if self._loop and self._loop_due and not self.pending and self.available:
            self._loop_due=False;self.request("mem",*self._loop_args,_loop=True)

    def disconnected(self):
        if self._request is not None:
            r=self._request;self.results.append(dict(id=r.request_id,op=r.operation,accepted_pass=False,reasons=["DISCONNECTED"],raw=list(r.raw)))
        if self._loop:self._finish_continuous(False,"连接断开")
        self._request=None;self._cancel_id=None;self._cancel_deadline=None;self._exit_after=False;self.pending=False;self.active=False;self.uncertain=False;self.capable=False;self.available=False;self.status_available=False;self._need_resync=False
        self.buffer_state=None;self._committed_front=None;self._demo_origin=None;self.status.setText("连接已断开 · 未完成结果已保留，重连后须核对状态");self._enable();self.state_changed.emit()

    def export_document(self):
        return dict(schema="ti60_lab23_gui_evidence_v1",utc=datetime.now(timezone.utc).isoformat(),identity=dict(self.identity),results=list(self.results),continuous=list(self.continuous_results),raw=list(self.raw_lines),hardware_accessed_by_panel=False,cold_boot_scope="本页不自动认证冷启动",notes=["电脑卡片是状态示意，并非显存截图", "ACK只表示接收，accepted_pass由完整匹配结果计算", "连续验证不覆盖请求间的主机派发间隙", "显示欠流为事件计数，不是丢帧数", "像素核对含真实计时末帧及首/中序号确定性重放；未捕获仅在早期计时帧出现后消失的瞬时错误"])
