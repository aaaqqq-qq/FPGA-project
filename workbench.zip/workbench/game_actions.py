"""UI-independent acknowledged game transactions and LAB1 configuration registry.

The caller owns one exclusive serial link. No function opens a port, sleeps,
changes a clock or resets unrelated game configuration.
"""
from __future__ import annotations
from dataclasses import dataclass
import re
import time
from typing import Callable, Any

from control_core import mode_command, parse_telemetry, limit_command


@dataclass(frozen=True)
class ConfigSpec:
    name: str
    label: str
    minimum: int
    maximum: int
    unit: str = ""
    group: str = "参数"
    menu_only: bool = False
    writable: bool = True
    note: str = ""

    @property
    def field(self):
        return self.name

    @property
    def min_value(self):
        return self.minimum

    @property
    def max_value(self):
        return self.maximum


# Bounds mirror game_config.c hot_fields, plus the explicit virtual controls.
# tick_profile is diagnostic; hud_dma_tail_enabled is a separate presentation
# policy whose enabled state is bound to the firmware replay/config hash.
# Cross-field relations (e.g. low < high) remain firmware-authoritative.
_SCALAR_DATA = """
boss_count|Boss数量|1|6|个|角色
enemy_count|普通敌人数量|0|12|个|角色
enemy_bullet_size|游戏敌弹尺寸|8|56|像素|弹幕
background_depth_enabled|背景纵深|0|1|开关|图层
layer_pipeline_enabled|图层管道|0|1|开关|图层
layer_y_sort|按纵坐标排序|0|1|开关|图层
layer_visuals_enabled|图层装饰|0|1|开关|图层
layer_visuals_strength|装饰强度|1|2|档|图层
battle_gather_enabled|战斗批量收集|0|1|开关|性能
opaque_sprites|不透明精灵优化|0|1|开关|性能
render_budget_enabled|自适应绘制预算|0|1|开关|性能
tick_profile|逻辑分段计时（诊断）|0|1|开关|性能诊断
adaptive_density|弹幕密度自适应|0|1|开关|弹幕
density_high_pct|密度高阈值|1|99|%|弹幕
density_low_pct|密度低阈值|0|98|%|弹幕
density_slow_num|降频倍率分子|1|16|比例|弹幕
density_slow_den|降频倍率分母|1|16|比例|弹幕
boss_profiles_enabled|Boss差异化攻击|0|1|开关|Boss
homing_retarget_ticks|追踪弹重选间隔|1|16|逻辑帧|玩家
near_enabled|近邻碰撞加速|0|1|开关|性能
graze_feedback_enabled|擦弹星点反馈|0|1|开关|效果
graze_feedback_cooldown|擦弹反馈间隔|1|600|逻辑帧|效果
low_hp_threshold|低血量阈值|1|100|HP|玩家
low_hp_pulse_ticks|低血量脉冲周期|8|600|逻辑帧|效果
death_slowmo_enabled|击破慢动作|0|1|开关|效果
death_slowmo_ticks|击破慢动作时长|1|180|逻辑帧|效果
death_slowmo_divisor|击破慢动作除数|1|8|倍|效果
death_star_budget|击破星点预算|0|8|个|效果
vignette_enabled|场地暗角|0|1|开关|效果
hud_dirty_enabled|HUD脏区优化|0|1|开关|性能
hud_dma_tail_enabled|HUD尾部DMA（对照）|0|1|开关|性能对照
stress_gather_enabled|压力批量收集|0|1|开关|性能
stress_overlap_enabled|压力计算绘制重叠|0|1|开关|性能
main_fire_period|主武器发射间隔|1|120|逻辑帧|玩家
homing_fire_period|追踪武器发射间隔|1|240|逻辑帧|玩家
player_shot_damage|玩家弹伤害|1|100|HP|玩家
player_shot_life|玩家弹存续时间|1|600|逻辑帧|玩家
player_shot_speed|玩家弹速度|1|24|像素/逻辑帧|玩家
homing_shot_speed|追踪弹速度|1|24|像素/逻辑帧|玩家
player_hit_damage|玩家受击扣血|1|100|HP|玩家
hit_invuln_ticks|受击无敌时长|0|600|逻辑帧|玩家
regen_wait_ticks|无伤回血等待|0|3600|逻辑帧|玩家
regen_period_ticks|回血间隔|1|600|逻辑帧|玩家
regen_amount|每次回血量|1|100|HP|玩家
effect_job_budget|效果绘制任务预算|0|12|任务/帧|性能
effect_area_budget|效果绘制面积预算|0|16384|像素/帧|性能
first_burst|首Boss狂暴弹数|0|4096|发|Boss
other_burst|其他Boss狂暴弹数|0|4096|发|Boss
burst_rings|基础爆发环数|1|8|环|Boss
"""
MENU_ONLY_FIELDS = frozenset(("boss_count", "enemy_count", "background_depth_enabled", "enemy_bullet_size", "tick_profile", "hud_dma_tail_enabled"))


def _make_registry() -> tuple[ConfigSpec, ...]:
    result = []
    for row in _SCALAR_DATA.strip().splitlines():
        name, label, low, high, unit, group = row.split("|")
        result.append(ConfigSpec(name, label, int(low), int(high), unit, group,
                                 name in MENU_ONLY_FIELDS,
                                 note=("默认关闭；仅菜单可改；诊断会增加耗时，结果不作普通帧率证明。"
                                       if name == "tick_profile" else
                                       "默认0；0=原CPU尾部绘制，1=DMA尾部绘制；仅菜单可改，画面与验收标准相同。"
                                       if name == "hud_dma_tail_enabled" else
                                       "最终仍由固件检查范围及关联约束。")))
    boss_arrays = (("boss_fire_num", "狂暴射频分子", 16), ("boss_fire_den", "狂暴射频分母", 16),
                   ("boss_move_num", "狂暴移速分子", 16), ("boss_move_den", "狂暴移速分母", 16),
                   ("boss_bullets_num", "狂暴弹数分子", 16), ("boss_bullets_den", "狂暴弹数分母", 16),
                   ("boss_burst_rings", "狂暴爆发环数", 8),
                   ("boss_burst_scale_num", "爆发弹数分子", 16),
                   ("boss_burst_scale_den", "爆发弹数分母", 16))
    for name, label, high in boss_arrays:
        for index in range(6):
            result.append(ConfigSpec(f"{name}[{index}]", f"Boss {index + 1} · {label}", 1, high,
                                     "环" if high == 8 else "比例", "Boss独立配置",
                                     note="分母非零，倍率须在1至4倍范围；由固件整体校验。"))
    for index in range(6):
        result.append(ConfigSpec(f"level_threshold[{index}]", f"等级{index}分数门槛", 1, 1000000,
                                 "分", "成长", writable=index >= 2,
                                 note="等级2至5须严格递增；0/1项固定不可写。"))
    for index in range(8):
        result.append(ConfigSpec(f"layer_order[{index}]", f"图层{index}绘制顺序", 0, 255,
                                 "顺序", "图层", note="只改变该图层顺序，不重置其他配置。"))
    # Declared GameConfig members without a game_config_set whitelist entry.
    # Show them as read-only; exposing a text box cannot make firmware support them.
    fixed = {
        "boss_max_hp": "Boss最大血量", "boss_half_hp": "Boss狂暴血量阈值",
        "enrage_intro_ticks": "狂暴预警时长", "enter_ticks": "增援入场时长",
        "refill_first": "首Boss狂暴回血", "refill_others": "其他Boss狂暴回血",
        "enrage_fire_num": "基础狂暴射频分子", "enrage_fire_den": "基础狂暴射频分母",
        "enrage_move_num": "基础狂暴移速分子", "enrage_move_den": "基础狂暴移速分母",
        "enrage_bullets_num": "基础狂暴弹数分子", "enrage_bullets_den": "基础狂暴弹数分母",
        "burst_speed_first": "首环弹速", "burst_speed_step": "每环弹速增量",
        "player_max_hp": "玩家最大血量", "spawn_invuln_ticks": "开场无敌时长",
        "bomb_invuln_ticks": "炸弹无敌时长", "bomb_damage": "炸弹伤害",
        "upgrade_ticks": "升级动画时长", "upgrade_invuln_ticks": "升级无敌时长",
        "hp_delay_ticks": "血条延迟时长", "hp_drop_rate": "血条回落速度",
        "player_shot_cap": "玩家弹上限", "max_level": "最高等级",
        "damage_score": "伤害得分倍率", "boss_kill_score": "Boss击破得分",
        "graze_score": "擦弹得分", "bullet_age_max": "敌弹最大存续时间",
        "logic_hz": "游戏逻辑频率", "logic_max_catchup": "逻辑补帧上限",
    }
    for name, label in fixed.items():
        unit = "逻辑帧" if name.endswith("ticks") or name == "bullet_age_max" else ""
        if name in {"burst_speed_first", "burst_speed_step"}:
            unit = "Q12像素/逻辑帧"
        if name == "logic_hz":
            unit = "Hz"
        result.append(ConfigSpec(name, label, 0, 0xFFFFFFFF, unit, "固件固定配置",
                                 writable=False, note="本固件未开放串口修改，修改须重新编译。"))
    for base, label in (("level_main", "主武器路数"), ("level_homing", "追踪武器路数")):
        for index in range(6):
            result.append(ConfigSpec(f"{base}[{index}]", f"等级{index} · {label}", 0, 0xFFFFFFFF,
                                     "路", "固件固定配置", writable=False,
                                     note="本固件未开放串口修改，修改须重新编译。"))
    return tuple(result)


CONFIG_FIELDS = _make_registry()
CONFIG_BY_NAME = {spec.name: spec for spec in CONFIG_FIELDS}
CONFIG_OPTIONS = (
    {"label": "4 Boss + 6普通敌人", "bosses": 4, "enemies": 6},
    {"label": "6 Boss + 12普通敌人", "bosses": 6, "enemies": 12},
    {"label": "3 Boss基线 · 无普通敌人", "bosses": 3, "enemies": 0},
)
PRESETS = CONFIG_OPTIONS


def config_value_command(field: str, value: int) -> bytes:
    spec = CONFIG_BY_NAME.get(field)
    if spec is None or not spec.writable:
        raise ValueError("该字段未开放串口修改")
    if isinstance(value, bool) or not isinstance(value, int) or not spec.minimum <= value <= spec.maximum:
        raise ValueError(f"{spec.label}范围应为{spec.minimum}至{spec.maximum}")
    if field == "enemy_bullet_size" and value not in (8,16,24,32,40,48,56):
        raise ValueError("游戏敌弹尺寸支持8、16、24、32、40、48、56像素")
    return f":set {field} {value}\n".encode("ascii")


class ActionSequence:
    """Exactly one acknowledged command at a time, with a deadline per step.

    LAB1's legacy OK set contains no field/request ID. The owner must therefore
    isolate manual sends for the whole sequence. There are no automatic retries
    or rollback claims: 'applied' lists only setters already acknowledged.
    """
    def __init__(self, send_callback: Callable[[bytes], Any], menu_callback: Callable[[], Any],
                 done_callback: Callable[[dict], Any], *, clock: Callable[[], float] = time.monotonic,
                 timeout: float = 5.0):
        if timeout <= 0:
            raise ValueError("超时必须大于0")
        self.send = send_callback
        self.menu = menu_callback
        self.done = done_callback
        self.clock = clock
        self.timeout = float(timeout)
        self.busy = False
        self.phase = "idle"
        self.requested: dict = {}
        self.applied: dict = {}
        self._steps: list[tuple[str, bytes | None, str]] = []
        self._deadline: float | None = None
        self._step: tuple[str, bytes | None, str] | None = None
        self._set_values: dict[str, int] = {}

    def start_preset(self, bosses: int, enemies: int, mode: int = 0) -> bool:
        if self.busy:
            return False
        boss_cmd = config_value_command("boss_count", bosses)
        enemy_cmd = config_value_command("enemy_count", enemies)
        if isinstance(mode, bool) or not isinstance(mode, int) or mode not in (0, 1, 2):
            raise ValueError("预设只支持普通、困难或极难阶段战")
        steps = [("menu", None, "menu"), ("boss_count", boss_cmd, "OK set"),
                 ("enemy_count", enemy_cmd, "OK set"), ("mode", mode_command(mode), f"OK mode {mode}")]
        return self._begin(dict(kind="preset", boss_count=bosses, enemy_count=enemies, mode=mode),
                           {"boss_count": bosses, "enemy_count": enemies}, steps)

    def start_config(self, field: str, value: int, requires_menu: bool = False) -> bool:
        if self.busy:
            return False
        command = config_value_command(field, value)
        menu_required = CONFIG_BY_NAME[field].menu_only or bool(requires_menu)
        steps = ([("menu", None, "menu")] if menu_required else [])
        steps.append((field, command, "OK set"))
        return self._begin(dict(kind="config", field=field, value=value, menu_required=menu_required),
                           {field: value}, steps)

    def start_menu(self) -> bool:
        if self.busy:return False
        return self._begin({"kind":"gload_menu"}, {}, [("menu",None,"menu")])

    def start_pressure(self, count: int, hardware: bool) -> bool:
        if self.busy:return False
        if not isinstance(hardware,bool):raise ValueError('请选择CPU或FPGA绘制')
        command=limit_command(count);mode=3 if hardware else 4
        return self._begin({'kind':'pressure','count':count,'hardware':hardware},{'bullet_limit':count},
            [('menu',None,'menu'),('bullet_limit',command,f'OK limit {count}'),('mode',mode_command(mode),f'OK mode {mode}')])

    def start_battle(self, size: int, count: int, bosses: int, enemies: int, mode: int = 0) -> bool:
        if self.busy:return False
        if isinstance(mode,bool) or mode not in (0,1,2):raise ValueError("请选择阶段战难度")
        values={"enemy_bullet_size":size,"boss_count":bosses,"enemy_count":enemies}
        commands=[(key,config_value_command(key,value),"OK set") for key,value in values.items()]
        commands.append(("bullet_limit",limit_command(count),f"OK limit {count}"))
        values["bullet_limit"]=count
        return self._begin(dict(kind="battle",mode=mode,**values),values,
            [("menu",None,"menu"),*commands,("mode",mode_command(mode),f"OK mode {mode}")])

    def _begin(self, requested, values, steps):
        self.busy = True
        self.phase = "starting"
        self.requested = requested
        self.applied = {}
        self._set_values = values
        self._steps = steps
        self._advance()
        return True

    def _advance(self):
        if not self._steps:
            self._finish(True, "COMPLETE", "已收到全部步骤确认")
            return
        self._step = self._steps.pop(0)
        self.phase = self._step[0]
        self._deadline = self.clock() + self.timeout
        try:
            result = self.menu() if self._step[1] is None else self.send(self._step[1])
            if result is False:
                self._finish(False, "SEND_ERROR", "发送方拒绝了本步骤")
        except Exception as exc:
            self._finish(False, "SEND_ERROR", str(exc))

    def feed(self, line: str) -> bool:
        if not self.busy or not isinstance(line, str):
            return False
        if self.tick():
            return False
        raw = line.strip()
        if raw.startswith("ERR ") or raw == "ERR":
            self._finish(False, "ERROR", raw)
            return True
        expected = self._step[2]
        matched = raw == expected
        if expected == "menu":
            matched = raw == "UI MENU"
            if not matched:
                telemetry = parse_telemetry(raw, "touhou_LAB")
                matched = bool(telemetry is not None and telemetry.get("mode_id") == 0)
        if not matched:
            return False
        field = self._step[0]
        if field in self._set_values:
            self.applied[field] = self._set_values[field]
        self._advance()
        return True

    def tick(self) -> bool:
        """Return True only when this call expires an active sequence."""
        if self.busy and self._deadline is not None and self.clock() >= self._deadline:
            self._finish(False, "TIMEOUT", "等待板端确认超时")
            return True
        return False

    def cancel(self, reason: str = "cancelled") -> bool:
        if not self.busy:
            return False
        self._finish(False, "CANCELLED", reason)
        return True

    def _finish(self, success: bool, status: str, reason: str):
        if not self.busy:
            return
        outcome = dict(success=success, status=status, reason=reason, phase=self.phase,
                       requested=self.requested.copy(), applied=self.applied.copy())
        self.busy = False
        self.phase = "idle"
        self._deadline = None
        self._steps.clear()
        self._step = None
        self.done(outcome)
