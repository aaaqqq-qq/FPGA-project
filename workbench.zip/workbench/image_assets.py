"""Bounded desktop image preparation. The RGB bytes also drive the preview."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import zlib
from PySide6.QtCore import Qt
from PySide6.QtGui import QImage,QImageReader,QPainter,QColor

LAB_BACKGROUND=0xF4F6FA
MAX_FILE_BYTES=64*1024*1024
MAX_DECODE_PIXELS=32_000_000
MAX_WIDTH,MAX_HEIGHT=1280,720

@dataclass(frozen=True)
class ImageAsset:
 path:str
 filename:str
 original_width:int
 original_height:int
 file_bytes:int
 had_alpha:bool
 image:QImage

@dataclass(frozen=True)
class PreparedImage:
 asset:ImageAsset
 width:int
 height:int
 rgb:bytes
 crc32:int
 image:QImage
 @property
 def key(self):
  # Cache comparisons are exact desktop-byte comparisons, not just a CRC32.
  # The tuple holds an immutable bytes reference and is never exported.
  return (self.width,self.height,len(self.rgb),self.crc32,self.rgb)
 def metadata(self):
  return dict(path=self.asset.path,filename=self.asset.filename,original_width=self.asset.original_width,
   original_height=self.asset.original_height,file_bytes=self.asset.file_bytes,width=self.width,
   height=self.height,pixel_bytes=len(self.rgb),crc32=self.crc32,format='RGB888',
   alpha_flattened=self.asset.had_alpha,background=LAB_BACKGROUND)

def load_image(path:str|Path)->ImageAsset:
 path=Path(path).expanduser().resolve()
 try:stat=path.stat()
 except OSError as exc:raise ValueError('无法读取图片文件：'+str(exc)) from exc
 if not path.is_file() or stat.st_size<=0 or stat.st_size>MAX_FILE_BYTES:raise ValueError('图片文件必须非空且不超过64 MiB。')
 reader=QImageReader(str(path));reader.setAutoTransform(True);reader.setDecideFormatFromContent(True)
 if bytes(reader.format()).lower() not in (b'png',b'jpeg',b'jpg',b'bmp'):raise ValueError('只支持PNG、JPG/JPEG和BMP图片。')
 size=reader.size()
 if not size.isValid() or size.width()*size.height()>MAX_DECODE_PIXELS:raise ValueError('图片解码尺寸必须不超过3200万像素。')
 image=reader.read()
 if image.isNull():raise ValueError('图片解码失败：'+reader.errorString())
 if image.width()*image.height()>MAX_DECODE_PIXELS:raise ValueError('图片解码尺寸超过3200万像素。')
 return ImageAsset(str(path),path.name,image.width(),image.height(),stat.st_size,image.hasAlphaChannel(),image)

def initial_size(asset:ImageAsset)->tuple[int,int]:
 scale=min(1.,256/asset.original_width,256/asset.original_height)
 return max(1,round(asset.original_width*scale)),max(1,round(asset.original_height*scale))

def proportional_size(asset:ImageAsset,width:int,height:int,changed:str)->tuple[int,int]:
 if changed=='width':height=max(1,round(width*asset.original_height/asset.original_width))
 else:width=max(1,round(height*asset.original_width/asset.original_height))
 scale=min(1.,MAX_WIDTH/width,MAX_HEIGHT/height)
 return max(1,min(MAX_WIDTH,round(width*scale))),max(1,min(MAX_HEIGHT,round(height*scale)))

def packed_rgb(image:QImage)->bytes:
 """Remove every QImage scanline's alignment padding, preserving RGB order."""
 converted=image.convertToFormat(QImage.Format_RGB888)
 if converted.isNull():raise ValueError('图片RGB转换失败。')
 raw=memoryview(converted.constBits());stride=converted.bytesPerLine();row=converted.width()*3
 return b''.join(bytes(raw[y*stride:y*stride+row]) for y in range(converted.height()))

def prepare_image(asset:ImageAsset,width:int,height:int)->PreparedImage:
 if type(width)is not int or type(height)is not int or not 1<=width<=MAX_WIDTH or not 1<=height<=MAX_HEIGHT:raise ValueError('处理尺寸应为宽1～1280、高1～720。')
 scaled=asset.image.scaled(width,height,Qt.IgnoreAspectRatio,Qt.SmoothTransformation)
 if scaled.isNull():raise ValueError('图片缩放失败。')
 flattened=QImage(width,height,QImage.Format_RGB32);flattened.fill(LAB_BACKGROUND)
 painter=QPainter(flattened);painter.drawImage(0,0,scaled);painter.end()
 rgb=packed_rgb(flattened)
 if len(rgb)!=width*height*3:raise ValueError('RGB像素长度异常。')
 # Use the exact packed upload bytes, including their explicit unpadded stride.
 preview=QImage(rgb,width,height,width*3,QImage.Format_RGB888).copy()
 return PreparedImage(asset,width,height,rgb,zlib.crc32(rgb)&0xffffffff,preview)

def image_canvas(prepared:PreparedImage,x:int,y:int)->QImage:
 if type(x)is not int or type(y)is not int or not 0<=x<=MAX_WIDTH-prepared.width or not 0<=y<=MAX_HEIGHT-prepared.height:raise ValueError('图片目标区域超出1280×720画布。')
 canvas=QImage(MAX_WIDTH,MAX_HEIGHT,QImage.Format_RGB32);canvas.fill(LAB_BACKGROUND)
 painter=QPainter(canvas);painter.drawImage(x,y,prepared.image);painter.end();return canvas
