"""White native game-load panel. No serial port or hardware access in this module."""
from __future__ import annotations
from datetime import datetime, timezone
import secrets,time
from PySide6.QtCore import Signal,QPointF,QEvent
from PySide6.QtGui import QWheelEvent
from PySide6.QtWidgets import (QWidget,QLabel,QVBoxLayout,QHBoxLayout,QComboBox,QSpinBox,
    QLineEdit,QCheckBox,QPushButton,QTableWidget,QTableWidgetItem,QHeaderView,QProgressBar,
    QApplication,QAbstractScrollArea)
from game_load_protocol import SIZES,validate_args,GameLoadRequest,boundary_rows
DESCENDING_COUNTS=(5000,4096,3072,2048,1024,512,256,128,64,32,16,8,4,2,1)

def scroll_surrounding_page(widget,event):
    """Forward wheel motion once to the containing scroll viewport, not a value editor."""
    parent=widget.parentWidget()
    while parent is not None and not isinstance(parent,QAbstractScrollArea):
        parent=parent.parentWidget()
    if parent is None:
        event.ignore();return
    viewport=parent.viewport()
    local=QPointF(viewport.mapFromGlobal(event.globalPosition().toPoint()))
    forwarded=QWheelEvent(local,event.globalPosition(),event.pixelDelta(),event.angleDelta(),
                          event.buttons(),event.modifiers(),event.phase(),event.inverted())
    QApplication.sendEvent(viewport,forwarded)
    event.setAccepted(forwarded.isAccepted())

class ScrollSafeSpinBox(QSpinBox):
    """Scroll the surrounding page; change values only by explicit editing."""
    def __init__(self,parent=None):
        super().__init__(parent)
        self.lineEdit().installEventFilter(self)
    def eventFilter(self,obj,event):
        if obj is self.lineEdit() and event.type()==QEvent.Wheel:
            scroll_surrounding_page(self,event);return True
        return super().eventFilter(obj,event)
    def wheelEvent(self,event):
        scroll_surrounding_page(self,event)

class ScrollSafeComboBox(QComboBox):
    """A closed selector must not consume ordinary page scrolling."""
    def wheelEvent(self,event):
        scroll_surrounding_page(self,event)

def label(text):
    item=QLabel(text);item.setWordWrap(True);return item
def spin(low,high,value):
    item=ScrollSafeSpinBox();item.setRange(low,high);item.setValue(value);return item
def combo(items):
    item=ScrollSafeComboBox()
    for name,value in items:item.addItem(name,value)
    return item

class GameLoadPanel(QWidget):
    command_requested=Signal(int,str,list)
    menu_requested=Signal()
    state_changed=Signal()
    export_requested=Signal()
    def __init__(self,parent=None,clock=time.monotonic):
        super().__init__(parent);self.clock=clock;self.capable=False;self.available=False;self.status_available=False
        self.uncertain=False;self._need_status=False;self._status_id=None;self._status_deadline=0
        self._foreign_id=None;self._request=None;self._menu_pending=False;self._menu_args=None
        self._deadline=0;self._cancelled=False;self._due=False;self._next_id=secrets.randbelow(1000000000)+1000000
        self.queue=[];self.results=[];self.raw_lines=[];self.plans=[];self._plan=None;self._fallback=False;self.identity={}
        self._build();self._enable()
    @property
    def blocks_game(self):
        return bool(self.uncertain or self._status_id or self._foreign_id or self._request or self._menu_pending or self.queue or self._due)
    @property
    def running(self):return bool(self._request or self._foreign_id or self._menu_pending)
    def _id(self):
        self._next_id=(self._next_id+1)%0xffffffff or 1;return self._next_id
    def _build(self):
        v=QVBoxLayout(self);v.setContentsMargins(0,6,0,12);v.setSpacing(12)
        title=label('游戏战斗负载测量');title.setStyleSheet('font-size:20px;font-weight:600');v.addWidget(title)
        self.fps_notice=label('FPS按本次累计换帧与计时计算；显示器约每60帧同步更新。预热及首个采样前显示 --。')
        self.fps_notice.setStyleSheet('font-weight:600;background:#f5f6f8;color:#1f2937;padding:10px;border-radius:8px;')
        v.addWidget(self.fps_notice)
        v.addWidget(label('使用东方游戏的逻辑、碰撞和绘制路径。测试会人工补足敌弹并让角色持续在场，满池自然发射会替换旧弹；这与自然阶段战不同，结果不会混入高阶压力记录。'))
        v.addWidget(label('固定极难阶段战、自动移动、真实受伤与缩放碰撞；敌弹不降尺寸、不降数量。游戏既有效果预算保留，报告全程效果质量范围、缩小效果和丢弃装饰数量。'))
        targets=QHBoxLayout()
        self.target_small=QPushButton('载入 8×8 · 20000颗目标')
        self.target_large=QPushButton('载入 32×32 · 5000颗目标')
        targets.addWidget(self.target_small);targets.addWidget(self.target_large);targets.addStretch();v.addLayout(targets)
        v.addWidget(label('目标配置固定六Boss和12个普通敌人，关闭自动降档；载入后仍须点击开始测量。载入目标不表示已达到60FPS。'))
        row=QHBoxLayout();self.bosses=spin(1,6,3);self.enemies=spin(0,12,6);self.size=combo([(f'{n} × {n}',n) for n in SIZES]);self.count=spin(1,20000,5000)
        for name,w in [('Boss',self.bosses),('普通敌人',self.enemies),('敌弹尺寸',self.size),('目标敌弹数',self.count)]:row.addWidget(label(name));row.addWidget(w)
        v.addLayout(row)
        row=QHBoxLayout();self.duration=combo([('60帧 · 快速探测',60),('600帧 · 约10秒观察',600),('36000帧 · 约10分钟长测',36000)]);self.seed=QLineEdit('123456789');self.seed.setMaxLength(10);self.seed.setMaximumWidth(150)
        row.addWidget(self.duration);row.addWidget(label('随机种子'));row.addWidget(self.seed);row.addStretch();v.addLayout(row)
        self.matrix=QCheckBox('按所选范围逐项测量');v.addWidget(self.matrix)
        row=QHBoxLayout();self.boss_from=spin(1,6,1);self.boss_to=spin(1,6,6);row.addWidget(label('Boss范围'));row.addWidget(self.boss_from);row.addWidget(label('至'));row.addWidget(self.boss_to)
        self.enemy_checks=[]
        for n in (0,6,12):
            w=QCheckBox(f'{n} 普通敌人');w.setChecked(True);self.enemy_checks.append((n,w));row.addWidget(w)
        row.addStretch();v.addLayout(row)
        row=QHBoxLayout();row.addWidget(label('尺寸'))
        self.size_checks=[]
        for n in SIZES:
            w=QCheckBox(str(n));w.setChecked(True);self.size_checks.append((n,w));row.addWidget(w)
        row.addStretch();v.addLayout(row)
        self.descend=QCheckBox('未达60FPS时逐档降低目标数量，并保留每次失败记录');self.descend.setChecked(True);v.addWidget(self.descend)
        v.addWidget(label('默认60帧快速探测。降档候选：'+' / '.join(map(str,DESCENDING_COUNTS))+'（只取低于本次输入的档位）。首次通过后继续下一组合；短测只给出探测边界，稳定性须另做长测。'))
        v.addWidget(label('板端单项测量限时：60帧20秒、600帧120秒、36000帧30分钟。负载与身份核对完整的超时记录可继续下一较低档，但不算完整失败上界；其他异常停止队列。停止会等待当前绘制安全结束。'))
        row=QHBoxLayout();self.start_button=QPushButton('开始所选测量');self.start_button.setObjectName('primary');self.stop_button=QPushButton('停止队列并结束当前测量');self.sync_button=QPushButton('核对测量状态');self.export_button=QPushButton('导出战斗测量')
        for w in (self.start_button,self.stop_button,self.sync_button,self.export_button):row.addWidget(w)
        v.addLayout(row);self.status=label('需完整固化支持 GAME_LOAD 的新版本后启用。');v.addWidget(self.status)
        self.progress=QProgressBar();self.progress.setRange(0,60);self.progress.setValue(0);self.progress.setTextVisible(False);v.addWidget(self.progress)
        self.live=label('等待FPS、弹幕与测试进度。');self.live.setStyleSheet('font-size:18px;font-weight:600;padding:10px;');v.addWidget(self.live)
        details=QWidget();dv=QVBoxLayout(details);dv.setContentsMargins(0,0,0,0);details.hide()
        detail_toggle=QPushButton('显示 / 收起详细计数与验收规则');detail_toggle.setCheckable(True);detail_toggle.toggled.connect(details.setVisible);v.addWidget(detail_toggle);v.addWidget(details)
        self.pipeline_notice=label('并行测量记录：等待板端确认实际显示帧数和游戏计算步数。');dv.addWidget(self.pipeline_notice)
        self.scan_notice=label('显示器保持60Hz刷新；错过换帧时会重复上一幅游戏画面，游戏FPS可能低于60。验收仍要求每次刷新都有新帧，且错过换帧和欠流均为0。');dv.addWidget(self.scan_notice)
        self.scan_notice.setText('严格通过：原严格判据。工程容差通过：仅完整36000帧、原始FPS≥59.99、累计漏帧≤6、单次间隔≤2，且完整性、画质与真实负载全部核对；保留板端原FAIL及全部计数。')
        self.table=QTableWidget(0,11);self.table.setHorizontalHeaderLabels(['请求 / 状态','尺寸','Boss / 敌人','请求弹数','实际弹数范围','实际角色范围','FPS','错过换帧 / 欠流','补弹 / 保活','效果全程','时长类型']);self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents);self.table.setEditTriggers(QTableWidget.NoEditTriggers);self.table.setMinimumHeight(190);v.addWidget(self.table)
        self.bounds=label('已验证结果：未测');v.addWidget(self.bounds)
        for column in (5,7,8,9):self.table.setColumnHidden(column,True)
        self.inputs=[self.bosses,self.enemies,self.size,self.count,self.duration,self.seed,self.matrix,self.boss_from,self.boss_to,self.descend,self.target_small,self.target_large,*[w for _,w in self.enemy_checks],*[w for _,w in self.size_checks]]
        self.target_small.clicked.connect(lambda:self.load_target(8))
        self.target_large.clicked.connect(lambda:self.load_target(32))
        self.start_button.clicked.connect(self.start);self.stop_button.clicked.connect(self.stop);self.sync_button.clicked.connect(self.query_status);self.export_button.clicked.connect(self.export_requested.emit)
    def load_target(self,size):
        if size not in (8,32) or not self.capable or not self.available or self.blocks_game:return False
        self.matrix.setChecked(False);self.descend.setChecked(False)
        self.bosses.setValue(6);self.enemies.setValue(12)
        self.size.setCurrentIndex(self.size.findData(size));self.count.setValue(20000 if size==8 else 5000)
        self.duration.setCurrentIndex(self.duration.findData(60));self.seed.setText('123456789')
        self.status.setText(f'已载入{size}×{size}目标配置，自动降档已关闭；等待开始测量。')
        return True
    def _enable(self):
        idle=self.capable and self.available and not self.blocks_game
        for w in self.inputs:w.setEnabled(idle)
        self.start_button.setEnabled(idle);self.stop_button.setEnabled(self.capable and bool(self.running or self.queue) and not self._cancelled)
        self.sync_button.setEnabled(self.capable and self.status_available and self._status_id is None and self._request is None and not self._menu_pending)
    def set_capabilities(self,caps):
        self.capable=bool(caps and caps.get('fw')=='LAB23' and caps.get('game_load')==1)
        self.identity=dict(caps or {});self.uncertain=self._need_status=self.capable
        if self.capable:self.status.setText('新固件已识别 · 等待确认战斗测量状态')
        else:self.status.setText('当前固件不支持游戏尺寸与 GAME_LOAD；请完整固化新版本。')
        self._enable()
    def set_available(self,available,status_available=None):
        self.available=bool(available);self.status_available=bool(available if status_available is None else status_available)
        self._enable()
        if self.capable and self._need_status and self.status_available and self._status_id is None:self.query_status()
    def owns(self,request_id,op,args):
        if op=='status':return request_id==self._status_id and not args
        if op=='cancel':return self._cancelled and request_id==(self._request.request_id if self._request else self._foreign_id) and not args
        return op=='run' and self._request is not None and request_id==self._request.request_id and tuple(args)==self._request.args
    def query_status(self):
        if not self.capable or not self.status_available or self._status_id is not None or self._request or self._menu_pending:return False
        self._status_id=self._id();self._status_deadline=self.clock()+8;self._need_status=False;self.uncertain=True
        self._enable();self.state_changed.emit();self.command_requested.emit(self._status_id,'status',[]);return True
    def start(self):
        if not self.capable or not self.available or self.blocks_game:return False
        try:
            if not self.seed.text().isascii() or not self.seed.text().isdigit():raise ValueError('随机种子须为非零整数')
            seed=int(self.seed.text());frames=self.duration.currentData();n=self.count.value()
            if self.matrix.isChecked():
                bs=list(range(self.boss_from.value(),self.boss_to.value()+1));ms=[n for n,w in self.enemy_checks if w.isChecked()];sizes=[n for n,w in self.size_checks if w.isChecked()]
                if not bs or not ms or not sizes:raise ValueError('请选择有效Boss范围、普通敌人和尺寸')
            else:bs=[self.bosses.value()];ms=[self.enemies.value()];sizes=[self.size.currentData()]
            args=[validate_args((b,m,n,s,frames,seed)) for b in bs for m in ms for s in sizes]
        except ValueError as exc:self.status.setText(str(exc));return False
        self._fallback=self.descend.isChecked();self._cancelled=False
        self._plan={'created_at':datetime.now(timezone.utc).isoformat(),'automatic_descent':self._fallback,
                    'cases':[{'args':list(a),'status':'NOT_RUN'} for a in args]}
        self.plans.append(self._plan);self.queue=list(self._plan['cases']);self._due=True;self.state_changed.emit();self._enable();self.tick();return True
    def _next(self):
        if not self.queue:self._due=False;self.status.setText('所选测量已结束 · 结果仅覆盖已执行负载');self._enable();self.state_changed.emit();return
        case=self.queue.pop(0);case['status']='WAIT_MENU';self._menu_args=tuple(case['args']);self._case=case;self._menu_pending=True;self._due=False
        self.status.setText('返回菜单，确认后开始下一项战斗负载');self._enable();self.state_changed.emit();self.menu_requested.emit()
    def menu_ready(self,success,reason=''):
        if not self._menu_pending:return
        self._menu_pending=False
        if not success or self._cancelled:
            self._case['status']='CANCELLED' if self._cancelled else 'MENU_FAILED';self._case['reason']=reason;self._clear_queue('NOT_RUN');self._enable();self.state_changed.emit();return
        args=self._menu_args
        expected=bool(self.identity.get('pipe')==1 and self.identity.get('pref8')==1 and args[3] in (8,32))
        self._request=GameLoadRequest(self._id(),args,expected_pipeline=expected,capabilities=dict(self.identity));self._case['status']='RUNNING';self._case['request_id']=self._request.request_id
        self._deadline=self.clock()+min(1800,max(20,args[4]/5))+90;self.progress.setRange(0,args[4]);self.progress.setValue(0)
        self.pipeline_notice.setText('本次等待并行绘制证据；准备步骤与测量窗口分开记录。' if expected else '本次为串行绘制；结果按本次实际连接和路径单独记录。')
        self.status.setText(f'测量请求 {self._request.request_id} · 受控游戏负载，等待板端确认')
        self._enable();self.state_changed.emit();self.command_requested.emit(self._request.request_id,'run',list(args))
    def _clear_queue(self,status):
        for case in self.queue:case['status']=status
        self.queue=[];self._due=False
    def stop(self):
        self._clear_queue('NOT_RUN_CANCELLED');self._cancelled=True
        request_id=self._request.request_id if self._request else self._foreign_id
        if request_id:
            self._deadline=self.clock()+15;self.status.setText('取消已请求 · 等待原测量结束，暂不释放控制权')
            self.command_requested.emit(request_id,'cancel',[])
        elif self._menu_pending:self.status.setText('队列已停止 · 等待菜单事务结束')
        else:self.status.setText('队列已停止')
        self._enable();self.state_changed.emit()
    def ingest(self,item):
        self.raw_lines.append(item['raw']);i=item['id'];kind=item['kind_line']
        if self._request and self.clock()>=self._deadline:self.tick()
        if kind=='GLOAD_ACK' and item.get('op')=='status' and i==self._status_id:
            self._status_id=None
            if self.identity.get('hud_dma_proof')==1 and (type(item.get('hud_dma'))is not int or item.get('hud_dma')!=self.identity.get('hud_dma')):
                self.uncertain=True;self.status.setText('板端HUD策略与已核对状态不一致，请重新连接核对')
            elif item.get('status')=='OK':
                self.uncertain=False;self._foreign_id=item['current'] if item['running'] else None
                self.status.setText('板端仍在战斗测量，可停止原任务' if self._foreign_id else '已确认空闲 · 可开始游戏战斗测量')
            else:self.uncertain=True;self.status.setText('状态核对失败，请重新核对')
            self._enable();self.state_changed.emit();return
        if self._foreign_id and i==self._foreign_id and kind=='GLOAD_DONE':
            self._foreign_id=None;self.uncertain=False;self.status.setText('原测量已结束；重连前数据不作完整验收');self._enable();self.state_changed.emit();return
        request=self._request
        if not request or request.request_id!=i:return
        if kind!='GLOAD_DONE':request.feed(item)
        if kind=='GLOAD_ACK' and item.get('op')=='run' and item.get('status')=='ERR':
            result=request.finish(dict(kind_line='GLOAD_DONE',id=i,status='ERROR',reason=item.get('reason'),raw='HOST run rejected'))
            self._finish(result,allow_descent=False);return
        if kind=='GLOAD_STAT':
            s=item;self.progress.setValue(s['frames']);fps=s['swaps']*1e6/s['us'] if s['us'] else 0
            self.live.setText(f"{fps:.3f} FPS  ·  {self._request.args[3] if self._request else '—'}像素 / 实测 {s['nmin']}～{s['nmax']}颗  ·  {s['bmin']}Boss + {s['mmin']}敌人  ·  {s['frames']}帧 / {s['us']/1e6:.1f}秒")
        if kind=='GLOAD_PIPE':
            if item['phase']=='prime':self.pipeline_notice.setText(f"已单独准备1步，用时 {item['prime_us']/1000:.3f} ms；准备步骤不计入本次测试。")
            else:self.pipeline_notice.setText(f"已显示 {item['presented_delta']} 帧 · 游戏计算完成 {item['logic_committed_delta']} 步 · 计算比画面领先 {item['latency']} 帧 · 串行回退 {item['fallback']} 次。")
        if kind=='GLOAD_DONE':self._finish(request.finish(item),allow_descent=not self._cancelled)
    def reject_wire(self,raw):
        """A corrupt in-window proof cannot be repaired by a later good copy."""
        if self._request:
            self._request.errors.append('测量或流水证据回包格式错误')
            self._request.raw_lines.append(raw)
    def _finish(self,result,allow_descent):
        self.results.append(result);self._case['status']=result['status'];self._case['accepted_pass']=result['accepted_pass']
        self._request=None;self.uncertain=result['status']=='TIMEOUT'
        # Only a complete measured timing failure can trigger the explicitly
        # enabled search. Missing replies, guards or load errors stop the queue.
        engineering=result.get('engineering_long_pass',False)
        self._case['engineering_long_pass']=engineering
        valid_failure=result.get('search_eligible',False) or result.get('partial_timeout_observation',False)
        if allow_descent and self._fallback and valid_failure and not engineering:
            candidates=[n for n in DESCENDING_COUNTS if n<result['args'][2]]
            if candidates:
                args=list(result['args']);args[2]=candidates[0];case={'args':args,'status':'NOT_RUN','after_failed_request':result['request_id']}
                self._plan['cases'].append(case);self.queue.insert(0,case)
        if result['status'] not in ('PASS','FAIL') or (result['status']=='FAIL' and not valid_failure and not engineering):self._clear_queue('NOT_RUN_INCOMPLETE')
        if result['status']=='PASS' and not result['accepted_pass']:self._clear_queue('NOT_RUN_INVALID_EVIDENCE')
        self.status.setText('严格通过' if result['accepted_pass'] else '工程容差通过 · 完整十分钟 ≥59.99 FPS（板端原判定 '+str(result['status'])+' / '+str(result['reason'])+'）' if engineering else '未完成 · 原窗口没有完整通过' if result['status'] not in ('PASS','FAIL') else '未通过：'+('；'.join(result['errors'])))
        if result.get('hud_policy_verified'):
            self.status.setText(self.status.text()+f" · 实际绘图设置已核对：{result['hud_policy_evidence']['expected']}")
        else:
            self.status.setText(self.status.text()+' · 绘图设置未核对，不能用于设置对比验收')
        self._refresh();self._due=bool(self.queue) and not self._cancelled;self._enable();self.state_changed.emit()
    def tick(self):
        now=self.clock()
        if self._status_id and now>=self._status_deadline:
            self._status_id=None;self.uncertain=True;self.status.setText('状态查询超时 · 重新核对前保持锁定');self._enable();self.state_changed.emit()
        if self._request and now>=self._deadline:
            if not self._cancelled:
                self._request.errors.append('主机等待超时');self.stop()
            else:
                result=self._request.finish(dict(kind_line='GLOAD_DONE',id=self._request.request_id,status='TIMEOUT',reason='host_timeout',raw='HOST timeout; board completion unknown'))
                self._finish(result,False);self.uncertain=True;self.status.setText('原测量结束未确认 · 保持锁定，请核对状态或重连');self._enable();self.state_changed.emit()
        if self._foreign_id and self._cancelled and now>=self._deadline:
            self.uncertain=True;self.status.setText('取消后尚未确认结束，请核对测量状态');self._enable()
        if self._due and not self._request and not self._menu_pending and self.available:self._next()
    def disconnected(self):
        if self._request:
            result=self._request.finish(dict(kind_line='GLOAD_DONE',id=self._request.request_id,status='DISCONNECTED',reason='connection_lost',raw='HOST disconnected'))
            self._finish(result,False)
        if self._menu_pending:self._case['status']='DISCONNECTED'
        self._clear_queue('NOT_RUN_DISCONNECTED');self._request=None;self._menu_pending=False;self._status_id=None;self._foreign_id=None
        self.capable=self.available=self.status_available=False;self.uncertain=self._need_status=False;self._cancelled=False;self._enable()
        self.pipeline_notice.setText('连接已断开；上次结果保留在记录中，等待新的测量。')
    def _refresh(self):
        self.table.setRowCount(len(self.results))
        for row,r in enumerate(self.results):
            b,m,n,size,frames,seed=r['args'];s=r.get('stat') or {};d=r.get('detail') or {}
            span=lambda a,z:f'{s.get(a,"—")}～{s.get(z,"—")}'
            visual=f"质量{d.get('qmin','—')}～{d.get('qmax','—')} / 缩小{d.get('lodsum','—')} / 丢弃{d.get('fxdrop','—')}+{d.get('ddrop','—')}"
            status='严格通过' if r['accepted_pass'] else '工程容差通过' if r.get('engineering_long_pass') else '未完成' if r['status'] not in ('PASS','FAIL') or r.get('partial_timeout_observation') else '未通过'
            if not r.get('hud_policy_verified'):status+=' / 设置未核对'
            duration=('10分钟长测' if frames>=36000 else f'{frames}帧观察')+f" / 已测{s.get('frames','—')}"
            cells=[f"{r['request_id']} / {status}",str(size),f'{b} / {m}',str(n),span('nmin','nmax'),span('bmin','bmax')+' / '+span('mmin','mmax'),f"{r['actual_fps']:.3f}" if r['actual_fps'] is not None else '—',f"{s.get('missed','—')} / {s.get('uf','—')}",f"{d.get('fill','—')} / {d.get('keep','—')}",visual,duration]
            for col,value in enumerate(cells):self.table.setItem(row,col,QTableWidgetItem(value))
        bounds=boundary_rows(self.results)
        self.bounds.setText('；'.join(f"{r['bosses']}Boss+{r['enemies']}敌人 / {r['size']}px / {r['frames']}帧{'短测' if r['frames']<36000 else '长测'}：已验≥{r['verified_lower'] if r['verified_lower'] is not None else '未有'}，失败上界{r['failed_upper'] if r['failed_upper'] is not None else '未测'}" for r in bounds[-8:]) or '未测')
        tolerant=[r for r in self.results if r.get('engineering_long_pass')]
        if tolerant:self.bounds.setText('工程容差长测已验：'+'；'.join(f"{r['args'][0]}Boss+{r['args'][1]}敌人 / {r['args'][3]}像素 / {r['args'][2]}颗 · {r['actual_fps']:.5f} FPS" for r in tolerant[-8:])+'（严格边界及原判定完整保存在导出中）')
    def export_document(self):
        return {'schema':'ti60_game_load_ui_v2_pipe5','exported_at':datetime.now(timezone.utc).isoformat(),
            'scope':'受控东方游戏负载：人工补弹、角色保活；不是自然阶段战或ADV压力',
            'identity':dict(self.identity),'results':list(self.results),'bounds':boundary_rows(self.results),'engineering_long_results':[dict(request_id=r['request_id'],args=r['args'],engineering_long_pass=r.get('engineering_long_pass',False),policy=r.get('engineering_policy'),original_board_verdict=r.get('original_board_verdict')) for r in self.results],'plans':self.plans,
            'pending_request':self._request.request_id if self._request else None,'completion_uncertain':self.blocks_game,
            'raw_lines':list(self.raw_lines)}
