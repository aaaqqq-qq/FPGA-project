"""Explicit LAB60 GUI presets; never choose a lower load after a slow result."""
from adv_protocol import validate_args

DURATIONS=[('600 帧 · 约10秒观察',600),('3600 帧 · 约1分钟观察',3600),('36000 帧 · 约10分钟长测',36000)]
PRESETS=[('当前自选参数',None)]
for alpha in (0,128,255):PRESETS.append(('8×8 · N20000 · Alpha%d · Key开'%alpha,(20000,8,alpha)))
for size in (16,24,32,40,48,56):PRESETS.append(('%d×%d · N64 · Alpha128 · Key开'%(size,size),(64,size,128)))

def preset_args(index,frames):
 entry=PRESETS[index][1]
 if entry is None:raise ValueError('当前配置不需要载入预设')
 n,size,alpha=entry
 return validate_args('stress',('fpga',n,size,0,0x4c8dff,0xf18bbb,0xf5be52,1,alpha,1,0,frames,1))

def performance_args(args,section):
 args=validate_args('stress',args)
 if args[0]!='fpga':raise ValueError('本轮60FPS测试只纳入FPGA；CPU仍可用普通压力测试。')
 if args[2]==64:raise ValueError('64×64暂不纳入本轮60FPS验收，可单独做普通压力测试。')
 if section=='key' and not args[9]:raise ValueError('高阶二性能测试需明确开启Key去背。')
 return args
