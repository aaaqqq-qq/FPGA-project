"""Acknowledged transaction tests; no Qt, serial device or hardware process."""
from pathlib import Path
import re
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import game_actions as g

MENU_STAT = ("STAT mode=0 hw=1 N=0 fps100=6000 swaps=120 scan=120 us=2000000 "
             "frame=16000 logic=1000 render=15000 missed=0 uf=0 vstr=2 h_pk=1200 "
             "fw=LAB1 paused=0 control=PC")


class SequenceTests(unittest.TestCase):
    def make_sequence(self):
        self.clock = 100.
        self.sent = []
        self.menus = []
        self.outcomes = []
        return g.ActionSequence(self.sent.append, lambda: self.menus.append(True),
                                self.outcomes.append, clock=lambda: self.clock, timeout=5)

    def test_preset_waits_for_each_ack_and_changes_only_two_fields(self):
        seq = self.make_sequence()
        self.assertTrue(seq.start_preset(4, 6, 1))
        self.assertEqual(self.menus, [True])
        self.assertEqual(self.sent, [])
        self.assertEqual(seq.phase, "menu")
        for unrelated in ("OK set", "OK mode 1", "UI MENU other", MENU_STAT.replace("mode=0", "mode=1")):
            self.assertFalse(seq.feed(unrelated))
        self.assertEqual(self.sent, [])
        self.assertTrue(seq.feed("UI MENU"))
        self.assertEqual(self.sent, [b":set boss_count 4\n"])
        self.assertTrue(seq.feed("OK set"))
        self.assertEqual(self.sent[-1], b":set enemy_count 6\n")
        self.assertEqual(seq.applied, {"boss_count": 4})
        self.assertTrue(seq.feed("OK set"))
        self.assertEqual(self.sent[-1], b":mode 1\n")
        self.assertEqual(len(self.sent), 3)
        self.assertFalse(seq.feed("OK mode 0"))
        self.assertTrue(seq.busy)
        self.assertTrue(seq.feed("OK mode 1"))
        self.assertFalse(seq.busy)
        self.assertEqual(len(self.outcomes), 1)
        self.assertTrue(self.outcomes[0]["success"])
        self.assertEqual(self.outcomes[0]["applied"], {"boss_count": 4, "enemy_count": 6})
        self.assertFalse(seq.feed("OK mode 1"))

    def test_fresh_lab_menu_stat_can_confirm_but_old_firmware_cannot(self):
        seq = self.make_sequence(); seq.start_preset(6, 12)
        self.assertFalse(seq.feed(MENU_STAT.replace("fw=LAB1 paused=0 control=PC", "")))
        self.assertEqual(self.sent, [])
        self.assertTrue(seq.feed(MENU_STAT))
        self.assertEqual(self.sent, [b":set boss_count 6\n"])

    def test_menu_failure_never_sets_or_starts(self):
        for failure in ("ERR lab active; exit lab first", "ERR replay active"):
            seq = self.make_sequence(); seq.start_preset(3, 0, 2)
            seq.feed(failure)
            self.assertEqual(self.sent, [])
            self.assertFalse(seq.busy)
            self.assertEqual(self.outcomes[0]["status"], "ERROR")
            self.assertEqual(self.outcomes[0]["applied"], {})

    def test_partial_failure_stops_and_reports_only_acknowledged_field(self):
        seq = self.make_sequence(); seq.start_preset(6, 12)
        seq.feed("UI MENU"); seq.feed("OK set"); seq.feed("ERR invalid field/value; unchanged")
        self.assertEqual(self.sent, [b":set boss_count 6\n", b":set enemy_count 12\n"])
        self.assertFalse(self.outcomes[0]["success"])
        self.assertEqual(self.outcomes[0]["applied"], {"boss_count": 6})
        self.assertEqual(self.outcomes[0]["phase"], "enemy_count")

    def test_concurrent_start_is_rejected_without_side_effects(self):
        seq = self.make_sequence(); seq.start_preset(4, 6)
        self.assertFalse(seq.start_preset(6, 12))
        self.assertFalse(seq.start_config("graze_score", 100))
        self.assertEqual(self.menus, [True]); self.assertEqual(self.sent, [])
        self.assertEqual(seq.requested["boss_count"], 4)

    def test_timeout_has_no_retry_and_late_ack_is_rejected(self):
        seq = self.make_sequence(); seq.start_preset(4, 6)
        self.clock = 104.99; self.assertFalse(seq.tick()); self.assertTrue(seq.busy)
        self.clock = 105.; self.assertTrue(seq.tick())
        self.assertEqual(self.sent, [])
        self.assertEqual(self.outcomes[0]["status"], "TIMEOUT")
        self.assertFalse(seq.feed("UI MENU")); self.assertEqual(self.sent, [])
        self.assertFalse(seq.tick()); self.assertEqual(len(self.outcomes), 1)

    def test_deadline_is_per_step_and_feed_itself_checks_deadline(self):
        seq = self.make_sequence(); seq.start_preset(4, 6)
        self.clock = 104.; seq.feed("UI MENU")
        self.clock = 108.; seq.feed("OK set")
        self.clock = 113.; self.assertFalse(seq.feed("OK set"))
        self.assertEqual(self.outcomes[0]["status"], "TIMEOUT")
        self.assertNotIn(b":mode 0\n", self.sent)

    def test_cancel_does_not_send_rollback_or_restart(self):
        seq = self.make_sequence(); seq.start_preset(4, 6)
        seq.feed("UI MENU"); seq.cancel("disconnected")
        self.assertEqual(self.sent, [b":set boss_count 4\n"])
        self.assertEqual(self.outcomes[0]["status"], "CANCELLED")
        self.assertFalse(seq.cancel()); self.assertEqual(len(self.outcomes), 1)

    def test_topology_config_enters_menu_and_remains_in_menu(self):
        for field, value in (("boss_count", 5), ("enemy_count", 9), ("background_depth_enabled", 1)):
            seq = self.make_sequence(); seq.start_config(field, value)
            self.assertEqual(self.menus, [True]); self.assertEqual(self.sent, [])
            seq.feed("UI MENU")
            self.assertEqual(self.sent, [f":set {field} {value}\n".encode()])
            seq.feed("OK set")
            self.assertTrue(self.outcomes[0]["success"])
            self.assertEqual(len(self.sent), 1)

    def test_ordinary_config_sets_directly_and_array_names_work(self):
        seq = self.make_sequence(); seq.start_config("boss_fire_num[4]", 8)
        self.assertEqual(self.menus, [])
        self.assertEqual(self.sent, [b":set boss_fire_num[4] 8\n"])
        seq.feed("OK set"); self.assertTrue(self.outcomes[0]["success"])
        seq.start_config("player_shot_damage", 20, requires_menu=True)
        self.assertEqual(self.menus, [True])
        self.assertEqual(len(self.sent), 1)

    def test_invalid_inputs_do_not_emit(self):
        seq = self.make_sequence()
        for args in ((0, 0, 0), (7, 0, 0), (3, 13, 0), (3, 0, 3), (True, 0, 0)):
            with self.assertRaises(ValueError): seq.start_preset(*args)
        for name, value in (("boss_max_hp", 1000), ("x\n:mode", 1), ("layer_order[8]", 2),
                            ("level_threshold[1]", 1000), ("enemy_count", True)):
            with self.assertRaises(ValueError): seq.start_config(name, value)
        self.assertEqual(self.sent, []); self.assertEqual(self.menus, [])

    def test_send_or_menu_exception_stops_immediately(self):
        def fail(*args): raise OSError("gone")
        results = []
        seq = g.ActionSequence(fail, fail, results.append)
        seq.start_preset(3, 0)
        self.assertFalse(seq.busy); self.assertEqual(results[0]["status"], "SEND_ERROR")
        results.clear(); seq.start_config("regen_amount", 10)
        self.assertFalse(seq.busy); self.assertEqual(results[0]["status"], "SEND_ERROR")


class RegistryTests(unittest.TestCase):
    def test_names_unique_and_visible_labels_ranges(self):
        self.assertEqual(len(g.CONFIG_FIELDS), len(g.CONFIG_BY_NAME))
        self.assertGreater(len(g.CONFIG_FIELDS), 100)
        for spec in g.CONFIG_FIELDS:
            self.assertRegex(spec.name, r"^[a-z][a-z0-9_]*(?:\[[0-9]\])?$")
            self.assertTrue(spec.label)
            self.assertLessEqual(spec.minimum, spec.maximum)
        self.assertEqual(g.CONFIG_BY_NAME["boss_count"].maximum, 6)
        self.assertEqual(g.CONFIG_BY_NAME["enemy_count"].maximum, 12)
        self.assertTrue(g.CONFIG_BY_NAME["enemy_count"].menu_only)
        self.assertFalse(g.CONFIG_BY_NAME["logic_hz"].writable)
        self.assertFalse(g.CONFIG_BY_NAME["level_main[5]"].writable)
        self.assertTrue(g.CONFIG_BY_NAME["level_threshold[5]"].writable)

    def test_registry_covers_actual_firmware_struct_and_setter_whitelist(self):
        from firmware_paths import project_root
        source = project_root()/"src"
        if not (source / "game_config.h").is_file():
            self.skipTest("firmware source is not shipped with this standalone app test checkout")
        header = (source / "game_config.h").read_text()
        header = re.sub(r"/\*.*?\*/", "", header, flags=re.S)
        header = re.search(r"typedef\s+struct\s*\{(.*?)\}\s*GameConfig", header, flags=re.S).group(1)
        fields = set()
        for declaration in re.findall(r"unsigned\s+([^;]+);", header):
            for entry in declaration.split(","):
                match = re.fullmatch(r"\s*(\w+)(?:\[(\w+)\])?\s*", entry)
                self.assertIsNotNone(match, entry)
                name, length = match.groups()
                if length:
                    size = 6 if length == "MAX_BOSSES" else int(length)
                    fields.update(f"{name}[{i}]" for i in range(size))
                else:
                    fields.add(name)
        self.assertEqual(set(g.CONFIG_BY_NAME), fields|{"tick_profile","hud_dma_tail_enabled"})
        self.assertNotIn("tick_profile",fields)
        self.assertTrue(g.CONFIG_BY_NAME["tick_profile"].menu_only)
        self.assertNotIn("hud_dma_tail_enabled",fields)
        self.assertTrue(g.CONFIG_BY_NAME["hud_dma_tail_enabled"].menu_only)
        code = (source / "game_config.c").read_text()
        hot = set(re.findall(r"FIELD\((\w+),", code)) - {"n"}
        arrays = {name: (6 if count == "MAX_BOSSES" else int(count))
                  for name, count in re.findall(r"ARRAY\((\w+),(MAX_BOSSES|[0-9]+),", code)}
        editable = hot | {f"{name}[{i}]" for name, size in arrays.items() for i in range(size)
                          if name != "level_threshold" or i >= 2}
        self.assertEqual({item.name for item in g.CONFIG_FIELDS if item.writable}, editable|{"tick_profile","hud_dma_tail_enabled"})
        self.assertRegex(code,r'if\(!strcmp\(field,"hud_dma_tail_enabled"\)\)\{if\(value>1\)return 0;hud_dma_tail_enabled=value;return 1;\}')

    def test_presets_do_not_contain_full_configuration_reset(self):
        self.assertEqual([(item["bosses"], item["enemies"]) for item in g.CONFIG_OPTIONS],
                         [(4, 6), (6, 12), (3, 0)])
        self.assertTrue(all(set(item) == {"label", "bosses", "enemies"} for item in g.CONFIG_OPTIONS))


if __name__ == "__main__":
    unittest.main(verbosity=2)
