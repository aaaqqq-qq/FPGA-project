"""Synthetic complete UART windows; no hardware, no performance claim."""
import copy
import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'tests'))
import engineering_policy as policy
import game_load_protocol as protocol
assert Path(policy.__file__).resolve()==ROOT/'engineering_policy.py'
assert Path(protocol.__file__).resolve()==ROOT/'game_load_protocol.py'

ARGS=(6,12,15000,32,36000,123456789)
def wire(item):
    return protocol.parse_game_load_reply(item['kind_line']+' '+' '.join(f'{k}={v}' for k,v in item.items() if k not in ('raw','kind_line')))
def complete(misses=6,*,status='FAIL',reason='timing'):
    b,m,n,size,frames,seed=ARGS
    def row(tag,**v):return dict(kind_line=tag,**v)
    rows=[
      row('GLOAD_ACK',id=42,op='run',status='OK',kind='GAME_LOAD',b=b,m=m,n=n,size=size,frames=frames,seed=seed,cfg=123,deadline_us=1800000000,pipe=1),
      row('GLOAD_PIPE',id=42,phase='prime',pipe=1,warmup=2,prime_us=9000,prime_logic=1,prime_present=1,live_start=0,live_end=1,presented_start=0,presented_end=0,input_start=0,input_end=1,n_start=n,n_end=n,r_epoch=3,snap_epoch=3,m_epoch=1,latency=1),
      row('GLOAD_READY',id=42,warmup=2,prepare_us=50000,initial_fill=n,kind='GAME_LOAD',pipe=1,prime=1),
      row('GLOAD_STAT',id=42,frames=frames,us=600000000,swaps=frames,scans=frames,gap=1,missed=0,uf=0,ldrop=0,lover=0,nmin=n,nmax=n,bmin=b,bmax=b,mmin=m,mmax=m,logicmax=5000,rendermax=7000,late=0),
      row('GLOAD_DETAIL',id=42,frames=frames,fill=50,recycle=10,keep=8,hits=2,damage=20,bhits=10,mhits=2,size=size,seed=seed,cfg=123,guards=0,logerr=0,qly=1,lod=0,qmin=1,qmax=1,lodsum=0,fxdrop=0,ddrop=0,fault=0,ticks=frames,runtime=frames+1,mode=1,hw=1,active=1,paused=0,invincible=0,autoplay=1,collision='scaled',pipe=1),
      row('MOTION_DIAG',id=42,submitted=frames,completed=frames,cycles_last=650000,read_last=660000,write_last=320000),
      row('GLOAD_PIPE',id=42,phase='final',pipe=1,frames=frames,presented_delta=frames,logic_committed_delta=frames,live_epoch=frames+1,presented_epoch=frames,input_epoch=frames,frame_epoch=frames+3,snap_epoch=frames+3,latency=1,backlog=0,fallback=0),
      row('GLOAD_VIEW',id=42,phase='final',state_epoch=frames,input_epoch=frames,n=n,b=b,m=m,cfg=123,mode=1,hw=1,active=1,paused=0,hp=85,score=200,lv=2,hit=1,grazes=5,graze_total=50,quality=1,lod=0,visual=2,bg=1,opaque=0,alpha=224,key=1,alpha_enable=1,draw_n=n,key_rgb=16711935),
      row('GLOAD_DONE',id=42,status=status,reason=reason)]
    ack,prime,ready,stat,detail,motion,final,view,done=rows
    for x in (ack,ready,detail):x['hud_dma']=0
    done.update(status=status,reason=reason)
    out=[ack,prime,ready]
    for frame in range(60,36001,60):
        miss=min(misses,frame//5000)
        st=copy.deepcopy(stat);st.update(frames=frame,us=round((frame+miss)*1e6/60),swaps=frame,scans=frame+miss,missed=miss,gap=2 if miss else 1,late=miss)
        de=copy.deepcopy(detail);de.update(frames=frame,ticks=frame,runtime=frame+1,qmin=1,qmax=1)
        win=copy.deepcopy(final);win.update(phase='sample' if frame<36000 else 'final',frames=frame,presented_delta=frame,logic_committed_delta=frame,live_epoch=frame+1,presented_epoch=frame,input_epoch=frame,frame_epoch=frame+3,snap_epoch=frame+3,backlog=miss)
        vi=copy.deepcopy(view);vi.update(phase=win['phase'],state_epoch=frame,input_epoch=frame)
        out.extend([st,de])
        if frame==36000:out.append(motion)
        out.extend([win,vi])
    out.append(done)
    return [wire(x) for x in out]
def finish(rows):
    req=protocol.GameLoadRequest(42,ARGS,expected_pipeline=True,capabilities={'hud_dma':0,'hud_dma_proof':1})
    for x in rows[:-1]:
        assert x is not None
        req.feed(x)

    return req.finish(rows[-1])
def mutate_rows(rows,kind,key,value,*,frame=None):
    for x in rows:
        if x['kind_line']==kind and (frame is None or x.get('frames',x.get('state_epoch'))==frame):x[key]=value
    return [wire(x) for x in rows]

class EngineeringLongPolicyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.good=finish(complete())
    def test_complete_six_misses_is_engineering_only_and_original_immutable(self):
        r=self.good
        self.assertTrue(r['engineering_long_pass'],r['engineering_errors'])
        self.assertFalse(r['accepted_pass']);self.assertFalse(r['long_60fps_pass'])
        self.assertEqual((r['status'],r['reason']),('FAIL','timing'))
        self.assertEqual(r['original_board_verdict'],{'status':'FAIL','reason':'timing'})
        self.assertEqual(r['stat']['missed'],6);self.assertEqual(r['stat']['frames'],36000)
        self.assertEqual(len(r['raw_lines']),2405)
    def test_pipeline_fail_reason_can_qualify_without_rewriting(self):
        rows=complete(reason='pipeline');r=finish(rows)
        self.assertTrue(r['engineering_long_pass'],r['engineering_errors'])
        self.assertEqual(r['status'],'FAIL');self.assertEqual(r['reason'],'pipeline')
    def test_zero_miss_clean_window_keeps_strict_pass(self):
        r=finish(complete(0,status='PASS',reason='complete'))
        self.assertTrue(r['accepted_pass'],r['errors']);self.assertTrue(r['long_60fps_pass'])
        self.assertTrue(r['engineering_long_pass'],r['engineering_errors'])
    def test_seven_misses_and_late_budget_reject(self):
        r=finish(complete(7));self.assertFalse(r['engineering_long_pass'])
        for kind,key,value in [('GLOAD_STAT','late',7),('GLOAD_STAT','gap',3),('GLOAD_PIPE','backlog',7)]:
            with self.subTest(key=key):
                r=finish(mutate_rows(complete(),kind,key,value,frame=36000));self.assertFalse(r['engineering_long_pass'])
    def test_integer_raw_fps_threshold_not_three_digit_display(self):
        for us,good in ((600100016,True),(600100017,False),(600000000,True),(599000000,False)):
            with self.subTest(us=us):
                r=finish(mutate_rows(complete(),'GLOAD_STAT','us',us,frame=36000))
                self.assertEqual(r['engineering_long_pass'],good,r['engineering_errors'])
    def test_every_counter_integrity_and_load_gate_survives_tolerance(self):
        for key,value in [('uf',1),('ldrop',1),('lover',1),('nmin',14999),('nmax',15001),('bmin',5),('bmax',7),('mmin',11),('mmax',13),('scans',36005),('swaps',35999),('frames',35999)]:
            with self.subTest(key=key):
                r=finish(mutate_rows(complete(),'GLOAD_STAT',key,value,frame=36000));self.assertFalse(r['engineering_long_pass'])
    def test_every_quality_runtime_and_fault_gate_survives_tolerance(self):
        for key,value in [('guards',1),('logerr',1),('fault',1),('fxdrop',1),('ddrop',1),('qmin',0),('qmax',2),('cfg',124),('size',8),('seed',1),('ticks',35999),('runtime',36000),('mode',0),('hw',0),('active',0),('paused',1),('invincible',1),('autoplay',0),('collision','fixed')]:
            with self.subTest(key=key):
                r=finish(mutate_rows(complete(),'GLOAD_DETAIL',key,value,frame=36000));self.assertFalse(r['engineering_long_pass'])
    def test_alpha_ck_motion_epoch_and_pipeline_gates_survive_tolerance(self):
        for kind,key,value in [('GLOAD_VIEW','alpha',255),('GLOAD_VIEW','key',0),('GLOAD_VIEW','key_rgb',0),('GLOAD_VIEW','opaque',1),('GLOAD_VIEW','draw_n',14999),('GLOAD_VIEW','n',14999),('GLOAD_VIEW','alpha_enable',0),('GLOAD_PIPE','fallback',1),('GLOAD_PIPE','latency',0),('GLOAD_PIPE','logic_committed_delta',35999),('GLOAD_PIPE','presented_delta',35999),('GLOAD_PIPE','snap_epoch',36002),('MOTION_DIAG','completed',35999)]:
            with self.subTest(key=key):
                r=finish(mutate_rows(complete(),kind,key,value,frame=None if kind=='MOTION_DIAG' else 36000));self.assertFalse(r['engineering_long_pass'])
    def test_early_fault_cannot_be_erased_by_good_final(self):
        for kind,key,value in [('GLOAD_STAT','uf',1),('GLOAD_STAT','late',1),('GLOAD_DETAIL','fault',1),('GLOAD_DETAIL','fxdrop',1),('GLOAD_PIPE','backlog',1),('GLOAD_VIEW','alpha',255)]:
            with self.subTest(kind=kind,key=key):
                r=finish(mutate_rows(complete(),kind,key,value,frame=60));self.assertFalse(r['engineering_long_pass'])
    def test_raw_sample_missing_duplicate_and_order_fail_closed(self):
        for change in ('missing','duplicate','reverse'):
            rows=complete()
            if change=='missing':rows.pop(3)
            elif change=='duplicate':rows.insert(3,copy.deepcopy(rows[3]))
            else:rows[3],rows[7]=rows[7],rows[3]
            with self.subTest(change=change):self.assertFalse(finish(rows)['engineering_long_pass'])
    def test_wrong_or_missing_hud_proof_rejected(self):
        for kind in ('GLOAD_ACK','GLOAD_READY','GLOAD_DETAIL'):
            with self.subTest(kind=kind):
                rows=complete()
                for x in rows:
                    if x['kind_line']==kind:x.pop('hud_dma',None)
                self.assertFalse(finish([wire(x)for x in rows])['engineering_long_pass'])
    def test_cancel_timeout_error_short_and_incomplete_never_pass(self):
        for status,reason in [('CANCEL','cancel'),('FAIL','timeout'),('FAIL','fault'),('ERROR','engine'),('PASS','timing')]:
            r=copy.deepcopy(self.good);r.update(status=status,reason=reason)
            with self.subTest(status=status,reason=reason):self.assertFalse(policy.engineering_evaluate(r)['pass'])
        for frames in (60,600,35999,36001):
            r=copy.deepcopy(self.good);r['args'][4]=frames
            with self.subTest(frames=frames):self.assertFalse(policy.engineering_evaluate(r)['pass'])
        for key in ('ack','ready','stat','detail','pipeline_evidence'):
            r=copy.deepcopy(self.good);r[key]=None
            with self.subTest(missing=key):self.assertFalse(policy.engineering_evaluate(r)['pass'])
    def test_attach_does_not_mutate_original_acceptance_status_or_counters(self):
        r=copy.deepcopy(self.good)
        original={k:copy.deepcopy(v)for k,v in r.items()if not k.startswith('engineering_')and k!='original_board_verdict'}
        policy.attach_engineering_result(r)
        self.assertEqual({k:v for k,v in r.items()if not k.startswith('engineering_')and k!='original_board_verdict'},original)

if __name__=='__main__':unittest.main(verbosity=2)
