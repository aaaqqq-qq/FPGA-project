"""V2.1 real Qt integration contracts; uses the hardware-free base UI fixture.

All UART/device/process launches remain forbidden by NativeUIContracts.setUp.
Tests exercise actual widgets, signals, ActionSequence and progress integration.
"""
import codecs
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_ui as base
from PySide6.QtWidgets import QLabel, QMessageBox
from game_actions import ActionSequence, CONFIG_FIELDS
import main as ui
import download_panel


class V21UIContracts(unittest.TestCase):
    # Reuse its strict no-real-device fixture without rerunning old test methods.
    setUpClass = classmethod(base.NativeUIContracts.setUpClass.__func__)
    setUp = base.NativeUIContracts.setUp
    dispose_window = base.NativeUIContracts.dispose_window
    connect_fake = base.NativeUIContracts.connect_fake
    poll = base.NativeUIContracts.poll
    ready = base.NativeUIContracts.ready
    disabled = base.NativeUIContracts.disabled

    def feed(self, link, *lines, now=101):
        link.lines = list(lines)
        self.poll(now)

    def start_preset(self, bosses=4, mobs=6, mode=0):
        link = self.ready()
        with patch.object(ui.time, 'monotonic', return_value=101):
            self.window.start_preset(bosses, mobs, mode)
        return link

    def select_field(self, name, value):
        index = self.window.cfg_field.findData(name)
        if index >= 0:
            self.window.cfg_field.setCurrentIndex(index)
        else:
            self.window.cfg_field.setEditText(name)
        self.window.cfg_value.setValue(value)

    def test_demo_page_can_be_browsed_offline_and_explains_recording(self):
        self.assertIn(5, self.window.page_nav)
        self.window.page_nav[5].click()
        self.assertEqual(self.window.stack.currentIndex(), 5)
        self.assertIsNone(self.window.link)
        labels = '\n'.join(w.text() for w in self.window.stack.widget(5).findChildren(QLabel))
        self.assertIn('演示与调参', labels)
        self.assertIn('游戏敌弹尺寸', labels)
        self.assertIn('它不是录像', labels)
        self.assertEqual(self.window.replay_buttons[0].text(), '6  录制新局')
        self.assertTrue(all(not b.isEnabled() for b in self.window.replay_buttons))

    def test_three_named_presets_are_present_on_both_pages(self):
        self.assertEqual(len(self.window.preset_buttons), 6)
        for index, expected in enumerate(('四 Boss ＋ 六妖精', '六 Boss ＋ 十二妖精', '三 Boss 基线')):
            for offset, page in ((0, 0), (3, 5)):
                b = self.window.preset_buttons[offset + index]
                self.assertIn(expected, b.text())
                self.assertTrue(self.window.stack.widget(page).isAncestorOf(b))
        self.window.show()
        self.app.processEvents()
        for page, buttons in ((0, self.window.preset_buttons[:3]), (5, self.window.preset_buttons[3:])):
            self.window.navigate(page)
            self.assertTrue(all(b.isVisible() for b in buttons))

    def test_home_preset_uses_selected_game_difficulty(self):
        link = self.ready()
        self.window.mode_choice.setCurrentIndex(self.window.mode_choice.findData(2))
        with patch.object(ui.time, 'monotonic', return_value=101):
            self.window.preset_buttons[0].click()
        self.assertIsInstance(self.window.game_sequence, ActionSequence)
        self.assertEqual(self.window.game_sequence.requested['mode'], 2)
        self.assertEqual(self.window.game_sequence.requested['boss_count'], 4)
        self.assertEqual(self.window.game_sequence.requested['enemy_count'], 6)
        self.assertEqual(link.actions[-2:], [('touhou_LAB', 'menu', True), ('touhou_LAB', 'menu', False)])

    def test_demo_preset_signal_uses_demo_difficulty(self):
        self.ready()
        self.window.demo_difficulty.setCurrentIndex(self.window.demo_difficulty.findData(1))
        with patch.object(ui.time, 'monotonic', return_value=101):
            self.window.preset_buttons[4].click()
        self.assertEqual(self.window.game_sequence.requested,
                         {'kind':'preset', 'boss_count':6, 'enemy_count':12, 'mode':1})

    def test_preset_requires_menu_two_set_acks_then_mode_ack(self):
        link = self.start_preset()
        sequence = self.window.game_sequence
        self.assertTrue(sequence.busy)
        self.assertEqual(link.sent, [])
        self.feed(link, 'OK set')  # unrelated setter ACK cannot replace menu.
        self.assertEqual(link.sent, [])
        self.feed(link, 'UI MENU')
        self.assertEqual(link.sent, [b':set boss_count 4\n'])
        self.assertEqual(sequence.applied, {})
        self.feed(link, 'OK set')
        self.assertEqual(link.sent[-1], b':set enemy_count 6\n')
        self.assertEqual(sequence.applied, {'boss_count':4})
        self.feed(link, 'OK set')
        self.assertEqual(link.sent[-1], b':mode 0\n')
        self.assertTrue(sequence.busy)
        self.assertEqual(sequence.applied, {'boss_count':4, 'enemy_count':6})
        self.feed(link, 'OK mode 1')
        self.assertTrue(sequence.busy)
        self.feed(link, 'OK mode 0')
        self.assertFalse(sequence.busy)
        self.assertIn('已由板端确认', self.window.footer.text())

    def test_busy_preset_excludes_all_manual_inputs_lab_and_download(self):
        link = self.start_preset()
        initial_sent = list(link.sent)
        initial_actions = list(link.actions)
        self.assertTrue(self.disabled())
        self.assertFalse(self.window.lab.available)
        self.assertFalse(self.window.download_button.isEnabled())
        self.assertFalse(self.window.check_button.isEnabled())
        self.assertTrue(all(not b.isEnabled() for b in self.window.preset_buttons))
        self.assertTrue(all(not b.isEnabled() for b in self.window.replay_buttons))
        with patch.object(ui.time, 'monotonic', return_value=101):
            self.window.action('start', True)
            self.window.start_mode()
            self.window.start_pressure()
            self.window.start_preset(6, 12, 2)
            self.window.apply_config()
            self.window.replay_action('record')
            self.window.run_job(False)
            self.window.run_job(True)
            self.assertFalse(self.window.lab.request('enter'))
            self.window.lab_send(99, 'enter', [])
        self.assertEqual(link.sent, initial_sent)
        self.assertEqual(link.actions, initial_actions)
        self.assertIsNone(self.window.job)

    def test_error_cancels_sequence_without_continuing_on_late_ack(self):
        link = self.start_preset()
        self.feed(link, 'UI MENU', 'OK set')
        self.assertEqual(link.sent, [b':set boss_count 4\n', b':set enemy_count 6\n'])
        self.feed(link, 'ERR invalid field/value; unchanged')
        self.assertFalse(self.window.game_sequence.busy)
        self.assertFalse(link.closed)  # Explicit negative ACK keeps ownership unambiguous.
        self.assertIs(self.window.link, link)
        self.assertTrue(self.window.protocol_ready)
        self.assertEqual(self.window.game_sequence.applied, {'boss_count':4})
        self.assertIn('未完成', self.window.footer.text())
        before = list(link.sent)
        self.feed(link, 'OK set', 'OK mode 0')
        self.assertEqual(link.sent, before)
        self.select_field('boss_fire_num[2]', 2)
        with patch.object(ui.time, 'monotonic', return_value=102):
            self.window.apply_config()
        self.assertEqual(link.sent[-1], b':set boss_fire_num[2] 2\n')
        self.assertTrue(self.window.game_sequence.busy)

    def test_timeout_revokes_capabilities_and_blocks_next_setter(self):
        link = self.ready()
        clock = [0.]
        self.window.game_sequence.clock = lambda: clock[0]
        self.select_field('boss_fire_num[2]', 2)
        with patch.object(ui.time, 'monotonic', return_value=101):
            self.window.apply_config()
        self.assertEqual(link.sent, [b':set boss_fire_num[2] 2\n'])
        clock[0] = 5.
        self.assertTrue(self.window.game_sequence.tick())
        self.assertTrue(link.closed)
        self.assertIsNone(self.window.link)
        self.assertFalse(self.window.protocol_ready)
        self.assertFalse(self.window.game_sequence.busy)
        self.assertTrue(self.disabled())
        self.assertFalse(self.window.game_sequence.feed('OK set'))
        with patch.object(ui.time, 'monotonic', return_value=102):
            self.window.apply_config()
        self.assertEqual(link.sent, [b':set boss_fire_num[2] 2\n'])
        self.assertIn('重新连接', self.window.footer.text())

    def test_write_error_revokes_capabilities_and_blocks_next_setter(self):
        link = self.ready()
        self.select_field('boss_fire_num[2]', 2)
        with patch.object(ui.time, 'monotonic', return_value=101), patch.object(link, 'send', side_effect=OSError('simulated short write')) as send:
            self.window.apply_config()
            send.assert_called_once_with(b':set boss_fire_num[2] 2\n')
        self.assertTrue(link.closed)
        self.assertIsNone(self.window.link)
        self.assertFalse(self.window.protocol_ready)
        self.assertFalse(self.window.game_sequence.busy)
        self.assertTrue(self.disabled())
        self.assertFalse(self.window.game_sequence.feed('OK set'))
        with patch.object(ui.time, 'monotonic', return_value=102):
            self.window.apply_config()
        self.assertEqual(link.sent, [])

    def test_disconnect_cancels_sequence_and_late_results_cannot_resume_it(self):
        link = self.start_preset()
        self.feed(link, 'UI MENU')
        before = list(link.sent)
        self.window.disconnect()
        self.assertFalse(self.window.game_sequence.busy)
        self.assertTrue(link.closed)
        self.window.game_sequence.feed('OK set')
        self.window.game_sequence.feed('OK mode 0')
        self.assertEqual(link.sent, before)
        self.assertFalse(self.window.protocol_ready)

    def test_enemy_count_five_is_acknowledged_config_not_a_batch_send(self):
        link = self.ready()
        self.select_field('enemy_count', 5)
        with patch.object(ui.time, 'monotonic', return_value=101):
            self.window.cfg_button.click()
        self.assertTrue(self.window.game_sequence.busy)
        self.assertEqual(link.sent, [])
        self.feed(link, 'UI MENU')
        self.assertEqual(link.sent, [b':set enemy_count 5\n'])
        self.assertTrue(self.window.game_sequence.busy)
        self.feed(link, 'OK set')
        self.assertFalse(self.window.game_sequence.busy)
        self.assertEqual(self.window.game_sequence.applied, {'enemy_count':5})
        self.assertNotIn(b':mode 0\n', link.sent)  # config does not restart game implicitly.

    def test_editable_array_field_uses_validated_action_sequence(self):
        link = self.ready()
        self.window.cfg_field.setEditText('boss_fire_num[2]')
        self.window.cfg_value.setValue(2)
        with patch.object(ui.time, 'monotonic', return_value=101):
            self.window.apply_config()
        self.assertEqual(link.sent, [b':set boss_fire_num[2] 2\n'])
        self.assertTrue(self.window.game_sequence.busy)
        self.feed(link, 'OK set')
        self.assertEqual(self.window.game_sequence.applied, {'boss_fire_num[2]':2})
        self.assertFalse(self.window.game_sequence.busy)

    def test_all_115_writable_fields_and_exact_ranges_are_exposed(self):
        writable = {spec.name:spec for spec in CONFIG_FIELDS if spec.writable}
        shown = {self.window.cfg_field.itemData(i) for i in range(self.window.cfg_field.count())}
        self.assertEqual(len(shown), 115)
        self.assertIn('hud_dma_tail_enabled', shown)
        self.assertEqual(len(shown - {'hud_dma_tail_enabled'}), 114)
        self.assertEqual(shown, set(writable))
        for name, spec in writable.items():
            with self.subTest(field=name):
                self.window.cfg_field.setCurrentIndex(self.window.cfg_field.findData(name))
                self.assertEqual(self.window.selected_config_field(), name)
                self.assertEqual((self.window.cfg_value.minimum(), self.window.cfg_value.maximum()),
                                 (spec.minimum, spec.maximum))
        self.select_field('layer_visuals_strength', 0)
        self.assertEqual((self.window.cfg_value.minimum(), self.window.cfg_value.maximum()), (1, 2))
        self.assertEqual(self.window.cfg_value.value(), 1)

    def test_record_name_seed_and_invalid_seed(self):
        link = self.ready()
        self.window.replay_seed.setText('0x123')
        with patch.object(ui.time, 'monotonic', return_value=101):
            self.window.replay_buttons[0].click()
        self.assertEqual(link.sent, [b':record 291\n'])
        self.window.replay_seed.setText('4294967296')
        with patch.object(ui.time, 'monotonic', return_value=101), patch.object(QMessageBox,'information',return_value=QMessageBox.Ok) as notice:
            self.window.replay_action('record')
            self.assertEqual(notice.call_count, 1)
            self.window.replay_action('stop')
            self.window.replay_action('status')
            self.assertEqual(notice.call_count, 1)  # Only record validates the seed.
        self.assertEqual(link.sent, [b':record 291\n', b':stop\n', b':replay status\n'])
        self.window.replay_seed.clear()
        with patch.object(ui.time, 'monotonic', return_value=101):
            self.window.replay_action('record')
        self.assertEqual(link.sent[-1], b':record\n')

    def test_fixed_download_panel_stays_visible_across_every_page(self):
        panel = self.window.download_panel
        self.assertFalse(self.window.stack.isAncestorOf(panel))
        self.assertIs(self.window.job_progress, panel.bar)
        self.assertIs(self.window.job_label, panel.detail)
        self.window.show()
        panel.reset()
        panel.show()
        self.app.processEvents()
        for page in (0, 1, 2, 3, 4, 5, 0):
            self.window.navigate(page)
            self.app.processEvents()
            self.assertTrue(panel.isVisible(), f'page {page}')
            self.assertFalse(self.window.stack.widget(page).isAncestorOf(panel))

    def test_main_progress_bridge_shows_real_count_and_neutral_wait(self):
        panel = self.window.download_panel
        with patch.object(download_panel.time, 'monotonic', return_value=100):
            panel.reset()
            self.window.show_download_progress('PROGRESS '+json.dumps(dict(stage='verify',step=4,state='running',done=65536,total=188818,unit='bytes')))
        self.assertEqual(panel.percent.text(), '34.7%')
        self.assertEqual((panel.bar.value(),panel.bar.maximum()), (65536,188818))
        self.assertIn('65,536 / 188,818', panel.detail.text())
        with patch.object(download_panel.time, 'monotonic', return_value=109):
            panel._tick()
        self.assertIn('一段时间未收到新消息', panel.activity.text())
        self.assertTrue(panel.running)
        self.assertIsNone(panel.success)
        self.assertEqual(panel.bar.value(), 65536)

    def test_plain_tool_log_refreshes_activity_and_failure_keeps_phase_not_100(self):
        class FakeJob:
            chunk = b'ordinary tool output\n'
            deleted = False
            def readAllStandardOutput(self):
                chunk,self.chunk=self.chunk,b''
                return chunk
            def deleteLater(self): self.deleted=True
        panel = self.window.download_panel
        with patch.object(download_panel.time, 'monotonic', return_value=100):
            panel.reset()
            self.window.show_download_progress('PROGRESS '+json.dumps(dict(stage='verify',step=4,state='running',done=188818,total=188818,unit='bytes')))
        job = FakeJob()
        self.window.job = job
        self.window.decoder = codecs.getincrementaldecoder('utf-8')('replace')
        self.window.pending = ''
        with patch.object(download_panel.time, 'monotonic', return_value=111):
            self.window.read_job()
        self.assertIn('最后消息 0 秒前',panel.activity.text())
        self.assertIn('ordinary tool output', self.window.log_view.toPlainText())
        self.assertEqual(panel.percent.text(), '100.0%')  # stage count, not final result.
        self.window.job_finished(1, object())
        self.assertTrue(job.deleted)
        self.assertIsNone(self.window.job)
        self.assertFalse(panel.running)
        self.assertFalse(panel.success)
        self.assertEqual(panel.percent.text(), '未完成')
        self.assertIn('阶段 4/5 未完成', panel.phase.text())
        self.assertEqual(panel.bar.value(), 0)
        self.assertEqual(self.window.stack.currentIndex(), 1)


if __name__ == '__main__':
    unittest.main()
