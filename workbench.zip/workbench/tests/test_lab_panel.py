"""Actual Qt widgets exercised offline; no device API is imported or called."""
import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from pathlib import Path
import random
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
try:
    from PySide6.QtWidgets import QApplication
except ImportError as exc:
    raise unittest.SkipTest("PySide6 runtime required for headless LabPanel tests") from exc

import lab_panel as lab


def done(request, status="PASS", errors=0, **extra):
    request_id, operation, args = request
    result = dict(kind="LAB_DONE", id=request_id, op=operation, status=status,
                  errors=errors, us=250, hw_cycles=900, width=1280, height=720,
                  refresh=60, active=0 if operation == "exit" else 1)
    result.update(extra)
    return result


class PreviewTests(unittest.TestCase):
    @staticmethod
    def rgb(image, x, y):
        return image.pixelColor(x, y).rgb() & 0xFFFFFF

    def test_fill_fresh_background_and_exact_edges(self):
        image = lab.preview_image("fill", [10, 20, 100, 50, 0x123456])
        self.assertEqual((image.width(), image.height()), (1280, 720))
        for x, y, color in ((10, 20, 0x123456), (109, 69, 0x123456),
                            (9, 20, 0xF4F6FA), (110, 69, 0xF4F6FA),
                            (10, 70, 0xF4F6FA), (1279, 719, 0xF4F6FA)):
            self.assertEqual(self.rgb(image, x, y), color)

    def test_copy_crop_is_anchored_in_source_coordinates(self):
        for tile in (0, 1):
            image = lab.preview_image("copy", [tile, 7, 9, 30, 31, 100, 120])
            for x, y in ((0, 0), (1, 0), (12, 23), (29, 30)):
                index = ((7 + x) // 8 + ((9 + y) // 8 if tile == 0 else 0)) % 4
                self.assertEqual(self.rgb(image, 100 + x, 120 + y), lab.TILE_COLORS[index])
            self.assertEqual(self.rgb(image, 99, 120), lab.BASE)
            self.assertEqual(self.rgb(image, 130, 150), lab.BASE)

    def test_patterns_match_independent_per_pixel_reference(self):
        rng = random.Random(451)
        points = [(0, 0), (1, 1), (2, 2), (3, 3), (4, 4), (1279, 719),
                  (640, 360), (640, 99), (99, 360), (12, 12), (1252, 12),
                  (12, 692), (1252, 692), (27, 27), (28, 28), (40, 41)]
        points += [(rng.randrange(1280), rng.randrange(720)) for _ in range(500)]
        for kind in (0, 1, 2):
            image = lab.preview_image("pattern", [kind])
            for x, y in points:
                edge = 4 if kind == 2 else 2
                if x < edge or y < edge or x >= 1280 - edge or y >= 720 - edge:
                    expected = 0x40444F
                elif kind == 0:
                    expected = 0xD4D8E2 if x % 40 == 0 or y % 40 == 0 else 0xF4F6FA
                elif kind == 1:
                    expected = lab.BAR_COLORS[x // 160]
                else:
                    expected = 0x4C8DFF if x == 640 or y == 360 else 0xFFFFFF
                    for (left, top), color in zip(((12, 12), (1252, 12), (12, 692), (1252, 692)), lab.TILE_COLORS):
                        if left <= x < left + 16 and top <= y < top + 16:
                            expected = color
                self.assertEqual(self.rgb(image, x, y), expected, (kind, x, y))


class LabPanelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication(["lab-panel-offline-tests"])

    def setUp(self):
        self.panel = lab.LabPanel()
        self.commands = []
        self.changes = []
        self.panel.command_requested.connect(lambda i, op, args: self.commands.append((i, op, args)))
        self.panel.state_changed.connect(lambda: self.changes.append((self.panel.active, self.panel.pending)))
        self.addCleanup(self.panel.deleteLater)

    def enter(self):
        self.panel.set_available(True)
        self.assertTrue(self.panel.request("enter"))
        self.panel.ingest(done(self.commands[-1]))
        self.assertTrue(self.panel.active)

    def test_initial_state_and_navigation_are_hardware_free(self):
        self.assertFalse(self.panel.active)
        self.assertFalse(self.panel.pending)
        self.assertFalse(self.panel.enter_button.isEnabled())
        self.assertFalse(self.panel.request("enter"))
        self.panel.operation.setCurrentIndex(1)
        self.panel.operation.setCurrentIndex(2)
        self.assertEqual(self.commands, [])
        self.panel.set_available(True)
        self.assertTrue(self.panel.enter_button.isEnabled())
        self.assertFalse(self.panel.execute_button.isEnabled())

    def test_ack_does_not_complete_or_activate(self):
        self.panel.set_available(True)
        self.panel.enter_button.click()
        request_id, op, args = self.commands[-1]
        self.panel.ingest(dict(kind="LAB_ACK", id=request_id, op=op, status="QUEUED"))
        self.assertTrue(self.panel.pending)
        self.assertFalse(self.panel.active)
        self.assertFalse(self.panel.enter_button.isEnabled())
        self.assertIn("排队", self.panel.status.text())
        self.assertEqual(self.panel.results, [])

    def test_only_current_id_and_operation_complete(self):
        self.panel.set_available(True); self.panel.request("enter")
        reply = done(self.commands[-1])
        self.panel.ingest(dict(reply, id=reply["id"] + 1))
        self.panel.ingest(dict(reply, op="fill"))
        self.assertTrue(self.panel.pending)
        self.panel.ingest(reply)
        self.assertFalse(self.panel.pending); self.assertTrue(self.panel.active)
        self.assertTrue(self.panel.results[-1]["accepted_pass"])
        self.assertTrue(self.panel.execute_button.isEnabled())
        self.assertIn((True, False), self.changes)

    def test_parameters_validate_before_emission_and_preview_updates_locally(self):
        self.enter()
        before = len(self.commands)
        self.panel.fill_fields["x"].setValue(1279)
        self.panel.fill_fields["w"].setValue(2)
        self.assertFalse(self.panel.execute_button.isEnabled())
        self.panel.execute()
        self.assertEqual(len(self.commands), before)
        self.panel.fill_fields["w"].setValue(1)
        self.panel.fill_color.setText("#FF1100")
        self.assertTrue(self.panel.execute_button.isEnabled())
        self.panel.execute_button.click()
        self.assertEqual(self.commands[-1][1:], ("fill", [1279, 140, 1, 280, 0xFF1100]))
        self.assertTrue(self.panel.pending)
        self.assertFalse(self.panel.forms.isEnabled())

    def test_error_and_nonzero_errors_are_never_pass(self):
        self.enter()
        for status, errors in (("ERROR", 0), ("PASS", 3)):
            self.panel.request("clear")
            self.panel.ingest(done(self.commands[-1], status=status, errors=errors, code="VERIFY"))
            self.assertFalse(self.panel.results[-1]["accepted_pass"])
            self.assertIn("失败", self.panel.status.text())

    def test_exit_requires_active_zero(self):
        self.enter(); self.panel.request("exit")
        self.panel.ingest(done(self.commands[-1], active=1))
        self.assertTrue(self.panel.active)
        self.assertFalse(self.panel.results[-1]["accepted_pass"])
        self.panel.request("exit"); self.panel.ingest(done(self.commands[-1]))
        self.assertFalse(self.panel.active)

    def test_reconnect_enter_error_recovers_actual_active_and_allows_exit(self):
        self.panel.set_available(True)
        self.panel.request("enter")
        self.panel.ingest(done(self.commands[-1], status="ERROR", code="MODE", active=1))
        self.assertTrue(self.panel.active)
        self.assertFalse(self.panel.results[-1]["accepted_pass"])
        self.assertTrue(self.panel.exit_button.isEnabled())
        self.panel.request("exit")
        self.panel.ingest(done(self.commands[-1], status="ERROR", code="RESTORE", active=1))
        self.assertTrue(self.panel.active)
        self.assertFalse(self.panel.results[-1]["accepted_pass"])
        self.panel.request("exit"); self.panel.ingest(done(self.commands[-1]))
        self.assertFalse(self.panel.active)

    def test_timeout_rejects_late_done_and_new_request_id_increases(self):
        self.panel.set_available(True)
        with patch.object(lab.time, "monotonic", return_value=100):
            self.panel.request("enter")
        first = self.commands[-1]
        with patch.object(lab.time, "monotonic", return_value=131):
            self.panel.tick()
        self.assertFalse(self.panel.pending); self.assertFalse(self.panel.active)
        self.assertEqual(self.panel.results[-1]["status"], "TIMEOUT")
        self.panel.ingest(done(first)); self.assertFalse(self.panel.active)
        self.panel.request("enter")
        self.assertGreater(self.commands[-1][0], first[0])
        self.panel.ingest(done(first)); self.assertTrue(self.panel.pending)

    def test_verify_cases_and_180_second_timeout(self):
        self.enter()
        with patch.object(lab.time, "monotonic", return_value=100):
            self.panel.request("verify")
        request_id = self.commands[-1][0]
        with patch.object(lab.time, "monotonic", return_value=140):
            self.panel.ingest(dict(kind="LAB_CASE", id=request_id, case="fill", status="FAIL", errors=1, code="VERIFY"))
        self.assertTrue(self.panel.pending)
        with patch.object(lab.time, "monotonic", return_value=150):
            self.panel.ingest(done(self.commands[-1], passed=6, failed=0))
        self.assertFalse(self.panel.results[-1]["accepted_pass"])
        with patch.object(lab.time, "monotonic", return_value=200):
            self.panel.request("verify")
        with patch.object(lab.time, "monotonic", return_value=379):
            self.panel.tick()
        self.assertTrue(self.panel.pending)
        with patch.object(lab.time, "monotonic", return_value=380):
            self.panel.tick()
        self.assertFalse(self.panel.pending)

    def test_verify_requires_all_nine_unique_cases_and_matching_summary(self):
        self.enter()
        # A truncated serial transcript may contain a PASS summary, but is not proof.
        self.panel.request("verify")
        self.panel.ingest(done(self.commands[-1], passed=9, failed=0))
        self.assertFalse(self.panel.results[-1]["accepted_pass"])
        self.panel.request("verify")
        current = self.commands[-1]
        for name in sorted(lab.VERIFY_CASES):
            self.panel.ingest(dict(kind="LAB_CASE", id=current[0], case=name, status="PASS", errors=0))
        self.panel.ingest(done(current, passed=9, failed=0))
        self.assertTrue(self.panel.results[-1]["accepted_pass"])
        # Duplicate case lines cannot substitute for missing cases.
        self.panel.request("verify"); current = self.commands[-1]
        for name in ["fill"] * 9:
            self.panel.ingest(dict(kind="LAB_CASE", id=current[0], case=name, status="PASS", errors=0))
        self.panel.ingest(done(current, passed=9, failed=0))
        self.assertFalse(self.panel.results[-1]["accepted_pass"])

    def test_demo_waits_for_done_then_800ms_and_stops_on_error(self):
        self.panel.set_available(True)
        with patch.object(lab.time, "monotonic", return_value=100):
            self.panel.start_demo()
        self.assertEqual(self.commands[-1][1], "enter")
        with patch.object(lab.time, "monotonic", return_value=101):
            self.panel.tick()
        self.assertEqual(len(self.commands), 1)
        with patch.object(lab.time, "monotonic", return_value=102):
            self.panel.ingest(done(self.commands[-1]))
        with patch.object(lab.time, "monotonic", return_value=102.79):
            self.panel.tick()
        self.assertEqual(len(self.commands), 1)
        with patch.object(lab.time, "monotonic", return_value=102.81):
            self.panel.tick()
        self.assertEqual(self.commands[-1][1], "clear")
        with patch.object(lab.time, "monotonic", return_value=103):
            self.panel.ingest(done(self.commands[-1], status="ERROR", code="ENGINE"))
        with patch.object(lab.time, "monotonic", return_value=110):
            self.panel.tick()
        self.assertEqual(len(self.commands), 2)
        self.assertFalse(self.panel._demo_running)

    def test_disconnect_cancels_pending_without_fake_exit_or_pass(self):
        self.enter(); self.panel.request("clear")
        self.panel.disconnected()
        self.assertFalse(self.panel.active); self.assertFalse(self.panel.pending)
        self.assertFalse(self.panel.available)
        self.assertEqual(self.panel.results[-1]["status"], "DISCONNECTED")
        self.assertFalse(self.panel.execute_button.isEnabled())
        self.assertIn("待重连", self.panel.status.text())

    def test_unavailable_only_disables_and_exports_existing_results(self):
        self.enter()
        self.panel.set_available(False)
        self.assertTrue(self.panel.active)
        self.assertFalse(self.panel.exit_button.isEnabled())
        self.assertFalse(self.panel.request("exit"))
        exported = []
        self.panel.export_requested.connect(lambda: exported.append(True))
        self.panel.export_button.click()
        self.assertEqual(exported, [True])

    def test_repeated_availability_refresh_preserves_last_verdict(self):
        self.enter()
        text = self.panel.status.text()
        self.assertIn("通过", text)
        for _ in range(20):
            self.panel.set_available(True)
        self.assertEqual(self.panel.status.text(), text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
