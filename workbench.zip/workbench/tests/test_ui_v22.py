"""UI2.2 persistent semantics with the hardware-free Qt base fixture."""
import json
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_ui as base
from PySide6.QtCore import QProcess
from PySide6.QtWidgets import QLabel, QMessageBox
import main as ui


class V22UIContracts(unittest.TestCase):
    setUpClass = classmethod(base.NativeUIContracts.setUpClass.__func__)
    setUp = base.NativeUIContracts.setUp
    dispose_window = base.NativeUIContracts.dispose_window
    connect_fake = base.NativeUIContracts.connect_fake
    poll = base.NativeUIContracts.poll
    ready = base.NativeUIContracts.ready
    disabled = base.NativeUIContracts.disabled

    def test_fixed_lab_flash_wording_has_no_temporary_loading_offer(self):
        labels = "\n".join(widget.text() for widget in self.window.findChildren(QLabel))
        self.assertEqual(self.window.download_button.text(), "完整烧录到 Flash")
        self.assertIn("GAME60_PIPELINE_5 · 固化版", self.window.version.itemText(0))
        self.assertIn("覆盖开机版本", labels)
        self.assertIn("场景切换不换固件", labels)
        self.assertNotIn("临时下载", labels)
        self.assertNotIn("保留原来的 Flash", labels)
        self.assertIn("断电启动待确认", self.window.flash_status.text())

    def test_preparing_marker_disables_program_but_keeps_offline_check(self):
        marker = self.bundle / "persistent_entry.json"
        values = json.loads(marker.read_text()); values["state"] = "PREPARING"
        marker.write_text(json.dumps(values)); self.window.update_controls()
        self.assertFalse(self.window.download_button.isEnabled())
        self.assertTrue(self.window.check_button.isEnabled())
        with patch.object(self.window, "save_settings", return_value=True), patch.object(QMessageBox, "warning") as message:
            self.window.run_job(False)
        message.assert_called_once()
        self.assertIsNone(self.window.job)

    def test_warm_boot_caps_and_stat_cannot_claim_cold_boot(self):
        before = self.window.flash_status.text()
        self.ready()
        self.assertEqual(self.window.flash_status.text(), before)
        self.assertIn("待确认", self.window.flash_status.text())

    def test_successful_program_exit_records_readback_but_cold_boot_pending(self):
        self.window.job = types.SimpleNamespace(deleteLater=lambda: None)
        self.window.job_check = False
        self.window.download_panel.reset(check=False)
        with patch.object(self.window, "read_job"), patch.object(self.window, "notify"):
            self.window.job_finished(0, ui.QProcess.NormalExit)
        self.assertIn("已写入并读回核对", self.window.flash_status.text())
        self.assertIn("断电启动待确认", self.window.flash_status.text())
        self.assertIn("断电启动待确认", self.window.download_panel.detail.text())

    def test_offline_check_never_sets_flash_or_cold_boot_pass(self):
        before = self.window.flash_status.text()
        self.window.job = types.SimpleNamespace(deleteLater=lambda: None)
        self.window.job_check = True; self.window.job_persistent_ready = False
        self.window.download_panel.reset(check=True)
        with patch.object(self.window, "read_job"), patch.object(self.window, "notify"):
            self.window.job_finished(0, ui.QProcess.NormalExit)
        self.assertEqual(self.window.flash_status.text(), before)
        self.assertIn("未执行 Flash 写入", self.window.download_panel.detail.text())
        self.assertIn("固化入口仍在准备", self.window.download_panel.detail.text())


if __name__ == "__main__": unittest.main(verbosity=2)
