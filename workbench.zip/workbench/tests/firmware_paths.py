"""Portable firmware inputs for hardware-free integration tests."""
from pathlib import Path
import os

def project_root():
    p=Path(os.environ.get("TI60_TEST_FIRMWARE_ROOT",Path(__file__).resolve().parents[2]/"release/projects/touhou_LAB"))
    if not (p/"src/game.c").is_file():raise FileNotFoundError("Set TI60_TEST_FIRMWARE_ROOT to the actual firmware project")
    return p.resolve()
