"""Opt-in application API test with real QProcess/board loader (not a unit test).

--run-hardware is required. Captures only this authored Qt window, not desktop.
"""
from pathlib import Path
import json,sys,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
if '--run-hardware' not in sys.argv:raise SystemExit('NOT_RUN: explicit --run-hardware required')
import bootstrap
bootstrap.prepare_runtime()
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
from PySide6.QtGui import QFont,QFontDatabase
import main
app=QApplication([]);app.setStyle('Fusion');QFontDatabase.addApplicationFont('C:/Windows/Fonts/msyh.ttc');app.setFont(QFont('Microsoft YaHei UI',10));app.setStyleSheet(main.STYLE)
w=main.MainWindow(smoke=True);w.setWindowTitle('赛题二工作台 · LAB1 上板验收');w.show()
out=ROOT/'evidence'/'live_download';out.mkdir(parents=True,exist_ok=True)
seen=False;shot_keys=set();started=time.monotonic();result=1
def observe():
    global seen,result
    if w.job is not None:seen=True
    current=w.download_progress._current
    if current:
        key=current['stage']+('_'+str(current['done']*4//current['total']) if 'total' in current else '')
        if key not in shot_keys:
            shot_keys.add(key);w.grab().save(str(out/(key+'.png')))
    if seen and w.job is None:
        passed=w.job_label.text().startswith('下载完成');result=0 if passed else 1
        w.grab().save(str(out/'finished.png'))
        report={'status':'PASS' if passed else 'FAIL','duration_s':time.monotonic()-started,'label':w.job_label.text(),'progress_value':w.job_progress.value(),'progress_maximum':w.job_progress.maximum(),'log':str(w.log_path),'screenshots':sorted(shot_keys)}
        (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False),flush=True);timer.stop();QTimer.singleShot(500,app.quit)
    elif time.monotonic()-started>800:
        print('GUI TEST TIMEOUT; loader still owns board, window retained',flush=True);timer.stop()
timer=QTimer();timer.timeout.connect(observe);timer.start(100)
QTimer.singleShot(300,lambda:w.run_job(False))
app.exec();raise SystemExit(result)
