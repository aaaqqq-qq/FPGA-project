"""Image byte fidelity and native Qt stop-and-wait flow. No devices/processes."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from pathlib import Path
import base64,json,struct,sys,tempfile,unittest,zlib
from dataclasses import replace
from unittest.mock import patch,Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtCore import QSize
from PySide6.QtGui import QImage,QColor
from PySide6.QtWidgets import QApplication
import image_assets as assets
from image_workflow import ImageWorkflow
import lab_panel as ui
from control_core import lab_command,parse_lab_reply

def image_file(path,w=10,h=20,alpha=False):
 image=QImage(w,h,QImage.Format_ARGB32 if alpha else QImage.Format_RGB32)
 for y in range(h):
  for x in range(w):image.setPixelColor(x,y,QColor((x*37)%256,(y*53)%256,((x+y)*17)%256,0 if alpha and x==0 else 128 if alpha else 255))
 if not image.save(str(path)):raise AssertionError('fixture image could not save')
 return path

def legacy_done(i,op):return dict(kind='LAB_DONE',id=i,op=op,status='PASS',errors=0,us=10,hw_cycles=20,width=1280,height=720,refresh=60,active=0 if op=='exit' else 1)

def image_done(i,op,wf,**overrides):
 p=wf.prepared;received=wf.waiting['received'] if wf.waiting else 0
 if op=='imgabort':fields=dict(session=wf.session,received=0,total=0,imgw=0,imgh=0,crc=0,ready=0,verified=0)
 else:fields=dict(session=wf.session,received=received,total=len(p.rgb),imgw=p.width,imgh=p.height,crc=zlib.crc32(p.rgb[:received])&0xffffffff,ready=int(op in ('imgcommit','imgcopy')),verified=921600 if op=='imgcopy' else 0)
 data=dict(legacy_done(i,op),**fields);data.update(overrides)
 # Exercise the real root-owned parser and wire field set, then allow faults
 # after parsing for widget/model defensive-validation tests.
 line='LAB_DONE '+' '.join('%s=%s'%(k,v) for k,v in data.items() if k!='kind')
 parsed=parse_lab_reply(line)
 if parsed is None:raise AssertionError('root parser rejected fixture: '+line)
 return parsed

class AssetTests(unittest.TestCase):
 def setUp(self):self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
 def test_scanline_padding_never_becomes_rgb_pixels(self):
  image=QImage(1,3,QImage.Format_RGB888)
  for y,rgb in enumerate(((1,2,3),(21,22,23),(201,202,203))):image.setPixelColor(0,y,QColor(*rgb))
  self.assertEqual(image.bytesPerLine(),4);self.assertEqual(assets.packed_rgb(image),bytes((1,2,3,21,22,23,201,202,203)))
 def test_prepared_rgb_crc_and_preview_are_identical_bytes(self):
  asset=assets.load_image(image_file(self.root/'奇步长.bmp',3,5));p=assets.prepare_image(asset,3,5)
  self.assertEqual(len(p.rgb),45);self.assertEqual(p.crc32,zlib.crc32(p.rgb)&0xffffffff)
  for y in range(5):
   for x in range(3):self.assertEqual(p.image.pixel(x,y)&0xffffff,int.from_bytes(p.rgb[(y*3+x)*3:(y*3+x+1)*3],'big'))
 def test_alpha_is_flattened_to_lab_background(self):
  asset=assets.load_image(image_file(self.root/'透明.png',3,2,True));p=assets.prepare_image(asset,3,2)
  self.assertTrue(asset.had_alpha);self.assertEqual(p.image.pixel(0,0)&0xffffff,assets.LAB_BACKGROUND);self.assertEqual(p.rgb[:3],bytes.fromhex('F4F6FA'));self.assertTrue(p.metadata()['alpha_flattened'])
 def test_default_long_edge256_preserves_ratio_and_does_not_upscale(self):
  large=assets.load_image(image_file(self.root/'large.png',400,200));small=assets.load_image(image_file(self.root/'small.png',3,2))
  self.assertEqual(assets.initial_size(large),(256,128));self.assertEqual(assets.initial_size(small),(3,2));self.assertEqual(assets.proportional_size(large,1280,1,'width'),(1280,640))
 def test_exif_orientation_is_applied_before_dimensions_and_resize(self):
  path=image_file(self.root/'orientation.jpg',2,3);raw=path.read_bytes()
  exif=b'Exif\0\0II'+struct.pack('<HIH',42,8,1)+struct.pack('<HHI',274,3,1)+struct.pack('<H',6)+b'\0\0'+struct.pack('<I',0)
  path.write_bytes(raw[:2]+b'\xff\xe1'+struct.pack('>H',len(exif)+2)+exif+raw[2:])
  asset=assets.load_image(path);self.assertEqual((asset.original_width,asset.original_height),(3,2))
 def test_bad_file_and_unsupported_content_are_rejected(self):
  for name,raw in (('bad.png',b'broken image'),('vector.png',b'<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"></svg>')):
   p=self.root/name;p.write_bytes(raw)
   with self.subTest(name=name),self.assertRaises(ValueError):assets.load_image(p)
 def test_decode_limit_is_checked_before_read(self):
  p=self.root/'huge.png';p.write_bytes(b'not decoded')
  reader=Mock();reader.format.return_value=b'png';reader.size.return_value=QSize(10000,10000)
  with patch.object(assets,'QImageReader',return_value=reader),self.assertRaisesRegex(ValueError,'3200'):assets.load_image(p)
  reader.read.assert_not_called();reader.setAutoTransform.assert_called_once_with(True)
 def test_oversize_file_rejected_before_decoder(self):
  p=self.root/'large.png'
  with p.open('wb') as f:f.truncate(assets.MAX_FILE_BYTES+1)
  with patch.object(assets,'QImageReader') as decoder,self.assertRaisesRegex(ValueError,'64'):assets.load_image(p)
  decoder.assert_not_called()
 def test_canvas_exact_edges_and_metadata_has_count_not_raw_pixels(self):
  p=assets.prepare_image(assets.load_image(image_file(self.root/'one.bmp',1,1)),1,1);canvas=assets.image_canvas(p,1279,719)
  self.assertEqual(canvas.pixel(1279,719)&0xffffff,p.image.pixel(0,0)&0xffffff);self.assertEqual(canvas.pixel(1278,719)&0xffffff,assets.LAB_BACKGROUND)
  with self.assertRaises(ValueError):assets.image_canvas(p,1280,719)
  self.assertEqual(p.metadata()['pixel_bytes'],3);json.dumps(p.metadata());self.assertNotIn('rgb',p.metadata())

class WorkflowTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
  self.p=assets.prepare_image(assets.load_image(image_file(self.root/'source.png')),10,20);self.w=ImageWorkflow(session_factory=lambda:123);self.i=1
 def command(self):
  cmd=self.w.next_command();self.assertIsNotNone(cmd);self.w.issued(self.i);self.i+=1;return cmd
 def complete(self):
  op=self.w.waiting['op'];r=image_done(self.w.waiting['id'],op,self.w);return self.w.receive(r)
 def run_all(self):
  commands=[]
  while self.w.busy:
   commands.append(self.command());self.complete()
  return commands
 def test_all_rgb_chunks_exact_bounded_and_independent_stop_wait(self):
  self.w.start(self.p,1,2);commands=self.run_all();self.assertEqual([x[0] for x in commands],['imgbegin','imgdata','imgdata','imgdata','imgcommit','imgcopy'])
  chunks=[base64.b64decode(a[2],validate=True) for op,a in commands if op=='imgdata'];self.assertEqual(list(map(len,chunks)),[288,288,24]);self.assertEqual(b''.join(chunks),self.p.rgb);self.assertTrue(self.w.last_summary['accepted_pass'])
 def test_ack_and_wrong_id_cannot_advance_a_step(self):
  self.w.start(self.p,0,0);op,args=self.command();before=dict(self.w.waiting)
  self.assertIsNone(self.w.receive(dict(kind='LAB_ACK',id=1,op=op,status='QUEUED')));self.assertIsNone(self.w.next_command());self.assertEqual(self.w.waiting,before)
  r=image_done(2,op,self.w);self.assertIsNone(self.w.receive(r));self.assertEqual(self.w.offset,0)
 def test_received_session_and_crc_mismatch_cannot_pass(self):
  for field,value in (('session',124),('received',3)):
   self.w=ImageWorkflow(session_factory=lambda:123);self.w.start(self.p,0,0);op,args=self.command();r=image_done(self.w.waiting['id'],op,self.w);r[field]=value;self.assertFalse(self.w.receive(r)['accepted_pass']);self.assertTrue(self.w.uncertain)
  self.w=ImageWorkflow(session_factory=lambda:123);self.w.start(self.p,0,0)
  while self.w.phase!='COMMIT':self.command();self.complete()
  self.command();r=image_done(self.w.waiting['id'],'imgcommit',self.w);r['crc']^=1;self.assertFalse(self.w.receive(r)['accepted_pass']);self.assertIsNone(self.w.cache)
 def test_only_real_copy921600_pixels_finishes_pass(self):
  self.w.start(self.p,0,0)
  while self.w.phase!='COPY':self.command();self.complete()
  self.assertIsNotNone(self.w.cache);self.assertIsNone(self.w.last_summary);self.command();r=image_done(self.w.waiting['id'],'imgcopy',self.w);r['verified']=0;self.assertFalse(self.w.receive(r)['accepted_pass']);self.assertFalse(self.w.last_summary['accepted_pass'])
 def test_changed_position_reuses_committed_but_new_size_does_not(self):
  self.w.start(self.p,0,0);self.run_all();self.w.start(self.p,100,200);op,args=self.command();self.assertEqual((op,args),('imgcopy',[123,100,200]));self.complete()
  new=assets.prepare_image(self.p.asset,5,10);self.w.start(new,0,0);self.assertEqual(self.command()[0],'imgbegin')
 def test_force_reupload_begins_new_transfer(self):
  self.w.start(self.p,0,0);self.run_all();self.w.start(self.p,0,0,force=True);self.assertEqual(self.command()[0],'imgbegin')
 def test_same_crc_different_rgb_can_never_reuse_cached_source(self):
  self.w.start(self.p,0,0);self.run_all()
  other=replace(self.p,rgb=bytes([self.p.rgb[0]^1])+self.p.rgb[1:])
  self.assertEqual(other.crc32,self.p.crc32);self.assertNotEqual(other.key,self.p.key)
  self.w.start(other,0,0);self.assertEqual(self.command()[0],'imgbegin')
 def test_status_cannot_relabel_old_source_as_new_same_crc_image(self):
  self.w.start(self.p,0,0);self.run_all();self.w.invalidate_cache()
  other=replace(self.p,rgb=bytes([self.p.rgb[0]^1])+self.p.rgb[1:])
  status=dict(legacy_done(999,'imgstatus'),session=123,received=600,total=600,imgw=10,imgh=20,crc=self.p.crc32,ready=1,verified=0)
  self.assertTrue(self.w.sync_status(status,other));self.assertIsNone(self.w.cache)
  self.w.start(other,0,0);self.assertEqual(self.command()[0],'imgbegin')
 def test_cancel_waits_inflight_done_then_abort_and_never_passes_flow(self):
  self.w.start(self.p,0,0);self.command();self.complete();self.command();self.w.cancel();self.assertIsNone(self.w.next_command());self.complete();self.assertEqual(self.w.phase,'ABORT');self.assertEqual(self.command()[0],'imgabort');self.complete();self.assertEqual(self.w.last_summary['status'],'CANCELLED');self.assertFalse(self.w.last_summary['accepted_pass'])
 def test_late_done_after_timeout_or_disconnect_is_not_success(self):
  self.w.start(self.p,0,0);self.command();late=image_done(self.w.waiting['id'],'imgbegin',self.w);self.w.fail('timeout','TIMEOUT');self.assertIsNone(self.w.receive(late));self.assertFalse(self.w.last_summary['accepted_pass']);self.w.disconnected();self.assertIsNone(self.w.cache)
 def test_timeout_forbids_abort_until_actual_nonbusy_status_pass(self):
  self.w.start(self.p,0,0);self.command();self.w.fail('timeout','TIMEOUT');self.assertFalse(self.w.cancel());self.assertTrue(self.w.status_required)
  status=dict(legacy_done(99,'imgstatus'),session=123,received=0,total=600,imgw=10,imgh=20,crc=0,ready=0,verified=0)
  self.assertFalse(self.w.sync_status(dict(status,status='ERROR',code='BUSY')));self.assertTrue(self.w.status_required)
  self.assertTrue(self.w.sync_status(status));self.assertTrue(self.w.cancel());self.assertEqual(self.command()[0],'imgabort')

class ImagePanelTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.app=QApplication.instance() or QApplication(['image-import-tests'])
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.path=image_file(Path(self.temp.name)/'上传样图.bmp');self.panel=ui.LabPanel();self.sent=[];self.changes=[]
  self.panel.command_requested.connect(lambda i,o,a:self.sent.append((i,o,a)));self.panel.state_changed.connect(lambda:self.changes.append((self.panel.active,self.panel.pending)));self.addCleanup(self.dispose)
 def dispose(self):self.panel.disconnected();self.panel.deleteLater();self.app.processEvents()
 def select_image(self):self.panel.operation.setCurrentIndex(1);self.panel.tile.setCurrentIndex(2);self.assertTrue(self.panel.import_image(self.path))
 def ready(self):
  self.panel.set_capabilities(dict(fw='LAB23',img=1));self.panel.set_available(True);self.panel.request('enter');i,o,a=self.sent[-1];self.panel.ingest(legacy_done(i,o));self.select_image()
 def reply_current(self):
  i,op,args=self.sent[-1];self.panel.ingest(image_done(i,op,self.panel.image_workflow))
 def run_all(self):
  limit=100
  while self.panel.image_workflow.busy:
   limit-=1;self.assertGreater(limit,0);self.panel.tick();self.reply_current()
 def test_old_caps_still_allow_offline_import_but_never_upload(self):
  self.select_image();self.assertTrue(self.panel.import_button.isEnabled());self.assertFalse(self.panel.execute_button.isEnabled());self.assertFalse(self.panel.start_image_upload());self.assertEqual(self.sent,[])
 def test_file_dialog_is_filtered_and_imports_without_device(self):
  self.panel.operation.setCurrentIndex(1);self.panel.tile.setCurrentIndex(2)
  with patch.object(ui.QFileDialog,'getOpenFileName',return_value=(str(self.path),'images')) as choose:self.panel.import_button.click()
  self.assertIsNotNone(self.panel.prepared_image);self.assertIn('*.png',choose.call_args.args[-1]);self.assertEqual(self.sent,[])
 def test_upload_holds_pending_between_every_chunk_and_exports_no_pixels(self):
  self.ready();self.changes=[];self.assertTrue(self.panel.start_image_upload());self.assertTrue(self.panel.pending);self.run_all()
  self.assertTrue(all(pending for active,pending in self.changes[:-1]));self.assertFalse(self.panel.pending);self.assertTrue(self.panel.active);self.assertTrue(self.panel.results[-1]['accepted_pass']);json.dumps(self.panel.results)
  self.assertEqual(self.panel.image_progress.value(),600);self.assertEqual(self.panel.results[-1]['image']['pixel_bytes'],600);self.assertNotIn('rgb',self.panel.results[-1]['image'])
 def test_ack_does_not_change_real_progress_or_send_another_chunk(self):
  self.ready();self.panel.start_image_upload();self.panel.tick();i,op,a=self.sent[-1];n=len(self.sent);self.panel.ingest(dict(kind='LAB_ACK',id=i,op=op,status='QUEUED'));self.panel.tick();self.assertEqual(len(self.sent),n);self.assertEqual(self.panel.image_progress.value(),0);self.assertTrue(self.panel.pending)
 def test_position_reuses_source_size_change_invalidates_upload_cache(self):
  self.ready();self.panel.start_image_upload();self.run_all();self.panel.image_x.setValue(1);self.assertIn('尚未执行',self.panel.image_validation.text());self.panel.start_image_upload();self.panel.tick();self.assertEqual(self.sent[-1][1],'imgcopy');self.reply_current()
  self.panel.image_width.setValue(5);self.assertIsNone(self.panel.image_workflow.cache);self.panel.start_image_upload();self.panel.tick();self.assertEqual(self.sent[-1][1],'imgbegin')
 def test_cancel_does_not_send_abort_until_original_step_done(self):
  self.ready();self.panel.start_image_upload();self.panel.tick();n=len(self.sent);self.panel.cancel_image();self.panel.tick();self.assertEqual(len(self.sent),n);self.reply_current();self.assertTrue(self.panel.pending);self.panel.tick();self.assertEqual(self.sent[-1][1],'imgabort');self.reply_current();self.assertFalse(self.panel.pending);self.assertEqual(self.panel.results[-1]['status'],'CANCELLED');self.assertFalse(self.panel.results[-1]['accepted_pass'])
 def test_timeout_late_reply_and_reconnect_never_reuse_success(self):
  self.ready();self.panel.start_image_upload();self.panel.tick();i,op,a=self.sent[-1];late=image_done(i,op,self.panel.image_workflow)
  with patch.object(ui.time,'monotonic',return_value=self.panel.tracker.deadline+1):self.panel.tick()
  self.assertTrue(self.panel.image_workflow.uncertain);self.assertFalse(self.panel.results[-1]['accepted_pass']);self.panel.ingest(late);self.assertFalse(self.panel.results[-1]['accepted_pass'])
  self.panel.disconnected();self.assertFalse(self.panel.img_capable);self.assertIsNotNone(self.panel.prepared_image);self.assertIn('未确认',self.panel.image_validation.text())
 def test_proportions_and_xy_bounds_follow_prepared_dimensions(self):
  self.select_image();self.panel.image_width.setValue(1280);self.assertEqual((self.panel.image_width.value(),self.panel.image_height.value()),(360,720));self.assertEqual(self.panel.image_x.maximum(),920);self.assertEqual(self.panel.image_y.maximum(),0)
  self.panel.image_aspect.setChecked(False);self.panel.image_width.setValue(1280);self.assertEqual(self.panel.image_x.maximum(),0);self.panel.center_image();self.assertEqual(self.panel.image_x.value(),0)
 def test_status_has_to_report_actual_state_before_changing_active(self):
  self.ready();self.panel.request('imgstatus');i,op,a=self.sent[-1];r=dict(legacy_done(i,op),session=0,received=0,total=0,imgw=0,imgh=0,crc=0,ready=0,verified=0,active=0);self.panel.ingest(r);self.assertFalse(self.panel.active);self.assertFalse(self.panel.execute_button.isEnabled());self.assertIsNone(self.panel.image_workflow.cache)
 def test_timeout_cancel_first_reads_status_busy_cannot_dispatch_abort(self):
  self.ready();self.panel.start_image_upload();self.panel.tick()
  with patch.object(ui.time,'monotonic',return_value=self.panel.tracker.deadline+1):self.panel.tick()
  self.assertFalse(self.panel.request('exit'));self.panel.cancel_image();i,op,a=self.sent[-1];self.assertEqual(op,'imgstatus')
  self.panel.ingest(image_done(i,op,self.panel.image_workflow,status='ERROR',code='BUSY'));self.panel.tick();self.assertEqual(self.sent[-1][1],'imgstatus');self.assertTrue(self.panel.image_workflow.status_required)
  self.panel.cancel_image();i,op,a=self.sent[-1];self.panel.ingest(image_done(i,op,self.panel.image_workflow));self.assertTrue(self.panel.pending);self.panel.tick();self.assertEqual(self.sent[-1][1],'imgabort');self.reply_current();self.assertEqual(self.panel.results[-1]['status'],'CANCELLED')
 def test_image_source_selector_remains_visible_and_can_return_to_builtins(self):
  self.select_image();self.panel.show();self.app.processEvents();self.assertTrue(self.panel.tile.isVisible());self.panel.tile.setCurrentIndex(0);self.app.processEvents();self.assertTrue(self.panel.copy_fields['sx'].isVisible());self.assertFalse(self.panel.image_controls.isVisible())

if __name__=='__main__':unittest.main()
