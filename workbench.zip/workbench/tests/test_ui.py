"""Real Qt GUI contracts, fake serial only; all device/process access forbidden.
Run with the control-center runtime and QT_QPA_PLATFORM=offscreen.
"""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
from pathlib import Path
import sys, tempfile, unittest
from unittest.mock import patch
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
try:
    from PySide6.QtCore import Qt, QEvent
    from PySide6.QtGui import QCloseEvent, QKeyEvent
    from PySide6.QtWidgets import QApplication, QMessageBox, QLabel, QLineEdit
except ImportError as exc:
    raise unittest.SkipTest('PySide6 runtime required for actual GUI tests') from exc
import main as ui
from control_core import Settings

CAPS = 'CAPS fw=LAB1 proto=2 controls=PC lab=1 width=1280 height=720 hz=60'
R8 = ('STAT mode=1 hw=1 N=636 fps100=5992 swaps=120 scan=122 us=2000000 '
      'frame=8900 missed=2 uf=0 render=8500 logic=400 vstr=2 h_pk=1200')
LAB = R8 + ' fw=LAB1 paused=0 control=PC'
R7 = ('STAT mode=2 hw=1 N=20000 fps100=6000 swaps=120 scan=120 us=2000000 '
      'frame=12000 missed=0 uf=0 render=11000 logic=1000 vstr=2')
MARIO = 'PERF,12,MARIO,GAME,0,2,1000000,12,60,88999,48,0,60,0,0,0,1000,2000,0'

class FakeLink:
    def __init__(self, lines=()):
        self.lines=list(lines);self.is_open=True;self.port='COM99'
        self.releases=self.heartbeats=0;self.closed=False
        self.actions=[];self.sent=[];self.accepted=[];self.held=set()
    def open(self, port): self.port=port;self.is_open=True
    def accept_capabilities(self, values):
        self.accepted.append(values)
        return bool(values and values.get('fw')=='LAB1' and values.get('proto')==2)
    def read_lines(self):
        lines,self.lines=self.lines,[]
        return lines
    def heartbeat(self): self.heartbeats+=1
    def release_all(self): self.releases+=1;self.held.clear()
    def set_action(self, profile, name, pressed):
        self.actions.append((profile,name,pressed))
        if pressed:self.held.add(name)
        else:self.held.discard(name)
        return True
    def send(self, payload): self.sent.append(payload)
    def close(self): self.closed=True;self.is_open=False

class NativeUIContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication(['board-studio-tests'])
        cls.app.setStyle('Fusion')
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.tmp_root=Path(self.tmp.name);self.bundle=self.tmp_root/'bundle';self.bundle.mkdir()
        (self.bundle/'START_MENU.py').write_text('# full flash fake entry')
        (self.bundle/'tools').mkdir();(self.bundle/'tools/local_paths.json').write_text('{}')
        (self.bundle/'projects/touhou_LAB').mkdir(parents=True)
        import json
        (self.bundle/'persistent_entry.json').write_text(json.dumps({'firmware':'LAB23','kind':'full_flash','state':'READY','ram_fallback_allowed':False}))
        self.settings=Settings(bundle_root=str(self.bundle),port='COM99',notifications=False)
        def local_data(create=False):
            d=self.tmp_root/'appdata'
            if create:d.mkdir(exist_ok=True)
            return d
        forbidden=AssertionError('Real device/process/application access forbidden in GUI tests')
        patches=[patch.object(ui.Settings,'load',return_value=self.settings),
            patch.object(ui,'app_data_dir',side_effect=local_data),
            patch.object(ui,'discover_bundle',return_value=self.bundle),
            patch.object(ui,'SerialLink',side_effect=forbidden),
            patch.object(ui,'QProcess',side_effect=forbidden),
            patch.object(ui.subprocess,'Popen',side_effect=forbidden),
            patch.object(ui.QDesktopServices,'openUrl',side_effect=forbidden)]
        for p in patches:p.start();self.addCleanup(p.stop)
        self.window=ui.MainWindow(smoke=True);self.window.timer.stop()
        self.addCleanup(self.dispose_window)
    def dispose_window(self):
        self.window.job=None;self.window.disconnect();self.app.removeEventFilter(self.window)
        try:self.app.applicationStateChanged.disconnect(self.window.app_state_changed)
        except RuntimeError:pass
        self.window.close();self.window.deleteLater();self.app.processEvents()
    def connect_fake(self,*lines):
        link=FakeLink(lines);self.window.link=link;return link
    def poll(self, now=100.):
        with patch.object(ui.time,'monotonic',return_value=now):self.window.poll_serial()
    def ready(self):
        link=self.connect_fake(CAPS,LAB);self.poll();return link
    def disabled(self):return bool(self.window.controls) and all(not b.isEnabled() for b in self.window.controls)
    def done(self, request_id, op, active):
        return (f'LAB_DONE id={request_id} op={op} status=PASS errors=0 us=123 '
                f'hw_cycles=456 width=1280 height=720 refresh=60 active={active}')
    def key(self, kind, key, repeat=False):
        event=QKeyEvent(kind,key,Qt.NoModifier,'',repeat,1)
        return self.window.eventFilter(self.window,event)

    def test_only_lab1_profile_exposed(self):
        self.assertEqual(set(self.window.game_nav),{'touhou_LAB'})
        self.assertEqual([self.window.version.itemData(i) for i in range(self.window.version.count())],['touhou_LAB'])
        self.assertTrue(self.disabled())
        for p in ('touhou_R8','touhou_R7p1','mario_HD32_R1','metal_FRONTLINE_v31'):
            self.window.select_profile(p);self.assertEqual(self.window.profile_id,'touhou_LAB')
    def test_saved_other_game_falls_back_to_lab1(self):
        self.dispose_window();self.settings.last_profile='mario_HD32_R1'
        self.window=ui.MainWindow(smoke=True);self.window.timer.stop()
        self.assertEqual(self.window.profile_id,'touhou_LAB')
    def test_caps_and_fresh_lab_stat_both_required_for_game(self):
        link=self.connect_fake(CAPS);self.poll()
        self.assertTrue(self.window.protocol_ready);self.assertTrue(self.disabled());self.assertTrue(self.window.lab.available)
        link.lines=[LAB];self.poll(101)
        self.assertTrue(all(b.isEnabled() for b in self.window.controls))
        self.assertEqual(self.window.fps.value.text(),'59.9');self.assertEqual(self.window.draw.value.text(),'8.50')
        self.assertEqual(self.window.underflow.value.text(),'0')
    def test_new_stat_without_caps_does_not_enable_game(self):
        self.connect_fake(LAB);self.poll();self.assertFalse(self.window.protocol_ready);self.assertTrue(self.disabled())
    def test_old_or_other_firmware_does_not_enable_lab_controls(self):
        link=self.connect_fake(CAPS);self.poll()
        for line in (R8,R7,MARIO):
            link.lines=[line];self.poll(101);self.assertTrue(self.disabled());self.assertEqual(self.window.fps.value.text(),'—')
    def test_invalid_capabilities_revoke_controls(self):
        link=self.ready();link.lines=['CAPS fw=OLD proto=1 controls=GPIO lab=0 width=1280 height=720 hz=60'];self.poll(101)
        self.assertFalse(self.window.protocol_ready);self.assertTrue(self.disabled());self.assertGreater(link.releases,0)
    def test_connect_sends_hello(self):
        link=FakeLink()
        with patch.object(ui,'SerialLink',return_value=link),patch.object(self.window,'save_settings',return_value=True):self.window.toggle_connection()
        self.assertEqual(link.sent,[b':hello\n']);self.assertFalse(self.window.protocol_ready);self.assertTrue(self.disabled())
    def test_boot_banner_requires_new_handshake(self):
        link=self.ready();link.lines=['PHASE BATTLE v3 LAB1 PC CONTROL'];self.poll(101)
        self.assertEqual(link.sent[-1],b':hello\n');self.assertFalse(self.window.protocol_ready);self.assertTrue(self.disabled())
    def test_mouse_start_press_release(self):
        link=self.ready();button=next(b for b in self.window.controls if b.text()=='开始 / 重开')
        with patch.object(ui.time,'monotonic',return_value=101):button.pressed.emit();button.released.emit()
        self.assertEqual(link.actions,[('touhou_LAB','start',True),('touhou_LAB','start',False)]);self.assertFalse(link.held)
    def test_mouse_keyboard_same_action_reference_count(self):
        link=self.ready()
        with patch.object(ui.time,'monotonic',return_value=101):
            self.window.input_action('left','mouse',True);self.window.input_action('left',('key',Qt.Key_A),True)
            self.window.input_action('left','mouse',False);self.assertEqual(link.actions,[('touhou_LAB','left',True)])
            self.window.input_action('left',('key',Qt.Key_A),False)
        self.assertEqual(link.actions[-1],('touhou_LAB','left',False));self.assertFalse(link.held)
    def test_key_release_without_press_never_creates_press(self):
        link=self.ready()
        with patch.object(ui.time,'monotonic',return_value=101),patch.object(self.window,'isActiveWindow',return_value=True),patch.object(QApplication,'focusWidget',return_value=None):
            self.key(QEvent.KeyRelease,Qt.Key_A)
        self.assertEqual(link.actions,[]);self.assertFalse(link.held)
    def test_qt_autorepeat_does_not_release_or_retrigger(self):
        link=self.ready()
        with patch.object(ui.time,'monotonic',return_value=101),patch.object(self.window,'isActiveWindow',return_value=True),patch.object(QApplication,'focusWidget',return_value=None):
            self.key(QEvent.KeyPress,Qt.Key_A)
            for _ in range(3):self.key(QEvent.KeyRelease,Qt.Key_A,True);self.key(QEvent.KeyPress,Qt.Key_A,True)
            self.assertEqual(link.actions,[('touhou_LAB','left',True)]);self.assertEqual(link.held,{'left'})
            self.key(QEvent.KeyRelease,Qt.Key_A)
        self.assertEqual(link.actions[-1],('touhou_LAB','left',False));self.assertFalse(link.held)
    def test_w_and_arrow_up_hold_until_both_release(self):
        link=self.ready()
        with patch.object(ui.time,'monotonic',return_value=101),patch.object(self.window,'isActiveWindow',return_value=True),patch.object(QApplication,'focusWidget',return_value=None):
            self.key(QEvent.KeyPress,Qt.Key_W);self.key(QEvent.KeyPress,Qt.Key_Up);self.key(QEvent.KeyRelease,Qt.Key_W)
            self.assertEqual(link.actions,[('touhou_LAB','up',True)])
            self.key(QEvent.KeyRelease,Qt.Key_Up)
        self.assertEqual(link.actions[-1],('touhou_LAB','up',False));self.assertFalse(link.held)
    def test_typing_focus_blocks_press_but_releases_existing_held(self):
        link=self.ready();edit=QLineEdit()
        with patch.object(ui.time,'monotonic',return_value=101),patch.object(self.window,'isActiveWindow',return_value=True):
            with patch.object(QApplication,'focusWidget',return_value=None):self.key(QEvent.KeyPress,Qt.Key_A)
            with patch.object(QApplication,'focusWidget',return_value=edit):
                self.key(QEvent.KeyRelease,Qt.Key_A);self.key(QEvent.KeyPress,Qt.Key_D)
        self.assertEqual(link.actions,[('touhou_LAB','left',True),('touhou_LAB','left',False)]);self.assertFalse(link.held)
    def test_focus_navigation_and_disconnect_release(self):
        link=self.ready()
        with patch.object(ui.time,'monotonic',return_value=101):
            self.window.input_action('left','mouse',True);self.window.eventFilter(self.window,QEvent(QEvent.WindowDeactivate))
            self.assertFalse(self.window.input_sources);self.assertFalse(link.held)
            self.window.input_action('right','mouse',True);before=link.releases;self.window.navigate(4)
            self.assertGreater(link.releases,before);self.assertFalse(self.window.input_sources);self.assertFalse(link.held)
        self.window.disconnect();self.assertTrue(link.closed);self.assertIsNone(self.window.link);self.assertTrue(self.disabled())
    def test_expired_game_metrics_do_not_block_lab(self):
        link=self.ready();self.poll(108)
        self.assertGreater(link.releases,0);self.assertTrue(self.disabled());self.assertEqual(self.window.fps.value.text(),'—')
        self.assertIn('过期',self.window.mode_label.text());self.assertTrue(self.window.lab.available)
        with patch.object(ui.time,'monotonic',return_value=109):self.assertTrue(self.window.lab.request('enter'))
        self.assertEqual(link.sent[-1],b':lab 1 enter\n')
    def test_lab_pending_ack_active_isolate_game(self):
        link=self.ready()
        with patch.object(ui.time,'monotonic',return_value=101):
            self.assertTrue(self.window.lab.request('enter'));self.assertTrue(self.disabled())
            self.window.action('start',True);self.window.start_pressure();self.window.start_mode()
        self.assertEqual(link.actions,[]);self.assertEqual(link.sent,[b':lab 1 enter\n'])
        link.lines=['LAB_ACK id=1 op=enter status=QUEUED'];self.poll(102)
        self.assertFalse(self.window.lab.active);self.assertTrue(self.window.lab.pending)
        link.lines=[self.done(1,'enter',1)];self.poll(103)
        self.assertTrue(self.window.lab.active);self.assertFalse(self.window.lab.pending);self.assertTrue(self.disabled())
        self.poll(120);self.assertTrue(self.window.lab.available)
        with patch.object(ui.time,'monotonic',return_value=120):self.assertTrue(self.window.lab.request('clear'))
        self.assertEqual(link.sent[-1],b':lab 2 clear\n')
    def test_exit_after_long_lab_wait_requires_new_game_stat(self):
        link=self.ready()
        with patch.object(ui.time,'monotonic',return_value=101):self.window.lab.request('enter')
        link.lines=[self.done(1,'enter',1)];self.poll(102);self.poll(120)
        with patch.object(ui.time,'monotonic',return_value=121):self.window.lab.request('exit')
        link.lines=[self.done(2,'exit',0)];self.poll(122)
        self.assertFalse(self.window.lab.active);self.assertTrue(self.disabled())
        link.lines=[LAB];self.poll(123);self.assertTrue(all(b.isEnabled() for b in self.window.controls))
    def test_busy_blocks_widgets_and_direct_slots(self):
        link=self.ready();sentinel=object();self.window.job=sentinel;self.window.set_busy(True)
        for obj in [self.window.download_button,self.window.check_button,self.window.version,self.window.connect_button,*self.window.game_nav.values()]:self.assertFalse(obj.isEnabled())
        self.assertTrue(self.disabled())
        with patch.object(ui.time,'monotonic',return_value=101):
            self.window.action('start',True);self.window.start_pressure();self.window.start_mode()
            self.assertFalse(self.window.lab.request('enter'));self.window.run_job(False)
        self.assertIs(self.window.job,sentinel);self.assertEqual(link.actions,[]);self.assertEqual(link.sent,[])
    def test_close_keeps_busy_job_and_normal_close_releases(self):
        link=self.connect_fake();sentinel=object();self.window.job=sentinel;event=QCloseEvent()
        with patch.object(QMessageBox,'information',return_value=QMessageBox.Ok):self.window.closeEvent(event)
        self.assertFalse(event.isAccepted());self.assertIs(self.window.job,sentinel)
        self.window.job=None;event=QCloseEvent();self.window.closeEvent(event)
        self.assertTrue(event.isAccepted());self.assertTrue(link.closed)
    def test_pressure_command_and_cpu_high_count_guard(self):
        link=self.ready()
        with patch.object(ui.time,'monotonic',return_value=101):
            self.window.pressure_count.setCurrentIndex(self.window.pressure_count.findData(64));self.window.start_pressure()
            self.assertEqual(link.sent,[b':limit 64\n:mode 3\n'])
            self.window.pressure_count.setCurrentIndex(self.window.pressure_count.findData(20000))
            self.window.pressure_backend.setCurrentIndex(self.window.pressure_backend.findData(False))
            with patch.object(QMessageBox,'information',return_value=QMessageBox.Ok) as message:self.window.start_pressure();self.assertEqual(message.call_count,1)
        self.assertEqual(len(link.sent),1)
    def test_help_explains_gpio_and_refresh(self):
        labels='\n'.join(w.text() for w in self.window.findChildren(QLabel))
        self.assertIn('GPIO 按键不参与游戏控制',labels);self.assertIn('60 Hz 是刷新规格',labels)

if __name__=='__main__':unittest.main()
