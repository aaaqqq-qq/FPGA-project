"""Actual Qt widgets with deterministic fake time and protocol only."""
import os
os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]));sys.path.insert(0,str(Path(__file__).resolve().parent))
from PySide6.QtWidgets import QApplication
from labx_panel import LabXPanel
from test_labx_protocol import parsed,done,measured


class PanelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])
    def setUp(self):
        self.now=0.;self.panel=LabXPanel(clock=lambda:self.now);self.panel.mem_size.setCurrentIndex(0);self.sent=[];self.panel.command_requested.connect(lambda i,o,a:self.sent.append((i,o,a)));self.addCleanup(self.panel.deleteLater)
    def enable(self):
        self.panel.set_capabilities(dict(fw="LAB23",labx=1));self.panel.set_available(True);i=self.sent[-1][0]
        self.panel.ingest(parsed("LABX_ACK",id=i,op="status",status="ACCEPTED"));self.panel.ingest(parsed("LABX_STATE",id=i,active=0,phase=0,front=0x01000000,back=0x01400000,swaps=1,pending=0,ready=0,errors=0));self.panel.ingest(done(i,"status",active=0))
    def enter(self):
        self.enable();self.panel.request("enter");i=self.sent[-1][0];self.panel.ingest(parsed("LABX_ACK",id=i,op="enter",status="QUEUED"));self.panel.ingest(done(i,"enter"));return i
    def complete_mem(self,elapsed=1000000):
        i=self.panel._request.request_id;_,lines,last=measured(i,"mem",self.panel.mem_repeats.value())
        for line in lines:self.panel.ingest(line)
        self.panel.ingest(dict(last,elapsed_us=elapsed))

    def test_old_firmware_does_not_enable_new_experiments(self):
        self.panel.set_capabilities(dict(fw="LAB1",labx=0));self.panel.set_available(True)
        self.assertFalse(self.panel.enter_button.isEnabled());self.assertFalse(self.panel.request("enter"));self.assertFalse(self.sent)
    def test_new_connection_requires_status_before_game_unlock(self):
        self.panel.set_capabilities(dict(fw="LAB23",labx=1));self.assertTrue(self.panel.blocks_game)
        self.enable();self.assertFalse(self.panel.blocks_game);self.assertTrue(self.panel.enter_button.isEnabled())
    def test_ack_does_not_complete_request(self):
        self.enter();self.panel.start_mem();i=self.sent[-1][0];self.panel.ingest(parsed("LABX_ACK",id=i,op="mem",status="QUEUED"))
        self.assertTrue(self.panel.pending);self.assertFalse(self.panel.results[-1].get("op")=="mem")
    def test_mem_complete_updates_only_real_results(self):
        self.enter();self.panel.start_mem();self.complete_mem();self.assertFalse(self.panel.pending);self.assertTrue(self.panel.results[-1]["accepted_pass"]);self.assertEqual(self.panel.table.rowCount(),6)
    def test_stale_reply_does_not_end_new_request(self):
        self.enter();self.panel.start_mem();self.panel.ingest(done(1,"mem",completed=6));self.assertTrue(self.panel.pending)
    def test_timeout_keeps_isolation_unknown_and_never_pass(self):
        self.enter();self.panel.start_mem();self.now=181.;self.panel.tick();self.assertFalse(self.panel.pending);self.assertTrue(self.panel.blocks_game);self.assertFalse(self.panel.results[-1]["accepted_pass"]);self.assertFalse(self.panel.mem_button.isEnabled())
    def test_stop_waits_original_then_exit(self):
        self.enter();self.panel.start_mem();original=self.sent[-1][0];self.panel.stop_and_return();cancel=self.sent[-1][0];self.assertEqual(self.sent[-1][1],"cancel")
        self.panel.ingest(done(cancel,"cancel"));self.assertTrue(self.panel.pending);self.assertNotEqual(self.sent[-1][1],"exit")
        self.panel.ingest(done(original,"mem",status="CANCELLED",code="CANCEL"));self.assertEqual(self.sent[-1][1],"exit");self.assertTrue(self.panel.pending)
    def test_cancel_ack_not_original_completion(self):
        self.enter();self.panel.start_mem();self.panel.stop_and_return();i=self.sent[-1][0];self.panel.ingest(parsed("LABX_ACK",id=i,op="cancel",status="ACCEPTED"));self.assertTrue(self.panel.pending)
    def test_disconnect_retains_incomplete_evidence(self):
        self.enter();self.panel.start_mem();self.panel.disconnected();self.assertFalse(self.panel.pending);self.assertFalse(self.panel.active);self.assertEqual(self.panel.results[-1]["reasons"],["DISCONNECTED"])
    def test_continuous_waits_actual_completions_not_timer(self):
        self.enter();self.panel.start_continuous();self.now=100.;self.assertTrue(self.panel._loop);self.assertFalse(self.panel.continuous_results)
        self.complete_mem(elapsed=30000001);self.assertFalse(self.panel._loop);self.assertTrue(self.panel.continuous_results[-1]["accepted_pass"])
    def test_continuous_each_next_request_after_done(self):
        self.enter();self.panel.start_continuous();before=len(self.sent);self.panel.tick();self.assertEqual(len(self.sent),before)
        self.complete_mem();self.assertEqual(len(self.sent),before);self.panel.tick();self.assertEqual(len(self.sent),before+1);self.assertNotEqual(self.sent[-1][0],self.sent[-2][0])
    def test_ui_available_refresh_preserves_result_message(self):
        self.enter();self.panel.start_mem();self.complete_mem();before=self.panel.status.text()
        for _ in range(20):self.panel.set_available(True)
        self.assertEqual(self.panel.status.text(),before)
    def test_export_marks_scope_and_keeps_raw(self):
        self.enter();self.panel.start_mem();self.complete_mem();doc=self.panel.export_document();self.assertFalse(doc["hardware_accessed_by_panel"]);self.assertTrue(doc["raw"]);self.assertIn("本页不自动认证",doc["cold_boot_scope"])

    def test_expired_terminal_is_rejected_even_without_timer_tick(self):
        self.enter();self.panel.start_mem();i=self.sent[-1][0];self.now=181.;self.panel.ingest(done(i,"mem",completed=6))
        self.assertFalse(self.panel.results[-1]["accepted_pass"]);self.assertIn("TIMEOUT",self.panel.results[-1]["reasons"]);self.assertTrue(self.panel.uncertain)

    def test_cancelled_zero_measurements_preserved_without_division_by_zero(self):
        self.enter();self.panel.start_mem();i=self.sent[-1][0];_,lines,last=measured(i,"mem",3)
        for item in lines:
            if item["kind_line"]=="LABX_RESULT":item=dict(item,frames=0,jobs=0,pixels=0,render_us=0)
            if item["kind_line"]=="LABX_METRIC":item=dict(item,elapsed_us=0,swaps=0,cycles=0,read=0,write=0)
            self.panel.ingest(item)
        self.panel.ingest(dict(last,status="CANCELLED",code="CANCEL"));self.assertFalse(self.panel.results[-1]["accepted_pass"]);self.assertFalse(self.panel.pending)

    def test_done_without_real_status_state_keeps_unknown_isolation(self):
        self.panel.set_capabilities(dict(fw="LAB23",labx=1));self.panel.set_available(True);i=self.sent[-1][0]
        self.panel.ingest(parsed("LABX_ACK",id=i,op="status",status="ACCEPTED"));self.panel.ingest(done(i,"status",active=0))
        self.assertTrue(self.panel.uncertain);self.assertTrue(self.panel.blocks_game)


if __name__=="__main__":unittest.main()
