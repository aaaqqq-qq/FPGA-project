"""C3 row-run diagnostics: synthetic protocol vectors and Qt only, never board proof."""
import unittest
from test_performance60 import sample_args
from test_performance_path import path_reply,verdict
from adv_protocol import parse_adv_reply
from adv_panel import AdvPanel
from PySide6.QtWidgets import QApplication

def row_args(size=17,physics=0,frames=600):
 args=list(sample_args(frames,size=size));args[1]=128 if physics else 64;args[7]=0;args[10]=physics;return tuple(args)
def row_path(args,path='rowrun',reason='rowrun_odd',**extra):
 fields=dict(prime_steps=0,prime_logic_us=0,measured_steps=args[11],passes=args[11],micro=args[11]*args[1]);fields.update(extra)
 return path_reply(args,path=path,reason=reason,**fields)

class RowRunProtocolTests(unittest.TestCase):
 def test_odd_singlekey_path_preserves_exact_request(self):
  args=row_args();r=verdict(args,row_path(args));self.assertTrue(r['accepted_pass']);self.assertEqual(r['args'],list(args));self.assertEqual(r['result']['initial'],64);self.assertFalse(r['long_60fps_pass'])
 def test_fusion_rowrun_reports_actual_count_without_silent_change(self):
  args=row_args(32,2);r=verdict(args,row_path(args,reason='rowrun_fusion'));self.assertTrue(r['accepted_pass']);self.assertEqual(r['result']['initial'],128);self.assertEqual(r['result']['final'],128)
 def test_mixed_capacity_path_can_retain_earlier_op2(self):
  args=row_args(32,2);r=verdict(args,row_path(args,path='rowrun_mixed',reason='rowrun_capacity_fallback',passes=12,micro=2048));self.assertTrue(r['accepted_pass']);self.assertEqual(r['path']['passes'],12)
 def test_all_attempts_fallback_is_honest_mixed_zero_op2(self):
  args=row_args();r=verdict(args,row_path(args,path='rowrun_mixed',reason='rowrun_capacity_fallback',passes=0,micro=0));self.assertTrue(r['accepted_pass']);self.assertFalse(r['long_60fps_pass'])
 def test_ordinary_rect_still_cannot_hide_earlier_op2_work(self):
  args=row_args();self.assertFalse(verdict(args,row_path(args,path='rect',reason='descriptor_capacity',passes=1,micro=16))['accepted_pass'])
 def test_cpu_or_keyoff_cannot_claim_rowrun(self):
  for key,value in [(0,'cpu'),(9,0)]:
   args=list(row_args());args[key]=value;args=tuple(args);self.assertFalse(verdict(args,row_path(args))['accepted_pass'])
 def test_reason_must_match_fusion_odd_or_capacity(self):
  args=row_args(32);self.assertFalse(verdict(args,row_path(args,reason='rowrun_odd'))['accepted_pass']);self.assertFalse(verdict(args,row_path(args,reason='rowrun_fusion'))['accepted_pass'])
  args=row_args();self.assertFalse(verdict(args,row_path(args,path='rowrun_mixed',reason='rowrun_odd'))['accepted_pass']);self.assertFalse(verdict(args,row_path(args,reason='rowrun_capacity_fallback'))['accepted_pass'])
 def test_unknown_rowrun_claim_is_not_an_accepted_enum(self):
  self.assertIsNone(parse_adv_reply(row_path(row_args())['raw'].replace('path=rowrun','path=rowrun_auto60')))

class RowRunWidgetTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.app=QApplication.instance() or QApplication(['rowrun-offline-tests'])
 def test_capacity_may_all_fallback_and_op2_scope_is_visible(self):
  p=AdvPanel(clock=lambda:10);self.addCleanup(p.deleteLater);args=row_args();r=verdict(args,row_path(args,path='rowrun_mixed',reason='rowrun_capacity_fallback',passes=0,micro=0));p.results.append(r);p._refresh_results()
  self.assertIn('20000',p.path_detail.text());self.assertIn('全部回退',p.path_detail.text());self.assertIn('额外填充',p.path_detail.text());self.assertFalse(r['long_60fps_pass']);self.assertIn('短测观察',p.summary.text())

if __name__=='__main__':unittest.main()
