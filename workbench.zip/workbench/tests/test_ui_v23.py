"""Actual MainWindow -> experiment page -> fake serial, no devices/processes."""
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
import test_ui as base
import main as ui
from control_core import parse_capabilities
from test_labx_protocol import parsed,done,measured

CAPS="CAPS fw=LAB23 proto=2 controls=PC lab=1 labx=1 width=1280 height=720 hz=60"
STAT=base.LAB.replace("fw=LAB1","fw=LAB23")


class FakeLab23(base.FakeLink):
    def __init__(self,lines=()):super().__init__(lines);self.capabilities=None
    def accept_capabilities(self,values):self.accepted.append(values);self.capabilities=values;return bool(values and values.get("fw")=="LAB23")


class V23UIContracts(unittest.TestCase):
    setUpClass=classmethod(base.NativeUIContracts.setUpClass.__func__)
    def setUp(self):
        base.NativeUIContracts.setUp(self)
        clock=patch.object(ui.time,'monotonic',return_value=102.);clock.start();self.addCleanup(clock.stop)
    dispose_window=base.NativeUIContracts.dispose_window
    poll=base.NativeUIContracts.poll
    disabled=base.NativeUIContracts.disabled

    def handshake(self):
        link=FakeLab23([CAPS]);self.window.link=link;self.poll();return link
    def inject(self,link,*items):
        link.lines=[item["raw"] if isinstance(item,dict) else item for item in items];self.poll(101)
    def ready23(self):
        link=self.handshake();request=self.window.labx._request;i=request.request_id
        self.inject(link,parsed("LABX_ACK",id=i,op="status",status="ACCEPTED"),parsed("LABX_STATE",id=i,active=0,phase=0,front=0x01000000,back=0x01400000,swaps=1,pending=0,ready=0,errors=0),done(i,"status",active=0),STAT)
        return link
    def enter23(self):
        link=self.ready23();self.window.labx.request("enter");i=self.window.labx._request.request_id
        self.inject(link,parsed("LABX_ACK",id=i,op="enter",status="QUEUED"),done(i,"enter"));return link

    def test_sidebar_new_page_available_offline_without_device_access(self):
        self.assertIn(6,self.window.page_nav);self.window.navigate(6);self.assertEqual(self.window.stack.currentIndex(),6);self.assertFalse(self.window.labx.enter_button.isEnabled())
    def test_lab23_caps_needs_real_status_before_controls(self):
        link=self.handshake();self.assertTrue(self.window.protocol_ready);self.assertTrue(self.disabled());self.assertEqual(link.sent[-1].split()[0],b":labx");self.assertIn(b" status\n",link.sent[-1])
    def test_real_status_accepted_ack_and_state_unblocks_after_fresh_stat(self):
        self.ready23();self.assertTrue(self.window.game_ready());self.assertFalse(self.window.labx.uncertain)
    def test_old_lab1_compatibility_cannot_open_new_experiment(self):
        self.window.link=base.FakeLink([base.CAPS,base.LAB]);self.poll();self.assertTrue(self.window.game_ready());self.assertFalse(self.window.labx.capable);self.assertFalse(self.window.labx.request("enter"));self.assertIn("旧版",self.window.connection.text())
    def test_new_version_without_labx_capability_is_rejected(self):
        self.assertIsNone(parse_capabilities(CAPS.replace(" labx=1","")))
    def test_active_labx_blocks_every_game_and_programming_direct_slot(self):
        link=self.enter23();before=len(link.sent)
        with patch.object(self.window,"save_settings") as save:
            self.window.run_job(True);self.window.run_job(False);save.assert_not_called()
        self.window.start_mode();self.window.run_pressure(64,True);self.window.control_send(b":pause 1\n");self.window.action("start",True)
        self.assertEqual(len(link.sent),before);self.assertFalse(link.actions);self.assertFalse(self.window.lab.request("enter"));self.assertFalse(self.window.download_button.isEnabled());self.assertFalse(self.window.check_button.isEnabled())
    def test_matched_three_fragment_measurement_reaches_ui(self):
        link=self.enter23();self.window.labx.mem_size.setCurrentIndex(0);self.window.labx.mem_repeats.setValue(1);self.window.labx.start_mem();i=self.window.labx._request.request_id
        _,lines,last=measured(i,"mem");self.inject(link,*lines,last);self.assertTrue(self.window.labx.results[-1]["accepted_pass"]);self.assertEqual(self.window.labx.table.rowCount(),2)
    def test_bad_or_incomplete_measurement_cannot_show_acceleration(self):
        link=self.enter23();self.window.labx.mem_size.setCurrentIndex(0);self.window.labx.mem_repeats.setValue(1);self.window.labx.start_mem();i=self.window.labx._request.request_id
        _,lines,last=measured(i,"mem");self.inject(link,*[x for x in lines if x["kind_line"]!="LABX_CHECK"],last);self.assertFalse(self.window.labx.results[-1]["accepted_pass"]);self.assertIn("—",self.window.labx.summary.text())
    def test_stale_done_cannot_unlock_experiment(self):
        link=self.enter23();self.window.labx.start_mem();self.inject(link,done(123,"mem",active=0));self.assertTrue(self.window.labx.pending);self.assertTrue(self.disabled())
    def test_legacy_active_status_restores_basic_one_exit(self):
        link=self.handshake();i=self.window.labx._request.request_id;self.inject(link,done(i,"status",status="ERROR",code="LEGACY_ACTIVE",active=0))
        self.assertTrue(self.window.lab.active);self.assertFalse(self.window.labx.uncertain);self.assertTrue(self.window.lab.exit_button.isEnabled());self.assertTrue(self.disabled())
    def test_disconnect_marks_pending_incomplete(self):
        link=self.enter23();self.window.labx.start_mem();self.window.disconnect();self.assertTrue(link.closed);self.assertFalse(self.window.labx.pending);self.assertFalse(self.window.labx.results[-1]["accepted_pass"])
    def test_cancel_delivery_keeps_game_isolated_until_original_terminal_and_exit(self):
        link=self.enter23();self.window.labx.start_mem();original=self.window.labx._request.request_id;self.window.labx.stop_and_return();cancel=self.window.labx._cancel_id
        self.inject(link,parsed("LABX_ACK",id=cancel,op="cancel",status="ACCEPTED"),done(cancel,"cancel"));self.assertTrue(self.window.labx.pending);self.assertTrue(self.disabled())
        self.inject(link,done(original,"mem",status="CANCELLED",code="CANCEL"));self.assertEqual(self.window.labx._request.operation,"exit");i=self.window.labx._request.request_id
        self.inject(link,parsed("LABX_ACK",id=i,op="exit",status="QUEUED"),done(i,"exit",active=0));self.assertFalse(self.window.game_ready());self.inject(link,STAT);self.assertTrue(self.window.game_ready())
    def test_unowned_direct_labx_slot_cannot_write(self):
        link=self.ready23();before=len(link.sent);self.window.labx_send(42,"enter",[]);self.assertEqual(len(link.sent),before)
    def test_gui_never_infers_cold_boot_from_lab23_handshake(self):
        before=self.window.flash_status.text();self.ready23();self.assertEqual(self.window.flash_status.text(),before)


if __name__=="__main__":unittest.main()
