"""Loader stream validation without launching hardware or the UI."""
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from download_progress import DownloadProgress


def event(stage, state="running", **kwargs):
    return "PROGRESS " + json.dumps(dict(stage=stage, state=state, **kwargs))


class DownloadProgressTests(unittest.TestCase):
    def test_real_loader_stream_and_distinct_first_step(self):
        p = DownloadProgress()
        stream = [event("files"), event("device", step=1), event("configure", step=2),
                  event("load", step=3), event("load", step=3),
                  event("verify", step=4, done=0, total=188818, unit="bytes"),
                  event("verify", step=4, done=65536, total=188818, unit="bytes"),
                  event("verify", step=4, done=188818, total=188818, unit="bytes"),
                  event("start", step=5), event("start", "done", step=5)]
        values = [p.feed(line) for line in stream]
        self.assertTrue(all(values))
        self.assertEqual([v["step"] for v in values], [1, 1, 2, 3, 3, 4, 4, 4, 5, 5])
        self.assertNotIn("percent", values[6])
        self.assertAlmostEqual(values[6]["done"] / values[6]["total"], 65536 / 188818)
        self.assertFalse(any("download_complete" in v for v in values))
        terminal = p.finish(True)
        self.assertTrue(terminal["complete"] and terminal["download_complete"])
        self.assertEqual((terminal["state"], terminal["label"]), ("done", "下载完成"))

    def test_failed_after_full_byte_count_does_not_claim_complete(self):
        p = DownloadProgress()
        p.feed(event("verify", done=100, total=100, unit="bytes"))
        terminal = p.finish(False)
        self.assertFalse(terminal["complete"] or terminal["download_complete"])
        self.assertEqual(terminal["state"], "failed")
        for key in ("percent", "done", "total", "unit"):
            self.assertNotIn(key, terminal)
        self.assertEqual(p.finish(True), terminal)  # a retry requires reset()
        self.assertIsNone(p.feed(event("start", "done")))

    def test_offline_check_success_is_not_download(self):
        p = DownloadProgress()
        p.reset(check=True)
        self.assertIsNotNone(p.feed(event("files")))
        self.assertIsNone(p.feed(event("configure")))
        self.assertIsNotNone(p.feed(event("files", "done")))
        result = p.finish(True)
        self.assertTrue(result["complete"])
        self.assertFalse(result["download_complete"])
        self.assertEqual((result["step"], result["label"]), (1, "离线检查完成"))
        p.reset(check=True)
        self.assertEqual(p.finish(False)["label"], "离线检查失败")

    def test_reject_malformed_untrusted_fields_and_numbers(self):
        invalid = ["plain log", "PROGRESS ", " PROGRESS {}", "PROGRESS []",
                   'PROGRESS {"stage":"load","stage":"start","state":"running"}',
                   'PROGRESS {"stage":"load","state":"running","done":NaN,"total":1}',
                   'PROGRESS {"stage":"load","state":"running","done":Infinity,"total":1}',
                   event("unknown"), event("LOAD"), event("load", "failed"),
                   event("load", step=2), event("load", step=True),
                   event("load", percent=100), event("load", seconds=3),
                   event("load", done=0), event("load", total=1),
                   event("load", done=True, total=1), event("load", done=0, total=False),
                   event("load", done=0.0, total=1), event("load", done="0", total=1),
                   event("load", done=-1, total=100), event("load", done=2, total=1),
                   event("load", done=0, total=0), event("load", done=0, total=1, unit="seconds"),
                   event("load", unit="bytes"), event("load", "done", done=1, total=2, unit="bytes"),
                   'PROGRESS {"stage":{},"state":"running"}',
                   'PROGRESS {"stage":"load","state":"running"} garbage']
        for line in invalid:
            with self.subTest(line=line):
                p = DownloadProgress()
                self.assertIsNone(p.feed(line))
                self.assertIsNotNone(p.feed(event("files")))  # rejection did not mutate stage

    def test_stage_counter_and_state_regressions_are_atomic(self):
        p = DownloadProgress()
        p.feed(event("load", done=10, total=100, unit="bytes"))
        for bad in [event("device"), event("load", done=9, total=100, unit="bytes"),
                    event("load", done=11, total=101, unit="bytes"), event("load", "done")]:
            self.assertIsNone(p.feed(bad))
        value = p.feed(event("load", done=100, total=100, unit="bytes"))
        self.assertEqual(value["total"], 100)
        self.assertIsNotNone(p.feed(event("load", "done")))
        self.assertIsNone(p.feed(event("load")))
        self.assertIsNotNone(p.feed(event("verify", done=0, total=100, unit="bytes")))
        value = p.feed(event("verify"))
        self.assertEqual(value["done"], 0)

    def test_existing_line_buffer_owns_split_lines(self):
        p = DownloadProgress()
        text = event("files") + "\r\n" + "LOG actual tool output\n" + event("device") + "\n"
        # Simulate the caller's existing buffer; feed() itself does not retain
        # arbitrary chunks or treat unframed console lines as progress.
        parts = [text[:7], text[7:22], text[22:47], text[47:]]
        pending = ""
        parsed = []
        for chunk in parts:
            pending += chunk
            while "\n" in pending:
                line, pending = pending.split("\n", 1)
                value = p.feed(line)
                if value is not None:
                    parsed.append(value["stage"])
        self.assertEqual(parsed, ["files", "device"])
        self.assertEqual(pending, "")

    def test_reset_snapshot_copy_and_boolean_types(self):
        p = DownloadProgress()
        value = p.feed(event("load", done=3, total=4))
        value["done"] = -1
        self.assertEqual(p.feed(event("load"))["done"], 3)
        p.finish(False)
        p.reset()
        self.assertIsNotNone(p.feed(event("files")))
        with self.assertRaises(TypeError):
            p.finish("False")
        with self.assertRaises(TypeError):
            p.reset(check="False")


if __name__ == "__main__":
    unittest.main()
