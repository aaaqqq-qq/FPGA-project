"""Portable current-release routing; no firmware artifacts or hardware opened."""
from pathlib import Path
import json,os,shutil,subprocess,sys,tempfile,unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import control_core as c

class BundleRoutingTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
  env=patch.dict(os.environ,{'TI60_BUNDLE_ROOT':''});env.start();self.addCleanup(env.stop)
  self.default=self.bundle('development');self.here=self.root/'portable'/'control_center';self.here.mkdir(parents=True)
  for p in (patch.object(c,'DEFAULT_BUNDLE',self.default),patch.object(c,'__file__',str(self.here/'control_core.py'))):p.start();self.addCleanup(p.stop)
 def bundle(self,name,current=True):
  root=self.root/name;(root/'projects/touhou_LAB').mkdir(parents=True);(root/'tools').mkdir();(root/'out').mkdir()
  (root/'START_MENU.py').write_text('# full flash only');(root/'tools/local_paths.json').write_text('{}')
  marker=dict(firmware='LAB23',kind='full_flash',profile='touhou_LAB',state='READY',manifest='out/manifest.json',ram_fallback_allowed=False,clock_mhz=100,release_id='GAME60_PIPELINE_5' if current else 'LAB23',required_capabilities={'adv':1,'img':1,'perf':1,'game_load':1,'gsizes':7,'batch32':1,'motion':1,'pref':1,'pipe':1,'pref8':1} if current else {})
  manifest=dict(release_id=marker['release_id'],firmware='LAB23',clock_mhz=100,boot_marker=c.BOOT_MARKER if current else 'PHASE BATTLE v3 LAB23 PC CONTROL',required_capabilities=marker['required_capabilities'],elf={'sha256':c.CURRENT_ELF_SHA256 if current else '0'*64},platform={'bit_sha256':c.CURRENT_PLATFORM_SHA256 if current else '0'*64})
  (root/'persistent_entry.json').write_text(json.dumps(marker));(root/'out/manifest.json').write_text(json.dumps(manifest));return root.resolve()
 def paired(self):return self.bundle('portable/TI60_GAME60_PIPELINE5_HUDLITE_20261104')
 def change(self,bundle,relative,key,value):
  p=bundle/relative;d=json.loads(p.read_text());d[key]=value;p.write_text(json.dumps(d))
 def test_explicit_environment_wins_preferred_adjacent_and_default(self):
  preferred=self.bundle('chosen');paired=self.paired();explicit=self.bundle('environment')
  with patch.dict(os.environ,{'TI60_BUNDLE_ROOT':str(explicit)}):self.assertEqual(c.discover_bundle(preferred),explicit)
 def test_matching_preferred_can_be_selected_in_gui(self):
  self.paired();selected=self.bundle('user_selected');self.assertEqual(c.discover_bundle(selected),selected)
 def test_source_adjacent_package_wins_development_default(self):
  paired=self.paired();self.assertEqual(c.discover_bundle(),paired)
 def test_frozen_executable_parent_and_grandparent_layouts(self):
  paired=self.paired()
  for exe in (self.root/'portable/dist_v26/Ti60ControlCenter.exe',self.root/'portable/control_center/dist_v26/Ti60ControlCenter.exe'):
   with self.subTest(exe=exe),patch.object(c.sys,'frozen',True,create=True),patch.object(c.sys,'executable',str(exe)):self.assertEqual(c.discover_bundle(),paired)
 def test_complete_legacy_lab23_saved_and_env_cannot_shadow_default(self):
  legacy=self.bundle('old_v3',current=False)
  self.assertTrue(c.persistent_bundle_available(legacy))
  with patch.dict(os.environ,{'TI60_BUNDLE_ROOT':str(legacy)}):self.assertEqual(c.discover_bundle(legacy),self.default)
 def test_release_adv_boot_and_elf_identity_are_all_required(self):
  for relative,key,value in [('persistent_entry.json','release_id','LAB23'),('persistent_entry.json','required_capabilities',{'adv':True}),('out/manifest.json','release_id','OTHER'),('out/manifest.json','required_capabilities',{'adv':0}),('out/manifest.json','boot_marker','OLD'),('out/manifest.json','elf',{'sha256':'f'*64})]:
   with self.subTest(key=key,value=value):
    selected=self.bundle('bad_'+str(len(list(self.root.iterdir()))));self.change(selected,relative,key,value);self.assertEqual(c.discover_bundle(selected),self.default)
 def test_discovery_never_runs_full_artifact_validator(self):
  paired=self.paired()
  with patch.object(c,'load_persistent_profile',side_effect=AssertionError('Full artifact scan is not startup routing')) as full:
   self.assertEqual(c.discover_bundle(),paired);full.assert_not_called()
 def test_corrupt_and_oversize_manifest_cannot_win(self):
  for text in ('not json',' '*262145):
   selected=self.bundle('bad_'+str(len(list(self.root.iterdir()))));(selected/'out/manifest.json').write_text(text);self.assertEqual(c.discover_bundle(selected),self.default)
 def test_preparing_current_release_can_check_but_cannot_program(self):
  selected=self.bundle('preparing');self.change(selected,'persistent_entry.json','state','PREPARING');self.assertEqual(c.discover_bundle(selected),selected);self.assertFalse(c.persistent_program_available(selected))
 def test_external_clean_process_finds_paired_copy_with_unmodified_code(self):
  paired=self.paired();production=Path(__file__).resolve().parents[1]
  for name in ('control_core.py','persistent_profile.py','image_protocol.py'):shutil.copy2(production/name,self.here/name)
  code="import sys,json;sys.path.insert(0,sys.argv[1]);import control_core as c;print(json.dumps({'module':c.__file__,'bundle':str(c.discover_bundle())}))"
  env=os.environ.copy();env.pop('TI60_BUNDLE_ROOT',None);env.pop('PYTHONHOME',None)
  result=subprocess.run([sys.executable,'-I','-c',code,str(self.here)],env=env,capture_output=True,text=True,check=True,timeout=15)
  data=json.loads(result.stdout);self.assertEqual(Path(data['module']).resolve(),self.here/'control_core.py');self.assertEqual(Path(data['bundle']),paired)

if __name__=='__main__':unittest.main()

