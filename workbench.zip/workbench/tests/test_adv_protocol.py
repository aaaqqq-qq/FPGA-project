"""Strict ADV1 evidence tests, malformed fragments and actual result boundaries."""
from pathlib import Path
import sys,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from adv_protocol import *

SHOW=('alpha',0,32,0,0xff3333,0x223344,128,0xff00ff,1,1,0)
STRESS=('fpga',64,16,0,0x4c8dff,0xf18bbb,0xf5be52,1,128,1,0,2,123456789)
CAPS='CAPS fw=LAB23 proto=2 controls=PC lab=1 labx=1 adv=1 width=1280 height=720 hz=60'

def parsed(kind,**fields):
 line=kind+' '+' '.join('%s=%s'%(k,v) for k,v in fields.items())
 reply=parse_adv_reply(line)
 if reply is None:raise AssertionError('Fixture rejected: '+line)
 return reply

def done(i,op,active=1,status='PASS',code='OK',completed=0):
 return parsed('ADV_DONE',id=i,op=op,status=status,code=code,completed=completed,active=active,elapsed_us=50000)

def control(i,op,active=1,running=0):
 return [parsed('ADV_ACK',id=i,op=op,status='ACCEPTED' if op=='status' else 'QUEUED'),parsed('ADV_STATE',id=i,op=op,active=active,running=running),done(i,op,active)]

def measured(i=42,op='stress',args=STRESS):
 task=task_identity(op,args);count=expected_count(op,args);n=args[1] if op=='stress' else 0
 items=[parsed('ADV_ACK',id=i,op=op,status='QUEUED'),
  parsed('ADV_PLAN',id=i,op=op,task=task,args=','.join(map(str,args)),expected=count,scope='sampled' if op=='stress' else 'full',key=expected_key(op,args)),
  parsed('ADV_RESULT',id=i,op=op,task=task,frames=count if op=='stress' else 0,cases=0 if op=='stress' else count,initial=n,final=n,minimum=n,maximum=n,pairs=0,collisions=0,merges=0),
  parsed('ADV_METRIC',id=i,op=op,task=task,logic_us=200,render_us=4000,wait_us=27000,elapsed_us=33333,swaps=count if op=='stress' else 0,uf=0,late=0),
  parsed('ADV_CHECK',id=i,op=op,task=task,errors=0,guards=0,source=0,checked=64 if op=='stress' else 921600,actual=1,replayed=0)]
 return items,done(i,op,completed=count)

def verdict(op='stress',args=STRESS,mutate=None,drop=None):
 items,end=measured(op=op,args=args);r=AdvRequest(42,op,args,100)
 if mutate:mutate(items,end)
 for item in items:
  if item['kind_line']!=drop:r.feed(item)
 return r.finish(end)

class AdvProtocolTests(unittest.TestCase):
 def test_twenty_thousand_at64_is_measurable_and_uint32seed_encodes(self):
  args=list(STRESS);args[1]=20000;args[2]=64;args[12]=4294967295
  self.assertIn(b'4294967295',adv_command(42,'stress',*args));self.assertEqual(timeout_for('stress',args),1860)
 def test_all_integer_sizes_and_six_shapes_valid(self):
  for size in range(8,65):
   for shape in range(6):
    a=list(STRESS);a[2]=size;a[3]=shape;validate_args('stress',a)
 def test_every_physics_mode_rejects513_without_clamping(self):
  for mode in range(1,6):
   a=list(STRESS);a[1]=513;a[10]=mode
   with self.assertRaisesRegex(ValueError,'512'):validate_args('stress',a)
   self.assertEqual(a[1],513)
 def test_boolean_and_out_of_range_seed_are_rejected(self):
  for index,value in ((1,True),(2,7),(2,65),(10,6),(11,36001),(12,0),(12,4294967296)):
   a=list(STRESS);a[index]=value
   with self.subTest(index=index,value=value),self.assertRaises(ValueError):validate_args('stress',a)
 def test_show_and_control_invalid_fields_rejected(self):
  for op,args in [('enter',(1,)),('show',SHOW[:-1]),('verify',('all',)),('bogus',())]:
   with self.assertRaises(ValueError):adv_command(1,op,*args)
 def test_exact_parser_rejects_duplicate_missing_extra_and_oversize(self):
  line=done(1,'status',0)['raw']
  for bad in (line+' id=2',line.replace(' active=0',''),line+' x=1',line.replace('id=1','id=-1'),line+'x'*384):self.assertIsNone(parse_adv_reply(bad))
 def test_identity_does_not_include_request_id(self):
  a,_=measured(1);b,_=measured(2);self.assertEqual(a[1]['task'],b[1]['task']);self.assertEqual(task_identity('stress',STRESS),a[1]['task'])
 def test_complete_stress_has_real_fps_and_separate_60fps_condition(self):
  r=verdict();self.assertTrue(r['accepted_pass']);self.assertAlmostEqual(r['actual_fps'],60.0006,places=3);self.assertTrue(r['performance_60fps'])
  r=verdict(mutate=lambda x,y:x[3].update(late=1));self.assertTrue(r['accepted_pass']);self.assertFalse(r['performance_60fps'])
  r=verdict(mutate=lambda x,y:x[3].update(uf=1));self.assertFalse(r['performance_60fps']);self.assertFalse(r['accepted_pass'])
 def test_mask_key_is_collision_free_for_magenta_including_gradient(self):
  for mode in range(3):
   a=list(STRESS);a[4]=0xff00ff;a[5]=0x0000ff;a[6]=0xff0000;a[7]=mode
   self.assertNotEqual(expected_key('stress',a),0xff00ff);self.assertTrue(verdict(args=tuple(a))['accepted_pass'])
 def test_show_key_and_complete_full_pixel_count_must_match(self):
  self.assertFalse(verdict('show',SHOW,mutate=lambda x,y:x[1].update(key=0))['accepted_pass'])
  self.assertFalse(verdict('verify',('alpha',),mutate=lambda x,y:x[4].update(checked=256))['accepted_pass'])
 def test_each_required_fragment_cannot_be_omitted(self):
  for kind in ('ADV_ACK','ADV_PLAN','ADV_RESULT','ADV_METRIC','ADV_CHECK'):
   with self.subTest(kind=kind):self.assertFalse(verdict(drop=kind)['accepted_pass'])
 def test_task_parameter_count_and_sampling_mismatch_rejected(self):
  for index,key,value in ((1,'task',0),(1,'args','fpga,1'),(1,'expected',1),(1,'scope','full'),(2,'frames',1),(3,'swaps',1),(4,'checked',63),(4,'replayed',1),(4,'actual',0),(4,'source',1),(4,'guards',1),(4,'errors',1)):
   with self.subTest(index=index,key=key):self.assertFalse(verdict(mutate=lambda x,y:x[index].update({key:value}))['accepted_pass'])
 def test_duplicate_fragment_rejected_and_foreign_id_ignored(self):
  items,end=measured();r=AdvRequest(42,'stress',STRESS,100)
  wrong=dict(items[0],id=43);self.assertFalse(r.feed(wrong))
  for x in items:r.feed(x)
  r.feed(items[1]);self.assertFalse(r.finish(end)['accepted_pass'])
 def test_fusion_count_semantics_not_just_bounds(self):
  args=list(STRESS);args[10]=2
  def valid(items,end):items[2].update(final=50,minimum=50,maximum=64,collisions=14,merges=14)
  self.assertTrue(verdict(args=tuple(args),mutate=valid)['accepted_pass'])
  for field,value in (('minimum',49),('maximum',63),('merges',13),('collisions',13)):
   def broken(items,end):valid(items,end);items[2][field]=value
   self.assertFalse(verdict(args=tuple(args),mutate=broken)['accepted_pass'])
 def test_nonfusion_cannot_change_n_or_merge(self):
  for field in ('final','minimum','maximum','merges'):
   self.assertFalse(verdict(mutate=lambda x,y:x[2].update({field:1}))['accepted_pass'])
 def test_show_and_verify_have_expected_counts_not_invented_fps(self):
  for op,args,count in [('show',SHOW,1),('show',('key',*SHOW[1:]),2),('show',('joint',*SHOW[1:]),4),('verify',('alpha',),256),('verify',('key',),8),('verify',('joint',),4)]:
   r=verdict(op,args);self.assertTrue(r['accepted_pass']);self.assertIsNone(r['actual_fps']);self.assertEqual(r['done']['completed'],count)
 def test_control_state_is_required(self):
  r=AdvRequest(1,'enter',(),20)
  for x in control(1,'enter')[:-1]:r.feed(x)
  self.assertTrue(r.finish(done(1,'enter'))['accepted_pass'])
  r=AdvRequest(1,'exit',(),20);r.feed(parsed('ADV_ACK',id=1,op='exit',status='QUEUED'))
  self.assertFalse(r.finish(done(1,'exit',0))['accepted_pass'])

if __name__=='__main__':unittest.main()
