"""Explicit HUD presentation-policy control; no board, settings or process access."""
from pathlib import Path
import unittest
from unittest.mock import patch
import game_actions as g
import test_ui as base
import main as ui
from firmware_paths import project_root

FIELD='hud_dma_tail_enabled'

class HudDmaPolicyTests(unittest.TestCase):
 def sequence(self):
  self.sent=[];self.menus=[];self.results=[]
  return g.ActionSequence(self.sent.append,lambda:self.menus.append(True),self.results.append,clock=lambda:10.)
 def test_field_is_explicit_menu_only_boolean_with_default_zero_note(self):
  spec=g.CONFIG_BY_NAME[FIELD]
  self.assertTrue(spec.writable);self.assertTrue(spec.menu_only)
  self.assertEqual((spec.minimum,spec.maximum),(0,1))
  self.assertIn('默认0',spec.note);self.assertIn('0=原CPU',spec.note);self.assertIn('1=DMA',spec.note)
 def test_zero_and_one_wait_for_menu_and_change_only_requested_field(self):
  for value in (0,1):
   with self.subTest(value=value):
    s=self.sequence();self.assertTrue(s.start_config(FIELD,value))
    self.assertEqual(self.menus,[True]);self.assertEqual(self.sent,[])
    self.assertFalse(s.feed('OK set'));self.assertEqual(self.sent,[])
    self.assertTrue(s.feed('UI MENU'));self.assertEqual(self.sent,[f':set {FIELD} {value}\n'.encode()])
    self.assertTrue(s.feed('OK set'));self.assertFalse(s.busy)
    self.assertEqual(self.results[0]['applied'],{FIELD:value})
 def test_invalid_policy_values_never_send_or_enter_menu(self):
  s=self.sequence()
  for value in (-1,2,True,False,1.0,'1',None):
   with self.subTest(value=value),self.assertRaises(ValueError):s.start_config(FIELD,value)
  self.assertEqual((self.sent,self.menus),([],[]))
 def test_failed_menu_or_rejected_set_never_claims_policy_applied(self):
  s=self.sequence();s.start_config(FIELD,1);s.feed('ERR replay active')
  self.assertEqual(self.sent,[]);self.assertFalse(self.results[0]['success']);self.assertEqual(self.results[0]['applied'],{})
  s=self.sequence();s.start_config(FIELD,1);s.feed('UI MENU');s.feed('ERR topology requires menu')
  self.assertEqual(self.sent,[b':set hud_dma_tail_enabled 1\n']);self.assertFalse(self.results[0]['success']);self.assertEqual(self.results[0]['applied'],{})
 def test_actual_firmware_defaults_menu_guard_and_replay_binding_exist(self):
  src=project_root()/'src'
  config=(src/'game_config.c').read_text(encoding='utf-8');header=(src/'game_config.h').read_text(encoding='utf-8');game=(src/'game.c').read_text(encoding='utf-8')
  self.assertIn('game_cfg = c;hud_dma_tail_enabled=0;',config)
  self.assertIn('extern unsigned hud_dma_tail_enabled;',header)
  self.assertIn('if(!strcmp(field,"hud_dma_tail_enabled")){if(value>1)return 0;hud_dma_tail_enabled=value;return 1;}',config)
  self.assertIn('(!strcmp(field,"hud_dma_tail_enabled")||',game)
  self.assertIn('&&mode!=MENU){command_message("ERR topology requires menu");return;}',game)
  self.assertIn('return hud_dma_tail_enabled?hash_bytes(h,&hud_dma_tail_enabled,sizeof(hud_dma_tail_enabled)):h;',game)

class HudDmaNativeUiTests(unittest.TestCase):
 setUpClass=classmethod(base.NativeUIContracts.setUpClass.__func__)
 dispose_window=base.NativeUIContracts.dispose_window
 ready=base.NativeUIContracts.ready
 poll=base.NativeUIContracts.poll
 connect_fake=base.NativeUIContracts.connect_fake
 def setUp(self):
  self.save_patch=patch.object(ui.Settings,'save',side_effect=AssertionError('No actual user settings write'))
  self.save_patch.start();self.addCleanup(self.save_patch.stop)
  base.NativeUIContracts.setUp(self)
 def select(self):
  index=self.window.cfg_field.findData(FIELD);self.assertGreaterEqual(index,0);self.window.cfg_field.setCurrentIndex(index)
 def test_selecting_optional_field_starts_at_zero_and_sends_nothing(self):
  link=self.ready();before=list(link.sent);actions=list(link.actions);self.window.cfg_value.setValue(5)
  self.select();self.assertEqual(self.window.cfg_value.value(),0)
  self.assertEqual((self.window.cfg_value.minimum(),self.window.cfg_value.maximum()),(0,1))
  self.assertIn('默认0',self.window.cfg_hint.text());self.assertIn('画面与验收标准相同',self.window.cfg_hint.text())
  self.assertEqual(link.sent,before);self.assertEqual(link.actions,actions)
 def test_explicit_one_only_transmits_after_menu_ack(self):
  link=self.ready();self.select();self.window.cfg_value.setValue(1)
  with patch.object(ui.time,'monotonic',return_value=101):self.window.apply_config()
  self.assertEqual(link.sent,[]);self.assertTrue(self.window.game_sequence.busy)
  self.assertEqual(link.actions[-2:],[('touhou_LAB','menu',True),('touhou_LAB','menu',False)])
  self.window.game_sequence.feed('UI MENU');self.assertEqual(link.sent,[b':set hud_dma_tail_enabled 1\n'])
  self.window.game_sequence.feed('OK set');self.assertFalse(self.window.game_sequence.busy)
  self.assertEqual(self.window.game_sequence.applied,{FIELD:1})
 def test_explicit_zero_uses_same_confirmed_transaction_without_restart(self):
  link=self.ready();self.select()
  with patch.object(ui.time,'monotonic',return_value=101):self.window.apply_config()
  self.window.game_sequence.feed('UI MENU');self.assertEqual(link.sent,[b':set hud_dma_tail_enabled 0\n'])
  self.window.game_sequence.feed('OK set');self.assertEqual(self.window.game_sequence.applied,{FIELD:0})
  self.assertFalse(any(b':mode' in row or b':limit' in row for row in link.sent))

if __name__=='__main__':unittest.main()
