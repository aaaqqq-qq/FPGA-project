"""Per-run policy proof and native handshake contracts. All serial links are fakes."""
import copy,unittest
from unittest.mock import patch
from control_core import parse_capabilities
from game_load_protocol import GameLoadRequest,parse_game_load_reply,boundary_rows
from game_load_panel import GameLoadPanel
import test_game_load as old
import test_ui as base
import main as ui
from test_ui_v23 import STAT

def caps(value=1,proof=True):return parse_capabilities(old.CAPS+f' hud_dma={value}'+(' hud_dma_proof=1'if proof else''))
def packets(value=1):
 result=[]
 for item in old.sample():
  raw=item['raw']
  if item['kind_line']in('GLOAD_ACK','GLOAD_READY','GLOAD_DETAIL'):raw+=' hud_dma='+str(value)
  result.append(parse_game_load_reply(raw))
 return result
def finish(items=None,cap=None):
 req=GameLoadRequest(42,old.ARGS,capabilities=cap if cap is not None else caps(),expected_pipeline=False)
 rows=items or packets()
 for item in rows[:-1]:req.feed(item)
 return req.finish(rows[-1])
class HudPolicyWireTests(unittest.TestCase):
 def test_new_capability_requires_explicit_boolean_policy(self):
  self.assertEqual(caps()['hud_dma'],1);self.assertEqual(caps()['hud_dma_proof'],1)
  for extra in (' hud_dma_proof=1',' hud_dma=2 hud_dma_proof=1',' hud_dma=1 hud_dma_proof=2',' hud_dma=1 hud_dma=0 hud_dma_proof=1'):
   self.assertIsNone(parse_capabilities(old.CAPS+extra))
 def test_legacy_capability_and_old_results_remain_unverified_for_policy(self):
  legacy=parse_capabilities(old.CAPS);self.assertNotIn('hud_dma_proof',legacy)
  r=finish(old.sample(),legacy);self.assertTrue(r['accepted_pass']);self.assertFalse(r['hud_policy_verified'])
 def test_c281_pre_caps_without_run_proof_cannot_verify_policy(self):
  r=finish(old.sample(),caps(1,False));self.assertTrue(r['accepted_pass']);self.assertFalse(r['hud_policy_verified'])
 def test_new_zero_and_one_require_and_verify_all_three_phases(self):
  for value in (0,1):
   r=finish(packets(value),caps(value));self.assertTrue(r['accepted_pass']);self.assertTrue(r['hud_policy_verified']);self.assertEqual(r['hud_policy_evidence']['expected'],value)
 def test_each_missing_phase_field_fails_new_proof(self):
  for index in (0,1,3):
   rows=packets();rows[index].pop('hud_dma');r=finish(rows)
   self.assertFalse(r['accepted_pass']);self.assertFalse(r['hud_policy_verified']);self.assertTrue(r['hud_policy_evidence']['errors'])
 def test_reset_to_zero_after_requested_one_is_explicit_failure(self):
  r=finish(packets(0),caps(1));self.assertFalse(r['accepted_pass']);self.assertFalse(r['hud_policy_verified']);self.assertEqual(r['hud_policy_evidence']['ack'],0)
 def test_policy_drift_each_phase_fails_and_is_not_searchable(self):
  for index in (0,1,3):
   rows=packets();rows[index]['hud_dma']=0;r=finish(rows)
   self.assertFalse(r['accepted_pass']);self.assertFalse(r['hud_policy_verified']);self.assertFalse(r['search_eligible'])
 def test_malformed_enum_duplicate_and_string_rejected_by_wire_parser(self):
  for item in packets():
   if item['kind_line']not in('GLOAD_ACK','GLOAD_READY','GLOAD_DETAIL'):continue
   for suffix in ('2','-1','true','1.0'):
    self.assertIsNone(parse_game_load_reply(item['raw'].replace('hud_dma=1','hud_dma='+suffix)))
   self.assertIsNone(parse_game_load_reply(item['raw']+' hud_dma=0'))
 def test_status_policy_is_strict_but_old_status_still_parses(self):
  raw='GLOAD_ACK id=12 op=status status=OK running=0 current=0'
  self.assertIsNotNone(parse_game_load_reply(raw));self.assertEqual(parse_game_load_reply(raw+' hud_dma=1')['hud_dma'],1)
  self.assertIsNone(parse_game_load_reply(raw+' hud_dma=2'))
 def test_later_good_detail_cannot_erase_earlier_policy_drift(self):
  rows=packets();bad=copy.deepcopy(rows[3]);bad['hud_dma']=0;rows.insert(3,bad)
  r=finish(rows);self.assertFalse(r['accepted_pass']);self.assertFalse(r['hud_policy_verified'])
 def test_policy_proof_does_not_hide_existing_performance_failure(self):
  rows=packets();rows[2]['us']=2000000;rows[2]['scans']=120;rows[2]['missed']=60;rows[2]['gap']=2;rows[-1]['status']='FAIL';rows[-1]['reason']='timing'
  r=finish(rows);self.assertTrue(r['hud_policy_verified']);self.assertFalse(r['accepted_pass']);self.assertEqual(r['actual_fps'],30.)
 def test_boundaries_never_mix_policy_versions_or_choices(self):
  rows=[finish(packets(0),caps(0)),finish(packets(1),caps(1)),finish(old.sample(),parse_capabilities(old.CAPS))]
  bounds=boundary_rows(rows);self.assertEqual(len(bounds),3)
  self.assertEqual([r['hud_policy_verified']for r in bounds],[True,True,False])
 def test_missing_expected_capability_policy_cannot_be_verified(self):
  c=caps();c.pop('hud_dma');r=finish(cap=c);self.assertFalse(r['accepted_pass']);self.assertFalse(r['hud_policy_verified'])

class HudPolicyPanelTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.app=base.QApplication.instance()or base.QApplication([])
 def test_status_policy_mismatch_or_missing_keeps_run_locked(self):
  for value in (None,0):
   p=GameLoadPanel();p.set_capabilities(caps());p.set_available(True);i=p._status_id
   packet=old.item('GLOAD_ACK',id=i,op='status',status='OK',running=0,current=0)
   if value is not None:packet['hud_dma']=value
   p.ingest(packet);self.assertTrue(p.uncertain);self.assertFalse(p.start_button.isEnabled());p.deleteLater()
 def test_matching_status_unlocks_explicitly_selected_policy(self):
  p=GameLoadPanel();p.set_capabilities(caps());p.set_available(True);i=p._status_id
  p.ingest(old.item('GLOAD_ACK',id=i,op='status',status='OK',running=0,current=0,hud_dma=1));self.assertFalse(p.uncertain);self.assertTrue(p.start_button.isEnabled());p.deleteLater()
 def test_legacy_result_is_visible_but_never_labelled_policy_verified(self):
  p=GameLoadPanel();p._case={};r=finish(old.sample(),parse_capabilities(old.CAPS));p._finish(r,False)
  self.assertIn('不能用于设置对比验收',p.status.text());self.assertIn('设置未核对',p.table.item(0,0).text());self.assertEqual(p.table.item(0,6).text(),'60.000');p.deleteLater()
 def test_valid_policy_failure_remains_failure_in_ui(self):
  rows=packets();rows[2]['us']=2000000;rows[-1]['status']='FAIL';rows[-1]['reason']='timing'
  p=GameLoadPanel();p._case={};p._finish(finish(rows),False)
  self.assertIn('本项未通过',p.status.text());self.assertIn('实际绘图设置已核对：1',p.status.text());self.assertEqual(p.table.item(0,6).text(),'30.000');p.deleteLater()

class PolicyLink(old.GameLoadOwnerLink):
 def __init__(self):
  super().__init__();self.policy=0;self.lines=[old.CAPS+' hud_dma=0 hud_dma_proof=1']
 def send(self,payload):
  super().send(payload)
  if payload.startswith(b':gload status ') and self.lines and self.lines[-1].startswith('GLOAD_ACK '):self.lines[-1]+=' hud_dma='+str(self.policy)

class HudPolicyHandshakeTests(unittest.TestCase):
 setUpClass=classmethod(base.NativeUIContracts.setUpClass.__func__)
 dispose_window=base.NativeUIContracts.dispose_window
 poll=base.NativeUIContracts.poll
 def setUp(self):
  base.NativeUIContracts.setUp(self)
  clock=patch.object(ui.time,'monotonic',return_value=100.);clock.start();self.addCleanup(clock.stop)
  p=patch.object(ui.Settings,'save',side_effect=AssertionError('No real settings writes'));p.start();self.addCleanup(p.stop)
  self.link=PolicyLink();self.window.link=self.link
  for _ in range(5):self.poll()
  self.link.lines=[STAT];self.poll();self.assertTrue(self.window.game_ready())
 def apply(self,value=1):
  self.window.cfg_field.setCurrentIndex(self.window.cfg_field.findData('hud_dma_tail_enabled'));self.window.cfg_value.setValue(value)
  with patch.object(ui.time,'monotonic',return_value=101.):self.window.apply_config()
  self.link.lines=['UI MENU','OK set'];self.poll(101.)
 def test_setter_ack_sends_fresh_hello_and_blocks_until_new_caps(self):
  self.apply();self.assertEqual(self.link.sent[-2:],[b':set hud_dma_tail_enabled 1\n',b':hello\n']);self.assertFalse(self.window.protocol_ready)
  before=list(self.link.sent);self.window.gload.start();self.assertEqual(self.link.sent,before)
  self.link.policy=1;self.link.lines=[old.CAPS+' hud_dma=1 hud_dma_proof=1'];self.poll(102.)
  self.assertTrue(self.window.protocol_ready);self.assertIsNone(self.window._hud_policy_expected);self.assertEqual(self.window.gload.identity['hud_dma'],1)
 def test_mismatched_actual_caps_disconnects_and_never_runs(self):
  self.apply();self.link.lines=[old.CAPS+' hud_dma=0 hud_dma_proof=1'];self.poll(102.)
  self.assertIsNone(self.window.link);self.assertTrue(self.link.closed);self.assertFalse(any(p.startswith(b':gload run')for p in self.link.sent))
 def test_missing_policy_caps_cannot_confirm_setter(self):
  self.apply();self.link.lines=[old.CAPS];self.poll(102.);self.assertIsNone(self.window.link)
 def test_handshake_timeout_disconnects_without_guessing_policy(self):
  self.apply();self.poll(112.);self.assertIsNone(self.window.link);self.assertIn('确认超时',self.window.footer.text())
 def test_explicit_zero_also_gets_fresh_capability_confirmation(self):
  self.apply(0);self.assertFalse(self.window.protocol_ready);self.assertEqual(self.link.sent[-1],b':hello\n')
  self.link.lines=[old.CAPS+' hud_dma=0 hud_dma_proof=1'];self.poll(102.);self.assertTrue(self.window.protocol_ready)

if __name__=='__main__':unittest.main()
