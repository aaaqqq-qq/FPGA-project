"""Independent host audit of real-state accounting; fixtures do not prove FPS."""
import copy,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from pipeline_evidence import *
from game_load_protocol import GameLoadRequest,parse_game_load_reply
import test_game_load as legacy

def packet(kind,**kw):
    raw=kind+' '+' '.join(f'{k}={v}' for k,v in kw.items())
    result=parse_pipeline_reply(raw)
    assert result is not None,raw
    return result

def pipe_fixture(args=legacy.ARGS):
    b,m,n,size,frames,seed=args
    ack,ready,stat,detail,done=legacy.sample(args=args)
    ack['pipe']=ready['pipe']=detail['pipe']=1;ready['prime']=1
    detail['runtime']=frames+1
    prime=packet('GLOAD_PIPE',id=42,phase='prime',pipe=1,warmup=2,prime_us=9000,
        prime_logic=1,prime_present=1,live_start=0,live_end=1,presented_start=0,
        presented_end=0,input_start=0,input_end=1,n_start=n,n_end=n,r_epoch=3,
        snap_epoch=3,m_epoch=1,latency=1)
    motion=packet('MOTION_DIAG',id=42,submitted=frames,completed=frames,cycles_last=650000,read_last=660000,write_last=320000)
    final=packet('GLOAD_PIPE',id=42,phase='final',pipe=1,frames=frames,presented_delta=frames,
        logic_committed_delta=frames,live_epoch=frames+1,presented_epoch=frames,
        input_epoch=frames,frame_epoch=frames+3,snap_epoch=frames+3,latency=1,backlog=0,fallback=0)
    view=packet('GLOAD_VIEW',id=42,phase='final',state_epoch=frames,input_epoch=frames,n=n,b=b,m=m,cfg=123,
        mode=1,hw=1,active=1,paused=0,hp=85,score=200,lv=2,hit=1,grazes=5,graze_total=50,
        quality=1,lod=0,visual=2,bg=1,opaque=0,alpha=224,key=1,alpha_enable=1,draw_n=n,key_rgb=16711935)
    items=[ack,prime,ready,stat,detail,motion,final,view,done]
    # Feed exactly what a real UART line parser produces, including ACK pipe.
    return [parse_game_load_reply(x['kind_line']+' '+' '.join(f'{k}={v}' for k,v in x.items() if k not in ('kind_line','raw'))) for x in items]

def evaluate(items=None,args=legacy.ARGS,expected=True):
    r=GameLoadRequest(42,args,expected_pipeline=expected)
    entries=items or pipe_fixture(args)
    for x in entries[:-1]:r.feed(x)
    return r.finish(entries[-1])

class PipelineWireTests(unittest.TestCase):
    def test_valid_fixture_is_short_observation_not_physical_evidence(self):
        r=evaluate();self.assertTrue(r['accepted_pass'],r['errors']);self.assertFalse(r['long_60fps_pass'])
        self.assertEqual(r['pipeline_evidence']['final']['live_epoch'],61)
    def test_both_hard_targets_and_long_duration_keep_all_in_window_steps(self):
        for side,n in ((8,20000),(32,5000)):
            for frames in (60,600,36000):
                args=(6,12,n,side,frames,123456789);r=evaluate(args=args)
                self.assertTrue(r['accepted_pass'],r['errors'])
                self.assertEqual(r['long_60fps_pass'],frames==36000)
    def test_missing_each_proof_rejects_never_fallback_pass(self):
        for i in (1,5,6,7):
            p=pipe_fixture();p.pop(i);self.assertFalse(evaluate(p)['accepted_pass'])
    def test_one_less_logic_step_cannot_masquerade_as_pipeline_speedup(self):
        for index,key,value in ((6,'logic_committed_delta',59),(6,'presented_delta',59),(5,'completed',59),(5,'submitted',59)):
            p=pipe_fixture();p[index][key]=value;self.assertFalse(evaluate(p)['accepted_pass'])
    def test_future_state_must_not_count_as_displayed(self):
        for key in ('presented_epoch','input_epoch'):
            p=pipe_fixture();p[6][key]=61;self.assertFalse(evaluate(p)['accepted_pass'])
        p=pipe_fixture();p[7]['state_epoch']=61;self.assertFalse(evaluate(p)['accepted_pass'])
    def test_exact_prime_is_explicit_and_separate(self):
        for key,value in [('prime_logic',0),('prime_logic',2),('prime_present',0),('prime_present',2),('live_start',1),('live_end',2),('presented_end',1),('input_end',2),('n_start',4999),('prime_us',0)]:
            p=pipe_fixture();p[1][key]=value;self.assertFalse(evaluate(p)['accepted_pass'],key)
        p=pipe_fixture();p[1],p[2]=p[2],p[1];self.assertFalse(evaluate(p)['accepted_pass'])
        p=pipe_fixture();p.insert(2,copy.deepcopy(p[1]));self.assertFalse(evaluate(p)['accepted_pass'])
    def test_no_stale_snapshot_mismatched_motion_or_bad_visuals(self):
        for index,key,value in [(1,'snap_epoch',2),(6,'snap_epoch',62),(5,'completed',0),(5,'cycles_last',0),(5,'read_last',0),(5,'write_last',0),(4,'runtime',60),(7,'cfg',124),(7,'n',4096),(7,'b',3),(7,'m',0),(7,'alpha',255),(7,'key',0),(7,'opaque',1),(7,'alpha_enable',0),(7,'draw_n',0),(7,'key_rgb',0),(7,'quality',2),(7,'hp',101),(7,'lv',6),(6,'latency',0),(6,'fallback',1),(6,'backlog',1),(6,'backlog',2)]:
            p=pipe_fixture();p[index][key]=value;self.assertFalse(evaluate(p)['accepted_pass'],key)
    def test_each_path_declaration_and_actual_capability_required(self):
        for index in (0,2,4):
            p=pipe_fixture();p[index]['pipe']=0;self.assertFalse(evaluate(p)['accepted_pass'])
        self.assertFalse(evaluate(expected=False)['accepted_pass'])
        self.assertFalse(evaluate(legacy.sample(),expected=True)['accepted_pass'])
        self.assertTrue(evaluate(legacy.sample(),expected=None)['accepted_pass'])
    def test_final_must_arrive_before_done(self):
        p=pipe_fixture();p.pop(7);self.assertFalse(evaluate(p)['accepted_pass'])
    def test_samples_are_monotonic_and_view_pairs_with_same_state(self):
        p=pipe_fixture(args=(*legacy.ARGS[:4],600,legacy.ARGS[5]))
        s=copy.deepcopy(p[6]);s.update(phase='sample',frames=60,presented_delta=60,logic_committed_delta=60,live_epoch=61,presented_epoch=60,input_epoch=60,frame_epoch=63,snap_epoch=63)
        v=copy.deepcopy(p[7]);v.update(phase='sample',state_epoch=60,input_epoch=60)
        p[5:5]=[s,v];args=(*legacy.ARGS[:4],600,legacy.ARGS[5])
        self.assertTrue(evaluate(p,args=args)['accepted_pass'])
        p.insert(7,copy.deepcopy(s));self.assertFalse(evaluate(p,args=args)['accepted_pass'])
    def test_parser_rejects_duplicates_negative_string_unknown_overflow(self):
        for item in pipe_fixture()[1:8]:
            if item['kind_line'] not in ('GLOAD_PIPE','GLOAD_VIEW','MOTION_DIAG'):continue
            raw=item['raw']
            for bad in (raw+' id=42',raw+' rogue=0',raw.replace('id=42','id=-1'),raw.replace('id=42','id=4294967296'),raw.replace('id=42','id=true'),raw+' fragment'):
                self.assertIsNone(parse_pipeline_reply(bad),bad)
            self.assertEqual(parse_game_load_reply(raw),parse_pipeline_reply(raw))
    def test_missing_pipeline_proof_never_becomes_search_bound(self):
        p=pipe_fixture();p[3].update(us=2000000,scans=120,gap=2,missed=60);p[-1].update(status='FAIL',reason='timing');p.pop(5)
        r=evaluate(p);self.assertFalse(r['search_eligible']);self.assertFalse(r['accepted_pass'])
    def test_independent_impossible_motion_metric_supplement(self):
        for values in ({'cycles_last':1,'read_last':128,'write_last':128},
                       {'cycles_last':650000,'read_last':129,'write_last':129},
                       {'cycles_last':650000,'read_last':4241,'write_last':129},
                       {'cycles_last':10,'read_last':4224,'write_last':128}):
            p=pipe_fixture();p[5].update(values);self.assertFalse(evaluate(p)['accepted_pass'])
    def test_cancel_retains_real_partial_steps_without_certifying_full_pass(self):
        p=pipe_fixture();p[3].update(frames=7,us=116667,swaps=7,scans=7)
        p[4].update(frames=7,ticks=7,runtime=8)
        p[5].update(submitted=7,completed=7)
        p[6].update(frames=7,presented_delta=7,logic_committed_delta=7,live_epoch=8,
            presented_epoch=7,input_epoch=7,frame_epoch=10,snap_epoch=10)
        p[7].update(state_epoch=7,input_epoch=7);p[-1].update(status='CANCEL',reason='cancel')
        r=evaluate(p);self.assertFalse(r['accepted_pass']);self.assertEqual(r['status'],'CANCEL')
        self.assertEqual(r['pipeline_validation_errors'],[])

class PipelinePanelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=legacy.base.QApplication.instance() or legacy.base.QApplication(['pipe-tests'])
    setUp=legacy.GameLoadPanelTests.setUp
    tearDown=legacy.GameLoadPanelTests.tearDown
    def start_pipe(self):
        caps=legacy.parse_capabilities(legacy.CAPS+' batch32=1 motion=1 pref=1 pipe=1 pref8=1')
        self.p.set_capabilities(caps);self.p.set_available(True)
        self.p.ingest(legacy.item('GLOAD_ACK',id=self.p._status_id,op='status',status='OK',running=0,current=0))
        self.p.load_target(8);self.p.start();self.p.menu_ready(True)
        self.assertTrue(self.p._request.expected_pipeline)
        return self.p
    def feed_fixture(self,p):
        i=p._request.request_id
        for x in pipe_fixture(p._request.args):
            raw=x['raw'].replace('id=42 ',f'id={i} ')
            p.ingest(parse_game_load_reply(raw))
    def test_native_panel_holds_request_until_all_proof_then_done(self):
        p=self.start_pipe();self.feed_fixture(p)
        self.assertTrue(p.results[-1]['accepted_pass'],p.results[-1]['errors'])
        saved=p.export_document()
        self.assertEqual(saved['schema'],'ti60_game_load_ui_v2_pipe5')
        self.assertEqual(saved['results'][-1]['pipeline_evidence']['motion']['completed'],60)
        self.assertIn('已显示 60 帧',p.pipeline_notice.text())
        self.assertIn('计算完成 60 步',p.pipeline_notice.text())
    def test_corrupt_then_valid_proof_cannot_be_laundered(self):
        p=self.start_pipe();p.reject_wire(f'GLOAD_PIPE id={p._request.request_id} pipe=true')
        self.feed_fixture(p);self.assertFalse(p.results[-1]['accepted_pass'])
    def test_actual_new_caps_validate_bits_and_defaults(self):
        self.assertEqual(legacy.parse_capabilities(legacy.CAPS)['pipe'],0)
        for flag in ('pipe','pref8'):
            self.assertIsNone(legacy.parse_capabilities(legacy.CAPS+f' {flag}=2'))

class PipelineOfflineAuditTests(unittest.TestCase):
    def test_exact_wire_proof_survives_raw_log_audit_without_qt_device(self):
        import tempfile,importlib.util
        path=Path(__file__).resolve().parents[1]/'evidence/reanalyse_game_load.py'
        spec=importlib.util.spec_from_file_location('pipe_raw_audit',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        caps=legacy.CAPS+' batch32=1 motion=1 pref=1 pipe=1 pref8=1'
        text='RX '+caps+'\nTX :gload run 42 '+' '.join(map(str,legacy.ARGS))+'\n'
        text+=''.join('RX '+x['raw']+'\n' for x in pipe_fixture())
        with tempfile.TemporaryDirectory(prefix='pipe5_wire_') as tmp:
            p=Path(tmp)/'raw.log';p.write_text(text,encoding='utf-8')
            source,records,issues,controls=module.analyse_source(p)
            self.assertFalse(issues,issues);self.assertEqual(len(records),1)
            self.assertTrue(records[0]['accepted_session_pass'],records[0]['production_result']['errors'])
            p.write_text(text.replace('RX MOTION_DIAG','IGNORED MOTION_DIAG'),encoding='utf-8')
            _,bad,_,_=module.analyse_source(p)
            self.assertFalse(bad[0]['accepted_session_pass'])

if __name__=='__main__':unittest.main()
