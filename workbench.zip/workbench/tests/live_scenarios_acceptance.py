"""Opt-in current-board test of application actions; no JTAG/Flash/download."""
from pathlib import Path
import json,sys,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
if '--run-hardware' not in sys.argv:raise SystemExit('NOT_RUN: explicit --run-hardware required')
import bootstrap
bootstrap.prepare_runtime()
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
from PySide6.QtGui import QFont,QFontDatabase
import main
from control_core import parse_telemetry,mode_command,pause_command
app=QApplication([]);QFontDatabase.addApplicationFont('C:/Windows/Fonts/msyh.ttc');app.setFont(QFont('Microsoft YaHei UI',10));app.setStyleSheet(main.STYLE)
w=main.MainWindow(smoke=True);w.navigate(5);w.show()
out=ROOT/'evidence/v21/live_scenarios';out.mkdir(parents=True,exist_ok=True)
results=[];acks=[];events=[];state='connect';deadline=time.monotonic()+12;cursor=0;result=1;expected_boss=0;operation_index=0
original=w.game_sequence.done
def done(value):events.append(value.copy());print(json.dumps(value,ensure_ascii=False),flush=True);original(value)
w.game_sequence.done=done
operations=[('preset',4,6),('preset',6,12),('preset',3,0),('enemy',3,5),('restore',3,0)]
def finish(success,error=''):
    global result
    timer.stop();result=0 if success else 1
    w.grab().save(str(out/'final.png'))
    report={'status':'PASS' if success else 'FAIL','error':error,'tests':results,'transactions':acks,'log':str(w.log_path),'hardware_scope':'UART current LAB1 only; no new download, no JTAG or Flash','final_state':'normal game paused, 3 Boss / 0 fairies' if success else 'inspect log'}
    (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False),flush=True);w.disconnect();QTimer.singleShot(200,app.quit)
def tick():
    global state,deadline,cursor,expected_boss,operation_index
    if time.monotonic()>deadline:finish(False,'timeout '+state);return
    if state=='connect':
        if not w.game_ready():return
        state='launch'
    if state=='launch':
        if operation_index==len(operations):
            w.control_send(pause_command(1));state='final_pause';deadline=time.monotonic()+8;cursor=len(w.session_lines);return
        name,boss,enemies=operations[operation_index];expected_boss=boss;cursor=len(w.session_lines)
        if name=='preset':w.start_preset(boss,enemies,0)
        else:
            w.cfg_field.setCurrentIndex(w.cfg_field.findData('enemy_count'));w.cfg_value.setValue(enemies);w.apply_config()
        state='ack';deadline=time.monotonic()+20;return
    if state=='ack':
        if not events:return
        value=events.pop(0);acks.append(value)
        if not value['success']:finish(False,'transaction '+str(value));return
        name,boss,enemies=operations[operation_index]
        if name!='preset':w.control_send(mode_command(0))
        cursor=len(w.session_lines);state='stat';deadline=time.monotonic()+10;return
    if state in ('stat','final_pause'):
        for line in w.session_lines[cursor:]:
            if 'STAT ' not in line:continue
            d=parse_telemetry(line[line.index('STAT '):],'touhou_LAB')
            if not d:continue
            val=d['values']
            if state=='stat' and val.get('mode')==1 and val.get('bosses')==expected_boss:
                name,boss,enemies=operations[operation_index]
                results.append({'operation':name,'bosses':boss,'enemy_count_requested_and_ACK':enemies,'mode_observed':val['mode'],'bosses_observed':val['bosses'],'mobs_observed':val['mobs'],'scope':'enemy count is acknowledged config; mobs is current live count'})
                w.grab().save(str(out/(str(operation_index)+'_'+name+'.png')));operation_index+=1;state='launch';deadline=time.monotonic()+5;return
            if state=='final_pause' and val.get('paused')==1 and val.get('keys')==0:
                results.append({'operation':'final_pause','status':'PASS','bosses':val['bosses'],'keys':val['keys']});finish(True);return
        cursor=len(w.session_lines)
timer=QTimer();timer.timeout.connect(tick);timer.start(100)
QTimer.singleShot(300,w.toggle_connection)
app.exec();raise SystemExit(result)
