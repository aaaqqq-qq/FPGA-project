"""Frozen reviewer counterexamples, including defects found outside root tests."""
import json,unittest
from pathlib import Path
from game_load_protocol import GameLoadRequest,parse_game_load_reply,boundary_rows
import test_pipeline_evidence as support

class IndependentWireRegressions(unittest.TestCase):
    def test_all_frozen_independent_cases_follow_expected_outcomes(self):
        d=json.loads((Path(__file__).parent/'fixtures/pipe5_independent_wires.json').read_text(encoding='utf-8'))
        self.assertTrue(d['synthetic_only_not_board_evidence'])
        for case in d['cases']:
            with self.subTest(case=case['case']):
                r=GameLoadRequest(42,tuple(d['args']),expected_pipeline=True)
                # The reviewed draft allowed backlog1; final FW5 explicitly
                # requires backlog0. Normalize ONLY this unrelated control
                # field so each old counterexample still tests its own defect.
                packets=[parse_game_load_reply(x.replace('backlog=1 ','backlog=0 ')) for x in case['wire']]
                self.assertTrue(all(packets))
                for x in packets[:-1]:r.feed(x)
                actual=r.finish(packets[-1])
                self.assertEqual(actual['accepted_pass'],case['expected_pass'],actual['errors'])
    def test_serial_and_pipeline_boundary_records_are_not_combined(self):
        old=support.legacy.result();new=support.evaluate()
        self.assertEqual(len(boundary_rows([old,new])),2)
    def test_capability_snapshot_is_per_request_not_export_time(self):
        caps={'pipe':1,'pref8':1};r=GameLoadRequest(42,support.legacy.ARGS,expected_pipeline=True,capabilities=dict(caps))
        caps['pipe']=0
        items=support.pipe_fixture()
        for item in items[:-1]:r.feed(item)
        out=r.finish(items[-1]);self.assertTrue(out['accepted_pass']);self.assertEqual(out['capabilities']['pipe'],1)

if __name__=='__main__':unittest.main()
