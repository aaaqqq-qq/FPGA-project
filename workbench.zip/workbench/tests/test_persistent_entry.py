"""Full-Flash entry guards. Temporary fixtures only; never starts a helper."""
from pathlib import Path
import hashlib
import json
import os
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import control_core as c


class PersistentEntryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def bundle(self, name="persistent", state="READY", marker=True):
        root = self.root / name
        (root / "projects/touhou_LAB").mkdir(parents=True)
        (root / "tools").mkdir(); (root / "tools/local_paths.json").write_text("{}")
        (root / "START_MENU.py").write_text("# reviewed full-flash fixture\n")
        (root / "out").mkdir(); (root / "out/manifest.json").write_text(json.dumps(dict(
            release_id="GAME60_PIPELINE_5",firmware="LAB23",clock_mhz=100,boot_marker=c.BOOT_MARKER,
            required_capabilities={"adv":1,"img":1,"perf":1,"game_load":1,"gsizes":7,"batch32":1,"motion":1,"pref":1,"pipe":1,"pref8":1},elf={"sha256":c.CURRENT_ELF_SHA256},platform={"bit_sha256":c.CURRENT_PLATFORM_SHA256})))
        if marker:
            (root / "persistent_entry.json").write_text(json.dumps(dict(firmware="LAB23",kind="full_flash", profile="touhou_LAB",
                state=state, manifest="out/manifest.json", ram_fallback_allowed=False, clock_mhz=100,
                release_id="GAME60_PIPELINE_5",required_capabilities={"adv":1,"img":1,"perf":1,"game_load":1,"gsizes":7,"batch32":1,"motion":1,"pref":1,"pipe":1,"pref8":1})))
        return root

    def test_old_saved_bundle_cannot_shadow_persistent_default(self):
        old = self.bundle("TI60_LAB_20261101", marker=False)
        new = self.bundle()
        with patch.object(c, "__file__", str(self.root / "app" / "control_core.py")), patch.object(c, "DEFAULT_BUNDLE", new), patch.dict(os.environ, {"TI60_BUNDLE_ROOT": str(old)}):
            self.assertEqual(c.discover_bundle(old), new.resolve())
        with patch.object(c, "__file__", str(self.root / "app" / "control_core.py")), patch.object(c, "DEFAULT_BUNDLE", self.root / "missing"), patch.dict(os.environ, {"TI60_BUNDLE_ROOT": str(old)}):
            self.assertIsNone(c.discover_bundle(old))

    def test_marker_missing_wrong_kind_or_ram_fallback_rejected(self):
        root = self.bundle(marker=False)
        with self.assertRaises(ValueError): c.build_command(root, "touhou_LAB", False, sys.executable)
        base = dict(firmware="LAB23",kind="full_flash", state="READY", ram_fallback_allowed=False)
        for key, value in (("kind", "temporary"), ("state", "UNKNOWN"), ("ram_fallback_allowed", True),
                           ("profile", "touhou_R8"), ("clock_mhz", 125), ("manifest", "../old/manifest.json")):
            (root / "persistent_entry.json").write_text(json.dumps(dict(base, **{key: value})))
            with self.subTest(key=key), self.assertRaises(ValueError):
                c.build_command(root, "touhou_LAB", True, sys.executable)

    def test_preparing_and_check_only_allow_only_offline_check(self):
        for state in ("PREPARING", "CHECK_ONLY"):
            root = self.bundle(state, state=state)
            self.assertTrue(c.persistent_bundle_available(root))
            self.assertFalse(c.persistent_program_available(root))
            with patch.object(c, "load_persistent_profile") as validate:
                command = c.build_command(root, "touhou_LAB", True, sys.executable)
                self.assertIn("--check", command)
                validate.assert_called_once_with(root / "out/manifest.json", reviewed=True)
            with patch.object(c, "load_persistent_profile") as validate, self.assertRaises(ValueError):
                c.build_command(root, "touhou_LAB", False, sys.executable)
            validate.assert_not_called()

    def test_ready_command_is_fixed_lab_and_never_uses_old_ram_helper(self):
        root = self.bundle()
        with patch.object(c, "load_persistent_profile") as validate:
            command = c.build_command(root, "touhou_LAB", False, sys.executable)
        self.assertTrue(c.persistent_program_available(root))
        self.assertEqual(command[-3:], [str(root / "START_MENU.py"), "--game", "touhou_LAB"])
        self.assertNotIn("--check", command)
        self.assertFalse(any("safe_phase_test" in word for word in command))
        for old in ("touhou_R8", "touhou_R7p1", "mario_HD32_R1", "metal_FRONTLINE_v31"):
            with self.subTest(old=old), self.assertRaises(ValueError):
                c.build_command(root, old, False, sys.executable)

    def test_invalid_full_image_has_no_ram_fallback(self):
        root = self.bundle()
        with patch.object(c, "load_persistent_profile", side_effect=ValueError("wrong complete-image hash")):
            with self.assertRaisesRegex(ValueError, "complete-image"):
                c.build_command(root, "touhou_LAB", False, sys.executable)

    def test_optional_launcher_and_manifest_identity_pins_reject_changes(self):
        root = self.bundle()
        marker = json.loads((root / "persistent_entry.json").read_text())
        marker.update(entry_sha256=hashlib.sha256((root / "START_MENU.py").read_bytes()).hexdigest(),
                      manifest_sha256=hashlib.sha256((root / "out/manifest.json").read_bytes()).hexdigest())
        (root / "persistent_entry.json").write_text(json.dumps(marker))
        with patch.object(c, "load_persistent_profile"):
            c.build_command(root, "touhou_LAB", True, sys.executable)
            (root / "START_MENU.py").write_text("# changed to old entry")
            with self.assertRaises(ValueError): c.build_command(root, "touhou_LAB", True, sys.executable)


if __name__ == "__main__": unittest.main(verbosity=2)

