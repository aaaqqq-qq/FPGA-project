"""Offline draft-profile checks; fake byte files only, no hardware imports."""
from pathlib import Path
import hashlib
import json
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch
import os
import zlib

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import persistent_profile as p

# Fixtures use mocked HW evidence only; actual HW integration is a separate test.
tempfile.tempdir = os.environ.get("TI60_TEST_TMP", "E:/Ti60_test_tmp")
Path(tempfile.tempdir).mkdir(parents=True, exist_ok=True)


class PersistentProfileTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.raws = {"firmware_elf": b"test-elf", "platform_bitstream": b"test-bit",
                     "bootloader_stage": b"test-boot"}
        image = bytearray(b"\xff" * 1024)
        image[0:8] = b"test-bit"; image[256:265] = b"test-boot"; image[512:520] = b"test-elf"
        self.raws["full_flash_image"] = bytes(image)
        specs = {}
        for role, data in self.raws.items():
            name = role + ".bin"; (self.root / name).write_bytes(data)
            specs[role] = dict(path=name, sha256=self.sha(data), size_bytes=len(data))
        def region(name, component, offset, length):
            return dict(name=name, component=component, offset=offset, length=length,
                        sha256=self.sha(image[offset:offset + length]))
        self.data = dict(schema=p.SCHEMA, profile_id="touhou_LAB", board="Ti60F225I3-V4",
                         release="LAB23", clock_mhz=100, storage="spi_flash", boot_marker=p.BOOT_MARKER,
                         artifacts=specs, verification={key: True for key in
                         ("full_image_hash_required", "flash_readback_required", "new_boot_required", "cold_boot_required")},
                         flash=dict(capacity_bytes=1024, erase_block_bytes=256,
                                    program_ranges=[region("platform", "platform", 0, 8),
                                                    region("bootloader", "bootloader", 256, 9),
                                                    region("firmware", "firmware", 512, 8)],
                                    protected_ranges=[region("factory", "reserved", 768, 256)]))
        self.manifest = self.root / "persistent.json"

    @staticmethod
    def sha(data): return hashlib.sha256(data).hexdigest()

    def validate(self, **options):
        self.manifest.write_text(json.dumps(self.data), encoding="utf-8")
        return p.validate_profile(self.manifest, expected_flash_capacity=1024,
                                  expected_elf_sha256=self.sha(self.raws["firmware_elf"]),
                                  expected_platform_sha256=self.sha(self.raws["platform_bitstream"]), **options)

    def test_offline_valid_never_claims_flash_or_boot_pass(self):
        result = self.validate()
        self.assertEqual(result.status, "OFFLINE_VALID_ONLY")
        self.assertTrue(result.needs_root_review)
        self.assertFalse(result.flash_programmed)
        self.assertFalse(result.flash_readback_verified)
        self.assertFalse(result.cold_boot_verified)
        pin = p.sha256_file(self.manifest)
        self.assertFalse(self.validate(approved_manifest_sha256=pin).needs_root_review)

    def test_ram_or_legacy_profile_rejected(self):
        for key, invalid in (("storage", "sram"), ("release", "R8"), ("profile_id", "touhou_R8"),
                             ("board", "other"), ("clock_mhz", 125), ("schema", "unknown")):
            original = self.data[key]; self.data[key] = invalid
            with self.subTest(key=key), self.assertRaises(p.ProfileValidationError): self.validate()
            self.data[key] = original

    def test_partial_or_unverified_package_rejected(self):
        for key in list(self.data["verification"]):
            self.data["verification"][key] = False
            with self.subTest(key=key), self.assertRaises(p.ProfileValidationError): self.validate()
            self.data["verification"][key] = True
        del self.data["artifacts"]["bootloader_stage"]
        with self.assertRaises(p.ProfileValidationError): self.validate()

    def test_changed_artifact_or_length_rejected(self):
        (self.root / "bootloader_stage.bin").write_bytes(b"evil-boot")
        with self.assertRaises(p.ProfileValidationError): self.validate()
        (self.root / "bootloader_stage.bin").write_bytes(self.raws["bootloader_stage"])
        self.data["artifacts"]["full_flash_image"]["size_bytes"] = 1000
        with self.assertRaises(p.ProfileValidationError): self.validate()

    def test_traversal_and_absolute_paths_rejected(self):
        spec = self.data["artifacts"]["firmware_elf"]
        for path in ("../x", "C:/old/image.bin", "/tmp/old.bin", "\\\\host\\file"):
            spec["path"] = path
            with self.subTest(path=path), self.assertRaises(p.ProfileValidationError): self.validate()

    def test_geometry_capacity_overlap_and_missing_offsets_rejected(self):
        flash = self.data["flash"]
        flash["capacity_bytes"] = 2048
        with self.assertRaises(p.ProfileValidationError): self.validate()
        flash["capacity_bytes"] = 1024; flash["erase_block_bytes"] = 250
        with self.assertRaises(p.ProfileValidationError): self.validate()
        flash["erase_block_bytes"] = 256
        flash["program_ranges"][1]["offset"] = 1
        with self.assertRaises(p.ProfileValidationError): self.validate()

    def test_protected_offset_even_in_same_erase_block_rejected(self):
        flash = self.data["flash"]
        flash["protected_ranges"][0].update(offset=530, length=10, sha256=self.sha(b"\xff" * 10))
        with self.assertRaises(p.ProfileValidationError): self.validate()

    def test_incomplete_component_map_and_region_hash_rejected(self):
        self.data["flash"]["program_ranges"][2]["component"] = "spare"
        with self.assertRaises(p.ProfileValidationError): self.validate()
        self.data["flash"]["program_ranges"][2]["component"] = "firmware"
        self.data["flash"]["program_ranges"][2]["sha256"] = "0" * 64
        with self.assertRaises(p.ProfileValidationError): self.validate()

    def test_review_pin_and_current_release_pins_fail_closed(self):
        with self.assertRaises(p.ProfileValidationError): self.validate(approved_manifest_sha256="0" * 64)
        self.validate()
        with self.assertRaises(p.ProfileValidationError):
            p.validate_profile(self.manifest, expected_flash_capacity=1024)

    def test_duplicate_manifest_keys_rejected(self):
        self.validate()
        raw = self.manifest.read_text()
        self.manifest.write_text(raw.replace('"release": "LAB23"', '"release": "R8", "release": "LAB23"'))
        with self.assertRaises(p.ProfileValidationError):
            p.validate_profile(self.manifest, expected_flash_capacity=1024)


class TwoStageImageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name); cls.out = cls.root / "out"; cls.out.mkdir()
        def digest(raw): return hashlib.sha256(raw).hexdigest()
        def elf(data, address, memory):
            ident = b"\x7fELF\x01\x01\x01" + b"\0" * 9
            header = struct.pack("<16sHHIIIIIHHHHHH", ident, 2, 243, 1, address, 52, 0, 0, 52, 32, 1, 0, 0, 0)
            ph = struct.pack("<IIIIIIII", 1, 256, address, address, len(data), memory, 7, 4096)
            return (header + ph).ljust(256, b"\0") + data
        cls.payload = bytes(i % 251 for i in range(213434))
        cls.payload = p.BOOT_MARKER.encode()+cls.payload[len(p.BOOT_MARKER):]
        cls.app_elf = elf(cls.payload, 0x1000, 230000)
        cls.stage2 = b"STAGE2"
        stage2_elf = elf(cls.stage2, 0xF00000, 32)
        stage1 = bytearray(b"\xff" * 126976); stage1[96:102] = cls.stage2
        cls.stage1 = bytes(stage1)
        cls.platform = b"Version:test\x01\x02"
        preservation = bytearray(b"\xff" * 8388608)
        preservation[0x600000]=0xA5
        cls.preservation=bytes(preservation)
        image = bytearray(cls.preservation)
        image[:len(cls.platform)] = cls.platform
        image[0x380000:0x380000 + len(stage1)] = stage1
        image[0x400000:0x400000 + len(cls.payload)] = cls.payload
        cls.image = bytes(image)
        files = {"app.elf": cls.app_elf, "platform.bit": b"bit-source-file",
                 "platform.hex": cls.platform.hex("\n").encode(),
                 "stage1.bin": cls.stage1, "stage2.bin": cls.stage2, "stage2.elf": stage2_elf,
                 "payload.bin": cls.payload, "image.bin": cls.image,
                 "image.hex": cls.image.hex("\n").encode(), "preservation_base.bin":cls.preservation}
        for name, raw in files.items(): (cls.out / name).write_bytes(raw)
        (cls.root / "loader.c").write_bytes(b"reviewed loader source")
        cls.elf_pin, cls.bit_pin = digest(cls.app_elf), digest(files["platform.bit"])
        cls.original = dict(schema=p.PERSISTENT_IMAGE_SCHEMA, status="OFFLINE_VERIFIED_NOT_BOARD_TESTED",
            board="Ti60F225I3-V4", release="LAB23", firmware="LAB23", release_id="GAME60_PIPELINE_5", required_capabilities={"adv":1,"img":1,"perf":1,"game_load":1,"gsizes":7,"batch32":1,"motion":1,"pref":1,"pipe":1,"pref8":1}, boot_marker=p.BOOT_MARKER, clock_mhz=100, flash_size=8388608, hardware_accessed=False, flash_written=False,
            elf=dict(path=str(cls.out / "app.elf"), sha256=cls.elf_pin, entry=4096, load_address=4096,
                     file_bytes=213434, memory_bytes=230000, crc32=f"{zlib.crc32(cls.payload):08x}"),
            platform=dict(bit_path=str(cls.out / "platform.bit"), bit_sha256=cls.bit_pin,
                     hex_path=str(cls.out / "platform.hex"), hex_sha256=digest(files["platform.hex"]),
                     flash_offset=0, decoded_bytes=len(cls.platform), decoded_sha256=digest(cls.platform)),
            stage1=dict(path="stage1.bin", sha256=digest(cls.stage1), flash_offset=0x380000,
                        copy_bytes=126976, unpadded_bytes=102, entry=4096, stage2_embedded_offset=96),
            stage2=dict(bin_path="stage2.bin", bin_sha256=digest(cls.stage2), elf_path="stage2.elf",
                        elf_sha256=digest(stage2_elf), run_address=0xF00000, stack_pointer=0xFFF000),
            payload=dict(path="payload.bin", sha256=digest(cls.payload), flash_offset=0x400000, bytes=213434),
            image=dict(bin_path="image.bin", bin_sha256=digest(cls.image), hex_path="image.hex",
                       hex_sha256=digest(files["image.hex"]), bytes=8388608),
            sources={"loader.c": digest(b"reviewed loader source")},
            pc_elf_ram_upload=False,ram_fallback_allowed=False,
            preservation_source=dict(path="preservation_base.bin",sha256=digest(cls.preservation),bytes=8388608,fresh_current_board_backup=False),
            platform_build_provenance=dict(schema="ti60_verified_hw_build_v1",status="PASS",review_path="../hardware_review.json",review_sha256="1"*64,
                 bit_sha256=cls.bit_pin,hex_sha256=digest(files["platform.hex"]),lbf_sha256="2"*64))

    @classmethod
    def tearDownClass(cls): cls.temp.cleanup()

    def setUp(self):
        self.data = json.loads(json.dumps(self.original))
        self.manifest = self.out / "manifest.json"

    def validate(self, **options):
        self.manifest.write_text(json.dumps(self.data), encoding="utf-8")
        reply=getattr(self,"hardware_reply",dict(bit_sha256=self.bit_pin,hex_sha256=self.original["platform"]["hex_sha256"],lbf_sha256="2"*64))
        with patch("hardware_gate.validate_review",return_value=reply,side_effect=getattr(self,"hardware_error",None)):
            return p.load_profile(self.manifest, expected_elf_sha256=self.elf_pin,
                                  expected_platform_sha256=self.bit_pin, **options)

    def test_exact_image_layout_and_internal_review_is_not_user_permission(self):
        result = self.validate()
        self.assertTrue(result.requires_review)
        self.assertTrue(result.readback_required and result.new_boot_required and result.cold_boot_required)
        self.assertEqual([(r["offset"], r["length"]) for r in result.partitions],
                         [(0, len(self.platform)), (0x380000, 126976), (0x400000, 213434)])
        result = self.validate(reviewed=True)
        self.assertTrue(result.reviewed)
        self.assertEqual(result.image_path, self.out / "image.bin")
        self.assertFalse(result.flash_programmed or result.flash_readback_verified or result.cold_boot_verified)

    def test_truncated_legacy_payload_or_wrong_stage_addresses_rejected(self):
        for section, key, value in (("payload", "bytes", 126976), ("payload", "flash_offset", 0x380000),
                                    ("stage1", "copy_bytes", 124000), ("stage2", "run_address", 0x1000),
                                    ("stage1", "stage2_embedded_offset", 97), ("elf", "crc32", "00000000")):
            old = self.data[section][key]; self.data[section][key] = value
            with self.subTest(section=section, key=key), self.assertRaises(p.ProfileValidationError): self.validate()
            self.data[section][key] = old

    def test_pinned_current_sources_and_provenance_required(self):
        self.data["platform"]["bit_sha256"] = "0" * 64
        with self.assertRaises(p.ProfileValidationError): self.validate()
        self.data = json.loads(json.dumps(self.original))
        self.data["platform_build_provenance"]["status"] = "FAIL"
        with self.assertRaises(p.ProfileValidationError): self.validate()
        self.data = json.loads(json.dumps(self.original)); self.data["stage1"]["path"] = str(self.out / "stage1.bin")
        with self.assertRaises(p.ProfileValidationError): self.validate()

    def test_full_image_old_slot_byte_rejected_even_if_file_hashes_match(self):
        changed = bytearray(self.image); changed[0x300000] = 0x55
        binary = self.out / "image.bin"; hexf = self.out / "image.hex"
        try:
            binary.write_bytes(changed); hexf.write_bytes(bytes(changed).hex("\n").encode())
            self.data["image"]["bin_sha256"] = p.sha256_file(binary)
            self.data["image"]["hex_sha256"] = p.sha256_file(hexf)
            with self.assertRaisesRegex(p.ProfileValidationError, "composition/gaps"): self.validate()
        finally:
            binary.write_bytes(self.image); hexf.write_bytes(self.image.hex("\n").encode())

    def test_old_production_release_is_explicitly_rejected(self):
        # The new GUI must never route old GAME_SIZE_3 as the new batch32 platform.
        manifest = Path("F:/FPGA/BoardStudio272/TI60_GAME_SIZE3_20261101/out/manifest.json")
        self.assertTrue(manifest.is_file())
        with self.assertRaises(p.ProfileValidationError):p.load_profile(manifest)

    def test_old_legacy_equality_cannot_be_faked_for_new_hardware(self):
        self.data["legacy_platform_provenance"]=dict(status="PASS",platform_hex_identical_to_original=True,platform_bit_identical_to_original=True,platform_prefix_matches_historical_booted_image=True)
        with self.assertRaises(p.ProfileValidationError):self.validate()

    def test_gate_failure_and_wrong_output_identity_rejected(self):
        self.hardware_error=ValueError("full hardware review rejected")
        with self.assertRaisesRegex(p.ProfileValidationError,"hardware review rejected"):self.validate()
        self.hardware_error=None
        self.hardware_reply=dict(bit_sha256=self.bit_pin,hex_sha256="0"*64,lbf_sha256="2"*64)
        with self.assertRaises(p.ProfileValidationError):self.validate()

    def test_preservation_snapshot_identity_and_ram_flags_are_mandatory(self):
        self.data["preservation_source"]["sha256"]="0"*64
        with self.assertRaises(p.ProfileValidationError):self.validate()
        self.data=json.loads(json.dumps(self.original));self.data["pc_elf_ram_upload"]=True
        with self.assertRaises(p.ProfileValidationError):self.validate()
        self.data=json.loads(json.dumps(self.original));self.data["ram_fallback_allowed"]=True
        with self.assertRaises(p.ProfileValidationError):self.validate()

    def test_non_ff_external_bytes_are_preserved(self):
        self.assertEqual(self.image[0x600000],0xA5)
        self.assertTrue(self.validate(reviewed=True).reviewed)



if __name__ == "__main__": unittest.main(verbosity=2)

