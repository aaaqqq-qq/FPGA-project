"""Offscreen real-Qt status tests. No devices, network, or processes involved."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication
from download_progress import DownloadProgress
import download_panel as ui


class DownloadPanelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication(['download-panel-tests'])
        cls.app.setStyle('Fusion')

    def setUp(self):
        self.widget = ui.DownloadPanel()
        self.widget.resize(680, 144)
        self.widget.show()
        self.app.processEvents()

    def tearDown(self):
        self.widget.timer.stop()
        self.widget.close()
        self.widget.deleteLater()
        self.app.processEvents()

    def reset(self, check=False):
        with patch.object(ui.time, 'monotonic', return_value=100.):
            self.widget.reset(check)

    def update(self, snapshot, now=101.):
        with patch.object(ui.time, 'monotonic', return_value=now):
            self.widget.update_progress(snapshot)

    def tick(self, now):
        with patch.object(ui.time, 'monotonic', return_value=now):
            self.widget._tick()

    def test_idle_is_fixed_visible_and_uses_thick_bar(self):
        self.assertTrue(self.widget.isVisible())
        self.assertEqual(self.widget.height(), 144)
        self.assertGreaterEqual(self.widget.bar.height(), 12)
        self.assertEqual(self.widget.percent.text(), '待开始')
        self.assertEqual(self.widget.phase.text(), '完整烧录到 Flash')
        self.assertFalse(self.widget.running)
        self.assertFalse(self.widget.timer.isActive())
        self.assertEqual(set(self.widget.stage_labels), {1, 2, 3, 4, 5})

    def test_unknown_progress_remains_indeterminate_as_time_passes(self):
        self.reset()
        self.assertEqual((self.widget.bar.minimum(), self.widget.bar.maximum()), (0, 0))
        self.update({'stage': 'configure', 'step': 2, 'state': 'running'})
        self.assertIn('阶段 2/5', self.widget.phase.text())
        self.assertIn('准备/配置烧录通道', self.widget.phase.text())
        self.tick(280)
        self.assertEqual((self.widget.bar.minimum(), self.widget.bar.maximum()), (0, 0))
        self.assertNotIn('%', self.widget.percent.text())
        self.assertEqual(self.widget.elapsed.text(), '已用 180 秒')
        self.assertIsNone(self.widget.success)
        self.assertTrue(self.widget.running)

    def test_actual_model_counts_are_exact_and_not_overall_progress(self):
        self.reset()
        model = DownloadProgress()
        value = model.feed('PROGRESS {"stage":"verify","step":4,"state":"running","done":65536,"total":188818,"unit":"bytes"}')
        self.update(value)
        self.assertEqual((self.widget.bar.value(), self.widget.bar.maximum()), (65536, 188818))
        self.assertEqual(self.widget.percent.text(), '34.7%')
        self.assertIn('65,536 / 188,818 字节', self.widget.detail.text())
        self.assertIn('本阶段', self.widget.detail.text())
        self.assertIn('阶段 4/5', self.widget.phase.text())
        before = self.widget.bar.value()
        self.tick(230)
        self.assertEqual(self.widget.bar.value(), before)
        self.assertIsNone(self.widget.success)

    def test_large_real_count_scales_qt_range_without_losing_text(self):
        self.reset()
        self.update({'stage':'verify', 'step':4, 'state':'running', 'done':5_000_000_000, 'total':10_000_000_000})
        self.assertEqual(self.widget.percent.text(), '50.0%')
        self.assertIn('5,000,000,000 / 10,000,000,000', self.widget.detail.text())
        self.assertEqual((self.widget.bar.value(), self.widget.bar.maximum()), (5000, 10000))

    def test_stage_transition_removes_previous_byte_percentage(self):
        self.reset()
        self.update({'stage':'verify', 'step':4, 'state':'running', 'done':188818, 'total':188818})
        self.assertEqual(self.widget.percent.text(), '100.0%')
        self.update({'stage':'start', 'step':5, 'state':'running'}, now=102)
        self.assertEqual(self.widget.percent.text(), '处理中')
        self.assertEqual(self.widget.bar.maximum(), 0)
        self.assertNotIn('188,818', self.widget.detail.text())
        self.assertIsNone(self.widget.success)

    def test_tool_stage_done_does_not_finish_entire_job(self):
        self.reset()
        self.update({'stage':'start', 'step':5, 'state':'done'})
        self.assertTrue(self.widget.running)
        self.assertIsNone(self.widget.success)
        self.assertIn('等待任务结束', self.widget.detail.text())
        self.assertNotIn('Flash写入及读回完成', self.widget.phase.text())

    def test_two_second_and_eight_second_wait_are_neutral(self):
        self.reset()
        self.tick(102.1)
        self.assertIn('工具处理中，等待返回', self.widget.activity.text())
        self.assertIn('最后消息 2 秒前', self.widget.activity.text())
        self.tick(108.2)
        self.assertIn('一段时间未收到新消息', self.widget.activity.text())
        self.assertNotIn('失败', self.widget.activity.text())
        self.assertTrue(self.widget.running)
        self.assertIsNone(self.widget.success)

    def test_ordinary_log_activity_refreshes_liveness_without_changing_bytes(self):
        self.reset()
        self.update({'stage':'verify', 'step':4, 'state':'running', 'done':12, 'total':100})
        self.tick(110)
        self.assertIn('一段时间未收到新消息', self.widget.activity.text())
        with patch.object(ui.time, 'monotonic', return_value=111):
            self.widget.log_activity()
        self.assertIn('正在接收工具消息', self.widget.activity.text())
        self.assertIn('最后消息 0 秒前', self.widget.activity.text())
        self.assertEqual(self.widget.bar.value(), 12)

    def test_activity_dots_animate_without_advancing_progress(self):
        self.reset()
        self.update({'stage':'load', 'step':3, 'state':'running'})
        text = self.widget.activity.text()
        self.tick(101.1)
        self.assertNotEqual(text, self.widget.activity.text())
        self.assertEqual(self.widget.bar.maximum(), 0)

    def test_only_finish_success_marks_download_done_and_freezes_elapsed(self):
        self.reset()
        self.update({'stage':'verify', 'step':4, 'state':'running', 'done':10, 'total':100})
        with patch.object(ui.time, 'monotonic', return_value=114):
            self.widget.finish(True, '校验、缓存同步和启动核对均已完成')
        self.assertFalse(self.widget.running)
        self.assertTrue(self.widget.success)
        self.assertFalse(self.widget.timer.isActive())
        self.assertEqual((self.widget.bar.value(), self.widget.bar.maximum()), (100, 100))
        self.assertEqual(self.widget.phase.text(), 'Flash写入及读回完成 · 断电启动待确认')
        self.assertEqual(self.widget.percent.text(), '已写入')
        self.assertIn('断电启动待确认', self.widget.detail.text())
        self.assertEqual(self.widget.elapsed.text(), '已用 14 秒')
        self.assertIn('启动核对', self.widget.detail.text())
        self.tick(300)
        self.assertEqual(self.widget.elapsed.text(), '已用 14 秒')

    def test_failure_preserves_failed_stage_and_never_claims_100_percent(self):
        self.reset()
        self.update({'stage':'verify', 'step':4, 'state':'running', 'done':188818, 'total':188818})
        with patch.object(ui.time, 'monotonic', return_value=117):
            self.widget.finish(False, '读回不一致，请查看日志')
        self.assertEqual(self.widget.current_stage, 'verify')
        self.assertIn('阶段 4/5 未完成', self.widget.phase.text())
        self.assertIn('Flash读回核对', self.widget.phase.text())
        self.assertEqual(self.widget.percent.text(), '未完成')
        self.assertFalse(self.widget.success)
        self.assertEqual(self.widget.bar.value(), 0)
        self.assertFalse(self.widget.timer.isActive())
        old = self.widget.phase.text()
        self.widget.finish(True)
        self.update({'stage':'start', 'step':5, 'state':'done'})
        self.assertEqual(self.widget.phase.text(), old)

    def test_offline_check_is_distinct_from_download(self):
        self.reset(check=True)
        self.assertIn('离线检查', self.widget.phase.text())
        with patch.object(ui.time, 'monotonic', return_value=104):
            self.widget.finish(True)
        self.assertEqual(self.widget.phase.text(), '离线检查通过')
        self.assertIn('未执行Flash写入', self.widget.activity.text())
        self.assertEqual(self.widget.current_step, 1)
        self.assertNotIn('#16846c', self.widget.stage_labels[5].styleSheet())

    def test_retry_resets_previous_failure_and_counts(self):
        self.reset()
        self.update({'stage':'load', 'step':3, 'state':'running', 'done':30, 'total':100})
        self.widget.finish(False)
        self.reset()
        self.assertIsNone(self.widget.success)
        self.assertEqual(self.widget.current_step, 1)
        self.assertEqual(self.widget.bar.maximum(), 0)
        self.assertEqual(self.widget.elapsed.text(), '已用 0 秒')

    def test_no_raw_string_parsing_or_automatic_job_start(self):
        self.widget.update_progress({'stage':'start', 'step':5, 'state':'done'})
        self.assertFalse(self.widget.running)
        self.reset()
        self.widget.update_progress('PROGRESS {"stage":"start"}')
        self.widget.update_progress({'stage':'bogus','step':9})
        self.assertEqual(self.widget.current_step, 1)
        with self.assertRaises(TypeError):self.widget.reset('yes')
        with self.assertRaises(TypeError):self.widget.finish('yes')

    def test_flash_stage_copy_and_normal_start_never_claim_cold_boot_pass(self):
        self.reset()
        for stage, step, title in [('configure',2,'准备/配置烧录通道'),
                                   ('load',3,'Flash完整写入'),
                                   ('verify',4,'Flash读回核对'),
                                   ('start',5,'重新启动并检查LAB1')]:
            self.update({'stage':stage,'step':step,'state':'running'})
            self.assertIn(title,self.widget.phase.text())
            self.assertNotIn('装载程序',self.widget.phase.text())
        self.widget.finish(True,'已观察到LAB1启动标记')
        self.assertIn('断电启动待确认',self.widget.phase.text())
        self.assertIn('断电启动待确认',self.widget.detail.text())
        self.assertNotIn('冷启动通过',self.widget.phase.text()+self.widget.detail.text()+self.widget.activity.text())


if __name__ == '__main__':
    unittest.main()
