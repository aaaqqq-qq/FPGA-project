"""Native ADV panel + whole-window integration, no real hardware/process access."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from pathlib import Path
import sys,unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
import test_ui as base
import main as ui
from adv_panel import AdvPanel,shape_contains,read_art
from test_adv_protocol import CAPS,parsed,done,control,measured
from test_ui_v23 import FakeLab23,STAT
from test_labx_protocol import parsed as xp,done as xd

class OwnerStatusLink(FakeLab23):
 """Model the actual firmware router: ADV ownership rejects even LABX status."""
 def __init__(self,adv_active=0,adv_running=0,labx_active=0,legacy=False):
  super().__init__([CAPS+' img=1 perf=1']);self.adv_active=adv_active;self.adv_running=adv_running;self.labx_active=labx_active;self.legacy=legacy
 def send(self,payload):
  super().send(payload);parts=payload.decode('ascii').split()
  if len(parts)!=3 or parts[2]!='status':return
  i=int(parts[1])
  if parts[0]==':adv':items=control(i,'status',self.adv_active,self.adv_running)
  elif parts[0]==':labx':
   if self.adv_active or self.adv_running:
    self.lines.append('ERR adv active; exit adv first');return
   if self.legacy:items=[xd(i,'status',active=0,status='ERROR',code='LEGACY_ACTIVE')]
   else:items=[xp('LABX_ACK',id=i,op='status',status='ACCEPTED'),xp('LABX_STATE',id=i,active=self.labx_active,phase=0,front=0x01000000,back=0x01400000,swaps=1,pending=0,ready=0,errors=0),xd(i,'status',active=self.labx_active)]
  else:return
  self.lines.extend(x['raw'] for x in items)

class AdvPanelTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.app=base.QApplication.instance() or base.QApplication(['ADV-tests'])
 def setUp(self):
  self.now=10.;self.panel=AdvPanel(clock=lambda:self.now);self.sent=[];self.panel.command_requested.connect(lambda i,o,a:self.sent.append((i,o,a)))
  self.addCleanup(self.panel.deleteLater)
 def feed(self,items):
  for item in items:self.panel.ingest(item)
 def ready(self):
  self.panel.set_capabilities(dict(fw='LAB23',adv=1));self.panel.set_available(True);i=self.panel._request.request_id;self.feed(control(i,'status',0))
  self.assertFalse(self.panel.uncertain);self.panel.request('enter');i=self.panel._request.request_id;self.feed(control(i,'enter'));return self.panel
 def complete(self):
  r=self.panel._request;items,end=measured(r.request_id,r.operation,r.args);self.feed([*items,end]);return self.panel.results[-1]
 def test_legacy_caps_explains_and_disables_advanced(self):
  self.panel.set_capabilities(dict(fw='LAB23',adv=0));self.panel.set_available(True);self.assertFalse(self.panel.request('enter'));self.assertIn('未启用',self.panel.status.text());self.assertFalse(self.sent)
 def test_new_caps_automatically_reads_status_before_enter(self):
  self.panel.set_capabilities(dict(fw='LAB23',adv=1));self.panel.set_available(True)
  self.assertEqual(self.sent[-1][1],'status');self.assertFalse(self.panel.enter_button.isEnabled());self.assertTrue(self.panel.blocks_game)
 def test_independent_alpha_key_entry_shares_pressure_controls(self):
  self.panel.set_section('key');self.assertEqual(self.panel.tabs.tabText(0),'去背与联合');self.assertTrue(self.panel.tabs.isTabVisible(1));self.assertTrue(self.panel.key_on.isChecked())
  self.panel.set_section('alpha');self.assertTrue(self.panel.tabs.isTabVisible(1));self.assertTrue(self.panel.alpha_on.isChecked())
 def test_physics_selection_keeps20000_and_rejects_send(self):
  p=self.ready();p.count.setValue(20000);p.physics.setCurrentIndex(2);before=len(self.sent)
  self.assertEqual(p.count.value(),20000);self.assertFalse(p.start_stress());self.assertEqual(len(self.sent),before);self.assertIn('512',p.status.text())
 def test_seed_uint32max_is_supported_and_zero_rejected(self):
  p=self.ready();p.seed.setText('4294967295');self.assertTrue(p.start_stress());self.assertEqual(self.sent[-1][2][-1],4294967295);self.complete()
  p.seed.setText('0');self.assertFalse(p.start_stress())
 def test_slider_coalesces_latest_after_done_not_unbounded_stream(self):
  p=self.ready();p.set_alpha(64);first=self.sent[-1];p.set_alpha(128);p.set_alpha(192);self.assertEqual(self.sent[-1],first)
  self.complete();self.assertIsNone(p._request);p.tick();self.assertEqual(self.sent[-1][1],'show');self.assertEqual(self.sent[-1][2][6],192)
 def test_joint_asks_all_four_cases_and_real_verify256(self):
  p=self.ready();p.queue_show('joint');self.assertEqual(self.complete()['done']['completed'],4)
  p.request('verify','alpha');self.assertEqual(self.complete()['done']['completed'],256)
 def test_cancel_delivery_is_not_original_completion(self):
  p=self.ready();p.start_stress();original=p._request.request_id;p.stop_and_return();cancel=p._cancel_id
  self.feed([parsed('ADV_ACK',id=cancel,op='cancel',status='ACCEPTED'),done(cancel,'cancel')]);self.assertTrue(p.pending);self.assertTrue(p.blocks_game)
  self.feed([done(original,'stress',status='CANCELLED',code='CANCEL')]);self.assertEqual(p._request.operation,'exit');i=p._request.request_id;self.feed(control(i,'exit',0));self.assertFalse(p.blocks_game)
 def test_late_done_cannot_turn_timeout_into_pass(self):
  p=self.ready();p.start_stress();r=p._request;items,end=measured(r.request_id,r.operation,r.args);self.feed(items);self.now=r.deadline;self.feed([end])
  self.assertTrue(p.uncertain);self.assertEqual(p.results[-1]['reasons'],['TIMEOUT']);self.assertFalse(p.results[-1]['accepted_pass'])
 def test_disconnect_retains_incomplete_evidence(self):
  p=self.ready();p.start_stress();p.disconnected();self.assertFalse(p.results[-1]['accepted_pass']);self.assertEqual(p.results[-1]['reasons'],['DISCONNECTED']);self.assertFalse(p.available)
 def test_timeout_stop_resyncs_then_cancels_foreign_owner_before_exit(self):
  p=self.ready();p.start_stress();self.now=p._request.deadline;p.tick();self.assertTrue(p.uncertain)
  p.stop_and_return();self.assertEqual(p._request.operation,'status');i=p._request.request_id;self.feed(control(i,'status',1,1));cancel=p._cancel_id;self.assertIsNotNone(cancel)
  self.feed([done(cancel,'cancel')]);self.assertTrue(p.blocks_game);self.assertIsNone(p._request)
  self.now+=.3;p.tick();self.assertEqual(p._request.operation,'status');i=p._request.request_id;self.feed(control(i,'status',1,0));self.assertEqual(p._request.operation,'exit');i=p._request.request_id;self.feed(control(i,'exit',0));self.assertFalse(p.blocks_game)
 def test_size_sweep_registers_all_and_sends_one_at_a_time(self):
  p=self.ready();p.count.setValue(99);p.seed.setText('4294967295');self.assertTrue(p.start_sweep());self.assertEqual(p.sweep_table.rowCount(),8)
  report=p.sweeps[-1];self.assertEqual([r['status'] for r in report['rows']],['PENDING']+['NOT_RUN']*7);self.assertFalse(p.start_stress())
  for size in (8,16,24,32,40,48,56,64):
   self.assertEqual(p._request.args[2],size);self.assertEqual(p._request.args[1],99);self.assertEqual(p._request.args[-1],4294967295);before=len(self.sent);self.complete();self.assertEqual(len(self.sent),before);p.tick()
  self.assertIsNone(p._sweep);self.assertEqual(report['status'],'COMPLETE');self.assertTrue(all(r['status']=='PASS' for r in report['rows']));self.assertEqual(len({r['id'] for r in report['rows']}),8)
 def test_cancel_sweep_marks_unrun_and_never_sends_next(self):
  p=self.ready();p.start_sweep();self.complete();p.tick();original=p._request.request_id;p.stop_and_return();cancel=p._cancel_id
  self.feed([done(cancel,'cancel'),done(original,'stress',status='CANCELLED',code='CANCEL')]);p.tick();report=p.export_document()['size_sweeps'][-1]
  self.assertEqual(report['status'],'CANCELLED');self.assertEqual([r['status'] for r in report['rows']],['PASS','CANCELLED']+['NOT_RUN']*6);self.assertFalse(any(x[1]=='stress' and x[2][2]==24 for x in self.sent))
 def test_sweep_error_stops_unexecuted_rows(self):
  p=self.ready();p.start_sweep();i=p._request.request_id;self.feed([done(i,'stress',status='ERROR',code='HARDWARE')]);p.tick()
  self.assertEqual(p.sweeps[-1]['status'],'INCOMPLETE');self.assertEqual(p.sweeps[-1]['rows'][1]['status'],'NOT_RUN')
 def test_material_enable_and_original_magenta_preview(self):
  p=self.ready();p.material.setCurrentIndex(1);self.assertFalse(p.fg.isEnabled());self.assertFalse(p.shape.isEnabled());p.material.setCurrentIndex(0);self.assertTrue(p.fg.isEnabled());self.assertTrue(p.shape.isEnabled())
  p.key.set_rgb(0x123456);self.assertEqual(p.preview.image.pixel(0,0)&0xffffff,0xff00ff)
 def test_source_shapes_are_distinct_and_bounded(self):
  masks=[tuple(shape_contains(s,x,y,32) for y in range(32) for x in range(32)) for s in range(6)]
  self.assertEqual(len(set(masks)),6);self.assertEqual(sum(masks[1]),1024)

class AdvMainIntegrationTests(unittest.TestCase):
 setUpClass=classmethod(base.NativeUIContracts.setUpClass.__func__)
 def setUp(self):
  base.NativeUIContracts.setUp(self);clock=patch.object(ui.time,'monotonic',return_value=102.);clock.start();self.addCleanup(clock.stop)
 dispose_window=base.NativeUIContracts.dispose_window
 poll=base.NativeUIContracts.poll
 disabled=base.NativeUIContracts.disabled
 def inject(self,link,*items):link.lines=[x['raw'] if isinstance(x,dict) else x for x in items];self.poll(101)
 def ready(self):
  link=FakeLab23([CAPS]);self.window.link=link;self.poll()
  adv=self.window.adv._request;self.assertIsNone(self.window.labx._request);self.assertIsNotNone(adv)
  self.assertEqual(adv.operation,'status');self.inject(link,*control(adv.request_id,'status',0))
  labx=self.window.labx._request;self.assertIsNotNone(labx);self.assertEqual(labx.operation,'status')
  i=labx.request_id
  self.inject(link,xp('LABX_ACK',id=i,op='status',status='ACCEPTED'),xp('LABX_STATE',id=i,active=0,phase=0,front=0x01000000,back=0x01400000,swaps=1,pending=0,ready=0,errors=0),xd(i,'status',active=0))
  self.assertFalse(self.window.game_ready());self.inject(link,STAT);self.assertTrue(self.window.game_ready());return link
 def enter(self):
  link=self.ready();self.assertTrue(self.window.adv.request('enter'));i=self.window.adv._request.request_id;self.inject(link,*control(i,'enter'));return link
 def test_caps_sequential_status_finishes_then_requires_fresh_stat(self):self.ready()
 def owner_handshake(self,**state):
  link=OwnerStatusLink(**state);self.window.link=link;self.poll()
  self.assertEqual(len(link.sent),1);self.assertTrue(link.sent[0].startswith(b':adv '));self.assertTrue(link.sent[0].endswith(b' status\n'))
  self.assertIsNone(self.window.labx._request);self.poll(101);return link
 def test_reconnect_active_adv_enables_own_controls_without_fake_labx_pass(self):
  link=self.owner_handshake(adv_active=1);p=self.window.adv
  self.assertTrue(p.active);self.assertFalse(p.uncertain);self.assertTrue(p.performance_preset.isEnabled());self.assertTrue(p.performance_start.isEnabled());self.assertTrue(p.exit_button.isEnabled())
  self.assertEqual(len(link.sent),1);self.assertTrue(self.window.labx.uncertain);self.assertTrue(self.window.labx._need_resync);self.assertFalse(self.window.labx.results)
  self.assertFalse(self.window.labx.enter_button.isEnabled());self.assertFalse(self.window.game_ready());self.assertFalse(self.window.download_button.isEnabled())
 def test_reconnect_running_adv_locks_inputs_but_can_cancel_safely(self):
  link=self.owner_handshake(adv_active=1,adv_running=1);p=self.window.adv
  self.assertTrue(p.uncertain);self.assertTrue(p._foreign_running);self.assertFalse(p.performance_preset.isEnabled());self.assertFalse(p.performance_start.isEnabled());self.assertTrue(p.stop_button.isEnabled())
  p.stop_and_return();self.assertIsNotNone(p._cancel_id);self.assertTrue(link.sent[-1].endswith(b' cancel\n'));self.assertFalse(any(x.startswith(b':labx ') for x in link.sent))
 def test_reconnect_labx_owner_is_detected_after_adv_is_confirmed_idle(self):
  link=self.owner_handshake(labx_active=1)
  self.assertEqual(len(link.sent),2);self.assertTrue(link.sent[1].startswith(b':labx '));self.assertTrue(self.window.labx.pending);self.assertFalse(self.window.adv.enter_button.isEnabled())
  self.poll(102);self.assertTrue(self.window.labx.active);self.assertTrue(self.window.labx.exit_button.isEnabled());self.assertFalse(self.window.adv.available);self.assertFalse(self.window.game_ready())
 def test_reconnect_both_idle_still_waits_for_new_game_telemetry(self):
  link=self.owner_handshake();self.assertTrue(self.window.labx.pending);self.poll(102)
  self.assertFalse(self.window.adv.uncertain);self.assertFalse(self.window.labx.uncertain);self.assertFalse(self.window.game_ready())
  self.inject(link,STAT);self.assertTrue(self.window.game_ready())
 def test_exit_reconnected_adv_checks_deferred_labx_before_other_controls(self):
  link=self.owner_handshake(adv_active=1);p=self.window.adv
  self.assertTrue(p.request('exit'));i=p._request.request_id;self.assertTrue(link.sent[-1].endswith(b' exit\n'))
  link.adv_active=0;self.inject(link,*control(i,'exit',0));self.assertTrue(self.window.labx.pending);self.assertFalse(p.enter_button.isEnabled());self.assertFalse(self.window.game_ready())
  self.poll(102);self.assertFalse(self.window.labx.uncertain);self.assertTrue(p.enter_button.isEnabled())
 def test_reconnect_legacy_basic1_can_exit_without_bypassing_ownership(self):
  link=self.owner_handshake(legacy=True);self.poll(102)
  self.assertTrue(self.window.lab.active);self.assertTrue(self.window.lab.available);self.assertFalse(self.window.adv.available);self.assertFalse(self.window.labx.available)
  self.assertTrue(self.window.lab.request('exit'));self.assertTrue(link.sent[-1].startswith(b':lab '));self.assertIn(b' exit',link.sent[-1])
 def test_lost_adv_status_waits_then_can_retry_without_querying_labx(self):
  p=self.window.adv;now=[100.];p.clock=lambda:now[0]
  link=FakeLab23([CAPS+' perf=1']);self.window.link=link;self.poll();request=p._request;self.assertEqual(len(link.sent),1)
  now[0]=request.deadline;p.tick();self.assertTrue(p.uncertain);self.assertFalse(p.performance_preset.isEnabled());self.assertTrue(p.sync_button.isEnabled());self.assertIsNone(self.window.labx._request)
  self.assertTrue(p.request('status'));i=p._request.request_id;self.inject(link,*control(i,'status',1));self.assertTrue(p.performance_preset.isEnabled());self.assertEqual(len(link.sent),2);self.assertFalse(any(x.startswith(b':labx ') for x in link.sent))
 def test_incomplete_or_mismatched_adv_status_does_not_unlock_labx(self):
  for missing in ('ADV_ACK','ADV_STATE'):
   with self.subTest(missing=missing):
    self.window.disconnect();link=FakeLab23([CAPS+' perf=1']);self.window.link=link;self.poll();i=self.window.adv._request.request_id
    self.inject(link,*[x for x in control(i,'status',0) if x['kind_line']!=missing]);self.assertTrue(self.window.adv.uncertain);self.assertFalse(self.window.adv.results[-1]['accepted_pass']);self.assertIsNone(self.window.labx._request);self.assertEqual(len(link.sent),1)
  self.window.disconnect();link=FakeLab23([CAPS+' perf=1']);self.window.link=link;self.poll();i=self.window.adv._request.request_id
  self.inject(link,*control(i+1,'status',0));self.assertTrue(self.window.adv.pending);self.assertIsNone(self.window.labx._request);self.assertEqual(len(link.sent),1)
 def test_direct_adv_enter_cannot_bypass_labx_status_uncertainty(self):
  link=self.owner_handshake();self.assertTrue(self.window.labx.pending);p=self.window.adv;before=len(link.sent)
  p.available=True;p.request('enter');self.assertEqual(len(link.sent),before);self.assertFalse(p.capable)
 def test_nav_preserves_basic2_basic3_and_adds_two_independent_entries(self):
  for nav,stack,section in [(6,6,'basic2'),(7,6,'basic3'),(8,7,'alpha'),(9,7,'key')]:
   self.window.navigate(nav);self.assertEqual(self.window.stack.currentIndex(),stack);self.assertEqual(self.window.labx.section if nav<8 else self.window.adv.section,section)
 def test_old_lab23_does_not_claim_adv_support(self):
  link=FakeLab23([CAPS.replace(' adv=1','')]);self.window.link=link;self.poll();self.assertFalse(self.window.adv.capable);self.assertFalse(self.window.adv.request('enter'));self.assertTrue(self.window.labx.pending)
 def test_active_adv_blocks_game_labx_basic_and_flash_direct_handlers(self):
  link=self.enter();before=len(link.sent)
  with patch.object(self.window,'save_settings') as save:self.window.run_job(True);self.window.run_job(False);save.assert_not_called()
  self.window.start_mode();self.window.run_pressure(64,True);self.window.control_send(b':pause 1\n');self.window.action('start',True)
  self.assertFalse(self.window.lab.request('enter'));self.assertFalse(self.window.labx.request('enter'));self.assertEqual(len(link.sent),before);self.assertFalse(link.actions);self.assertFalse(self.window.download_button.isEnabled())
 def test_adv_direct_unowned_handler_cannot_send(self):
  link=self.ready();before=len(link.sent);self.window.adv_send(123,'enter',[]);self.assertEqual(len(link.sent),before)
 def test_legacy_lab_owner_prevents_adv_request_even_if_slot_forced(self):
  link=self.ready();self.window.lab.active=True;self.window.update_controls();before=len(link.sent);self.assertFalse(self.window.adv.request('enter'))
  p=self.window.adv;p.available=True;p.request('enter');self.assertEqual(len(link.sent),before);self.assertFalse(p.capable)
 def test_matched_fragments_reach_native_table(self):
  link=self.enter();self.window.adv.start_stress();r=self.window.adv._request;items,end=measured(r.request_id,r.operation,r.args);self.inject(link,*items,end)
  self.assertTrue(self.window.adv.results[-1]['accepted_pass']);self.assertEqual(self.window.adv.table.rowCount(),1)
 def test_export_does_not_claim_board_boot(self):
  self.ready();d=self.window.adv.export_document();self.assertIn('本页不自动认证物理冷启动',d['notes']);self.assertNotIn('cold_boot_pass',d)

if __name__=='__main__':unittest.main()
