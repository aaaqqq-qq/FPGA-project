"""Current source policy checks, not map/PNR/STA or physical acceptance."""
from pathlib import Path
import hashlib,json,os,shutil,tempfile,unittest,xml.etree.ElementTree as ET
import hardware_gate as gate

WORK=Path(__file__).resolve().parents[2]
BUNDLE=Path(os.environ.get('TI60_TEST_RELEASE_ROOT',str(WORK/'release')))
HW=BUNDLE/'projects/touhou_LAB'
REFERENCE=BUNDLE/'reference'
NS='{http://www.efinixinc.com/enf_proj}'

class Pipe5SourcePolicyTests(unittest.TestCase):
    def test_actual_four_source_declarations_only(self):
        gate.validate_project_xml(HW,REFERENCE/'baseline_project.xml')
    def test_wrong_parent_text_children_attributes_duplicates_and_constraints_rejected(self):
        original=(HW/gate.PROJECT_XML).read_bytes()
        def mutate(tag):
            root=ET.fromstring(original);design=root.find(NS+'design_info')
            entry=next(x for x in design if x.get('name')=='../../rtl/render_axi_arbiter.sv')
            if tag=='parent':design.remove(entry);root.append(entry)
            elif tag=='child':ET.SubElement(entry,NS+'rogue')
            elif tag=='text':entry.text='not empty'
            elif tag=='tail':entry.tail='not empty'
            elif tag=='attribute':entry.set('library','changed')
            elif tag=='duplicate':design.append(ET.fromstring(ET.tostring(entry)))
            elif tag=='omit':design.remove(entry)
            elif tag=='extra':ET.SubElement(design,NS+'design_file',{'name':'../../rtl/rogue.sv','version':'default','library':'default'})
            elif tag=='settings':root.set('rogue_clock','200')
            return root
        with tempfile.TemporaryDirectory(prefix='pipe5_xml_') as temp:
            root=Path(temp);target=root/gate.PROJECT_XML;target.parent.mkdir(parents=True)
            for tag in ('parent','child','text','tail','attribute','duplicate','omit','extra','settings'):
                with self.subTest(tag=tag):
                    ET.ElementTree(mutate(tag)).write(target,encoding='utf-8')
                    with self.assertRaises(gate.EvidenceError):gate.validate_project_xml(root,REFERENCE/'baseline_project.xml')
    def test_actual_dependency_set_is_exactly_83_and_approved_diff_only(self):
        baseline=gate.json_file(gate.pinned(REFERENCE/'baseline_input_pins.json',gate.BASE_PINS_SHA))
        names={x['path'] for x in baseline['inputs']}|gate.NEW_RTL
        rows=[]
        for name in sorted(names):
            p=HW/name;rows.append(dict(path=name,bytes=p.stat().st_size,sha256=gate.digest(p)))
        self.assertEqual(len(rows),83)
        gate.validate_sources(HW,{'source_inputs':rows},baseline)
        for bad in (rows[:-1],rows+[dict(rows[0])]):
            with self.assertRaises(gate.EvidenceError):gate.validate_sources(HW,{'source_inputs':bad},baseline)

if __name__=='__main__':unittest.main()
