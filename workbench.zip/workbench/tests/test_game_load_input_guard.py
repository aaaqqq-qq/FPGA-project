"""Native Qt input protection tests; no settings, GUI session, serial or board work."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import unittest
from PySide6.QtCore import Qt,QPoint,QPointF
from PySide6.QtGui import QWheelEvent
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QWidget,QVBoxLayout,QPushButton,QScrollArea,QSpinBox,QComboBox,QStyle,QStyleOptionSpinBox
from game_load_panel import GameLoadPanel,ScrollSafeSpinBox,ScrollSafeComboBox

class GameLoadInputGuardTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.app=QApplication.instance()or QApplication([])
 def setUp(self):
  self.outer=QWidget();layout=QVBoxLayout(self.outer);self.other=QPushButton('Other focus');layout.addWidget(self.other)
  self.scroll=QScrollArea();self.scroll.setWidgetResizable(True);layout.addWidget(self.scroll)
  self.panel=GameLoadPanel();self.scroll.setWidget(self.panel);self.outer.resize(1000,440)
  self.panel.capable=self.panel.available=self.panel.status_available=True;self.panel.uncertain=False
  self.panel.identity=dict(fw='LAB23',game_load=1,pipe=1,pref8=1);self.panel._enable()
  self.sent=[];self.panel.command_requested.connect(lambda i,op,args:self.sent.append((i,op,args)))
  self.outer.show();self.outer.activateWindow();self.app.processEvents();self.assertTrue(self.panel.load_target(8))
 def tearDown(self):
  self.outer.close();self.outer.deleteLater();self.app.processEvents()
 def wheel(self,w,delta=-360):
  event=QWheelEvent(QPointF(w.rect().center()),QPointF(w.mapToGlobal(w.rect().center())),QPoint(),QPoint(0,delta),Qt.NoButton,Qt.NoModifier,Qt.ScrollUpdate,False)
  QApplication.sendEvent(w,event);self.app.processEvents()
 def focus(self,w):
  self.scroll.ensureWidgetVisible(w);w.setFocus();self.app.processEvents()
 def values(self):
  return (self.panel.bosses.value(),self.panel.enemies.value(),self.panel.count.value(),self.panel.size.currentData(),self.panel.duration.currentData(),self.panel.boss_from.value(),self.panel.boss_to.value())
 def test_every_panel_spin_and_combo_uses_guard(self):
  controls=self.panel.findChildren(QSpinBox)+self.panel.findChildren(QComboBox)
  self.assertEqual(len(controls),7)
  self.assertTrue(all(isinstance(w,(ScrollSafeSpinBox,ScrollSafeComboBox))for w in controls))
 def test_unfocused_wheel_changes_no_spin_or_combo(self):
  for w in self.panel.findChildren(QSpinBox)+self.panel.findChildren(QComboBox):
   for delta in (-360,360):
    with self.subTest(widget=w,delta=delta):
     self.other.setFocus();self.app.processEvents();self.assertFalse(w.hasFocus());before=self.values();self.wheel(w,delta);self.assertEqual(self.values(),before)
  self.assertEqual(self.sent,[])
 def test_focused_wheel_changes_no_spin_or_combo(self):
  for w in self.panel.findChildren(QSpinBox)+self.panel.findChildren(QComboBox):
   for delta in (-360,360):
    with self.subTest(widget=w,delta=delta):
     self.focus(w);self.assertTrue(w.hasFocus());before=self.values();self.wheel(w,delta);self.assertEqual(self.values(),before)
  self.assertEqual(self.sent,[])
 def test_ignored_spin_wheel_scrolls_the_page(self):
  self.focus(self.panel.enemies);bar=self.scroll.verticalScrollBar();bar.setValue(100);self.app.processEvents();before=bar.value()
  self.wheel(self.panel.enemies,-120);self.assertGreater(bar.value(),before);self.assertEqual(self.panel.enemies.value(),12)
 def test_ignored_combo_wheel_scrolls_the_page(self):
  self.focus(self.panel.size);bar=self.scroll.verticalScrollBar();bar.setValue(100);self.app.processEvents();before=bar.value()
  self.wheel(self.panel.size,-120);self.assertGreater(bar.value(),before);self.assertEqual(self.panel.size.currentData(),8)
 def test_inner_spin_editor_wheel_also_preserves_value_and_scrolls(self):
  self.focus(self.panel.enemies);bar=self.scroll.verticalScrollBar();bar.setValue(100);self.app.processEvents();before=bar.value()
  self.wheel(self.panel.enemies.lineEdit(),-120);self.assertGreater(bar.value(),before);self.assertEqual(self.panel.enemies.value(),12)
 def test_keyboard_typing_and_arrows_still_edit_custom_values(self):
  w=self.panel.enemies;self.focus(w);w.lineEdit().selectAll();QTest.keyClicks(w.lineEdit(),'9');QTest.keyClick(w.lineEdit(),Qt.Key_Enter)
  self.assertEqual(w.value(),9);QTest.keyClick(w,Qt.Key_Down);self.assertEqual(w.value(),8)
  QTest.keyClick(w,Qt.Key_Up);self.assertEqual(w.value(),9);self.assertEqual(self.sent,[])
 def test_mouse_spin_step_button_still_edits(self):
  w=self.panel.enemies;self.focus(w);option=QStyleOptionSpinBox();w.initStyleOption(option)
  rect=w.style().subControlRect(QStyle.CC_SpinBox,option,QStyle.SC_SpinBoxDown,w)
  QTest.mouseClick(w,Qt.LeftButton,pos=rect.center());self.assertEqual(w.value(),11);self.assertEqual(self.sent,[])
 def test_explicit_popup_mouse_selection_still_edits_size(self):
  w=self.panel.size;self.focus(w);QTest.mouseClick(w,Qt.LeftButton,pos=QPoint(w.width()-5,w.height()//2));self.app.processEvents()
  self.assertTrue(w.view().isVisible());index=w.model().index(w.findData(32),0);rect=w.view().visualRect(index)
  # Let the native popup's opening-click release guard expire before a second click.
  QTest.qWait(QApplication.doubleClickInterval()+10)
  QTest.mouseMove(w.view().viewport(),rect.center())
  QTest.mouseClick(w.view().viewport(),Qt.LeftButton,pos=rect.center());self.app.processEvents()
  self.assertEqual(w.currentData(),32);self.assertEqual(self.sent,[])
 def test_combo_keyboard_navigation_still_edits(self):
  w=self.panel.size;self.focus(w);before=w.currentIndex();QTest.keyClick(w,Qt.Key_Down)
  self.assertEqual(w.currentIndex(),before+1);self.assertEqual(self.sent,[])
 def test_loaded_targets_survive_scrolling_and_emit_exact_requests(self):
  for size,count in ((8,20000),(32,5000)):
   with self.subTest(size=size):
    self.panel.load_target(size)
    for w in self.panel.findChildren(QSpinBox)+self.panel.findChildren(QComboBox):self.wheel(w,-360)
    self.assertTrue(self.panel.start());self.panel.menu_ready(True)
    self.assertEqual(self.sent[-1][1:],('run',[6,12,count,size,60,123456789]))
    self.panel.disconnected();self.panel.capable=self.panel.available=self.panel.status_available=True;self.panel.uncertain=False;self.panel._enable()
 def test_custom_enemy_nine_remains_legal_and_is_not_forced_to_twelve(self):
  self.panel.enemies.setValue(9);self.panel.bosses.setValue(4);self.panel.start();self.panel.menu_ready(True)
  self.assertEqual(self.sent[-1][1:],('run',[4,9,20000,8,60,123456789]))
 def test_inflight_controls_remain_locked_and_request_snapshot_unchanged(self):
  self.panel.start();before=self.panel._menu_args
  for w in self.panel.findChildren(QSpinBox)+self.panel.findChildren(QComboBox):self.assertFalse(w.isEnabled());self.wheel(w,-360)
  self.assertEqual(self.panel._menu_args,before);self.panel.menu_ready(True);self.assertEqual(self.sent[-1][2],list(before))

if __name__=='__main__':unittest.main()
