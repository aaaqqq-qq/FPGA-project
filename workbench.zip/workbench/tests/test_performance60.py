"""LAB60 actual counter acceptance and native GUI, fake replies only."""
from pathlib import Path
import json,sys,unittest
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test_adv_protocol import STRESS,SHOW,parsed,measured,control,done
from adv_protocol import AdvRequest,adv_command,parse_adv_reply,task_identity,FIELDS,timeout_for
from performance_cases import preset_args,performance_args
from adv_panel import AdvPanel
from control_core import parse_capabilities
from PySide6.QtWidgets import QApplication

def sample_args(frames=36000,backend='fpga',size=8):
 a=list(STRESS);a[0]=backend;a[2]=size;a[11]=frames;return tuple(a)

def timed(i=42,op='stress',args=None):
 args=args or sample_args();items,end=measured(i,op,args);frames=args[11] if op=='stress' else 0;t=task_identity(op,args)
 if op=='stress':
  items[3].update(logic_us=frames*1000,render_us=frames*5000,wait_us=frames*11000,elapsed_us=frames*16683,swaps=frames,late=frames)
  pipeline=int(args[0]=='fpga' and args[2]==8 and args[10]==0)
  fields=dict(scan_total=frames,max_scan_gap=1,missed_scans=0,pixel_changes=max(0,frames-1),pixel_first=1,pixel_last=2 if frames>1 else 1,max_logic_us=1200,max_render_us=6000,max_frame_us=17000,min_frame_us=16666,pipeline=pipeline,state_first=123,state_last=456,sample_points=16,hw_us=frames*4000,overlap_us=frames*500 if pipeline else 0,warmup_frames=1)
 else:fields={k:0 for k in FIELDS['ADV_TIMING'] if k not in ('id','op','task')}
 timing=parsed('ADV_TIMING',id=i,op=op,task=t,**fields);items.insert(-1,timing);return items,end

def progress(i,args,frames=600,**overrides):
 fields=dict(id=i,op='stress',task=task_identity('stress',args),frames=frames,total=args[11],elapsed_us=frames*16683,swaps=frames,uf=0,late=frames,scan_total=frames,missed_scans=0,pixel_changes=max(0,frames-1));fields.update(overrides)
 return parsed('ADV_PROGRESS',**fields)

def verdict(args=None,mutate=None,drop=None,section='alpha'):
 args=args or sample_args();items,end=timed(args=args);r=AdvRequest(42,'stress',args,1860,require_timing=True,request_identity={'ui_section':section})
 if mutate:mutate(items,end)
 for x in items:
  if x['kind_line']!=drop:r.feed(x)
 return r.finish(end)

class PerformanceWireTests(unittest.TestCase):
 def test_exact_schema_matches_current_firmware_document(self):
  schema=__import__('firmware_paths').project_root()/'docs/adv_protocol.json'
  data=json.loads(schema.read_text(encoding='utf8'));self.assertEqual({k:list(v) for k,v in FIELDS.items()},data['reply_fields']);self.assertEqual(data['line_max_payload_bytes'],509)
 def test36000_exact_frames_encoded_and_whole_budget_margin_retained(self):
  args=sample_args();self.assertIn(b'36000',adv_command(1,'stress',*args));self.assertEqual(timeout_for('stress',args),1860)
 def test_optional_perf_capability_is_strict_and_old_caps_still_connect(self):
  caps='CAPS fw=LAB23 proto=2 controls=PC lab=1 labx=1 adv=1 img=1 width=1280 height=720 hz=60'
  self.assertEqual(parse_capabilities(caps)['perf'],0);self.assertEqual(parse_capabilities(caps+' perf=1')['perf'],1);self.assertIsNone(parse_capabilities(caps+' perf=2'))
 def test_short_observation_never_claims_long_stability(self):
  r=verdict(sample_args(600));self.assertTrue(r['accepted_pass']);self.assertFalse(r['long_60fps_pass'])
 def test_long_scan_cadence_can_pass_with_honestly_reported_old_threshold_late(self):
  r=verdict();self.assertTrue(r['accepted_pass']);self.assertTrue(r['long_60fps_pass']);self.assertFalse(r['performance_60fps']);self.assertEqual(r['metric']['late'],36000);self.assertAlmostEqual(r['actual_fps'],59.94,places=2)
 def test_missing_or_malformed_timing_cannot_pass_perf_release(self):
  self.assertFalse(verdict(drop='ADV_TIMING')['accepted_pass']);items,end=timed();line=next(x['raw'] for x in items if x['kind_line']=='ADV_TIMING')
  for bad in (line+' unrecognized=1',line.replace(' warmup_frames=1',''),line+'x'*510):self.assertIsNone(parse_adv_reply(bad))
 def test_cpu_and_64_are_not_certified_without_changing_requested_load(self):
  for args in (sample_args(36000,'cpu'),sample_args(36000,size=64)):
   r=verdict(args);self.assertTrue(r['accepted_pass']);self.assertFalse(r['long_60fps_pass']);self.assertEqual(r['args'],list(args))
 def test_high2_requires_explicit_key_for_qualification(self):
  args=list(sample_args());args[9]=0;r=verdict(tuple(args),section='key');self.assertTrue(r['accepted_pass']);self.assertFalse(r['long_60fps_pass'])
 def test_each_scan_gate_fps_duration_warmup_or_uf_blocks_long_pass(self):
  mutations=[lambda a,b:a[3].update(elapsed_us=620000000),lambda a,b:a[3].update(elapsed_us=1000000),lambda a,b:a[3].update(uf=1)]
  for key,value in (('scan_total',36001),('max_scan_gap',2),('missed_scans',1),('warmup_frames',0)):
   mutations.append(lambda a,b,k=key,v=value:a[-2].update({k:v}))
  for mutate in mutations:self.assertFalse(verdict(mutate=mutate)['long_60fps_pass'])
 def test_alpha0_repeated_front_samples_are_honest_not_whole_frame_motion_failure(self):
  args=list(sample_args());args[8]=0
  r=verdict(tuple(args),mutate=lambda a,b:a[-2].update(pixel_changes=0,pixel_first=777,pixel_last=777));self.assertTrue(r['long_60fps_pass']);self.assertNotEqual(r['timing']['state_first'],r['timing']['state_last'])
 def test_overlap_has_its_own_apb_interval_and_cannot_exceed_engine_busy(self):
  self.assertTrue(verdict()['accepted_pass'])
  self.assertTrue(verdict(mutate=lambda a,b:a[-2].update(overlap_us=a[3]['logic_us']+1))['accepted_pass'])
  self.assertFalse(verdict(mutate=lambda a,b:a[-2].update(overlap_us=a[-2]['hw_us']+1))['accepted_pass'])
 def test_progress_identity_sequence_and_final_counts_are_checked(self):
  args=sample_args();r=AdvRequest(42,'stress',args,1860,require_timing=True)
  self.assertTrue(r.feed(progress(42,args)));self.assertTrue(r.feed(progress(42,args,1200)));self.assertFalse(r.feed(progress(42,args,600)))
  items,end=timed(args=args)
  for x in items:r.feed(x)
  self.assertFalse(r.finish(end)['accepted_pass']);self.assertEqual(len(r.progress),2)
 def test_progress_alone_or_wrong_task_can_never_pass(self):
  args=sample_args();r=AdvRequest(42,'stress',args,1860,require_timing=True);self.assertFalse(r.feed(progress(42,args,task=0)));self.assertFalse(r.finish(done(42,'stress',completed=36000))['accepted_pass'])
 def test_show_and_verify_require_zero_timing_extensions(self):
  for op,args in (('show',SHOW),('verify',('alpha',))):
   r=AdvRequest(42,op,args,240,require_timing=True);items,end=timed(op=op,args=args)
   for x in items:r.feed(x)
   self.assertTrue(r.finish(end)['accepted_pass'])

class PerformanceWidgetTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.app=QApplication.instance() or QApplication(['perf60-tests'])
 def setUp(self):
  self.now=10.;self.p=AdvPanel(clock=lambda:self.now);self.sent=[];self.p.command_requested.connect(lambda i,o,a:self.sent.append((i,o,a)));self.addCleanup(self.p.deleteLater)
 def feed(self,items):
  for item in items:self.p.ingest(item)
 def ready(self,perf=1):
  p=self.p;p.set_capabilities(dict(fw='LAB23',adv=1,img=1,perf=perf));p.set_available(True);self.feed(control(p._request.request_id,'status',0));p.request('enter');self.feed(control(p._request.request_id,'enter'));return p
 def finish(self):
  r=self.p._request;items,end=timed(r.request_id,r.operation,r.args);self.feed([*items,end]);return self.p.results[-1]
 def test_preset_load_is_explicit_repeatable_and_sends_nothing(self):
  p=self.ready();before=len(self.sent);p.performance_preset.setCurrentIndex(2);p.frames.setValue(36000);p.load_performance_preset();self.assertEqual(len(self.sent),before);self.assertEqual(p.count.value(),20000);self.assertEqual(p.stress_size.value(),8);self.assertEqual(p.seed.text(),'1');self.assertEqual(p.frames.value(),36000)
 def test_exact_current_frames_are_not_silently_replaced_by_shortcut(self):
  p=self.ready();p.frames.setValue(12345);self.assertIsNone(p.performance_duration.currentData());p.start_performance();self.assertEqual(self.sent[-1][2][11],12345)
 def test_shortcut_selects36000_and_busy_repeat_cannot_mutate_inputs(self):
  p=self.ready();p.performance_duration.setCurrentIndex(p.performance_duration.findData(36000));self.assertEqual(p.frames.value(),36000);p.start_performance();n=len(self.sent);old=p.count.value();self.assertFalse(p.repeat_performance());self.assertEqual(len(self.sent),n);self.assertEqual(p.count.value(),old)
 def test_old_perf_missing_keeps_short_operations_but_rejects_long_without_degrading(self):
  p=self.ready(0);p.frames.setValue(36000);self.assertFalse(p.start_stress());self.assertEqual(p.frames.value(),36000);p.frames.setValue(120);self.assertTrue(p.start_stress())
 def test_cpu64_and_key_off_are_rejected_before_stability_send(self):
  p=self.ready();n=len(self.sent);p.backend.setCurrentIndex(1);self.assertFalse(p.start_performance());p.backend.setCurrentIndex(0);p.stress_size.setValue(64);self.assertFalse(p.start_performance());self.assertEqual(p.stress_size.value(),64)
  p.stress_size.setValue(8);p.set_section('key');p.stress_key.setChecked(False);self.assertFalse(p.start_performance());self.assertEqual(len(self.sent),n)
 def test_current_request_progress_only_real_data_changes_bar_not_host_wait(self):
  p=self.ready();p.frames.setValue(36000);p.start_performance();r=p._request;self.now+=12;p.tick();self.assertEqual(p.performance_progress.value(),0);self.assertIn('主机',p.performance_wait.text())
  self.feed([progress(r.request_id+1,r.args)]);self.assertEqual(p.performance_progress.value(),0);self.feed([progress(r.request_id,r.args)]);self.assertEqual(p.performance_progress.value(),600);self.assertTrue(p.pending);self.assertIn('非最终验收',p.performance_live.text())
 def test_long_final_shows_actual_fps_and_scoped_content_evidence(self):
  p=self.ready();p.stress_size.setValue(8);p.frames.setValue(36000);p.start_performance();result=self.finish();self.assertTrue(result['long_60fps_pass']);self.assertIn('60FPS长测通过',p.summary.text());self.assertIn('59.94FPS',p.summary.text());self.assertIn('不是全帧hash',p.timing_detail.text());self.assertIn('不能相加',p.timing_detail.text())
 def test_exact_repeat_keeps_old_n_and_frames_after_user_edits(self):
  p=self.ready();p.frames.setValue(600);p.count.setValue(99);p.start_performance();original=tuple(p._request.args);self.finish();p.count.setValue(3);p.frames.setValue(36000);self.assertTrue(p.repeat_performance());self.assertEqual(tuple(p._request.args),original);self.assertEqual(p.count.value(),99);self.assertEqual(p.frames.value(),600)
 def test_cancelled_long_record_retains_plan_and_never_passes(self):
  p=self.ready();p.frames.setValue(36000);p.start_performance();r=p._request;p.stop_and_return();cancel=p._cancel_id;self.feed([done(cancel,'cancel'),done(r.request_id,'stress',status='CANCELLED',code='CANCEL')]);record=p.export_document()['performance_cases'][-1];self.assertEqual(record['target_frames'],36000);self.assertEqual(record['status'],'CANCELLED');self.assertFalse(record['long_60fps_pass'])

if __name__=='__main__':unittest.main()
