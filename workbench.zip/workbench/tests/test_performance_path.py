"""B2 optional path diagnostics. Synthetic vectors/Qt only, no hardware access."""
from pathlib import Path
import copy,json,unittest
from test_performance60 import timed,sample_args
from adv_protocol import AdvRequest,parse_adv_reply,task_identity,FIELDS,OPTIONAL_FIELDS,PATHS,PATH_REASONS
from adv_panel import AdvPanel
from PySide6.QtWidgets import QApplication

def path_reply(args=None,i=42,path='direct8',reason='none',**extra):
 args=args or sample_args(600);frames=args[11]
 fields=dict(id=i,op='stress',task=task_identity('stress',args),path=path,reason=reason,passes=frames,micro=frames*args[1],prime_steps=1,prime_logic_us=14100,measured_steps=frames-1,total_steps=frames);fields.update(extra)
 line='ADV_PATH '+' '.join(k+'='+str(v) for k,v in fields.items())
 return parse_adv_reply(line)

def verdict(args=None,path=None,duplicate=False):
 args=args or sample_args(600);items,end=timed(args=args);request=AdvRequest(42,'stress',args,1860,require_timing=True,request_identity={'ui_section':'key'})
 for reply in items:request.feed(reply)
 if path is not None:
  request.feed(path)
  if duplicate:request.feed(path)
 return request.finish(end)

class PathWireTests(unittest.TestCase):
 def test_exact_optional_schema_and_enums_match_current_firmware(self):
  doc=__import__('firmware_paths').project_root()/'docs/adv_protocol.json';data=json.loads(doc.read_text(encoding='utf-8'))
  self.assertEqual({k:list(v) for k,v in OPTIONAL_FIELDS.items()},data['optional_reply_fields']);self.assertEqual(PATHS,set(data['path_enums']));self.assertEqual(PATH_REASONS,set(data['reason_enums']))
 def test_original_timing_fields_not_extended(self):
  self.assertNotIn('ADV_PATH',FIELDS);self.assertEqual(OPTIONAL_FIELDS['ADV_PATH'],('id','op','task','path','reason','passes','micro','prime_steps','prime_logic_us','measured_steps','total_steps'))
 def test_missing_diagnostic_stays_optional_not_algorithm_based_60(self):
  short=verdict();self.assertTrue(short['accepted_pass']);self.assertFalse(short['long_60fps_pass']);self.assertIsNone(short['path'])
  long=verdict(sample_args());self.assertTrue(long['long_60fps_pass'])
 def test_direct_path_prime_accounting_preserved(self):
  p=path_reply();r=verdict(path=p);self.assertTrue(r['accepted_pass']);self.assertEqual(r['path']['prime_logic_us'],14100);self.assertEqual(r['path']['measured_steps'],599)
 def test_unknown_fields_enum_or_nonstress_or_prime2_rejected(self):
  line=path_reply()['raw']
  for value in [line+' extra=1',line.replace('path=direct8','path=magic'),line.replace('reason=none','reason=unknown'),line.replace('op=stress','op=verify'),line.replace('prime_steps=1','prime_steps=2')]:self.assertIsNone(parse_adv_reply(value))
 def test_wrong_task_duplicate_or_incomplete_step_accounting_blocks_pass(self):
  for change in [dict(task=0),dict(total_steps=599),dict(total_steps=600,measured_steps=598),dict(prime_steps=0,measured_steps=600)]:self.assertFalse(verdict(path=path_reply(**change))['accepted_pass'])
  self.assertFalse(verdict(path=path_reply(),duplicate=True)['accepted_pass'])
 def test_ordered_and_commutable_large_paths_keep_exact_load(self):
  args=sample_args(600,size=56)
  for path,reason in [('tile8_ordered','materials_fit'),('tile8_commute','single_color_key')]:
   r=verdict(args,path_reply(args,path=path,reason=reason,passes=1200,micro=600000,prime_steps=0,prime_logic_us=0,measured_steps=600))
   self.assertTrue(r['accepted_pass']);self.assertEqual(r['args'],list(args));self.assertFalse(r['long_60fps_pass'])
 def test_commutable_keyoff_and_unaligned_size_rejected(self):
  args=list(sample_args(600,size=56));args[9]=0
  self.assertFalse(verdict(tuple(args),path_reply(tuple(args),path='tile8_commute',reason='single_color_key'))['accepted_pass'])
  args=sample_args(600,size=55)
  self.assertFalse(verdict(args,path_reply(args,path='tile8_ordered',reason='materials_fit'))['accepted_pass'])
 def test_fallback_reason_not_hidden_or_treated_as_60(self):
  args=sample_args(600,size=56);r=verdict(args,path_reply(args,path='rect',reason='materials_over16',passes=0,micro=0,prime_steps=0,prime_logic_us=0,measured_steps=600))
  self.assertTrue(r['accepted_pass']);self.assertEqual(r['path']['reason'],'materials_over16');self.assertFalse(r['long_60fps_pass'])
 def test_cpu_and_rect_cannot_claim_op2_work(self):
  args=sample_args(600,'cpu');self.assertFalse(verdict(args,path_reply(args,path='cpu',reason='cpu_reference'))['accepted_pass'])
  r=verdict(args,path_reply(args,path='cpu',reason='cpu_reference',passes=0,micro=0,prime_steps=0,prime_logic_us=0,measured_steps=600));self.assertTrue(r['accepted_pass']);self.assertFalse(r['long_60fps_pass'])
 def test_job_and_descriptor_are_cumulative_and_consistent(self):
  for values in [dict(passes=1,micro=0),dict(passes=5,micro=4),dict(passes=0,micro=1)]:self.assertFalse(verdict(path=path_reply(**values))['accepted_pass'])

class PathWidgetTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.app=QApplication.instance() or QApplication(['path-offline-tests'])
 def setUp(self):self.p=AdvPanel(clock=lambda:10);self.addCleanup(self.p.deleteLater)
 def finish_display(self,args,p=None):
  r=verdict(args,p);self.p.results.append(r);self.p._refresh_results();return r
 def test_optional_missing_cannot_show_old_path(self):
  self.finish_display(sample_args(600),path_reply());self.assertIn('预热预计算1步',self.p.path_detail.text());self.p.results=[];self.finish_display(sample_args(600));self.assertIn('未提供',self.p.path_detail.text());self.assertNotIn('预热预计算1步',self.p.path_detail.text())
 def test_actual_fallback_and_prime_are_clear_without_fps_inference(self):
  args=sample_args(600,size=56);r=self.finish_display(args,path_reply(args,path='rect',reason='materials_over16',passes=0,micro=0,prime_steps=0,prime_logic_us=0,measured_steps=600))
  self.assertIn('逐精灵矩形回退',self.p.path_detail.text());self.assertIn('超过16种',self.p.path_detail.text());self.assertIn('不是每帧值',self.p.path_detail.text());self.assertFalse(r['long_60fps_pass'])
 def test_raw_path_export_retains_prime_and_count_scope(self):
  self.finish_display(sample_args(600),path_reply());doc=self.p.export_document();self.assertEqual(doc['results'][0]['path']['total_steps'],600);self.assertTrue(any('预热预计算' in note for note in doc['notes']))

if __name__=='__main__':unittest.main()
