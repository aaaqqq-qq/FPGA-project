"""GAME_LOAD wire, acceptance, queue and native MainWindow; no device access."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from pathlib import Path
import sys,unittest,json
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
sys.path.insert(0,str(Path(__file__).resolve().parent))
from game_load_protocol import *
from game_load_panel import GameLoadPanel
from game_actions import ActionSequence,config_value_command
from control_core import parse_capabilities
import test_ui as base
from test_adv_ui import OwnerStatusLink
from test_ui_v23 import STAT

ARGS=(6,12,5000,8,60,123456789)
CAPS='CAPS fw=LAB23 proto=2 controls=PC lab=1 labx=1 adv=1 img=1 perf=1 game_load=1 gsizes=7 width=1280 height=720 hz=60'
def item(line_kind,**values):
    raw=line_kind+' '+' '.join(f'{k}={v}' for k,v in values.items());result=parse_game_load_reply(raw)
    assert result is not None,raw
    return result
def sample(i=42,args=ARGS,*,status='PASS',reason='complete',changes=None):
    b,m,n,size,frames,seed=args
    ack=item('GLOAD_ACK',id=i,op='run',status='OK',kind='GAME_LOAD',**dict(zip(ARG_NAMES,args)),cfg=123,deadline_us=min(1800000000,max(20000000,frames*200000)))
    ready=item('GLOAD_READY',id=i,warmup=2,prepare_us=50000,initial_fill=n,kind='GAME_LOAD')
    s=dict(frames=frames,us=round(frames*1e6/60),swaps=frames,scans=frames,gap=1,missed=0,uf=0,ldrop=0,lover=0,nmin=n,nmax=n,bmin=b,bmax=b,mmin=m,mmax=m,logicmax=5000,rendermax=7000,late=1)
    if changes:s.update(changes)
    stat=item('GLOAD_STAT',id=i,**s)
    detail=item('GLOAD_DETAIL',id=i,frames=frames,fill=50,recycle=10,keep=8,hits=2,damage=20,bhits=10,mhits=2,size=size,seed=seed,cfg=123,guards=0,logerr=0,qly=1,lod=0,qmin=0,qmax=1,lodsum=0,fxdrop=0,ddrop=0,fault=0,ticks=frames,runtime=frames,mode=1,hw=1,active=1,paused=0,invincible=0,autoplay=1,collision='scaled')
    done=item('GLOAD_DONE',id=i,status=status,reason=reason)
    return [ack,ready,stat,detail,done]
def result(items=None,args=ARGS):
    r=GameLoadRequest(42,args)
    entries=items or sample(args=args)
    for x in entries[:-1]:r.feed(x)
    return r.finish(entries[-1])

class GameLoadWireTests(unittest.TestCase):
    def test_commands_have_exact_id_and_order(self):
        self.assertEqual(game_load_command(42,'run',*ARGS),b':gload run 42 6 12 5000 8 60 123456789\n')
        self.assertEqual(game_load_command(42,'cancel'),b':gload cancel 42\n')
    def test_invalid_sizes_counts_topology_frames_seed_are_rejected(self):
        for pos,val in [(0,0),(0,7),(1,13),(2,0),(2,20001),(3,64),(3,12),(4,59),(4,36001),(5,0),(5,0x100000000),(2,True)]:
            a=list(ARGS);a[pos]=val
            with self.subTest(pos=pos,value=val),self.assertRaises(ValueError):game_load_command(1,'run',*a)
    def test_missing_duplicate_negative_or_forged_reply_is_rejected(self):
        raw=sample()[2]['raw']
        for bad in [raw+' frames=60',raw.replace(' nmin=5000',''),raw.replace(' missed=0',' missed=-1'),raw.replace('id=42','id=x'),raw+' fragment']:
            self.assertIsNone(parse_game_load_reply(bad))
    def test_capability_rejects_old_fw_or_partial_new_flags(self):
        self.assertEqual(parse_capabilities(CAPS)['game_load'],1)
        self.assertEqual(parse_capabilities(CAPS.replace(' game_load=1 gsizes=7',''))['game_load'],0)
        self.assertEqual(parse_capabilities(CAPS.replace(' gsizes=7',''))['game_load'],0)
        self.assertIsNone(parse_capabilities(CAPS.replace('game_load=1','game_load=2')))
    def test_full_short_pass_is_never_long_stability(self):
        r=result();self.assertTrue(r['accepted_pass']);self.assertFalse(r['long_60fps_pass']);self.assertEqual(r['actual_fps'],60)
    def test_full_long_pass_uses_raw_counts_not_rounded_fps(self):
        args=(*ARGS[:4],36000,ARGS[5]);r=result(args=args);self.assertTrue(r['long_60fps_pass']);self.assertEqual(r['stat']['us'],600000000)
    def test_each_missing_evidence_fragment_fails(self):
        for index in range(4):
            entries=sample();entries.pop(index);self.assertFalse(result(entries)['accepted_pass'])
    def test_wrong_request_identity_cannot_be_accepted(self):
        entries=sample();entries[0]['n']=4096;self.assertFalse(result(entries)['accepted_pass'])
        r=GameLoadRequest(42,ARGS);self.assertFalse(r.feed(sample(43)[0]))
    def test_each_counter_and_actual_load_gate(self):
        for key,value in [('swaps',59),('scans',61),('gap',2),('missed',1),('uf',1),('ldrop',1),('lover',1),('nmin',4999),('bmin',5),('mmin',11),('us',2000000)]:
            self.assertFalse(result(sample(changes={key:value}))['accepted_pass'],key)
    def test_guard_config_fault_collision_or_disabled_damage_fails(self):
        for key,value in [('guards',1),('cfg',124),('fault',1),('logerr',1),('size',16),('seed',1),('invincible',1),('collision','fixed')]:
            entries=sample();entries[3][key]=value;self.assertFalse(result(entries)['accepted_pass'],key)
    def test_counter_regression_invalidates_later_good_final(self):
        r=GameLoadRequest(42,ARGS);entries=sample()
        for x in entries[:3]:r.feed(x)
        low=dict(entries[2]);low['frames']=30;r.feed(low)
        for x in entries[2:4]:r.feed(x)
        self.assertFalse(r.finish(entries[4])['accepted_pass'])
    def test_failure_is_searchable_only_with_full_correct_load_evidence(self):
        entries=sample(status='FAIL',reason='timing',changes={'us':2000000,'scans':120,'missed':60,'gap':2})
        self.assertTrue(result(entries)['search_eligible']);entries[2]['nmin']=10;self.assertFalse(result(entries)['search_eligible'])
    def test_bounds_keep_duration_separate_and_no_exact_maximum(self):
        good=result();bad=result(sample(status='FAIL',reason='timing',changes={'us':2000000}));bad['args'][2]=6144
        rows=boundary_rows([good,bad]);self.assertEqual(rows[0]['verified_lower'],5000);self.assertEqual(rows[0]['failed_upper'],6144);self.assertIsNone(rows[0]['exact_maximum'])
        long=result(args=(*ARGS[:4],36000,ARGS[5]));self.assertEqual(len(boundary_rows([good,long])),2)
    def test_natural_battle_transaction_waits_each_set_and_exact_limit_ack(self):
        sent=[];done=[];menu=[];q=ActionSequence(sent.append,lambda:menu.append(1),done.append)
        q.start_battle(16,5000,1,6,2);self.assertEqual(sent,[]);q.feed('UI MENU')
        self.assertEqual(sent[-1],b':set enemy_bullet_size 16\n')
        for _ in range(3):q.feed('OK set')
        self.assertEqual(sent[-1],b':limit 5000\n');self.assertFalse(q.feed('OK limit 4096'));q.feed('OK limit 5000');self.assertEqual(sent[-1],b':mode 2\n');q.feed('OK mode 2')
        self.assertTrue(done[-1]['success']);self.assertEqual(done[-1]['applied']['bullet_limit'],5000)
    def test_size_setter_discrete_and_menu_only(self):
        for size in SIZES:self.assertIn(str(size).encode(),config_value_command('enemy_bullet_size',size))
        with self.assertRaises(ValueError):config_value_command('enemy_bullet_size',9)
    def test_stale_details_and_partial_timeout_are_not_boundary(self):
        entries=sample();entries[3]['frames']=30;self.assertFalse(result(entries)['accepted_pass'])
        entries=sample(status='FAIL',reason='timeout',changes={'frames':30,'swaps':30,'scans':1200,'us':20000000});r=result(entries)
        self.assertFalse(r['search_eligible']);self.assertIsNone(boundary_rows([r])[0]['failed_upper'])
    def test_quality_is_saved_for_whole_window(self):
        entries=sample();entries[3].update(qmin=0,qmax=1,lodsum=10,fxdrop=30,ddrop=8)
        r=result(entries);self.assertEqual(r['visual_policy'],dict(qmin=0,qmax=1,lodsum=10,fxdrop=30,ddrop=8));self.assertTrue(r['accepted_pass'])
    def test_partial_timeout_can_guide_search_but_never_complete_boundary(self):
        entries=sample(status='FAIL',reason='timeout',changes={'frames':30,'swaps':30,'scans':1200,'missed':1170,'gap':40,'us':20000000});entries[3]['frames']=30
        r=result(entries);self.assertTrue(r['partial_timeout_observation']);self.assertFalse(r['accepted_pass']);self.assertFalse(r['search_eligible']);self.assertIsNone(boundary_rows([r])[0]['failed_upper']);self.assertEqual(boundary_rows([r])[0]['partial_timeouts'],[5000])
        for key,value in [('guards',1),('logerr',1),('cfg',124),('frames',20)]:
            bad=[dict(e) for e in entries];bad[3][key]=value;self.assertFalse(result(bad)['partial_timeout_observation'])
    def test_static_or_wrong_mode_cannot_pass(self):
        for key,value in [('ticks',0),('ticks',30),('mode',2),('hw',0),('active',0),('paused',1)]:
            entries=sample();entries[3][key]=value;self.assertFalse(result(entries)['accepted_pass'])
        entries=sample();entries[3]['ticks']=59;self.assertTrue(result(entries)['accepted_pass'])
    def test_new_firmware_pressure_enters_menu_before_limit_then_mode(self):
        sent=[];done=[];q=ActionSequence(sent.append,lambda:None,done.append);q.start_pressure(256,False)
        self.assertFalse(sent);q.feed('UI MENU');self.assertEqual(sent[-1],b':limit 256\n');q.feed('OK limit 256');self.assertEqual(sent[-1],b':mode 4\n');q.feed('OK mode 4');self.assertTrue(done[-1]['success'])
    def test_window_minmax_cannot_reset_to_hide_earlier_lower_load(self):
        entries=sample();r=GameLoadRequest(42,ARGS)
        for x in entries[:2]:r.feed(x)
        earlier=dict(entries[2],frames=30,us=500000,swaps=30,scans=30,nmin=4999);r.feed(earlier)
        for x in entries[2:4]:r.feed(x)
        self.assertFalse(r.finish(entries[4])['accepted_pass'])
    def test_detail_before_stat_and_wrong_ready_kind_are_rejected(self):
        entries=sample();entries[2],entries[3]=entries[3],entries[2];self.assertFalse(result(entries)['accepted_pass'])
        self.assertIsNone(parse_game_load_reply(sample()[1]['raw'].replace('kind=GAME_LOAD','kind=ADV')))

class GameLoadPanelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=base.QApplication.instance() or base.QApplication(['game-load-tests'])
    def setUp(self):
        self.now=10.;self.p=GameLoadPanel(clock=lambda:self.now);self.sent=[];self.menus=[]
        self.p.command_requested.connect(lambda i,o,a:self.sent.append((i,o,a)));self.p.menu_requested.connect(lambda:self.menus.append(1));self.addCleanup(self.p.deleteLater)
    def ready(self):
        self.p.set_capabilities(parse_capabilities(CAPS));self.p.set_available(True)
        self.p.ingest(item('GLOAD_ACK',id=self.p._status_id,op='status',status='OK',running=0,current=0));return self.p
    def start_run(self):
        p=self.ready();self.assertTrue(p.start());self.assertIsNone(p._request);p.menu_ready(True);return p
    def complete(self,status='PASS',reason='complete',changes=None):
        for x in sample(self.p._request.request_id,self.p._request.args,status=status,reason=reason,changes=changes):self.p.ingest(x)
        return self.p.results[-1]
    def test_start_requires_new_capability_and_confirmed_idle(self):
        self.p.set_available(True);self.assertFalse(self.p.start());self.p.set_capabilities(parse_capabilities(CAPS));self.assertFalse(self.p.start())
    def test_menu_confirmation_precedes_run_and_default_is60(self):
        p=self.ready();p.start();self.assertEqual(self.menus,[1]);self.assertEqual(self.sent[-1][1],'status');p.menu_ready(True);self.assertEqual(self.sent[-1][1],'run');self.assertEqual(self.sent[-1][2][4],60)
        self.assertEqual(p.table.horizontalHeaderItem(7).text(),'错过换帧 / 欠流')
        self.assertIn('60Hz',p.scan_notice.text());self.assertIn('重复上一幅游戏画面',p.scan_notice.text());self.assertIn('均为0',p.scan_notice.text())
    def test_full_matrix_registered126_cases_single_request(self):
        p=self.ready();p.matrix.setChecked(True);p.start();self.assertEqual(len(p.plans[-1]['cases']),126);self.assertEqual(len(p.queue),125);p.menu_ready(True);self.assertEqual(sum(o=='run' for _,o,_ in self.sent),1)
    def test_valid_failure_descends_preserving_both_cases(self):
        p=self.start_run();r=self.complete('FAIL','timing',{'us':2000000,'scans':120,'missed':60,'gap':2});self.assertTrue(r['search_eligible']);self.assertEqual(p.queue[0]['args'][2],4096);p.tick();p.menu_ready(True);self.complete();self.assertEqual(len(p.results),2);self.assertEqual(boundary_rows(p.results)[0]['verified_lower'],4096);self.assertEqual(boundary_rows(p.results)[0]['failed_upper'],5000)
    def test_failed64_starts_new32_request_without_mutating_original(self):
        p=self.ready();p.count.setValue(64);p.start();p.menu_ready(True)
        original_id=p._request.request_id;original_args=tuple(p._request.args)
        original_sent=tuple(self.sent[-1][2])
        failed=self.complete('FAIL','timing',{'us':2000000,'scans':120,'missed':60,'gap':2})
        self.assertTrue(failed['search_eligible']);self.assertEqual(failed['args'][2],64)
        self.assertEqual(failed['stat']['nmin'],64);self.assertEqual(failed['stat']['nmax'],64)
        self.assertEqual(p.queue[0]['args'][2],32);self.assertEqual(p.count.value(),64)
        p.tick();p.menu_ready(True)
        self.assertNotEqual(p._request.request_id,original_id);self.assertEqual(p._request.args[2],32)
        self.assertEqual(tuple(failed['args']),original_args);self.assertEqual(original_sent,original_args)
        self.assertEqual(self.sent[-1],(p._request.request_id,'run',list(p._request.args)))
        self.complete();bounds=boundary_rows(p.results)[0]
        self.assertEqual(bounds['verified_lower'],32);self.assertEqual(bounds['failed_upper'],64)
    def test_small_descent_follows_visible_steps_and_notice(self):
        p=self.ready();p.count.setValue(64);p.start();p.menu_ready(True);ids=[]
        for expected in (64,32,16,8,4,2,1):
            self.assertEqual(p._request.args[2],expected);ids.append(p._request.request_id)
            result=self.complete('FAIL','timing',{'us':2000000,'scans':120,'missed':60,'gap':2})
            self.assertEqual(result['args'][2],expected)
            self.assertEqual(result['stat']['nmin'],expected);self.assertEqual(result['stat']['nmax'],expected)
            if expected>1:p.tick();p.menu_ready(True)
        self.assertEqual(len(set(ids)),7);self.assertFalse(p.queue);self.assertIsNone(p._request)
        self.assertEqual(p.count.value(),64);self.assertTrue(all(not r['accepted_pass'] for r in p.results))
        self.assertEqual(p.fps_notice.text(),'测试帧率请看本面板实际FPS；显示器右侧FPS沿用上一次普通游戏读数，测试时不更新。')
        self.assertTrue(any('64 / 32 / 16 / 8 / 4 / 2 / 1' in w.text() for w in p.findChildren(base.QLabel)))
    def test_disabled_descent_does_not_change_quantity(self):
        p=self.ready();p.descend.setChecked(False);p.start();p.menu_ready(True);self.complete('FAIL','timing',{'us':2000000});self.assertFalse(p.queue);self.assertEqual(p.count.value(),5000)
    def test_cancel_ack_does_not_release_original_run(self):
        p=self.start_run();i=p._request.request_id;p.stop();self.assertEqual(self.sent[-1],(i,'cancel',[]));p.ingest(item('GLOAD_ACK',id=i,op='cancel',status='OK'));self.assertTrue(p.blocks_game)
        p.ingest(item('GLOAD_DONE',id=i,status='CANCEL',reason='cancel'));self.assertFalse(p.blocks_game);self.assertFalse(p.results[-1]['accepted_pass'])
    def test_cancel_matrix_keeps_unrun_in_export(self):
        p=self.ready();p.matrix.setChecked(True);p.start();p.menu_ready(True);p.stop();p.ingest(item('GLOAD_DONE',id=p._request.request_id,status='CANCEL',reason='cancel'));p.tick()
        self.assertEqual(sum(c['status']=='NOT_RUN_CANCELLED' for c in p.export_document()['plans'][-1]['cases']),125);self.assertEqual(sum(o=='run' for _,o,_ in self.sent),1)
    def test_wrong_id_done_cannot_unlock(self):
        p=self.start_run();p.ingest(item('GLOAD_DONE',id=p._request.request_id+10,status='PASS',reason='complete'));self.assertTrue(p.blocks_game);self.assertFalse(p.results)
    def test_timeout_cancel_and_uncertain_until_status(self):
        p=self.start_run();self.now=p._deadline;p.tick();self.assertEqual(self.sent[-1][1],'cancel');self.now=p._deadline;p.tick();self.assertTrue(p.uncertain);self.assertFalse(p.start());self.assertEqual(p.results[-1]['status'],'TIMEOUT')
        p.query_status();p.ingest(item('GLOAD_ACK',id=p._status_id,op='status',status='OK',running=0,current=0));self.assertFalse(p.blocks_game)
    def test_reconnect_active_can_cancel_foreign_id_without_acceptance(self):
        p=self.p;p.set_capabilities(parse_capabilities(CAPS));p.set_available(True);p.ingest(item('GLOAD_ACK',id=p._status_id,op='status',status='OK',running=1,current=222));p.stop();self.assertEqual(self.sent[-1],(222,'cancel',[]));p.ingest(item('GLOAD_DONE',id=222,status='CANCEL',reason='cancel'));self.assertFalse(p.blocks_game);self.assertFalse(p.results)
    def test_disconnect_preserves_incomplete_and_stops_queue(self):
        p=self.start_run();p.disconnected();self.assertEqual(p.results[-1]['status'],'DISCONNECTED');self.assertFalse(p.results[-1]['accepted_pass']);self.assertFalse(p.queue)
    def test_partial_evidence_never_descends_or_continues_matrix(self):
        p=self.ready();p.matrix.setChecked(True);p.start();p.menu_ready(True);p.ingest(item('GLOAD_DONE',id=p._request.request_id,status='FAIL',reason='timing'));self.assertFalse(p.queue);self.assertFalse(p.results[-1]['search_eligible'])
    def test_export_is_serializable_and_separate_from_adv(self):
        p=self.start_run();self.complete();doc=p.export_document();json.dumps(doc);self.assertEqual(doc['schema'],'ti60_game_load_ui_v2_pipe5');self.assertEqual(doc['results'][0]['kind'],'GAME_LOAD');self.assertNotIn('ADV_STRESS',json.dumps(doc))
    def test_late_done_after_deadline_is_not_pass(self):
        p=self.start_run();entries=sample(p._request.request_id,p._request.args)
        for x in entries[:-1]:p.ingest(x)
        self.now=p._deadline;p.ingest(entries[-1]);self.assertFalse(p.results[-1]['accepted_pass']);self.assertIn('主机等待超时',p.results[-1]['errors'])
    def test_all126_cases_progress_without_changing_requested_count(self):
        p=self.ready();p.matrix.setChecked(True);p.start()
        for _ in range(126):
            p.menu_ready(True);self.assertEqual(p._request.args[2],5000);self.complete();p.tick()
        self.assertFalse(p.blocks_game);self.assertEqual(len(p.results),126);self.assertEqual(len(boundary_rows(p.results)),126)
    def test_timeout_has_own_observation_and_new_lower_request(self):
        p=self.start_run();entries=sample(p._request.request_id,p._request.args,status='FAIL',reason='timeout',changes={'frames':30,'swaps':30,'scans':1200,'missed':1170,'gap':40,'us':20000000});entries[3]['frames']=30
        for x in entries:p.ingest(x)
        self.assertTrue(p.results[-1]['partial_timeout_observation']);self.assertEqual(p.queue[0]['args'][2],4096);self.assertIsNone(boundary_rows(p.results)[0]['failed_upper'])

class GameLoadOwnerLink(OwnerStatusLink):
    def __init__(self,running=0):
        super().__init__();self.lines=[CAPS];self.running=running
    def send(self,payload):
        super().send(payload);parts=payload.decode().split()
        if parts[:2]==[':gload','status']:self.lines.append(item('GLOAD_ACK',id=int(parts[2]),op='status',status='OK',running=self.running,current=333 if self.running else 0)['raw'])

class GameLoadMainTests(unittest.TestCase):
    setUpClass=classmethod(base.NativeUIContracts.setUpClass.__func__)
    def setUp(self):
        base.NativeUIContracts.setUp(self)
        clock=patch('main.time.monotonic',return_value=102.);clock.start();self.addCleanup(clock.stop)
    dispose_window=base.NativeUIContracts.dispose_window
    poll=base.NativeUIContracts.poll
    def ready(self):
        link=GameLoadOwnerLink();self.window.link=link
        for _ in range(5):self.poll()
        link.lines=[STAT];self.poll();return link
    def test_connect_orders_gload_adv_labx_no_parallel_ownership(self):
        link=self.ready();ops=[p.decode().split()[0] for p in link.sent];self.assertEqual(ops[:3],[':gload',':adv',':labx']);self.assertTrue(self.window.game_ready());self.assertTrue(self.window.game_apply.isEnabled())
    def test_active_gload_blocks_all_other_commands_and_flash(self):
        link=GameLoadOwnerLink(1);self.window.link=link
        for _ in range(4):self.poll()
        self.assertEqual(len(link.sent),1);self.assertFalse(self.window.game_ready());self.assertFalse(self.window.download_button.isEnabled())
        self.window.start_custom_battle();self.window.start_mode();self.window.run_job(False);self.assertEqual(len(link.sent),1)
    def test_real_ui_menu_ack_then_one_owned_run(self):
        link=self.ready();before=len(link.sent);actions=list(link.actions);self.window.gload.start();self.assertTrue(self.window.game_sequence.busy);self.assertFalse(any(x.startswith(b':gload run') for x in link.sent))
        self.assertEqual(link.sent[before:],[b':menu\n']);self.assertEqual(link.actions,actions)
        link.lines=['UI MENU'];self.poll();self.assertEqual(sum(x.startswith(b':gload run') for x in link.sent),1);self.assertFalse(self.window.game_ready())
        r=self.window.gload._request;link.lines=[x['raw'] for x in sample(r.request_id,r.args)];self.poll();self.assertTrue(self.window.gload.results[-1]['accepted_pass'])
    def test_gload_text_menu_is_capability_and_owner_gated(self):
        link=self.ready();before=len(link.sent)
        self.window.game_sequence.start_menu()
        self.assertEqual(len(link.sent),before);self.assertFalse(self.window.game_sequence.busy)
        self.window.gload.capable=False;self.window.game_sequence.start_menu()
        self.assertEqual(len(link.sent),before);self.assertFalse(self.window.game_sequence.busy)
    def test_disconnect_during_text_menu_never_runs_on_stale_menu_reply(self):
        link=self.ready();self.window.gload.start();self.assertEqual(link.sent[-1],b':menu\n')
        self.window.disconnect();self.assertFalse(self.window.game_sequence.busy)
        replacement=self.ready();before=len(replacement.sent)
        replacement.lines=['UI MENU'];self.poll()
        self.assertEqual(len(replacement.sent),before);self.assertFalse(any(x.startswith(b':gload run') for x in replacement.sent))
    def test_ordinary_game_menu_keeps_binary_pc_controls(self):
        link=self.ready();actions=len(link.actions);before=len(link.sent)
        self.window.start_preset(4,6)
        self.assertEqual(link.actions[actions:],[('touhou_LAB','menu',True),('touhou_LAB','menu',False)])
        self.assertEqual(len(link.sent),before)
    def test_unowned_direct_slot_never_sends(self):
        link=self.ready();before=len(link.sent);self.window.gload_send(4,'run',list(ARGS));self.window.gload_send(4,'cancel',[]);self.assertEqual(len(link.sent),before)
    def test_new_fw_fixed_pressure_is_an_acknowledged_transaction(self):
        link=self.ready();self.window.run_pressure(64,True);self.assertTrue(self.window.game_sequence.busy)
        link.lines=['UI MENU'];self.poll();self.assertEqual(link.sent[-1],b':limit 64\n');link.lines=['OK limit 64'];self.poll();self.assertEqual(link.sent[-1],b':mode 3\n')
    def test_production_c_protocol_through_mainwindow_parser_and_panel(self):
        from firmware_paths import project_root
        source=project_root()/'results/validation/game_load_native_protocol.log'
        if not source.is_file():self.skipTest('Native C protocol artifact is not included in standalone app checkout')
        lines=source.read_text(encoding='utf-8').splitlines();self.assertIn('not physical FPS',lines[0])
        link=self.ready();p=self.window.gload;p.bosses.setValue(6);p.enemies.setValue(12);p._next_id=122;p.start()
        link.lines=['UI MENU'];self.poll();self.assertEqual(link.sent[-1],b':gload run 123 6 12 5000 8 60 123456789\n')
        link.lines=lines;self.poll();r=p.results[-1];self.assertTrue(r['accepted_pass']);self.assertFalse(r['long_60fps_pass']);self.assertEqual(r['detail']['bhits'],2);self.assertEqual(r['detail']['mhits'],3)
    def test_old_firmware_keeps_new_game_controls_disabled(self):
        link=OwnerStatusLink();self.window.link=link
        for _ in range(4):self.poll()
        link.lines=[STAT];self.poll();self.assertTrue(self.window.game_ready());self.assertFalse(self.window.game_apply.isEnabled());self.assertFalse(self.window.gload.start_button.isEnabled())

if __name__=='__main__':unittest.main()

