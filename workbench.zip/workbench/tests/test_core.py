"""Offline tests: no real serial port, hardware process or USB access."""
from pathlib import Path
import json
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import control_core as c

TOUHOU = "STAT mode=1 hw=1 N=636 fps100=5897 swaps=118 scan=120 us=2000757 frame=16000 logic=1000 render=15000 missed=2 uf=0 vstr=2 h_pk=1200"
MARIO = "PERF,0,MARIO,GAME,0,2,1083234,13,65,68393,52,0,65,0,0,0,20609472,141474528,0"
METAL = "PERF schema=2 backend=1 build=31 seq=6000 epoch=8 state=1 level=0 difficulty=0 samples=120 lab=0 enemies=0 bullets=0 updated=0 updated_bullets=0 mode=0 path=1 alpha=255 visible=0 frame_us=117647 update_us=46 render_us=97127 swap_us=2735 fps_x10=85 p95_us=120000 max_us=140000 late=712 total=712 underflows=0 drops=0 jobs=462 cycles=4865935 combat_alive=37 combat_shots=9"


class FakeSerial:
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.is_open = False
        self.dtr = self.rts = True
        self.port = kwargs.get("port")
        self.data = bytearray()
        self.writes = []
        self.closed = False
    def open(self):
        assert self.dtr is False and self.rts is False
        self.is_open = True
    @property
    def in_waiting(self):
        return len(self.data)
    def read(self, n):
        result = bytes(self.data[:n]); del self.data[:n]; return result
    def write(self, payload):
        self.writes.append(payload); return len(payload)
    def close(self):
        self.is_open = False; self.closed = True


class SettingsTests(unittest.TestCase):
    def test_atomic_roundtrip_and_private_config(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t); (root / "tools").mkdir()
            original = root / "tools/local_paths.json"
            original.write_text('{"capture_seconds": 10, "host_cc":"gcc"}')
            before = original.read_bytes()
            settings = c.Settings(bundle_root=str(root), port="COM20", notifications=False)
            destination = root / "preferences/settings.json"
            settings.save(destination)
            restored = c.Settings.load(destination)
            self.assertEqual(restored.port, "COM20")
            self.assertFalse(restored.notifications)
            result = restored.write_tool_config(root, root / "private/job.json")
            self.assertEqual(json.loads(result.read_text())["uart_port"], "COM20")
            self.assertEqual(original.read_bytes(), before)
    def test_reject_invalid_values_and_preserve_bad_file(self):
        for field, value in [("port", "COM0"), ("port", "COM16; start x"), ("usb_location", "any"), ("baudrate", True), ("notifications", "yes")]:
            obj = c.Settings(); setattr(obj, field, value)
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):obj.validate()
        with tempfile.TemporaryDirectory() as t:
            p = Path(t) / "bad.json"; p.write_text("{oops")
            result = c.Settings.load(p)
            self.assertTrue(result.load_warning)
            self.assertEqual(p.read_text(), "{oops")


class CommandTests(unittest.TestCase):
    def make_bundle(self, root):
        (root / "START_MENU.py").write_text("# full flash fixture")
        (root / "projects/touhou_LAB").mkdir(parents=True)
        (root / "tools").mkdir(); (root / "tools/local_paths.json").write_text("{}")
        (root / "persistent_entry.json").write_text(json.dumps({"firmware":"LAB23","kind":"full_flash","state":"READY","ram_fallback_allowed":False}))
    def test_bundle_command_whitelist_and_no_shell(self):
        with tempfile.TemporaryDirectory() as t:
            r = Path(t); self.make_bundle(r)
            with patch.object(c,"load_persistent_profile"):
                command = c.build_command(r, "touhou_LAB", True, sys.executable)
                self.assertIsInstance(command, list)
                self.assertIn("--check", command)
                self.assertEqual(command[command.index("--game") + 1], "touhou_LAB")
                self.assertNotIn("--check", c.build_command(r, "touhou_LAB", False, sys.executable))
            with self.assertRaises(ValueError):c.build_command(r, "x & calc")
    def test_changed_guard_is_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            r=Path(t); self.make_bundle(r)
            (r / "PACK_MANIFEST.json").write_text(json.dumps({"files":{"START_MENU.py":{"sha256":"0"*64}}}))
            with patch.object(c,"load_persistent_profile"), self.assertRaises(ValueError):c.build_command(r,"touhou_LAB",True,sys.executable)
    def test_known_protocols_and_unsupported_actions(self):
        for profile in ("touhou_R8", "touhou_R7p1"):
            self.assertEqual(c.command_for_action(profile,"start"),b"r\n")
            for action in ("left","right","up","down","jump","pause","bomb"):
                self.assertIsNone(c.command_for_action(profile,action))
        self.assertEqual(c.command_for_action("mario_HD32_R1","jump"),b"w")
        self.assertIsNone(c.command_for_action("mario_HD32_R1","jump",False))
        self.assertIsNone(c.command_for_action("mario_HD32_R1","restart"))
        self.assertEqual(c.command_for_action("metal_FRONTLINE_v31","pause"),b"p")
        self.assertEqual(c.command_for_action("metal_FRONTLINE_v31","left",False),bytes.fromhex("a55a0000a7"))
        self.assertEqual(c.stress_command("touhou_R8",20000),b"mn20000\ns\n")
        self.assertIsNone(c.stress_command("mario_HD32_R1",20000))
        for count in (0,20001,-1,True):
            with self.assertRaises(ValueError):c.stress_command("touhou_R8",count)
    def test_packet_mask_checksum(self):
        self.assertEqual(c.metal_packet(5),bytes.fromhex("a55a0500a2"))
        for invalid in (-1,64,0x1000,True):
            with self.assertRaises(ValueError):c.metal_packet(invalid)


class TelemetryTests(unittest.TestCase):
    def test_fps_scaling_and_semantics(self):
        a=c.parse_telemetry(TOUHOU,"touhou_R8")
        self.assertEqual((a["fps"],a["mode"],a["sprites"]),(58.97,"战斗",636))
        self.assertEqual(a["render_us"],15000)
        self.assertEqual(a["underflow_semantics"],"window_delta")
        b=c.parse_telemetry(MARIO,"mario_HD32_R1")
        self.assertAlmostEqual(b["fps"],13e6/1083234)
        self.assertIsNone(b["sprites"])
        self.assertIsNone(b["render_us"])
        self.assertIn("菜单",b["mode"])
        d=c.parse_telemetry(METAL,"metal_FRONTLINE_v31")
        self.assertEqual((d["fps"],d["mode"]),(8.5,"战斗"))
        self.assertIsNone(d["sprites"])
        self.assertEqual(d["underflow_semantics"],"cumulative")
    def test_no_cross_game_or_partial_messages(self):
        for line, other in [(TOUHOU,"mario_HD32_R1"),(MARIO,"touhou_R8"),(METAL,"touhou_R7p1")]:
            self.assertIsNone(c.parse_telemetry(line,other))
        for line in ["STAT mode=1 fps100=6000",MARIO.rsplit(",",1)[0],METAL.rsplit(" ",1)[0],METAL.replace("build=31","build=30"),METAL.replace("lab=0","lab=2"),TOUHOU.replace("fps100=5897","fps100=5897oops")]:
            self.assertIsNone(c.parse_telemetry(line),line)
        self.assertIsNone(c.parse_telemetry("LOADER DONE"))
    def test_touhou_versions_are_not_interchanged(self):
        p1=TOUHOU.rsplit(" h_pk=",1)[0]
        self.assertEqual(c.parse_telemetry(p1)["game_id"],"touhou_R7p1")
        self.assertIsNone(c.parse_telemetry(p1,"touhou_R8"))
        self.assertIsNone(c.parse_telemetry(TOUHOU,"touhou_R7p1"))


class SerialTests(unittest.TestCase):
    def make_link(self):
        factory=types.SimpleNamespace(Serial=FakeSerial)
        with patch.dict(sys.modules,{"serial":factory}):
            link=c.SerialLink();self.assertFalse(link.is_open);link.open("COM16")
        return link
    def test_open_no_control_line_pulse(self):
        link=self.make_link();device=link._serial
        self.assertIsNone(device.kwargs["port"])
        self.assertFalse(device.dtr);self.assertFalse(device.rts)
        self.assertEqual(link.port,"COM16")
        link.close();self.assertTrue(device.closed)
    def test_lines_are_buffered_and_decoded(self):
        link=self.make_link();device=link._serial
        device.data.extend(b"first\r\npart")
        self.assertEqual(link.read_lines(),["first"])
        device.data.extend(b"ial\n")
        self.assertEqual(link.read_lines(),["partial"])
        link.close()
    def test_metal_held_keys_aggregate_and_disconnect_zeroes(self):
        link=self.make_link();device=link._serial
        link.set_action("metal_FRONTLINE_v31","left",True)
        link.set_action("metal_FRONTLINE_v31","jump",True)
        self.assertEqual(device.writes[-1],c.metal_packet(5))
        link.set_action("metal_FRONTLINE_v31","left",False)
        self.assertEqual(device.writes[-1],c.metal_packet(4))
        link.close();self.assertEqual(device.writes[-1],c.metal_packet(0))
        self.assertFalse(link.is_open)
    def test_mario_release_sends_no_invented_packet(self):
        link=self.make_link();device=link._serial
        link.set_action("mario_HD32_R1","left",True)
        self.assertEqual(device.writes,[b"a"])
        link.set_action("mario_HD32_R1","left",False)
        self.assertEqual(device.writes,[b"a"])
        link.close();self.assertEqual(device.writes,[b"a"])
    def test_write_failure_on_release_still_closes(self):
        link=self.make_link();device=link._serial
        link.set_action("metal_FRONTLINE_v31","left",True)
        def fail(_):raise OSError("gone")
        device.write=fail
        with self.assertRaises(OSError):link.close()
        self.assertTrue(device.closed)
        self.assertFalse(link.is_open)


if __name__=="__main__":
    unittest.main(verbosity=2)
