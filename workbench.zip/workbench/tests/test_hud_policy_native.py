"""Replay actual production-C UART output, with synthetic MMIO/time, never board FPS."""
import hashlib,unittest
from firmware_paths import project_root
from control_core import parse_capabilities
from game_load_protocol import ARG_NAMES,GameLoadRequest,parse_game_load_reply
import test_game_load as old
import test_game_load_hud_policy as policy
from test_ui_v23 import STAT

PIN='a8c481c9a52fbf433f64cf4df02586cf5da4f5cf9800ea9b78429ecb4aa8605a'

def actual_fixture():
 from pathlib import Path
 p=Path(__file__).resolve().parent/'fixtures/hud_policy1_complete.log'
 raw=p.read_bytes()
 if hashlib.sha256(raw).hexdigest()!=PIN:raise AssertionError('Real native fixture identity changed')
 lines=raw.decode('utf-8').splitlines()
 if 'NOT board FPS evidence'not in lines[0]:raise AssertionError('Fixture scope must remain explicit')
 caps=[parse_capabilities(x)for x in lines if x.startswith('CAPS ')]
 packets=[parse_game_load_reply(x)for x in lines if x.startswith('GLOAD_')]
 if len(caps)!=2 or None in caps or None in packets:raise AssertionError('Incomplete real protocol fixture')
 return lines,caps,packets

class ActualNativeHudWireTests(unittest.TestCase):
 def test_actual_c_lifecycle_before_run_during_run_and_restored_caps_match(self):
  lines,caps,packets=actual_fixture();ack=packets[0]
  self.assertEqual(caps[0],caps[1]);self.assertEqual(caps[0]['hud_dma_proof'],1)
  self.assertEqual(caps[0]['hud_dma'],1)
  req=GameLoadRequest(ack['id'],tuple(ack[k]for k in ARG_NAMES),capabilities=caps[0],expected_pipeline=bool(caps[0]['pipe']))
  for item in packets[:-1]:req.feed(item)
  result=req.finish(packets[-1])
  self.assertTrue(result['accepted_pass']);self.assertTrue(result['hud_policy_verified'])
  self.assertEqual((result['ack']['hud_dma'],result['ready']['hud_dma'],result['detail']['hud_dma']),(1,1,1))
  self.assertAlmostEqual(result['actual_fps'],60*1e6/1000001)
  self.assertFalse(result['long_60fps_pass'])

class ActualNativeHudMainWindowTests(unittest.TestCase):
 setUpClass=classmethod(policy.HudPolicyHandshakeTests.setUpClass.__func__)
 setUp=policy.HudPolicyHandshakeTests.setUp
 poll=policy.HudPolicyHandshakeTests.poll
 dispose_window=policy.HudPolicyHandshakeTests.dispose_window
 def test_actual_c_lifecycle_through_mainwindow_and_panel(self):
  lines,caps,packets=actual_fixture();ack=packets[0]
  self.link.policy=1;self.link.lines=[next(x for x in lines if x.startswith('CAPS '))]
  for _ in range(5):self.poll()
  self.link.lines=[STAT];self.poll();p=self.window.gload
  p.bosses.setValue(ack['b']);p.enemies.setValue(ack['m']);p.count.setValue(ack['n']);p.size.setCurrentIndex(p.size.findData(ack['size']))
  p._next_id=ack['id']-1;p.start();self.link.lines=['UI MENU'];self.poll()
  self.assertEqual(self.link.sent[-1],b':gload run 282 6 12 5000 32 60 123456789\n')
  self.link.lines=[x for x in lines if x.startswith(('GLOAD_','MOTION_DIAG'))];self.poll()
  result=p.results[-1];self.assertTrue(result['hud_policy_verified']);self.assertTrue(result['accepted_pass'])
  self.assertIn('实际绘图设置已核对：1',p.status.text());self.assertAlmostEqual(result['actual_fps'],60*1e6/1000001)

if __name__=='__main__':unittest.main()
