"""Independent firmware-protocol and isolation checks; no device is accessed.

Vectors were read from the packaged production game.c/main.c/remote.c,
not copied from the upper-computer implementation.
Run: python -m unittest discover -s tests -p test_integration.py -v
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import control_core as core


class FakeSerial:
    def __init__(self, **kwargs):
        self.port = kwargs.get('port')
        self.is_open = bool(self.port)
        self.dtr = True
        self.rts = True
        self.kwargs = kwargs
        self.open_lines = None
        self.incoming = bytearray()
        self.writes = []
        self.closed = False

    def open(self):
        self.open_lines = (self.dtr, self.rts)
        self.is_open = True

    @property
    def in_waiting(self):
        return len(self.incoming)

    def read(self, count):
        value = bytes(self.incoming[:count])
        del self.incoming[:count]
        return value

    def write(self, value):
        self.writes.append(bytes(value))
        return len(value)

    def close(self):
        self.closed = True
        self.is_open = False


class ProtocolIntegration(unittest.TestCase):
    def test_import_has_no_process_or_device_side_effects(self):
        name = 'control_core_isolated_protocol_test'
        spec = importlib.util.spec_from_file_location(name, ROOT / 'control_core.py')
        module = importlib.util.module_from_spec(spec)
        serial_stub = types.SimpleNamespace(Serial=lambda *a, **k: self.fail('Serial opened at import'))
        with patch('subprocess.Popen', side_effect=AssertionError('Process started at import')), patch.dict(sys.modules, {'serial': serial_stub, name: module}):
            spec.loader.exec_module(module)
        self.assertEqual(set(module.PROFILES), {'touhou_LAB','touhou_R8', 'touhou_R7p1', 'mario_HD32_R1', 'metal_FRONTLINE_v31'})

    def test_touhou_does_not_invent_gpio_or_pause_uart(self):
        for game in ('touhou_R8', 'touhou_R7p1'):
            for action in ('left', 'right', 'up', 'down', 'jump', 'pause', 'bomb'):
                self.assertIsNone(core.command_for_action(game, action), (game, action))
            self.assertEqual(core.command_for_action(game, 'start'), b'r\n')
            self.assertEqual(core.command_for_action(game, 'restart'), b'r\n')
            self.assertEqual(core.command_for_action(game, 'menu'), b'm')
            self.assertIsNone(core.command_for_action(game, 'start', False))
            self.assertEqual(core.stress_command(game, 20000), b'mn20000\ns\n')
            self.assertEqual(core.stress_command(game, 64, False), b'mn64\nc\n')

    def test_mario_only_has_virtual_gpio_pulses(self):
        expected = {'left': b'a', 'right': b'd', 'jump': b'w', 'start': b's', 'pause': b's'}
        for action, value in expected.items():
            self.assertEqual(core.command_for_action('mario_HD32_R1', action), value)
            self.assertIsNone(core.command_for_action('mario_HD32_R1', action, False))
        self.assertIsNone(core.command_for_action('mario_HD32_R1', 'restart'))
        self.assertIsNone(core.command_for_action('mario_HD32_R1', 'menu'))
        self.assertIsNone(core.command_for_action('mario_HD32_R1', 'bomb'))

    def test_metal_packet_matches_production_remote_contract(self):
        for mask in (0, 1, 2, 4, 8, 16, 32, 5, 17, 1024, 2048, 0x0C3F):
            low, high = mask & 255, mask >> 8
            expected = bytes([0xA5, 0x5A, low, high, low ^ high ^ 0xA7])
            self.assertEqual(core.metal_packet(mask), expected)
        for invalid in (-1, 0x40, 0x1000, 65536, True, '4'):
            with self.assertRaises(ValueError):
                core.metal_packet(invalid)
        self.assertEqual(core.command_for_action('metal_FRONTLINE_v31', 'start'), b'p')
        self.assertIsNone(core.command_for_action('metal_FRONTLINE_v31', 'restart'))
        self.assertIsNone(core.command_for_action('metal_FRONTLINE_v31', 'menu'))

    def test_touhou_telemetry_unit_mode_and_window_counters(self):
        line = 'STAT mode=1 hw=1 N=636 fps100=5992 swaps=120 scan=122 us=2000000 frame=8900 missed=2 uf=0 render=8500 logic=400 vstr=2 h_pk=1200'
        d = core.parse_telemetry(line, 'touhou_R8')
        self.assertAlmostEqual(d['fps'], 59.92)
        self.assertEqual(d['mode'], '战斗')
        self.assertEqual((d['sprites'], d['render_us'], d['logic_us']), (636, 8500, 400))
        self.assertEqual((d['underflow_semantics'], d['missed_semantics']), ('window_delta', 'window_delta'))
        self.assertIsNone(core.parse_telemetry(line, 'mario_HD32_R1'))
        self.assertIsNone(core.parse_telemetry(line, 'metal_FRONTLINE_v31'))

    def test_mario_counts_new_swaps_not_display_scan(self):
        line = 'PERF,12,MARIO,GAME,0,2,1000000,12,60,88999,48,0,60,0,0,0,1000,2000,0'
        d = core.parse_telemetry(line, 'mario_HD32_R1')
        self.assertEqual(d['fps'], 12.0)
        self.assertIn('菜单', d['mode'])
        self.assertIsNone(d['sprites'])  # count=0 in GAME means unavailable, not zero actors.
        self.assertIsNone(d['render_us'])
        self.assertEqual(d['peak_us'], 88999)
        self.assertEqual(d['missed'], 48)
        self.assertIsNone(core.parse_telemetry(line, 'touhou_R8'))
        self.assertIsNone(core.parse_telemetry(line, 'metal_FRONTLINE_v31'))
        bad = line.split(','); bad[6] = '0'
        self.assertIsNone(core.parse_telemetry(','.join(bad)))
        self.assertIsNone(core.parse_telemetry(line.rsplit(',', 1)[0]))

    def test_metal_combat_counts_are_not_stress_counts(self):
        line = 'PERF schema=2 backend=1 build=31 seq=240 epoch=3 state=1 lab=0 samples=120 enemies=0 bullets=0 frame_us=110000 update_us=1000 render_us=105000 swap_us=4000 fps_x10=91 underflows=0 late=120 total=240 combat_alive=12 combat_shots=7'
        d = core.parse_telemetry(line, 'metal_FRONTLINE_v31')
        self.assertEqual(d['fps'], 9.1)
        self.assertEqual(d['mode'], '战斗')
        self.assertIsNone(d['sprites'])
        self.assertEqual(d['values']['combat_alive'], 12)
        self.assertEqual(d['render_us'], 105000)
        self.assertEqual(d['underflow_semantics'], 'cumulative')
        lab = line.replace('lab=0', 'lab=1').replace('enemies=0', 'enemies=20000').replace('bullets=0', 'bullets=4096')
        self.assertEqual(core.parse_telemetry(lab)['sprites'], 24096)
        self.assertIsNone(core.parse_telemetry(line, 'mario_HD32_R1'))
        self.assertIsNone(core.parse_telemetry(line, 'touhou_R8'))
        self.assertIsNone(core.parse_telemetry(line.replace('schema=2', 'schema=3')))
        self.assertIsNone(core.parse_telemetry(line.replace('build=31', 'build=99')))

    def test_unknown_and_headers_never_fabricate_live_metrics(self):
        for line in ('', 'READY', 'PERF_HEADER,run,game,mode', 'STAT broken', 'PERF schema=2 state=1', 'STAT mode=1 fps100=-1'):
            self.assertIsNone(core.parse_telemetry(line), line)

    def make_link(self):
        handles = []
        def factory(**kwargs):
            h = FakeSerial(**kwargs); handles.append(h); return h
        patcher = patch.dict(sys.modules, {'serial': types.SimpleNamespace(Serial=factory)})
        patcher.start(); self.addCleanup(patcher.stop)
        link = core.SerialLink(); link.open('COM99'); self.addCleanup(link.close)
        return link, handles[0]

    def test_serial_open_keeps_control_lines_low_before_open(self):
        link, handle = self.make_link()
        self.assertEqual(handle.open_lines, (False, False))
        self.assertEqual(handle.port, 'COM99')
        self.assertTrue(link.is_open)

    def test_metal_held_chords_release_and_close(self):
        link, handle = self.make_link()
        link.set_action('metal_FRONTLINE_v31', 'left', True)
        link.set_action('metal_FRONTLINE_v31', 'jump', True)
        self.assertEqual(handle.writes[-1], core.metal_packet(5))
        link.set_action('metal_FRONTLINE_v31', 'left', False)
        self.assertEqual(handle.writes[-1], core.metal_packet(4))
        link.close()
        self.assertEqual(handle.writes[-1], core.metal_packet(0))
        self.assertTrue(handle.closed)
        self.assertFalse(link.is_open)

    def test_mario_release_sends_no_invented_packet(self):
        link, handle = self.make_link()
        link.set_action('mario_HD32_R1', 'left', True)
        self.assertEqual(handle.writes[-1], b'a')
        count = len(handle.writes)
        link.set_action('mario_HD32_R1', 'left', False)
        link.heartbeat(); link.release_all()
        self.assertEqual(len(handle.writes), count)
        link.close()
        self.assertEqual(len(handle.writes), count)

    def test_family_change_releases_previous_metal_mask(self):
        link, handle = self.make_link()
        link.set_action('metal_FRONTLINE_v31', 'left', True)
        link.set_action('touhou_R8', 'menu', True)
        self.assertEqual(handle.writes[-2:], [core.metal_packet(0), b'm'])

    def test_serial_line_buffer_never_returns_half_record(self):
        link, handle = self.make_link()
        handle.incoming.extend(b'STAT mode=1 fps100=')
        self.assertEqual(link.read_lines(), [])
        handle.incoming.extend(b'5992\r\nsecond\n')
        self.assertEqual(link.read_lines(), ['STAT mode=1 fps100=5992', 'second'])
        handle.incoming.extend(b'x' * 65537)
        self.assertEqual(link.read_lines(), [])
        self.assertTrue(any('丢弃' in x for x in link.read_lines()))

    def test_guarded_command_is_argument_list_and_detects_modified_entry(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root / 'projects/touhou_LAB').mkdir(parents=True)
            (root / 'tools/games').mkdir(parents=True)
            (root / 'tools/local_paths.json').write_text('{}')
            (root / 'persistent_entry.json').write_text(json.dumps({'firmware':'LAB23','kind':'full_flash','state':'READY','ram_fallback_allowed':False}))
            entry = root / 'START_MENU.py'; entry.write_text('# guarded fixture\n')
            helper = root / 'tools/games/test_game_local.py'; helper.write_text('# guarded helper fixture\n')
            info = {'files': {p.relative_to(root).as_posix(): {'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in (entry, helper)}}
            (root / 'PACK_MANIFEST.json').write_text(json.dumps(info))
            with patch.object(core,'load_persistent_profile'):
                command = core.build_command(root, 'touhou_LAB', True, sys.executable)
            self.assertIsInstance(command, list)
            self.assertIn('--check', command)
            self.assertEqual(command[command.index('--game')+1], 'touhou_LAB')
            with patch.object(core,'load_persistent_profile'):
                self.assertNotIn('--check', core.build_command(root, 'touhou_LAB', False, sys.executable))
            self.assertNotIn('--flash', command)
            entry.write_text('# changed\n')
            with patch.object(core,'load_persistent_profile'), self.assertRaises(ValueError):core.build_command(root, 'touhou_LAB', True, sys.executable)
            with self.assertRaises(ValueError):core.build_command(root, 'mario_HD32_R1', True, sys.executable)
            with self.assertRaises(ValueError):core.build_command(root, 'mario_HD32_R1; unsafe', True, sys.executable)

    def test_private_job_config_never_overwrites_archived_defaults(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root / 'bundle/tools').mkdir(parents=True)
            original = root / 'bundle/tools/local_paths.json'
            original.write_text(json.dumps({'uart_port':'COM16','custom':'preserved'}))
            before = original.read_bytes()
            settings = core.Settings(port='COM99')
            job = settings.write_tool_config(root / 'bundle', root / 'private/job.json')
            self.assertEqual(original.read_bytes(), before)
            values = json.loads(job.read_text())
            self.assertEqual(values['uart_port'], 'COM99')
            self.assertEqual(values['custom'], 'preserved')


if __name__ == '__main__':
    unittest.main()
