"""Image wire bounds, stale/corrupt replies and ACK/complete distinction."""
from pathlib import Path
import base64
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from control_core import lab_command, parse_lab_reply, LabRequestTracker, parse_capabilities


def done(op="imgcopy", **changes):
    d = dict(id=7, op=op, status="PASS", errors=0, us=250, hw_cycles=100,
             width=1280, height=720, refresh=60, active=1, session=9,
             received=18, total=18, imgw=3, imgh=2, crc=42,
             verified=921600 if op == "imgcopy" else 0, ready=1)
    d.update(changes)
    return "LAB_DONE " + " ".join(f"{k}={v}" for k, v in d.items())


class ImageProtocolTests(unittest.TestCase):
    def test_full_chunk_fits_real_firmware_line(self):
        b64 = base64.b64encode(bytes(range(256)) + bytes(range(32))).decode()
        self.assertEqual(len(b64), 384)
        wire = lab_command(2147483647, "imgdata", 2147483647, 2764512, b64)
        self.assertLess(len(wire), 576)
        self.assertTrue(wire.endswith(b"\n"))

    def test_valid_commands_and_legacy_copy(self):
        self.assertEqual(lab_command(1, "imgbegin", 9, 1280, 720, 0xffffffff), b":lab 1 imgbegin 9 1280 720 4294967295\n")
        self.assertEqual(lab_command(2, "imgdata", 9, 0, "AQID"), b":lab 2 imgdata 9 0 AQID\n")
        self.assertEqual(lab_command(3, "imgcopy", 9, 0, 0), b":lab 3 imgcopy 9 0 0\n")
        self.assertEqual(lab_command(4, "imgabort", 9), b":lab 4 imgabort 9\n")
        self.assertEqual(lab_command(5, "imgstatus"), b":lab 5 imgstatus\n")
        self.assertEqual(lab_command(6, "copy", 1, 0, 0, 64, 64, 0, 0), b":lab 6 copy 1 0 0 64 64 0 0\n")

    def test_rejects_bad_bounds_and_injected_encoding(self):
        cases = [("imgbegin", 0, 1, 1, 0), ("imgbegin", 1, 1281, 720, 0),
                 ("imgbegin", 1, 1280, 721, 0), ("imgbegin", 1, True, 2, 0),
                 ("imgbegin", 1, 1, 1, -1), ("imgcopy", 1, 1280, 0),
                 ("imgcopy", 1, 0, 720), ("imgstatus", 1), ("imgcommit", 1, 2),
                 ("imgdata", 1, 1, "AQID"), ("imgdata", 1, 0, "AQ=="),
                 ("imgdata", 1, 0, "AQID\n:menu"), ("imgdata", 1, 0, "!!!!"),
                 ("imgdata", 1, 0, "AQID="), ("imgdata", 1, 2764799, "AQID"),
                 ("imgdata", 1, 0, base64.b64encode(bytes(291)).decode())]
        for args in cases:
            with self.subTest(args=args[:3]), self.assertRaises(ValueError):
                lab_command(1, *args)

    def test_copy_requires_actual_full_pixel_check(self):
        self.assertEqual(parse_lab_reply(done())["verified"], 921600)
        for changes in ({"verified": 1}, {"verified": 0}, {"ready": 0},
                        {"received": 15}, {"total": 19}, {"crc": 4294967296},
                        {"imgw": 1281}, {"session": 2147483648}, {"active": 2},
                        {"errors": 1}, {"verified": "0921600"}):
            with self.subTest(changes=changes):
                self.assertIsNone(parse_lab_reply(done(**changes)))

    def test_commit_and_errors_cannot_claim_display_check(self):
        self.assertIsNotNone(parse_lab_reply(done("imgcommit")))
        self.assertIsNone(parse_lab_reply(done("imgcommit", ready=0)))
        self.assertIsNone(parse_lab_reply(done("imgcommit", verified=921600)))
        self.assertIsNone(parse_lab_reply(done(status="ERROR", code="CRC")))
        self.assertIsNotNone(parse_lab_reply(done("imgcommit", status="ERROR", code="CRC", ready=0)))
        abort = done("imgabort", received=0, total=0, imgw=0, imgh=0, crc=0, ready=0)
        self.assertIsNotNone(parse_lab_reply(abort))

    def test_ack_stale_id_and_timeout_never_complete(self):
        t = LabRequestTracker()
        t.begin(7, "imgcopy", now=0)
        self.assertTrue(t.receive(parse_lab_reply("LAB_ACK id=7 op=imgcopy status=QUEUED"), now=1))
        self.assertEqual(t.pending_id, 7)
        self.assertFalse(t.receive(parse_lab_reply(done(id=6)), now=2))
        self.assertEqual(t.expire(now=180)["status"], "TIMEOUT")
        self.assertFalse(t.receive(parse_lab_reply(done()), now=181))

    def test_capability_is_explicit_and_legacy_retained(self):
        caps = "CAPS fw=LAB23 proto=2 controls=PC lab=1 labx=1 adv=1 width=1280 height=720 hz=60"
        self.assertEqual(parse_capabilities(caps)["img"], 0)
        self.assertEqual(parse_capabilities(caps + " img=1")["img"], 1)
        self.assertIsNone(parse_capabilities(caps + " img=2"))


if __name__ == "__main__":
    unittest.main()
