"""LAB1 protocol tests. Every serial device here is an in-memory fake."""
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import control_core as c
from test_core import FakeSerial, TOUHOU

CAPS = "CAPS fw=LAB1 proto=2 controls=PC lab=1 width=1280 height=720 hz=60"
STAT = TOUHOU + " fw=LAB1 paused=1 control=PC"
DONE = "LAB_DONE id=17 op=fill status=PASS errors=0 us=123 hw_cycles=456 width=1280 height=720 refresh=60 active=1"


class ProtocolTests(unittest.TestCase):
    def test_strict_capability_identity(self):
        cap = c.parse_capabilities(CAPS)
        self.assertEqual((cap["fw"], cap["proto"], cap["width"]), ("LAB1", 2, 1280))
        for bad in (CAPS.replace("LAB1", "R8"), CAPS.replace("proto=2", "proto=1"),
                    CAPS.replace("PC", "GPIO"), CAPS.replace("lab=1", "lab=0"),
                    CAPS.replace("width=1280", "width=640"), CAPS.rsplit(" ", 1)[0],
                    CAPS + " fw=LAB1", "log " + CAPS):
            self.assertIsNone(c.parse_capabilities(bad), bad)

    def test_new_firmware_is_not_old_firmware(self):
        data = c.parse_telemetry(STAT, "touhou_LAB")
        self.assertEqual((data["game_id"], data["paused"], data["control"]), ("touhou_LAB", 1, "PC"))
        self.assertIsNone(c.parse_telemetry(TOUHOU, "touhou_LAB"))
        self.assertIsNone(c.parse_telemetry(STAT, "touhou_R8"))
        for bad in (STAT.replace("fw=LAB1", "fw=R8"), STAT.replace("control=PC", "control=GPIO"),
                    STAT.replace("paused=1", "paused=2"), STAT.replace("paused=1 ", ""),
                    STAT + " fw=LAB1"):
            self.assertIsNone(c.parse_telemetry(bad), bad)

    def test_state_packet_sequence_checksum_and_bounds(self):
        self.assertEqual(c.touhou_packet(2, 21), bytes.fromhex("a55a021500b0"))
        self.assertEqual(c.touhou_packet(255, 0)[-1], 255 ^ 0xA7)
        for seq, mask in ((-1, 0), (256, 0), (True, 0), (0, 256), (0, -1), (0, True)):
            with self.assertRaises(ValueError):
                c.touhou_packet(seq, mask)

    def test_explicit_ascii_helpers_have_no_legacy_characters(self):
        self.assertEqual(c.hello_command(), b":hello\n")
        self.assertEqual(c.mode_command(2), b":mode 2\n")
        self.assertEqual(c.pause_command(True), b":pause 1\n")
        self.assertEqual(c.stress_command("touhou_LAB", 3000), b":limit 3000\n:mode 3\n")
        self.assertEqual(c.stress_command("touhou_LAB", 3000, False), b":limit 3000\n:mode 4\n")
        self.assertEqual(c.toggle_command("autoplay", False), b":autoplay 0\n")
        self.assertEqual(c.config_command("layer_order", 2), b":set layer_order 2\n")
        self.assertEqual(c.replay_command("record", 42), b":record 42\n")
        self.assertEqual(c.replay_command("dump"), b":replay dump\n")
        self.assertEqual(c.replay_command("status"), b":replay status\n")
        self.assertIsNone(c.command_for_action("touhou_LAB", "start"))
        for action in (lambda: c.mode_command(True), lambda: c.limit_command(20001),
                       lambda: c.pause_command(2), lambda: c.toggle_command("r\nm", 1),
                       lambda: c.config_command("x\n:mode", 3), lambda: c.config_command("x", True),
                       lambda: c.replay_command("record\n:mode"), lambda: c.replay_command("stop", 2)):
            with self.assertRaises(ValueError):
                action()

    def test_lab_encoder(self):
        self.assertEqual(c.lab_command(1, "enter"), b":lab 1 enter\n")
        self.assertEqual(c.lab_command(17, "fill", 10, 20, 30, 40, "0xF4F6FA"),
                         b":lab 17 fill 10 20 30 40 16054010\n")
        self.assertEqual(c.lab_command(2, "copy", 1, 0, 0, 64, 64, 100, 200),
                         b":lab 2 copy 1 0 0 64 64 100 200\n")
        for args in ((0, "enter"), (1, "enter", 3), (1, "bad"), (1, "pattern", 3),
                     (1, "fill", 1270, 0, 20, 10, 1), (1, "fill", 0, 0, 1, 1, -1),
                     (1, "copy", 0, 60, 0, 20, 10, 0, 0)):
            with self.assertRaises(ValueError):
                c.lab_command(*args)

    def test_reply_parser_does_not_turn_ack_into_pass(self):
        ack = c.parse_lab_reply("LAB_ACK id=17 op=fill status=QUEUED")
        self.assertEqual((ack["kind"], ack["status"]), ("LAB_ACK", "QUEUED"))
        done = c.parse_lab_reply(DONE)
        self.assertEqual((done["id"], done["errors"], done["us"]), (17, 0, 123))
        error = c.parse_lab_reply("LAB_DONE id=17 op=fill status=ERROR code=RANGE errors=0 us=0")
        self.assertEqual(error["code"], "RANGE")
        case = c.parse_lab_reply("LAB_CASE id=17 case=copy status=PASS errors=0")
        self.assertEqual(case["case"], "copy")
        failed = c.parse_lab_reply("LAB_CASE id=17 case=copy status=FAIL code=VERIFY errors=3")
        self.assertEqual((failed["status"], failed["errors"]), ("FAIL", 3))
        for bad in (DONE.replace("errors=0", "errors=1"), DONE.replace("refresh=60", "refresh=59"),
                    DONE.replace("id=17", "id=0"), DONE.replace("op=fill", "op=unknown"),
                    DONE.replace("us=123", "us=oops"), DONE + " id=17",
                    "LAB_ACK id=17 op=fill status=PASS", "LAB_DONE id=17 op=fill status=PASS"):
            self.assertIsNone(c.parse_lab_reply(bad), bad)


class RequestTests(unittest.TestCase):
    def test_ack_pending_then_only_matching_done_completes(self):
        tracker = c.LabRequestTracker()
        tracker.begin(17, "fill", now=100)
        self.assertTrue(tracker.receive(c.parse_lab_reply("LAB_ACK id=17 op=fill status=QUEUED"), now=101))
        self.assertEqual(tracker.pending_id, 17)
        self.assertTrue(tracker.acknowledged)
        for bad in (DONE.replace("id=17", "id=16"), DONE.replace("op=fill", "op=clear")):
            self.assertFalse(tracker.receive(c.parse_lab_reply(bad), now=102))
        self.assertEqual(tracker.pending_id, 17)
        self.assertTrue(tracker.receive(c.parse_lab_reply(DONE), now=102))
        self.assertIsNone(tracker.pending_id)
        self.assertEqual(tracker.last_result["status"], "PASS")
        self.assertFalse(tracker.receive(c.parse_lab_reply(DONE), now=103))

    def test_timeout_stale_rejection_and_verify_deadline(self):
        tracker = c.LabRequestTracker()
        tracker.begin(17, "fill", now=100)
        with self.assertRaises(RuntimeError):
            tracker.begin(18, "clear", now=101)
        self.assertIsNone(tracker.expire(now=129.9))
        expired = tracker.expire(now=130)
        self.assertEqual((expired["id"], expired["status"]), (17, "TIMEOUT"))
        tracker.begin(18, "verify", now=131)
        self.assertFalse(tracker.receive(c.parse_lab_reply(DONE), now=140))
        self.assertIsNone(tracker.expire(now=310.9))
        self.assertEqual(tracker.expire(now=311)["status"], "TIMEOUT")
        self.assertFalse(tracker.receive(c.parse_lab_reply(DONE.replace("id=17", "id=18").replace("op=fill", "op=verify")), now=312))

    def test_expired_reply_cannot_be_accepted_without_explicit_timer_tick(self):
        tracker = c.LabRequestTracker(); tracker.begin(17, "fill", now=0)
        self.assertFalse(tracker.receive(c.parse_lab_reply(DONE), now=31))
        self.assertEqual(tracker.last_result["status"], "TIMEOUT")

    def test_case_only_during_matching_verify_and_cancel(self):
        tracker = c.LabRequestTracker(); tracker.begin(17, "verify", now=0)
        reply = c.parse_lab_reply("LAB_CASE id=17 case=copy status=PASS errors=0")
        self.assertTrue(tracker.receive(reply, now=1)); self.assertEqual(len(tracker.cases), 1)
        tracker.cancel(); self.assertFalse(tracker.receive(reply, now=2))
        with self.assertRaises(ValueError):
            tracker.begin(17, "fill", now=3)
        tracker.begin(18, "fill", now=3)
        self.assertFalse(tracker.receive(dict(reply, id=18), now=4))


class SerialProtocolTests(unittest.TestCase):
    def make_link(self, capabilities=True):
        with patch.dict(sys.modules, {"serial": types.SimpleNamespace(Serial=FakeSerial)}):
            link = c.SerialLink(); link.open("COM16")
        if capabilities:
            self.assertTrue(link.accept_capabilities(c.parse_capabilities(CAPS)))
        return link

    def test_new_controls_require_current_handshake(self):
        link = self.make_link(False); device = link._serial
        with self.assertRaises(RuntimeError):
            link.set_action("touhou_LAB", "left", True)
        self.assertEqual(device.writes, [])
        self.assertFalse(link.accept_capabilities({"fw": "R8"}))
        self.assertTrue(link.accept_capabilities(c.parse_capabilities(CAPS)))
        link.close(); self.assertIsNone(link.capabilities)
        with patch.dict(sys.modules, {"serial": types.SimpleNamespace(Serial=FakeSerial)}):
            link.open("COM16")
        self.assertIsNone(link.capabilities)
        with self.assertRaises(RuntimeError):
            link.set_action("touhou_LAB", "start", True)
        link.close()

    def test_simultaneous_direction_bomb_and_edge_releases(self):
        link = self.make_link(); device = link._serial
        for action in ("left", "up", "bomb"):
            link.set_action("touhou_LAB", action, True)
        self.assertEqual(device.writes[-1], c.touhou_packet(2, 21))
        before = len(device.writes)
        link.set_action("touhou_LAB", "bomb", True)
        self.assertEqual(len(device.writes), before)  # keyboard auto-repeat
        link.set_action("touhou_LAB", "bomb", False)
        self.assertEqual(device.writes[-1], c.touhou_packet(3, 5))
        link.set_action("touhou_LAB", "pause", True)
        self.assertEqual(device.writes[-1], c.touhou_packet(4, 37))
        link.set_action("touhou_LAB", "pause", False)
        self.assertEqual(device.writes[-1], c.touhou_packet(5, 5))
        link.release_all()
        self.assertEqual(device.writes[-1], c.touhou_packet(6, 0))
        self.assertFalse(link._held)
        link.close()

    def test_sequence_wrap_and_heartbeat_75ms(self):
        link = self.make_link(); device = link._serial; link._sequence = 255
        with patch.object(c.time, "monotonic", return_value=10):
            link.set_action("touhou_LAB", "right", True)
        self.assertEqual(device.writes[-1], c.touhou_packet(255, 2))
        with patch.object(c.time, "monotonic", return_value=10.07):
            link.heartbeat()
        self.assertEqual(len(device.writes), 1)
        with patch.object(c.time, "monotonic", return_value=10.08):
            link.heartbeat()
        self.assertEqual(device.writes[-1], c.touhou_packet(0, 2))
        link.close(); self.assertEqual(device.writes[-1], c.touhou_packet(1, 0))

    def test_all_action_buttons_have_release_state(self):
        for name, mask in (("pause", 32), ("start", 64), ("restart", 64), ("menu", 128), ("bomb", 16)):
            link = self.make_link(); device = link._serial
            link.set_action("touhou_LAB", name, True)
            link.set_action("touhou_LAB", name, False)
            self.assertEqual(device.writes, [c.touhou_packet(0, mask), c.touhou_packet(1, 0)])
            link.close()

    def test_fragmented_capabilities_and_replies_and_large_input(self):
        link = self.make_link(False); device = link._serial
        device.data.extend(CAPS[:19].encode()); self.assertEqual(link.read_lines(), [])
        device.data.extend((CAPS[19:] + "\r\n" + DONE[:29]).encode())
        self.assertEqual(link.read_lines(), [CAPS])
        device.data.extend((DONE[29:] + "\n").encode())
        self.assertEqual(link.read_lines(), [DONE])
        device.data.extend(b"x" * 70000)
        self.assertEqual(link.read_lines(), [])
        self.assertIn("超长", link.read_lines()[0])
        link.close()

    def test_write_failure_still_closes_and_clears_capability(self):
        link = self.make_link(); device = link._serial
        link.set_action("touhou_LAB", "left", True)
        def fail(_):
            raise OSError("gone")
        device.write = fail
        with self.assertRaises(OSError):
            link.close()
        self.assertTrue(device.closed); self.assertIsNone(link.capabilities)
        self.assertFalse(link._held)


if __name__ == "__main__":
    unittest.main(verbosity=2)
