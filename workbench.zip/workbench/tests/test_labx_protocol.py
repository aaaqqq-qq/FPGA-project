"""Strict LAB23 evidence tests. No serial, process, USB, or board access."""
from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from labx_protocol import labx_command,parse_labx_reply,ExperimentRequest


def parsed(prefix,**values):
    line=prefix+" "+" ".join("%s=%s"%(k,v) for k,v in values.items())
    result=parse_labx_reply(line)
    assert result is not None,line
    return result


def done(request_id,operation,**extra):
    values=dict(id=request_id,op=operation,status="PASS",code="OK",completed=0,active=1,elapsed_us=1000000,uf=0)
    values.update(extra);return parsed("LABX_DONE",**values)


def measured(request_id=1,operation="compare",repeats=1,frames=3):
    kind="blocks" if operation=="compare" else "copy"; frames=frames if operation=="compare" else 1
    args=(kind,"small",frames,2,repeats) if operation=="compare" else (kind,"small","aligned",repeats)
    request=ExperimentRequest(request_id,operation,args,0,180)
    messages=[parsed("LABX_ACK",id=request_id,op=operation,status="QUEUED"),
      parsed("LABX_PLAN",id=request_id,op=operation,kind=kind,size="small",layout="aligned",frames=frames,warmup=2 if operation=="compare" else 0,repeats=repeats,expected=2*repeats,w=128,h=96,task=12345),
      parsed("LABX_SCOPE",id=request_id,first=0,middle=frames//2,last=frames-1,check="full_frame",units="bytes",hz=100000000,fps="display_wall",sample_mode="last_actual",actual_last=1)]
    pairs=[("CPU",kind),("FPGA",kind)] if operation=="compare" else [("FPGA","split"),("FPGA","merged")]
    for group in range(1,repeats+1):
        for backend,method in pairs:
            key=dict(id=request_id,group=group,backend=backend,method=method)
            count_jobs=(24 if method=="split" else 1) if operation=="mem" else 13
            count_pixels=128*96 if operation=="mem" else 128*96+12*10*10
            messages.extend([parsed("LABX_RESULT",**key,task=12345,frames=frames,jobs=frames*count_jobs,pixels=frames*count_pixels,render_us=100000 if backend=="CPU" or method=="split" else 10000,wait_us=1000),
              parsed("LABX_METRIC",**key,elapsed_us=150000,swaps=frames,cycles=100000 if backend=="FPGA" else 0,read=4096 if backend=="FPGA" else 0,write=frames*count_pixels*4 if backend=="FPGA" else 0,uf=0,check_us=300000),
              parsed("LABX_CHECK",**key,samples=len({0,frames//2,frames-1}),errors=0,guards=0,source=0,actual=1,replayed=len({0,frames//2,frames-1})-1,checked=len({0,frames//2,frames-1})*1280*720,first=0,middle=frames//2,last=frames-1)])
    return request,messages,done(request_id,operation,completed=2*repeats)


class ProtocolTests(unittest.TestCase):
    def test_commands_validated(self):
        self.assertEqual(labx_command(7,"compare","blocks","small",120,2,3),b":labx 7 compare blocks small 120 2 3\n")
        self.assertEqual(labx_command(8,"mem","copy","large","boundary",3),b":labx 8 mem copy large boundary 3\n")
        for args in ((0,"enter"),(1,"mem","copy","small","raw",1),(1,"compare","blocks","small",121,0,1),(1,"double","bad"),(1,"status",1)):
            with self.subTest(args=args),self.assertRaises(ValueError):labx_command(*args)

    def test_reject_duplicate_malformed_missing_or_bad_capability_fields(self):
        for line in ("LABX_ACK id=1 op=mem status=QUEUED id=2","LABX_ACK id=1 op=mem status=ACCEPTED","LABX_ACK id=-1 op=mem status=QUEUED","LABX_DONE id=1 op=mem status=PASS","LABX_ACK id=1 op=mem status=QUEUED extra","LABX_ACK id=18446744073709551616 op=mem status=QUEUED"):
            self.assertIsNone(parse_labx_reply(line),line)

    def test_exact_cpu_fpga_pair(self):
        r,lines,last=measured(repeats=3)
        for line in lines:self.assertTrue(r.feed(line))
        result=r.finish(last);self.assertTrue(result["accepted_pass"],result["reasons"]);self.assertEqual(len(result["rows"]),6)
        self.assertEqual(result["rows"][0]["actual_fps"],20)

    def test_mem_split_and_merged_pair(self):
        r,lines,last=measured(operation="mem")
        for line in lines:r.feed(line)
        self.assertTrue(r.finish(last)["accepted_pass"])

    def test_every_missing_result_fragment_rejects_pass(self):
        for missing in ("LABX_RESULT","LABX_METRIC","LABX_CHECK","LABX_PLAN","LABX_SCOPE","LABX_ACK"):
            r,lines,last=measured()
            for line in lines:
                if line["kind_line"]!=missing:r.feed(line)
            with self.subTest(missing=missing):self.assertFalse(r.finish(last)["accepted_pass"])

    def test_task_count_scope_and_errors_cannot_fake_pass(self):
        for kind,key,value in (("LABX_RESULT","task",678),("LABX_RESULT","frames",2),("LABX_RESULT","pixels",1),("LABX_PLAN","frames",4),("LABX_CHECK","samples",1),("LABX_CHECK","checked",1),("LABX_CHECK","source",1),("LABX_METRIC","uf",1),("LABX_SCOPE","fps","validation_wall")):
            r,lines,last=measured();changed=False
            for line in lines:
                if line["kind_line"]==kind and not changed:line=dict(line,**{key:value});changed=True
                r.feed(line)
            with self.subTest(kind=kind,key=key):self.assertFalse(r.finish(last)["accepted_pass"])

    def test_duplicate_fragment_rejected(self):
        r,lines,last=measured()
        for line in lines:r.feed(line)
        r.feed(lines[3]);self.assertFalse(r.finish(last)["accepted_pass"])

    def test_stale_id_wrong_op_ignored(self):
        r,lines,last=measured()
        self.assertFalse(r.feed(dict(lines[0],id=99)));self.assertFalse(r.feed(dict(lines[0],op="mem")));self.assertFalse(r.acknowledged)

    def test_error_cancelled_never_pass(self):
        for state in ("ERROR","CANCELLED"):
            r,lines,last=measured()
            for line in lines:r.feed(line)
            self.assertFalse(r.finish(dict(last,status=state,code="STOP"))["accepted_pass"])

    def test_status_requires_real_state(self):
        r=ExperimentRequest(1,"status",(),0,30);r.feed(parsed("LABX_ACK",id=1,op="status",status="ACCEPTED"))
        self.assertFalse(r.finish(done(1,"status"))["accepted_pass"])

    def test_full_double_five_steps_and_real_swap(self):
        for bad in (False,True):
            r=ExperimentRequest(1,"double",("auto",),0,30);r.feed(parsed("LABX_ACK",id=1,op="double",status="QUEUED"))
            for phase in range(1,6):r.feed(parsed("LABX_STATE",id=1,active=1,phase=phase,front=0x01400000 if phase==5 else 0x01000000,back=0x01000000 if phase==5 else 0x01400000,swaps=11 if phase==5 and not bad else 10,pending=int(phase==4),ready=int(phase in (3,4)),errors=0))
            self.assertEqual(r.finish(done(1,"double"))["accepted_pass"],not bad)


if __name__=="__main__":unittest.main()
