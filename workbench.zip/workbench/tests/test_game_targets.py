"""Hard targets must never silently turn into a lower-count measurement."""
import unittest
import os
import test_game_load as support
from pathlib import Path
import persistent_profile
from control_core import parse_capabilities

class GameTargetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=support.base.QApplication.instance() or support.base.QApplication(['game-target-tests'])
    setUp=support.GameLoadPanelTests.setUp
    tearDown=support.GameLoadPanelTests.tearDown
    ready=support.GameLoadPanelTests.ready
    start_run=support.GameLoadPanelTests.start_run
    complete=support.GameLoadPanelTests.complete
    def test_targets_load_exact_values_without_sending_run(self):
        p=self.ready()
        for side,n in ((8,20000),(32,5000)):
            sent=len(self.sent)
            self.assertTrue(p.load_target(side))
            self.assertEqual((p.bosses.value(),p.enemies.value(),p.size.currentData(),p.count.value()),(6,12,side,n))
            self.assertFalse(p.matrix.isChecked());self.assertFalse(p.descend.isChecked())
            self.assertEqual(len(self.sent),sent)
    def test_failed_hard_target_never_queues_lower_count(self):
        p=self.ready();p.load_target(32);p.start();p.menu_ready(True)
        r=self.complete('FAIL','timing',{'us':2000000,'scans':120,'missed':60,'gap':2})
        self.assertEqual(r['args'][2:4],[5000,32]);self.assertFalse(p.queue)
        self.assertEqual(r['stat']['nmin'],5000)
    def test_active_target_buttons_cannot_mutate_request(self):
        p=self.start_run();before=(p.count.value(),p.size.currentData(),tuple(p._request.args))
        self.assertFalse(p.load_target(32))
        self.assertEqual((p.count.value(),p.size.currentData(),tuple(p._request.args)),before)
    def test_new_hardware_capability_is_explicit_and_range_checked(self):
        caps=support.CAPS+' batch32=1 tprof=1'
        self.assertEqual(parse_capabilities(caps)['batch32'],1)
        self.assertEqual(parse_capabilities(caps)['tprof'],1)
        self.assertEqual(parse_capabilities(support.CAPS)['batch32'],0)
        self.assertIsNone(parse_capabilities(caps.replace('batch32=1','batch32=2')))
    def test_motion_and_preflight_capability_bits_are_explicit(self):
        base=support.CAPS+' batch32=1 tprof=1'
        self.assertEqual((parse_capabilities(base)['motion'],parse_capabilities(base)['pref']),(0,0))
        caps=base+' motion=1 pref=1'
        self.assertEqual((parse_capabilities(caps)['motion'],parse_capabilities(caps)['pref']),(1,1))
        for bad in ('motion=2 pref=1','motion=1 pref=true','motion=1 pref=1 motion=0'):
            self.assertIsNone(parse_capabilities(base+' '+bad))
    def test_real_new_image_and_full_hardware_evidence_validate(self):
        # Real frozen build evidence; no mock, port, programmer or board work.
        p=Path(os.environ.get('TI60_TEST_MANIFEST',Path(__file__).resolve().parents[2]/'release/out/manifest.json'))
        if not p.is_file():self.skipTest('Optional frozen release manifest is not included in the anonymous source submission')
        result=persistent_profile.load_profile(p)
        self.assertEqual(result.flash_capacity_bytes,8388608)
        self.assertFalse(result.flash_programmed)
