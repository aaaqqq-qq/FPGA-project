"""Same firmware is not the same hardware release; all fixtures are temporary."""
from pathlib import Path
import json,os,shutil,subprocess,sys,unittest
from unittest.mock import patch
import control_core as c
import test_bundle_routing as support
import test_ui as native

class PlatformRoutingTests(unittest.TestCase):
 setUp=support.BundleRoutingTests.setUp
 bundle=support.BundleRoutingTests.bundle
 paired=support.BundleRoutingTests.paired
 change=support.BundleRoutingTests.change
 def wrong_platform(self,name='old_same_elf'):
  root=self.bundle(name)
  self.change(root,'out/manifest.json','platform',{'bit_sha256':'c84519f2d214e5cf8700f376b23c3cb95125e3c7689ad9fb82e5b9947ed1a033'})
  return root
 def test_saved_same_elf_old_hardware_is_skipped_for_own_paired_bundle(self):
  own=self.paired();old=self.wrong_platform()
  self.assertEqual(json.loads((old/'out/manifest.json').read_text())['elf']['sha256'],c.CURRENT_ELF_SHA256)
  self.assertTrue(c.persistent_bundle_available(old));self.assertFalse(c.current_bundle_available(old))
  self.assertEqual(c.discover_bundle(old),own)
 def test_environment_same_elf_old_hardware_cannot_shadow_own_paired_bundle(self):
  own=self.paired();old=self.wrong_platform()
  with patch.dict(os.environ,{'TI60_BUNDLE_ROOT':str(old)}):self.assertEqual(c.discover_bundle(old),own)
 def test_missing_malformed_or_other_platform_never_matches_current(self):
  for value in (None,{},[],True,'hardware',{'sha256':c.CURRENT_PLATFORM_SHA256},{'bit_sha256':True},{'bit_sha256':'f'*64}):
   root=self.bundle('bad_'+str(len(list(self.root.iterdir()))));self.change(root,'out/manifest.json','platform',value)
   with self.subTest(platform=value):
    self.assertFalse(c.current_bundle_available(root));self.assertEqual(c.discover_bundle(root),self.default)
 def test_correct_hardware_does_not_excuse_old_firmware(self):
  root=self.bundle('same_hardware_old_elf');self.change(root,'out/manifest.json','elf',{'sha256':'0'*64})
  self.assertFalse(c.current_bundle_available(root));self.assertEqual(c.discover_bundle(root),self.default)
 def test_routing_match_still_requires_full_burn_artifact_validation(self):
  root=self.paired();self.assertTrue(c.current_bundle_available(root))
  with patch.object(c,'load_persistent_profile',side_effect=ValueError('wrong complete-image hash'))as full:
   with self.assertRaisesRegex(ValueError,'wrong complete-image hash'):c.build_command(root,'touhou_LAB',False,sys.executable)
   full.assert_called_once_with(root/'out/manifest.json',reviewed=True)
 def test_startup_message_names_actual_path_version_and_both_bit_identities(self):
  root=self.paired()
  with patch.object(c,'load_persistent_profile',side_effect=AssertionError('Not startup routing'))as full:
   text=c.bundle_startup_message(root);full.assert_not_called()
  self.assertIn(str(root),text);self.assertIn('赛题二工作台 2.8.9',text)
  self.assertIn('清单硬件 '+c.CURRENT_PLATFORM_SHA256[:12],text);self.assertIn('当前硬件 '+c.CURRENT_PLATFORM_SHA256[:12],text)
  self.assertIn(c.CURRENT_ELF_SHA256[:12],text)
 def test_clean_external_process_skips_saved_wrong_bit_and_logs_own_bundle(self):
  own=self.paired();old=self.wrong_platform();production=Path(__file__).resolve().parents[1]
  for name in ('control_core.py','persistent_profile.py','image_protocol.py'):shutil.copy2(production/name,self.here/name)
  code="import sys,json;sys.path.insert(0,sys.argv[1]);import control_core as c;b=c.discover_bundle(sys.argv[2]);print(json.dumps({'bundle':str(b),'log':c.bundle_startup_message(b)}))"
  env=os.environ.copy();env.pop('TI60_BUNDLE_ROOT',None);env.pop('PYTHONHOME',None)
  run=subprocess.run([sys.executable,'-I','-c',code,str(self.here),str(old)],env=env,capture_output=True,text=True,check=True,timeout=15)
  row=json.loads(run.stdout);self.assertEqual(Path(row['bundle']),own);self.assertIn(str(own),row['log']);self.assertNotIn(str(old),row['log'])

class StartupIdentityLogTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):native.NativeUIContracts.setUpClass.__func__(cls)
 dispose_window=native.NativeUIContracts.dispose_window
 def setUp(self):
  self.save_patch=patch.object(native.ui.Settings,'save',side_effect=AssertionError('No real settings writes'))
  self.saved=self.save_patch.start();self.addCleanup(self.save_patch.stop)
  native.NativeUIContracts.setUp(self)
 def test_native_startup_log_identifies_version_selected_path_and_expected_hardware(self):
  text='\n'.join(self.window.session_lines)
  self.assertIn('工程身份',text);self.assertIn('赛题二工作台 2.8.9',text);self.assertIn(str(self.bundle),text)
  self.assertIn(c.CURRENT_PLATFORM_SHA256[:12],text);self.saved.assert_not_called()

if __name__=='__main__':unittest.main()
