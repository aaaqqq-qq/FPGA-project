"""Validate structured loader progress; ordinary console lines are not evidence.

The caller supplies complete lines (its existing stream reader owns buffering).
Byte progress is local to one stage. Only a successful process exit passed to
finish() can mark the complete download successful.
"""
from __future__ import annotations

import json
from typing import Any


_STAGES = ("files", "device", "configure", "load", "verify", "start")
_STEP = {"files": 1, "device": 1, "configure": 2, "load": 3, "verify": 4, "start": 5}
_FIELDS = frozenset(("stage", "step", "state", "done", "total", "unit"))


def _object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    obj: dict[str, Any] = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError("duplicate JSON key")
        obj[key] = value
    return obj


def _constant(value: str) -> None:
    raise ValueError("non-finite JSON number")


class DownloadProgress:
    """Monotonic five-step progress, with files/device sharing step one.

    feed() returns only validated fields, or None without changing state.
    finish() returns a terminal snapshot with complete, download_complete,
    check and label. In check mode complete means the offline check completed;
    download_complete is always False. A failed terminal snapshot contains no
    byte counters, so it cannot accidentally display 100% overall success.
    """

    def __init__(self) -> None:
        self.reset()

    def reset(self, check: bool = False) -> None:
        if type(check) is not bool:
            raise TypeError("check must be bool")
        self.check = check
        self._rank = -1
        self._current: dict[str, Any] | None = None
        self._terminal: dict[str, Any] | None = None

    def feed(self, line: str) -> dict[str, Any] | None:
        if self._terminal is not None or not isinstance(line, str):
            return None
        if not line.startswith("PROGRESS ") or len(line) > 2048:
            return None
        try:
            value = json.loads(line[9:], object_pairs_hook=_object, parse_constant=_constant)
        except (ValueError, TypeError, RecursionError):
            return None
        if not isinstance(value, dict) or set(value) - _FIELDS:
            return None
        stage, state = value.get("stage"), value.get("state")
        if not isinstance(stage, str) or stage not in _STEP or state not in ("running", "done"):
            return None
        step = value.get("step", _STEP[stage])
        if type(step) is not int or step != _STEP[stage]:
            return None
        rank = _STAGES.index(stage)
        if rank < self._rank or (self.check and rank > 1):
            return None
        has_done, has_total = "done" in value, "total" in value
        if has_done != has_total:
            return None
        if "unit" in value and (value["unit"] != "bytes" or not has_done):
            return None
        if has_done:
            done, total = value["done"], value["total"]
            if type(done) is not int or type(total) is not int or not 0 <= done <= total or total <= 0:
                return None
        result: dict[str, Any] = {"stage": stage, "step": step, "state": state}
        previous = self._current if rank == self._rank else None
        if previous:
            if previous["state"] == "done" and state != "done":
                return None
            if "done" in previous:
                if has_done and (value["done"] < previous["done"] or value["total"] != previous["total"]):
                    return None
                if "unit" in value and "unit" in previous and value["unit"] != previous["unit"]:
                    return None
                result.update({k: previous[k] for k in ("done", "total", "unit") if k in previous})
        if has_done:
            result.update(done=value["done"], total=value["total"])
        if "unit" in value:
            result["unit"] = value["unit"]
        if state == "done" and "done" in result and result["done"] != result["total"]:
            return None
        self._rank, self._current = rank, result
        return dict(result)

    def finish(self, success: bool) -> dict[str, Any]:
        if type(success) is not bool:
            raise TypeError("success must be bool")
        if self._terminal is not None:
            return dict(self._terminal)
        current = self._current or {"stage": "files", "step": 1}
        if success and not self.check:
            result: dict[str, Any] = {"stage": "start", "step": 5, "state": "done"}
        else:
            result = {"stage": current["stage"], "step": current["step"], "state": "done" if success else "failed"}
        result.update(complete=success, download_complete=success and not self.check, check=self.check)
        result["label"] = ("离线检查完成" if success else "离线检查失败") if self.check else ("下载完成" if success else "下载失败")
        self._terminal = result
        return dict(result)
