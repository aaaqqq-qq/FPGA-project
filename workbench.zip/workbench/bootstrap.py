"""Start the Touhou Project control center without automatic firmware actions."""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys
import traceback

DEFAULT_RUNTIME = Path(__file__).resolve().parent / "runtime"


def prepare_runtime() -> Path | None:
    """A frozen executable uses only the libraries collected in its bundle."""
    if getattr(sys, "frozen", False):
        return None
    for name in ("QT_PLUGIN_PATH", "QT_QPA_PLATFORM_PLUGIN_PATH"):
        os.environ.pop(name, None)
    value = os.environ.get("FPGA_CONTROL_RUNTIME", "").strip()
    candidates = [Path(value).expanduser()] if value else []
    candidates.extend([Path(__file__).resolve().parent / "runtime", DEFAULT_RUNTIME])
    for candidate in candidates:
        if (candidate / "PySide6").is_dir() and (candidate / "serial").is_dir():
            sys.path.insert(0, str(candidate))
            return candidate
    return None


def report_startup_error(error: BaseException) -> None:
    directory = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Ti60ControlCenter"
    try:
        directory.mkdir(parents=True, exist_ok=True)
        log = directory / "startup_error.log"
        log.write_text(traceback.format_exc(), encoding="utf-8")
        log_text = str(log)
    except OSError:
        log_text = "无法写入启动日志"
    message = (
        "赛题二工作台暂时无法启动。\n\n"
        "请先使用本目录的 README.txt 核对运行环境。\n"
        "源码版需要 PySide6-Essentials 和 pyserial；已打包的 EXE 不需要安装这些 Python 库。\n\n"
        f"原因：{type(error).__name__}: {error}\n\n日志：{log_text}"
    )
    print(message, file=sys.stderr)
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, message, "赛题二工作台 · 启动提示", 0x10)
        except Exception:
            pass


def run() -> int:
    runtime = prepare_runtime()
    try:
        import PySide6
        import serial
        if "--bootstrap-check" in sys.argv:
            print(json.dumps({
                "status": "PASS", "python": sys.executable,
                "frozen": bool(getattr(sys, "frozen", False)),
                "runtime": str(runtime) if runtime else None,
                "PySide6": PySide6.__version__, "pyserial": serial.__version__,
                "hardware_accessed": False,
            }, ensure_ascii=False))
            return 0
        from main import main
        return int(main() or 0)
    except Exception as error:
        if "--bootstrap-check" in sys.argv:
            print(f"BOOTSTRAP_CHECK_FAILED {type(error).__name__}: {error}", file=sys.stderr)
        else:
            report_startup_error(error)
        return 1


if __name__ == "__main__":
    raise SystemExit(run())
