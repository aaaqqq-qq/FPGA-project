"""Bounded LABIMG1 RGB888 transfer contract; contains no device access."""
from __future__ import annotations

import base64
import binascii
from typing import Any

IMAGE_OPS = frozenset(("imgbegin", "imgdata", "imgcommit", "imgcopy", "imgabort", "imgstatus"))
MAX_WIDTH, MAX_HEIGHT = 1280, 720
MAX_RGB_BYTES = MAX_WIDTH * MAX_HEIGHT * 3
CHUNK_RGB_BYTES = 288
FRAME_PIXELS = MAX_WIDTH * MAX_HEIGHT
IMAGE_ERRORS = frozenset(("CRC", "SESSION", "OFFSET", "INCOMPLETE", "GUARD", "ENCODING"))
IMAGE_NUMBERS = frozenset(("session", "received", "total", "imgw", "imgh", "crc", "verified", "ready"))


def integer(v: Any, low: int, high: int, label: str) -> int:
    if type(v) is not int or not low <= v <= high:
        raise ValueError(label)
    return v


def image_arguments(operation: str, args: tuple | list) -> list[int | str]:
    if operation not in IMAGE_OPS:
        raise ValueError("未知图片操作")
    if operation == "imgstatus":
        if args:
            raise ValueError("图片状态操作不接受参数")
        return []
    expected = {"imgbegin": 4, "imgdata": 3, "imgcopy": 3, "imgcommit": 1, "imgabort": 1}[operation]
    if len(args) != expected:
        raise ValueError("图片操作参数数量错误")
    session = integer(args[0], 1, 2147483647, "图片会话编号无效")
    if operation == "imgbegin":
        return [session, integer(args[1], 1, MAX_WIDTH, "图片宽度应为1至1280"),
                integer(args[2], 1, MAX_HEIGHT, "图片高度应为1至720"),
                integer(args[3], 0, 0xffffffff, "图片CRC无效")]
    if operation == "imgdata":
        offset = integer(args[1], 0, MAX_RGB_BYTES - 3, "图片分块偏移无效")
        if offset % 3:
            raise ValueError("图片分块必须在RGB像素边界开始")
        data = args[2]
        if not isinstance(data, str) or not 4 <= len(data) <= 384 or len(data) % 4:
            raise ValueError("图片分块编码长度无效")
        try:
            raw = base64.b64decode(data, validate=True)
        except (ValueError, binascii.Error):
            raise ValueError("图片分块不是有效base64") from None
        if (not raw or len(raw) > CHUNK_RGB_BYTES or len(raw) % 3
                or offset + len(raw) > MAX_RGB_BYTES or base64.b64encode(raw).decode("ascii") != data):
            raise ValueError("图片分块必须包含1至96个完整RGB像素")
        return [session, offset, data]
    if operation == "imgcopy":
        return [session, integer(args[1], 0, MAX_WIDTH - 1, "搬运位置X超出画布"),
                integer(args[2], 0, MAX_HEIGHT - 1, "搬运位置Y超出画布")]
    return [session]


def image_reply_valid(values: dict) -> bool:
    """Require the actual image state even for a failed image operation."""
    if not IMAGE_NUMBERS <= values.keys():
        return False
    try:
        nums = {key: int(values[key]) for key in IMAGE_NUMBERS}
    except (ValueError, TypeError):
        return False
    if any(str(nums[key]) != str(values[key]) for key in IMAGE_NUMBERS):
        return False
    successful_copy = values.get("op") == "imgcopy" and values.get("status") == "PASS"
    if nums["verified"] != (FRAME_PIXELS if successful_copy else 0):
        return False
    if successful_copy and nums["ready"] != 1:
        return False
    if values.get("status") == "PASS":
        if values.get("op") == "imgcommit" and nums["ready"] != 1:
            return False
        if values.get("op") == "imgbegin" and (nums["ready"] or nums["received"] or not nums["total"]):
            return False
        if values.get("op") == "imgabort" and any(nums[k] for k in ("ready", "received", "total", "crc", "imgw", "imgh")):
            return False
    return (0 <= nums["session"] <= 2147483647
            and 0 <= nums["received"] <= nums["total"] <= MAX_RGB_BYTES
            and nums["received"] % 3 == 0 and nums["total"] % 3 == 0
            and 0 <= nums["imgw"] <= MAX_WIDTH and 0 <= nums["imgh"] <= MAX_HEIGHT
            and nums["total"] == nums["imgw"] * nums["imgh"] * 3
            and 0 <= nums["crc"] <= 0xffffffff and nums["ready"] in (0, 1)
            and nums["verified"] in (0, FRAME_PIXELS)
            and (not nums["ready"] or nums["total"] > 0 and nums["received"] == nums["total"]))
