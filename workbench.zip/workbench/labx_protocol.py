"""File-only LAB23 experiment protocol and evidence validation.

Nothing in this module imports serial, Qt, a programmer, or touches hardware.
An ACK means accepted, never measured or passed.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Any

FRAMEBUFFERS = {0x01000000, 0x01400000}
OPERATIONS = {"enter", "exit", "status", "mem", "compare", "double", "cancel"}
SIZES = {"small", "medium", "large"}
LAYOUTS = {"aligned", "offset", "boundary"}
KEY = ("group", "backend", "method")
SCHEMAS = {
    "LABX_ACK": {"id", "op", "status"},
    "LABX_PLAN": {"id", "op", "kind", "size", "layout", "frames", "warmup", "repeats", "expected", "w", "h", "task"},
    "LABX_SCOPE": {"id", "first", "middle", "last", "check", "units", "hz", "fps", "sample_mode", "actual_last"},
    "LABX_RESULT": {"id", *KEY, "task", "frames", "jobs", "pixels", "render_us", "wait_us"},
    "LABX_METRIC": {"id", *KEY, "elapsed_us", "swaps", "cycles", "read", "write", "uf", "check_us"},
    "LABX_CHECK": {"id", *KEY, "samples", "errors", "guards", "source", "checked", "first", "middle", "last", "actual", "replayed"},
    "LABX_STATE": {"id", "active", "phase", "front", "back", "swaps", "pending", "ready", "errors"},
    "LABX_DONE": {"id", "op", "status", "code", "completed", "active", "elapsed_us", "uf"},
}
TEXT_KEYS = {"op", "status", "code", "kind", "size", "layout", "backend", "method", "check", "units", "fps", "sample_mode"}


def labx_command(request_id: int, operation: str, *args: Any) -> bytes:
    if type(request_id) is not int or not 1 <= request_id <= 2147483647:
        raise ValueError("实验编号超出范围")
    if operation not in OPERATIONS:
        raise ValueError("未知实验操作")
    def integer(value, lo, hi):
        if type(value) is not int or not lo <= value <= hi:
            raise ValueError("实验参数超出范围")
    if operation in {"enter", "exit", "status", "cancel"}:
        if args: raise ValueError("此操作不接受额外参数")
    elif operation == "mem":
        if len(args) != 4 or args[0] not in {"fill", "copy"} or args[1] not in SIZES or args[2] not in LAYOUTS:
            raise ValueError("请选择填充/复制、规模和合法布局")
        integer(args[3], 1, 3)
    elif operation == "compare":
        if len(args) != 5 or args[0] not in {"blocks", "image"} or args[1] not in SIZES:
            raise ValueError("请选择移动方块/大图切换及规模")
        integer(args[2], 1, 120); integer(args[3], 0, 8); integer(args[4], 1, 3)
    elif len(args) != 1 or args[0] not in {"reset", "next", "auto"}:
        raise ValueError("未知双缓冲步骤")
    return (":labx %d %s%s\n" % (request_id, operation, " " + " ".join(map(str, args)) if args else "")).encode("ascii")


def parse_labx_reply(line: str) -> dict | None:
    fields = line.strip().split()
    if not fields or fields[0] not in SCHEMAS:
        return None
    values: dict[str, Any] = {"kind_line": fields[0], "raw": line.strip()}
    for item in fields[1:]:
        if "=" not in item: return None
        key, value = item.split("=", 1)
        if key in values or not re.fullmatch(r"[a-z][a-z_]*", key): return None
        if key in TEXT_KEYS:
            if not re.fullmatch(r"[A-Za-z0-9_]+", value): return None
            values[key] = value
        else:
            if not re.fullmatch(r"[0-9]+", value) or int(value) > 0xffffffffffffffff: return None
            values[key] = int(value)
    if not SCHEMAS[fields[0]] <= values.keys() or not 1 <= values.get("id", 0) <= 2147483647: return None
    if "op" in values and values["op"] not in OPERATIONS: return None
    for name in ("active", "pending", "ready"):
        if name in values and values[name] not in (0, 1): return None
    if fields[0] == "LABX_ACK" and values["status"] not in {"QUEUED", "ACCEPTED"}: return None
    if fields[0] == "LABX_ACK" and values["status"] != ("ACCEPTED" if values["op"] in {"cancel","status"} else "QUEUED"): return None
    if fields[0] == "LABX_DONE" and values["status"] not in {"PASS", "ERROR", "CANCELLED"}: return None
    if fields[0] in {"LABX_RESULT", "LABX_METRIC", "LABX_CHECK"}:
        if values["backend"] not in {"CPU", "FPGA"} or values["method"] not in {"split", "merged", "blocks", "image"}: return None
    if fields[0] == "LABX_STATE":
        if values["front"] not in FRAMEBUFFERS or values["back"] not in FRAMEBUFFERS or values["front"] == values["back"] or values["phase"] not in range(6): return None
    return values


@dataclass
class ExperimentRequest:
    request_id: int
    operation: str
    args: tuple
    started: float
    deadline: float
    acknowledged: bool = False
    plan: dict | None = None
    scope: dict | None = None
    records: dict = field(default_factory=dict)
    states: list = field(default_factory=list)
    raw: list = field(default_factory=list)
    protocol_errors: list = field(default_factory=list)

    def feed(self, reply: dict) -> bool:
        if reply.get("id") != self.request_id: return False
        if "op" in reply and reply["op"] != self.operation: return False
        self.raw.append(dict(reply))
        kind = reply["kind_line"]
        if kind == "LABX_ACK": self.acknowledged = True
        elif kind == "LABX_PLAN":
            if self.plan is not None: self.protocol_errors.append("重复PLAN")
            else: self.plan = dict(reply)
        elif kind == "LABX_SCOPE":
            if self.scope is not None: self.protocol_errors.append("重复SCOPE")
            else: self.scope = dict(reply)
        elif kind in {"LABX_RESULT", "LABX_METRIC", "LABX_CHECK"}:
            key = tuple(reply[k] for k in KEY)
            record = self.records.setdefault(key, {})
            if kind in record: self.protocol_errors.append("重复结果片段")
            else: record[kind] = dict(reply)
        elif kind == "LABX_STATE": self.states.append(dict(reply))
        return True

    def finish(self, done: dict) -> dict:
        reasons = list(self.protocol_errors)
        if not self.acknowledged: reasons.append("缺少排队确认")
        if done.get("status") != "PASS" or done.get("code") != "OK": reasons.append(done.get("code", "未完成"))
        if done.get("uf", 0): reasons.append("显示新增欠流")
        rows = []
        if self.operation in {"mem", "compare"}:
            reasons.extend(self._check_measurements(done, rows))
        elif self.operation == "double":
            phases = [s["phase"] for s in self.states]
            if not phases: reasons.append("缺少真实缓冲状态")
            if any(s["errors"] for s in self.states): reasons.append("缓冲内容校验失败")
            if self.args == ("auto",) and phases != [1, 2, 3, 4, 5]: reasons.append("双缓冲五步不完整")
            if self.args == ("reset",) and phases != [1]: reasons.append("缓冲未复位至第一步")
            if self.args == ("auto",) and len(self.states) == 5:
                initial, half, ready, queued, final = self.states
                if any(s["front"] != initial["front"] or s["back"] != initial["back"] or s["swaps"] != initial["swaps"] for s in (half,ready)):
                    reasons.append("后台未完成前已改变前台")
                if ready["ready"] != 1 or final["pending"] != 0 or final["front"] != initial["back"] or final["back"] != initial["front"] or ((final["swaps"]-initial["swaps"]) & 0xffffffff) != 1:
                    reasons.append("缺少真实安全换帧确认")
        elif self.operation == "status":
            if not self.states or self.states[-1]["active"] != done.get("active"):
                reasons.append("缺少一致的板端隔离状态")
        if done.get("active") != (0 if self.operation == "exit" else 1) and self.operation not in {"status", "cancel"}:
            reasons.append("显示占用状态不一致")
        return dict(id=self.request_id, op=self.operation, args=list(self.args), done=dict(done),
                    accepted_pass=not reasons, reasons=sorted(set(reasons)), plan=self.plan,
                    scope=self.scope, rows=rows, states=list(self.states), raw=list(self.raw))

    def _check_measurements(self, done: dict, rows: list) -> list[str]:
        reasons = []
        p, s = self.plan, self.scope
        if not p or not s: return ["缺少任务预登记或像素抽样范围"]
        if self.operation == "mem":
            kind, size, layout, repeats = self.args
            frames, warmup = 1, 0
            methods, backends = {"split", "merged"}, {"FPGA"}
        else:
            kind, size, frames, warmup, repeats = self.args
            layout = "aligned"
            methods, backends = {kind}, {"CPU", "FPGA"}
        for key, expected in dict(op=self.operation, kind=kind, size=size, frames=frames, warmup=warmup, repeats=repeats, expected=2*repeats).items():
            if p.get(key) != expected: reasons.append("任务预登记与请求不符:"+key)
        if self.operation == "mem" and p.get("layout") != layout: reasons.append("访存布局与请求不符")
        width,height={"small":(128,96),"medium":(512,256),"large":(960,480)}[size]
        if (p.get("w"),p.get("h"))!=(width,height):reasons.append("预登记尺寸与规模不符")
        indices = {0, frames//2, frames-1}
        if any(s[k] != v for k, v in dict(first=0,middle=frames//2,last=frames-1).items()) or s.get("check") != "full_frame" or s.get("units") != "bytes" or s.get("hz") != 100000000 or s.get("fps") != "display_wall" or s.get("sample_mode") != "last_actual" or s.get("actual_last") != 1:
            reasons.append("像素抽样或计量定义不符")
        if len(self.records) != 2*repeats or done.get("completed") != 2*repeats: reasons.append("成对结果数量不完整")
        groups: dict[int, list] = {}
        for (group, backend, method), fragments in self.records.items():
            if group not in range(1,repeats+1): reasons.append("结果组编号超出预登记")
            if set(fragments) != {"LABX_RESULT", "LABX_METRIC", "LABX_CHECK"}:
                reasons.append("结果三片段缺失"); continue
            row = {}
            for fragment in fragments.values(): row.update(fragment)
            if backend not in backends or method not in methods: reasons.append("结果方法不符")
            if row["frames"] != frames or row["task"] != p["task"]: reasons.append("结果任务身份不一致")
            if self.operation=="mem":
                jobs=((width+31)//32)*((height+15)//16) if method=="split" else 1
                pixels=width*height
            else:
                edge=min(40,max(8,width//12))
                jobs=2 if kind=="image" else 13
                pixels=2*width*height if kind=="image" else width*height+12*edge*edge
            if row["jobs"] != jobs*frames or row["pixels"] != pixels*frames: reasons.append("完成任务数或有效像素与预登记不符")
            if row["swaps"] != frames:reasons.append("实际换帧数不符")
            if row["render_us"] <= 0 or row["elapsed_us"] <= 0 or row["pixels"] <= 0 or row["jobs"] <= 0: reasons.append("缺少有效计量")
            if row["errors"] or row["guards"] or row["source"] or row["uf"]: reasons.append("像素/保护区/源图/欠流检查失败")
            if row["samples"] != len(indices) or row["checked"] != len(indices)*1280*720 or {row["first"],row["middle"],row["last"]} != indices: reasons.append("实际像素抽样范围不完整")
            if row["actual"] != 1 or row["replayed"] != len(indices)-1:reasons.append("末帧实测与首中帧重放范围不符")
            if backend == "CPU" and any(row[k] for k in ("cycles","read","write")): reasons.append("CPU不应冒用引擎计数")
            if backend == "FPGA" and (not row["cycles"] or row["write"] != row["pixels"]*4):reasons.append("引擎周期或有效写字节不符")
            row["actual_fps"] = row["swaps"]*1000000/row["elapsed_us"] if row["elapsed_us"] else None
            row["effective_MBps"] = row["pixels"]*4/row["render_us"] if row["render_us"] else None
            groups.setdefault(group, []).append(row); rows.append(row)
        if len(groups) != repeats: reasons.append("重复组数不符")
        for group_rows in groups.values():
            pairs = {(r["backend"],r["method"]) for r in group_rows}
            expected = {(b,m) for b in backends for m in methods}
            if pairs != expected or len(group_rows) != 2: reasons.append("同组配对不完整")
            if len({(r["task"], r["frames"],r["pixels"]) for r in group_rows}) != 1: reasons.append("同组有效工作量不一致")
        return reasons


def request_timeout(operation: str) -> float:
    return 180.0 if operation in {"mem", "compare"} else 30.0
